"""Historical G4 terminal qualification, private Linux root and pinned NumPy.
No economics and no Windows-host invocation. Large QS1 runs belong on the PC.
"""
from pathlib import Path
import argparse,hashlib,json,os,platform,shutil,subprocess,sys,tempfile,time,venv,zipfile
ROOT=Path(__file__).resolve().parents[1]
PWSH_SHA='3C6E4D629571429CF6CC86DB94278E2CE17349EDBBFE0A0DE007BB6BCCDBC208'

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest().upper()

def safe_extract(z,d):
 with zipfile.ZipFile(z) as a:
  names=a.namelist();normalized=[n.replace('\\','/') for n in names]
  if len({n.casefold() for n in normalized})!=len(names):raise RuntimeError('ZIP_DUPLICATE')
  if a.testzip():raise RuntimeError('ZIP_CRC')
  for member,name in zip(a.infolist(),normalized):
   if name.startswith('/') or ':' in name or any(x in ('','.','..') for x in name.split('/')) or (member.external_attr>>16)&0o170000==0o120000:raise RuntimeError('ZIP_UNSAFE')
  d.mkdir(exist_ok=False)
  for member,name in zip(a.infolist(),normalized):
   p=d/name;p.parent.mkdir(parents=True,exist_ok=True)
   with a.open(member) as src,p.open('xb') as dst:shutil.copyfileobj(src,dst)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pwsh',type=Path);n=ap.parse_args()
 if sys.platform!='linux' or sys.version_info[:2]!=(3,12) or platform.machine()!='x86_64':raise RuntimeError('LINUX_CPYTHON_3_12_X86_64_REQUIRED')
 libc,version=platform.libc_ver();assert libc=='glibc' and tuple(map(int,version.split('.')[:2]))>=(2,28)
 sys.path.insert(0,str(ROOT/'CODE'));from pegasus_entry import verify_tree
 verify_tree()
 pwsh=n.pwsh or (Path(shutil.which('pwsh')) if shutil.which('pwsh') else None)
 if pwsh is None or not pwsh.is_absolute() or sha(pwsh)!=PWSH_SHA:raise RuntimeError('EXACT_PWSH_7_6_6_REQUIRED; supply --pwsh absolute_path')
 work=Path(tempfile.mkdtemp(prefix='PEGASUS_QS1_G4_',dir='/tmp'));print('OWNED_LINUX_ROOT='+str(work),flush=True)
 env={**os.environ,'PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1','DOTNET_SYSTEM_GLOBALIZATION_INVARIANT':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','XDG_CONFIG_HOME':str(work/'config'),'XDG_CACHE_HOME':str(work/'cache')}
 env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
 receipt={'schema':'PEGASUS_QS1_ENV_WRAPPER_V002','work':str(work),'python':sys.version,'pwsh_sha256':sha(pwsh),'cases':[],'result':'BLOCKED'}
 def call(label,argv,expected=0,contains=None,budget=180):
  start=time.monotonic();log=work/(label+'.log')
  with log.open('x') as f:
   p=subprocess.Popen(argv,cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT)
   while p.poll() is None:
    if time.monotonic()-start>budget:raise RuntimeError('TIMEOUT_NO_KILL_RECONCILE_PID '+str(p.pid))
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:print('QS1_HEARTBEAT='+label+' elapsed_s='+str(round(time.monotonic()-start)),flush=True)
  rc=p.wait();text=log.read_text(errors='replace')
  if (expected is None and rc==0) or (expected is not None and rc!=expected) or (contains and contains not in text):raise RuntimeError(label+' failed rc='+str(rc))
  receipt['cases'].append({'name':label,'rc':rc,'log_sha256':sha(log)})
 try:
  archive=ROOT/'evidence/E01_POST_PID_REUSE_20261008_RECONSTRUCTED.zip'
  if sha(archive)!='3757373881C20D8329E5D4C41B39D04BD25403BAA0453AEA51494CA9B64B8EC0':raise RuntimeError('SOURCE_IDENTITY')
  safe_extract(archive,work/'source');shutil.copytree(ROOT/'HISTORICAL_G4',work/'G4')
  env['MINOTAURO_E01_PAYLOAD']=str(work/'source/EVIDENCE/payload');env['MINOTAURO_PWSH']=str(pwsh)
  venv.EnvBuilder(with_pip=True,system_site_packages=False).create(work/'venv');py=work/'venv/bin/python'
  call('NEGATIVE_NUMPY_ABSENT',[str(py),'-B','-c','import numpy'],None,"No module named 'numpy'")
  dep=ROOT/'dependencies';bad=work/'bad.lock';bad.write_text('numpy==2.4.6 --hash=sha256:'+'0'*64+'\n')
  install=[str(py),'-B','-m','pip','--isolated','--disable-pip-version-check','install','--no-index','--find-links',str(dep),'--only-binary=:all:','--require-hashes','--no-deps','--no-compile','-r']
  call('NEGATIVE_WHEEL_HASH',install+[str(bad)],None,'DO NOT MATCH THE HASHES')
  call('NEGATIVE_NO_PARTIAL_INSTALL',[str(py),'-B','-c','import numpy'],None,"No module named 'numpy'")
  call('PINNED_NUMPY_INSTALL',install+[str(dep/'requirements_linux.lock')])
  probe="import sys,numpy,site,pathlib;assert numpy.__version__=='2.4.6';assert site.ENABLE_USER_SITE is False;assert pathlib.Path(numpy.__file__).resolve().is_relative_to(pathlib.Path(sys.prefix));sys.path.insert(0,sys.argv[1]);import test_qs1,unittest;assert unittest.defaultTestLoader.loadTestsFromModule(test_qs1).countTestCases()==55;print(sys.executable,numpy.__version__,numpy.__file__)"
  call('IMPORT_55_BEFORE_TERMINAL',[str(py),'-B','-c',probe,str(work/'G4/tests')])
  call('QS1_TERMINAL',[str(py),'-B',str(work/'G4/tests/run_qs1.py'),str(work/'qs1_terminal_receipt.json')],budget=7200)
  terminal=json.loads((work/'qs1_terminal_receipt.json').read_text())
  assert terminal['result']=='PASS' and terminal['tests_run']==terminal['passed']==55 and terminal['adapter_tree_unchanged'] and terminal['e01_payload_unchanged']
  receipt['result']='PASS_G4_TERMINAL_ONLY_NOT_FULL_QUALIFIED'
 finally:
  (work/'WRAPPER_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
  result=ROOT.parent/('PEGASUS_QS1_RESULT_'+work.name+'.zip')
  with zipfile.ZipFile(result,'x',zipfile.ZIP_DEFLATED) as z:
   for p in sorted(work.iterdir()):
    if p.is_file():z.write(p,p.name)
  print('RESULT_ZIP='+str(result)+' SHA256='+sha(result),flush=True)
 return 0
if __name__=='__main__':sys.exit(main())
