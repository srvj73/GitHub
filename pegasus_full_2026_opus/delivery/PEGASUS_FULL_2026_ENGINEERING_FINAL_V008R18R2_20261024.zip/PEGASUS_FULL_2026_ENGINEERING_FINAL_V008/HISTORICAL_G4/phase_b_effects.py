"""PHASE_B_ADAPTER_V001 — camada base: exceções, hashes, inventário por conteúdo,
escrita atômica de evidência, captura de trace e classificação de saída.

Regras de import-safety: somente stdlib; nenhum efeito em import; nenhum import do CODE.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import sys
from pathlib import Path

BLOCK = 8 * 1024 * 1024

EXIT_PASS = 0
EXIT_BLOCKED = 2
EXIT_PARTIAL = 3
EXIT_SAFE_STOP = 130


class AdapterBlocked(Exception):
    """Falha de gate rotulada (fail-closed)."""

    def __init__(self, code: str, detail: str = ""):
        self.code = str(code)
        self.detail = str(detail)
        super().__init__((self.code + " " + self.detail).strip())


class PreProcessRecordBoundary(BaseException):
    """BND_PRE_PROCESS_RECORD — fronteira do dry-run (SEAM-PPR, modo DRY)."""


class TraceGuardMismatch(BaseException):
    """Guarda de trace do RUN divergente do template do DRY (SEAM-PPR, modo RUN)."""


# --------------------------------------------------------------------------- hashes
def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def sha256_file(path, block: int = BLOCK, progress=None) -> str:
    h = hashlib.sha256()
    done = 0
    with Path(path).open("rb") as f:
        while True:
            b = f.read(block)
            if not b:
                break
            h.update(b)
            done += len(b)
            if progress is not None:
                progress(done)
    return h.hexdigest().upper()


def canonical_bytes(obj) -> bytes:
    """Mesma serialização de minotauro_v005r1_r23_contract.canonical_json_bytes."""
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def canonical_hash(obj, exclude_keys=()) -> str:
    if isinstance(obj, dict) and exclude_keys:
        ex = set(exclude_keys)
        obj = {k: v for k, v in obj.items() if k not in ex}
    return sha256_bytes(canonical_bytes(obj))


def load_json_strict(data: bytes):
    """JSON UTF-8 (BOM tolerado como o core: utf-8-sig) com rejeição de chaves duplicadas."""
    def hook(pairs):
        out = {}
        for k, v in pairs:
            if k in out:
                raise AdapterBlocked("JSON_DUPLICATE_KEY", k)
            out[k] = v
        return out
    try:
        return json.loads(data.decode("utf-8-sig"), object_pairs_hook=hook)
    except AdapterBlocked:
        raise
    except Exception as e:  # noqa: BLE001 - rotula qualquer falha de parse
        raise AdapterBlocked("JSON_INVALID", type(e).__name__) from e


# --------------------------------------------------------------------------- links
def is_link(p: Path) -> bool:
    try:
        if p.is_symlink():
            return True
        j = getattr(p, "is_junction", None)
        return bool(j()) if j is not None else False
    except OSError:
        return True


def assert_no_link_in_chain(p: Path, code: str) -> None:
    p = Path(p)
    for node in (p, *p.parents):
        if node.exists() and is_link(node):
            raise AdapterBlocked(code, str(node))


# --------------------------------------------------------------------------- inventory
def inventory(root, hash_files: bool = True) -> dict:
    """Inventário integral (sem top-N) por conteúdo: arquivos (bytes+SHA), diretórios e links."""
    root = Path(root)
    inv = {"root": str(root), "exists": root.is_dir(), "files": {}, "dirs": [], "links": [], "other": []}
    if not inv["exists"]:
        return inv
    if is_link(root):
        inv["links"].append(".")
        return inv
    for cur, dnames, fnames in os.walk(root, topdown=True, followlinks=False):
        curp = Path(cur)
        keep = []
        for d in sorted(dnames):
            dp = curp / d
            rel = dp.relative_to(root).as_posix()
            if is_link(dp):
                inv["links"].append(rel)
            else:
                inv["dirs"].append(rel)
                keep.append(d)
        dnames[:] = keep
        for fn in sorted(fnames):
            fp = curp / fn
            rel = fp.relative_to(root).as_posix()
            if is_link(fp):
                inv["links"].append(rel)
            elif fp.is_file():
                st = fp.stat()
                inv["files"][rel] = {"bytes": int(st.st_size),
                                     "sha256": sha256_file(fp) if hash_files else None}
            else:
                inv["other"].append(rel)
    inv["dirs"].sort(); inv["links"].sort(); inv["other"].sort()
    return inv


def inventory_digest(inv: dict) -> str:
    return canonical_hash({k: inv[k] for k in ("exists", "files", "dirs", "links", "other")})


def diff_inventories(before: dict, after: dict) -> list[str]:
    out = []
    if before.get("exists") != after.get("exists"):
        out.append("<root-existence>")
    bf, af = before.get("files", {}), after.get("files", {})
    for k in sorted(set(bf) | set(af)):
        if bf.get(k) != af.get(k):
            out.append("file:" + k)
    for kind in ("dirs", "links", "other"):
        b, a = set(before.get(kind, [])), set(after.get(kind, []))
        for k in sorted(b ^ a):
            out.append(kind[:-1] + ":" + k)
    return out


# --------------------------------------------------------------------------- evidence writes
def replace_with_retry(tmp: Path, path: Path, attempts: int = 8, pause: float = 0.25) -> None:
    """os.replace com novas tentativas: violação de compartilhamento transitória no Windows (leitor com o
    destino aberto, antivírus). Esgotadas as tentativas, a última exceção é propagada (fail-closed)."""
    import time as _t
    for i in range(max(1, attempts)):
        try:
            os.replace(tmp, path)
            return
        except OSError:
            if i == max(1, attempts) - 1:
                raise
            _t.sleep(pause)


def write_json_durable(path, obj, exclusive: bool = False) -> str:
    """Escrita canônica atômica com fsync do arquivo (diretório: fsync em POSIX)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = canonical_bytes(obj)
    if exclusive and path.exists():
        raise AdapterBlocked("EVIDENCE_EXISTS", str(path))
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("xb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    replace_with_retry(tmp, path)
    if os.name != "nt":
        fd = os.open(str(path.parent), os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    return sha256_bytes(data)


class EvidenceLog:
    """Log do adapter em caminho absoluto fixo (<evidence_root>/ADAPTER/ADAPTER.log)."""

    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def line(self, text: str) -> None:
        with self.path.open("a", encoding="utf-8", newline="\n") as f:
            f.write(text.rstrip("\n") + "\n")
            f.flush()
            os.fsync(f.fileno())


# --------------------------------------------------------------------------- trace
class TraceTee(io.TextIOBase):
    """Tee observacional de stdout: repassa tudo ao stream original e retém linhas completas."""

    def __init__(self, original):
        self.original = original
        self.lines: list[str] = []
        self._buf = ""

    def writable(self):
        return True

    def write(self, s):
        self.original.write(s)
        self._buf += s
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            self.lines.append(line)
        return len(s)

    def flush(self):
        self.original.flush()

    @property
    def encoding(self):
        return getattr(self.original, "encoding", "utf-8")


def parse_trace_line(line: str):
    parts = line.strip().split()
    if not parts:
        return None, {}
    head = parts[0]
    event, kv = head, {}
    if "=" in head:
        event, first = head.split("=", 1)
        kv["_value"] = first
    for tok in parts[1:]:
        if "=" in tok:
            k, v = tok.split("=", 1)
            kv[k] = v
    return event, kv


def normalize_trace(lines, trace_spec: dict) -> list[str]:
    keep = set(trace_spec["kept_events"])
    keys = trace_spec["kept_keys"]
    out = []
    for line in lines:
        event, kv = parse_trace_line(line)
        if event not in keep:
            continue
        sel = [f"{k}={kv[k]}" for k in keys.get(event, []) if k in kv]
        out.append(" ".join([event] + sel))
    return out


# --------------------------------------------------------------------------- exit classification
def classify_exit(mode: str, *, outcome: str, f1_marked: bool, control_changed: bool,
                  runtime_started: bool, runtime_tree_clean: bool, reclass_state: str | None,
                  protected_input_changed: bool = False, run_post_validated: bool = False) -> tuple[int, dict]:
    """Mapa de saída do envelope (0 PASS, 2 BLOCKED_NO_PROTECTED_EFFECT,
    3 FAIL_OR_BLOCKED_AFTER_PROTECTED_EFFECT, 130 SAFE_STOP_WITH_RUNTIME_EVIDENCE).

    mode ∈ {CLASSIFY, DRY, RUN}; outcome ∈ {PASS, BLOCKED, ERROR, INTERRUPT}.
    control_changed: CONTROL difere do BEFORE desta invocação.
    protected_input_changed: PREFLIGHT, CODE ou pacote do adapter diferem do BEFORE (ou não prováveis).
    run_post_validated: G24 PASS nesta invocação (só RUN).

    B01: no RUN, alteração de CONTROL é o efeito contratado; um RUN concluído com G24 validado é 0
    e não declara PARTIAL_EFFECT. Deriva de PREFLIGHT/CODE nunca é PASS, em nenhum modo.
    """
    if mode not in ("CLASSIFY", "DRY", "RUN"):
        raise ValueError("mode")
    labels: dict = {}
    effect = bool(f1_marked or control_changed or protected_input_changed)
    if outcome == "PASS":
        if protected_input_changed:
            labels.update(INCIDENT="PROTECTED_INPUT_CHANGED_ON_PASS_PATH", PASS_REFUSED="YES",
                          PARTIAL_EFFECT="YES")
            return EXIT_PARTIAL, labels
        if mode == "RUN":
            if not run_post_validated:
                labels.update(INCIDENT="RUN_PASS_WITHOUT_G24", PASS_REFUSED="YES",
                              PARTIAL_EFFECT="YES" if effect else "NO")
                return (EXIT_PARTIAL if effect else EXIT_BLOCKED), labels
            labels.update(EFFECT="COMPLETE_FINAL_VALID", RUN_POST="G24_PASS")
            return EXIT_PASS, labels
        if control_changed or f1_marked:
            labels.update(INCIDENT="CONTROL_CHANGED_IN_" + mode, PASS_REFUSED="YES", PARTIAL_EFFECT="YES")
            return EXIT_PARTIAL, labels
        labels["PARTIAL_EFFECT"] = "NO"
        return EXIT_PASS, labels
    if outcome == "INTERRUPT":
        if mode != "RUN":
            if control_changed or protected_input_changed or f1_marked:
                labels.update(SAFE_STOP="NO", PARTIAL_EFFECT="YES", INCIDENT="PROTECTED_CHANGED_IN_" + mode)
                return EXIT_PARTIAL, labels
            if runtime_started and not runtime_tree_clean:
                labels.update(SAFE_STOP="NO", PROCESS_TREE="UNPROVEN", EFFECT="NONE_IN_CONTROL")
                return EXIT_BLOCKED, labels
            labels.update(SAFE_STOP="YES", EFFECT="NONE",
                          PROCESS_TREE="YES" if runtime_started else "NOT_APPLICABLE")
            return EXIT_SAFE_STOP, labels
        if protected_input_changed:
            labels.update(SAFE_STOP="NO", PARTIAL_EFFECT="YES", INCIDENT="PROTECTED_INPUT_CHANGED_IN_RUN")
            return EXIT_PARTIAL, labels
        if not f1_marked and not control_changed:
            labels.update(SAFE_STOP="YES", EFFECT="NONE", PROCESS_TREE="NOT_APPLICABLE")
            return EXIT_SAFE_STOP, labels
        if runtime_started and runtime_tree_clean and reclass_state in ("PREPARED", "IN_PROGRESS"):
            labels.update(SAFE_STOP="YES", PROCESS_TREE="YES", STATE_AFTER=reclass_state)
            return EXIT_SAFE_STOP, labels
        labels.update(SAFE_STOP="NO", PARTIAL_EFFECT="YES", STATE_AFTER=str(reclass_state))
        return EXIT_PARTIAL, labels
    # BLOCKED / ERROR
    if effect:
        labels["PARTIAL_EFFECT"] = "YES"
        if mode != "RUN" and (control_changed or f1_marked):
            labels["INCIDENT"] = "CONTROL_CHANGED_IN_" + mode
        if protected_input_changed:
            labels["INCIDENT_PROTECTED_INPUT"] = "CHANGED"
        return EXIT_PARTIAL, labels
    labels["PARTIAL_EFFECT"] = "NO"
    if runtime_started and not runtime_tree_clean:
        labels["PROCESS_TREE"] = "UNPROVEN"
    return EXIT_BLOCKED, labels


def downgrade_for_missing_receipt(code: int, *, effect: bool) -> int:
    """B02: um receipt não gravado/não verificado nunca preserva PASS (0) nem SAFE_STOP (130)."""
    if code in (EXIT_PASS, EXIT_SAFE_STOP):
        return EXIT_PARTIAL if effect else EXIT_BLOCKED
    return code


# --------------------------------------------------------------------------- status incremental (B05)
STATUS_FIELDS = ("PHASE", "PROGRESS", "COMMITTED", "TOTAL", "RATE", "ETA", "FINISH", "ACTIVE",
                 "READY_WAITING", "CHECKPOINT", "SAFE_STOP")
STATUS_CADENCE_SECONDS = 30


def fmt_eta(seconds) -> str:
    """Formato canônico D.HH.MM.SS ou UNKNOWN."""
    if seconds is None:
        return "UNKNOWN"
    try:
        s = int(round(float(seconds)))
    except (TypeError, ValueError):
        return "UNKNOWN"
    if s < 0:
        return "UNKNOWN"
    d, r = divmod(s, 86400)
    h, r = divmod(r, 3600)
    m, sec = divmod(r, 60)
    return f"{d}.{h:02d}.{m:02d}.{sec:02d}"


def write_status_atomic(path, obj, attempts: int = 8, pause: float = 0.25) -> str:
    """Status incremental: tmp exclusivo + fsync, depois os.replace com novas tentativas quando o leitor
    (bootstrap) mantém o destino aberto (violação de compartilhamento no Windows). Sem remoção de arquivos:
    se todas as tentativas falharem, o único tmp desta escrita permanece no diretório owned e a falha é rotulada."""
    import time as _t
    path = Path(path)
    data = canonical_bytes(obj)
    import threading as _th
    tmp = path.with_name(f"{path.name}.{os.getpid()}.{_th.get_ident()}.{_t.time_ns()}.tmp")
    try:
        with tmp.open("xb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        replace_with_retry(tmp, path, attempts, pause)
    except OSError as e:
        raise AdapterBlocked("STATUS_WRITE_FAILED", type(e).__name__) from e
    return sha256_bytes(data)


def stdout_kv(key: str, value) -> None:
    sys.stdout.write(f"{key}={value}\n")
    sys.stdout.flush()
