"""PHASE_B_ADAPTER_V001 — classificador de estado (§5.5), somente leitura.

classify_structure() decide o estado candidato apenas a partir do inventário por conteúdo
de CONTROL. validate_in_progress()/journal_preview() usam validadores congelados (após G06),
sempre sem escrita (checkpoint presente => _load_checkpoint é somente leitura, DD-3/PX4).
Nunca chama recover().
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path

from phase_b_contract import DATE_RE, load_json_strict, pinned_files
from phase_b_effects import AdapterBlocked, canonical_bytes, sha256_bytes, sha256_file

EMPTY, PREPARED, IN_PROGRESS, FINAL_VALID, BLOCKED = (
    "EMPTY", "PREPARED", "IN_PROGRESS", "FINAL_VALID", "BLOCKED_AMBIGUOUS")

JOURNAL_RE = re.compile(r"^PHASE_B/_commit_journal/(\d{4}-\d{2}-\d{2})\.(\d+_\d+)\.json$")
SESSION_FILE_RE = re.compile(r"^PHASE_B/sessions/(\d{4}-\d{2}-\d{2})(\.pending)?/([^/]+)$")
LEDGER_RE = re.compile(r"^PHASE_B/EVENT_LEDGER_2026_FROZEN_ONLY/(\d{4}-\d{2}-\d{2})\.jsonl\.gz$")
SEAL_RE = re.compile(r"^TELEMETRY/SESSION_SEALS/([0-9a-f]{64})/(\d{4}-\d{2}-\d{2})\.json$")


def seal_key(control_root) -> str:
    """Mesma chave de r1r11_coordinator.Runtime.seal_precommit/verify_committed (hexdigest minúsculo)."""
    return hashlib.sha256(str((Path(control_root) / "PHASE_B").resolve()).encode()).hexdigest()


def _result(state, findings, **extra):
    d = {"state": state, "findings": sorted(set(findings))}
    d.update(extra)
    return d


def _normalize_runtime_dirs(dirs, control_root):
    """Reconcile only physically proven PHASE_B runtime dirs.

    A bare inventory label is normalized only when the corresponding physical
    directory exists under CONTROL/PHASE_B and no same-named bare directory
    exists under CONTROL. Unknown/ambiguous directories remain blocking.
    """
    root = Path(control_root)
    out = set(dirs)
    for d in list(out):
        if not (d in ('_commit_journal','sessions') or d.startswith('sessions/')):
            continue
        bare = root / Path(d)
        phase = root / 'PHASE_B' / Path(d)
        if phase.is_dir() and not bare.exists():
            out.remove(d)
            out.add('PHASE_B/' + d)
    return out


def classify_structure(inv: dict, constants: dict, control_root) -> dict:
    findings = []
    if not inv.get("exists"):
        return _result(BLOCKED, ["CONTROL_MISSING"])
    if inv["links"] or inv["other"]:
        return _result(BLOCKED, [f"LINK_OR_SPECIAL:{x}" for x in inv["links"] + inv["other"]])
    files, dirs = inv["files"], _normalize_runtime_dirs(inv["dirs"], control_root)
    for rel in list(files) + list(dirs):
        top = rel.split("/", 1)[0]
        if top in ("PHASE_A", "PHASE_C", "PILOT_A"):
            findings.append(f"FORBIDDEN_PHASE_ROOT:{top}")
        if "_avast_" in rel.lower():
            findings.append(f"ANTIVIRUS_ARTIFACT:{rel}")
    if findings:
        return _result(BLOCKED, findings)
    pins = pinned_files(constants["control_prepared"]["files"])
    base_names = (constants["config"]["path"], constants["owner_authorization"]["path"])
    for b in base_names:
        if files.get(b) != pins[b]:
            findings.append(f"BASE_FILE_DRIFT:{b}")
    if findings:
        return _result(BLOCKED, findings)
    p21 = constants["prepared_21"]
    present = [p for p in p21 if p in files]
    run_binding = constants["run_owned_names"]["run_binding"]
    others = sorted(set(files) - set(base_names) - set(p21) - {run_binding})
    base_dirs = {"GATES", "PREFLIGHT"}
    prep_dirs = set(constants["control_prepared"]["dirs"])

    # EMPTY
    if not present and not others and run_binding not in files:
        if dirs <= prep_dirs and base_dirs <= dirs:
            return _result(EMPTY, [])
        return _result(BLOCKED, [f"EMPTY_UNEXPECTED_DIR:{d}" for d in sorted(dirs - prep_dirs)] or ["EMPTY_BASE_DIRS_MISSING"])
    # 21 exatos
    divergent = [p for p in p21 if files.get(p) != pins[p]]
    if divergent:
        return _result(BLOCKED, [f"PREPARED_DIVERGENT:{p}" for p in divergent])
    # PREPARED
    if not others:
        if dirs != prep_dirs:
            return _result(BLOCKED, [f"PREPARED_DIR_DELTA:{d}" for d in sorted(dirs ^ prep_dirs)])
        return _result(PREPARED, [], run_binding_present=run_binding in files)
    # IN_PROGRESS / FINAL_VALID candidatos
    if "PHASE_B/CHECKPOINT.json" not in files:
        return _result(BLOCKED, ["RUNTIME_RESIDUE_WITHOUT_CHECKPOINT"] + [f"RESIDUE:{o}" for o in others[:20]])
    if run_binding not in files:
        return _result(BLOCKED, ["CHECKPOINT_WITHOUT_ADAPTER_RUN_BINDING"])
    names = constants["run_owned_names"]
    tel_res = [re.compile(r) for r in names["telemetry_files_regex"]]
    session_names = set(names["session_files"])
    key = seal_key(control_root)
    journals, pending, sessions, seals, ledger, fin_present = [], {}, {}, [], [], []
    scratch_files, runlock = [], False
    final_report = names["final_report"]
    completion = names["completion_receipt"]
    for o in others:
        if o == "PHASE_B/CHECKPOINT.json":
            continue
        if o == "PHASE_B/CHECKPOINT.json.v004-next":
            findings.append("CHECKPOINT_NEXT_TEMP")  # válido só com journal (checado abaixo)
            continue
        m = JOURNAL_RE.match(o)
        if m:
            journals.append((o, m.group(1), m.group(2)))
            continue
        m = SESSION_FILE_RE.match(o)
        if m and m.group(3) in session_names:
            target = pending if m.group(2) else sessions
            target.setdefault(m.group(1), set()).add(m.group(3))
            continue
        m = SEAL_RE.match(o)
        if m:
            if m.group(1) != key:
                return _result(BLOCKED, [f"SEAL_KEY_FOREIGN:{o}"])
            seals.append(m.group(2))
            continue
        if any(r.match(o) for r in tel_res):
            continue
        if o.startswith("_scratch/"):
            scratch_files.append(o)
            continue
        if o == "RUN.lock":
            runlock = True
            continue
        if o in names["finalize_files"] or LEDGER_RE.match(o):
            fin_present.append(o)
            continue
        if o in (final_report, completion):
            fin_present.append(o)
            continue
        return _result(BLOCKED, [f"UNKNOWN_ENTRY:{o}"])
    allowed_dir = re.compile(r"^(PHASE_B/(sessions|_commit_journal|EVENT_LEDGER_2026_FROZEN_ONLY)"
                             r"|PHASE_B/sessions/\d{4}-\d{2}-\d{2}(\.pending)?"
                             r"|TELEMETRY|TELEMETRY/SESSION_SEALS|TELEMETRY/SESSION_SEALS/" + key +
                             r"|_scratch(/.*)?)$")
    bad_dirs = [d for d in sorted(dirs - prep_dirs) if not allowed_dir.match(d)]
    if bad_dirs:
        return _result(BLOCKED, [f"UNKNOWN_DIR:{d}" for d in bad_dirs])
    if len(journals) > 1:
        return _result(BLOCKED, ["MULTIPLE_UNRESOLVED_JOURNALS"])
    if "CHECKPOINT_NEXT_TEMP" in findings and not journals:
        return _result(BLOCKED, ["CHECKPOINT_NEXT_TEMP_WITHOUT_JOURNAL"])
    if pending and not journals:
        return _result(BLOCKED, ["PENDING_WITHOUT_JOURNAL"])
    for s, have in sessions.items():
        if have != session_names:
            return _result(BLOCKED, [f"SESSION_FILES_INCOMPLETE:{s}"])
    try:
        cp = load_json_strict(Path(control_root, "PHASE_B", "CHECKPOINT.json").read_bytes())
    except AdapterBlocked as e:
        return _result(BLOCKED, ["CHECKPOINT_UNREADABLE:" + e.code])
    completed = cp.get("completed")
    if not isinstance(completed, list) or any(not DATE_RE.match(str(s)) for s in completed):
        return _result(BLOCKED, ["CHECKPOINT_COMPLETED_INVALID"])
    expected_n = int(constants["sessions"]["expected"])
    all_done = len(completed) == expected_n
    if fin_present and not all_done:
        return _result(BLOCKED, ["FINALIZE_OUTPUT_BEFORE_ALL_SESSIONS"])
    if completion in fin_present and final_report not in fin_present:
        return _result(BLOCKED, ["COMPLETION_RECEIPT_WITHOUT_FINAL"])
    extra = {"completed": completed, "journal": journals[0] if journals else None,
             "pending": sorted(pending), "sessions": sorted(sessions), "seals": sorted(seals),
             "scratch_files": len(scratch_files), "runlock_present": runlock,
             "finalize_outputs": sorted(fin_present), "seal_key": key}
    if not journals:
        if sorted(sessions) != sorted(completed):
            return _result(BLOCKED, ["SESSION_CHECKPOINT_WITHOUT_JOURNAL"], **extra)
        if sorted(seals) != sorted(completed):
            return _result(BLOCKED, ["SEAL_SET_NE_COMPLETED"], **extra)
    if final_report in fin_present:
        if journals or pending:
            return _result(BLOCKED, ["FINAL_WITH_PENDING_TRANSACTION"], **extra)
        return _result(FINAL_VALID, [], candidate=True, **extra)
    return _result(IN_PROGRESS, ["FINALIZE_PENDING"] if fin_present else [], **extra)


def journal_preview(control_root, journal_entry) -> dict:
    """Pré-visualização somente leitura do protocolo de tx.recover (r1r11_v4_transaction.py:118-154)."""
    po = Path(control_root) / "PHASE_B"
    rel, s, instance = journal_entry
    jp = Path(control_root) / rel
    j = load_json_strict(jp.read_bytes())
    sig = j.pop("journal_sha256", None)
    if hashlib.sha256(canonical_bytes(j)).hexdigest() != sig:
        raise AdapterBlocked("JOURNAL_HASH")
    if j.get("session") != s or j.get("run_instance") != instance or j.get("version") != "V005R1":
        raise AdapterBlocked("JOURNAL_BINDING")
    if j.get("out_root") != str(po.resolve()) or j.get("checkpoint_path") != str((po / "CHECKPOINT.json").resolve()):
        raise AdapterBlocked("JOURNAL_BINDING_PATH")
    next_sha = hashlib.sha256(canonical_bytes(j["checkpoint_next"])).hexdigest()
    if next_sha != j.get("checkpoint_next_sha256"):
        raise AdapterBlocked("JOURNAL_NEXT_HASH")
    with (po / "CHECKPOINT.json").open("rb") as f:
        cp_hash = hashlib.file_digest(f, "sha256").hexdigest()
    if cp_hash not in (j.get("checkpoint_previous_sha256"), next_sha):
        raise AdapterBlocked("CHECKPOINT_THIRD_STATE")
    final, pend = po / "sessions" / s, po / "sessions" / (s + ".pending")
    if final.exists() and pend.exists():
        raise AdapterBlocked("BOTH_FINAL_AND_PENDING")
    if not final.exists() and cp_hash != j.get("checkpoint_previous_sha256"):
        raise AdapterBlocked("CHECKPOINT_ADVANCED_WITHOUT_SESSION")
    outcome = "ROLL_FORWARD" if final.exists() else "ROLL_BACK"
    return {"session": s, "outcome": outcome,
            "checkpoint": "NEXT" if cp_hash == next_sha else "PREVIOUS"}


def validate_in_progress(control_root, constants: dict, struct: dict, frozen, identity_control: dict,
                         runtime_hashes: dict, cells, calendar_rows: list[dict], layout) -> dict:
    """DD-10: validadores congelados somente leitura sobre CONTROL em IN_PROGRESS/FINAL_VALID."""
    po = Path(control_root) / "PHASE_B"
    cp_path = po / "CHECKPOINT.json"
    before = sha256_file(cp_path)
    out = {}
    if struct.get("journal"):
        out["journal"] = journal_preview(control_root, struct["journal"])
        out["dry_scope_note"] = "JOURNAL_PENDING_RECOVER_DEFERRED_TO_RUN"
        return out
    cp = frozen.base._load_checkpoint(cp_path, "B", cells, identity_control, runtime_hashes)
    if sha256_file(cp_path) != before:
        raise AdapterBlocked("CHECKPOINT_MUTATED_BY_READONLY_VALIDATION")
    done = set(cp["completed"])
    target = {r["session_date"] for r in calendar_rows}
    if not done <= target:
        raise AdapterBlocked("CHECKPOINT_CONTAINS_OUT_OF_SCOPE_SESSION")
    frozen.base._verify_committed_trades_present(po, done)
    telemetry = Path(control_root) / "TELEMETRY" / "R1R11_TRANSPORT.jsonl"

    class _SealView:  # objeto mínimo exigido por Runtime.verify_committed (só .telemetry)
        pass
    view = _SealView()
    view.telemetry = telemetry
    frozen.coord.Runtime.verify_committed(view, po, cp)
    resume = cp.get("source_resume")
    if isinstance(resume, dict):
        tp = Path(resume.get("fingerprint", {}).get("path", ""))
        frozen.fast_resume.validate_fingerprint(tp, resume["fingerprint"])
        rs = str(resume.get("session", ""))
        if rs not in target:
            raise AdapterBlocked("SOURCE_RESUME_SESSION_OUT_OF_SCOPE", rs)
        month_rows = [r for r in calendar_rows if layout.same_tick(r["tick_file"], tp)]
        if not month_rows:
            raise AdapterBlocked("SOURCE_RESUME_TICK_NOT_IN_CALENDAR", str(tp))
        expected_prefixes = frozen.base._session_prefix_expectations(po, month_rows, done, Path(month_rows[0]["tick_file"]))
        frozen.fast_resume.rehydrate_prefix_tracker(tp, resume, expected_prefixes)
        out["source_resume"] = {"session": rs, "offset": int(resume.get("offset", -1))}
    if sha256_file(cp_path) != before:
        raise AdapterBlocked("CHECKPOINT_MUTATED_BY_READONLY_VALIDATION")
    out["completed"] = len(done)
    out["checkpoint_sha256"] = before
    return out


def stale_owner_check(control_root, frozen) -> dict:
    """RUN.lock e registros de scratch: nenhum dono vivo (PID + creation_time) — res:298-313."""
    root = Path(control_root)
    live = []
    lock = root / "RUN.lock"
    if lock.exists():
        prev = load_json_strict(lock.read_bytes())
        if "creation_time_100ns" not in prev:
            raise AdapterBlocked("LEGACY_RUN_LOCK")
        if frozen.resources.process_identity_live({"pid": prev["pid"], "creation_time_100ns": prev["creation_time_100ns"]}):
            live.append("RUN.lock")
    scratch = root / "_scratch"
    if scratch.exists():
        for reg in list(scratch.rglob("worker.json")) + list(scratch.rglob("*.helper.json")):
            robj = load_json_strict(reg.read_bytes())
            if "creation_time_100ns" not in robj:
                raise AdapterBlocked("LEGACY_SCRATCH_REGISTRY", str(reg))
            if frozen.resources.process_identity_live({"pid": robj["pid"], "creation_time_100ns": robj["creation_time_100ns"]}):
                live.append(str(reg.relative_to(root)))
    if live:
        raise AdapterBlocked("LIVE_OWNER_PRESENT", ",".join(live))
    return {"live_owners": 0}


def state_digest(struct: dict) -> str:
    return sha256_bytes(canonical_bytes({k: struct[k] for k in sorted(struct) if k != "findings"} | {"findings": struct["findings"]}))
