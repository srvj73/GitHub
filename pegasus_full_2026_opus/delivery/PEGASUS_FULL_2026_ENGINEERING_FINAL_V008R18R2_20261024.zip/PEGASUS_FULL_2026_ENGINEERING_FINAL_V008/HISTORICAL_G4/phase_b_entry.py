"""PHASE_B_ADAPTER_V001 — entrypoint único (CLI fechada).

Uso (somente via BOOTSTRAP_PHASE_B_ADAPTER.ps1, com python -B e PYTHONDONTWRITEBYTECODE=1):
  phase_b_entry.py status-b
  phase_b_entry.py classify-b --attempt-id <ID> [--with-tick-rehash]
  phase_b_entry.py dry-run-b  --attempt-id <ID>
  phase_b_entry.py run-b      --attempt-id <ID> --policy-receipt <P> --run-authorization <P> --dry-receipt <P>
       (run-b é recusado em G00 enquanto release_stage != RUN_RELEASED)

Import-safety: este módulo é reimportado como __mp_main__ pelos filhos 'spawn' do runtime
congelado; por isso não há nenhum efeito fora de main().
"""
from __future__ import annotations

import sys
import time
import traceback
from pathlib import Path

ALLOWED = {
    "status-b": {"flags": set(), "values": set(), "required": set()},
    "classify-b": {"flags": {"--with-tick-rehash"}, "values": {"--attempt-id"}, "required": {"--attempt-id"}},
    "dry-run-b": {"flags": set(), "values": {"--attempt-id"}, "required": {"--attempt-id"}},
    "run-b": {"flags": set(), "values": {"--attempt-id", "--policy-receipt", "--run-authorization", "--dry-receipt"},
              "required": {"--attempt-id", "--policy-receipt", "--run-authorization", "--dry-receipt"}},
}


def parse_argv(argv: list[str]):
    """G00: argv exato. Qualquer token fora da gramática (inclusive 'C' ou '--phase') => None."""
    if not argv or argv[0] not in ALLOWED:
        return None
    spec = ALLOWED[argv[0]]
    opts, flags, i = {}, set(), 1
    while i < len(argv):
        tok = argv[i]
        if tok in spec["flags"] and tok not in flags:
            flags.add(tok); i += 1; continue
        if tok in spec["values"] and tok not in opts and i + 1 < len(argv) and not argv[i + 1].startswith("--"):
            opts[tok] = argv[i + 1]; i += 2; continue
        return None
    if not spec["required"] <= set(opts):
        return None
    return {"command": argv[0], "opts": opts, "flags": flags}


def _print(k, v):
    sys.stdout.write(f"{k}={v}\n"); sys.stdout.flush()


def main(argv: list[str]) -> int:
    from phase_b_contract import load_constants
    from phase_b_effects import (EXIT_BLOCKED, AdapterBlocked, PreProcessRecordBoundary, TraceGuardMismatch,
                                 inventory)
    from phase_b_shared import (Layout, Session, WindowsPlatform, _release_mutexes, classify_flow, dry_flow,
                                finish, gate_g00, run_flow)
    from phase_b_state import classify_structure

    package_root = Path(__file__).resolve().parent
    _print("ADAPTER", "PHASE_B_ADAPTER_V001")
    _print("PHASE_C_EXECUTION", "NO")
    _print("RESELECTION_2026", "FORBIDDEN")
    parsed = parse_argv(argv)
    try:
        constants = load_constants(package_root / "phase_b_constants.json")
        gate_g00(parsed is not None, constants, parsed["command"] if parsed else "")
    except AdapterBlocked as e:
        _print("GATE_G00", "BLOCKED")
        _print("ERROR", e.code)
        _print("PARTIAL_EFFECT", "NO")
        _print("ADAPTER_EXIT", EXIT_BLOCKED)
        return EXIT_BLOCKED
    _print("GATE_G00", "PASS")
    _print("COMMAND", parsed["command"])
    _print("RELEASE_STAGE", constants["release_stage"])
    layout = Layout.production(constants, package_root)

    if parsed["command"] == "status-b":
        st = classify_structure(inventory(layout.control_root), constants, layout.control_root)
        _print("STATE_STRUCTURE", st["state"])
        _print("FINDINGS", ",".join(st["findings"]) or "NONE")
        _print("NOTE", "status-b is structural only; authoritative state comes from classify-b/dry-run-b")
        _print("ADAPTER_EXIT", 0)
        return 0

    mode = {"classify-b": "CLASSIFY", "dry-run-b": "DRY", "run-b": "RUN"}[parsed["command"]]
    s = Session(mode=mode, layout=layout, constants=constants, platform=WindowsPlatform(),
                attempt_id=parsed["opts"]["--attempt-id"],
                options={"policy_receipt": parsed["opts"].get("--policy-receipt"),
                         "run_authorization": parsed["opts"].get("--run-authorization"),
                         "dry_receipt": parsed["opts"].get("--dry-receipt")})
    s.started_ns = time.time_ns()
    outcome, error = "PASS", None
    try:
        s.open_evidence()
        s.emit("ATTEMPT_ID", s.attempt_id, evidence=str(s.evidence_dir))
        if mode == "CLASSIFY":
            r = classify_flow(s, "--with-tick-rehash" in parsed["flags"])
        elif mode == "DRY":
            r = dry_flow(s)
        else:
            r = run_flow(s)
        s.emit("RESULT", "PASS", **{k: v for k, v in r.items() if isinstance(v, str)})
    except AdapterBlocked as e:
        outcome, error = "BLOCKED", {"code": e.code, "detail": e.detail[:2000]}
        s.emit("ERROR", e.code)
    except KeyboardInterrupt:
        outcome, error = "INTERRUPT", {"code": "KEYBOARD_INTERRUPT"}
        s.safe_stop = "REQUESTED"
        s.emit("INTERRUPT", "KEYBOARD_INTERRUPT")
    except (PreProcessRecordBoundary, TraceGuardMismatch) as e:
        outcome, error = "BLOCKED", {"code": type(e).__name__, "detail": str(e)}
        s.emit("ERROR", type(e).__name__)
    except Exception as e:  # noqa: BLE001 - erro primário preservado no receipt
        outcome, error = "ERROR", {"code": type(e).__name__, "detail": str(e)[:2000],
                                   "traceback": traceback.format_exc()[-6000:]}
        s.emit("ERROR", type(e).__name__)
    finally:
        _release_mutexes(s)
    code = finish(s, outcome, error)
    _print("ADAPTER_EXIT", code)
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
