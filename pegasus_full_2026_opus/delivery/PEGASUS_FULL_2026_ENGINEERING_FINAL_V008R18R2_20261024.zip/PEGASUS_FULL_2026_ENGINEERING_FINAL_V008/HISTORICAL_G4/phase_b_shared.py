"""PHASE_B_ADAPTER_V001 — executor de gates G00–G24 (caminho compartilhado DRY/RUN),
shadow, seams de lista fechada, mutexes e captura de trace.

Import-safety: somente stdlib + módulos do adapter no topo; o CODE congelado só é importado
dentro de gate_g06_code(), após verificação byte a byte. Nenhum efeito em import.
"""
from __future__ import annotations

import hashlib
import importlib
import json
import os
import shutil
import sys
import time
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from phase_b_contract import (ATTEMPT_RE, config_validate, d1b_validate, dry_receipt_validate,
                              final_validate, inputs_validate, load_json_strict, owner_auth_validate,
                              parent_validate, pinned_files, policy_receipt_validate, preflight_validate,
                              release_validate, render_d1_extract, rows_from_bytes,
                              run_authorization_validate, run_binding_compare, run_binding_document,
                              tick_rehash)
from phase_b_effects import (EXIT_BLOCKED, STATUS_FIELDS, AdapterBlocked, EvidenceLog, PreProcessRecordBoundary,
                             TraceGuardMismatch, TraceTee, assert_no_link_in_chain, canonical_bytes,
                             canonical_hash, classify_exit, diff_inventories, downgrade_for_missing_receipt,
                             fmt_eta, inventory, inventory_digest, normalize_trace, sha256_bytes, sha256_file,
                             write_json_durable, write_status_atomic)
from phase_b_state import (BLOCKED, EMPTY, FINAL_VALID, IN_PROGRESS, PREPARED, classify_structure,
                           stale_owner_check, state_digest, validate_in_progress)

FROZEN_MODULES = {
    "full": "r1r11_full_2026",
    "base": "minotauro_v004_runner",
    "coord": "r1r11_coordinator",
    "resources": "r1r11_resources",
    "tx": "r1r11_v4_transaction",
    "fast_resume": "r1r11_fast_resume",
    "fcontract": "minotauro_v005r1_r23_contract",
    "io": "minotauro_v004_io",
}
STATUS_CHUNK_BYTES = 1024 ** 3
STATUS_CADENCE_SECONDS = 30
PLAN_COMMON = ["G01", "G02", "G03", "G04", "G05", "G06", "G07", "G08", "G09", "G10", "G11", "G12", "G13", "G14", "G15", "G16"]
COMPARE_IN_RUN = ("G06", "G07", "G09", "G10", "G12", "G13", "G14", "G15", "G17", "G18")
QUALIFICATION_SEAM_MODULE = "phase_b_qualification_seams"


# =========================================================================== layout / platform
@dataclass
class Layout:
    release_root: str
    code_root: str
    control_root: str
    preflight_root: str
    shadow_base: str
    evidence_base: str
    base_csv_root: str
    ind_d1: str
    m1_root: str
    parent_2025_root: str
    g8_local_receipt: str
    g8_evidence_zip: str
    phase_b_evidence_zip: str
    package_root: str

    @classmethod
    def production(cls, constants: dict, package_root) -> "Layout":
        p = constants["paths"]
        return cls(release_root=p["release_root"], code_root=p["code_root"], control_root=p["control_root"],
                   preflight_root=p["preflight_root"], shadow_base=p["shadow_base"], evidence_base=p["evidence_base"],
                   base_csv_root=p["base_csv_root"], ind_d1=p["ind_d1"], m1_root=p["m1_root"],
                   parent_2025_root=p["parent_2025_root"], g8_local_receipt=p["g8_local_receipt"],
                   g8_evidence_zip=p["g8_evidence_zip"], phase_b_evidence_zip=p["phase_b_evidence_zip"],
                   package_root=str(package_root))

    @staticmethod
    def tick_path(raw: str) -> Path:
        return Path(raw)

    def same_tick(self, raw: str, other) -> bool:
        return self.tick_path(raw).resolve() == Path(other).resolve()


class WindowsPlatform:
    """Primitivas Win32 de produção. Em não-Windows, toda operação bloqueia (fail-closed)."""

    def __init__(self):
        self._k = None

    def _kernel(self):
        if os.name != "nt":
            raise AdapterBlocked("WINDOWS_REQUIRED")
        if self._k is None:
            import ctypes
            from ctypes import wintypes
            k = ctypes.WinDLL("kernel32", use_last_error=True)
            k.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
            k.CreateMutexW.restype = ctypes.c_void_p
            k.WaitForSingleObject.argtypes = [ctypes.c_void_p, wintypes.DWORD]
            k.WaitForSingleObject.restype = wintypes.DWORD
            k.ReleaseMutex.argtypes = [ctypes.c_void_p]
            k.ReleaseMutex.restype = wintypes.BOOL
            k.CloseHandle.argtypes = [ctypes.c_void_p]
            k.CloseHandle.restype = wintypes.BOOL
            self._k = k
        return self._k

    def acquire_named_mutex(self, name: str):
        k = self._kernel()
        h = k.CreateMutexW(None, False, name)
        if not h:
            raise AdapterBlocked("MUTEX_CREATE_FAILED", name)
        r = k.WaitForSingleObject(h, 0)
        if r not in (0, 0x80):  # WAIT_OBJECT_0 ou WAIT_ABANDONED (mesma regra de r1r11_resources.py:274)
            k.CloseHandle(h)
            raise AdapterBlocked("MUTEX_ACTIVE_OR_UNAVAILABLE", name)
        return h

    def release_named_mutex(self, h) -> None:
        k = self._kernel()
        try:
            if not k.ReleaseMutex(h):
                raise AdapterBlocked("MUTEX_RELEASE_FAILED")
        finally:
            k.CloseHandle(h)

    def runtime_observation(self) -> dict:
        import numpy as np  # dependência pinada do runtime; não é CODE
        exe = os.path.abspath(sys.executable)
        return {"python_exe": exe, "python_exe_sha256": sha256_file(exe), "python_version": sys.version.split()[0],
                "numpy": str(np.__version__), "numpy_origin": os.path.abspath(str(np.__file__))}

    @staticmethod
    def free_bytes(path) -> int:
        return int(shutil.disk_usage(str(path)).free)

    def host_observation(self, paths) -> dict:
        """Q05 (somente leitura): CPUs lógicas, RAM, FS/serial/espaço de cada volume citado."""
        out = {"logical_cpus": os.cpu_count(), "platform": sys.platform, "volumes": {}}
        if os.name != "nt":
            out["status"] = "UNAVAILABLE_NON_WINDOWS"
            return out
        import ctypes
        from ctypes import wintypes

        class MEMSTAT(ctypes.Structure):
            _fields_ = [("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
                        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        ms = MEMSTAT()
        ms.dwLength = ctypes.sizeof(MEMSTAT)
        if k.GlobalMemoryStatusEx(ctypes.byref(ms)):
            out["ram_total_bytes"] = int(ms.ullTotalPhys)
            out["ram_available_bytes"] = int(ms.ullAvailPhys)
        else:
            out["ram"] = "UNAVAILABLE_" + str(ctypes.get_last_error())
        for anchor in sorted({Path(str(x)).anchor for x in paths if Path(str(x)).anchor}):
            vol = {}
            fs_name = ctypes.create_unicode_buffer(64)
            name = ctypes.create_unicode_buffer(261)
            serial, maxlen, flags = wintypes.DWORD(), wintypes.DWORD(), wintypes.DWORD()
            if k.GetVolumeInformationW(ctypes.c_wchar_p(anchor), name, 261, ctypes.byref(serial), ctypes.byref(maxlen),
                                       ctypes.byref(flags), fs_name, 64):
                vol.update(fs=fs_name.value, serial=f"{serial.value:08X}", label=name.value)
            else:
                vol["fs"] = "UNAVAILABLE_" + str(ctypes.get_last_error())
            try:
                du = shutil.disk_usage(anchor)
                vol.update(total_bytes=int(du.total), free_bytes=int(du.free))
            except OSError as e:
                vol["usage"] = "UNAVAILABLE_" + type(e).__name__
            out["volumes"][anchor] = vol
        return out


def adapter_mutex_name(release_root: str) -> str:
    return "Global\\MinotauroPhaseBAdapter_" + hashlib.sha256(str(release_root).casefold().encode()).hexdigest()


def r1r11_mutex_name(root) -> str:
    """Mesma fórmula de r1r11_resources.RunLock.__enter__ (res:269), com root = Path(root).resolve()."""
    return "Global\\MinotauroR1R11_" + hashlib.sha256(str(Path(root).resolve()).casefold().encode()).hexdigest()


def _path_inside(child, parent) -> bool:
    c, p = Path(child).resolve(), Path(parent).resolve()
    if os.name == "nt":
        cs, ps = str(c).casefold(), str(p).casefold()
        return cs == ps or cs.startswith(ps.rstrip("\\") + "\\")
    return c == p or c.is_relative_to(p)


# =========================================================================== frozen namespace / seams
class Frozen:
    def __init__(self, mods: dict):
        self.full = mods.get("full")
        self.base = mods["base"]
        self.coord = mods["coord"]
        self.resources = mods.get("resources")
        self.tx = mods.get("tx")
        self.fast_resume = mods.get("fast_resume")
        self.fcontract = mods.get("fcontract")
        self.io = mods.get("io")
        self.orig_load_d1_extract = mods["base"]._load_d1_extract
        self.orig_process_record = mods["coord"].ParallelSession.__dict__["process_record"]
        self.code_root = None


def namespace_snapshot(code_root) -> dict:
    """Identidades de todos os callables/classes em nível de módulo e de classe do CODE carregado."""
    root = Path(code_root).resolve()
    snap = {}
    for name, mod in list(sys.modules.items()):
        f = getattr(mod, "__file__", None)
        if not f:
            continue
        try:
            if Path(f).resolve().parent != root:
                continue
        except OSError:
            continue
        for k, v in list(vars(mod).items()):
            if callable(v) or isinstance(v, type):
                snap[(name, k)] = id(v)
            if isinstance(v, type) and getattr(v, "__module__", None) == name:
                for ck, cv in list(vars(v).items()):
                    if callable(cv) or isinstance(cv, (staticmethod, classmethod, property)):
                        snap[(name, k, ck)] = id(cv)
    return snap


def namespace_delta(a: dict, b: dict) -> list:
    return sorted(k for k in a if b.get(k) != a[k])


EXPECTED_SEAM_KEYS = {("minotauro_v004_runner", "_load_d1_extract"),
                      ("r1r11_coordinator", "ParallelSession", "process_record")}


class SeamSet:
    """SEAM-D1 + SEAM-PPR (lista fechada). Afirma identidade antes/depois e delta exato."""

    def __init__(self, session: "Session", mode: str, root: Path, template_runtime_trace=None):
        self.s = session
        self.mode = mode
        self.root = Path(root)
        self.template = template_runtime_trace
        self.ppr_restored = False
        self.snap0 = None

    # ---- SEAM-D1
    def _make_d1(self):
        s, fz, constants = self.s, self.s.frozen, self.s.constants
        expected = (self.root / "PHASE_B" / "D1_PREDECESSOR_EXTRACT_PHASE_B.csv").resolve()
        po = self.root / "PHASE_B"

        def seam_load_d1_extract(path):
            if Path(path).resolve() != expected:
                raise AdapterBlocked("SEAM_D1_PATH_REFUSED", str(path))
            data = Path(path).read_bytes()
            cal = fz.base.cal(po / "SESSION_CALENDAR_PHASE_B.csv")
            exp = fz.base.cal(po / "EXPECTED_SESSIONS_PHASE_B.csv")
            bars = fz.io.load_d1(Path(s.layout.ind_d1))
            binding = load_json_strict((po / "RUN_SOURCE_BINDING_B.json").read_bytes())
            summary = d1b_validate(data, cal, exp, bars, constants,
                                   extract_sha_expected=constants["d1b"]["extract_sha256"],
                                   binding=binding, ind_sha=sha256_file(s.layout.ind_d1))
            rows = fz.base.cal(Path(path))
            if sha256_file(path) != summary["extract_sha256"]:
                raise AdapterBlocked("SEAM_D1_TOCTOU")
            s.record["d1b_at_use"] = summary
            s.emit("SEAM_D1", "PASS", sessions=summary["sessions"])
            return {r["session_date"]: r for r in rows}
        return seam_load_d1_extract

    # ---- SEAM-PPR
    def _make_ppr(self):
        s, fz = self.s, self.s.frozen
        orig = fz.orig_process_record
        seamset = self

        if self.mode == "DRY":
            def seam_process_record(self_, rec):
                s.record["bnd_session"] = getattr(self_, "session", None)
                raise PreProcessRecordBoundary("BND_PRE_PROCESS_RECORD")
            return seam_process_record

        def seam_process_record_run(self_, rec):
            got = normalize_trace(s.tee.lines if s.tee else [], s.constants["trace"])
            if seamset.template is not None and got != seamset.template:
                raise TraceGuardMismatch("TRACE_GUARD_MISMATCH")
            fz.coord.ParallelSession.process_record = orig
            seamset.ppr_restored = True
            s.emit("SEAM_PPR_GUARD", "PASS", template="COMPARED" if seamset.template is not None else "NOT_APPLICABLE")
            return orig(self_, rec)
        return seam_process_record_run

    def __enter__(self):
        fz = self.s.frozen
        if QUALIFICATION_SEAM_MODULE in sys.modules:
            raise AdapterBlocked("QUALIFICATION_SEAM_MODULE_LOADED_IN_PRODUCTION")
        if fz.base._load_d1_extract is not fz.orig_load_d1_extract:
            raise AdapterBlocked("SEAM_D1_ORIGINAL_IDENTITY")
        if fz.coord.ParallelSession.__dict__["process_record"] is not fz.orig_process_record:
            raise AdapterBlocked("SEAM_PPR_ORIGINAL_IDENTITY")
        self.snap0 = namespace_snapshot(fz.code_root)
        fz.base._load_d1_extract = self._make_d1()
        fz.coord.ParallelSession.process_record = self._make_ppr()
        delta = set(namespace_delta(self.snap0, namespace_snapshot(fz.code_root)))
        if delta != EXPECTED_SEAM_KEYS:
            self._restore()
            raise AdapterBlocked("SEAM_CLOSED_LIST_VIOLATION", repr(sorted(delta)))
        return self

    def _restore(self):
        fz = self.s.frozen
        fz.base._load_d1_extract = fz.orig_load_d1_extract
        fz.coord.ParallelSession.process_record = fz.orig_process_record

    def __exit__(self, *exc):
        fz = self.s.frozen
        self._restore()
        if fz.base._load_d1_extract is not fz.orig_load_d1_extract or \
                fz.coord.ParallelSession.__dict__["process_record"] is not fz.orig_process_record:
            raise AdapterBlocked("SEAM_RESTORE_IDENTITY")
        after = namespace_snapshot(fz.code_root)
        delta = [k for k in self.snap0 if after.get(k) != self.snap0[k]]
        if delta:
            raise AdapterBlocked("SEAM_RESTORE_NAMESPACE_DELTA", repr(delta[:5]))
        return False


# =========================================================================== phase guards
def phase_b_only(fn):
    def guarded(out, phase, *args, **kwargs):
        if phase != "B":
            raise AdapterBlocked("PHASE_NOT_B", repr(phase))
        return fn(out, phase, *args, **kwargs)
    guarded.__name__ = "phase_b_only_" + getattr(fn, "__name__", "fn")
    return guarded


def runtime_evidence(root, pid: int, started_ns: int) -> dict:
    """Prova do próprio runtime (§5.6): STATUS desta invocação + evento PROCESS_TREE_CLEAN no transporte."""
    root = Path(root)
    st_p = root / "TELEMETRY" / "R1R11_STATUS.json"
    out = {"started": False, "clean": False, "instance": None}
    if not st_p.is_file():
        return out
    try:
        st = json.loads(st_p.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return out
    inst = str(st.get("run_instance", ""))
    pid_s, _, ns = inst.partition("_")
    if pid_s != str(pid) or not ns.isdigit() or int(ns) < started_ns:
        return out
    out.update(started=True, instance=inst)
    transport = root / "TELEMETRY" / "R1R11_TRANSPORT.jsonl"
    event_ok = False
    if transport.is_file():
        for line in transport.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if row.get("event") == "PROCESS_TREE_CLEAN" and row.get("run_instance") == inst:
                event_ok = True
    out["clean"] = bool(st.get("PROCESS_TREE_CLEAN") == "YES" and event_ok)
    out["safe_stop_status"] = st.get("SAFE_STOP")
    return out


# =========================================================================== session
@dataclass
class Session:
    mode: str                      # DRY | RUN | CLASSIFY
    layout: Layout
    constants: dict
    platform: object
    attempt_id: str
    options: dict = field(default_factory=dict)
    gates: list = field(default_factory=list)
    record: dict = field(default_factory=dict)
    frozen: Frozen | None = None
    tee: TraceTee | None = None
    log: EvidenceLog | None = None
    evidence_dir: Path | None = None
    f1_marked: bool = False
    started_ns: int = 0
    mutexes: list = field(default_factory=list)
    adapter_identity: dict | None = None
    # B05 — status incremental atômico (campos canônicos de runner longo)
    plan: list = field(default_factory=list)
    phase: str = "INIT"
    checkpoint: str = "NONE"
    safe_stop: str = "NO"
    status_path: Path | None = None
    status_seq: int = 0
    status_failures: int = 0
    status_last_sha256: str | None = None
    status_last_monotonic: float = 0.0
    status_last_kw: dict = field(default_factory=dict)
    status_lock: object = None
    heartbeat_stop: object = None
    heartbeat_thread: object = None

    # ------------------------------------------------------------------ output
    def emit(self, key: str, status: str, **kv) -> None:
        extra = " ".join(f"{k}={v}" for k, v in kv.items())
        self.raw_line(f"{key}={status}" + (" " + extra if extra else ""))

    def raw_line(self, line: str) -> None:
        if self.tee is not None:
            self.tee.original.write(line + "\n"); self.tee.original.flush()
        else:
            sys.stdout.write(line + "\n"); sys.stdout.flush()
        if self.log is not None:
            self.log.line(line)

    def gate(self, gid: str, fn, *, input_of=None):
        t0 = time.monotonic()
        self.phase = gid
        self.status()
        try:
            result = fn()
        except AdapterBlocked as e:
            self.gates.append({"id": gid, "status": "BLOCKED", "code": e.code, "detail": e.detail[:400],
                               "seconds": round(time.monotonic() - t0, 3)})
            self.emit("GATE_" + gid, "BLOCKED", code=e.code)
            self.phase = gid + "_BLOCKED"
            self.status()
            raise
        rec = {"id": gid, "status": "PASS", "seconds": round(time.monotonic() - t0, 3),
               "compare_in_run": gid in COMPARE_IN_RUN}
        if input_of is not None:
            rec["input_sha256"] = canonical_hash(input_of(result))
        self.gates.append(rec)
        self.emit("GATE_" + gid, "PASS")
        self.checkpoint = gid
        self.status()
        return result

    def mark(self, gid: str, **rec) -> None:
        """Gate concluído fora de Session.gate (G22/BND)."""
        self.gates.append(dict({"id": gid, "status": "PASS"}, **rec))
        self.checkpoint = gid
        self.status()

    # ------------------------------------------------------------------ status (B05)
    def status_document(self, *, progress=None, total=None, rate=None, eta_s=None, active="YES",
                        committed=None, extra=None) -> dict:
        passed = sum(1 for g in self.gates if g.get("status") == "PASS")
        now = time.time()
        finish = "UNKNOWN"
        if eta_s is not None and fmt_eta(eta_s) != "UNKNOWN":
            finish = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now + float(eta_s)))
        elif active == "NO":
            finish = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now))
        if committed is None:
            committed = "0" if self.mode in ("CLASSIFY", "DRY") else "UNKNOWN_FROZEN_RUNTIME_OWNS_COMMITS"
        fields = {"PHASE": self.phase,
                  "PROGRESS": str(progress if progress is not None else passed),
                  "COMMITTED": str(committed),
                  "TOTAL": str(total if total is not None else (len(self.plan) or "UNKNOWN")),
                  "RATE": str(rate) if rate is not None else "UNKNOWN",
                  "ETA": fmt_eta(eta_s) if active == "YES" else fmt_eta(0),
                  "FINISH": finish,
                  "ACTIVE": active,
                  "READY_WAITING": "0",
                  "CHECKPOINT": self.checkpoint,
                  "SAFE_STOP": self.safe_stop}
        assert tuple(fields) == STATUS_FIELDS
        doc = {"schema": "MINOTAURO_PHASE_B_ADAPTER_STATUS_V001", "field_order": list(STATUS_FIELDS),
               "attempt_id": self.attempt_id, "mode": self.mode,
               "pid": os.getpid(), "seq": self.status_seq + 1,
               "updated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now)),
               "cadence": "GATE_OR_CHUNK_BOUNDARY_AND_<=30S_IN_LONG_GATES", "fields": fields,
               "status_write_failures": self.status_failures}
        if extra:
            doc["extra"] = extra
        return doc

    def status(self, *, _liveness: bool = False, **kw) -> None:
        """Grava ADAPTER_STATUS.json atomicamente. Observacional: falha não altera o resultado autoritativo,
        mas é contada e reportada no receipt (status_write_failures). Serializado por lock (thread de vida)."""
        if self.status_path is None:
            return
        if self.status_lock is None:
            import threading
            self.status_lock = threading.Lock()
        with self.status_lock:
            if _liveness:
                kw = dict(self.status_last_kw)
            else:
                self.status_last_kw = dict(kw)
            doc = self.status_document(**kw)
            doc["liveness_tick"] = _liveness
            try:
                self.status_last_sha256 = write_status_atomic(self.status_path, doc)
                self.status_seq = doc["seq"]
                self.status_last_monotonic = time.monotonic()
            except AdapterBlocked:
                self.status_failures += 1
                return
        if not _liveness:
            f = doc["fields"]
            self.raw_line("HEARTBEAT " + " ".join(f"{k}={f[k]}" for k in STATUS_FIELDS))

    def final_status(self, code: int, receipt_name) -> tuple:
        """B08: status final obrigatório (ACTIVE=NO, exit) gravado E relido ANTES do receipt autoritativo.
        Retorna (persistido, sha256). Qualquer falha => (False, None)."""
        if self.status_path is None:
            return False, None
        self.phase = "FINISHED"
        before = self.status_failures
        self.status(active="NO", extra={"exit_code": code, "receipt": receipt_name,
                                        "receipt_written_after_this_status": receipt_name is not None})
        if self.status_failures != before or self.status_last_sha256 is None:
            return False, None
        try:
            raw = Path(self.status_path).read_bytes()
            doc = load_json_strict(raw)
            ok = (sha256_bytes(raw) == self.status_last_sha256 and doc["fields"]["ACTIVE"] == "NO"
                  and doc["fields"]["PHASE"] == "FINISHED" and doc["extra"]["exit_code"] == code)
        except Exception:  # noqa: BLE001
            ok = False
        return ok, (self.status_last_sha256 if ok else None)

    def start_heartbeat(self, interval: float = None) -> None:
        """Cadência por tempo (B05): thread daemon que regrava o status a cada <= 30 s, inclusive dentro de gates
        longos e do runtime congelado. Só escreve ADAPTER_STATUS.json (nunca stdout/trace)."""
        import threading
        if self.heartbeat_thread is not None or self.status_path is None:
            return
        period = float(interval if interval is not None else STATUS_CADENCE_SECONDS)
        self.heartbeat_stop = threading.Event()

        def loop():
            while not self.heartbeat_stop.wait(period):
                if time.monotonic() - self.status_last_monotonic >= period * 0.9:
                    self.status(_liveness=True)
        self.heartbeat_thread = threading.Thread(target=loop, name="phase_b_adapter_status", daemon=True)
        self.heartbeat_thread.start()

    def stop_heartbeat(self) -> None:
        if self.heartbeat_thread is None:
            return
        self.heartbeat_stop.set()
        self.heartbeat_thread.join(timeout=10)
        self.heartbeat_thread = None

    # ------------------------------------------------------------------ evidence
    def open_evidence(self) -> None:
        if not ATTEMPT_RE.match(self.attempt_id or ""):
            raise AdapterBlocked("ATTEMPT_ID_INVALID", str(self.attempt_id))
        base = Path(self.layout.evidence_base)
        for forbidden in (self.layout.release_root, self.layout.base_csv_root):
            if _path_inside(base, forbidden):
                raise AdapterBlocked("EVIDENCE_ROOT_FORBIDDEN_LOCATION", str(base))
        self.evidence_dir = base / self.attempt_id / "ADAPTER"
        if self.evidence_dir.exists():
            raise AdapterBlocked("EVIDENCE_ATTEMPT_REUSED", str(self.evidence_dir))
        self.evidence_dir.mkdir(parents=True, exist_ok=False)
        assert_no_link_in_chain(self.evidence_dir, "EVIDENCE_ROOT_LINK")
        self.log = EvidenceLog(self.evidence_dir / "ADAPTER.log")
        self.status_path = self.evidence_dir / "ADAPTER_STATUS.json"
        self.phase = "STARTED"
        self.status()
        self.start_heartbeat()

    def write_evidence(self, name: str, obj) -> str:
        return write_json_durable(self.evidence_dir / name, obj, exclusive=True)


# =========================================================================== gates
def gate_g00(argv_ok: bool, constants: dict, command: str) -> dict:
    if not argv_ok:
        raise AdapterBlocked("ENTRY_ARGV")
    if command == "run-b" and constants.get("release_stage") != "RUN_RELEASED":
        raise AdapterBlocked("RUN_B_DISABLED_IN_PACKAGE_IDENTITY", constants.get("release_stage", ""))
    return {"command": command}


def gate_g02_bytecode() -> dict:
    if sys.flags.dont_write_bytecode != 1 or not sys.dont_write_bytecode or os.environ.get("PYTHONDONTWRITEBYTECODE") != "1":
        raise AdapterBlocked("BYTECODE_SUPPRESSION_REQUIRED", "-B and PYTHONDONTWRITEBYTECODE=1")
    return {"dont_write_bytecode": 1}


def gate_g03_runtime(observed: dict, constants: dict) -> dict:
    r = constants["runtime"]
    want = {"python_exe": r["python_exe"], "python_exe_sha256": r["python_exe_sha256"],
            "python_version": r["python_version"], "numpy": r["numpy"], "numpy_origin": r["numpy_origin"]}
    bad = []
    for k, v in want.items():
        got = observed.get(k)
        if k in ("python_exe", "numpy_origin"):
            if os.path.normcase(str(got)) != os.path.normcase(v):
                bad.append(k)
        elif got != v:
            bad.append(k)
    if bad:
        raise AdapterBlocked("RUNTIME_PIN_MISMATCH", ",".join(bad))
    return want


def gate_g04_authority(s: Session) -> dict:
    a = s.constants["authority"]
    out = {"snapshot_master_sha256": a["snapshot_master_sha256"], "snapshot_head_sha256": a["snapshot_head_sha256"]}
    if s.mode == "RUN":
        out["live"] = policy_receipt_validate(s.options.get("policy_receipt"), s.constants)
    else:
        out["live"] = "NOT_REQUIRED_OUTSIDE_RUN"
    return out


def gate_g05_package(layout: Layout, constants: dict) -> dict:
    root = Path(layout.package_root)
    man = root / "MANIFEST_SHA256.txt"
    ident_p = root / "ADAPTER_IDENTITY.json"
    if not man.is_file() or not ident_p.is_file():
        raise AdapterBlocked("ADAPTER_PACKAGE_MANIFEST_MISSING")
    listed = {}
    for line in man.read_text(encoding="ascii").splitlines():
        if not line.strip():
            continue
        h, n = line.split("  ", 1)
        if n in listed or Path(n).is_absolute() or ".." in Path(n).parts:
            raise AdapterBlocked("ADAPTER_MANIFEST_ENTRY", n)
        listed[n] = h.upper()
    actual = {}
    for p in root.rglob("*"):
        if p.is_file() and p not in (man, ident_p):
            actual[p.relative_to(root).as_posix()] = p
    if set(actual) != set(listed):
        raise AdapterBlocked("ADAPTER_EXACT_PAYLOAD", repr(sorted(set(actual) ^ set(listed))[:20]))
    for n, p in actual.items():
        if sha256_file(p) != listed[n]:
            raise AdapterBlocked("ADAPTER_MEMBER_HASH", n)
    if any(d.name == "__pycache__" for d in root.rglob("*") if d.is_dir()):
        raise AdapterBlocked("ADAPTER_PYCACHE_PRESENT")
    ident = load_json_strict(ident_p.read_bytes())
    man_sha = sha256_file(man)
    if (ident.get("adapter_identity_sha256") != man_sha or ident.get("manifest_sha256") != man_sha
            or ident.get("constants_sha256") != constants["_sha256"]
            or ident.get("envelope_sha256") != constants["envelope"]["sha256"]
            or ident.get("release_stage") != constants["release_stage"]):
        raise AdapterBlocked("ADAPTER_IDENTITY_MISMATCH")
    return ident


def gate_g06_code(s: Session) -> dict:
    lay, c = s.layout, s.constants
    code = Path(lay.code_root)
    man = code / "SHA256SUMS.txt"
    if not man.is_file() or sha256_file(man) != c["frozen_code"]["manifest_sha256"]:
        raise AdapterBlocked("CODE_MANIFEST_IDENTITY")
    listed = {}
    for line in man.read_text(encoding="ascii").splitlines():
        if not line.strip():
            continue
        h, n = line.split(None, 1)
        n = n.strip().replace("\\", "/")
        if n in listed:
            raise AdapterBlocked("CODE_MANIFEST_DUPLICATE", n)
        listed[n] = h.upper()
    if len(listed) != int(c["frozen_code"]["files"]):
        raise AdapterBlocked("CODE_MANIFEST_CARDINALITY", str(len(listed)))
    actual = {p.relative_to(code).as_posix(): p for p in code.rglob("*") if p.is_file() and p != man}
    if set(actual) != set(listed):
        raise AdapterBlocked("CODE_EXACT_PAYLOAD", repr(sorted(set(actual) ^ set(listed))[:20]))
    for n, p in actual.items():
        if sha256_file(p) != listed[n]:
            raise AdapterBlocked("CODE_MEMBER_HASH", n)
    for key in ("r1r11_full_2026", "minotauro_v004_runner", "r1r11_coordinator", "r1r11_resources", "r1r11_v4_transaction"):
        if listed.get(key + ".py") != c["frozen_code"][key + "_sha256"]:
            raise AdapterBlocked("CODE_KEY_MODULE_PIN", key)
    # import somente após a verificação byte a byte
    preloaded = [m for m in FROZEN_MODULES.values() if m in sys.modules]
    if preloaded:
        raise AdapterBlocked("CODE_MODULE_PRELOADED", ",".join(preloaded))
    sys.path.insert(0, str(code))
    mods = {}
    for alias, name in FROZEN_MODULES.items():
        mod = importlib.import_module(name)
        f = Path(getattr(mod, "__file__", "")).resolve()
        if f.parent != code.resolve():
            raise AdapterBlocked("CODE_MODULE_SHADOWED", f"{name}={f}")
        mods[alias] = mod
    fz = Frozen(mods)
    fz.code_root = str(code)
    s.frozen = fz
    pkg = fz.full.verify_package()
    if pkg != c["frozen_code"]["manifest_sha256"]:
        raise AdapterBlocked("CODE_VERIFY_PACKAGE")
    rid, _ = fz.fcontract.runner_identity(code)
    if rid != c["frozen_code"]["runner_identity_sha256"]:
        raise AdapterBlocked("CODE_RUNNER_IDENTITY", rid)
    rh = fz.base._runtime_module_hashes(code)
    fc = c["frozen_code"]
    if (rh["preflight_py_sha256"] != fc["expected_preflight_sha256"] or rh["io_py_sha256"] != fc["expected_io_sha256"]
            or rh["core_imported_definitions_sha256"] != fc["expected_core_imported_definitions_sha256"]
            or fz.fcontract.EXPECTED_PREFLIGHT_SHA256 != fc["expected_preflight_sha256"]
            or fz.fcontract.SPEC_SHA256 != fc["spec_sha256"]):
        raise AdapterBlocked("CODE_EXPECTED_IDENTITIES")
    fl = c["frozen_literals"]
    cfgv = fz.full.cfg(Path(lay.control_root))
    checks = {"parent_2025": str(fz.full.PARENT_2025) == fl["parent_2025"],
              "default_out": str(fz.full.DEFAULT_OUT) == fl["default_out"],
              "ind_d1": cfgv["ind_d1"] == fl["ind_d1"] and str(lay.ind_d1) == fl["ind_d1"],
              "m1_root": cfgv["m1_root"] == fl["m1_root"] and str(lay.m1_root) == fl["m1_root"],
              "ticks_root": cfgv["ticks_root"] == fl["ticks_root"],
              "parent_layout": str(lay.parent_2025_root) == fl["parent_2025"],
              "phase_range_b": list(fz.full.PHASES["B"]) == c["sessions"]["range"],
              "phase_order": tuple(fz.full.PHASE_ORDER) == ("B", "C")}
    bad = [k for k, ok in checks.items() if not ok]
    if bad:
        raise AdapterBlocked("CODE_FROZEN_LITERALS", ",".join(bad))
    return {"manifest_sha256": pkg, "runner_identity_sha256": rid, "runtime_module_hashes": rh}


def wanted_config(s: Session, pkg: str, parent: dict) -> dict:
    """Mesmo objeto de r1r11_full_2026.main (full:462-464), sem chamar main."""
    fz, c = s.frozen, s.constants
    return {"schema": c["config"]["schema"], "package_manifest_sha256": pkg,
            "parent_2025_freeze_sha256": parent["freeze_sha256"],
            "parent_2025_homologation_sha256": parent["homologation_sha256"],
            "phases": ["B", "C"], "phase_ranges": {"B": fz.full.PHASES["B"], "C": fz.full.PHASES["C"]},
            "preflight_source_root": str(Path(s.layout.preflight_root).resolve()),
            "frozen_cell_ids": [cc.cell_id for cc in parent["cells"]],
            "workers": c["config"]["workers"], "batch_rows": c["config"]["batch_rows"]}


def release_top_inventory(layout: Layout) -> dict:
    root = Path(layout.release_root)
    out = {}
    if root.is_dir():
        for p in sorted(root.iterdir()):
            if p.is_file():
                out[p.name] = {"bytes": p.stat().st_size, "sha256": sha256_file(p)}
            else:
                out[p.name + "/"] = "DIR" if p.is_dir() else "OTHER"
    return out


def inputs_metadata(layout: Layout, constants: dict) -> dict:
    ind = Path(layout.ind_d1)
    st = ind.stat()
    out = {"ind": {"bytes": st.st_size, "mtime_ns": st.st_mtime_ns, "sha256": sha256_file(ind)}, "ticks": []}
    for t in constants["inputs"]["ticks"]:
        tst = layout.tick_path(t["path"]).stat()
        out["ticks"].append({"path": t["path"], "bytes": tst.st_size, "ino": tst.st_ino, "mtime_ns": tst.st_mtime_ns})
    return out


def snapshot_all(s: Session) -> dict:
    lay = s.layout
    return {"control": inventory(lay.control_root), "preflight": inventory(lay.preflight_root),
            "code": inventory(lay.code_root), "package": inventory(lay.package_root),
            "release_top": release_top_inventory(lay), "inputs": inputs_metadata(lay, s.constants)}


def snapshot_digests(snap: dict) -> dict:
    return {"control": inventory_digest(snap["control"]), "preflight": inventory_digest(snap["preflight"]),
            "code": inventory_digest(snap["code"]), "package": inventory_digest(snap["package"]),
            "release_top": canonical_hash(snap["release_top"]), "inputs": canonical_hash(snap["inputs"])}


def gate_g15_d1b(s: Session, state: str) -> dict:
    fz, c, lay = s.frozen, s.constants, s.layout
    src = Path(lay.preflight_root) / "PHASE_B"
    cal = rows_from_bytes((src / "SESSION_CALENDAR_PHASE_B.csv").read_bytes())
    exp = rows_from_bytes((src / "EXPECTED_SESSIONS_PHASE_B.csv").read_bytes())
    bars = fz.io.load_d1(Path(lay.ind_d1))
    derived = render_d1_extract(c["d1b"]["columns"], cal, bars)
    out = {"preflight_derived": d1b_validate(derived, cal, exp, bars, c, extract_sha_expected=c["d1b"]["extract_sha256"])}
    if state != EMPTY:
        po = Path(lay.control_root) / "PHASE_B"
        binding = load_json_strict((po / "RUN_SOURCE_BINDING_B.json").read_bytes())
        out["control"] = d1b_validate((po / "D1_PREDECESSOR_EXTRACT_PHASE_B.csv").read_bytes(),
                                      rows_from_bytes((po / "SESSION_CALENDAR_PHASE_B.csv").read_bytes()),
                                      rows_from_bytes((po / "EXPECTED_SESSIONS_PHASE_B.csv").read_bytes()),
                                      bars, c, extract_sha_expected=c["d1b"]["extract_sha256"],
                                      binding=binding, ind_sha=sha256_file(lay.ind_d1))
    return out


def gate_g16_free_space(s: Session, control_inv: dict) -> dict:
    fs = s.constants["free_space"]
    probe = Path(s.layout.shadow_base).resolve()
    while not probe.exists() and probe != probe.parent:
        probe = probe.parent
    free = int(s.platform.free_bytes(probe))
    shadow_need = sum(v["bytes"] for v in control_inv["files"].values()) + int(fs["dry_margin_bytes"])
    if s.mode == "RUN":
        if fs.get("run_growth_bytes") is None:
            raise AdapterBlocked("RUN_GROWTH_NOT_QUALIFIED", "measure in QS4 and re-release")
        need = int(fs["run_growth_bytes"]) * int(fs["run_multiplier"]) + int(fs["dry_margin_bytes"])
    else:
        need = shadow_need
    if free < need:
        raise AdapterBlocked("FREE_SPACE_INSUFFICIENT", f"free={free} need={need}")
    return {"free": free, "need": need}


def prepare_shadow(s: Session, state: str) -> Path:
    lay = s.layout
    base = Path(lay.shadow_base)
    for forbidden in (lay.release_root, lay.code_root, lay.control_root, lay.preflight_root, lay.base_csv_root):
        if _path_inside(base, forbidden):
            raise AdapterBlocked("SHADOW_FORBIDDEN_LOCATION", str(forbidden))
    base.mkdir(parents=True, exist_ok=True)
    assert_no_link_in_chain(base, "SHADOW_LINK")
    attempt = base / s.attempt_id
    attempt.mkdir(parents=False, exist_ok=False)
    root = attempt / "CONTROL"
    root.mkdir()
    if root.stat().st_dev != Path(lay.control_root).stat().st_dev:
        raise AdapterBlocked("SHADOW_CROSS_VOLUME")
    pins = pinned_files(s.constants["control_prepared"]["files"])
    names = list(pins) if state != EMPTY else [s.constants["config"]["path"], s.constants["owner_authorization"]["path"]]
    for rel in names:
        src, dst = Path(lay.control_root) / rel, root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        if sha256_file(dst) != pins[rel]["sha256"]:
            raise AdapterBlocked("SHADOW_COPY_HASH", rel)
    (root / "PREFLIGHT").mkdir(exist_ok=True)
    return root


def compare_prepared(root, constants: dict, platform_tolerant=frozenset()) -> dict:
    pins = pinned_files(constants["control_prepared"]["files"])
    inv = inventory(root)
    want = set(pins)
    if set(inv["files"]) != want or inv["links"] or inv["other"]:
        raise AdapterBlocked("PREPARED_REPRODUCTION_SET", repr(sorted(set(inv["files"]) ^ want)[:20]))
    tolerated = []
    for rel in sorted(want):
        if inv["files"][rel] == pins[rel]:
            continue
        if rel in platform_tolerant:
            data = (Path(root) / rel).read_bytes()
            if sha256_bytes(data.replace(b"\n", b"\r\n")) == pins[rel]["sha256"]:
                tolerated.append(rel)
                continue
        raise AdapterBlocked("PREPARED_REPRODUCTION_BYTES", rel)
    if set(inv["dirs"]) != set(constants["control_prepared"]["dirs"]):
        raise AdapterBlocked("PREPARED_REPRODUCTION_DIRS", repr(sorted(set(inv["dirs"]) ^ set(constants["control_prepared"]["dirs"]))))
    return {"files": len(want), "platform_tolerated": tolerated}


def gate_g18_shadow(s: Session, state: str, parent: dict, platform_tolerant=frozenset()) -> dict:
    fz = s.frozen
    root = prepare_shadow(s, state)
    s.record["shadow_root"] = str(root)
    pf, _cal, _rows, _d1 = phase_b_only(fz.full.prepare_preflight)(root, "B", Path(s.layout.preflight_root))
    po, binding, identity, runtime_hashes, cal, d1_path = phase_b_only(fz.full.build_binding)(root, "B", pf, parent["cells"], parent)
    repro = compare_prepared(root, s.constants, platform_tolerant)
    if identity["config_sha256"] != fz.fcontract.config_hash(fz.full.cfg(root)):
        raise AdapterBlocked("SHADOW_IDENTITY_CONFIG")
    identity_control = dict(identity)
    identity_control["config_sha256"] = fz.fcontract.config_hash(fz.full.cfg(Path(s.layout.control_root)))
    s.record.update(shadow_po=str(po), shadow_identity=identity, identity_control=identity_control,
                    runtime_hashes=runtime_hashes, calendar=cal, d1_path=str(d1_path), binding=binding)
    stable_identity = {k: v for k, v in identity.items() if k not in ("config_sha256",)}
    return {"reproduction": repro, "identity_stable": stable_identity,
            "files": {k: v for k, v in sorted(inventory(root)["files"].items())}}


# =========================================================================== flows
def _common_pre_shadow(s: Session, *, with_tick_rehash: bool) -> dict:
    """G01–G17 (compartilhado). Retorna contexto."""
    lay, c = s.layout, s.constants
    s.mutexes.append(s.gate("G01", lambda: s.platform.acquire_named_mutex(adapter_mutex_name(lay.release_root))))
    s.gate("G02", gate_g02_bytecode)
    observed: dict = {}

    def g03():
        observed.update(s.platform.runtime_observation())
        return gate_g03_runtime(observed, c)
    s.gate("G03", g03)
    s.record["runtime_observed"] = dict(observed)
    s.gate("G04", lambda: gate_g04_authority(s))
    s.adapter_identity = s.gate("G05", lambda: gate_g05_package(lay, c))
    g06 = s.gate("G06", lambda: gate_g06_code(s),
                 input_of=lambda r: {"m": r["manifest_sha256"], "r": r["runner_identity_sha256"]})
    s.gate("G07", lambda: release_validate(lay, c), input_of=lambda r: r)
    def g08():
        out = owner_auth_validate(lay.control_root, c)
        if s.mode == "RUN":
            s.record["run_authorization"] = run_authorization_validate(
                s.options.get("run_authorization"), c, s.adapter_identity["adapter_identity_sha256"])
        return out
    s.gate("G08", g08, input_of=lambda r: r)
    parent = s.gate("G09", lambda: s.frozen.full.validate_parent_2025(),
                    input_of=lambda p: {"f": p["freeze_sha256"], "h": p["homologation_sha256"],
                                        "cells": [x.cell_id for x in p["cells"]]})
    parent_validate(parent, c)
    s.gate("G10", lambda: config_validate((Path(lay.control_root) / c["config"]["path"]).read_bytes(), c,
                                          wanted_config(s, g06["manifest_sha256"], parent)), input_of=lambda r: r)
    before = s.gate("G11", lambda: snapshot_all(s))
    s.record["before_digests"] = snapshot_digests(before)
    s.record["before_json_sha256"] = s.write_evidence("BEFORE.json", before)

    def g12():
        st = classify_structure(before["control"], c, lay.control_root)
        if st["state"] == BLOCKED:
            raise AdapterBlocked("STATE_BLOCKED_AMBIGUOUS", ";".join(st["findings"])[:400])
        if st.get("runlock_present") or st.get("scratch_files"):
            st["owners"] = stale_owner_check(lay.control_root, s.frozen)
        rb = Path(lay.control_root) / c["run_owned_names"]["run_binding"]
        if rb.exists():
            run_binding_compare(load_json_strict(rb.read_bytes()), s.adapter_identity, c)
        return st
    struct = s.gate("G12", g12, input_of=lambda st: state_digest(st))
    s.record["state"] = struct["state"]
    s.emit("STATE", struct["state"], findings=",".join(struct["findings"]) or "NONE")
    s.gate("G13", lambda: preflight_validate(lay.preflight_root, c), input_of=lambda r: r)
    s.record["g14"] = s.gate("G14", lambda: inputs_validate(lay, c),
           input_of=lambda r: {"ind": r["ind_d1_sha256"], "m1": r["m1_inventory_sha256"], "ticks": r["ticks_metadata"]})
    s.record["d1b"] = s.gate("G15", lambda: gate_g15_d1b(s, struct["state"]), input_of=lambda r: r)
    s.gate("G16", lambda: gate_g16_free_space(s, before["control"]))
    if with_tick_rehash:
        t_start = time.monotonic()

        def progress(done, total, _last=[0, t_start]):
            now = time.monotonic()
            # cadência canônica: fronteira de chunk (1 GiB) ou <= 30 s, e o último bloco
            if done - _last[0] >= STATUS_CHUNK_BYTES or now - _last[1] >= STATUS_CADENCE_SECONDS or done == total:
                _last[0], _last[1] = done, now
                rate = done / max(now - t_start, 1e-6)
                eta = (total - done) / rate if rate > 0 else None
                s.emit("TICK_REHASH_PROGRESS", f"{100.0 * done / total:.1f}%", bytes=done)
                s.status(progress=done, total=total, rate=f"{rate / 2 ** 20:.1f}MiB/s", eta_s=eta,
                         extra={"unit": "bytes", "gate": "G17"})
        s.record["tick_rehash"] = s.gate("G17", lambda: tick_rehash(lay, c, progress), input_of=lambda r: r["ticks"])
    return {"parent": parent, "struct": struct, "before": before, "g06": g06}


def _release_mutexes(s: Session) -> None:
    while s.mutexes:
        h = s.mutexes.pop()
        try:
            s.platform.release_named_mutex(h)
        except AdapterBlocked as e:
            s.emit("MUTEX_RELEASE", "BLOCKED", code=e.code)


def _shadow_run_to_boundary(s: Session, root: Path) -> None:
    """G20–G22 + BND no shadow (modo DRY)."""
    fz, c = s.frozen, s.constants
    po = root / "PHASE_B"
    s.gate("G20", lambda: _assert_final_absent(po))
    h = None
    try:
        with SeamSet(s, "DRY", root):
            h = s.gate("G21", lambda: _pre_recover(s, root))
            try:
                phase_b_only(fz.full.run_phase)(root, "B", s.record["parent_cells"], s.record["binding"],
                                                s.record["shadow_identity"], s.record["runtime_hashes"],
                                                s.record["calendar"], Path(s.record["d1_path"]),
                                                c["config"]["workers"], c["config"]["batch_rows"])
            except PreProcessRecordBoundary:
                s.record["bnd_reached"] = True
                s.mark("G22", compare_in_run=False)
                s.mark("BND", session=s.record.get("bnd_session"))
                s.emit("BND_PRE_PROCESS_RECORD", "REACHED", session=s.record.get("bnd_session"))
                return
            raise AdapterBlocked("BND_NOT_REACHED")
    finally:
        if h is not None:
            s.platform.release_named_mutex(h)


def _assert_final_absent(po: Path) -> dict:
    if (Path(po) / "PHASE_B_FINAL_REPORT.json").exists():
        raise AdapterBlocked("FINAL_PRESENT_BEFORE_RUN_PHASE", str(po))
    return {"final_absent": True}


def _pre_recover(s: Session, root: Path):
    h = s.platform.acquire_named_mutex(r1r11_mutex_name(root))
    try:
        s.frozen.tx.recover(Path(root) / "PHASE_B")
    except BaseException:
        s.platform.release_named_mutex(h)
        raise
    return h


def dry_flow(s: Session, platform_tolerant=frozenset()) -> dict:
    s.plan = PLAN_COMMON + ["G17", "G18", "G20", "G21", "G22", "BND", "G23"]
    ctx = _common_pre_shadow(s, with_tick_rehash=True)
    state = ctx["struct"]["state"]
    s.record["parent_cells"] = ctx["parent"]["cells"]
    s.tee = TraceTee(sys.stdout)
    real_stdout = sys.stdout
    sys.stdout = s.tee
    scope = None
    try:
        s.gate("G18", lambda: gate_g18_shadow(s, state, ctx["parent"], platform_tolerant),
               input_of=lambda r: {"repro": r["reproduction"]["files"], "identity": r["identity_stable"], "files": r["files"]})
        if state not in (EMPTY, PREPARED):
            s.plan = PLAN_COMMON + ["G17", "G18", "G23"]
        if state in (EMPTY, PREPARED):
            _shadow_run_to_boundary(s, Path(s.record["shadow_root"]))
            scope = "SUBSTANTIVE_TO_BND"
        elif state == IN_PROGRESS:
            s.record["in_progress"] = validate_in_progress(
                s.layout.control_root, s.constants, ctx["struct"], s.frozen, s.record["identity_control"],
                s.record["runtime_hashes"], ctx["parent"]["cells"], s.record["calendar"], s.layout)
            scope = "PRELOCK_READONLY"
        elif state == FINAL_VALID:
            exp = rows_from_bytes((Path(s.layout.control_root) / "PHASE_B" / "EXPECTED_SESSIONS_PHASE_B.csv").read_bytes())
            s.record["final"] = final_validate(Path(s.layout.control_root) / "PHASE_B", s.constants, exp,
                                               lambda po, cp: _verify_seals(s, po, cp))
            scope = "FINAL_VALID_READONLY"
    finally:
        sys.stdout = real_stdout
    s.record["dry_scope"] = scope
    s.record["runtime_trace"] = normalize_trace(s.tee.lines, s.constants["trace"])
    after = s.gate("G23", lambda: snapshot_all(s))
    s.write_evidence("AFTER.json", after)
    s.record["after_digests"] = snapshot_digests(after)
    delta = diff_inventories(ctx["before"]["control"], after["control"])
    s.record["control_delta"] = delta
    others = [k for k in ("preflight", "code", "package", "release_top", "inputs")
              if s.record["before_digests"][k] != s.record["after_digests"][k]]
    if delta or others:
        raise AdapterBlocked("DRY_MUTATION_DETECTED", ",".join(delta[:10] + others))
    s.record["t30"] = t30_foreign_entries(s)
    if s.record["t30"]["foreign"]:
        raise AdapterBlocked("T30_FOREIGN_ENTRY", ";".join(s.record["t30"]["foreign"][:20]))
    if scope == "SUBSTANTIVE_TO_BND":
        ev = runtime_evidence(s.record["shadow_root"], os.getpid(), s.started_ns)
        import multiprocessing
        if not ev["started"] or not ev["clean"] or multiprocessing.active_children():
            raise AdapterBlocked("DRY_PROCESS_TREE_NOT_PROVEN", json.dumps(ev, sort_keys=True))
        s.record["runtime_evidence"] = ev
    return {"scope": scope, "state": state}


FOREIGN_MARKERS = ("_avast_",)


def t30_foreign_entries(s: Session) -> dict:
    """T30 (DD-9): entradas estranhas (marcadores de antivírus, links, objetos não regulares) em CONTROL,
    CODE e no shadow desta tentativa. Somente leitura; nomes apenas (sem conteúdo)."""
    out = {"roots": {}, "foreign": []}
    roots = {"control": s.layout.control_root, "code": s.layout.code_root}
    if s.record.get("shadow_root"):
        roots["shadow"] = str(Path(s.record["shadow_root"]).parent)
    for key, root in roots.items():
        inv = inventory(root, hash_files=False)
        names = list(inv["files"]) + inv["dirs"]
        hits = [f"{key}:{n}" for n in names if any(m in n.casefold() for m in FOREIGN_MARKERS)]
        hits += [f"{key}:link:{n}" for n in inv["links"]] + [f"{key}:other:{n}" for n in inv["other"]]
        out["roots"][key] = {"root": str(root), "entries": len(names), "foreign": len(hits)}
        out["foreign"] += hits
    return out


def _verify_seals(s: Session, po, cp) -> None:
    class _V:
        pass
    v = _V()
    v.telemetry = Path(s.layout.control_root) / "TELEMETRY" / "R1R11_TRANSPORT.jsonl"
    s.frozen.coord.Runtime.verify_committed(v, Path(po), cp)


def dry_receipt(s: Session, result: str, exit_code: int, labels: dict, error=None) -> dict:
    return {
        "schema": "MINOTAURO_PHASE_B_ADAPTER_DRY_RECEIPT_V001",
        "result": result, "exit_code": exit_code, "labels": labels, "error": error,
        "attempt_id": s.attempt_id, "mode": s.mode,
        "adapter_identity_sha256": (s.adapter_identity or {}).get("adapter_identity_sha256"),
        "constants_sha256": s.constants.get("_sha256"), "envelope_sha256": s.constants["envelope"]["sha256"],
        "code_manifest_sha256": s.constants["frozen_code"]["manifest_sha256"],
        "state": s.record.get("state"), "dry_scope": s.record.get("dry_scope"),
        "gates": s.gates, "runtime_trace": s.record.get("runtime_trace"),
        "runtime_trace_sha256": canonical_hash(s.record.get("runtime_trace") or []),
        "raw_trace_lines": len(s.tee.lines) if s.tee else 0,
        "before_digests": s.record.get("before_digests"), "after_digests": s.record.get("after_digests"),
        "control_delta": s.record.get("control_delta"), "shadow_root": s.record.get("shadow_root"),
        "bnd_reached": bool(s.record.get("bnd_reached")), "bnd_session": s.record.get("bnd_session"),
        "runtime_evidence": s.record.get("runtime_evidence"), "tick_rehash": s.record.get("tick_rehash"),
        "d1b": s.record.get("d1b"), "d1b_at_use": s.record.get("d1b_at_use"),
        "in_progress": s.record.get("in_progress"), "final": s.record.get("final"), "t30": s.record.get("t30"),
        "phase_c_execution": "NO", "reselection_2026": "FORBIDDEN",
    }


# --------------------------------------------------------------------------- RUN (desabilitado nesta identidade)
def run_flow(s: Session) -> dict:
    """Caminho RUN (G19/G24). Inalcançável enquanto release_stage != RUN_RELEASED (G00)."""
    if s.constants.get("release_stage") != "RUN_RELEASED":
        raise AdapterBlocked("RUN_B_DISABLED_IN_PACKAGE_IDENTITY")
    s.plan = PLAN_COMMON + ["G17", "G18", "G19", "G20", "G21", "G22", "G24"]
    ctx = _common_pre_shadow(s, with_tick_rehash=True)
    state = ctx["struct"]["state"]
    s.record["parent_cells"] = ctx["parent"]["cells"]
    lay, c, fz = s.layout, s.constants, s.frozen
    s.tee = TraceTee(sys.stdout)
    real_stdout = sys.stdout
    sys.stdout = s.tee
    try:
        s.gate("G18", lambda: gate_g18_shadow(s, state, ctx["parent"]),
               input_of=lambda r: {"repro": r["reproduction"]["files"], "identity": r["identity_stable"], "files": r["files"]})
        template = dry_receipt_validate(s.options.get("dry_receipt"), s.adapter_identity["adapter_identity_sha256"],
                                        state, s.gates, list(COMPARE_IN_RUN))
        s.tee.lines.clear()  # trace do RUN começa no G19 (mesma janela comparável do DRY: prepare+run_phase)
        control = Path(lay.control_root)
        po = control / "PHASE_B"
        if state != FINAL_VALID:
            def g19():
                rb_path = control / c["run_owned_names"]["run_binding"]
                existing = rb_path.exists()
                if existing:  # comparação somente leitura ANTES de F1
                    run_binding_compare(load_json_strict(rb_path.read_bytes()), s.adapter_identity, c)
                s.f1_marked = True
                s.emit("EFFECTFUL_FRONTIER", "F1_CONTROL")
                if not existing:
                    write_json_durable(rb_path, run_binding_document(s.adapter_identity, c, s.attempt_id), exclusive=True)
                pf, _a, _b, _d = phase_b_only(fz.full.prepare_preflight)(control, "B", Path(lay.preflight_root))
                po_, binding, identity, rhash, cal, d1_path = phase_b_only(fz.full.build_binding)(
                    control, "B", pf, ctx["parent"]["cells"], ctx["parent"])
                inv = inventory(control)
                pins = pinned_files(c["control_prepared"]["files"])
                bad = [k for k, v in pins.items() if inv["files"].get(k) != v]
                if bad:
                    raise AdapterBlocked("CONTROL_PREP_POSTVERIFY", ",".join(bad))
                if identity != s.record["identity_control"]:
                    raise AdapterBlocked("CONTROL_IDENTITY_NE_SHADOW_EXPECTED")
                return {"binding": binding, "identity": identity, "rhash": rhash, "cal": cal, "d1_path": str(d1_path)}
            g19r = s.gate("G19", g19)
            s.gate("G20", lambda: _assert_final_absent(po))
            h = None
            try:
                rt = template.get("runtime_trace") if template.get("dry_scope") == "SUBSTANTIVE_TO_BND" else None
                with SeamSet(s, "RUN", control, template_runtime_trace=rt):
                    h = s.gate("G21", lambda: _pre_recover(s, control))
                    phase_b_only(fz.full.run_phase)(control, "B", ctx["parent"]["cells"], g19r["binding"], g19r["identity"],
                                                    g19r["rhash"], g19r["cal"], Path(g19r["d1_path"]),
                                                    c["config"]["workers"], c["config"]["batch_rows"])
            finally:
                if h is not None:
                    s.platform.release_named_mutex(h)
            s.mark("G22")
            s.phase = "FINALIZE_PHASE_B"
            s.status()
            phase_b_only(fz.full.finalize_phase)(control, "B", ctx["parent"]["cells"], ctx["parent"])
    finally:
        sys.stdout = real_stdout
    return _run_post(s, ctx)


def _run_post(s: Session, ctx: dict) -> dict:
    lay, c = s.layout, s.constants
    control = Path(lay.control_root)
    po = control / "PHASE_B"
    exp = rows_from_bytes((po / "EXPECTED_SESSIONS_PHASE_B.csv").read_bytes())

    def g24():
        fin = final_validate(po, c, exp, lambda p, cp: _verify_seals(s, p, cp))
        if (control / "PHASE_C").exists():
            raise AdapterBlocked("PHASE_C_EFFECT_DETECTED")
        receipt = completion_receipt(s, po)
        rp = control / c["run_owned_names"]["completion_receipt"]
        if rp.exists():
            if load_json_strict(rp.read_bytes()) != receipt:
                raise AdapterBlocked("COMPLETION_RECEIPT_DIVERGENT")
        else:
            write_json_durable(rp, receipt, exclusive=True)
        zsha = evidence_zip(s, po, rp)
        gate_g06_recheck_code(s)
        return {"final": fin, "evidence_zip_sha256": zsha}
    return s.gate("G24", g24)


def gate_g06_recheck_code(s: Session) -> None:
    inv = inventory(s.layout.code_root)
    before = s.record.get("before_digests", {}).get("code")
    if before is not None and inventory_digest(inv) != before:
        raise AdapterBlocked("CODE_CHANGED_DURING_RUN")


def completion_receipt(s: Session, po: Path) -> dict:
    fr = load_json_strict((po / "PHASE_B_FINAL_REPORT.json").read_bytes())
    gate = load_json_strict((po / "CONFIRMATION_GATE.json").read_bytes())
    c = s.constants
    return {"schema": "MINOTAURO_PHASE_B_COMPLETION_RECEIPT_ADAPTER_V001", "status": "PASS", "phase": "B",
            "sessions": fr["sessions"], "first_session": fr["first_session"], "last_session": fr["last_session"],
            "checkpoint_sha256": fr["checkpoint_sha256"], "phase_master_manifest_sha256": fr["master_manifest_sha256"],
            "confirmation_gate_sha256": fr["confirmation_gate_sha256"], "confirmation_status": gate.get("status"),
            "adapter_identity_sha256": (s.adapter_identity or {}).get("adapter_identity_sha256"),
            "constants_sha256": c["_sha256"], "envelope_sha256": c["envelope"]["sha256"],
            "runner_identity_sha256": c["frozen_code"]["runner_identity_sha256"],
            "code_manifest_sha256": c["frozen_code"]["manifest_sha256"],
            "owner_authorization_receipt_sha256": c["owner_authorization"]["sha256"],
            "phase_c_committed": 0, "phase_c_authorized": "NO", "reselection_2026": "FORBIDDEN"}


def evidence_zip(s: Session, po: Path, completion_path: Path) -> str:
    out = Path(s.layout.phase_b_evidence_zip)
    names = ["PHASE_B_FINAL_REPORT.json", "CONFIRMATION_GATE.json", "CHECKPOINT.json", "RUN_SOURCE_BINDING_B.json",
             "EXPECTED_SESSIONS_PHASE_B.csv", "R3_CUTOFF_SIDECARS_PHASE_B.jsonl", "SUMMARY_2026_FROZEN_ONLY.csv",
             "MONTHLY_2026_FROZEN_ONLY.csv", "SHA256SUMS.txt"]
    members = [("CONTROL/PHASE_B/" + n, (po / n).read_bytes()) for n in names]
    members.append(("CONTROL/GATES/PHASE_B_COMPLETION_RECEIPT.json", completion_path.read_bytes()))
    members.sort(key=lambda m: m[0])
    manifest = "".join(f"{sha256_bytes(d)}  {n}\n" for n, d in members).encode("ascii")
    members.append(("MANIFEST_SHA256.txt", manifest))
    import io
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for n, d in members:
            zi = zipfile.ZipInfo(n, (1980, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, d)
    data = buf.getvalue()
    if out.exists():
        if sha256_file(out) != sha256_bytes(data):
            raise AdapterBlocked("EVIDENCE_ZIP_DIVERGENT")
        return sha256_bytes(data)
    tmp = out.with_name(out.name + ".tmp")
    with tmp.open("xb") as f:
        f.write(data); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, out)
    return sha256_bytes(data)


def _percentile(sorted_vals: list, q: float):
    """Nearest-rank."""
    if not sorted_vals:
        return None
    import math
    k = max(1, math.ceil(q * len(sorted_vals)))
    return sorted_vals[k - 1]


def _dir_sizes_stat_only(root: Path) -> dict:
    """Somente stat (DD-7: nenhum conteúdo econômico é aberto)."""
    files, total = 0, 0
    for cur, _d, fnames in os.walk(root, followlinks=False):
        for fn in fnames:
            fp = Path(cur) / fn
            if fp.is_file() and not is_link_safe(fp):
                files += 1
                total += fp.stat().st_size
    return {"files": files, "bytes": total}


def is_link_safe(p: Path) -> bool:
    try:
        return p.is_symlink()
    except OSError:
        return True


def q06_partial(s: Session, before: dict) -> dict:
    sess_root = Path(s.layout.parent_2025_root) / "PHASE_A" / "sessions"
    out = {"scope": "PARTIAL: parent 2025 PHASE_A/sessions + current CONTROL/TELEMETRY sizes; QS4 growth not measured",
           "parent_sessions_root": str(sess_root)}
    if not sess_root.is_dir():
        out["parent_sessions"] = {"status": "ABSENT"}
    else:
        per = []
        for d in sorted(sess_root.iterdir()):
            if d.is_dir() and not is_link_safe(d):
                per.append(dict({"session": d.name}, **_dir_sizes_stat_only(d)))
        vals = sorted(x["bytes"] for x in per)
        out["parent_sessions"] = {"status": "PRESENT", "count": len(per), "total_bytes": sum(vals),
                                  "p50_bytes": _percentile(vals, 0.50), "p95_bytes": _percentile(vals, 0.95),
                                  "max_bytes": vals[-1] if vals else None, "per_session": per}
    tel = {k: v["bytes"] for k, v in before["control"]["files"].items() if k.startswith("TELEMETRY/")}
    out["control_telemetry"] = {"status": "PRESENT" if tel else "ABSENT_IN_CURRENT_STATE", "files": len(tel),
                                "total_bytes": sum(tel.values()), "per_file_bytes": tel}
    return out


def qs2_physical(s: Session, ctx: dict) -> dict:
    """B03: detalhes físicos Q01–Q06_partial persistidos no CLASSIFY_RECEIPT (não só hashes agregados)."""
    c, lay, before = s.constants, s.layout, ctx["before"]
    g14 = s.record.get("g14") or {}
    ind_meta = before["inputs"]["ind"]
    ticks_meta = {t["path"]: t for t in g14.get("ticks_metadata", [])}
    rehash = {t["path"]: t["sha256"] for t in (s.record.get("tick_rehash") or {}).get("ticks", [])}
    q04 = []
    for t in c["inputs"]["ticks"]:
        m = ticks_meta.get(t["path"], {})
        q04.append({"path": t["path"], "bytes": m.get("bytes"), "expected_bytes": t["bytes"],
                    "mtime_ns": m.get("mtime_ns"), "volume_serial_st_dev": m.get("st_dev"),
                    "file_id_st_ino": m.get("st_ino"), "expected_sha256": t["sha256"],
                    "rehash_sha256": rehash.get(t["path"], "NOT_REHASHED_IN_THIS_INVOCATION")})
    host_fn = getattr(s.platform, "host_observation", None)
    host = host_fn([lay.release_root, lay.base_csv_root, lay.evidence_base, lay.shadow_base]) if host_fn else {"status": "UNAVAILABLE"}
    return {
        "Q01": {"control_files": len(before["control"]["files"]), "control_expected_files": len(c["control_prepared"]["files"]),
                "control_inventory": before["control"]["files"], "control_dirs": before["control"]["dirs"],
                "control_links": before["control"]["links"], "control_other": before["control"]["other"],
                "state_structure": s.record.get("state"),
                "preflight_files": len(before["preflight"]["files"]), "preflight_inventory": before["preflight"]["files"],
                "preflight_dirs": before["preflight"]["dirs"], "before_json_sha256": s.record.get("before_json_sha256")},
        "Q02": {"path": str(lay.ind_d1), "bytes": ind_meta["bytes"], "mtime_ns": ind_meta["mtime_ns"],
                "sha256": ind_meta["sha256"], "binding_ind_d1_sha256": c["inputs"]["ind_d1_sha256"],
                "equal": ind_meta["sha256"] == c["inputs"]["ind_d1_sha256"]},
        "Q03": {"range": c["inputs"]["m1_inventory_range"], "root": str(lay.m1_root),
                "files": len(g14.get("m1_inventory", [])), "inventory": g14.get("m1_inventory"),
                "inventory_sha256": g14.get("m1_inventory_sha256")},
        "Q04": {"ticks": q04, "total_bytes": sum(int(x["bytes"] or 0) for x in q04),
                "expected_total_bytes": c["inputs"]["ticks_total_bytes"]},
        "Q05": {"runtime_observed": s.record.get("runtime_observed"), "host": host,
                "powershell_version_and_antivirus": "COLLECTED_BY_BOOTSTRAP_IN_QS2_RECEIPT"},
        "Q06_partial": q06_partial(s, before),
    }


def qs2_physical_with_verdicts(s: Session, ctx: dict) -> dict:
    q = qs2_physical(s, ctx)
    for k, v in qs2_verdicts(q, s.constants).items():
        q[k].update(v)
    return q


def _months(lo: str, hi: str) -> list:
    y, m = int(lo[:4]), int(lo[5:7])
    out = []
    while f"{y:04d}-{m:02d}" <= hi:
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return out


def qs2_verdicts(q: dict, c: dict) -> dict:
    """B03: veredito substantivo por item (nunca por mera presença da chave)."""
    out = {}
    r = []
    q1 = q["Q01"]
    if q1["state_structure"] != PREPARED:
        r.append("STATE_NOT_PREPARED:" + str(q1["state_structure"]))
    if q1["control_files"] != q1["control_expected_files"]:
        r.append(f"CONTROL_FILES={q1['control_files']}!={q1['control_expected_files']}")
    if q1["preflight_files"] != len(c["preflight"]["files"]):
        r.append(f"PREFLIGHT_FILES={q1['preflight_files']}!={len(c['preflight']['files'])}")
    if q1["control_links"] or q1["control_other"]:
        r.append("CONTROL_LINKS_OR_OTHER")
    pins = {e["path"]: e["sha256"] for e in c["control_prepared"]["files"]}
    if any(q1["control_inventory"].get(k, {}).get("sha256") != v for k, v in pins.items()):
        r.append("CONTROL_PINNED_HASH_DRIFT")
    out["Q01"] = r
    out["Q02"] = [] if q["Q02"]["equal"] is True else ["IND_SHA_NE_BINDING"]
    r = []
    inv = q["Q03"]["inventory"] or []
    months = [x["name"][-11:-4].replace("_", "-") for x in inv]
    want = _months(*c["inputs"]["m1_inventory_range"])
    missing = [m for m in want if m not in months]
    if not inv or q["Q03"]["files"] != len(inv) or not q["Q03"]["inventory_sha256"]:
        r.append("M1_INVENTORY_EMPTY_OR_INCONSISTENT")
    if missing:
        r.append("M1_MONTHS_MISSING:" + ",".join(missing[:40]))
    if len(set(months)) != len(months):
        r.append("M1_MONTH_DUPLICATED")
    if any(len(str(x.get("sha256") or "")) != 64 for x in inv):
        r.append("M1_SHA_INVALID")
    out["Q03"] = r
    r = []
    ticks = q["Q04"]["ticks"]
    if len(ticks) != len(c["inputs"]["ticks"]):
        r.append("TICK_COUNT")
    for t in ticks:
        if t["bytes"] != t["expected_bytes"]:
            r.append("TICK_BYTES:" + t["path"])
        if not t["file_id_st_ino"] or t["volume_serial_st_dev"] is None or t["mtime_ns"] is None:
            r.append("TICK_FILE_ID_OR_META_MISSING:" + t["path"])
    out["Q04"] = r
    r = []
    ro = q["Q05"]["runtime_observed"] or {}
    for k in ("python_exe", "python_exe_sha256", "python_version", "numpy", "numpy_origin"):
        if not ro.get(k):
            r.append("RUNTIME_" + k.upper() + "_MISSING")
    host = q["Q05"]["host"] or {}
    if host.get("status") is not None:
        r.append("HOST_" + str(host.get("status")))
    if not host.get("logical_cpus") or not host.get("ram_total_bytes"):
        r.append("HOST_CPU_OR_RAM_MISSING")
    vols = host.get("volumes") or {}
    if not vols or any(not str(v.get("fs", "")) or str(v.get("fs", "")).startswith("UNAVAILABLE") or "free_bytes" not in v
                       for v in vols.values()):
        r.append("HOST_VOLUME_FS_OR_SPACE_MISSING")
    out["Q05"] = r
    ps = q["Q06_partial"]["parent_sessions"]
    out["Q06_partial"] = [] if ps.get("status") == "PRESENT" and ps.get("count", 0) > 0 else ["PARENT_SESSIONS_" + str(ps.get("status"))]
    return {k: {"verdict": "PASS" if not v else "FAIL", "reasons": v} for k, v in out.items()}


def classify_flow(s: Session, with_tick_rehash: bool) -> dict:
    s.plan = PLAN_COMMON + (["G17"] if with_tick_rehash else []) + ["Q_PHYSICAL", "G23"]
    ctx = _common_pre_shadow(s, with_tick_rehash=with_tick_rehash)
    s.record["qs2_physical"] = s.gate("Q_PHYSICAL", lambda: qs2_physical_with_verdicts(s, ctx))
    after = s.gate("G23", lambda: snapshot_all(s))
    s.write_evidence("AFTER.json", after)
    s.record["after_digests"] = snapshot_digests(after)
    delta = diff_inventories(ctx["before"]["control"], after["control"])
    s.record["control_delta"] = delta
    others = [k for k in ("preflight", "code", "package", "release_top", "inputs")
              if s.record["before_digests"][k] != s.record["after_digests"][k]]
    if delta or others:
        raise AdapterBlocked("CLASSIFY_MUTATION_DETECTED", ",".join(delta[:10] + others))
    return {"state": ctx["struct"]["state"]}


RECEIPT_NAMES = {"DRY": "DRY_RECEIPT.json", "RUN": "RUN_RECEIPT.json", "CLASSIFY": "CLASSIFY_RECEIPT.json"}
RECEIPT_SCHEMAS = {"DRY": "MINOTAURO_PHASE_B_ADAPTER_DRY_RECEIPT_V001",
                   "RUN": "MINOTAURO_PHASE_B_ADAPTER_RUN_RECEIPT_V001",
                   "CLASSIFY": "MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001"}


def protected_deltas(s: Session) -> dict:
    """Recomputa CONTROL/PREFLIGHT/CODE/pacote contra o BEFORE desta invocação.
    Impossibilidade de provar => tratado como alterado (fail-closed)."""
    out = {"control": False, "inputs": [], "unprovable": False}
    bd = s.record.get("before_digests") or {}
    try:
        for key, root in (("control", s.layout.control_root), ("preflight", s.layout.preflight_root),
                          ("code", s.layout.code_root), ("package", s.layout.package_root)):
            if bd.get(key) is not None and inventory_digest(inventory(root)) != bd[key]:
                if key == "control":
                    out["control"] = True
                else:
                    out["inputs"].append(key)
    except Exception:  # noqa: BLE001
        out.update(control=True, unprovable=True)
        out["inputs"].append("UNPROVABLE")
    return out


def verified_companion_name(name: str) -> str:
    return name[:-len(".json")] + ".VERIFIED.json"


def verified_companion(receipt_sha256: str, attempt_id: str, exit_code: int, mode: str) -> dict:
    return {"schema": "MINOTAURO_PHASE_B_ADAPTER_RECEIPT_VERIFIED_V001", "receipt_sha256": receipt_sha256,
            "attempt_id": attempt_id, "exit_code": exit_code, "mode": mode, "readback": "PASS"}


def verify_receipt_on_disk(path: Path, expected_sha256: str, attempt_id: str, exit_code: int, mode: str) -> None:
    """B02: verificação física do receipt gravado (bytes, JSON, identidade da tentativa, exit)."""
    raw = Path(path).read_bytes()
    if sha256_bytes(raw) != expected_sha256:
        raise AdapterBlocked("RECEIPT_READBACK_SHA")
    doc = load_json_strict(raw)
    if (doc.get("attempt_id") != attempt_id or doc.get("exit_code") != exit_code or doc.get("mode") != mode
            or doc.get("schema") != RECEIPT_SCHEMAS[mode]):
        raise AdapterBlocked("RECEIPT_READBACK_CONTENT")


def finish(s: Session, outcome: str, error) -> int:
    """Classificação final de saída + status final + receipt (B01/B02/B08).
    Ordem obrigatória: (1) falhas anteriores de status rebaixam 0/130; (2) status final ACTIVE=NO gravado e relido;
    (3) receipt autoritativo com o resultado do passo 2; (4) releitura + companion. Receipt ausente/não verificado
    ou status obrigatório não persistido nunca preserva 0 nem 130 (2 sem efeito protegido, 3 com efeito)."""
    pd = protected_deltas(s)
    control_changed = pd["control"]
    input_changed = bool(pd["inputs"])
    s.record["protected_delta_at_finish"] = (["control"] if control_changed else []) + pd["inputs"]
    ev_root = s.layout.control_root if s.mode == "RUN" else s.record.get("shadow_root")
    ev = runtime_evidence(ev_root, os.getpid(), s.started_ns) if ev_root else {"started": False, "clean": False}
    reclass = None
    if s.mode == "RUN" and outcome == "INTERRUPT" and s.f1_marked:
        try:
            reclass = classify_structure(inventory(s.layout.control_root), s.constants, s.layout.control_root)["state"]
        except Exception:  # noqa: BLE001
            reclass = BLOCKED
    run_post_validated = s.mode == "RUN" and any(g.get("id") == "G24" and g.get("status") == "PASS" for g in s.gates)
    code, labels = classify_exit(s.mode, outcome=outcome, f1_marked=s.f1_marked, control_changed=control_changed,
                                 runtime_started=ev.get("started", False), runtime_tree_clean=ev.get("clean", False),
                                 reclass_state=reclass, protected_input_changed=input_changed,
                                 run_post_validated=run_post_validated)
    if s.record["protected_delta_at_finish"]:
        labels["PROTECTED_DELTA"] = ",".join(s.record["protected_delta_at_finish"])
    effect = bool(s.f1_marked or control_changed or input_changed)
    if code == 130:
        s.safe_stop = "YES"
    s.stop_heartbeat()
    state = {"code": code}

    def downgrade(reason: str) -> None:
        cur = state["code"]
        new = downgrade_for_missing_receipt(cur, effect=effect)
        if new != cur:
            labels[reason + "_DOWNGRADE"] = f"{cur}->{new}"
            if cur == 130:
                s.safe_stop = "NO"
            state["code"] = new
    # B08 (1): qualquer falha do status incremental obrigatório (transição, chunk ou vida) nunca preserva 0/130
    if s.status_failures:
        labels["STATUS_PERSISTENCE"] = f"FAILED:{s.status_failures}"
        downgrade("STATUS")
    # B08 (2): status final ACTIVE=NO persistido e relido ANTES do receipt; o receipt reflete este resultado
    name = RECEIPT_NAMES[s.mode]
    status_ok, status_sha = s.final_status(state["code"], name if s.evidence_dir is not None else None)
    if not status_ok:
        labels["STATUS_FINAL_PERSISTED"] = "NO"
        downgrade("STATUS")
    code = state["code"]
    receipt_ok = False
    if s.evidence_dir is not None:
        try:
            rec = dry_receipt(s, "PASS" if code == 0 else ("SAFE_STOP" if code == 130 else "NOT_PASS"), code, labels,
                              error)
            rec["schema"] = RECEIPT_SCHEMAS[s.mode]
            rec["protected_delta_at_finish"] = s.record["protected_delta_at_finish"]
            rec["run_post_validated"] = run_post_validated
            rec["status_write_failures"] = s.status_failures
            rec["status_final_persisted"] = status_ok
            rec["status_final_sha256"] = status_sha
            if s.mode == "CLASSIFY":
                rec["qs2_physical"] = s.record.get("qs2_physical")
            rsha = s.write_evidence(name, rec)
            verify_receipt_on_disk(s.evidence_dir / name, rsha, s.attempt_id, code, s.mode)
            # companion positivo (B02/B09): só existe se a releitura física confirmou o receipt
            s.write_evidence(verified_companion_name(name), verified_companion(rsha, s.attempt_id, code, s.mode))
            receipt_ok = True
            s.emit("RECEIPT", name, sha256=rsha, path=str(s.evidence_dir / name), verified="YES")
        except Exception as e:  # noqa: BLE001 - erro primário prevalece; receipt ausente nunca é PASS
            s.emit("RECEIPT_WRITE", "FAILED", error=type(e).__name__)
            labels["RECEIPT_WRITTEN"] = "NO"
            labels["RECEIPT_ERROR"] = type(e).__name__
    else:
        labels["RECEIPT_WRITTEN"] = "NO"
        labels["RECEIPT_ERROR"] = "EVIDENCE_DIR_NOT_OPEN"
    if not receipt_ok:
        downgrade("RECEIPT")
        if state["code"] != code:
            # status final corretivo (melhor esforço): o receipt ausente/inválido já impede PASS no bootstrap
            s.final_status(state["code"], None)
        code = state["code"]
    for k, v in labels.items():
        s.emit(k, v)
    return code
