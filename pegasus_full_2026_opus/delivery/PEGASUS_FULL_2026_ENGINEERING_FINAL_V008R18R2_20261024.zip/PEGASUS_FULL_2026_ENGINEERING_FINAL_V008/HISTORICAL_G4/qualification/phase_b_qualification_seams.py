"""PHASE_B_ADAPTER_V001 — seams SOMENTE de qualificação (QS4): SEAM-INTERRUPT-AFTER e SEAM-FAULT.

Nunca importado por dry-run-b/run-b: SeamSet (phase_b_shared) bloqueia com
QUALIFICATION_SEAM_MODULE_LOADED_IN_PRODUCTION se este módulo estiver em sys.modules.
Uso previsto apenas pelo harness QS4 (shadow com dados reais em quarentena, DD-7),
que ainda NÃO está autorizado.
"""
from __future__ import annotations

import functools

INTERRUPT_TARGETS = {
    # alvo (módulo, atributo[, atributo]) — lista fechada do T18 (§9 V002)
    "RUNLOCK_ENTER": ("r1r11_resources", "RunLock", "__enter__"),
    "PREPARE_VOLUME": ("r1r11_full_2026", "prepare_volume"),  # from-import em full:25
    "RECOVER": ("r1r11_full_2026", "recover"),  # from-import em full:25
    "LOAD_CHECKPOINT": ("minotauro_v004_runner", "_load_checkpoint"),
    "WRITE_ANCHOR": ("r1r11_fast_resume", "write_anchor_checkpoint"),
    "CLEAR_ANCHOR": ("r1r11_fast_resume", "clear_anchor_checkpoint"),
    "FINALIZE_TRADES_CSV": ("r1r11_full_2026", "write_trades_csv_streaming"),  # nome ligado em full por from-import
}
FAULT_POINTS = ("before_journal", "after_journal", "during_pending", "after_pending", "before_publish",
                "after_commit_before_checkpoint", "during_checkpoint_replace", "after_checkpoint_before_cleanup")


class InterruptAfter:
    """Chama a função congelada original e, em seguida, levanta KeyboardInterrupt (uma vez)."""

    def __init__(self, sys_modules, target_key: str):
        if target_key not in INTERRUPT_TARGETS:
            raise ValueError("TARGET_NOT_IN_CLOSED_LIST " + target_key)
        self.mods = sys_modules
        self.spec = INTERRUPT_TARGETS[target_key]
        self.orig = None
        self.fired = False

    def _owner(self):
        owner = self.mods[self.spec[0]]
        for a in self.spec[1:-1]:
            owner = getattr(owner, a)
        return owner

    def __enter__(self):
        owner, name = self._owner(), self.spec[-1]
        self.orig = owner.__dict__[name] if isinstance(owner, type) else getattr(owner, name)
        orig = self.orig

        @functools.wraps(orig)
        def wrapper(*a, **k):
            r = orig(*a, **k)
            if not self.fired:
                self.fired = True
                raise KeyboardInterrupt("SEAM_INTERRUPT_AFTER " + "/".join(self.spec))
            return r
        setattr(owner, name, wrapper)
        return self

    def __exit__(self, *exc):
        setattr(self._owner(), self.spec[-1], self.orig)
        return False


class FaultAt:
    """SEAM-FAULT: substitui r1r11_coordinator.Runtime.fault_at para devolver 'kind' no ponto
    transacional configurado (pontos congelados de r1r11_v4_transaction.py:12-14). Runtime.inject
    (coord:403-404) converte isso em ModelError('FAULT_<POINT>')."""

    def __init__(self, sys_modules, point: str, kind: str = "raise"):
        if point not in FAULT_POINTS:
            raise ValueError("FAULT_POINT_NOT_IN_CLOSED_LIST " + point)
        self.cls = sys_modules["r1r11_coordinator"].Runtime
        self.point, self.kind, self.orig = point, kind, None

    def __enter__(self):
        self.orig = self.cls.__dict__["fault_at"]
        point, kind = self.point, self.kind

        def fault_at(self_, p, seq=None):
            return kind if p == point else None
        self.cls.fault_at = fault_at
        return self

    def __exit__(self, *exc):
        self.cls.fault_at = self.orig
        return False
