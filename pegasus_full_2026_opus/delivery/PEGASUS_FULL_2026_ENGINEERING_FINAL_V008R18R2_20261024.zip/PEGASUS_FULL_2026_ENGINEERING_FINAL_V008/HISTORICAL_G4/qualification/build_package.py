"""PHASE_B_ADAPTER_V001 — gera MANIFEST_SHA256.txt e ADAPTER_IDENTITY.json (sandbox de auditoria).
Uso: python -B qualification/build_package.py <PHASE_B_ADAPTER_V001_dir>"""
import hashlib
import json
import sys
from pathlib import Path


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()


def main(root):
    root = Path(root).resolve()
    if any(d.name == "__pycache__" for d in root.rglob("*") if d.is_dir()):
        raise SystemExit("PYCACHE_PRESENT")
    skip = {"MANIFEST_SHA256.txt", "ADAPTER_IDENTITY.json"}
    rels = sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and p.relative_to(root).as_posix() not in skip)
    text = "".join(f"{sha(root / r)}  {r}\n" for r in rels)
    (root / "MANIFEST_SHA256.txt").write_bytes(text.encode("ascii"))
    c = json.loads((root / "phase_b_constants.json").read_text(encoding="utf-8"))
    man = sha(root / "MANIFEST_SHA256.txt")
    ident = {"schema": "MINOTAURO_PHASE_B_ADAPTER_IDENTITY_V001", "adapter_version": c["adapter_version"],
             "adapter_identity_sha256": man, "manifest_sha256": man,
             "constants_sha256": sha(root / "phase_b_constants.json"), "envelope_sha256": c["envelope"]["sha256"],
             "release_stage": c["release_stage"], "files": len(rels),
             "code_manifest_sha256": c["frozen_code"]["manifest_sha256"],
             "runner_identity_sha256": c["frozen_code"]["runner_identity_sha256"]}
    (root / "ADAPTER_IDENTITY.json").write_bytes((json.dumps(ident, indent=1, sort_keys=True) + "\n").encode("utf-8"))
    print("ADAPTER_IDENTITY_SHA256=" + man)
    print("FILES=" + str(len(rels)))


if __name__ == "__main__":
    main(sys.argv[1])
