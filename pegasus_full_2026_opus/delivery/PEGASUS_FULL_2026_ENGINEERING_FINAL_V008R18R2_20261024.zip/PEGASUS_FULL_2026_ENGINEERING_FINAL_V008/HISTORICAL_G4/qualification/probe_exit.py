"""PHASE_B_ADAPTER_V001 — probe de propagação de exit nativo (QS2/QS3: T26). Sem import do projeto.

Escreve em stderr bytes determinísticos (b"PROBE_STDERR=<rc>\n", sem tradução de newline) para qualificar,
no alvo e na MESMA fronteira System.Diagnostics.Process, a captura de stderr + SHA-256 (B06) antes de ela
ser usada como diagnóstico do adapter."""
import sys

ALLOWED = {"0": 0, "2": 2, "3": 3, "7": 7, "130": 130, "7q": 7}  # "7q": sem stderr (T26-H via operador de chamada)

if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in ALLOWED or sys.flags.dont_write_bytecode != 1:
        sys.stdout.write("PROBE_EXIT=INVALID\n")
        sys.exit(9)
    sys.stdout.write("PROBE_EXIT=" + sys.argv[1] + "\n")
    sys.stdout.flush()
    if not sys.argv[1].endswith("q"):
        sys.stderr.buffer.write(b"PROBE_STDERR=" + sys.argv[1].encode("ascii") + b"\n")
        sys.stderr.buffer.flush()
    sys.exit(ALLOWED[sys.argv[1]])
