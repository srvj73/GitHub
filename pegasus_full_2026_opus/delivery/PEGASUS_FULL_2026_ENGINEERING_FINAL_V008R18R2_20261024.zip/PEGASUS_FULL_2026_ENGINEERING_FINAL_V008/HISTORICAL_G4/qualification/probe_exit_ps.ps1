<#
PHASE_B_ADAPTER_V001 - Q08 probe: propagacao de exit nativo pelo bloco PowerShell completo.
Lancado pelo BOOTSTRAP via System.Diagnostics.Process: powershell.exe -NoProfile -NonInteractive
  -ExecutionPolicy Bypass -File probe_exit_ps.ps1 -PythonExe <exe> -Probe <probe_exit.py> -Want <rc>
O filho Python e lancado pela mesma fronteira System.Diagnostics.Process; o exit do script = ExitCode do filho.
Sem sentinela de exit e sem cmdlet de lancamento de processo. Somente ASCII.
#>
param(
    [Parameter(Mandatory = $true)][string]$PythonExe,
    [Parameter(Mandatory = $true)][string]$Probe,
    [Parameter(Mandatory = $true)][ValidateSet('0', '2', '3', '7', '130')][string]$Want
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $PythonExe
$psi.Arguments = '-B "' + $Probe + '" ' + $Want
$psi.UseShellExecute = $false
$psi.EnvironmentVariables['PYTHONDONTWRITEBYTECODE'] = '1'
$proc = New-Object System.Diagnostics.Process
$proc.StartInfo = $psi
[void]$proc.Start()
$proc.WaitForExit()
$proc.Refresh()
$inner = $proc.ExitCode
Write-Output ('Q08_INNER_NATIVE_EXIT=' + $inner)
exit $inner
