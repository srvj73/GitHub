# PHASE_B_ADAPTER_V001 — Plano de qualificação (QS0–QS5) — sucessor R3 (policy live rebind)

Envelope: `CHANGE_ENVELOPE_PHASE_B_FIXABC_V001.json` (post-FIX-B SHA-256 `FAC9229A19B783745184461384FE97BF0844164ED8ED3F0D99AF55D7398CB3F4`; parent envelope preserved as `PARENT_CHANGE_ENVELOPE_PHASE_B_FIXABC_V001_20261005.json`).
`release_stage = QUALIFICATION_ONLY_RUN_DISABLED`: `run-b` é recusado em G00 nesta identidade.

| Estágio | Onde | Como | Estado nesta entrega |
|---|---|---|---|
| QS0 | Sandbox | `python -B qualification/qs0_static.py <receipt> --pwsh <pwsh>` | Executado (receipt no pacote de retorno) |
| QS1 | Sandbox (fixtures; E01 só leitura) | `MINOTAURO_E01_PAYLOAD=<payload> MINOTAURO_PWSH=<pwsh> python -B tests/run_qs1.py <receipt>` | Executado (receipt no pacote de retorno) |
| QS2 | PC, somente leitura + raiz owned | `BOOTSTRAP_PHASE_B_ADAPTER.ps1 -Stage QS2_READONLY -AuthorizationText "AUTORIZO QS2 PHASE_B_ADAPTER_V001" -PolicyReceipt <receipt>` | **NÃO autorizado / NÃO executado** |
| QS3 | PC, DRY substantivo (shadow owned) | `-Stage QS3_DRY -AuthorizationText "AUTORIZO QS3 PHASE_B_ADAPTER_V001" -PriorQS2Receipt <absoluto>\QS2_RECEIPT.json -PriorQS2ReceiptSha256 <sha>` → B07 (QS2 PASS provado) → T26 → `dry-run-b` até BND | **NÃO autorizado / NÃO executado** |
| QS4 | PC, shadow com dados reais em quarentena (DD-7) | harness próprio com `phase_b_qualification_seams` | **NÃO implementado como executor**; exige envelope de harness e autorização |
| QS5 | Pré-RUN | R01–R06 + nova identidade `RUN_RELEASED` + auditoria pré-entrega | Futuro |

## QS2 — itens do envelope e onde cada um é produzido

| Item | Produzido por | Evidência física persistida |
|---|---|---|
| Q01 | `classify-b` (G11/G12/G13) | `CLASSIFY_RECEIPT.qs2_physical.Q01`: inventário integral de CONTROL (caminho, bytes, SHA), diretórios, links, PREFLIGHT, SHA do `BEFORE.json` |
| Q02 | `classify-b` (G14) | `Q02`: caminho, bytes, mtime, SHA do IND e igualdade com `binding.ind_d1_sha256` |
| Q03 | `classify-b` (G14) | `Q03`: lista integral M1 2024-01..2026-08 (nome, bytes, SHA) + SHA canônico da lista |
| Q04 | `classify-b` (G14) | `Q04`: 8 ticks com bytes, mtime, `st_dev` (serial do volume) e `st_ino` (file ID NTFS) |
| Q05 | `classify-b` + bootstrap | `Q05`: runtime observado (exe, SHA, versão, numpy, origem), CPUs, RAM, FS/serial/espaço por volume; bootstrap: versão do PowerShell, CLR, SO, antivírus e exclusões (somente leitura) |
| Q06_partial | `classify-b` | `Q06_partial`: tamanhos por sessão de `PARENT_2025/PHASE_A/sessions` (total, p50, p95, máx; só `stat`) e tamanhos de `CONTROL/TELEMETRY` |
| Q07 | `qs2_target_probe.py q07` | `QS2/Q07_RECEIPT.json` (validação do receipt de recheck live da política, 1+1, SHAs) |
| Q08 | bootstrap → `powershell.exe -File probe_exit_ps.ps1` → python | `QS2_RECEIPT.items.Q08`: exit do bloco PowerShell completo para 0/2/3/7/130 |
| T26 | bootstrap → python (System.Diagnostics.Process) | exits 0/2/3/7/130 + stderr determinístico (qualifica a captura de stderr e o SHA-256 do B06) + padrão histórico `-999` reproduzido e classificado `INVALID_MEASUREMENT` |
| T31a | `qs2_target_probe.py t31a` | `QS2/T31A_RECEIPT.json`: mutex do adapter + RunLock congelado reentrante na mesma thread em raiz owned; 2º processo recusado; posse liberada sem vazamento |

Parse do bootstrap em **Windows PowerShell 5.1** (`[System.Management.Automation.Language.Parser]::ParseFile`) antes de executá-lo.

## Observabilidade (B05)
* Adapter: `ADAPTER/ADAPTER_STATUS.json` atualizado atomicamente (tmp + fsync + `os.replace`, com novas tentativas)
  em cada transição de gate e a cada 1 GiB ou ≤ 30 s no G17; campos PHASE, PROGRESS, COMMITTED, TOTAL, RATE, ETA
  (`D.HH.MM.SS`|`UNKNOWN`), FINISH, ACTIVE, READY_WAITING, CHECKPOINT, SAFE_STOP; persiste após o fim (ACTIVE=NO).
* Bootstrap: heartbeat a cada 30 s com os mesmos campos (incorporando o status do adapter e sua idade) e
  `BOOTSTRAP_STATUS.json` atômico (WriteThrough + `File.Replace`). Watchdog finito por filho, **sem auto-kill**:
  expiração ⇒ sem PASS, exit 3, `RECONCILIATION_REQUIRED=YES`, filho intocado.

## Autoridade live (rebind 2026-10-03)
`constants.authority` vinculado ao par live 1+1 FROZEN MASTER `40AE13EA…81F4` / HEAD `71A5E594…97DB`
(revisão `20261003T072301-0300-40AE13EAD4A2B260`), registro `qualification/POLICY_LIVE_REBIND_20261003.json`.
O par anterior (MASTER `D5EBEA05…`, HEAD `BA899ECC…`) passa a ser recusado por `policy_receipt_validate` (Q07 e G04/RUN).
Somente o bloco `authority` mudou (QS0.46 fixa o hash canônico da superfície não-authority igual ao R2).

## Encadeamento QS2 → QS3 (B07)
O QS3 só começa se `Test-PriorQS2Receipt` provar, antes de T26 e do dry-run: caminho absoluto em
`<evidence_base>\<attempt QS2>\QS2_RECEIPT.json`; SHA-256 completo igual ao fornecido pelo owner; schema/stage QS2;
`final_exit=0`, sem interrupção, sem efeito não provado, status persistido sem falhas; mesma identidade de adapter e de ZIP;
Q01–Q08, T26 (incl. histórico) e T31a PASS; vínculos físicos (CLASSIFY/T31A/Q07 receipts, companion `QS2_RECEIPT.VERIFIED.json`,
linha `STAGE_RECEIPT=` única e `FINAL_EXIT=0` única no `BOOTSTRAP.log`, `BOOTSTRAP_STATUS.json` final vinculado por SHA);
**conteúdo físico** dos receipts filhos (CLASSIFY PASS/0 com companion, status persistido e vereditos Q01–Q06_partial PASS;
T31A e Q07 PASS/0 da mesma tentativa). A validação roda duas vezes: antes da extração do pacote (identidade adiada) e após o
manifesto (identidade comparada). O SHA do receipt QS2 fica gravado em `QS3_RECEIPT.facts`.
Ressalva declarada: o mesmo QS2 PASS pode habilitar mais de um QS3 da mesma identidade (sem limite temporal); o próprio dry-run
reavalia todo o estado (G01–G23) em cada tentativa.

## Status obrigatório (B08)
Qualquer falha de persistência do status (transição, chunk, vida ou final) rebaixa 0/130 para 2 (sem efeito protegido)
ou 3 (com efeito/não provado), no adapter e no bootstrap. O status final `ACTIVE=NO` é gravado e relido ANTES do receipt;
o receipt registra `status_final_persisted`, `status_final_sha256` e `status_write_failures`, e o bootstrap confere o
`ADAPTER_STATUS.json` contra esse SHA antes de aceitar PASS.

## Lacunas conhecidas, declaradas
* G22 (RunLock → spawn → BND) nunca executou: depende de Win32 (QS3).
* T14F prova G01–G21 em fixture Linux e para em `RunLock.__enter__` (`MemoryProbeError WINDOWS_REQUIRED`).
* T31a só pode passar no alvo; na sandbox, prova G02/G06 + fórmula do mutex e o bloqueio fail-closed `WINDOWS_REQUIRED`.
* Harness do bootstrap executado em pwsh 7.4.6 (Linux), não em Windows PowerShell 5.1; a prova no alvo é o próprio QS2.
* PREPARED com resíduo de runtime sem checkpoint ⇒ BLOCKED_AMBIGUOUS (literal do envelope §5.5); medir em QS4 P3.
* FINALIZE_PENDING (saídas de finalize sem FINAL) é admitido como IN_PROGRESS para permitir a refinalização do T32.


## FIXABC qualification maintenance — 2026-10-05

- QS0.12 scanner now distinguishes filesystem destruction from in-memory collection `.remove()` calls; `out.remove()` in `phase_b_state.py` is a `set.remove()` and is non-destructive.
- QS0.46 is rebound to the physical active policy pair validated on 2026-10-05 and pins the FIXABC successor non-authority canonical SHA, rather than the predecessor R2 baseline.
- Production adapter code bytes and FIX-A/B/C runtime bytes are unchanged by this qualification maintenance.

## FIXABC R2 — derived RUNNER_HASH rebind (2026-10-05)

- Cause confirmed after the first authorized QS4 attempt: `CONTROL/PHASE_B/RUNNER_HASH.txt` in the successor was copied from the predecessor and remained bound to runner identity `0ACDD45F...`, while `frozen_code.runner_identity_sha256` is `5980D399025B29BBC2E6B3CC66B2D1C0EEF11BE5C532BE2015818D0817B3D76F`.
- The frozen `build_binding` correctly regenerates `RUNNER_HASH.txt` from the current runner identity. Expected file SHA-256 is `8D1C408D4DB06A3C6E919D4954D778B49D0FA43C2BD131F537E4B4308584E6F5`.
- Runtime production Python modules are unchanged. The delta is limited to the prepared-file pin, adapter version/currentness qualification metadata, QS0 non-authority baseline, and package identity.
- Any retry remains forbidden until physical state reconciliation is adjudicated PASS and the successor prepared control is explicitly rebound by an owner-authorized action.



## Post-FIX-B projected identity closure — 2026-10-06

- parent CODE manifest: `A5E272EEB01F5D8F039AC77DC32CFF8158E9510EB17804BAC4302E0717917292`
- projected CODE manifest: `725ECDC031A1A1F0F258892B09E3831BD392C262A7D10E66A0956455D1CC076E`
- projected runner identity: `5B03F79114D678739248BB37A26AC2F08C565D011156D8B178ADE97F61988767`
- derived `PHASE_B/RUNNER_HASH.txt` SHA-256: `D9C42C808FCBBBEA9F45C6D0D1D220020891C9C1045700568BE60EE5C32B15E7` (66 bytes, ASCII identity + CRLF)
- patched CODE hashes: coordinator `B172B95C99F4B33B4D74AEE1BF3CCD379EA1CA7DC6CA76A20F78EF8807770B85`; full `4BD5ACBD8E91D5FE949B19027A1B9F7809C50B2E87B0A009D8165B34A0ACC970`
- target mutation: **NO**; QS4: **NO**; FULL Phase B: **NO**.


## Projected FULL_2026_CONFIGURATION rebind — 2026-10-06 V001R2

- projected config SHA-256: `8BBD2309351C10F0E849ABA29781EEDD17BC22FFE841AD8084A508E2D59D874B`; only `package_manifest_sha256` changes from `A5E272EEB01F5D8F039AC77DC32CFF8158E9510EB17804BAC4302E0717917292` to `725ECDC031A1A1F0F258892B09E3831BD392C262A7D10E66A0956455D1CC076E`.
- prepared-control delta now includes `FULL_2026_CONFIGURATION.json` and `PHASE_B/RUNNER_HASH.txt`.
- production adapter runtime modules remain byte-identical; QS0.18 TEMP/TMP isolation remains qualification-only.
- target mutation: **NO**; QS4: **NO**; FULL Phase B: **NO**.


## G2 — 2026-10-08 — variante FIXB -> PID_REUSE (anexo de qualificação)

A seção anterior que descreve manifest `725ECDC0...` e config `8BBD2309...` corresponde **somente** ao FIXB projetado histórico. O envelope físico `CHANGE_ENVELOPE_PHASE_B_FIXABC_V001.json` não é alterado. A instalação posterior PID_REUSE atualizou os módulos `r1r11_resources.py`, `r1r11_v5_stream.py` e o `CODE/SHA256SUMS.txt`; o manifesto atual validado na captura reconstruída é `823E555C...E2D1A`, config `3BFEE008...91A4B`.

A transição histórica é registrada em `FIXB_PID_REUSE_QUALIFICATION_LINEAGE_V001.json` e validada pelo `build_constants.py` que exige **ambas** identidades, a pré no envelope e a pós no payload / constantes. O reprodutor não substitui a evidência E01 original: `E01_ORIGINAL_PROVENANCE=NOT_PROVEN`. Seu PASS apenas prova coerência da fixture reconstruída em sandbox. O QS0 da identidade posterior deverá ser reexecutado, QS1 integral continua pendente; RUN/C2/FULL proibidos nesta fase.


## G4 (2026-10-08) — E01 original autenticado e rebind policy v30
- E01 original 02/10 SHA256 21189621F22C9E134E5E7F3887D5F9D012E290884FF42663933D94EE0CC1310A provado por manifesto 558/558; captura de testes posterior 3757373881C20D8329E5D4C41B39D04BD25403BAA0453AEA51494CA9B64B8EC0 preservada como RECONSTRUCTED, não substitui E01.
- Revisão viva em construção: MASTER 011CFB0CDD39E3B2ECC104A7B967330D2B29D84EA2A506E74A3ABB2B8D231FA2 HEAD 8DDDF99F206848471A6A27A9E37637CC51CAD8378C482C3CA3F7C3322A68A1C5; novo arquivo qualification/POLICY_LIVE_REBIND_20261008_V30.json.
- QS0/Q07 requerem nova identidade e provas próprias; testes QS1 anteriores são evidência histórica limitada, não PASS terminal automático.
- Módulos econômicos / bootstrap inalterados; RUN_RELEASED=NO; AUTOCPU24 e SAFE_STOP continuam não qualificados.
