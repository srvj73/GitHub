"""G2: reproducer fail-closed sobre envelope FIXB + lineage PID_REUSE.

Uso (somente em sandbox OWNED):
 python -B build_constants.py <envelope_FIXB_original.json> <fixture_reconstruida_root> <out_constants.json>
PASS atesta reprodutibilidade de CONSTANTS da fixture reconstruída, NUNCA E01 original ou QS1 terminal.
"""
import hashlib, json, sys
from pathlib import Path, PurePosixPath

ROOT=Path(__file__).resolve().parents[1]
ENVELOPE_SHA256='FAC9229A19B783745184461384FE97BF0844164ED8ED3F0D99AF55D7398CB3F4'
LINEAGE_PATH=ROOT/'qualification/FIXB_PID_REUSE_QUALIFICATION_LINEAGE_V001.json'
LINEAGE_SHA256='CA42C9C18027BC32CA9B9DC19C0E0E938495529970E4060115C4BCDD0C53DFAE'
PRE_MANIFEST_SHA256='725ECDC031A1A1F0F258892B09E3831BD392C262A7D10E66A0956455D1CC076E'
PRE_CONFIG_SHA256='8BBD2309351C10F0E849ABA29781EEDD17BC22FFE841AD8084A508E2D59D874B'
POST_MANIFEST_SHA256='823E555C928A75CD14DBE55F5135757A9CC64B9F419D881401992F5E007E2D1A'
POST_CONFIG_SHA256='3BFEE008DA545E413A3B2282A273FFC99E6F0838C68592F51A57D2216B491A4B'
POST_RESOURCES_SHA256='56D046E53FDACE8DA415A5AC632609D7F6C4699FB7597D244EFF302BE255B2DB'
POST_STREAM_SHA256='4310B12530BB1667FCE7EEEA23D40091987D41F0EE06F5A5508410E87FDCCDCA'

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()

def require(ok, message):
    if not ok: raise SystemExit(message)

def exact_manifest(root):
    # Confirma a árvore pós-patch, não apenas a assinatura do manifesto.
    code=root/'CODE'
    raw=(code/'SHA256SUMS.txt').read_bytes().decode('ascii')
    entries={}
    for line in raw.splitlines():
        parts=line.split('  ',1)
        require(len(parts)==2,'CODE_MANIFEST_LINE_INVALID')
        key=parts[1]
        partskey=PurePosixPath(key)
        require(key and key not in entries and not partskey.is_absolute() and all(x not in ('.','..','') for x in key.split('/')) and chr(92) not in key and ':' not in key and key==partskey.as_posix(), 'CODE_MANIFEST_NAME_INVALID')
        entries[key]=parts[0]
    require(len(entries)==474,'CODE_MANIFEST_CARDINALITY_MISMATCH')
    for k,expected in entries.items():
        p=code/k
        require(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(code.resolve()) and sha(p)==expected,'CODE_MEMBER_MISMATCH:'+k)
    # Manifesto 474 entradas, incluindo subpastas relativas históricas; sem material extra atribuído a ele.
    physical={p.relative_to(code).as_posix() for p in code.rglob('*') if p.is_file()} - {'SHA256SUMS.txt'}
    require(physical==set(entries),'CODE_MANIFEST_FILE_SET_INVALID')

def main(argv):
    require(len(argv)==4,'USAGE')
    env,payload,out=map(Path,argv[1:])
    require(not out.resolve().is_relative_to(ROOT.resolve()) and not out.resolve().is_relative_to(payload.resolve()) and out.resolve()!=env.resolve(), 'OUTPUT_OVERWRITES_PROTECTED_SOURCE')
    require(sha(env)==ENVELOPE_SHA256,'ENVELOPE_SHA256_MISMATCH')
    e=json.loads(env.read_text(encoding='utf-8'))
    require(e.get('successor_code_manifest_sha256')==PRE_MANIFEST_SHA256 and e.get('projected_full_2026_configuration_sha256')==PRE_CONFIG_SHA256,'HISTORICAL_ENVELOPE_PRE_PATCH_MISMATCH')
    require(sha(LINEAGE_PATH)==LINEAGE_SHA256,'LINEAGE_RECORD_SHA256_MISMATCH')
    lineage=json.loads(LINEAGE_PATH.read_text(encoding='utf-8'))
    require(lineage.get('schema')=='PEGASUS_FIXB_TO_PID_REUSE_QUALIFICATION_LINEAGE_V001' and lineage.get('e01_original_provenance')=='NOT_PROVEN' and lineage.get('evidence_class')=='RECONSTRUCTED_SOURCE_CAPTURE_NOT_ORIGINAL_E01','LINEAGE_SCOPE_MISMATCH')
    require(lineage['historical_envelope']['sha256']==ENVELOPE_SHA256 and lineage['historical_envelope']['projected_manifest_sha256']==PRE_MANIFEST_SHA256 and lineage['historical_envelope']['projected_config_sha256']==PRE_CONFIG_SHA256,'LINEAGE_ENVELOPE_MISMATCH')
    require(lineage['pre_patch']['manifest_sha256']==PRE_MANIFEST_SHA256 and lineage['pre_patch']['config_sha256']==PRE_CONFIG_SHA256,'LINEAGE_PRE_PATCH_MISMATCH')
    require(lineage['post_patch']=={'manifest_sha256':POST_MANIFEST_SHA256,'config_sha256':POST_CONFIG_SHA256,'r1r11_resources_sha256':POST_RESOURCES_SHA256,'r1r11_v5_stream_sha256':POST_STREAM_SHA256},'LINEAGE_POST_PATCH_MISMATCH')
    require(lineage['historical_install_evidence']['post_manifest_sha256']==POST_MANIFEST_SHA256 and lineage['historical_install_evidence']['pre_manifest_sha256']==PRE_MANIFEST_SHA256 and lineage['historical_install_evidence']['manifest_rows']==474,'LINEAGE_INSTALL_BINDING_MISMATCH')
    require(sha(payload/'CODE/SHA256SUMS.txt')==POST_MANIFEST_SHA256,'POST_CODE_MANIFEST_MISMATCH')
    require(sha(payload/'CODE/r1r11_resources.py')==POST_RESOURCES_SHA256,'POST_RESOURCES_MISMATCH')
    require(sha(payload/'CODE/r1r11_v5_stream.py')==POST_STREAM_SHA256,'POST_STREAM_MISMATCH')
    exact_manifest(payload)
    require(sha(payload/'CONTROL/FULL_2026_CONFIGURATION.json')==POST_CONFIG_SHA256,'POST_CONFIG_MISMATCH')
    cfg=json.loads((payload/'CONTROL/FULL_2026_CONFIGURATION.json').read_text(encoding='utf-8'))
    require(cfg.get('package_manifest_sha256')==POST_MANIFEST_SHA256 and cfg.get('workers')==15,'POST_CONFIG_CONTENT_MISMATCH')
    src=ROOT/'phase_b_constants.json'
    c=json.loads(src.read_text(encoding='utf-8'))
    require(c.get('adapter_version')=='PHASE_B_ADAPTER_V001_FIXABC_R3_FIXB_RUNTIME_ROOT_REBIND','ADAPTER_VERSION_MISMATCH')
    au=c.get('authority',{}); lr=au.get('live_rebind',{})
    require(au.get('snapshot_master_sha256')=='011CFB0CDD39E3B2ECC104A7B967330D2B29D84EA2A506E74A3ABB2B8D231FA2' and au.get('snapshot_head_sha256')=='8DDDF99F206848471A6A27A9E37637CC51CAD8378C482C3CA3F7C3322A68A1C5' and au.get('snapshot_revision_id')=='20261008T132913-0300-011CFB0CDD39E3B2','POLICY_CURRENTNESS_BINDING_MISMATCH')
    require(lr.get('record')=='qualification/POLICY_LIVE_REBIND_20261008_V30.json','POLICY_REBIND_RECORD_MISMATCH')
    require(lr.get('record_sha256')=='51059071BC7EC5027DACAE4F21DC0076C8A422EF3D84784C23DC72F971B087CC' and sha(ROOT/lr['record'])==lr['record_sha256'],'POLICY_REBIND_RECORD_SHA256_MISMATCH')
    require(sha(ROOT/'qualification/E01_G3_PROVENANCE_BRIDGE_V001.json')=='0682DD5445545593E3FAD3C60A37252816A5A8B06A049BE5F1B682CC332B732D','E01_G3_BRIDGE_IDENTITY_MISMATCH')
    require(c.get('envelope')=={'file':'CHANGE_ENVELOPE_PHASE_B_FIXABC_V001.json','sha256':ENVELOPE_SHA256},'CONSTANTS_ENVELOPE_BINDING_MISMATCH')
    require(c.get('frozen_code',{}).get('manifest_sha256')==POST_MANIFEST_SHA256 and c['frozen_code'].get('r1r11_resources_sha256')==POST_RESOURCES_SHA256,'CONSTANTS_POST_CODE_BINDING_MISMATCH')
    require(c.get('config',{}).get('sha256')==POST_CONFIG_SHA256,'CONSTANTS_POST_CONFIG_BINDING_MISMATCH')
    require(c.get('release_stage')=='QUALIFICATION_ONLY_RUN_DISABLED','RELEASE_STAGE_MISMATCH')
    out.write_bytes(src.read_bytes())
    print('CONSTANTS_REPRODUCER=PASS_RECONSTRUCTED_POST_PID_REUSE_ONLY SHA256='+sha(out))
    print('E01_ORIGINAL_PROVENANCE=NOT_PROVEN QS1_TERMINAL=NOT_QUALIFIED')
    return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
