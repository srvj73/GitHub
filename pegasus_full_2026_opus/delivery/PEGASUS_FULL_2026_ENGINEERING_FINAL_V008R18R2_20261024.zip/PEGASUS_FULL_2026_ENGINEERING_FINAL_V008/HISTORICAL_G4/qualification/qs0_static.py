"""PHASE_B_ADAPTER_V001 — QS0 (estático + import-safety). Não importa o CODE; não toca D:\\.
Uso: python -B qualification/qs0_static.py <receipt_out.json> [--pwsh <pwsh_exe>]
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PRODUCTION = ["phase_b_entry.py", "phase_b_shared.py", "phase_b_state.py", "phase_b_contract.py", "phase_b_effects.py"]
CODE_MODULE_NAMES = {"r1r11_full_2026", "minotauro_v004_runner", "r1r11_coordinator", "r1r11_resources",
                     "r1r11_v4_transaction", "r1r11_fast_resume", "minotauro_v005r1_r23_contract", "minotauro_v004_io",
                     "minotauro_v004_core"}
PS_AUTOMATIC = ["args", "input", "PID", "LASTEXITCODE", "Error", "Host", "_", "PSItem", "Matches", "true", "false",
                "null", "PSScriptRoot", "MyInvocation", "PSBoundParameters", "HOME", "PWD", "ExecutionContext",
                "Event", "EventArgs", "foreach", "switch", "this", "PSCmdlet", "StackTrace", "Sender", "ShellId",
                "PSCommandPath", "PSVersionTable", "OFS", "ConsoleFileName", "NestedPromptLevel", "Profile"]


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()


def check(results, cid, ok, detail=""):
    results.append({"check": cid, "result": "PASS" if ok else "FAIL", "detail": detail})


def attr_chain(node):
    parts = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
        return ".".join(reversed(parts))
    return None


T26H_MARKER = "# QS0_ALLOW_T26_HISTORICAL_SENTINEL"
CANON_FIELDS = ["PHASE", "PROGRESS", "COMMITTED", "TOTAL", "RATE", "ETA", "FINISH", "ACTIVE", "READY_WAITING",
                "CHECKPOINT", "SAFE_STOP"]


def tree_digest(root):
    h = {}
    for p in sorted(Path(root).rglob("*")):
        if p.is_file():
            h[p.relative_to(root).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest().upper()
    return hashlib.sha256(json.dumps(h, sort_keys=True).encode()).hexdigest().upper(), len(h)


def ps_function_body(text: str, name: str) -> str:
    m = re.search(r"^function " + re.escape(name) + r"\b.*?(?=^function |^# =+ execução)", text, re.S | re.M)
    return m.group(0) if m else ""


def main(argv):
    out = Path(argv[1])
    pwsh = argv[argv.index("--pwsh") + 1] if "--pwsh" in argv else None
    R = []
    tree_before = tree_digest(ROOT)
    # 1. payload exato + identidade
    man = ROOT / "MANIFEST_SHA256.txt"
    listed = {}
    for line in man.read_text(encoding="ascii").splitlines():
        h, n = line.split("  ", 1)
        listed[n] = h
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file()} - {"MANIFEST_SHA256.txt", "ADAPTER_IDENTITY.json"}
    check(R, "QS0.01_EXACT_PAYLOAD_SET", actual == set(listed), repr(sorted(actual ^ set(listed))))
    bad = [n for n in listed if sha(ROOT / n) != listed[n]]
    check(R, "QS0.02_MEMBER_HASHES", not bad, ",".join(bad))
    check(R, "QS0.03_NO_PYCACHE", not any(d.name == "__pycache__" for d in ROOT.rglob("*") if d.is_dir()))
    ident = json.loads((ROOT / "ADAPTER_IDENTITY.json").read_text(encoding="utf-8"))
    consts = json.loads((ROOT / "phase_b_constants.json").read_text(encoding="utf-8"))
    check(R, "QS0.04_IDENTITY_BINDING", ident["adapter_identity_sha256"] == sha(man) == ident["manifest_sha256"]
          and ident["constants_sha256"] == sha(ROOT / "phase_b_constants.json")
          and ident["envelope_sha256"] == consts["envelope"]["sha256"] == "FAC9229A19B783745184461384FE97BF0844164ED8ED3F0D99AF55D7398CB3F4")
    check(R, "QS0.05_RELEASE_STAGE_RUN_DISABLED", consts["release_stage"] == "QUALIFICATION_ONLY_RUN_DISABLED"
          and ident["release_stage"] == consts["release_stage"])
    allowed_files = {"phase_b_entry.py", "phase_b_state.py", "phase_b_contract.py", "phase_b_shared.py", "phase_b_effects.py",
                     "phase_b_constants.json", "BOOTSTRAP_PHASE_B_ADAPTER.ps1", "MANIFEST_SHA256.txt", "ADAPTER_IDENTITY.json"}
    outside = sorted(r for r in actual | {"MANIFEST_SHA256.txt", "ADAPTER_IDENTITY.json"}
                     if r not in allowed_files and not r.startswith(("tests/", "qualification/")))
    check(R, "QS0.06_ENVELOPE_ALLOWED_FILES", not outside, ",".join(outside))
    # 2. AST dos módulos de produção
    trees = {f: ast.parse((ROOT / f).read_text(encoding="utf-8"), filename=f) for f in PRODUCTION}
    for f, t in trees.items():
        compile(t, f, "exec")
    check(R, "QS0.07_COMPILE", True)
    top_bad = []
    for f, t in trees.items():
        for n in t.body:
            ok = isinstance(n, (ast.Import, ast.ImportFrom, ast.FunctionDef, ast.ClassDef)) or \
                (isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant)) or \
                (isinstance(n, (ast.Assign, ast.AnnAssign)) and not any(isinstance(x, ast.Call) and attr_chain(x.func) not in ("re.compile", "frozenset", "set", "dict") for x in ast.walk(n))) or \
                (isinstance(n, ast.If) and f == "phase_b_entry.py" and "__name__" in ast.unparse(n.test))
            if not ok:
                top_bad.append(f"{f}:{n.lineno}")
            if isinstance(n, (ast.Import, ast.ImportFrom)):
                names = [a.name.split(".")[0] for a in n.names] if isinstance(n, ast.Import) else [(n.module or "").split(".")[0]]
                if any(x in CODE_MODULE_NAMES for x in names):
                    top_bad.append(f"{f}:{n.lineno}:TOP_LEVEL_CODE_IMPORT")
    check(R, "QS0.08_IMPORT_SAFETY_STATIC", not top_bad, ",".join(top_bad))
    forbidden_imports = {"subprocess", "socket", "urllib", "http", "requests", "ftplib", "smtplib", "ctypes.util"}
    fi = [f"{f}:{n.lineno}" for f, t in trees.items() for n in ast.walk(t)
          if isinstance(n, (ast.Import, ast.ImportFrom)) and any(
              (a.name.split(".")[0] if isinstance(n, ast.Import) else (n.module or "").split(".")[0]) in forbidden_imports for a in n.names)]
    check(R, "QS0.09_NO_PROCESS_OR_NETWORK_IMPORTS", not fi, ",".join(fi))
    # 3. lista fechada de seams: toda atribuição a atributo de objeto congelado
    seam_targets, setattr_calls, destructive, main_refs, phase_calls, direct_full_calls = [], [], [], [], [], []
    for f, t in trees.items():
        for n in ast.walk(t):
            if isinstance(n, (ast.Assign, ast.AugAssign, ast.AnnAssign)):
                tg = n.targets if isinstance(n, ast.Assign) else [n.target]
                for x in tg:
                    if isinstance(x, ast.Attribute):
                        ch = attr_chain(x) or ast.unparse(x)
                        if re.match(r"^(fz|s\.frozen|self\.s\.frozen)\.(base|coord|full|tx|resources|fast_resume|io|fcontract)\.", ch):
                            seam_targets.append(f"{f}:{n.lineno}:{ch}")
                        elif re.match(r"^(minotauro|r1r11)_", ch):
                            seam_targets.append(f"{f}:{n.lineno}:{ch}")
            if isinstance(n, ast.Call):
                fn = attr_chain(n.func) or ""
                if fn in ("setattr", "delattr"):
                    setattr_calls.append(f"{f}:{n.lineno}")
                # Destructive filesystem calls: receiver-aware for .remove().
                # A generic collection method such as set.remove()/list.remove() is not a filesystem mutation.
                destructive_exact = {"os.remove", "os.unlink", "os.rmdir", "os.removedirs", "shutil.rmtree", "os.system"}
                destructive_method = fn.endswith(".unlink") or fn.endswith(".rmdir")
                if fn in destructive_exact or destructive_method:
                    destructive.append(f"{f}:{n.lineno}:{fn}")
                if isinstance(n.func, ast.Call) and attr_chain(n.func.func) == "phase_b_only":
                    target = attr_chain(n.func.args[0]) if n.func.args else None
                    ph = n.args[1] if len(n.args) > 1 else None
                    phase_calls.append((f, n.lineno, target, isinstance(ph, ast.Constant) and ph.value == "B"))
                if re.search(r"\.full\.(prepare_preflight|build_binding|run_phase|finalize_phase)$", fn):
                    direct_full_calls.append(f"{f}:{n.lineno}:{fn}")
            if isinstance(n, ast.Attribute) and n.attr == "main" and (attr_chain(n) or "").endswith("full.main"):
                main_refs.append(f"{f}:{n.lineno}")
            if isinstance(n, ast.Attribute) and n.attr in ("run_phase_a", "finalize_phase_a", "select_2025", "_run_phase_a_multi"):
                main_refs.append(f"{f}:{n.lineno}:{n.attr}")
    expected_seams = {"fz.base._load_d1_extract", "fz.coord.ParallelSession.process_record"}
    seen = {x.split(":", 2)[2] for x in seam_targets}
    check(R, "QS0.10_CLOSED_SEAM_LIST", seen == expected_seams and all(x.startswith("phase_b_shared.py:") for x in seam_targets),
          ";".join(seam_targets))
    check(R, "QS0.11_NO_SETATTR_IN_PRODUCTION", not setattr_calls, ",".join(setattr_calls))
    check(R, "QS0.12_NO_DESTRUCTIVE_CALLS_IN_PRODUCTION", not destructive, ",".join(destructive))
    check(R, "QS0.13_NO_FULL_MAIN_OR_PHASE_A_ENTRYPOINTS", not main_refs, ",".join(main_refs))
    phase_ok = phase_calls and all(p[3] for p in phase_calls) and all(
        (p[2] or "").endswith(("full.prepare_preflight", "full.build_binding", "full.run_phase", "full.finalize_phase")) for p in phase_calls)
    check(R, "QS0.14_FROZEN_PHASE_CALLS_WRAPPED_LITERAL_B", bool(phase_ok) and not direct_full_calls,
          json.dumps([list(p) for p in phase_calls]) + " direct=" + ",".join(direct_full_calls))
    ent = (ROOT / "phase_b_entry.py").read_text(encoding="utf-8")
    check(R, "QS0.15_ENTRY_PRODUCTION_PLATFORM_AND_NO_TEST_KNOBS",
          "WindowsPlatform()" in ent and "FakePlatform" not in ent and "platform_tolerant" not in ent
          and re.search(r"dry_flow\(s\)", ent) is not None)
    prod_src = "\n".join((ROOT / f).read_text(encoding="utf-8") for f in PRODUCTION)
    check(R, "QS0.16_QUALIFICATION_SEAMS_NOT_IMPORTED_BY_PRODUCTION",
          "import phase_b_qualification_seams" not in prod_src and "from phase_b_qualification_seams" not in prod_src)
    check(R, "QS0.17_NO_PHASE_C_LITERAL_CALLS", re.search(r"phase_b_only\([^)]*\)\([^)]*['\"]C['\"]", prod_src) is None)
    # 4. import-safety dinâmico (subprocesso isolado, cwd temporário)
    imp = []
    for f in PRODUCTION:
        mod = f[:-3]
        with tempfile.TemporaryDirectory() as td:
            cwd = Path(td) / "cwd"
            tmp = Path(td) / "tmp"
            cwd.mkdir()
            tmp.mkdir()
            probe = ("import sys,threading,os;sys.path.insert(0,%r);before=set(sys.modules);import %s;"
                     "after=set(sys.modules)-before;code=sorted(m for m in after if m in %r);"
                     "print('THREADS='+str(threading.active_count()));print('CODE_LOADED='+','.join(code));"
                     "print('CWD_FILES='+str(len(os.listdir('.'))))") % (str(ROOT), mod, sorted(CODE_MODULE_NAMES))
            r = subprocess.run([sys.executable, "-B", "-I", "-c", probe], cwd=str(cwd), capture_output=True, text=True,
                               env={"PYTHONDONTWRITEBYTECODE": "1", "PATH": os.environ.get("PATH", ""),
                                    "TEMP": str(tmp), "TMP": str(tmp)})
            ok = (r.returncode == 0 and "THREADS=1" in r.stdout and "CODE_LOADED=\n" in r.stdout + "\n"
                  and "CWD_FILES=0" in r.stdout and r.stdout.count("\n") == 3 and not r.stderr.strip())
            imp.append({"module": mod, "ok": ok, "stdout": r.stdout.strip(), "stderr": r.stderr.strip()[-300:]})
    check(R, "QS0.18_IMPORT_SAFETY_DYNAMIC", all(x["ok"] for x in imp), json.dumps(imp))
    check(R, "QS0.19_NO_PYCACHE_AFTER_IMPORT_PROBES", not any(d.name == "__pycache__" for d in ROOT.rglob("*") if d.is_dir()))
    # 5. PowerShell
    ps = (ROOT / "BOOTSTRAP_PHASE_B_ADAPTER.ps1").read_bytes()
    text = ps[3:].decode("utf-8") if ps.startswith(b"\xef\xbb\xbf") else ps.decode("utf-8", "replace")
    nonascii = any(ord(ch) > 127 for ch in text)
    check(R, "QS0.20_PS_UTF8_BOM_WHEN_NON_ASCII", (not nonascii) or ps.startswith(b"\xef\xbb\xbf"))
    check(R, "QS0.21_PS_CRLF", b"\r\n" in ps and re.search(rb"(?<!\r)\n", ps) is None)
    t26h = ps_function_body(text, "Invoke-T26HistoricalPattern")
    general = re.sub(r"<#.*?#>", "", text.replace(t26h, "") if t26h else text, flags=re.S)
    scan = "\n".join(ln for ln in general.splitlines() if T26H_MARKER not in ln)
    auto_assign = [v for v in PS_AUTOMATIC if re.search(r"(?<![\w:])\$" + re.escape(v) + r"\s*(=|\+=|-=)(?!=)", scan, re.I)]
    param_block = re.search(r"param\s*\((.*?)\n\)", text, re.S | re.I)
    pnames = re.findall(r"\]\s*\$(\w+)", param_block.group(1)) if param_block else []
    collide = [p for p in pnames if p.lower() in {v.lower() for v in PS_AUTOMATIC}]
    foreach_vars = re.findall(r"foreach\s*\(\s*\$(\w+)\s+in", text, re.I)
    fv_collide = [v for v in foreach_vars if v.lower() in {x.lower() for x in PS_AUTOMATIC}]
    check(R, "QS0.22_PS_NO_AUTOMATIC_VARIABLE_ASSIGNMENT_OR_COLLISION", not auto_assign and not collide and not fv_collide,
          f"assign={auto_assign} params={pnames} collide={collide} foreach={fv_collide}")
    forb = [p for p in (r"\$LASTEXITCODE", r"Start-Process", r"Invoke-Expression", r"\biex\b", r"Remove-Item", r"&\s*\{", r"&\s*\$\w+",
                        r"\?\?", r"\s&&\s", r"\s\|\|\s", r"\?\s*\$\w+\s*:", r"\bpython\s+-c\b", r"ArgumentList\.Add")
            if re.search(p, general, re.I)]
    check(R, "QS0.23_PS_FORBIDDEN_CONSTRUCTS_ABSENT_OUTSIDE_T26H", not forb, ",".join(forb))
    exit_seq = re.search(r"\$proc\.WaitForExit\(\)\s*\r?\n\s*\$proc\.Refresh\(\)\s*\r?\n\s*\$result\.ExitCode = \[int\]\$proc\.ExitCode", text) is not None
    check(R, "QS0.24_PS_NATIVE_EXIT_SEQUENCE", exit_seq and "exit $FinalCode" in text.splitlines()[-1] + "\n" + text[-40:])
    check(R, "QS0.25_PS_STAGE_SET_EXCLUDES_QS4_AND_RUN",
          re.search(r"ValidateSet\('QS2_READONLY', 'QS3_DRY'\)", text) is not None and re.search(r"(?<!dry-)run-b", text) is None and "QS4" not in re.sub(r"<#.*?#>", "", text, flags=re.S))
    check(R, "QS0.26_PS_LOG_ABSOLUTE_FIXED_PATH",
          re.search(r"^\$EvidenceBase\s+= 'D:\\MinotauroRuns\\MINOTAURO_PHASE_B_ADAPTER_EVIDENCE'\r?$", text, re.M) is not None
          and "Join-Path $AttemptDir 'BOOTSTRAP.log'" in text and "Join-Path $AttemptDir 'BOOTSTRAP_STATUS.json'" in text)
    check(R, "QS0.27_PS_RESULT_CONTEXT_HEADER_FOOTER", "RESULT_CONTEXT=ChatGPT | " in text and "RESULT_RETURN_TO=ChatGPT | " in text
          and "PROJECT=Pegasus Original | THREAD=Implementacao Runner Paralelo 7" in text)
    check(R, "QS0.28_PS_PYTHON_B_FLAG_AND_ENV", text.count("'-B \"'") >= 3 and "PYTHONDONTWRITEBYTECODE'] = '1'" in text)
    # 6. B04 — identidade por SHA-256 completo (nunca prefixo)
    py_all = {p.relative_to(ROOT).as_posix(): p.read_text(encoding="utf-8") for p in ROOT.rglob("*.py")}
    py_prefix = [f"{n}:{m.group(0)}" for n, src in py_all.items()
                 for m in re.finditer(r"(sha|hash|digest)\w*(\(\))?\[\s*-?\d*\s*:\s*-?\d*\s*\]", src, re.I)]
    ps_prefix = [ln.strip() for ln in text.splitlines() if ".Substring(" in ln and re.search(r"sha|hash", ln, re.I)]
    check(R, "QS0.30_NO_HASH_PREFIX_AS_IDENTITY",
          not py_prefix and not ps_prefix and "$PackageDir = Join-Path $PackageBase $zipSha\r" in text
          and "Substring(0, 16)" not in text, f"py={py_prefix} ps={ps_prefix}")
    # 7. B05 — watchdog finito sem auto-kill; heartbeat canônico; status atômico incremental
    wd = re.search(r"^\$WatchdogSeconds\s+= @\{(.*?)\}\r?$", text, re.M)
    wd_map = dict(re.findall(r"'(\w+)' = (\d+)", wd.group(1))) if wd else {}
    used_wd = set(re.findall(r"\$WatchdogSeconds\['(\w+)'\]", text))
    kill = [p for p in (r"\.Kill\(", r"Stop-Process", r"taskkill", r"TerminateProcess") if re.search(p, text, re.I)]
    check(R, "QS0.31_WATCHDOG_FINITE_NO_AUTOKILL",
          bool(wd_map) and used_wd <= set(wd_map) and all(0 < int(v) <= 86400 for v in wd_map.values()) and not kill
          and "WATCHDOG_EXPIRED label=" in text and "auto_kill=NO child_killed=NO PASS=NO RECONCILIATION_REQUIRED=YES" in text
          and "$script:Unproven = $true" in text, f"wd={wd_map} used={sorted(used_wd)} kill={kill}")
    ps_fields = re.search(r"^\$StatusFields\s+= @\((.*?)\)\r?$", text, re.M)
    ps_fields = re.findall(r"'(\w+)'", ps_fields.group(1)) if ps_fields else []
    hb = re.search(r"^\$HeartbeatMs\s+= (\d+)\r?$", text, re.M)
    eff = (ROOT / "phase_b_effects.py").read_text(encoding="utf-8")
    shared = (ROOT / "phase_b_shared.py").read_text(encoding="utf-8")
    eff_tree = ast.parse(eff)
    py_fields = next((ast.literal_eval(n.value) for n in eff_tree.body if isinstance(n, ast.Assign)
                      and getattr(n.targets[0], "id", "") == "STATUS_FIELDS"), ())
    py_cad = re.search(r"^STATUS_CADENCE_SECONDS = (\d+)$", shared, re.M)
    check(R, "QS0.32_HEARTBEAT_CANONICAL_FIELDS_CADENCE_ATOMIC_STATUS",
          ps_fields == CANON_FIELDS and list(py_fields) == CANON_FIELDS and hb is not None and 30000 <= int(hb.group(1)) <= 60000
          and py_cad is not None and 30 <= int(py_cad.group(1)) <= 60
          and "os.replace(tmp, path)" in eff and "def write_status_atomic" in eff
          and "[System.IO.FileOptions]::WriteThrough" in text and "[System.IO.File]::Replace($tmp, $Path, [NullString]::Value)" in text
          and text.count("Set-BootstrapStatus ") >= 4 and "Write-Heartbeat $Label" in text
          and "self.status()" in shared and "s.status(progress=done" in shared,
          f"ps={ps_fields} py={list(py_fields)} hb={hb.group(1) if hb else None} cad={py_cad.group(1) if py_cad else None}")
    # 8. B02 — receipt verificado antes de PASS (adapter e bootstrap)
    fin = shared[shared.index("def finish("):]
    adapter_calls = re.findall(r"Invoke-Child \$PythonExe \('-B \"' \+ \$entryPy \+ '\" (classify-b|dry-run-b)", text)
    check(R, "QS0.33_RECEIPT_PHYSICALLY_VERIFIED_BEFORE_PASS",
          "verify_receipt_on_disk(" in fin and "downgrade_for_missing_receipt(" in fin
          and "def downgrade_for_missing_receipt" in eff and sorted(adapter_calls) == ["classify-b", "dry-run-b"]
          and text.count("Test-ChildReceipt (Join-Path") == 4 and text.count("Resolve-ChildOutcome $c") == 4
          and "$FinalCode = Get-StageExit $Items $RequiredItems[$Stage]" in text, f"adapter_calls={adapter_calls}")
    # 9. B06 — exit nativo preservado + SHA-256 do stderr quando o receipt downstream falta
    check(R, "QS0.34_DOWNSTREAM_NATIVE_EXIT_AND_STDERR_SHA256",
          "$psi.RedirectStandardError = $true" in text and "$proc.StandardError.BaseStream.CopyToAsync($errBuffer)" in text
          and "if ($errTask.Wait($StderrDrainMs))" in text and "[System.IO.File]::WriteAllBytes($stderrPath, $errBytes)" in text
          and "ReadToEnd" not in general.replace("$sr.ReadToEnd()", "") and "INCOMPLETE_PIPE_HELD_BY_DESCENDANT" in text
          and "MISSING_DOWNSTREAM_RESULT label=' + $Label + ' native_exit=' + $Child.ExitCode + ' stderr_sha256=' + $Child.StderrSha256" in text
          and "_NATIVE_EXIT_PRESERVED" in text and "RedirectStandardOutput" not in text)
    # 10. B03 — QS2 aderente ao envelope (Q01..Q08 + T26 + T31a)
    req = re.search(r"'QS2_READONLY' = @\((.*?)\)", text)
    req = set(re.findall(r"'(\w+)'", req.group(1))) if req else set()
    env_qs2 = {"Q01", "Q02", "Q03", "Q04", "Q05", "Q06_partial", "Q07", "Q08", "T26", "T31a"}
    req3 = re.search(r"'QS3_DRY' = @\((.*?)\)", text)
    req3 = set(re.findall(r"'(\w+)'", req3.group(1))) if req3 else set()
    env_qs3 = {"T02", "T11c", "T14", "T19_template", "T23", "T27", "T30"}
    probe_ps = ROOT / "qualification" / "probe_exit_ps.ps1"
    probe_ps_text = probe_ps.read_bytes().decode("ascii") if probe_ps.is_file() else ""
    check(R, "QS0.35_QS2_ITEMS_MATCH_ENVELOPE",
          env_qs2 <= req and "foreach ($want in @(0, 2, 3, 7, 130))" in text and text.count("foreach ($want in @(0, 2, 3, 7, 130))") == 2
          and (ROOT / "qualification" / "qs2_target_probe.py").is_file() and probe_ps.is_file()
          and "$LASTEXITCODE" not in probe_ps_text and "Start-Process" not in probe_ps_text
          and "exit $inner" in probe_ps_text and "qs2_physical" in shared
          and env_qs3 <= req3 and "function Get-DryItems" in text and "$dItems = Get-DryItems" in text
          and "'SUBSTANTIVE_TO_BND'" in ps_function_body(text, "Get-DryItems"),
          f"required={sorted(req)} qs3={sorted(req3)}")
    # 11. T26-H — sentinela -999 confinada à reprodução histórica e nunca usada como exit
    marked = [ln for ln in text.splitlines() if T26H_MARKER in ln]
    check(R, "QS0.36_T26_HISTORICAL_SENTINEL_CONFINED",
          bool(t26h) and len(marked) >= 2 and all(ln in t26h for ln in marked)
          and all(("LASTEXITCODE" in ln or "& {" in ln or "& $PythonExe" in ln) for ln in marked)
          and "$LASTEXITCODE = -999" in marked[1] and "$sentinelProcess = & {" in t26h and "$sentinelNative = & {" in t26h
          and "$null = & $PythonExe -B $Probe 7q" in t26h and "$global:LASTEXITCODE" in t26h
          and "classification = 'INVALID_MEASUREMENT'" in t26h and "used_as_exit = 'NO'" in t26h
          and not re.search(r"\$FinalCode\s*=.*(sentinel|historical|LASTEXITCODE)", text, re.I)
          and "$script:T26HistoricalChild = Invoke-Child" in t26h, f"marked={len(marked)}")
    # 12. revisão independente: extração/reuso do pacote, interrupção, companion, vereditos Q, vida do status
    exp = ps_function_body(text, "Expand-AdapterPackage")
    check(R, "QS0.39_PACKAGE_STAGING_ATOMIC_AND_REUSE_VERIFIED",
          "$staging = $TargetDir + '.extract.' + $Nonce" in exp and "[System.IO.Directory]::Move($staging, $TargetDir)" in exp
          and "PACKAGE_DIR_NE_ZIP" in exp and "$zipFiles = Expand-AdapterPackage $PackageZip $PackageDir" in text)
    fin_ps = text[text.rindex("\nfinally {"):]
    check(R, "QS0.40_BOOTSTRAP_INTERRUPTION_EXIT_COHERENT",
          "$script:MainCompleted = $true" in text and text.count("$script:MainCompleted = $true") == 2
          and "if (-not $script:MainCompleted) { [Environment]::Exit($FinalCode) }" in fin_ps and "BOOTSTRAP_INTERRUPTED=YES" in fin_ps)
    contract = (ROOT / "phase_b_contract.py").read_text(encoding="utf-8")
    check(R, "QS0.41_RECEIPT_VERIFIED_COMPANION",
          "verified_companion(rsha" in fin and "DRY_RECEIPT_NOT_VERIFIED" in contract
          and "RECEIPT_NOT_VERIFIED_BY_ADAPTER" in text and "RECEIPT_COMPANION_MISMATCH" in text)
    check(R, "QS0.42_QS2_ITEMS_BY_SUBSTANTIVE_VERDICT",
          "def qs2_verdicts" in shared and "qs2_physical_with_verdicts" in shared
          and "$v = Get-JsonProp $sec 'verdict'" in ps_function_body(text, "Get-QItems") and "$present" not in text)
    check(R, "QS0.43_ADAPTER_STATUS_TIME_CADENCE_THREAD",
          "self.start_heartbeat()" in shared and "s.stop_heartbeat()" in fin and "daemon=True" in shared
          and "def start_heartbeat" in shared)
    # 13. B07 — QS3 exige QS2 PASS anterior físico, absoluto e vinculado, antes de qualquer trabalho substantivo
    pq = ps_function_body(text, "Test-PriorQS2Receipt")
    main_ps = text[text.index("# ============================================================================ execução"):]
    i_prior = main_ps.find("$prior = Test-PriorQS2Receipt $PriorQS2Receipt $PriorQS2ReceiptSha256 $AdapterIdentity $zipSha")
    i_t26 = main_ps.find("$t26 = Invoke-T26Probes $probe $AdapterDir")
    i_dry = main_ps.find("dry-run-b --attempt-id")
    reasons = ["PRIOR_QS2_RECEIPT_PATH_NOT_ABSOLUTE", "PRIOR_QS2_RECEIPT_MISSING", "PRIOR_QS2_RECEIPT_SHA_MISMATCH",
               "PRIOR_QS2_SCHEMA_OR_STAGE", "PRIOR_QS2_FINAL_EXIT_NOT_ZERO", "PRIOR_QS2_NOT_CLEAN", "PRIOR_QS2_RECEIPT_LOCATION",
               "PRIOR_QS2_OTHER_ADAPTER", "PRIOR_QS2_OTHER_ZIP", "PRIOR_QS2_ITEM_MISSING", "PRIOR_QS2_ITEM_NOT_PASS",
               "PRIOR_QS2_BINDING", "PRIOR_QS2_COMPANION_MISSING", "PRIOR_QS2_LOG_BINDING",
               "'PRIOR_QS2_CHILD_CONTENT:CLASSIFY_B:'", "'PRIOR_QS2_CHILD_CONTENT:T31a:'", "'PRIOR_QS2_CHILD_CONTENT:Q07:'",
               "'PRIOR_QS2_CHILD_CONTENT:' + $q", "PRIOR_QS2_LOG_FINAL_EXIT", "PRIOR_QS2_FINAL_STATUS"]
    i_pre = main_ps.find("$prior0 = Test-PriorQS2Receipt $PriorQS2Receipt $PriorQS2ReceiptSha256 '' $zipSha")
    i_exp = main_ps.find("$zipFiles = Expand-AdapterPackage $PackageZip $PackageDir")
    check(R, "QS0.44_B07_QS3_REQUIRES_PROVEN_PRIOR_QS2",
          "[string]$PriorQS2Receipt = ''" in text and "[string]$PriorQS2ReceiptSha256 = ''" in text
          and "throw 'B07_QS3_REQUIRES_PRIOR_QS2_RECEIPT_AND_SHA256'" in main_ps
          and all(x in pq for x in reasons) and "foreach ($q in $RequiredItems['QS2_READONLY'])" in pq
          and "'QS3_DRY' = @('PRIOR_QS2'," in text
          and 0 <= i_pre < i_exp < i_prior < i_t26 < i_dry
          and "throw ('B07_PRIOR_QS2_NOT_PROVEN ' + $prior0.reason)" in main_ps[i_pre:i_exp]
          and "if (-not $prior.valid) { throw ('B07_PRIOR_QS2_NOT_PROVEN ' + $prior.reason) }" in main_ps[i_prior:i_t26]
          and "$Facts['prior_qs2_receipt_sha256'] = $prior.sha256" in main_ps
          and "'.VERIFIED.json'" in ps_function_body(text, "Write-StageReceipt"),
          f"order pre={i_pre} extract={i_exp} prior={i_prior} t26={i_t26} dry={i_dry}")
    # 14. B08 — status obrigatório não persistido nunca preserva 0/130 (adapter e bootstrap)
    i_sf = fin.find("    if s.status_failures:")
    i_fs = fin.find("status_ok, status_sha = s.final_status(")
    i_rc = fin.find("rsha = s.write_evidence(name, rec)")
    fin_boot = text[text.rindex("\nfinally {"):]
    i_r1 = fin_boot.find("$FinalCode = Resolve-FinalExit $FinalCode $script:StatusWriteFailures $true")
    i_st = fin_boot.find("$script:FinalStatusWritten = Set-BootstrapStatus $ff")
    i_r2 = fin_boot.find("$FinalCode = Resolve-FinalExit $FinalCode $script:StatusWriteFailures $script:FinalStatusWritten")
    i_sr = fin_boot.find("$stageSha = Write-StageReceipt $StageReceiptPath $rec")
    check(R, "QS0.45_B08_STATUS_PERSISTENCE_NEVER_PASS",
          0 <= i_sf < i_fs < i_rc and 'downgrade("STATUS")' in fin[i_sf:i_rc]
          and 'rec["status_final_persisted"] = status_ok' in fin and 'rec["status_final_sha256"] = status_sha' in fin
          and "def final_status" in shared and 'doc["fields"]["ACTIVE"] == "NO"' in shared
          and 0 <= i_r1 < i_st < i_r2 < i_sr
          and "throw 'STATUS_READBACK_MISMATCH'" in ps_function_body(text, "Set-BootstrapStatus")
          and "RECEIPT_STATUS_NOT_PERSISTED" in ps_function_body(text, "Test-ChildReceipt")
          and "RECEIPT_STATUS_FINAL_MISMATCH" in ps_function_body(text, "Test-ChildReceipt")
          and "if ($FinalCode -eq 0 -or $FinalCode -eq 130) {" in fin_boot[i_sr:]
          and "$rec['final_status_sha256']" in fin_boot,
          f"adapter={i_sf},{i_fs},{i_rc} boot={i_r1},{i_st},{i_r2},{i_sr}")
    # 15. C2 GROWTH BOUND CURRENT LIVE POLICY REBIND (2026-10-08).
    # The FIXABC R3 FIX-B projected-code/runner-hash rebind legitimately changes a derived non-authority prepared pin.
    # Therefore this gate pins the complete FIXABC R3 post-FIX-B non-authority baseline, while allowing only
    # the authority/currentness block to rebind to the physically validated live policy pair.
    rb_p = ROOT / "qualification" / "POLICY_LIVE_REBIND_20261008_V30.json"
    rb = json.loads(rb_p.read_text(encoding="utf-8")) if rb_p.is_file() else {}
    au = consts.get("authority", {})
    lr = au.get("live_rebind", {})
    non_auth = hashlib.sha256(json.dumps({k: v for k, v in consts.items() if k != "authority"}, sort_keys=True,
                                         ensure_ascii=False, separators=(",", ":")).encode()).hexdigest().upper()
    check(R, "QS0.46_C2_GROWTH_BOUND_LIVE_POLICY_20261008_V30",
          au.get("snapshot_master_sha256") == rb.get("master_sha256") == "011CFB0CDD39E3B2ECC104A7B967330D2B29D84EA2A506E74A3ABB2B8D231FA2"
          and au.get("snapshot_head_sha256") == rb.get("head_sha256") == "8DDDF99F206848471A6A27A9E37637CC51CAD8378C482C3CA3F7C3322A68A1C5"
          and au.get("snapshot_revision_id") == rb.get("revision_id") == "20261008T132913-0300-011CFB0CDD39E3B2"
          and rb.get("cardinality") == "1+1" and rb.get("state") == "FROZEN"
          and lr.get("record") == "qualification/POLICY_LIVE_REBIND_20261008_V30.json"
          and lr.get("record_sha256") == (sha(rb_p) if rb_p.is_file() else None)
          and lr.get("previous_master_sha256") == "2B7F681F176009ACA5F5F280B132EA792069027F0DE44A80EF442434C3788DF4"
          and lr.get("previous_head_sha256") == "0DB5BEA132E6F423F3B748E73CB94B81C588E308C911D4A573952A3DEFC22A03"
          and lr.get("previous_revision_id") == "20261007T204116-0300-2B7F681F176009AC"
          and rb.get("non_authority_canonical_sha256") == "4913A72D501160D683CD78DF3948AAA17A4D935F9AF0131542D95C87FD3BE30A"
          and au.get("run_requires_live_recheck_receipt") is True
          and non_auth == "F5AEFCF39C69DA544E0ED0F81311BCF3DD5B24E62EF21B39F415C0FCFDAC01D5"
          and (ROOT / "qualification/E01_G3_PROVENANCE_BRIDGE_V001.json").is_file()
          and sha(ROOT / "qualification/E01_G3_PROVENANCE_BRIDGE_V001.json") == "0682DD5445545593E3FAD3C60A37252816A5A8B06A049BE5F1B682CC332B732D"
          and consts.get("free_space", {}).get("run_growth_bytes") == 1900518140
          and consts.get("release_stage") == "QUALIFICATION_ONLY_RUN_DISABLED",
          f"non_authority_canonical={non_auth}")
    ps_files = ["BOOTSTRAP_PHASE_B_ADAPTER.ps1", "qualification/probe_exit_ps.ps1", "tests/bootstrap_harness.ps1"]
    ascii_ok = all(not any(b > 127 for b in (ROOT / f).read_bytes()) for f in ps_files[1:])
    check(R, "QS0.37_AUX_PS_ASCII_CRLF", ascii_ok and all(re.search(rb"(?<!\r)\n", (ROOT / f).read_bytes()) is None for f in ps_files[1:]))
    if pwsh:
        envp = dict(os.environ, DOTNET_SYSTEM_GLOBALIZATION_INVARIANT="1")
        ver = subprocess.run([pwsh, "-NoProfile", "-Command", "$PSVersionTable.PSVersion.ToString()"], capture_output=True,
                             text=True, env=envp).stdout.strip()
        outs, ok_all = [], True
        for f in ps_files:
            cmd = ("$e=$null;$t=$null;[void][System.Management.Automation.Language.Parser]::ParseFile('%s',[ref]$t,[ref]$e);"
                   "if($e.Count -gt 0){$e|%%{Write-Output ('PARSE_ERROR '+$_.Message)};exit 3};Write-Output 'PARSE=PASS'") % str(ROOT / f)
            r = subprocess.run([pwsh, "-NoProfile", "-NonInteractive", "-Command", cmd], capture_output=True, text=True, env=envp)
            ok = r.returncode == 0 and "PARSE=PASS" in r.stdout
            ok_all = ok_all and ok
            outs.append(f"{f}:{'PASS' if ok else (r.stdout + r.stderr)[-300:]}")
        check(R, "QS0.29_PS_PARSE_PWSH_" + ver.replace(".", "_"), ok_all,
              "; ".join(outs) + " NOTE: alvo é Windows PowerShell 5.1; parse 5.1 fica para QS2")
    else:
        check(R, "QS0.29_PS_PARSE", False, "pwsh indisponível na sandbox")
    tree_after = tree_digest(ROOT)
    check(R, "QS0.38_ADAPTER_TREE_UNCHANGED_BY_QS0", tree_before == tree_after, f"{tree_before} -> {tree_after}")
    rec = {"schema": "MINOTAURO_PHASE_B_ADAPTER_QS0_RECEIPT_V001", "adapter_identity_sha256": ident["adapter_identity_sha256"],
           "adapter_identity_recomputed_manifest_sha256": sha(man),
           "adapter_tree_digest_before": {"sha256": tree_before[0], "files": tree_before[1]},
           "adapter_tree_digest_after": {"sha256": tree_after[0], "files": tree_after[1]},
           "adapter_tree_unchanged": tree_before == tree_after,
           "pwsh": pwsh, "python": sys.version.split()[0],
           "checks": R, "passed": sum(1 for x in R if x["result"] == "PASS"), "total": len(R),
           "result": "PASS" if all(x["result"] == "PASS" for x in R) else "FAIL"}
    out.write_text(json.dumps(rec, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    for x in R:
        print(f"{x['check']}={x['result']}" + ("" if x["result"] == "PASS" else " " + x["detail"][:300]))
    print("QS0_RESULT=" + rec["result"], f"{rec['passed']}/{rec['total']}")
    return 0 if rec["result"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
