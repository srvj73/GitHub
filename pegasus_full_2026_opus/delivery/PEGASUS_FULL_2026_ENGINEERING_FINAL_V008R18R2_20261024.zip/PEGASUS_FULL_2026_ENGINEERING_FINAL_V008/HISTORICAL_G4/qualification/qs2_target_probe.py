"""PHASE_B_ADAPTER_V001 — sondas QS2 no alvo (T31a e Q07). Somente via BOOTSTRAP_PHASE_B_ADAPTER.ps1.

Uso (python -B, PYTHONDONTWRITEBYTECODE=1):
  qs2_target_probe.py t31a        --attempt-id <ID>
  qs2_target_probe.py t31a-second --attempt-id <ID> --expect BLOCKED|FREE
  qs2_target_probe.py q07         --attempt-id <ID> --policy-receipt <arquivo>

Efeitos: escreve SOMENTE em <evidence_base>/<ID>/QS2/ (raiz owned). CONTROL, PREFLIGHT, CODE e entradas
são apenas lidos; o CODE congelado só é importado após gate_g06_code (verificação byte a byte) e sem bytecode.

T31a (PRE_RECOVER_B, envelope G21): numa raiz owned vazia,
  (1) o adapter obtém o mutex nominal R1R11 (mesma fórmula de r1r11_resources.RunLock.__enter__);
  (2) um 2º processo é recusado (adapter e RunLock congelado);
  (3) o RunLock congelado, na MESMA thread, entra (reentrância Win32) e sai removendo RUN.lock;
  (4) após a saída do RunLock o adapter ainda detém o mutex (2º processo continua recusado);
  (5) após a liberação pelo adapter, um 2º processo obtém o RunLock congelado (sem vazamento de posse).
Exit: 0 PASS; 2 BLOCKED (sem efeito protegido). Em não-Windows: BLOCKED WINDOWS_REQUIRED (fail-closed).
"""
from __future__ import annotations

import hashlib
import inspect
import os
import subprocess
import sys
import traceback
from pathlib import Path

ADAPTER = Path(__file__).resolve().parents[1]
if str(ADAPTER) not in sys.path:
    sys.path.insert(0, str(ADAPTER))

from phase_b_contract import ATTEMPT_RE, load_constants, policy_receipt_validate  # noqa: E402
from phase_b_effects import (AdapterBlocked, inventory, inventory_digest, sha256_file,  # noqa: E402
                             write_json_durable)
from phase_b_shared import (Layout, Session, WindowsPlatform, _path_inside, gate_g02_bytecode,  # noqa: E402
                            gate_g06_code, r1r11_mutex_name)

SECOND_TIMEOUT_S = 300  # 4 chamadas <= 1200 s < watchdog T31A do bootstrap (1800 s); expiração NÃO mata o filho
FROZEN_FORMULA = "'Global\\\\MinotauroR1R11_' + hashlib.sha256(str(self.root).casefold().encode()).hexdigest()"


def _print(k, v):
    sys.stdout.write(f"{k}={v}\n")
    sys.stdout.flush()


def _args(argv):
    out, i = {}, 0
    while i < len(argv):
        if not argv[i].startswith("--") or i + 1 >= len(argv) or argv[i] in out:
            raise AdapterBlocked("QS2_PROBE_ARGV", " ".join(argv))
        out[argv[i]] = argv[i + 1]
        i += 2
    return out


def _context(attempt_id: str):
    if not ATTEMPT_RE.match(attempt_id or ""):
        raise AdapterBlocked("ATTEMPT_ID_INVALID", str(attempt_id))
    constants = load_constants(ADAPTER / "phase_b_constants.json")
    layout = Layout.production(constants, ADAPTER)
    qs2 = Path(layout.evidence_base) / attempt_id / "QS2"
    for forbidden in (layout.release_root, layout.base_csv_root):
        if _path_inside(qs2, forbidden):
            raise AdapterBlocked("QS2_EVIDENCE_FORBIDDEN_LOCATION", str(qs2))
    return constants, layout, qs2


def _frozen(constants, layout, attempt_id):
    gate_g02_bytecode()
    s = Session(mode="CLASSIFY", layout=layout, constants=constants, platform=WindowsPlatform(), attempt_id=attempt_id)
    gate_g06_code(s)
    return s


def _second(attempt_id: str, expect: str) -> dict:
    cmd = [sys.executable, "-B", str(Path(__file__).resolve()), "t31a-second", "--attempt-id", attempt_id,
           "--expect", expect]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    try:
        out_b, err_b = proc.communicate(timeout=SECOND_TIMEOUT_S)
    except subprocess.TimeoutExpired:
        # sem auto-kill: o filho permanece; o T31a falha e exige reconciliação
        return {"expect": expect, "native_exit": None, "pid": proc.pid, "timed_out": True, "auto_kill": "NO",
                "reconciliation_required": "YES", "matched": False}
    out, err = out_b.decode("utf-8", "replace"), err_b.decode("utf-8", "replace")
    label = [ln for ln in out.splitlines() if ln.startswith("T31A_SECOND=")]
    return {"expect": expect, "native_exit": proc.returncode, "label": label[-1] if label else None,
            "stdout_tail": out[-1500:], "stderr_sha256": hashlib.sha256(err_b).hexdigest().upper(),
            "stderr_tail": err[-1500:], "timed_out": False, "matched": proc.returncode == 0}


def cmd_t31a_second(attempt_id: str, expect: str) -> int:
    """2º processo: tenta o mutex do adapter e o RunLock congelado na raiz owned."""
    constants, layout, qs2 = _context(attempt_id)
    root = qs2 / "T31A_OWNED_ROOT"
    s = _frozen(constants, layout, attempt_id)
    plat = WindowsPlatform()
    if expect == "BLOCKED":
        adapter_blocked = False
        try:
            h = plat.acquire_named_mutex(r1r11_mutex_name(root))
            plat.release_named_mutex(h)
        except AdapterBlocked as e:
            adapter_blocked = e.code == "MUTEX_ACTIVE_OR_UNAVAILABLE"
        frozen_code = None
        try:
            lk = s.frozen.resources.RunLock(root)
            lk.__enter__()
            lk.__exit__(None, None, None)
            frozen_code = "ENTERED"
        except Exception as e:  # noqa: BLE001 - ModelError congelado
            frozen_code = str(e)
        ok = adapter_blocked and frozen_code == "RUN_MUTEX_ACTIVE_OR_UNAVAILABLE"
        _print("T31A_SECOND", f"BLOCKED adapter={'MUTEX_ACTIVE_OR_UNAVAILABLE' if adapter_blocked else 'ACQUIRED'} "
                              f"frozen={frozen_code}")
        return 0 if ok else 4
    if expect == "FREE":
        try:
            with s.frozen.resources.RunLock(root) as lk:
                held = lk.mutex is not None
            _print("T31A_SECOND", f"ACQUIRED frozen_runlock=YES mutex_held={'YES' if held else 'NO'}")
            return 0 if held else 4
        except Exception as e:  # noqa: BLE001
            _print("T31A_SECOND", f"NOT_ACQUIRED frozen={e}")
            return 4
    raise AdapterBlocked("QS2_PROBE_ARGV", expect)


def cmd_t31a(attempt_id: str) -> int:
    constants, layout, qs2 = _context(attempt_id)
    qs2.mkdir(parents=True, exist_ok=True)
    out_p = qs2 / "T31A_RECEIPT.json"
    rec = {"schema": "MINOTAURO_PHASE_B_ADAPTER_QS2_T31A_RECEIPT_V001", "attempt_id": attempt_id, "result": "BLOCKED",
           "steps": [], "error": None}
    plat = WindowsPlatform()
    h = None
    try:
        root = qs2 / "T31A_OWNED_ROOT"
        root.mkdir(parents=False, exist_ok=False)
        rec["owned_root"] = str(root)
        s = _frozen(constants, layout, attempt_id)
        code_before = inventory_digest(inventory(layout.code_root))
        name = r1r11_mutex_name(root)
        frozen_name = "Global\\MinotauroR1R11_" + hashlib.sha256(str(Path(root).resolve()).casefold().encode()).hexdigest()
        src = inspect.getsource(s.frozen.resources.RunLock.__enter__)
        rec.update(mutex_name=name, formula_equal=name == frozen_name, frozen_source_formula_present=FROZEN_FORMULA in src)
        if not (rec["formula_equal"] and rec["frozen_source_formula_present"]):
            raise AdapterBlocked("T31A_MUTEX_FORMULA_MISMATCH")
        h = plat.acquire_named_mutex(name)
        rec["steps"].append(dict(step="1_adapter_holds_second_process_refused", **_second(attempt_id, "BLOCKED")))
        with s.frozen.resources.RunLock(root) as lk:
            rec["reentrant_same_thread"] = lk.mutex is not None and (root / "RUN.lock").is_file()
            rec["steps"].append(dict(step="2_frozen_runlock_inside_second_process_refused", **_second(attempt_id, "BLOCKED")))
        rec["run_lock_removed_on_exit"] = not (root / "RUN.lock").exists()
        rec["steps"].append(dict(step="3_after_runlock_exit_adapter_still_owns", **_second(attempt_id, "BLOCKED")))
        plat.release_named_mutex(h)
        h = None
        rec["steps"].append(dict(step="4_after_adapter_release_second_process_acquires", **_second(attempt_id, "FREE")))
        code_after = inventory_digest(inventory(layout.code_root))
        rec.update(code_digest_before=code_before, code_digest_after=code_after, code_unchanged=code_before == code_after,
                   owned_root_after=sorted(p.name for p in root.iterdir()))
        ok = (rec["reentrant_same_thread"] and rec["run_lock_removed_on_exit"] and rec["code_unchanged"]
              and all(x["matched"] for x in rec["steps"]) and rec["owned_root_after"] == [])
        rec["result"] = "PASS" if ok else "BLOCKED"
        if not ok:
            rec["error"] = {"code": "T31A_EXPECTATION_NOT_MET"}
    except AdapterBlocked as e:
        rec["error"] = {"code": e.code, "detail": e.detail[:1000]}
    except Exception as e:  # noqa: BLE001
        rec["error"] = {"code": type(e).__name__, "detail": str(e)[:1000], "traceback": traceback.format_exc()[-4000:]}
    finally:
        if h is not None:
            try:
                plat.release_named_mutex(h)
            except AdapterBlocked:
                rec["mutex_release"] = "FAILED"
    # processo-filho deixado vivo após timeout (sem kill) => estado não provado: exit 3 + reconciliação
    left_alive = [x.get("pid") for x in rec["steps"] if x.get("timed_out")]
    if left_alive:
        rec["result"] = "BLOCKED"
        rec["reconciliation_required"] = "YES"
        rec["second_process_left_alive_pids"] = left_alive
    rec["exit_code"] = 0 if rec["result"] == "PASS" else (3 if left_alive else 2)
    sha = write_json_durable(out_p, rec, exclusive=True)
    _print("T31A", rec["result"])
    _print("T31A_RECEIPT", f"{out_p} sha256={sha}")
    if rec["error"]:
        _print("T31A_ERROR", rec["error"]["code"])
    return rec["exit_code"]


def cmd_q07(attempt_id: str, receipt: str) -> int:
    constants, layout, qs2 = _context(attempt_id)
    qs2.mkdir(parents=True, exist_ok=True)
    out_p = qs2 / "Q07_RECEIPT.json"
    rec = {"schema": "MINOTAURO_PHASE_B_ADAPTER_QS2_Q07_RECEIPT_V001", "attempt_id": attempt_id,
           "policy_receipt_path": str(receipt), "expected_master_sha256": constants["authority"]["snapshot_master_sha256"],
           "expected_head_sha256": constants["authority"]["snapshot_head_sha256"], "result": "BLOCKED", "error": None}
    try:
        p = Path(receipt)
        if not p.is_file():
            raise AdapterBlocked("LIVE_POLICY_RECEIPT_MISSING", str(p))
        rec["policy_receipt_sha256"] = sha256_file(p)
        rec["validated"] = policy_receipt_validate(p, constants)
        rec["result"] = "PASS"
    except AdapterBlocked as e:
        rec["error"] = {"code": e.code, "detail": e.detail[:1000]}
    rec["exit_code"] = 0 if rec["result"] == "PASS" else 2
    sha = write_json_durable(out_p, rec, exclusive=True)
    _print("Q07", rec["result"])
    _print("Q07_RECEIPT", f"{out_p} sha256={sha}")
    return rec["exit_code"]


def main(argv) -> int:
    _print("QS2_PROBE", "PHASE_B_ADAPTER_V001")
    try:
        if not argv:
            raise AdapterBlocked("QS2_PROBE_ARGV")
        cmd, a = argv[0], _args(argv[1:])
        if cmd == "t31a" and set(a) == {"--attempt-id"}:
            return cmd_t31a(a["--attempt-id"])
        if cmd == "t31a-second" and set(a) == {"--attempt-id", "--expect"}:
            return cmd_t31a_second(a["--attempt-id"], a["--expect"])
        if cmd == "q07" and set(a) == {"--attempt-id", "--policy-receipt"}:
            return cmd_q07(a["--attempt-id"], a["--policy-receipt"])
        raise AdapterBlocked("QS2_PROBE_ARGV", " ".join(argv))
    except AdapterBlocked as e:
        _print("QS2_PROBE_BLOCKED", e.code)
        return 2


if __name__ == "__main__":
    rc = main(sys.argv[1:])
    _print("QS2_PROBE_EXIT", rc)
    sys.exit(rc)
