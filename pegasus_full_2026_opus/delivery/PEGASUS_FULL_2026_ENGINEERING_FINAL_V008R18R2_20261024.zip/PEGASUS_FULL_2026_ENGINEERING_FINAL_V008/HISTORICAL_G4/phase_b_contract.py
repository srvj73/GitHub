"""PHASE_B_ADAPTER_V001 — contratos puros (D1-B, configuração, PREFLIGHT, entradas,
rehash de ticks, FINAL, receipts). Somente leitura. Sem import do CODE no topo.
"""
from __future__ import annotations

import csv
import io
import re
from pathlib import Path

from phase_b_effects import (AdapterBlocked, canonical_hash, inventory, load_json_strict,
                             sha256_bytes, sha256_file)

DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
ATTEMPT_RE = re.compile(r"^\d{8}T\d{6}Z_[0-9a-f]{8}$")


# --------------------------------------------------------------------------- constants
def load_constants(path) -> dict:
    data = Path(path).read_bytes()
    c = load_json_strict(data)
    if c.get("schema") != "MINOTAURO_PHASE_B_ADAPTER_CONSTANTS_V001" or c.get("scope") != "PHASE_B_2026_ONLY":
        raise AdapterBlocked("CONSTANTS_SCHEMA_OR_SCOPE")
    if len(c.get("prepared_21", [])) != 21 or len(c["control_prepared"]["files"]) != 23:
        raise AdapterBlocked("CONSTANTS_PREPARED_CARDINALITY")
    c["_sha256"] = sha256_bytes(data)
    return c


def pinned_files(entries) -> dict:
    return {e["path"]: {"bytes": int(e["bytes"]), "sha256": str(e["sha256"]).upper()} for e in entries}


# --------------------------------------------------------------------------- csv helpers
def rows_from_bytes(data: bytes) -> list[dict]:
    """Mesma leitura de minotauro_v004_runner.cal (utf-8-sig, ';')."""
    return list(csv.DictReader(io.StringIO(data.decode("utf-8-sig"), newline=""), delimiter=";"))


def render_d1_extract(columns, calendar_rows, bars) -> bytes:
    """Reprodução em memória de build_binding + write_csv (LF, sem BOM)."""
    buf = io.StringIO(newline="")
    w = csv.DictWriter(buf, fieldnames=list(columns), delimiter=";", lineterminator="\n")
    w.writeheader()
    for r in calendar_rows:
        prev = r["expected_previous_session_date"]
        if prev not in bars:
            raise AdapterBlocked("D1B_PREDECESSOR_INVALID", f"{r['session_date']} prev={prev} absent_in_IND")
        b = bars[prev]
        w.writerow({"session_date": r["session_date"], "expected_previous_session_date": prev,
                    "open_micro": int(b.open_micro), "high_micro": int(b.high_micro),
                    "low_micro": int(b.low_micro), "close_micro": int(b.close_micro)})
    return buf.getvalue().encode("utf-8")


# --------------------------------------------------------------------------- D1-B (§5.4)
def d1b_validate(extract_bytes: bytes, calendar_rows: list[dict], expected_rows: list[dict], bars,
                 constants: dict, *, extract_sha_expected: str | None = None,
                 binding: dict | None = None, ind_sha: str | None = None) -> dict:
    cols = constants["d1b"]["columns"]
    n_literal = int(constants["sessions"]["expected"])
    lo, hi = constants["sessions"]["range"]
    # 1. bytes / schema
    if extract_bytes.startswith(b"\xef\xbb\xbf"):
        raise AdapterBlocked("D1B_SCHEMA", "BOM")
    if b"\r" in extract_bytes:
        raise AdapterBlocked("D1B_SCHEMA", "CR")
    header = extract_bytes.split(b"\n", 1)[0].decode("utf-8", "replace")
    if header != ";".join(cols):
        raise AdapterBlocked("D1B_SCHEMA", "HEADER")
    rows = rows_from_bytes(extract_bytes)
    for r in rows:
        if None in r or any(r.get(k) is None for k in cols) or len(r) != len(cols):
            raise AdapterBlocked("D1B_SCHEMA", "FIELD_COUNT " + str(r.get("session_date")))
        for k in cols[2:]:
            if not r[k].isdigit():
                raise AdapterBlocked("D1B_SCHEMA", f"INT {k} {r['session_date']}")
        for k in cols[:2]:
            if not DATE_RE.match(r[k] or ""):
                raise AdapterBlocked("D1B_SCHEMA", f"DATE {k} {r.get(k)}")
    # 2. cardinalidade em dupla fonte
    n = len(expected_rows)
    if n != n_literal or len(rows) != n or len(calendar_rows) != n:
        raise AdapterBlocked("D1B_CARDINALITY", f"ext={len(rows)} cal={len(calendar_rows)} exp={n} literal={n_literal}")
    s_ext = [r["session_date"] for r in rows]
    s_cal = [r["session_date"] for r in calendar_rows]
    s_exp = [r["session_date"] for r in expected_rows]
    # 3. unicidade, faixa, sequência, ordem
    for name, seq in (("extract", s_ext), ("calendar", s_cal), ("expected", s_exp)):
        if len(set(seq)) != len(seq):
            raise AdapterBlocked("D1B_DUPLICATE", name)
    if any(not (lo <= s <= hi) for s in s_ext + s_cal + s_exp):
        raise AdapterBlocked("D1B_RANGE")
    if s_exp != sorted(s_exp):
        raise AdapterBlocked("D1B_ORDER", "expected_not_sorted")
    if set(s_ext) != set(s_exp) or set(s_cal) != set(s_exp):
        raise AdapterBlocked("D1B_SEQUENCE")
    if s_ext != s_exp or s_cal != s_exp:
        raise AdapterBlocked("D1B_ORDER")
    # 4-5. predecessor em três vias + OHLC
    for re_, rc, rx in zip(rows, calendar_rows, expected_rows):
        s = re_["session_date"]
        p = re_["expected_previous_session_date"]
        if not (p == rc.get("expected_previous_session_date") == rx.get("expected_previous_session_date")):
            raise AdapterBlocked("D1B_PREDECESSOR_3WAY", s)
        if not p < s or p not in bars:
            raise AdapterBlocked("D1B_PREDECESSOR_INVALID", s)
        b = bars[p]
        got = (int(re_["open_micro"]), int(re_["high_micro"]), int(re_["low_micro"]), int(re_["close_micro"]))
        if got != (int(b.open_micro), int(b.high_micro), int(b.low_micro), int(b.close_micro)):
            raise AdapterBlocked("D1B_OHLC", s)
    # 6. identidade
    ext_sha = sha256_bytes(extract_bytes)
    if extract_sha_expected is not None and ext_sha != extract_sha_expected.upper():
        raise AdapterBlocked("D1B_EXTRACT_SHA", ext_sha)
    if binding is not None:
        if str(binding.get("d1_predecessor_extract_sha256", "")).upper() != ext_sha:
            raise AdapterBlocked("D1B_EXTRACT_SHA", "binding")
        if binding.get("binding_content_sha256") != canonical_hash(binding, exclude_keys={"binding_content_sha256"}):
            raise AdapterBlocked("D1B_BINDING_SELF_HASH")
        if ind_sha is None or str(binding.get("ind_d1_sha256", "")).upper() != ind_sha.upper():
            raise AdapterBlocked("D1B_OHLC", "IND_SHA_NE_BINDING")
    return {"sessions": n, "first": s_exp[0], "last": s_exp[-1],
            "first_predecessor": rows[0]["expected_previous_session_date"], "extract_sha256": ext_sha}


# --------------------------------------------------------------------------- config (G10)
def json_domain(obj):
    import json
    return json.loads(json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")))


def config_validate(raw: bytes, constants: dict, wanted: dict) -> dict:
    pin = constants["config"]
    got_sha = sha256_bytes(raw)
    if got_sha != pin["sha256"]:
        raise AdapterBlocked("CONFIG_SHA_DRIFT", got_sha)
    got = load_json_strict(raw)
    if not isinstance(got, dict):
        raise AdapterBlocked("CONFIG_NOT_OBJECT")
    pinned_keys = set(pin["keys"])
    if set(got) != pinned_keys or set(wanted) != pinned_keys:
        raise AdapterBlocked("CONFIG_KEYSET_MISMATCH",
                             f"missing={sorted(pinned_keys - set(got))} extra={sorted(set(got) - pinned_keys)} "
                             f"wanted_delta={sorted(set(wanted) ^ pinned_keys)}")
    diffs = [k for k in sorted(pinned_keys) if json_domain(got[k]) != json_domain(wanted[k])]
    if diffs:
        raise AdapterBlocked("CONFIG_VALUE_MISMATCH", ",".join(diffs))
    return {"sha256": got_sha, "keys": sorted(got)}


# --------------------------------------------------------------------------- PREFLIGHT (G13)
def preflight_validate(preflight_root, constants: dict) -> dict:
    inv = inventory(preflight_root)
    pin = constants["preflight"]
    if not inv["exists"] or inv["links"] or inv["other"]:
        raise AdapterBlocked("PREFLIGHT_TREE_INVALID", f"exists={inv['exists']} links={inv['links']} other={inv['other']}")
    want_files = pinned_files(pin["files"])
    if inv["files"] != want_files:
        delta = sorted(set(inv["files"]) ^ set(want_files)) + sorted(
            k for k in set(inv["files"]) & set(want_files) if inv["files"][k] != want_files[k])
        raise AdapterBlocked("PREFLIGHT_FILES_DRIFT", ",".join(delta))
    want_dirs = sorted(pin["dirs"] + pin["extraneous_empty_dirs_pinned"])
    if inv["dirs"] != want_dirs:
        raise AdapterBlocked("PREFLIGHT_DIRS_DRIFT", ",".join(sorted(set(inv["dirs"]) ^ set(want_dirs))))
    root = Path(preflight_root)
    st = load_json_strict((root / "PHASE_B" / "PHASE_STATUS.json").read_bytes())
    if st.get("PHASE_DATA_STATUS") != "PASS" or st.get("phase") != "B" or int(st.get("sessions", -1)) != int(constants["sessions"]["expected"]):
        raise AdapterBlocked("PREFLIGHT_STATUS_NOT_PASS_166")
    fails = load_json_strict((root / "PHASE_B" / "PREFLIGHT_FAILURES.json").read_bytes())
    if fails != []:
        raise AdapterBlocked("PREFLIGHT_FAILURES_NONEMPTY")
    cp = load_json_strict((root / "PHASE_B" / "PREFLIGHT_CHECKPOINT.json").read_bytes())
    ticks = [t["path"] for t in constants["inputs"]["ticks"]]
    if cp.get("status") != "PASS" or cp.get("phase") != "B" or cp.get("completed_files") != ticks:
        raise AdapterBlocked("PREFLIGHT_CHECKPOINT_NOT_PASS_8")
    return {"inventory_sha256": canonical_hash({"files": inv["files"], "dirs": inv["dirs"]})}


# --------------------------------------------------------------------------- inputs (G14) and ticks (G17)
def inputs_validate(layout, constants: dict) -> dict:
    ind = Path(layout.ind_d1)
    if not ind.is_file():
        raise AdapterBlocked("INPUT_IND_MISSING", str(ind))
    ind_sha = sha256_file(ind)
    if ind_sha != constants["inputs"]["ind_d1_sha256"]:
        raise AdapterBlocked("INPUT_IND_DRIFT", ind_sha)
    ticks = []
    for t in constants["inputs"]["ticks"]:
        p = layout.tick_path(t["path"])
        if not p.is_file():
            raise AdapterBlocked("INPUT_TICK_MISSING", t["path"])
        st = p.stat()
        if int(st.st_size) != int(t["bytes"]):
            raise AdapterBlocked("INPUT_TICK_SIZE_DRIFT", t["path"])
        ticks.append({"path": t["path"], "bytes": int(st.st_size), "st_dev": int(st.st_dev),
                      "st_ino": int(st.st_ino), "mtime_ns": int(st.st_mtime_ns)})
    m1 = []
    lo, hi = constants["inputs"]["m1_inventory_range"]
    m1_root = Path(layout.m1_root)
    if not m1_root.is_dir():
        raise AdapterBlocked("INPUT_M1_ROOT_MISSING", str(m1_root))
    for p in sorted(m1_root.glob("WIN@N_M1_*.csv")):
        ym = p.stem[-7:].replace("_", "-")
        if lo <= ym <= hi:
            m1.append({"name": p.name, "bytes": p.stat().st_size, "sha256": sha256_file(p)})
    return {"ind_d1_sha256": ind_sha, "ticks_metadata": ticks, "m1_inventory": m1,
            "m1_inventory_sha256": canonical_hash(m1)}


def tick_rehash(layout, constants: dict, progress=None) -> dict:
    out = []
    total = int(constants["inputs"]["ticks_total_bytes"])
    done_before = 0
    for t in constants["inputs"]["ticks"]:
        p = layout.tick_path(t["path"])
        cb = None
        if progress is not None:
            cb = (lambda base: (lambda n: progress(base + n, total)))(done_before)
        got = sha256_file(p, progress=cb)
        if got != t["sha256"]:
            raise AdapterBlocked("TICK_REHASH_DRIFT", f"{t['path']} expected={t['sha256']} got={got}")
        done_before += int(t["bytes"])
        out.append({"path": t["path"], "sha256": got})
    return {"ticks": out, "bytes": done_before}


# --------------------------------------------------------------------------- release / owner / parent
def release_validate(layout, constants: dict) -> dict:
    rec_p, zip_p = Path(layout.g8_local_receipt), Path(layout.g8_evidence_zip)
    if not rec_p.is_file() or sha256_file(rec_p) != constants["release"]["g8_local_receipt_sha256"]:
        raise AdapterBlocked("G8_LOCAL_RECEIPT_IDENTITY")
    if not zip_p.is_file() or sha256_file(zip_p) != constants["release"]["g8_evidence_zip_sha256"]:
        raise AdapterBlocked("G8_EVIDENCE_IDENTITY")
    rec = load_json_strict(rec_p.read_bytes())
    for k, v in constants["release_receipt_contract"].items():
        if rec.get(k) != v:
            raise AdapterBlocked("G8_RECEIPT_CONTRACT", k)
    return {"g8_local_receipt_sha256": constants["release"]["g8_local_receipt_sha256"]}


def owner_auth_validate(control_root, constants: dict) -> dict:
    p = Path(control_root) / constants["owner_authorization"]["path"]
    if not p.is_file():
        raise AdapterBlocked("OWNER_AUTHORIZATION_MISSING")
    raw = p.read_bytes()
    if sha256_bytes(raw) != constants["owner_authorization"]["sha256"]:
        raise AdapterBlocked("OWNER_AUTHORIZATION_SHA")
    a = load_json_strict(raw)
    if (a.get("authorized_scope") != "PHASE_B_2026_ONLY" or a.get("phase_c_authorized") != "NO"
            or a.get("reselection_2026") != "FORBIDDEN"):
        raise AdapterBlocked("OWNER_AUTHORIZATION_SCOPE")
    return {"sha256": constants["owner_authorization"]["sha256"]}


def parent_validate(parent: dict, constants: dict) -> dict:
    p = constants["parent_2025"]
    if str(parent.get("freeze_sha256", "")).upper() != p["freeze_sha256"]:
        raise AdapterBlocked("PARENT_FREEZE_SHA")
    if str(parent.get("homologation_sha256", "")).upper() != p["homologation_sha256"]:
        raise AdapterBlocked("PARENT_HOMOLOGATION_SHA")
    if parent.get("status") != p["freeze_status"] or parent.get("selected") is not None:
        raise AdapterBlocked("PARENT_FREEZE_STATUS", str(parent.get("status")))
    ids = [c.cell_id for c in parent.get("cells", [])]
    if ids != p["frozen_cell_ids"]:
        raise AdapterBlocked("PARENT_FROZEN_CELLS", ",".join(ids))
    return {"cells": ids}


# --------------------------------------------------------------------------- FINAL (V001 §5.8 + DD-4)
def manifest_expected_files(po: Path) -> list[Path]:
    """Mesmo predicado de r1r11_full_2026.py:280."""
    master = po / "SHA256SUMS.txt"
    return [p for p in po.rglob("*") if p.is_file() and p.name != "CHECKPOINT.json"
            and not p.name.endswith(".tmp") and p != master and p.name != "PHASE_B_FINAL_REPORT.json"]


def final_validate(po, constants: dict, expected_rows: list[dict], verify_committed=None) -> dict:
    po = Path(po)
    fr_p, cp_p, man_p, gate_p = (po / "PHASE_B_FINAL_REPORT.json", po / "CHECKPOINT.json",
                                 po / "SHA256SUMS.txt", po / "CONFIRMATION_GATE.json")
    for p in (fr_p, cp_p, man_p, gate_p):
        if not p.is_file():
            raise AdapterBlocked("FINAL_ARTIFACT_MISSING", p.name)
    fr = load_json_strict(fr_p.read_bytes())
    cp = load_json_strict(cp_p.read_bytes())
    exp = [r["session_date"] for r in expected_rows]
    n = int(constants["sessions"]["expected"])
    checks = {
        "schema": fr.get("schema") == "MINOTAURO_PHASE_B_FINAL_REPORT_V001",
        "status": fr.get("status") == "PASS",
        "phase": fr.get("phase") == "B",
        "sessions": fr.get("sessions") == n == len(exp),
        "first": fr.get("first_session") == exp[0],
        "last": fr.get("last_session") == exp[-1],
        "verified_months": fr.get("verified_months") == 8,
        "checkpoint_sha256": fr.get("checkpoint_sha256") == sha256_file(cp_p),
        "checkpoint_completed": cp.get("completed") == exp,
        "checkpoint_phase": cp.get("phase") == "B",
        "verified_month_hashes": cp.get("verified_months") == {t["path"]: t["sha256"] for t in constants["inputs"]["ticks"]},
        "master_manifest_sha256": fr.get("master_manifest_sha256") == sha256_file(man_p),
        "confirmation_gate_sha256": fr.get("confirmation_gate_sha256") == sha256_file(gate_p),
        "frozen_cell_ids": fr.get("frozen_cell_ids") == constants["parent_2025"]["frozen_cell_ids"],
    }
    bad = [k for k, ok in checks.items() if not ok]
    if bad:
        raise AdapterBlocked("FINAL_REPORT_INVALID", ",".join(bad))
    text = man_p.read_bytes()
    if b"\r" in text or not text.endswith(b"\n"):
        raise AdapterBlocked("FINAL_MANIFEST_FORMAT")
    listed = []
    for line in text.decode("ascii").splitlines():
        m = re.fullmatch(r"([0-9A-F]{64})  (.+)", line)
        if not m:
            raise AdapterBlocked("FINAL_MANIFEST_LINE", line[:80])
        listed.append((m.group(2), m.group(1)))
    rels = [r for r, _ in listed]
    if rels != sorted(rels) or len(set(rels)) != len(rels):
        raise AdapterBlocked("FINAL_MANIFEST_ORDER")
    actual = sorted(p.relative_to(po).as_posix() for p in manifest_expected_files(po))
    if rels != actual:
        raise AdapterBlocked("FINAL_MANIFEST_SET", ",".join(sorted(set(rels) ^ set(actual))[:20]))
    for rel, h in listed:
        if sha256_file(po / rel) != h:
            raise AdapterBlocked("FINAL_MANIFEST_HASH", rel)
    gate = load_json_strict(gate_p.read_bytes())
    gchecks = {
        "schema": gate.get("schema") == "MINOTAURO_CONFIRMATION_GATE_2026_V001",
        "sessions": gate.get("sessions") == n,
        "range": gate.get("range") == [exp[0], exp[-1]],
        "baseline": gate.get("baseline_cell_id") == constants["baseline_cell_id"],
        "selected_none": gate.get("selected_cell_id") is None,
        "parent_status": gate.get("parent_selection_status") == constants["parent_2025"]["freeze_status"],
    }
    gbad = [k for k, ok in gchecks.items() if not ok]
    if gbad:
        raise AdapterBlocked("FINAL_CONFIRMATION_GATE_INVALID", ",".join(gbad))
    sessions_dir = po / "sessions"
    dirs = sorted(p.name for p in sessions_dir.iterdir() if p.is_dir()) if sessions_dir.is_dir() else []
    if dirs != exp:
        raise AdapterBlocked("FINAL_SESSIONS_SET")
    if verify_committed is not None:
        verify_committed(po, cp)
    return {"final_report_sha256": sha256_file(fr_p), "manifest_entries": len(listed),
            "confirmation_status": gate.get("status")}


# --------------------------------------------------------------------------- RUN-only documents
def policy_receipt_validate(path, constants: dict) -> dict:
    if path is None:
        raise AdapterBlocked("LIVE_POLICY_RECEIPT_REQUIRED")
    r = load_json_strict(Path(path).read_bytes())
    a = constants["authority"]
    if (r.get("schema") != "MINOTAURO_LIVE_POLICY_RECHECK_RECEIPT_V001" or r.get("cardinality") != "1+1"
            or r.get("state") != "FROZEN" or r.get("master_sha256") != a["snapshot_master_sha256"]
            or r.get("head_sha256") != a["snapshot_head_sha256"]):
        raise AdapterBlocked("LIVE_POLICY_RECEIPT_MISMATCH")
    return {"master_sha256": r["master_sha256"]}


def run_authorization_validate(path, constants: dict, adapter_identity_sha256: str) -> dict:
    if path is None:
        raise AdapterBlocked("RUN_AUTHORIZATION_REQUIRED")
    raw = Path(path).read_bytes()
    r = load_json_strict(raw)
    text = constants["authorization_texts"]["run"]
    if (r.get("schema") != "MINOTAURO_PHASE_B_ADAPTER_RUN_AUTHORIZATION_V001"
            or r.get("authorization_text") != text
            or r.get("authorization_text_lf_sha256") != sha256_bytes((text + "\n").encode("utf-8"))
            or r.get("adapter_identity_sha256") != adapter_identity_sha256
            or r.get("authorized_scope") != "PHASE_B_2026_ONLY"
            or r.get("phase_c_authorized") != "NO"):
        raise AdapterBlocked("RUN_AUTHORIZATION_MISMATCH")
    return {"sha256": sha256_bytes(raw)}


def run_binding_document(adapter_identity: dict, constants: dict, attempt_id: str) -> dict:
    return {"schema": "MINOTAURO_PHASE_B_ADAPTER_RUN_BINDING_V001",
            "adapter_identity_sha256": adapter_identity["adapter_identity_sha256"],
            "constants_sha256": constants["_sha256"],
            "envelope_sha256": constants["envelope"]["sha256"],
            "code_manifest_sha256": constants["frozen_code"]["manifest_sha256"],
            "runner_identity_sha256": constants["frozen_code"]["runner_identity_sha256"],
            "first_attempt_id": attempt_id, "phase": "B", "phase_c_authorized": "NO"}


def run_binding_compare(existing: dict, adapter_identity: dict, constants: dict) -> None:
    keys = ("schema", "adapter_identity_sha256", "constants_sha256", "envelope_sha256",
            "code_manifest_sha256", "runner_identity_sha256", "phase", "phase_c_authorized")
    want = run_binding_document(adapter_identity, constants, "-")
    bad = [k for k in keys if existing.get(k) != want.get(k)]
    if bad:
        raise AdapterBlocked("ADAPTER_IDENTITY_MISMATCH", ",".join(bad))


def dry_receipt_validate(path, adapter_identity_sha256: str, state: str, gate_trace: list,
                         compare_ids: list) -> dict:
    """Template do DRY: mesma identidade, mesmo estado, mesmos input_sha256 por gate (FP-25).
    compare_ids = gates já executados no RUN no momento da comparação; todos obrigatórios nos dois lados."""
    if path is None:
        raise AdapterBlocked("DRY_RECEIPT_REQUIRED")
    raw = Path(path).read_bytes()
    r = load_json_strict(raw)
    if (r.get("schema") != "MINOTAURO_PHASE_B_ADAPTER_DRY_RECEIPT_V001" or r.get("result") != "PASS"
            or r.get("exit_code") != 0 or r.get("mode") != "DRY"):
        raise AdapterBlocked("DRY_RECEIPT_NOT_PASS")
    comp_p = Path(path).with_name(Path(path).name[:-len(".json")] + ".VERIFIED.json")
    comp = load_json_strict(comp_p.read_bytes()) if comp_p.is_file() else {}
    if (comp.get("schema") != "MINOTAURO_PHASE_B_ADAPTER_RECEIPT_VERIFIED_V001"
            or comp.get("receipt_sha256") != sha256_bytes(raw) or comp.get("exit_code") != 0
            or comp.get("mode") != "DRY" or comp.get("attempt_id") != r.get("attempt_id")):
        raise AdapterBlocked("DRY_RECEIPT_NOT_VERIFIED")
    if r.get("adapter_identity_sha256") != adapter_identity_sha256 or r.get("state") != state:
        raise AdapterBlocked("DRY_RECEIPT_IDENTITY_OR_STATE")
    want = {g["id"]: g.get("input_sha256") for g in r.get("gates", [])}
    got = {g["id"]: g.get("input_sha256") for g in gate_trace}
    for gid in compare_ids:
        if gid not in want or gid not in got or want[gid] is None or got[gid] != want[gid]:
            raise AdapterBlocked("DRY_TEMPLATE_GATE_INPUT_DRIFT", gid)
    return r
