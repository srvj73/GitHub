﻿<#
PHASE_B_ADAPTER_V001 — BOOTSTRAP (Windows PowerShell 5.1)
ESTADO: especificação executável SOMENTE após auditoria pré-entrega e autorização explícita
        do owner por estágio (QS2_READONLY ou QS3_DRY). QS4 e RUN não são aceitos por este script.
Uso (a partir de C:\Users\silvi):
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File <caminho>\BOOTSTRAP_PHASE_B_ADAPTER.ps1 `
      -Stage QS2_READONLY -PackageZip <zip> -PackageZipSha256 <sha> -AuthorizationText "<texto exato>" `
      -PolicyReceipt <receipt de recheck live da política (Q07)>
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File <caminho>\BOOTSTRAP_PHASE_B_ADAPTER.ps1 `
      -Stage QS3_DRY -PackageZip <zip> -PackageZipSha256 <sha> -AuthorizationText "<texto exato>" `
      -PriorQS2Receipt <caminho ABSOLUTO do QS2_RECEIPT.json PASS> -PriorQS2ReceiptSha256 <SHA-256 completo desse receipt>
  (B07: QS3 só prossegue se o QS2 anterior PASS, da MESMA identidade de adapter e ZIP, for provado fisicamente.)
Log: caminho absoluto fixo D:\MinotauroRuns\MINOTAURO_PHASE_B_ADAPTER_EVIDENCE\<ATTEMPT_ID>\BOOTSTRAP.log,
     independente do diretório corrente. Status incremental atômico: <mesma pasta>\BOOTSTRAP_STATUS.json.
Receipt do estágio: <mesma pasta>\QS2_RECEIPT.json ou QS3_RECEIPT.json.

Regras (MASTER): exit nativo autoritativo via System.Diagnostics.Process (WaitForExit()+Refresh()+ExitCode);
nenhum Start-Process; nenhuma sentinela de $LASTEXITCODE como medição (o padrão histórico -999 só é
REPRODUZIDO no T26 e classificado como medição inválida); identidade sempre por SHA-256 completo;
watchdog finito SEM auto-kill (expiração => sem PASS + reconciliação); heartbeat <= 30 s com os campos
PHASE,PROGRESS,COMMITTED,TOTAL,RATE,ETA,FINISH,ACTIVE,READY_WAITING,CHECKPOINT,SAFE_STOP;
receipt downstream ausente => exit nativo preservado no log + SHA-256 dos bytes brutos do stderr do filho;
interrupção do próprio bootstrap => FINAL_EXIT coerente com o log (3 se algum filho do adapter iniciou).
#>
param(
    [Parameter(Mandatory = $true)][ValidateSet('QS2_READONLY', 'QS3_DRY')][string]$Stage,
    [Parameter(Mandatory = $true)][string]$PackageZip,
    [Parameter(Mandatory = $true)][ValidatePattern('^[0-9A-Fa-f]{64}$')][string]$PackageZipSha256,
    [Parameter(Mandatory = $true)][string]$AuthorizationText,
    [string]$PolicyReceipt = '',
    [string]$PriorQS2Receipt = '',
    [string]$PriorQS2ReceiptSha256 = ''
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$ProjectLine     = 'PROJECT=Pegasus Original | THREAD=Implementacao Runner Paralelo 7'
$PythonExe       = 'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe'
$PythonSha256    = '4942B86A6597E5AEE0128DAA00050ED79BC21F6E709A78EB19CBFEB0C2F39AC9'
$WindowsPsExe    = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
$PackageBase     = 'D:\MinotauroRuns\MINOTAURO_PHASE_B_ADAPTER_PKG'
$EvidenceBase    = 'D:\MinotauroRuns\MINOTAURO_PHASE_B_ADAPTER_EVIDENCE'
$ReleaseRoot     = 'D:\MinotauroRuns\MINOTAURO_R1R11_FULL_2026_R3_RELEASE_20261001'
$StageTexts      = @{ 'QS2_READONLY' = 'AUTORIZO QS2 PHASE_B_ADAPTER_V001'; 'QS3_DRY' = 'AUTORIZO QS3 PHASE_B_ADAPTER_V001' }
$Utf8NoBom       = New-Object System.Text.UTF8Encoding($false)
$StatusFields    = @('PHASE', 'PROGRESS', 'COMMITTED', 'TOTAL', 'RATE', 'ETA', 'FINISH', 'ACTIVE', 'READY_WAITING', 'CHECKPOINT', 'SAFE_STOP')
$HeartbeatMs     = 30000
$WatchdogSeconds = @{ 'PROBE' = 120; 'Q08' = 300; 'STATUS_B' = 1800; 'CLASSIFY_B' = 21600; 'DRY_RUN_B' = 43200; 'T31A' = 1800; 'Q07' = 300 }
$StderrDrainMs   = 60000
$ContractExits   = @(0, 2, 3, 130)
$RequiredItems   = @{ 'QS2_READONLY' = @('Q01', 'Q02', 'Q03', 'Q04', 'Q05', 'Q05_HOST', 'Q06_partial', 'Q07', 'Q08', 'T26', 'T31a', 'STATUS_B', 'CLASSIFY_B');
                      'QS3_DRY' = @('PRIOR_QS2', 'T26', 'DRY_RUN_B', 'T02', 'T11c', 'T14', 'T19_template', 'T23', 'T27', 'T30') }

$NonceBytes = New-Object byte[] 4
$Rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
$Rng.GetBytes($NonceBytes)
$Rng.Dispose()
$Nonce = -join ($NonceBytes | ForEach-Object { $_.ToString('x2') })
$AttemptId  = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ') + '_' + $Nonce
$AttemptDir = Join-Path $EvidenceBase $AttemptId
$LogPath    = Join-Path $AttemptDir 'BOOTSTRAP.log'
$BootstrapStatusPath = Join-Path $AttemptDir 'BOOTSTRAP_STATUS.json'
$StageReceiptPath = Join-Path $AttemptDir ($Stage.Split('_')[0] + '_RECEIPT.json')
$FinalCode  = 2
$Frontier   = 'NONE'
$BlockedReason = $null
$Items = [ordered]@{}
$Facts = [ordered]@{}
$script:StatusSeq = 0
$script:StatusWriteFailures = 0
$script:FinalStatusWritten = $false
$script:Checkpoint = 'NONE'
$script:AdapterChildStarted = $false
$script:Unproven = $false
$script:MainCompleted = $false
$script:LastReceiptDoc = $null
$script:LastStatusSha256 = $null

# ============================================================================ funções
function Write-Line([string]$Text) {
    Write-Host $Text
    if (Test-Path -LiteralPath $AttemptDir) {
        [System.IO.File]::AppendAllText($LogPath, $Text + "`r`n", $Utf8NoBom)
    }
}

function Get-Sha256([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToUpperInvariant()
}

function Get-TextSha256([string]$Text) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = $sha.ComputeHash($Utf8NoBom.GetBytes($Text))
    }
    finally { $sha.Dispose() }
    return (-join ($bytes | ForEach-Object { $_.ToString('X2') }))
}

function Read-SharedText([string]$Path) {
    $share = [System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete
    $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, $share)
    try {
        $sr = New-Object System.IO.StreamReader($fs, $Utf8NoBom)
        return $sr.ReadToEnd()
    }
    finally { $fs.Dispose() }
}

function Get-BytesSha256([byte[]]$Bytes) {
    $h = [System.Security.Cryptography.SHA256]::Create()
    try { return (-join ($h.ComputeHash($Bytes) | ForEach-Object { $_.ToString('X2') })) }
    finally { $h.Dispose() }
}

function Read-SharedBytes([string]$Path) {
    $share = [System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete
    $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, $share)
    try {
        $ms = New-Object System.IO.MemoryStream
        $fs.CopyTo($ms)
        return ,$ms.ToArray()
    }
    finally { $fs.Dispose() }
}

function Write-AtomicText([string]$Path, [string]$Text) {
    # tmp exclusivo com WriteThrough + Flush(true) e troca atômica (File.Replace / File.Move); novas tentativas
    # quando um leitor mantém o destino aberto.
    $tmp = $Path + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    $bytes = $Utf8NoBom.GetBytes($Text)
    $fs = New-Object System.IO.FileStream($tmp, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None, 4096, [System.IO.FileOptions]::WriteThrough)
    try {
        $fs.Write($bytes, 0, $bytes.Length)
        $fs.Flush($true)
    }
    finally { $fs.Dispose() }
    for ($i = 0; $i -lt 8; $i++) {
        try {
            if ([System.IO.File]::Exists($Path)) { [System.IO.File]::Replace($tmp, $Path, [NullString]::Value) }
            else { [System.IO.File]::Move($tmp, $Path) }
            return
        }
        catch { Start-Sleep -Milliseconds 250 }
    }
    if ([System.IO.File]::Exists($tmp)) { [System.IO.File]::Delete($tmp) }
    throw ('ATOMIC_WRITE_FAILED ' + $Path)
}

function Get-JsonProp($Obj, [string]$Name) {
    if ($null -eq $Obj) { return $null }
    $p = $Obj.PSObject.Properties[$Name]
    if ($null -eq $p) { return $null }
    return $p.Value
}

function Format-Eta($Seconds) {
    if ($null -eq $Seconds) { return 'UNKNOWN' }
    $s = [int64][Math]::Round([double]$Seconds)
    if ($s -lt 0) { return 'UNKNOWN' }
    $ts = [TimeSpan]::FromSeconds($s)
    return ('{0}.{1:00}.{2:00}.{3:00}' -f $ts.Days, $ts.Hours, $ts.Minutes, $ts.Seconds)
}

function New-StatusFields([string]$Phase) {
    $f = [ordered]@{}
    $f['PHASE'] = $Phase
    $f['PROGRESS'] = 'UNKNOWN'
    $f['COMMITTED'] = '0'
    $f['TOTAL'] = 'UNKNOWN'
    $f['RATE'] = 'UNKNOWN'
    $f['ETA'] = 'UNKNOWN'
    $f['FINISH'] = 'UNKNOWN'
    $f['ACTIVE'] = 'YES'
    $f['READY_WAITING'] = '0'
    $f['CHECKPOINT'] = $script:Checkpoint
    $f['SAFE_STOP'] = 'NO'
    return $f
}

function Set-BootstrapStatus($Fields, $Extra) {
    # Status incremental atômico (LONG_RUNNER_STATUS_FILE_ATOMIC=MANDATORY; persiste após o fim).
    $doc = [ordered]@{}
    $doc['schema'] = 'MINOTAURO_PHASE_B_ADAPTER_BOOTSTRAP_STATUS_V001'
    $doc['attempt_id'] = $AttemptId
    $doc['stage'] = $Stage
    $doc['seq'] = $script:StatusSeq + 1
    $doc['updated_utc'] = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
    $doc['field_order'] = $StatusFields
    $ordered = [ordered]@{}
    foreach ($k in $StatusFields) { $ordered[$k] = [string]$Fields[$k] }
    $doc['fields'] = $ordered
    $doc['status_write_failures'] = $script:StatusWriteFailures
    if ($null -ne $Extra) { $doc['extra'] = $Extra }
    try {
        if (Test-Path -LiteralPath $AttemptDir) {
            $text = $doc | ConvertTo-Json -Depth 8
            Write-AtomicText $BootstrapStatusPath $text
            # releitura física: o status só conta como persistido se os bytes no disco forem os gravados
            $back = Read-SharedBytes $BootstrapStatusPath
            $want = $Utf8NoBom.GetBytes($text)
            if ($back.Length -ne $want.Length -or (Get-BytesSha256 $back) -ne (Get-BytesSha256 $want)) { throw 'STATUS_READBACK_MISMATCH' }
            $script:StatusSeq = $doc['seq']
            $script:LastStatusSha256 = Get-BytesSha256 $back
            return $true
        }
    }
    catch {
        $script:StatusWriteFailures++
        Write-Line ('STATUS_WRITE=DEGRADED failures=' + $script:StatusWriteFailures)
    }
    return $false
}

function Read-AdapterStatus([string]$Path) {
    if ([string]::IsNullOrEmpty($Path) -or -not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    try { return ((Read-SharedText $Path) | ConvertFrom-Json) } catch { return $null }
}

function Write-Heartbeat([string]$Label, [int]$ChildPid, [int]$ElapsedS, [int]$WatchdogS, [string]$AdapterStatusPath) {
    $f = New-StatusFields $Label
    $age = 'NO_ADAPTER_STATUS'
    $st = Read-AdapterStatus $AdapterStatusPath
    $af = Get-JsonProp $st 'fields'
    if ($null -ne $af) {
        foreach ($k in $StatusFields) {
            $v = Get-JsonProp $af $k
            if ($null -ne $v) { $f[$k] = [string]$v }
        }
        $upd = Get-JsonProp $st 'updated_utc'
        try {
            if ($upd -is [DateTime]) { $then = $upd.ToUniversalTime() }
            else { $then = [DateTime]::ParseExact([string]$upd, 'yyyy-MM-ddTHH:mm:ssZ', [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AdjustToUniversal -bor [Globalization.DateTimeStyles]::AssumeUniversal) }
            $age = [string][int]((Get-Date).ToUniversalTime() - $then).TotalSeconds
        }
        catch { $age = 'UNPARSEABLE' }
    }
    $parts = @()
    foreach ($k in $StatusFields) { $parts += ($k + '=' + $f[$k]) }
    Write-Line ('HEARTBEAT label=' + $Label + ' pid=' + $ChildPid + ' elapsed_s=' + $ElapsedS + ' watchdog_s=' + $WatchdogS + ' auto_kill=NO adapter_status_age_s=' + $age + ' ' + ($parts -join ' '))
    $extra = [ordered]@{ label = $Label; child_pid = $ChildPid; elapsed_s = $ElapsedS; watchdog_s = $WatchdogS; auto_kill = 'NO'; adapter_status_age_s = $age }
    [void](Set-BootstrapStatus $f $extra)
}

function Invoke-Child([string]$Exe, [string]$Arguments, [string]$WorkDir, [string]$Label, [int]$Watchdog, [string]$AdapterStatusPath) {
    # Fronteira única: System.Diagnostics.Process. stderr drenado de forma assíncrona em BYTES BRUTOS
    # (BaseStream.CopyToAsync -> MemoryStream), qualificado no alvo pelo T26 (bytes determinísticos) antes de
    # servir de diagnóstico do adapter. Espera de dreno limitada: pipe retido por descendente => não provado.
    $stderrPath = Join-Path $AttemptDir ('STDERR_' + $Label + '.txt')
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Exe
    $psi.Arguments = $Arguments
    $psi.WorkingDirectory = $WorkDir
    $psi.UseShellExecute = $false
    $psi.RedirectStandardError = $true
    $psi.EnvironmentVariables['PYTHONDONTWRITEBYTECODE'] = '1'
    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $psi
    $started = Get-Date
    $errBuffer = New-Object System.IO.MemoryStream
    [void]$proc.Start()
    $errTask = $proc.StandardError.BaseStream.CopyToAsync($errBuffer)
    $childPid = $proc.Id
    Write-Line ('CHILD_START label=' + $Label + ' pid=' + $childPid + ' watchdog_s=' + $Watchdog + ' auto_kill=NO')
    $f0 = New-StatusFields $Label
    [void](Set-BootstrapStatus $f0 ([ordered]@{ label = $Label; child_pid = $childPid; watchdog_s = $Watchdog; auto_kill = 'NO' }))
    $result = [ordered]@{ Label = $Label; Pid = $childPid; ExitCode = $null; TimedOut = $false; Completed = $false; StderrComplete = $false;
                          StderrPath = $null; StderrSha256 = 'UNAVAILABLE'; StderrBytes = $null; StderrText = $null; Seconds = $null }
    try {
        while (-not $proc.WaitForExit($HeartbeatMs)) {
            $elapsed = [int]((Get-Date) - $started).TotalSeconds
            Write-Heartbeat $Label $childPid $elapsed $Watchdog $AdapterStatusPath
            if ($elapsed -ge $Watchdog) {
                $result.TimedOut = $true
                break
            }
        }
        if (-not $result.TimedOut) {
            $proc.WaitForExit()
            $proc.Refresh()
            $result.ExitCode = [int]$proc.ExitCode
            if ($errTask.Wait($StderrDrainMs)) {
                $errBytes = $errBuffer.ToArray()
                [System.IO.File]::WriteAllBytes($stderrPath, $errBytes)
                $result.StderrPath = $stderrPath
                $result.StderrSha256 = Get-Sha256 $stderrPath
                $result.StderrBytes = $errBytes.Length
                $result.StderrText = $Utf8NoBom.GetString($errBytes)
                $result.StderrComplete = $true
            }
            else {
                $script:Unproven = $true
                $result.StderrSha256 = 'INCOMPLETE_PIPE_HELD_BY_DESCENDANT'
                Write-Line ('STDERR_DRAIN_TIMEOUT label=' + $Label + ' pid=' + $childPid + ' drain_ms=' + $StderrDrainMs + ' descendant_holds_pipe=SUSPECTED auto_kill=NO RECONCILIATION_REQUIRED=YES')
            }
            $result.Completed = $true
        }
    }
    finally {
        $result.Seconds = [int]((Get-Date) - $started).TotalSeconds
        if ($result.TimedOut) {
            $script:Unproven = $true
            $result.StderrSha256 = 'UNAVAILABLE_CHILD_STILL_RUNNING'
            Write-Line ('WATCHDOG_EXPIRED label=' + $Label + ' pid=' + $childPid + ' watchdog_s=' + $Watchdog + ' auto_kill=NO child_killed=NO PASS=NO RECONCILIATION_REQUIRED=YES')
            $ft = New-StatusFields ($Label + '_WATCHDOG_EXPIRED')
            [void](Set-BootstrapStatus $ft ([ordered]@{ label = $Label; child_pid = $childPid; watchdog_expired = 'YES'; auto_kill = 'NO'; reconciliation_required = 'YES' }))
        }
        elseif (-not $result.Completed) {
            # interrupção do próprio bootstrap: nenhum kill; registra o que for provável
            $script:Unproven = $true
            Write-Line ('CHILD_UNRESOLVED label=' + $Label + ' pid=' + $childPid + ' auto_kill=NO RECONCILIATION_REQUIRED=YES')
        }
        else {
            Write-Line ('CHILD_EXIT label=' + $Label + ' pid=' + $childPid + ' native_exit=' + $result.ExitCode + ' stderr_sha256=' + $result.StderrSha256 + ' stderr_bytes=' + $result.StderrBytes + ' stderr_path=' + $result.StderrPath + ' seconds=' + $result.Seconds)
        }
    }
    return [pscustomobject]$result
}

function Test-ChildReceipt([string]$Path, [string]$Schema, [string]$Mode, $NativeExit, [string]$IdentitySha, $ResultByExit, [string]$ExpectedAttempt = '') {
    # B02: verificação física do receipt esperado antes de aceitar o resultado do filho.
    $r = [ordered]@{ path = $Path; present = $false; valid = $false; reason = 'RECEIPT_MISSING'; sha256 = $null; result = $null }
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $r }
    $r.present = $true
    # uma única leitura: o SHA-256 e o JSON vêm dos MESMOS bytes (sem TOCTOU entre verificação e uso)
    $raw = Read-SharedBytes $Path
    $hasher = [System.Security.Cryptography.SHA256]::Create()
    try { $r.sha256 = (-join ($hasher.ComputeHash($raw) | ForEach-Object { $_.ToString('X2') })) } finally { $hasher.Dispose() }
    $script:LastReceiptDoc = $null
    try { $doc = $Utf8NoBom.GetString($raw).TrimStart([char]0xFEFF) | ConvertFrom-Json }
    catch { $r.reason = 'RECEIPT_JSON_INVALID'; return $r }
    $r.result = Get-JsonProp $doc 'result'
    if ([string]::IsNullOrEmpty($ExpectedAttempt)) { $ExpectedAttempt = $AttemptId }
    $want = $ResultByExit['other']
    if ($ResultByExit.Contains([string]$NativeExit)) { $want = $ResultByExit[[string]$NativeExit] }
    if ((Get-JsonProp $doc 'schema') -ne $Schema) { $r.reason = 'RECEIPT_SCHEMA'; return $r }
    if ((Get-JsonProp $doc 'attempt_id') -ne $ExpectedAttempt) { $r.reason = 'RECEIPT_ATTEMPT_ID'; return $r }
    if ($null -eq $NativeExit -or (Get-JsonProp $doc 'exit_code') -ne $NativeExit) { $r.reason = 'RECEIPT_EXIT_CODE_NE_NATIVE'; return $r }
    if ($r.result -ne $want) { $r.reason = 'RECEIPT_RESULT_NE_NATIVE'; return $r }
    if ($Mode -ne '' -and (Get-JsonProp $doc 'mode') -ne $Mode) { $r.reason = 'RECEIPT_MODE'; return $r }
    if ($IdentitySha -ne '' -and (Get-JsonProp $doc 'adapter_identity_sha256') -ne $IdentitySha) { $r.reason = 'RECEIPT_ADAPTER_IDENTITY'; return $r }
    if ($Mode -ne '') {
        # companion positivo gravado pelo adapter só após a releitura física do receipt (B02)
        $cp = $Path.Substring(0, $Path.Length - 5) + '.VERIFIED.json'
        if (-not (Test-Path -LiteralPath $cp -PathType Leaf)) { $r.reason = 'RECEIPT_NOT_VERIFIED_BY_ADAPTER'; return $r }
        try { $comp = (Read-SharedText $cp) | ConvertFrom-Json } catch { $r.reason = 'RECEIPT_COMPANION_INVALID'; return $r }
        if ((Get-JsonProp $comp 'schema') -ne 'MINOTAURO_PHASE_B_ADAPTER_RECEIPT_VERIFIED_V001' -or (Get-JsonProp $comp 'receipt_sha256') -ne $r.sha256 -or
            (Get-JsonProp $comp 'exit_code') -ne $NativeExit -or (Get-JsonProp $comp 'attempt_id') -ne $ExpectedAttempt -or (Get-JsonProp $comp 'mode') -ne $Mode) {
            $r.reason = 'RECEIPT_COMPANION_MISMATCH'; return $r
        }
        if ($NativeExit -eq 0 -or $NativeExit -eq 130) {
            # B08: PASS/SAFE_STOP só com status incremental sem falhas e status final ACTIVE=NO persistido e vinculado
            if ((Get-JsonProp $doc 'status_write_failures') -ne 0 -or (Get-JsonProp $doc 'status_final_persisted') -ne $true) { $r.reason = 'RECEIPT_STATUS_NOT_PERSISTED'; return $r }
            $sp = Join-Path (Split-Path -Parent $Path) 'ADAPTER_STATUS.json'
            if (-not (Test-Path -LiteralPath $sp -PathType Leaf)) { $r.reason = 'RECEIPT_STATUS_FILE_MISSING'; return $r }
            $sb = Read-SharedBytes $sp
            if ((Get-BytesSha256 $sb) -ne (Get-JsonProp $doc 'status_final_sha256')) { $r.reason = 'RECEIPT_STATUS_FINAL_MISMATCH'; return $r }
            try { $sd = $Utf8NoBom.GetString($sb) | ConvertFrom-Json } catch { $r.reason = 'RECEIPT_STATUS_FINAL_MISMATCH'; return $r }
            if ((Get-JsonProp (Get-JsonProp $sd 'fields') 'ACTIVE') -ne 'NO' -or (Get-JsonProp (Get-JsonProp $sd 'extra') 'exit_code') -ne $NativeExit) { $r.reason = 'RECEIPT_STATUS_FINAL_MISMATCH'; return $r }
        }
    }
    $r.valid = $true
    $r.reason = 'OK'
    $script:LastReceiptDoc = $doc
    return $r
}

function Resolve-ChildOutcome($Child, $Receipt, [string]$Label) {
    # Exit final do item. Nunca aceita PASS sem receipt verificado; nunca perde o exit nativo.
    $o = [ordered]@{ label = $Label; native_exit = $Child.ExitCode; final_exit = 3; reason = $null;
                     stderr_sha256 = $Child.StderrSha256; stderr_path = $Child.StderrPath; receipt = $Receipt; timed_out = $Child.TimedOut }
    if ($Child.TimedOut) { $o.reason = 'WATCHDOG_EXPIRED_CHILD_STILL_RUNNING_RECONCILIATION_REQUIRED' }
    elseif (-not $Child.Completed) { $o.reason = 'CHILD_UNRESOLVED_RECONCILIATION_REQUIRED' }
    elseif ($ContractExits -notcontains $Child.ExitCode) { $o.reason = 'NATIVE_EXIT_OUT_OF_CONTRACT' }
    elseif (-not $Child.StderrComplete) { $o.reason = 'STDERR_PIPE_HELD_BY_DESCENDANT_RECONCILIATION_REQUIRED' }
    elseif ($Receipt.valid) { $o.final_exit = $Child.ExitCode; $o.reason = 'RECEIPT_VERIFIED' }
    elseif ($Child.ExitCode -eq 0 -or $Child.ExitCode -eq 130) { $o.reason = 'DOWNSTREAM_RECEIPT_' + $Receipt.reason + '_PASS_REFUSED' }
    else { $o.final_exit = $Child.ExitCode; $o.reason = 'DOWNSTREAM_RECEIPT_' + $Receipt.reason + '_NATIVE_EXIT_PRESERVED' }
    if (-not $Receipt.valid) {
        Write-Line ('MISSING_DOWNSTREAM_RESULT label=' + $Label + ' native_exit=' + $Child.ExitCode + ' stderr_sha256=' + $Child.StderrSha256 + ' stderr_path=' + $Child.StderrPath + ' receipt=' + $Receipt.reason)
    }
    if ($o.final_exit -eq 3 -and $o.reason -ne 'RECEIPT_VERIFIED') { $script:Unproven = $true }
    Write-Line ('CHILD_OUTCOME label=' + $Label + ' native_exit=' + $Child.ExitCode + ' final_exit=' + $o.final_exit + ' reason=' + $o.reason)
    return $o
}

function Invoke-T26Probes([string]$Probe, [string]$WorkDir) {
    # T26: exit nativo 0/2/3/7/130 pela fronteira System.Diagnostics.Process + qualificação da captura de stderr.
    $rows = @()
    $ok = $true
    foreach ($want in @(0, 2, 3, 7, 130)) {
        $c = Invoke-Child $PythonExe ('-B "' + $Probe + '" ' + $want) $WorkDir ('T26_PROBE_' + $want) $WatchdogSeconds['PROBE'] ''
        $expectedErr = 'PROBE_STDERR=' + $want + "`n"
        $row = [ordered]@{ want = $want; native_exit = $c.ExitCode; completed = $c.Completed; stderr_sha256 = $c.StderrSha256;
                           stderr_expected_sha256 = (Get-TextSha256 $expectedErr); stderr_match = ($c.StderrText -ceq $expectedErr) }
        $row['pass'] = ($c.Completed -and $c.ExitCode -eq $want -and $row.stderr_match)
        if (-not $row['pass']) { $ok = $false }
        $rows += $row
    }
    return [ordered]@{ result = $(if ($ok) { 'PASS' } else { 'FAIL' }); probes = $rows }
}

function Invoke-T26HistoricalPattern([string]$Probe, [string]$WorkDir) {
    # T26-H: reproduz o padrão do incidente (sentinela -999 atribuída dentro de & { } e lida sem escopo) e o
    # compara com a medição autoritativa (System.Diagnostics.Process.ExitCode). Duas variantes:
    #  (a) fronteira Process dentro do padrão: a leitura da sentinela não é medição de nada;
    #  (b) reprodução fiel: comando nativo pelo operador de chamada dentro do mesmo & { }; o automático GLOBAL
    #      recebe o exit real, mas a leitura sem escopo devolve a sentinela local (sombreamento) — não tautológico:
    #      se o PowerShell não sombreasse, a leitura devolveria 7 e o T26 falharia.
    # Nenhum valor daqui é usado como exit; a classificação é sempre INVALID_MEASUREMENT.
    $script:T26HistoricalChild = $null
    $sentinelProcess = & {  # QS0_ALLOW_T26_HISTORICAL_SENTINEL
        $LASTEXITCODE = -999  # QS0_ALLOW_T26_HISTORICAL_SENTINEL
        $script:T26HistoricalChild = Invoke-Child $PythonExe ('-B "' + $Probe + '" 7') $WorkDir 'T26_HISTORICAL' $WatchdogSeconds['PROBE'] ''
        $LASTEXITCODE  # QS0_ALLOW_T26_HISTORICAL_SENTINEL
    }
    $script:T26HistoricalGlobal = $null
    $sentinelNative = & {  # QS0_ALLOW_T26_HISTORICAL_SENTINEL
        $LASTEXITCODE = -999  # QS0_ALLOW_T26_HISTORICAL_SENTINEL
        $null = & $PythonExe -B $Probe 7q  # QS0_ALLOW_T26_HISTORICAL_SENTINEL
        $script:T26HistoricalGlobal = $global:LASTEXITCODE  # QS0_ALLOW_T26_HISTORICAL_SENTINEL
        $LASTEXITCODE  # QS0_ALLOW_T26_HISTORICAL_SENTINEL
    }
    $auth = $script:T26HistoricalChild.ExitCode
    $reproduced = ([string]$sentinelProcess -eq '-999') -and ([string]$sentinelNative -eq '-999') -and
                  ([string]$script:T26HistoricalGlobal -eq '7') -and ($auth -eq 7)
    $h = [ordered]@{ sentinel_read_process_boundary = [string]$sentinelProcess; sentinel_read_native_call = [string]$sentinelNative;
                     global_lastexitcode_after_native_call = [string]$script:T26HistoricalGlobal;
                     authoritative_process_exit = $auth; shadowing_reproduced = $reproduced;
                     classification = 'INVALID_MEASUREMENT'; used_as_exit = 'NO'; result = $(if ($reproduced) { 'PASS' } else { 'FAIL' }) }
    Write-Line ('T26_HISTORICAL sentinel_process=' + $h.sentinel_read_process_boundary + ' sentinel_native=' + $h.sentinel_read_native_call + ' global_after_native=' + $h.global_lastexitcode_after_native_call + ' authoritative_process_exit=' + $auth + ' classification=INVALID_MEASUREMENT reproduced=' + $reproduced)
    return $h
}

function Invoke-Q08([string]$ProbePs, [string]$Probe, [string]$WorkDir) {
    # Q08: propagação do exit nativo pelo bloco PowerShell completo (powershell.exe -File -> python -> exit).
    $rows = @()
    $ok = $true
    foreach ($want in @(0, 2, 3, 7, 130)) {
        $a = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + $ProbePs + '" -PythonExe "' + $PythonExe + '" -Probe "' + $Probe + '" -Want ' + $want
        $c = Invoke-Child $WindowsPsExe $a $WorkDir ('Q08_PS_' + $want) $WatchdogSeconds['Q08'] ''
        $row = [ordered]@{ want = $want; outer_powershell_exit = $c.ExitCode; completed = $c.Completed; stderr_sha256 = $c.StderrSha256 }
        $row['pass'] = ($c.Completed -and $c.ExitCode -eq $want)
        if (-not $row['pass']) { $ok = $false }
        $rows += $row
    }
    return [ordered]@{ result = $(if ($ok) { 'PASS' } else { 'FAIL' }); runs = $rows }
}

function Get-HostQ05 {
    # Q05 (parte do bootstrap): PowerShell, SO, antivírus e exclusões — somente leitura.
    $o = [ordered]@{}
    $o['ps_version'] = $PSVersionTable.PSVersion.ToString()
    $o['ps_edition'] = [string]$PSVersionTable['PSEdition']
    $o['clr_version'] = [string]$PSVersionTable['CLRVersion']
    $o['os'] = [Environment]::OSVersion.VersionString
    $o['logical_cpus'] = [Environment]::ProcessorCount
    $o['is_64bit_process'] = [Environment]::Is64BitProcess
    try {
        $av = @(Get-CimInstance -Namespace 'root/SecurityCenter2' -ClassName 'AntiVirusProduct' -ErrorAction Stop | ForEach-Object { [ordered]@{ name = [string]$_.displayName; product_state = [string]$_.productState } })
        $o['antivirus_products'] = $av
    }
    catch { $o['antivirus_products'] = 'UNAVAILABLE: ' + $_.Exception.GetType().Name }
    try {
        $mp = Get-MpPreference -ErrorAction Stop
        $o['defender_exclusion_path'] = @($mp.ExclusionPath | Where-Object { $null -ne $_ })
        $o['defender_exclusion_process'] = @($mp.ExclusionProcess | Where-Object { $null -ne $_ })
    }
    catch { $o['defender_exclusions'] = 'UNAVAILABLE: ' + $_.Exception.GetType().Name }
    return $o
}

function Expand-AdapterPackage([string]$ZipPath, [string]$TargetDir) {
    # B04/B06-R: extração do ZIP (SHA-256 completo fixado pelo owner) em staging owned + troca atômica de nome;
    # diretório novo ou reutilizado é conferido byte a byte contra as entradas do ZIP.
    $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
    try {
        $zipHashes = @{}
        foreach ($entry in $zip.Entries) {
            $n = $entry.FullName
            if ($n.Contains('..') -or $n.StartsWith('/') -or $n.Contains(':') -or $n.Contains('\')) { throw ('ZIP_ENTRY_UNSAFE ' + $n) }
            if ($n.EndsWith('/')) { continue }
            $es = $entry.Open()
            $hasher = [System.Security.Cryptography.SHA256]::Create()
            try { $zipHashes[$n] = (-join ($hasher.ComputeHash($es) | ForEach-Object { $_.ToString('X2') })) }
            finally { $es.Dispose(); $hasher.Dispose() }
        }
        Write-Line ('ZIP_FILE_ENTRIES=' + $zipHashes.Count)
        if (-not (Test-Path -LiteralPath $TargetDir)) {
            # extração em diretório de staging owned e troca atômica de nome: extração parcial nunca ocupa o nome final
            $script:Frontier = 'PACKAGE_EXTRACTION'
            $staging = $TargetDir + '.extract.' + $Nonce
            Write-Line ('EFFECTFUL_FRONTIER=PACKAGE_EXTRACTION (owned directory only) staging=' + $staging)
            [void](New-Item -ItemType Directory -Path $staging)
            foreach ($entry in $zip.Entries) {
                if ($entry.FullName.EndsWith('/')) { continue }
                $dest = Join-Path $staging ($entry.FullName.Replace('/', '\'))
                $parent = Split-Path -Parent $dest
                if (-not (Test-Path -LiteralPath $parent)) { [void](New-Item -ItemType Directory -Path $parent -Force) }
                [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $dest, $false)
            }
            $moved = $false
            for ($i = 0; $i -lt 8 -and -not $moved; $i++) {
                try { [System.IO.Directory]::Move($staging, $TargetDir); $moved = $true }
                catch { Start-Sleep -Milliseconds 500 }
            }
            if (-not $moved) { throw ('PACKAGE_STAGING_MOVE_FAILED staging=' + $staging + ' RECONCILIATION_REQUIRED') }
        }
    }
    finally { $zip.Dispose() }
    # diretório novo OU reutilizado: conteúdo byte a byte = ZIP fixado pelo owner (SHA-256 completo)
    $onDisk = @(Get-ChildItem -LiteralPath $TargetDir -Recurse -File -Force | ForEach-Object { $_.FullName.Substring($TargetDir.Length + 1).Replace('\', '/') })
    if ($onDisk.Count -ne $zipHashes.Count) { throw ('PACKAGE_DIR_NE_ZIP count disk=' + $onDisk.Count + ' zip=' + $zipHashes.Count + ' RECONCILIATION_REQUIRED') }
    foreach ($rel in $onDisk) {
        if (-not $zipHashes.ContainsKey($rel)) { throw ('PACKAGE_DIR_NE_ZIP extra=' + $rel) }
        if ((Get-Sha256 (Join-Path $TargetDir ($rel.Replace('/', '\')))) -ne $zipHashes[$rel]) { throw ('PACKAGE_DIR_NE_ZIP hash=' + $rel) }
    }
    Write-Line 'PACKAGE_DIR_EQUALS_ZIP=PASS'
    return $zipHashes.Count
}

function Get-QItems($Phys, [string]$ReceiptSha) {
    # B03: Q01..Q06_partial pelo VEREDITO substantivo do adapter (qs2_verdicts), nunca por presença.
    $out = [ordered]@{}
    foreach ($q in @('Q01', 'Q02', 'Q03', 'Q04', 'Q05', 'Q06_partial')) {
        $sec = Get-JsonProp $Phys $q
        $v = Get-JsonProp $sec 'verdict'
        $reasons = @()
        if ($null -ne $sec -and $null -ne $sec.PSObject.Properties['reasons'] -and $null -ne $sec.PSObject.Properties['reasons'].Value) { $reasons = @($sec.PSObject.Properties['reasons'].Value) }
        $out[$q] = [ordered]@{ result = $(if ($v -eq 'PASS') { 'PASS' } else { 'FAIL' }); verdict = $v; reasons = $reasons;
                               source = 'CLASSIFY_RECEIPT.qs2_physical.' + $q; receipt_sha256 = $ReceiptSha }
    }
    return $out
}

function Get-DryItems($Doc, [string]$ReceiptSha) {
    # QS3: itens do envelope derivados do DRY_RECEIPT verificado; nenhum PASS sem prova substantiva até BND.
    $out = [ordered]@{}
    $gates = @(Get-JsonProp $Doc 'gates')
    $gatePass = @{}
    foreach ($g in $gates) { if ((Get-JsonProp $g 'status') -eq 'PASS') { $gatePass[[string](Get-JsonProp $g 'id')] = $true } }
    $bd = Get-JsonProp $Doc 'before_digests'
    $ad = Get-JsonProp $Doc 'after_digests'
    $same = $true
    foreach ($k in @('control', 'preflight', 'code', 'package', 'release_top', 'inputs')) {
        $b = Get-JsonProp $bd $k
        if ($null -eq $b -or $b -ne (Get-JsonProp $ad $k)) { $same = $false }
    }
    $substantive = ((Get-JsonProp $Doc 'dry_scope') -eq 'SUBSTANTIVE_TO_BND') -and ((Get-JsonProp $Doc 'bnd_reached') -eq $true) -and
                   $gatePass.ContainsKey('BND') -and $gatePass.ContainsKey('G22') -and $gatePass.ContainsKey('G21')
    $ev = Get-JsonProp $Doc 'runtime_evidence'
    $clean = ((Get-JsonProp $ev 'started') -eq $true) -and ((Get-JsonProp $ev 'clean') -eq $true)
    $d1 = Get-JsonProp $Doc 'd1b_at_use'
    # acesso direto à propriedade (sem 'return' de função, que desenrolaria arrays de 0/1 elemento)
    $traceProp = $Doc.PSObject.Properties['runtime_trace']
    $trace = @()
    if ($null -ne $traceProp -and $traceProp.Value -is [array]) { $trace = $traceProp.Value }
    $t30 = Get-JsonProp $Doc 't30'
    $foreignOk = $false
    if ($null -ne $t30) {
        $foreignProp = $t30.PSObject.Properties['foreign']
        $foreignOk = ($null -ne $foreignProp) -and ($foreignProp.Value -is [array]) -and ($foreignProp.Value.Count -eq 0)
    }
    $t30roots = Get-JsonProp $t30 'roots'
    $checks = [ordered]@{
        'T02' = ($substantive -and $null -ne $d1 -and (Get-JsonProp $d1 'sessions') -eq 166)
        'T11c' = ($substantive -and @('PREPARED', 'EMPTY') -contains (Get-JsonProp $Doc 'state'))
        'T14' = ($substantive -and $gatePass.ContainsKey('G18'))
        'T19_template' = ($substantive -and $trace.Count -gt 0 -and [string](Get-JsonProp $Doc 'runtime_trace_sha256') -match '^[0-9A-F]{64}$')
        'T23' = ($substantive -and $same -and $gatePass.ContainsKey('G23'))
        'T27' = ($substantive -and $same -and $clean -and $gatePass.ContainsKey('G06'))
        'T30' = ($substantive -and $null -ne $t30 -and $foreignOk -and $null -ne (Get-JsonProp $t30roots 'shadow'))
    }
    foreach ($k in $checks.Keys) {
        $out[$k] = [ordered]@{ result = $(if ($checks[$k]) { 'PASS' } else { 'FAIL' }); source = 'DRY_RECEIPT'; receipt_sha256 = $ReceiptSha }
    }
    return $out
}

function Write-StageReceipt([string]$Path, $Rec) {
    # Receipt do estágio: escrita atômica, releitura física única e companion positivo (consumido pelo B07 do QS3).
    $recText = $Rec | ConvertTo-Json -Depth 10
    Write-AtomicText $Path $recText
    $stageSha = Get-BytesSha256 (Read-SharedBytes $Path)
    if ($stageSha -ne (Get-BytesSha256 ($Utf8NoBom.GetBytes($recText)))) { throw 'STAGE_RECEIPT_READBACK_MISMATCH' }
    $comp = [ordered]@{ schema = 'MINOTAURO_PHASE_B_ADAPTER_BOOTSTRAP_RECEIPT_VERIFIED_V001'; receipt_sha256 = $stageSha;
                        attempt_id = $Rec['attempt_id']; stage = $Rec['stage']; final_exit = $Rec['final_exit']; readback = 'PASS' }
    Write-AtomicText ($Path.Substring(0, $Path.Length - 5) + '.VERIFIED.json') ($comp | ConvertTo-Json -Depth 3)
    return $stageSha
}

function Resolve-FinalExit([int]$Code, [int]$StatusFailures, [bool]$FinalStatusWritten) {
    # B08: status incremental/final obrigatório não persistido nunca preserva 0 nem 130 (2 sem efeito provado; 3 se não provado).
    if (($Code -eq 0 -or $Code -eq 130) -and ($StatusFailures -gt 0 -or -not $FinalStatusWritten)) {
        if ($script:Unproven) { return 3 }
        return 2
    }
    return $Code
}

function Test-PriorQS2Receipt([string]$Path, [string]$ExpectedSha, [string]$AdapterIdentity, [string]$ZipSha) {
    # B07: o QS3 exige um QS2 PASS anterior, físico, absoluto, da MESMA identidade de adapter e de ZIP, com o SHA-256
    # completo fixado pelo owner, itens Q01..Q08/T26/T31a PASS e vínculos físicos às evidências da tentativa QS2.
    $r = [ordered]@{ path = $Path; valid = $false; reason = $null; sha256 = $null; attempt_id = $null }
    if ([string]::IsNullOrEmpty($Path) -or $Path.Contains('"') -or -not [System.IO.Path]::IsPathRooted($Path)) { $r.reason = 'PRIOR_QS2_RECEIPT_PATH_NOT_ABSOLUTE'; return $r }
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { $r.reason = 'PRIOR_QS2_RECEIPT_MISSING'; return $r }
    if ($ExpectedSha -notmatch '^[0-9A-Fa-f]{64}$') { $r.reason = 'PRIOR_QS2_RECEIPT_SHA_PARAM_INVALID'; return $r }
    $raw = Read-SharedBytes $Path
    $r.sha256 = Get-BytesSha256 $raw
    if ($r.sha256 -ne $ExpectedSha.ToUpperInvariant()) { $r.reason = 'PRIOR_QS2_RECEIPT_SHA_MISMATCH'; return $r }
    try { $doc = $Utf8NoBom.GetString($raw).TrimStart([char]0xFEFF) | ConvertFrom-Json } catch { $r.reason = 'PRIOR_QS2_RECEIPT_JSON_INVALID'; return $r }
    if ((Get-JsonProp $doc 'schema') -ne 'MINOTAURO_PHASE_B_ADAPTER_BOOTSTRAP_QS2_READONLY_RECEIPT_V001' -or (Get-JsonProp $doc 'stage') -ne 'QS2_READONLY') { $r.reason = 'PRIOR_QS2_SCHEMA_OR_STAGE'; return $r }
    $fe = Get-JsonProp $doc 'final_exit'
    if ($null -eq $fe -or $fe -ne 0) { $r.reason = 'PRIOR_QS2_FINAL_EXIT_NOT_ZERO'; return $r }
    if ((Get-JsonProp $doc 'interrupted') -ne $false -or (Get-JsonProp $doc 'unproven_effect') -ne $false -or $null -ne (Get-JsonProp $doc 'blocked_reason') -or
        (Get-JsonProp $doc 'final_status_written') -ne $true -or (Get-JsonProp $doc 'status_write_failures') -ne 0) { $r.reason = 'PRIOR_QS2_NOT_CLEAN'; return $r }
    $att = [string](Get-JsonProp $doc 'attempt_id')
    $r.attempt_id = $att
    if ($att -notmatch '^\d{8}T\d{6}Z_[0-9a-f]{8}$' -or $att -eq $AttemptId) { $r.reason = 'PRIOR_QS2_ATTEMPT_ID'; return $r }
    $qdir = Join-Path $EvidenceBase $att
    $wantPath = Join-Path $qdir 'QS2_RECEIPT.json'
    if ([System.IO.Path]::GetFullPath($Path) -ne [System.IO.Path]::GetFullPath($wantPath)) { $r.reason = 'PRIOR_QS2_RECEIPT_LOCATION'; return $r }
    $facts = Get-JsonProp $doc 'facts'
    $declaredIdentity = [string](Get-JsonProp $facts 'adapter_identity_sha256')
    $r['adapter_identity'] = $declaredIdentity
    # identidade vazia = fase pré-extração (o chamador compara depois com o manifesto); a comparação final nunca é pulada
    if ($declaredIdentity -notmatch '^[0-9A-F]{64}$' -or ($AdapterIdentity -ne '' -and $declaredIdentity -cne $AdapterIdentity)) { $r.reason = 'PRIOR_QS2_OTHER_ADAPTER'; return $r }
    if ((Get-JsonProp $facts 'package_zip_sha256') -cne $ZipSha) { $r.reason = 'PRIOR_QS2_OTHER_ZIP'; return $r }
    $declared = @(Get-JsonProp $doc 'required_items')
    $items = Get-JsonProp $doc 'items'
    foreach ($q in $RequiredItems['QS2_READONLY']) {
        if ($declared -notcontains $q) { $r.reason = 'PRIOR_QS2_REQUIRED_SET:' + $q; return $r }
        $it = Get-JsonProp $items $q
        if ($null -eq $it) { $r.reason = 'PRIOR_QS2_ITEM_MISSING:' + $q; return $r }
        $want = 'PASS'
        if ($q -eq 'Q05_HOST') { $want = 'COLLECTED' }
        if ((Get-JsonProp $it 'result') -ne $want) { $r.reason = 'PRIOR_QS2_ITEM_NOT_PASS:' + $q; return $r }
    }
    if ((Get-JsonProp (Get-JsonProp (Get-JsonProp $items 'T26') 'historical') 'result') -ne 'PASS') { $r.reason = 'PRIOR_QS2_ITEM_NOT_PASS:T26_HISTORICAL'; return $r }
    # vínculos físicos: cada receipt citado existe na tentativa QS2 e tem o SHA registrado
    $binds = @(
        @('CLASSIFY_B', (Join-Path (Join-Path $qdir 'ADAPTER') 'CLASSIFY_RECEIPT.json')),
        @('T31a', (Join-Path (Join-Path $qdir 'QS2') 'T31A_RECEIPT.json')),
        @('Q07', (Join-Path (Join-Path $qdir 'QS2') 'Q07_RECEIPT.json'))
    )
    foreach ($b in $binds) {
        $rc = Get-JsonProp (Get-JsonProp $items $b[0]) 'receipt'
        $rs = Get-JsonProp $rc 'sha256'
        if ((Get-JsonProp $rc 'valid') -ne $true -or $null -eq $rs -or -not (Test-Path -LiteralPath $b[1] -PathType Leaf) -or (Get-Sha256 $b[1]) -ne $rs) { $r.reason = 'PRIOR_QS2_BINDING:' + $b[0]; return $r }
    }
    # conteúdo físico dos receipts filhos (não basta o SHA): PASS/0, mesma tentativa, mesma identidade, companion e status
    $adapterMap = @{ '0' = 'PASS'; '130' = 'SAFE_STOP'; 'other' = 'NOT_PASS' }
    $probeMap = @{ '0' = 'PASS'; 'other' = 'BLOCKED' }
    $cc = Test-ChildReceipt $binds[0][1] 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $declaredIdentity $adapterMap $att
    if (-not $cc.valid) { $r.reason = 'PRIOR_QS2_CHILD_CONTENT:CLASSIFY_B:' + $cc.reason; return $r }
    $qv = Get-QItems (Get-JsonProp $script:LastReceiptDoc 'qs2_physical') $cc.sha256
    foreach ($q in $qv.Keys) { if ($qv[$q]['result'] -ne 'PASS') { $r.reason = 'PRIOR_QS2_CHILD_CONTENT:' + $q; return $r } }
    $ct = Test-ChildReceipt $binds[1][1] 'MINOTAURO_PHASE_B_ADAPTER_QS2_T31A_RECEIPT_V001' '' 0 '' $probeMap $att
    if (-not $ct.valid) { $r.reason = 'PRIOR_QS2_CHILD_CONTENT:T31a:' + $ct.reason; return $r }
    $cq = Test-ChildReceipt $binds[2][1] 'MINOTAURO_PHASE_B_ADAPTER_QS2_Q07_RECEIPT_V001' '' 0 '' $probeMap $att
    if (-not $cq.valid) { $r.reason = 'PRIOR_QS2_CHILD_CONTENT:Q07:' + $cq.reason; return $r }
    $script:LastReceiptDoc = $null
    $classifySha = Get-JsonProp (Get-JsonProp (Get-JsonProp $items 'CLASSIFY_B') 'receipt') 'sha256'
    foreach ($q in @('Q01', 'Q02', 'Q03', 'Q04', 'Q05', 'Q06_partial')) {
        if ((Get-JsonProp (Get-JsonProp $items $q) 'receipt_sha256') -ne $classifySha) { $r.reason = 'PRIOR_QS2_BINDING:' + $q; return $r }
    }
    $cp = Join-Path $qdir 'QS2_RECEIPT.VERIFIED.json'
    if (-not (Test-Path -LiteralPath $cp -PathType Leaf)) { $r.reason = 'PRIOR_QS2_COMPANION_MISSING'; return $r }
    try { $comp = (Read-SharedText $cp) | ConvertFrom-Json } catch { $r.reason = 'PRIOR_QS2_COMPANION_INVALID'; return $r }
    if ((Get-JsonProp $comp 'receipt_sha256') -ne $r.sha256 -or (Get-JsonProp $comp 'attempt_id') -ne $att -or (Get-JsonProp $comp 'final_exit') -ne 0) { $r.reason = 'PRIOR_QS2_COMPANION_MISMATCH'; return $r }
    $logp = Join-Path $qdir 'BOOTSTRAP.log'
    if (-not (Test-Path -LiteralPath $logp -PathType Leaf)) { $r.reason = 'PRIOR_QS2_LOG_BINDING'; return $r }
    $lines = @((Read-SharedText $logp) -split "`r?`n" | Where-Object { $_ -ne '' })
    $stageLines = @($lines | Where-Object { $_.StartsWith('STAGE_RECEIPT=') })
    if ($stageLines.Count -ne 1 -or $stageLines[0] -cne ('STAGE_RECEIPT=' + $wantPath + ' sha256=' + $r.sha256)) { $r.reason = 'PRIOR_QS2_LOG_BINDING'; return $r }
    $finalLines = @($lines | Where-Object { $_.StartsWith('FINAL_EXIT=') })
    if ($finalLines.Count -ne 1 -or $finalLines[0] -cne 'FINAL_EXIT=0') { $r.reason = 'PRIOR_QS2_LOG_FINAL_EXIT'; return $r }
    # status final do bootstrap QS2: persistido, ACTIVE=NO, final_exit=0 e vinculado por SHA no receipt
    $bsp = Join-Path $qdir 'BOOTSTRAP_STATUS.json'
    $fsha = Get-JsonProp $doc 'final_status_sha256'
    if (-not (Test-Path -LiteralPath $bsp -PathType Leaf) -or $null -eq $fsha) { $r.reason = 'PRIOR_QS2_FINAL_STATUS'; return $r }
    $bsb = Read-SharedBytes $bsp
    if ((Get-BytesSha256 $bsb) -ne $fsha) { $r.reason = 'PRIOR_QS2_FINAL_STATUS'; return $r }
    try { $bsd = $Utf8NoBom.GetString($bsb) | ConvertFrom-Json } catch { $r.reason = 'PRIOR_QS2_FINAL_STATUS'; return $r }
    if ((Get-JsonProp (Get-JsonProp $bsd 'fields') 'ACTIVE') -ne 'NO' -or (Get-JsonProp (Get-JsonProp $bsd 'extra') 'final_exit') -ne 0) { $r.reason = 'PRIOR_QS2_FINAL_STATUS'; return $r }
    $r.valid = $true
    $r.reason = 'OK'
    return $r
}

function Get-StageExit($ItemsTable, $Required) {
    # 0 só se todos os itens exigidos existem e são PASS; 3 se houver efeito não provado / exit 3;
    # 130 se algum item terminou em SAFE_STOP com receipt verificado; senão 2.
    $all = $true
    $three = $script:Unproven
    foreach ($q in $Required) { if (-not $ItemsTable.Contains($q)) { $all = $false } }
    $safeStop = $false
    foreach ($k in $ItemsTable.Keys) {
        $it = $ItemsTable[$k]
        if ($it['result'] -ne 'PASS' -and $it['result'] -ne 'COLLECTED') { $all = $false }
        if ($it.Contains('final_exit') -and $it['final_exit'] -eq 3) { $three = $true }
        if ($it.Contains('final_exit') -and $it['final_exit'] -eq 130) { $safeStop = $true }
    }
    if ($three) { return 3 }
    if ($safeStop) { return 130 }
    if ($all -and $ItemsTable.Count -gt 0) { return 0 }
    return 2
}

# ============================================================================ execução
Write-Host ('RESULT_CONTEXT=ChatGPT | ' + $ProjectLine)
try {
    if ($StageTexts[$Stage] -cne $AuthorizationText) { throw 'STAGE_AUTHORIZATION_TEXT_MISMATCH' }
    if ($Stage -eq 'QS3_DRY' -and ([string]::IsNullOrEmpty($PriorQS2Receipt) -or [string]::IsNullOrEmpty($PriorQS2ReceiptSha256))) { throw 'B07_QS3_REQUIRES_PRIOR_QS2_RECEIPT_AND_SHA256' }
    if ($Stage -eq 'QS2_READONLY' -and (-not [string]::IsNullOrEmpty($PriorQS2Receipt) -or -not [string]::IsNullOrEmpty($PriorQS2ReceiptSha256))) { throw 'PRIOR_QS2_RECEIPT_NOT_APPLICABLE_TO_QS2' }
    if ($Stage -eq 'QS2_READONLY') {
        if ([string]::IsNullOrEmpty($PolicyReceipt)) { throw 'Q07_POLICY_RECEIPT_REQUIRED' }
        if ($PolicyReceipt.Contains('"') -or $PolicyReceipt.EndsWith('\') -or -not [System.IO.Path]::IsPathRooted($PolicyReceipt) -or
            -not (Test-Path -LiteralPath $PolicyReceipt -PathType Leaf)) { throw 'Q07_POLICY_RECEIPT_PATH_INVALID_ABSOLUTE_FILE_REQUIRED' }
    }
    if (-not (Test-Path -LiteralPath $EvidenceBase)) { [void](New-Item -ItemType Directory -Path $EvidenceBase) }
    if (Test-Path -LiteralPath $AttemptDir) { throw 'ATTEMPT_DIR_EXISTS' }
    [void](New-Item -ItemType Directory -Path $AttemptDir)
    Write-Line ('ATTEMPT_ID=' + $AttemptId)
    Write-Line ('STAGE=' + $Stage)
    Write-Line ('LOG=' + $LogPath)
    Write-Line ('STATUS=' + $BootstrapStatusPath)
    Write-Line ('PS_VERSION=' + $PSVersionTable.PSVersion.ToString())
    [void](Set-BootstrapStatus (New-StatusFields 'PREPARE') $null)
    if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'WINDOWS_POWERSHELL_5_1_REQUIRED' }

    if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) { throw 'PYTHON_EXE_MISSING' }
    $pySha = Get-Sha256 $PythonExe
    if ($pySha -ne $PythonSha256) { throw ('PYTHON_EXE_SHA_MISMATCH got=' + $pySha) }
    $Facts['python_exe_sha256'] = $pySha
    if (-not (Test-Path -LiteralPath $PackageZip -PathType Leaf)) { throw 'PACKAGE_ZIP_MISSING' }
    $zipSha = Get-Sha256 $PackageZip
    if ($zipSha -ne $PackageZipSha256.ToUpperInvariant()) { throw ('PACKAGE_ZIP_SHA_MISMATCH got=' + $zipSha) }
    $Facts['package_zip_sha256'] = $zipSha
    Write-Line ('PACKAGE_ZIP_SHA256=' + $zipSha)

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    # B04: identidade do diretório de pacote = SHA-256 COMPLETO (64 hex), nunca prefixo.
    $PackageDir = Join-Path $PackageBase $zipSha
    $AdapterDir = Join-Path $PackageDir 'PHASE_B_ADAPTER_V001'
    $Facts['package_dir'] = $PackageDir
    if ($PackageDir.ToUpperInvariant().StartsWith($ReleaseRoot.ToUpperInvariant())) { throw 'PACKAGE_DIR_INSIDE_RELEASE_ROOT' }
    if ($Stage -eq 'QS3_DRY') {
        # B07 (fase 1, antes da extração): SHA fixado, ZIP, estado limpo, itens, conteúdo e vínculos do QS2 anterior
        $prior0 = Test-PriorQS2Receipt $PriorQS2Receipt $PriorQS2ReceiptSha256 '' $zipSha
        Write-Line ('PRIOR_QS2_PRECHECK=' + $(if ($prior0.valid) { 'PASS' } else { 'FAIL' }) + ' reason=' + $prior0.reason)
        if (-not $prior0.valid) {
            $Items['PRIOR_QS2'] = [ordered]@{ result = 'FAIL'; check = $prior0 }
            throw ('B07_PRIOR_QS2_NOT_PROVEN ' + $prior0.reason)
        }
    }
    $zipFiles = Expand-AdapterPackage $PackageZip $PackageDir
    $Facts['package_zip_file_entries'] = $zipFiles

    $manifest = Join-Path $AdapterDir 'MANIFEST_SHA256.txt'
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw 'ADAPTER_MANIFEST_MISSING' }
    $listed = @{}
    foreach ($line in [System.IO.File]::ReadAllLines($manifest)) {
        if ($line.Trim().Length -eq 0) { continue }
        $parts = $line.Split(@('  '), 2, [System.StringSplitOptions]::None)
        $listed[$parts[1]] = $parts[0].ToUpperInvariant()
    }
    foreach ($rel in $listed.Keys) {
        $p = Join-Path $AdapterDir ($rel.Replace('/', '\'))
        if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { throw ('ADAPTER_MEMBER_MISSING ' + $rel) }
        if ((Get-Sha256 $p) -ne $listed[$rel]) { throw ('ADAPTER_MEMBER_HASH ' + $rel) }
    }
    $actual = @(Get-ChildItem -LiteralPath $AdapterDir -Recurse -File -Force | ForEach-Object { $_.FullName.Substring($AdapterDir.Length + 1).Replace('\', '/') })
    foreach ($rel in $actual) {
        if (($rel -ne 'MANIFEST_SHA256.txt') -and ($rel -ne 'ADAPTER_IDENTITY.json') -and (-not $listed.ContainsKey($rel))) { throw ('ADAPTER_EXTRA_FILE ' + $rel) }
    }
    $manifestSha = Get-Sha256 $manifest
    $identityDoc = (Read-SharedText (Join-Path $AdapterDir 'ADAPTER_IDENTITY.json')) | ConvertFrom-Json
    $AdapterIdentity = [string](Get-JsonProp $identityDoc 'adapter_identity_sha256')
    if ($AdapterIdentity -ne $manifestSha) { throw 'ADAPTER_IDENTITY_NE_MANIFEST' }
    $Facts['adapter_identity_sha256'] = $AdapterIdentity
    Write-Line ('ADAPTER_MANIFEST_SHA256=' + $manifestSha)
    Write-Line ('ADAPTER_IDENTITY_SHA256=' + $AdapterIdentity)
    Write-Line 'ADAPTER_PAYLOAD=PASS'
    $script:Checkpoint = 'ADAPTER_PAYLOAD'

    $probe = Join-Path $AdapterDir 'qualification\probe_exit.py'
    $probePs = Join-Path $AdapterDir 'qualification\probe_exit_ps.ps1'
    $qs2Probe = Join-Path $AdapterDir 'qualification\qs2_target_probe.py'
    $entryPy = Join-Path $AdapterDir 'phase_b_entry.py'
    $adapterStatus = Join-Path (Join-Path $AttemptDir 'ADAPTER') 'ADAPTER_STATUS.json'
    $adapterResults = @{ '0' = 'PASS'; '130' = 'SAFE_STOP'; 'other' = 'NOT_PASS' }
    $probeResults = @{ '0' = 'PASS'; 'other' = 'BLOCKED' }

    if ($Stage -eq 'QS3_DRY') {
        # B07: antes de QUALQUER trabalho substantivo (T26, dry-run): QS2 PASS anterior provado e vinculado
        $prior = Test-PriorQS2Receipt $PriorQS2Receipt $PriorQS2ReceiptSha256 $AdapterIdentity $zipSha
        $Items['PRIOR_QS2'] = [ordered]@{ result = $(if ($prior.valid) { 'PASS' } else { 'FAIL' }); check = $prior }
        $Facts['prior_qs2_receipt_path'] = $prior.path
        $Facts['prior_qs2_receipt_sha256'] = $prior.sha256
        $Facts['prior_qs2_attempt_id'] = $prior.attempt_id
        Write-Line ('PRIOR_QS2=' + $Items['PRIOR_QS2']['result'] + ' reason=' + $prior.reason + ' sha256=' + $prior.sha256 + ' attempt=' + $prior.attempt_id)
        if (-not $prior.valid) { throw ('B07_PRIOR_QS2_NOT_PROVEN ' + $prior.reason) }
        $script:Checkpoint = 'PRIOR_QS2'
    }

    $t26 = Invoke-T26Probes $probe $AdapterDir
    $t26['historical'] = Invoke-T26HistoricalPattern $probe $AdapterDir
    if ($t26['historical']['result'] -ne 'PASS') { $t26['result'] = 'FAIL' }
    $Items['T26'] = $t26
    Write-Line ('T26=' + $t26['result'])
    if ($t26['result'] -ne 'PASS') { throw 'T26_NATIVE_EXIT_OR_STDERR_CAPTURE_NOT_QUALIFIED' }
    $script:Checkpoint = 'T26'

    if ($Stage -eq 'QS2_READONLY') {
        if (-not (Test-Path -LiteralPath $WindowsPsExe -PathType Leaf)) { throw 'WINDOWS_POWERSHELL_EXE_MISSING' }
        $q08 = Invoke-Q08 $probePs $probe $AdapterDir
        $Items['Q08'] = $q08
        Write-Line ('Q08=' + $q08['result'])
        if ($q08['result'] -ne 'PASS') { throw 'Q08_POWERSHELL_EXIT_PROPAGATION_NOT_QUALIFIED' }
        $script:Checkpoint = 'Q08'

        $Items['Q05_HOST'] = [ordered]@{ result = 'COLLECTED'; host = (Get-HostQ05) }
        Write-Line 'Q05_HOST=COLLECTED'

        $script:AdapterChildStarted = $true
        $cs = Invoke-Child $PythonExe ('-B "' + $entryPy + '" status-b') $AdapterDir 'STATUS_B' $WatchdogSeconds['STATUS_B'] ''
        if ($cs.Completed -and $cs.StderrComplete -and $cs.ExitCode -eq 0) { $sbExit = 0 }
        elseif ($cs.Completed -and $cs.StderrComplete -and $cs.ExitCode -eq 2) { $sbExit = 2 }
        else { $sbExit = 3; $script:Unproven = $true }
        $Items['STATUS_B'] = [ordered]@{ result = $(if ($sbExit -eq 0) { 'PASS' } else { 'FAIL' }); native_exit = $cs.ExitCode; final_exit = $sbExit;
                                         stderr_sha256 = $cs.StderrSha256; note = 'structural status, no receipt by design; authoritative state = CLASSIFY_RECEIPT' }
        if ($sbExit -ne 0) { Write-Line ('STATUS_B_OUTCOME native_exit=' + $cs.ExitCode + ' final_exit=' + $sbExit + ' stderr_sha256=' + $cs.StderrSha256) }

        $cc = Invoke-Child $PythonExe ('-B "' + $entryPy + '" classify-b --attempt-id ' + $AttemptId) $AdapterDir 'CLASSIFY_B' $WatchdogSeconds['CLASSIFY_B'] $adapterStatus
        $rc = Test-ChildReceipt (Join-Path (Join-Path $AttemptDir 'ADAPTER') 'CLASSIFY_RECEIPT.json') 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' $cc.ExitCode $AdapterIdentity $adapterResults
        $oc = Resolve-ChildOutcome $cc $rc 'CLASSIFY_B'
        $oc['result'] = $(if ($oc.final_exit -eq 0) { 'PASS' } else { 'FAIL' })
        if ($oc['result'] -eq 'PASS') {
            $doc = $script:LastReceiptDoc
            $qItems = Get-QItems (Get-JsonProp $doc 'qs2_physical') $rc.sha256
            foreach ($q in $qItems.Keys) { $Items[$q] = $qItems[$q]; Write-Line ($q + '=' + $qItems[$q]['result'] + ' reasons=' + ($qItems[$q]['reasons'] -join ';')) }
        }
        $Items['CLASSIFY_B'] = $oc
        Write-Line ('CLASSIFY_B=' + $oc['result'])
        $script:Checkpoint = 'CLASSIFY_B'

        $ct = Invoke-Child $PythonExe ('-B "' + $qs2Probe + '" t31a --attempt-id ' + $AttemptId) $AdapterDir 'T31A' $WatchdogSeconds['T31A'] ''
        $rt = Test-ChildReceipt (Join-Path (Join-Path $AttemptDir 'QS2') 'T31A_RECEIPT.json') 'MINOTAURO_PHASE_B_ADAPTER_QS2_T31A_RECEIPT_V001' '' $ct.ExitCode '' $probeResults
        $ot = Resolve-ChildOutcome $ct $rt 'T31A'
        $ot['result'] = $(if ($ot.final_exit -eq 0) { 'PASS' } else { 'FAIL' })
        $Items['T31a'] = $ot
        Write-Line ('T31a=' + $ot['result'])
        $script:Checkpoint = 'T31a'

        $cq = Invoke-Child $PythonExe ('-B "' + $qs2Probe + '" q07 --attempt-id ' + $AttemptId + ' --policy-receipt "' + $PolicyReceipt + '"') $AdapterDir 'Q07' $WatchdogSeconds['Q07'] ''
        $rq = Test-ChildReceipt (Join-Path (Join-Path $AttemptDir 'QS2') 'Q07_RECEIPT.json') 'MINOTAURO_PHASE_B_ADAPTER_QS2_Q07_RECEIPT_V001' '' $cq.ExitCode '' $probeResults
        $oq = Resolve-ChildOutcome $cq $rq 'Q07'
        $oq['result'] = $(if ($oq.final_exit -eq 0) { 'PASS' } else { 'FAIL' })
        $Items['Q07'] = $oq
        Write-Line ('Q07=' + $oq['result'])
        $script:Checkpoint = 'Q07'
    }
    elseif ($Stage -eq 'QS3_DRY') {
        $script:AdapterChildStarted = $true
        $cd = Invoke-Child $PythonExe ('-B "' + $entryPy + '" dry-run-b --attempt-id ' + $AttemptId) $AdapterDir 'DRY_RUN_B' $WatchdogSeconds['DRY_RUN_B'] $adapterStatus
        $rd = Test-ChildReceipt (Join-Path (Join-Path $AttemptDir 'ADAPTER') 'DRY_RECEIPT.json') 'MINOTAURO_PHASE_B_ADAPTER_DRY_RECEIPT_V001' 'DRY' $cd.ExitCode $AdapterIdentity $adapterResults
        $od = Resolve-ChildOutcome $cd $rd 'DRY_RUN_B'
        $od['result'] = $(if ($od.final_exit -eq 0) { 'PASS' } else { 'FAIL' })
        $Items['DRY_RUN_B'] = $od
        Write-Line ('DRY_RUN_B=' + $od['result'])
        if ($od['result'] -eq 'PASS') {
            $dItems = Get-DryItems $script:LastReceiptDoc $rd.sha256
            foreach ($q in $dItems.Keys) { $Items[$q] = $dItems[$q]; Write-Line ($q + '=' + $dItems[$q]['result']) }
        }
        $script:Checkpoint = 'DRY_RUN_B'
    }
    $FinalCode = Get-StageExit $Items $RequiredItems[$Stage]
    $script:MainCompleted = $true
}
catch {
    $script:MainCompleted = $true
    $BlockedReason = $_.Exception.Message
    Write-Line ('BOOTSTRAP_BLOCKED=' + $BlockedReason)
    Write-Line ('BOOTSTRAP_FRONTIER=' + $Frontier)
    if ($script:AdapterChildStarted -or $script:Unproven) { $FinalCode = 3 } else { $FinalCode = 2 }
}
finally {
    if (-not $script:MainCompleted) {
        # interrupção do próprio bootstrap (ex.: Ctrl+C): nenhum kill; exit coerente com o log
        $BlockedReason = 'BOOTSTRAP_INTERRUPTED'
        if ($script:AdapterChildStarted -or $script:Unproven) { $FinalCode = 3 } else { $FinalCode = 2 }
        Write-Line ('BOOTSTRAP_INTERRUPTED=YES auto_kill=NO final_exit=' + $FinalCode + ' RECONCILIATION_REQUIRED=' + $(if ($FinalCode -eq 3) { 'YES' } else { 'NO' }))
    }
    if (Test-Path -LiteralPath $AttemptDir) {
        $ff = New-StatusFields 'FINISHED'
        $ff['ACTIVE'] = 'NO'
        $ff['ETA'] = Format-Eta 0
        $ff['FINISH'] = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
        # B08: falhas anteriores do status incremental obrigatório nunca preservam 0/130 (antes do status final)
        $pre = $FinalCode
        $FinalCode = Resolve-FinalExit $FinalCode $script:StatusWriteFailures $true
        $script:FinalStatusWritten = Set-BootstrapStatus $ff ([ordered]@{ final_exit = $FinalCode; stage_receipt = $StageReceiptPath })
        # B08: status final ACTIVE=NO persistido e relido ANTES do receipt do estágio
        $FinalCode = Resolve-FinalExit $FinalCode $script:StatusWriteFailures $script:FinalStatusWritten
        if ($FinalCode -ne $pre) { Write-Line ('STATUS_PERSISTENCE_FAILED failures=' + $script:StatusWriteFailures + ' final_status_written=' + $script:FinalStatusWritten + ' exit=' + $pre + '->' + $FinalCode + ' PASS_REFUSED') }
        try {
            $rec = [ordered]@{}
            $rec['schema'] = 'MINOTAURO_PHASE_B_ADAPTER_BOOTSTRAP_' + $Stage + '_RECEIPT_V001'
            $rec['attempt_id'] = $AttemptId
            $rec['stage'] = $Stage
            $rec['facts'] = $Facts
            $rec['items'] = $Items
            $rec['required_items'] = $RequiredItems[$Stage]
            $rec['blocked_reason'] = $BlockedReason
            $rec['frontier'] = $Frontier
            $rec['unproven_effect'] = $script:Unproven
            $rec['interrupted'] = (-not $script:MainCompleted)
            $rec['status_write_failures'] = $script:StatusWriteFailures
            $rec['final_status_written'] = $script:FinalStatusWritten
            $rec['final_status_sha256'] = $(if ($script:FinalStatusWritten) { $script:LastStatusSha256 } else { $null })
            $rec['final_exit'] = $FinalCode
            $rec['auto_kill'] = 'NO'
            $stageSha = Write-StageReceipt $StageReceiptPath $rec
            Write-Line ('STAGE_RECEIPT=' + $StageReceiptPath + ' sha256=' + $stageSha)
        }
        catch {
            Write-Line ('STAGE_RECEIPT_WRITE=FAILED ' + $_.Exception.GetType().Name)
            # receipt residual (gravado antes da falha do companion) é invalidado por renomeação; nada é apagado
            if ([System.IO.File]::Exists($StageReceiptPath)) {
                try { [System.IO.File]::Move($StageReceiptPath, $StageReceiptPath + '.INVALIDATED.' + $Nonce) } catch { Write-Line 'STAGE_RECEIPT_RESIDUAL_NOT_INVALIDATED' }
            }
            if ($FinalCode -eq 0 -or $FinalCode -eq 130) {
                if ($script:Unproven) { $FinalCode = 3 } else { $FinalCode = 2 }
                [void](Set-BootstrapStatus $ff ([ordered]@{ final_exit = $FinalCode; stage_receipt = 'NOT_WRITTEN' }))
            }
        }
    }
    Write-Line ('FINAL_EXIT=' + $FinalCode)
    Write-Line 'BLIND_RETRY=FORBIDDEN'
    Write-Host ('RESULT_RETURN_TO=ChatGPT | ' + $ProjectLine)
    if (-not $script:MainCompleted) { [Environment]::Exit($FinalCode) }
}
exit $FinalCode
