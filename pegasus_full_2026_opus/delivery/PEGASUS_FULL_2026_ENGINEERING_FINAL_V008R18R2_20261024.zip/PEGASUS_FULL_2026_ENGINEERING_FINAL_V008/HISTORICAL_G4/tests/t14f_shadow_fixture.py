"""PHASE_B_ADAPTER_V001 — T14F: fixture Linux do caminho compartilhado DRY (dry_flow de produção).

Mundo de fixture: cwd temporário onde os caminhos literais Windows do CODE congelado
('D:\\Base CSV\\...', 'D:\\MinotauroRuns\\...PERF_NEXT...') existem como nomes literais (POSIX trata '\\'
como caractere comum). Ticks = arquivos esparsos com o tamanho exato do E01 (conteúdo NÃO real);
M1 2025-12 = barra SINTÉTICA 2025-12-30 (único predecessor fora da coleta). Nenhum dado real é inventado
como fato: o que se prova é o encadeamento de gates e a reprodução byte a byte dos 21 PREPARED.

Esperado: dry_flow percorre G01..G21 e entra no run_phase congelado (SEAM-D1 executado em full:297);
para em RunLock.__enter__ (Win32) com MemoryProbeError('WINDOWS_REQUIRED') — fronteira da sandbox.
CONTROL, PREFLIGHT e CODE da fixture ficam byte-idênticos; receipt classificado com exit 2.

Cenários adicionais (B01/B02/B03/B05) no MESMO mundo literal, um por subprocesso (o CODE congelado
só pode ser importado uma vez por processo — CODE_MODULE_PRELOADED):
  CL_PASS              classify_flow PASS -> finish 0; CLASSIFY_RECEIPT verificado; qs2_physical Q01..Q06_partial;
                       ADAPTER_STATUS.json final com os 11 campos canônicos.
  CL_PREFLIGHT_DRIFT   deriva de PREFLIGHT no caminho de PASS -> 3 (PROTECTED_INPUT_CHANGED_ON_PASS_PATH)
  CL_CODE_DRIFT        deriva de CODE (bytecode) no caminho de PASS -> 3
  CL_RECEIPT_FAIL      falha de gravação do receipt no caminho de PASS -> 2 (nunca 0)
  CL_READBACK_FAIL     receipt gravado mas verificação física divergente -> 2 (nunca 0)
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import sys
import tempfile
import time
from contextlib import redirect_stdout
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import qs1_fixtures as fx  # noqa: E402

from phase_b_effects import canonical_bytes, inventory, inventory_digest, sha256_file  # noqa: E402


def sparse(path: Path, size: int):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as f:
        f.truncate(size)


def zero_sha(size: int) -> str:
    h = hashlib.sha256()
    block = b"\0" * (8 * 1024 * 1024)
    left = size
    while left:
        n = min(left, len(block))
        h.update(block[:n] if n != len(block) else block)
        left -= n
    return h.hexdigest().upper()


def build_world(work: Path):
    """Constrói o mundo literal no cwd = work. Retorna (ps, s, plat, C, C2, control, pre, rel)."""
    P = fx.payload()
    C = fx.constants()
    if True:
        lit = C["frozen_literals"]
        # entradas literais
        ind = Path(lit["ind_d1"]); ind.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(P / "DATA" / "IND_D1.csv", ind)
        m1 = Path(lit["m1_root"]); m1.mkdir(parents=True)
        for f in sorted((P / "M1_2026").glob("*.csv")):
            shutil.copyfile(f, m1 / f.name)
        (m1 / "WIN@N_M1_2025_12.csv").write_text(  # SINTÉTICO: só fornece a sessão predecessora 2025-12-30
            "WIN@N;M1;2025.12.30;09:00:00;1.00;1.00;1.00;1.00;1;1;1.00;0;0\n", encoding="utf-8")
        tick_shas = {}
        for t in C["inputs"]["ticks"]:
            sparse(Path(t["path"]), int(t["bytes"]))
            tick_shas[t["path"]] = zero_sha(int(t["bytes"]))
        parent = Path(lit["parent_2025"])
        (parent / "GATES").mkdir(parents=True); (parent / "PHASE_A").mkdir(parents=True)
        shutil.copyfile(P / "PARENT_2025" / "GATES" / "CORRECTNESS_FULL_HOMOLOGATION_RECEIPT.json",
                        parent / "GATES" / "CORRECTNESS_FULL_HOMOLOGATION_RECEIPT.json")
        shutil.copyfile(P / "PARENT_2025" / "PHASE_A" / "SELECTION_FREEZE.json", parent / "PHASE_A" / "SELECTION_FREEZE.json")
        # raízes owned de fixture
        rel = work / "RELEASE"; rel.mkdir()
        shutil.copytree(P / "CODE", rel / "CODE")
        control = fx.copy_control(rel / "CONTROL")
        pre = fx.copy_preflight(rel / "PREFLIGHT")
        for f in ("G8_RELEASE_RECEIPT.json", "G8_DRY_RUN_RELEASE_FF_CUTOFF_R3_20261001_EVIDENCE.zip"):
            shutil.copyfile(P / "RELEASE" / f, rel / f)
        sys.path.insert(0, str(fx.ADAPTER))
        import phase_b_shared as ps
        lay = ps.Layout(release_root=str(rel), code_root=str(rel / "CODE"), control_root=str(control),
                        preflight_root=str(pre), shadow_base=str(work / "SHADOW"), evidence_base=str(work / "EVIDENCE"),
                        base_csv_root=str(work / "D:\\Base CSV"), ind_d1=lit["ind_d1"], m1_root=lit["m1_root"],
                        parent_2025_root=lit["parent_2025"], g8_local_receipt=str(rel / "G8_RELEASE_RECEIPT.json"),
                        g8_evidence_zip=str(rel / "G8_DRY_RUN_RELEASE_FF_CUTOFF_R3_20261001_EVIDENCE.zip"),
                        phase_b_evidence_zip=str(rel / "PHASE_B_2026_FF_CUTOFF_R3_20261001_EVIDENCE.zip"),
                        package_root=str(fx.ADAPTER))
        # constantes de fixture: única diferença legítima = preflight_source_root (caminho) na configuração
        # e SHA dos ticks esparsos (o binding continua usando os SHAs reais do SOURCE_INVENTORY)
        cfg = json.loads((control / "FULL_2026_CONFIGURATION.json").read_text(encoding="utf-8"))
        cfg["preflight_source_root"] = str(pre.resolve())
        raw = json.dumps(cfg, ensure_ascii=False, indent=2).encode()
        (control / "FULL_2026_CONFIGURATION.json").write_bytes(raw)
        C2 = json.loads(json.dumps({k: v for k, v in C.items() if k != "_sha256"}))
        C2["_sha256"] = C["_sha256"]
        C2["config"]["sha256"] = sha256_file(control / "FULL_2026_CONFIGURATION.json")
        for e in C2["control_prepared"]["files"]:
            if e["path"] == "FULL_2026_CONFIGURATION.json":
                e["sha256"], e["bytes"] = C2["config"]["sha256"], len(raw)
        for t in C2["inputs"]["ticks"]:
            t["sha256"] = tick_shas[t["path"]]
        plat = fx.FakePlatform(observed={k: C["runtime"][k] for k in ("python_exe", "python_exe_sha256", "python_version", "numpy", "numpy_origin")})
        return ps, lay, plat, C, C2, control, pre, rel


def synthetic_parent_sessions(lit: dict) -> list:
    """SINTÉTICO (rotulado): 5 sessões do pai com tamanhos conhecidos, só para provar o cálculo do Q06_partial."""
    root = Path(lit["parent_2025"]) / "PHASE_A" / "sessions"
    sizes = [100, 300, 200, 500, 400]
    for i, n in enumerate(sizes):
        d = root / f"2025-01-0{i + 2}"
        d.mkdir(parents=True)
        (d / "trades.jsonl.gz").write_bytes(b"\0" * n)
    return sizes


def main_t14f():
    work = Path(tempfile.mkdtemp(prefix="t14f_"))
    os.chdir(work)
    try:
        ps, lay, plat, C, C2, control, pre, rel = build_world(work)
        s = ps.Session(mode="DRY", layout=lay, constants=C2, platform=plat, attempt_id="20261003T000000Z_0000f14f")
        s.started_ns = time.time_ns()
        s.open_evidence()
        before = {k: inventory_digest(inventory(p)) for k, p in (("control", control), ("preflight", pre), ("code", rel / "CODE"))}
        err = None
        buf = io.StringIO()
        try:
            with redirect_stdout(buf):
                ps.dry_flow(s, platform_tolerant=frozenset(C["platform_dependent_prepared_files"]["files"]))
        except Exception as e:  # noqa: BLE001
            err = e
        finally:
            ps._release_mutexes(s)
        out = buf.getvalue()
        sys.stdout.write(out[-3000:])
        ids = [g["id"] for g in s.gates]
        want = ["G01", "G02", "G03", "G04", "G05", "G06", "G07", "G08", "G09", "G10", "G11", "G12", "G13", "G14", "G15",
                "G16", "G17", "G18", "G20", "G21"]
        assert ids == want, ids
        assert all(g["status"] == "PASS" for g in s.gates), s.gates
        assert type(err).__name__ == "MemoryProbeError" and "WINDOWS_REQUIRED" in str(err), repr(err)
        assert s.record["state"] == "PREPARED"
        assert s.record.get("d1b_at_use", {}).get("sessions") == 166, s.record.get("d1b_at_use")
        assert s.frozen.base._load_d1_extract is s.frozen.orig_load_d1_extract
        assert s.frozen.coord.ParallelSession.__dict__["process_record"] is s.frozen.orig_process_record
        assert plat.held == {}, plat.held
        g18 = [g for g in s.gates if g["id"] == "G18"][0]
        after = {k: inventory_digest(inventory(p)) for k, p in (("control", control), ("preflight", pre), ("code", rel / "CODE"))}
        assert before == after, (before, after)
        shadow = Path(s.record["shadow_root"])
        sb = json.loads((shadow / "PHASE_B" / "RUN_SOURCE_BINDING_B.json").read_text())
        assert sha256_file(shadow / "PHASE_B" / "RUN_SOURCE_BINDING_B.json") == C["d1b"]["binding_sha256"]
        assert sha256_file(shadow / "PHASE_B" / "D1_PREDECESSOR_EXTRACT_PHASE_B.csv") == C["d1b"]["extract_sha256"]
        assert "PREFLIGHT_PHASE_B_REUSE" in "\n".join(s.tee.lines)
        code = ps.finish(s, "ERROR", {"code": type(err).__name__, "detail": str(err)})
        assert code == 2, code
        rec = json.loads((s.evidence_dir / "DRY_RECEIPT.json").read_text())
        assert rec["result"] == "NOT_PASS" and rec["labels"]["PARTIAL_EFFECT"] == "NO"
        assert rec["exit_code"] == 2 and rec["attempt_id"] == s.attempt_id
        assert (s.evidence_dir / "DRY_RECEIPT.json").stat().st_size < 1024 * 1024
        check_final_status(s, 2)
        print("T14F_GATES=" + ",".join(ids))
        print("T14F_SHADOW_BINDING_SHA256=" + sha256_file(shadow / "PHASE_B" / "RUN_SOURCE_BINDING_B.json"))
        print("T14F_SANDBOX_BOUNDARY=" + type(err).__name__ + ":" + str(err))
        print("T14F_G18_INPUT_SHA256=" + g18["input_sha256"])
        print("T14F=PASS")
    finally:
        os.chdir("/")
        shutil.rmtree(work, ignore_errors=True)


def check_final_status(s, code: int) -> dict:
    from phase_b_effects import STATUS_FIELDS
    import re
    st = json.loads((s.evidence_dir / "ADAPTER_STATUS.json").read_text())
    f = st["fields"]
    assert set(f) == set(STATUS_FIELDS) and st["field_order"] == list(STATUS_FIELDS), list(f)
    assert f["ACTIVE"] == "NO" and f["PHASE"] == "FINISHED", f
    assert re.fullmatch(r"\d+\.\d{2}\.\d{2}\.\d{2}|UNKNOWN", f["ETA"]), f["ETA"]
    assert st["extra"]["exit_code"] == code, st
    assert not list(s.evidence_dir.glob("*.tmp")), "status tmp residue"
    log = (s.evidence_dir / "ADAPTER.log").read_text()
    assert "HEARTBEAT PHASE=" in log and all(k + "=" in log for k in STATUS_FIELDS)
    return st


def main_classify(scenario: str):
    work = Path(tempfile.mkdtemp(prefix="tcl_"))
    os.chdir(work)
    try:
        ps, lay, plat, C, C2, control, pre, rel = build_world(work)
        sizes = synthetic_parent_sessions(C["frozen_literals"])
        s = ps.Session(mode="CLASSIFY", layout=lay, constants=C2, platform=plat,
                       attempt_id="20261003T000000Z_0000c1a5")
        s.started_ns = time.time_ns()
        s.open_evidence()
        buf = io.StringIO()
        with redirect_stdout(buf):
            r = ps.classify_flow(s, with_tick_rehash=False)
        ps._release_mutexes(s)
        assert r["state"] == "PREPARED", r
        if scenario == "CL_PREFLIGHT_DRIFT":
            f = pre / "PHASE_B" / "PHASE_STATUS.json"
            f.write_bytes(f.read_bytes() + b" ")
        elif scenario == "CL_CODE_DRIFT":
            (rel / "CODE" / "__pycache__").mkdir()
            (rel / "CODE" / "__pycache__" / "r1r11_full_2026.cpython-314.pyc").write_bytes(b"x")
        elif scenario == "CL_RECEIPT_FAIL":
            def boom(name, obj):
                raise OSError("SIMULATED_RECEIPT_WRITE_FAILURE")
            s.write_evidence = boom
        elif scenario == "CL_READBACK_FAIL":
            orig = s.write_evidence
            s.write_evidence = lambda name, obj: (orig(name, obj), "0" * 64)[1]
        with redirect_stdout(buf):
            code = ps.finish(s, "PASS", None)
        out = buf.getvalue()
        name = s.evidence_dir / "CLASSIFY_RECEIPT.json"
        if scenario == "CL_PASS":
            assert code == 0, (code, out[-2000:])
            rec = json.loads(name.read_text())
            assert rec["exit_code"] == 0 and rec["result"] == "PASS" and rec["labels"] == {"PARTIAL_EFFECT": "NO"}, rec["labels"]
            q = rec["qs2_physical"]
            assert set(q) == {"Q01", "Q02", "Q03", "Q04", "Q05", "Q06_partial"}, sorted(q)
            assert q["Q01"]["control_files"] == 23 and len(q["Q01"]["control_inventory"]) == 23
            assert all(len(v["sha256"]) == 64 for v in q["Q01"]["control_inventory"].values())
            assert q["Q01"]["preflight_files"] == 16
            assert q["Q02"]["equal"] is True
            assert q["Q03"]["files"] == len(q["Q03"]["inventory"]) > 0
            assert all(set(x) == {"name", "bytes", "sha256"} for x in q["Q03"]["inventory"])
            assert len(q["Q04"]["ticks"]) == 8 and all(isinstance(t["file_id_st_ino"], int) for t in q["Q04"]["ticks"])
            assert q["Q04"]["total_bytes"] == q["Q04"]["expected_total_bytes"]
            assert q["Q05"]["runtime_observed"]["python_version"] == C["runtime"]["python_version"]
            assert q["Q05"]["host"]["logical_cpus"] >= 1
            ps6 = q["Q06_partial"]["parent_sessions"]
            assert ps6["count"] == 5 and ps6["total_bytes"] == sum(sizes) and ps6["max_bytes"] == 500
            assert ps6["p50_bytes"] == 300 and ps6["p95_bytes"] == 500
            assert q["Q06_partial"]["control_telemetry"]["status"] == "ABSENT_IN_CURRENT_STATE"  # PREPARED: sem TELEMETRY
            # vereditos substantivos (B03): a fixture NÃO tem M1 2024-01..2025-11 nem host Win32 => FAIL rotulado
            v = {k: q[k]["verdict"] for k in q}
            assert v == {"Q01": "PASS", "Q02": "PASS", "Q03": "FAIL", "Q04": "PASS", "Q05": "FAIL", "Q06_partial": "PASS"}, v
            assert any(r.startswith("M1_MONTHS_MISSING:2024-01") for r in q["Q03"]["reasons"]), q["Q03"]["reasons"]
            assert "HOST_FIXTURE" in q["Q05"]["reasons"], q["Q05"]["reasons"]
            comp = json.loads((s.evidence_dir / "CLASSIFY_RECEIPT.VERIFIED.json").read_text())
            assert comp["receipt_sha256"] == sha256_file(name) and comp["exit_code"] == 0 and comp["mode"] == "CLASSIFY"
            assert "RECEIPT=CLASSIFY_RECEIPT.json" in out and "verified=YES" in out
            # Windows PowerShell 5.1 ConvertFrom-Json: limite histórico de 2 MiB (JavaScriptSerializer)
            assert name.stat().st_size < 1024 * 1024, name.stat().st_size
            print("CL_PASS_RECEIPT_BYTES=" + str(name.stat().st_size))
        elif scenario in ("CL_PREFLIGHT_DRIFT", "CL_CODE_DRIFT"):
            assert code == 3, (code, out[-2000:])
            rec = json.loads(name.read_text())
            assert rec["exit_code"] == 3 and rec["result"] == "NOT_PASS"
            assert rec["labels"]["INCIDENT"] == "PROTECTED_INPUT_CHANGED_ON_PASS_PATH", rec["labels"]
            want = "preflight" if scenario == "CL_PREFLIGHT_DRIFT" else "code"
            assert rec["protected_delta_at_finish"] == [want], rec["protected_delta_at_finish"]
        elif scenario == "CL_RECEIPT_FAIL":
            assert code == 2, (code, out[-2000:])
            assert not name.exists()
            assert "RECEIPT_WRITTEN=NO" in out and "RECEIPT_DOWNGRADE=0->2" in out, out[-2000:]
        elif scenario == "CL_READBACK_FAIL":
            assert code == 2, (code, out[-2000:])
            assert not (s.evidence_dir / "CLASSIFY_RECEIPT.VERIFIED.json").exists()  # sem companion: nunca aceito
            assert "RECEIPT_ERROR=AdapterBlocked" in out and "RECEIPT_DOWNGRADE=0->2" in out, out[-2000:]
        else:
            raise SystemExit("unknown scenario " + scenario)
        check_final_status(s, code)
        print(f"{scenario}=PASS exit={code}")
    finally:
        os.chdir("/")
        shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    arg = sys.argv[1] if len(sys.argv) > 1 else "T14F"
    if arg == "T14F":
        main_t14f()
    else:
        main_classify(arg)
