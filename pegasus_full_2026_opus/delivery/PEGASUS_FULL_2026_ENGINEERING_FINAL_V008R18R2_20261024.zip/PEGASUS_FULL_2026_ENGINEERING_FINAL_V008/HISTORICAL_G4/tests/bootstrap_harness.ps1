<#
PHASE_B_ADAPTER_V001 - QS1 harness do BOOTSTRAP (sandbox; pwsh). Carrega SOMENTE as definicoes de funcao do
BOOTSTRAP_PHASE_B_ADAPTER.ps1 via AST (o corpo principal nao e executado) e exercita, com filhos Python reais
pela mesma fronteira System.Diagnostics.Process:
  H1 T26 exit nativo 0/2/3/7/130 + captura de stderr (bytes deterministicos)
  H2 T26 padrao historico -999 (sentinela dentro de & { }) classificado como medicao invalida
  H3 watchdog expirado SEM auto-kill (filho continua vivo; sem PASS; reconciliacao) + heartbeat + status atomico
  H4 heartbeat incorporando ADAPTER_STATUS.json (campos canonicos)
  H5 verificacao fisica de receipt (B02) e preservacao de exit nativo + SHA-256 do stderr (B06)
  H6 Format-Eta (D.HH.MM.SS | UNKNOWN)
  H7 Write-AtomicText (substituicao) e Get-StageExit
  H8 Q08 analogo (pwsh -File probe_exit_ps.ps1 -> python) 0/2/3/7/130
  H9 Get-HostQ05 nao lanca fora do Windows (antivirus/exclusoes UNAVAILABLE)
  H10 stderr em bytes brutos (nao UTF-8) com SHA-256 exato
  H11 pipe de stderr retido por descendente: espera limitada, sem PASS, reconciliacao
  H12 QS3: itens T02/T11c/T14/T19_template/T23/T27/T30 so PASS com prova substantiva no DRY_RECEIPT
  H13 QS2: Q01..Q06_partial pelo veredito substantivo (nunca por presenca)
  H14 pacote: extracao em staging + troca de nome; reuso conferido contra o ZIP; adulteracao/extra bloqueiam
  H15 B08: status obrigatorio nao persistido (falha total, apos heartbeats, so a final) nunca preserva 0/130
  H16 B07: QS3 so com QS2 PASS anterior provado (positivo + 22 negativos, conteudo fisico dos filhos), via a mesma funcao do bootstrap
Somente ASCII. Limitacao declarada: pwsh 7 em Linux, nao Windows PowerShell 5.1.
#>
param(
    [Parameter(Mandatory = $true)][string]$Bootstrap,
    [Parameter(Mandatory = $true)][string]$Python,
    [Parameter(Mandatory = $true)][string]$Adapter,
    [Parameter(Mandatory = $true)][string]$Work,
    [Parameter(Mandatory = $true)][string]$Pwsh
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$StatusFields = @('PHASE', 'PROGRESS', 'COMMITTED', 'TOTAL', 'RATE', 'ETA', 'FINISH', 'ACTIVE', 'READY_WAITING', 'CHECKPOINT', 'SAFE_STOP')
$HeartbeatMs = 1000
$StderrDrainMs = 60000
$Nonce = '0000beef'
$Frontier = 'NONE'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$WatchdogSeconds = @{ 'PROBE' = 60; 'Q08' = 120 }
$ContractExits = @(0, 2, 3, 130)
$RequiredItems = @{ 'QS2_READONLY' = @('Q01', 'Q02', 'Q03', 'Q04', 'Q05', 'Q05_HOST', 'Q06_partial', 'Q07', 'Q08', 'T26', 'T31a', 'STATUS_B', 'CLASSIFY_B') }
$Stage = 'QS2_READONLY'
$AttemptId = '20261003T000000Z_0000beef'
$AttemptDir = Join-Path $Work 'ATTEMPT'
$LogPath = Join-Path $AttemptDir 'BOOTSTRAP.log'
$BootstrapStatusPath = Join-Path $AttemptDir 'BOOTSTRAP_STATUS.json'
$PythonExe = $Python
$WindowsPsExe = $Pwsh
$script:StatusSeq = 0
$script:StatusWriteFailures = 0
$script:Checkpoint = 'NONE'
$script:Unproven = $false
[void](New-Item -ItemType Directory -Path $AttemptDir)

$tokens = $null
$errors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($Bootstrap, [ref]$tokens, [ref]$errors)
if ($errors.Count -ne 0) { throw 'BOOTSTRAP_PARSE_ERRORS' }
$fns = $ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true)
foreach ($f in $fns) { . ([ScriptBlock]::Create($f.Extent.Text)) }
Write-Host ('FUNCTIONS_LOADED=' + $fns.Count)

$results = [ordered]@{}
function Assert-True([bool]$Cond, [string]$Msg) { if (-not $Cond) { throw ('ASSERT ' + $Msg) } }

$probe = Join-Path $Adapter 'qualification/probe_exit.py'
$probePs = Join-Path $Adapter 'qualification/probe_exit_ps.ps1'

# H1
$t = Invoke-T26Probes $probe $Work
Assert-True ($t['result'] -eq 'PASS') 'H1 result'
foreach ($r in $t['probes']) { Assert-True ($r['pass'] -and $r['stderr_match']) ('H1 probe ' + $r['want']) }
$results['H1_T26_EXIT_0_2_3_7_130_STDERR'] = 'PASS'

# H2
$h = Invoke-T26HistoricalPattern $probe $Work
Assert-True ($h['sentinel_read_process_boundary'] -eq '-999') 'H2 sentinel process'
Assert-True ($h['sentinel_read_native_call'] -eq '-999') 'H2 sentinel native (shadowing)'
Assert-True ($h['global_lastexitcode_after_native_call'] -eq '7') 'H2 global updated by native call'
Assert-True ($h['authoritative_process_exit'] -eq 7) 'H2 authoritative'
Assert-True ($h['shadowing_reproduced'] -eq $true -and $h['used_as_exit'] -eq 'NO') 'H2 reproduced'
Assert-True ($h['classification'] -eq 'INVALID_MEASUREMENT' -and $h['result'] -eq 'PASS') 'H2 classification'
$results['H2_T26_HISTORICAL_MINUS_999'] = 'PASS'

# H3
$script:Unproven = $false
$c = Invoke-Child $PythonExe '-B -c "import time; time.sleep(6)"' $Work 'H3_SLEEP' 2 ''
Assert-True ($c.TimedOut) 'H3 timed out'
Assert-True ($null -eq $c.ExitCode) 'H3 no exit claimed'
Assert-True ($script:Unproven) 'H3 unproven flag'
$alive = $null -ne (Get-Process -Id $c.Pid -ErrorAction SilentlyContinue)
Assert-True $alive 'H3 child still alive (no auto-kill)'
$log = [System.IO.File]::ReadAllText($LogPath)
Assert-True ($log.Contains('WATCHDOG_EXPIRED label=H3_SLEEP') -and $log.Contains('auto_kill=NO child_killed=NO PASS=NO RECONCILIATION_REQUIRED=YES')) 'H3 log'
$hb = @($log.Split("`n") | Where-Object { $_.StartsWith('HEARTBEAT label=H3_SLEEP') })
Assert-True ($hb.Count -ge 1) 'H3 heartbeat'
foreach ($k in $StatusFields) { Assert-True ($hb[0].Contains(' ' + $k + '=')) ('H3 heartbeat field ' + $k) }
$st = [System.IO.File]::ReadAllText($BootstrapStatusPath) | ConvertFrom-Json
foreach ($k in $StatusFields) { Assert-True ($null -ne $st.fields.PSObject.Properties[$k]) ('H3 status field ' + $k) }
Assert-True ($st.fields.PHASE -eq 'H3_SLEEP_WATCHDOG_EXPIRED') 'H3 status phase'
Assert-True (@(Get-ChildItem -LiteralPath $AttemptDir -Filter '*.tmp').Count -eq 0) 'H3 no tmp residue'
$p = Get-Process -Id $c.Pid -ErrorAction SilentlyContinue
if ($null -ne $p) { $p.WaitForExit() }
$results['H3_WATCHDOG_NO_AUTOKILL_HEARTBEAT_STATUS'] = 'PASS'

# H4
$adir = Join-Path $AttemptDir 'ADAPTER'
[void](New-Item -ItemType Directory -Path $adir)
$ast4 = Join-Path $adir 'ADAPTER_STATUS.json'
$now = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
$doc = '{"fields":{"ACTIVE":"YES","CHECKPOINT":"G16","COMMITTED":"0","ETA":"0.00.01.05","FINISH":"UNKNOWN","PHASE":"G17","PROGRESS":"1073741824","RATE":"512.0MiB/s","READY_WAITING":"0","SAFE_STOP":"NO","TOTAL":"34317940389"},"updated_utc":"' + $now + '"}'
Write-AtomicText $ast4 $doc
$c4 = Invoke-Child $PythonExe '-B -c "import time; time.sleep(3)"' $Work 'H4_ADAPTER' 60 $ast4
Assert-True ($c4.Completed -and $c4.ExitCode -eq 0) 'H4 exit'
$log = [System.IO.File]::ReadAllText($LogPath)
$hb4 = @($log.Split("`n") | Where-Object { $_.StartsWith('HEARTBEAT label=H4_ADAPTER') })
Assert-True ($hb4.Count -ge 1) 'H4 heartbeat'
Assert-True ($hb4[0].Contains('PHASE=G17') -and $hb4[0].Contains('ETA=0.00.01.05') -and $hb4[0].Contains('RATE=512.0MiB/s')) 'H4 fields from adapter status'
Assert-True (-not $hb4[0].Contains('adapter_status_age_s=NO_ADAPTER_STATUS') -and -not $hb4[0].Contains('adapter_status_age_s=UNPARSEABLE')) 'H4 age'
$results['H4_HEARTBEAT_FROM_ADAPTER_STATUS'] = 'PASS'

# H5
$ident = ('A' * 64)
$map = @{ '0' = 'PASS'; '130' = 'SAFE_STOP'; 'other' = 'NOT_PASS' }
$rp = Join-Path $adir 'CLASSIFY_RECEIPT.json'
$spath = Join-Path $adir 'ADAPTER_STATUS.json'
function New-Rec([int]$Exit, [string]$Result, [string]$Attempt, [string]$StatusSha = '', [int]$Failures = 0, [string]$Persisted = 'true') {
    return ('{"schema":"MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001","attempt_id":"' + $Attempt + '","mode":"CLASSIFY","exit_code":' + $Exit + ',"result":"' + $Result +
            '","adapter_identity_sha256":"' + $ident + '","status_write_failures":' + $Failures + ',"status_final_persisted":' + $Persisted + ',"status_final_sha256":"' + $StatusSha + '"}')
}
$cpath = Join-Path $adir 'CLASSIFY_RECEIPT.VERIFIED.json'
function Write-RecAndCompanion([int]$Exit, [string]$Result, [string]$Attempt, [int]$Failures = 0, [string]$Persisted = 'true', [string]$Active = 'NO') {
    Write-AtomicText $spath ('{"fields":{"ACTIVE":"' + $Active + '","PHASE":"FINISHED"},"extra":{"exit_code":' + $Exit + '}}')
    Write-AtomicText $rp (New-Rec $Exit $Result $Attempt (Get-Sha256 $spath) $Failures $Persisted)
    $sha = Get-Sha256 $rp
    Write-AtomicText $cpath ('{"schema":"MINOTAURO_PHASE_B_ADAPTER_RECEIPT_VERIFIED_V001","receipt_sha256":"' + $sha + '","attempt_id":"' + $Attempt + '","exit_code":' + $Exit + ',"mode":"CLASSIFY","readback":"PASS"}')
}
$okChild = [pscustomobject]@{ ExitCode = 0; Completed = $true; TimedOut = $false; StderrComplete = $true; StderrSha256 = ('E' * 64); StderrPath = 'x' }
# (a) valido
Write-RecAndCompanion 0 'PASS' $AttemptId
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $ident $map
Assert-True ($r.valid) 'H5a valid'
$o = Resolve-ChildOutcome $okChild $r 'H5A'
Assert-True ($o.final_exit -eq 0) 'H5a final 0'
# (b) ausente com exit nativo 0 -> nunca PASS; exit nativo e SHA do stderr registrados
Remove-Item -LiteralPath $rp
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $ident $map
Assert-True (-not $r.valid -and $r.reason -eq 'RECEIPT_MISSING') 'H5b missing'
$o = Resolve-ChildOutcome $okChild $r 'H5B'
Assert-True ($o.final_exit -eq 3 -and $o.native_exit -eq 0) 'H5b final 3 native 0 preserved'
$log = [System.IO.File]::ReadAllText($LogPath)
Assert-True ($log.Contains('MISSING_DOWNSTREAM_RESULT label=H5B native_exit=0 stderr_sha256=' + ('E' * 64))) 'H5b log'
# (c) exit do receipt diferente do nativo
Write-RecAndCompanion 0 'PASS' $AttemptId
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 2 $ident $map
Assert-True ($r.reason -eq 'RECEIPT_EXIT_CODE_NE_NATIVE') 'H5c mismatch'
$twoChild = [pscustomobject]@{ ExitCode = 2; Completed = $true; TimedOut = $false; StderrComplete = $true; StderrSha256 = ('F' * 64); StderrPath = 'y' }
$o = Resolve-ChildOutcome $twoChild $r 'H5C'
Assert-True ($o.final_exit -eq 2) 'H5c native 2 preserved'
# (d) attempt divergente / identidade divergente
Write-RecAndCompanion 0 'PASS' '20261003T000000Z_00000000'
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $ident $map
Assert-True ($r.reason -eq 'RECEIPT_ATTEMPT_ID') 'H5d attempt'
Write-RecAndCompanion 0 'PASS' $AttemptId
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 ('B' * 64) $map
Assert-True ($r.reason -eq 'RECEIPT_ADAPTER_IDENTITY') 'H5d identity'
# (e) exit fora do contrato
$nineChild = [pscustomobject]@{ ExitCode = 9; Completed = $true; TimedOut = $false; StderrComplete = $true; StderrSha256 = ('C' * 64); StderrPath = 'z' }
$o = Resolve-ChildOutcome $nineChild $r 'H5E'
Assert-True ($o.final_exit -eq 3 -and $o.reason -eq 'NATIVE_EXIT_OUT_OF_CONTRACT') 'H5e out of contract'
# (f) SAFE_STOP com receipt valido
Write-RecAndCompanion 130 'SAFE_STOP' $AttemptId
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 130 $ident $map
$ssChild = [pscustomobject]@{ ExitCode = 130; Completed = $true; TimedOut = $false; StderrComplete = $true; StderrSha256 = ('D' * 64); StderrPath = 'w' }
$o = Resolve-ChildOutcome $ssChild $r 'H5F'
Assert-True ($r.valid -and $o.final_exit -eq 130) 'H5f safe stop'
# (h) companion ausente / divergente (receipt nao confirmado pela releitura do adapter)
Write-RecAndCompanion 0 'PASS' $AttemptId
Remove-Item -LiteralPath $cpath
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $ident $map
Assert-True ($r.reason -eq 'RECEIPT_NOT_VERIFIED_BY_ADAPTER') 'H5h companion missing'
Write-RecAndCompanion 0 'PASS' $AttemptId
Write-AtomicText $rp ((New-Rec 0 'PASS' $AttemptId) + ' ')
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $ident $map
Assert-True ($r.reason -eq 'RECEIPT_COMPANION_MISMATCH') 'H5h companion sha mismatch'
# (j) B08: PASS/SAFE_STOP exige status sem falhas, final persistido e vinculado por SHA ao ADAPTER_STATUS.json
Write-RecAndCompanion 0 'PASS' $AttemptId 2 'true'
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $ident $map
Assert-True ($r.reason -eq 'RECEIPT_STATUS_NOT_PERSISTED') 'H5j failures>0'
Assert-True ((Resolve-ChildOutcome $okChild $r 'H5J').final_exit -eq 3) 'H5j never 0'
Write-RecAndCompanion 0 'PASS' $AttemptId 0 'false'
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $ident $map
Assert-True ($r.reason -eq 'RECEIPT_STATUS_NOT_PERSISTED') 'H5j final not persisted'
Write-RecAndCompanion 0 'PASS' $AttemptId 0 'true' 'YES'
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $ident $map
Assert-True ($r.reason -eq 'RECEIPT_STATUS_FINAL_MISMATCH') 'H5j ACTIVE not NO'
Write-RecAndCompanion 0 'PASS' $AttemptId
Write-AtomicText $spath '{"fields":{"ACTIVE":"NO","PHASE":"FINISHED"},"extra":{"exit_code":0}} '
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $ident $map
Assert-True ($r.reason -eq 'RECEIPT_STATUS_FINAL_MISMATCH') 'H5j status file altered after receipt'
Write-RecAndCompanion 0 'PASS' $AttemptId
Remove-Item -LiteralPath $spath
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $ident $map
Assert-True ($r.reason -eq 'RECEIPT_STATUS_FILE_MISSING') 'H5j status file missing'
Write-RecAndCompanion 2 'NOT_PASS' $AttemptId 3 'false'
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 2 $ident $map
Assert-True ($r.valid) 'H5j non-pass receipt with status failure is a valid NOT_PASS record'
# (g) JSON invalido
[System.IO.File]::WriteAllText($rp, '{not json', $Utf8NoBom)
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $ident $map
Assert-True ($r.reason -eq 'RECEIPT_JSON_INVALID') 'H5g invalid json'
# (i) N5: o documento usado pelo chamador e o mesmo cujo SHA foi verificado (leitura unica)
Write-RecAndCompanion 0 'PASS' $AttemptId
$r = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $ident $map
Assert-True ($r.valid -and $null -ne $script:LastReceiptDoc -and $script:LastReceiptDoc.attempt_id -eq $AttemptId) 'H5i single read doc'
Assert-True ($r.sha256 -eq (Get-Sha256 $rp)) 'H5i sha from same bytes'
$results['H5_RECEIPT_VERIFY_NATIVE_EXIT_STDERR'] = 'PASS'

# H6
Assert-True ((Format-Eta 0) -eq '0.00.00.00') 'H6 zero'
Assert-True ((Format-Eta 93784) -eq '1.02.03.04') 'H6 value'
Assert-True ((Format-Eta $null) -eq 'UNKNOWN') 'H6 null'
Assert-True ((Format-Eta -5) -eq 'UNKNOWN') 'H6 negative'
$results['H6_FORMAT_ETA'] = 'PASS'

# H7
$ap = Join-Path $Work 'atomic.json'
Write-AtomicText $ap '{"a":1}'
Write-AtomicText $ap '{"a":2}'
Assert-True ([System.IO.File]::ReadAllText($ap) -eq '{"a":2}') 'H7 replace'
$script:Unproven = $false
$it = [ordered]@{ 'A' = [ordered]@{ result = 'PASS' }; 'B' = [ordered]@{ result = 'COLLECTED' } }
Assert-True ((Get-StageExit $it @('A', 'B')) -eq 0) 'H7 all pass'
Assert-True ((Get-StageExit $it @('A', 'B', 'C')) -eq 2) 'H7 missing required'
$it['C'] = [ordered]@{ result = 'FAIL'; final_exit = 3 }
Assert-True ((Get-StageExit $it @('A', 'B', 'C')) -eq 3) 'H7 three'
$it['C'] = [ordered]@{ result = 'FAIL'; final_exit = 2 }
Assert-True ((Get-StageExit $it @('A', 'B', 'C')) -eq 2) 'H7 two'
$script:Unproven = $true
Assert-True ((Get-StageExit ([ordered]@{ 'A' = [ordered]@{ result = 'PASS' } }) @('A')) -eq 3) 'H7 unproven'
$script:Unproven = $false
$it130 = [ordered]@{ 'A' = [ordered]@{ result = 'PASS' }; 'B' = [ordered]@{ result = 'FAIL'; final_exit = 130 } }
Assert-True ((Get-StageExit $it130 @('A', 'B')) -eq 130) 'H7 safe stop propagates 130'
$it130['C'] = [ordered]@{ result = 'FAIL'; final_exit = 3 }
Assert-True ((Get-StageExit $it130 @('A', 'B', 'C')) -eq 3) 'H7 three dominates 130'
$results['H7_ATOMIC_WRITE_STAGE_EXIT'] = 'PASS'

# H8
$q = Invoke-Q08 $probePs $probe $Work
Assert-True ($q['result'] -eq 'PASS') 'H8 q08 analog'
$results['H8_Q08_ANALOG_PWSH_FILE'] = 'PASS'

# H9
$hq = Get-HostQ05
Assert-True ($hq.Contains('ps_version') -and $hq.Contains('logical_cpus')) 'H9 host'
$results['H9_HOST_Q05_NO_THROW'] = 'PASS'

# H10
$c10 = Invoke-Child $PythonExe '-B -c "import sys; sys.stderr.buffer.write(bytes([255, 254, 128, 97, 98, 99])); sys.exit(0)"' $Work 'H10_RAW' 60 ''
$sha10 = [System.Security.Cryptography.SHA256]::Create()
$want10 = -join ($sha10.ComputeHash([byte[]](255, 254, 128, 97, 98, 99)) | ForEach-Object { $_.ToString('X2') })
$sha10.Dispose()
Assert-True ($c10.Completed -and $c10.StderrComplete -and $c10.StderrBytes -eq 6) 'H10 complete 6 bytes'
Assert-True ($c10.StderrSha256 -eq $want10) 'H10 raw sha'
$results['H10_STDERR_RAW_BYTES_SHA256'] = 'PASS'

# H11
$script:Unproven = $false
$StderrDrainMs = 1500
$t11 = Get-Date
$c11 = Invoke-Child $PythonExe '-B -c "import subprocess, sys; subprocess.Popen([sys.executable, ''-c'', ''import time; time.sleep(6)'']); sys.exit(0)"' $Work 'H11_PIPE' 60 ''
$el11 = ((Get-Date) - $t11).TotalSeconds
$StderrDrainMs = 60000
Assert-True ($c11.Completed -and -not $c11.StderrComplete -and $c11.StderrSha256 -eq 'INCOMPLETE_PIPE_HELD_BY_DESCENDANT') 'H11 incomplete'
Assert-True ($el11 -lt 5) ('H11 bounded wait ' + $el11)
Assert-True ($script:Unproven) 'H11 unproven'
Write-RecAndCompanion 0 'PASS' $AttemptId
$r11 = Test-ChildReceipt $rp 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001' 'CLASSIFY' 0 $ident $map
$o11 = Resolve-ChildOutcome $c11 $r11 'H11'
Assert-True ($r11.valid -and $o11.final_exit -eq 3 -and $o11.reason -eq 'STDERR_PIPE_HELD_BY_DESCENDANT_RECONCILIATION_REQUIRED') 'H11 outcome 3'
$script:Unproven = $false
Start-Sleep -Seconds 6
$results['H11_STDERR_DRAIN_BOUNDED_DESCENDANT'] = 'PASS'

# H12
$gl = '[{"id":"G06","status":"PASS"},{"id":"G18","status":"PASS"},{"id":"G21","status":"PASS"},{"id":"G22","status":"PASS"},{"id":"BND","status":"PASS"},{"id":"G23","status":"PASS"}]'
$dg = '{"control":"A","preflight":"B","code":"C","package":"D","release_top":"E","inputs":"F"}'
$trsha = ('A' * 64)
function New-Dry([string]$Scope, [string]$Bnd, [string]$After, [string]$Foreign) {
    return ('{"dry_scope":"' + $Scope + '","bnd_reached":' + $Bnd + ',"state":"PREPARED","gates":' + $gl + ',"before_digests":' + $dg + ',"after_digests":' + $After +
            ',"runtime_evidence":{"started":true,"clean":true},"d1b_at_use":{"sessions":166},"runtime_trace":["RUN_START x=1"],"runtime_trace_sha256":"' + $trsha +
            '","t30":{"foreign":' + $Foreign + ',"roots":{"control":{},"code":{},"shadow":{}}}}') | ConvertFrom-Json
}
$di = Get-DryItems (New-Dry 'SUBSTANTIVE_TO_BND' 'true' $dg '[]') ('S' * 64)
foreach ($k in @('T02', 'T11c', 'T14', 'T19_template', 'T23', 'T27', 'T30')) { Assert-True ($di[$k]['result'] -eq 'PASS') ('H12 pass ' + $k) }
$di = Get-DryItems (New-Dry 'PRELOCK_READONLY' 'false' $dg '[]') ('S' * 64)
foreach ($k in $di.Keys) { Assert-True ($di[$k]['result'] -eq 'FAIL') ('H12 non-substantive ' + $k) }
$di = Get-DryItems (New-Dry 'SUBSTANTIVE_TO_BND' 'true' '{"control":"X","preflight":"B","code":"C","package":"D","release_top":"E","inputs":"F"}' '["shadow:_avast_/x"]') ('S' * 64)
Assert-True ($di['T23']['result'] -eq 'FAIL' -and $di['T27']['result'] -eq 'FAIL' -and $di['T30']['result'] -eq 'FAIL' -and $di['T14']['result'] -eq 'PASS') 'H12 mutation/foreign'
$nt = ('{"dry_scope":"SUBSTANTIVE_TO_BND","bnd_reached":true,"state":"PREPARED","gates":' + $gl + ',"before_digests":' + $dg + ',"after_digests":' + $dg +
       ',"runtime_evidence":{"started":true,"clean":true},"d1b_at_use":{"sessions":166},"runtime_trace":null,"runtime_trace_sha256":"' + $trsha +
       '","t30":{"roots":{"shadow":{}}}}') | ConvertFrom-Json
$di = Get-DryItems $nt ('S' * 64)
Assert-True ($di['T19_template']['result'] -eq 'FAIL' -and $di['T30']['result'] -eq 'FAIL') 'H12 null trace / missing foreign never PASS'
$results['H12_QS3_ITEMS_SUBSTANTIVE_ONLY'] = 'PASS'

# H13
$phys = '{"Q01":{"verdict":"PASS","reasons":[]},"Q02":{"verdict":"PASS","reasons":[]},"Q03":{"verdict":"FAIL","reasons":["M1_MONTHS_MISSING:2024-01"]},"Q04":{"verdict":"PASS","reasons":[]},"Q05":{"reasons":[]},"Q06_partial":{"verdict":"PASS","reasons":[]}}' | ConvertFrom-Json
$qi = Get-QItems $phys ('R' * 64)
Assert-True ($qi['Q01']['result'] -eq 'PASS' -and $qi['Q03']['result'] -eq 'FAIL' -and $qi['Q05']['result'] -eq 'FAIL') 'H13 verdict mapping (presence is not PASS)'
$results['H13_QS2_Q_ITEMS_BY_VERDICT'] = 'PASS'

# H14
$src14 = Join-Path $Work 'pkgsrc'
[void](New-Item -ItemType Directory -Path (Join-Path $src14 'PHASE_B_ADAPTER_V001'))
[System.IO.File]::WriteAllText((Join-Path (Join-Path $src14 'PHASE_B_ADAPTER_V001') 'a.txt'), 'alpha', $Utf8NoBom)
[System.IO.File]::WriteAllText((Join-Path (Join-Path $src14 'PHASE_B_ADAPTER_V001') 'b.txt'), 'beta', $Utf8NoBom)
$zip14 = Join-Path $Work 'pkg.zip'
$zs = [System.IO.Compression.ZipFile]::Open($zip14, 'Create')
try {
    foreach ($n in @('a.txt', 'b.txt')) { [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zs, (Join-Path (Join-Path $src14 'PHASE_B_ADAPTER_V001') $n), ('PHASE_B_ADAPTER_V001/' + $n)) }
}
finally { $zs.Dispose() }
$dir14 = Join-Path $Work ('PKG_' + ('F' * 64))
Assert-True ((Expand-AdapterPackage $zip14 $dir14) -eq 2) 'H14 fresh'
Assert-True (@(Get-ChildItem -LiteralPath $Work -Filter '*.extract.*').Count -eq 0) 'H14 staging renamed'
Assert-True ((Expand-AdapterPackage $zip14 $dir14) -eq 2) 'H14 reuse verified'
$victim = @(Get-ChildItem -LiteralPath $dir14 -Recurse -File)[0].FullName
[System.IO.File]::WriteAllText($victim, 'tampered', $Utf8NoBom)
$threw = $false
try { [void](Expand-AdapterPackage $zip14 $dir14) } catch { $threw = $_.Exception.Message.StartsWith('PACKAGE_DIR_NE_ZIP') }
Assert-True $threw 'H14 tamper blocks'
$dir14b = Join-Path $Work ('PKG_' + ('E' * 64))
[void](Expand-AdapterPackage $zip14 $dir14b)
[System.IO.File]::WriteAllText((Join-Path $dir14b 'extra.txt'), 'x', $Utf8NoBom)
$threw = $false
try { [void](Expand-AdapterPackage $zip14 $dir14b) } catch { $threw = $_.Exception.Message.StartsWith('PACKAGE_DIR_NE_ZIP') }
Assert-True $threw 'H14 extra blocks'
$dir14c = Join-Path $Work ('PKG_' + ('D' * 64))
[void](Expand-AdapterPackage $zip14 $dir14c)
$hid = Join-Path $dir14c '.hidden_extra'
[System.IO.File]::WriteAllText($hid, 'x', $Utf8NoBom)
$threw = $false
try { [void](Expand-AdapterPackage $zip14 $dir14c) } catch { $threw = $_.Exception.Message.StartsWith('PACKAGE_DIR_NE_ZIP') }
Assert-True $threw 'H14 hidden extra blocks (-Force)'
$results['H14_PACKAGE_STAGING_AND_REUSE_VERIFY'] = 'PASS'

# H15
$script:Unproven = $false
Assert-True ((Resolve-FinalExit 0 0 $true) -eq 0) 'H15 control pass'
Assert-True ((Resolve-FinalExit 0 3 $true) -eq 2) 'H15 failures after heartbeats'
Assert-True ((Resolve-FinalExit 0 0 $false) -eq 2) 'H15 final status not written'
Assert-True ((Resolve-FinalExit 130 1 $true) -eq 2) 'H15 safe stop downgraded'
Assert-True ((Resolve-FinalExit 3 5 $false) -eq 3) 'H15 three kept'
Assert-True ((Resolve-FinalExit 2 5 $false) -eq 2) 'H15 two kept'
$script:Unproven = $true
Assert-True ((Resolve-FinalExit 0 1 $true) -eq 3) 'H15 unproven -> 3'
$script:Unproven = $false
# falha total real de Set-BootstrapStatus (Write-AtomicText substituida) e contagem
$saved = ${function:Write-AtomicText}
$before = $script:StatusWriteFailures
${function:Write-AtomicText} = { param($Path, $Text) throw 'SIMULATED_STATUS_FAILURE' }
$ok1 = Set-BootstrapStatus (New-StatusFields 'H15') $null
$ok2 = Set-BootstrapStatus (New-StatusFields 'FINISHED') $null
${function:Write-AtomicText} = $saved
Assert-True ((-not $ok1) -and (-not $ok2) -and ($script:StatusWriteFailures -eq $before + 2)) 'H15 total failure counted'
Assert-True ((Resolve-FinalExit 0 $script:StatusWriteFailures $ok2) -eq 2) 'H15 total failure never 0'
$script:StatusWriteFailures = 0
$results['H15_B08_STATUS_PERSISTENCE_NEVER_PASS'] = 'PASS'

# H16
$EvidenceBase = Join-Path $Work 'EVB'
$zipSha16 = ('Z' * 64).Replace('Z', 'C')
$ident16 = ('A' * 64)
$qa = '20261002T000000Z_0000aaaa'
function New-QS2World([hashtable]$Mut) {
    $qd = Join-Path $EvidenceBase $qa
    if (Test-Path -LiteralPath $qd) { Remove-Item -LiteralPath $qd -Recurse -Force }
    $ad = Join-Path $qd 'ADAPTER'
    $q2 = Join-Path $qd 'QS2'
    [void](New-Item -ItemType Directory -Path $ad -Force)
    [void](New-Item -ItemType Directory -Path $q2 -Force)
    $cr = Join-Path $ad 'CLASSIFY_RECEIPT.json'
    $tr = Join-Path $q2 'T31A_RECEIPT.json'
    $q7 = Join-Path $q2 'Q07_RECEIPT.json'
    $ast = Join-Path $ad 'ADAPTER_STATUS.json'
    Write-AtomicText $ast '{"fields":{"ACTIVE":"NO","PHASE":"FINISHED"},"extra":{"exit_code":0}}'
    $phys = [ordered]@{}
    foreach ($q in @('Q01', 'Q02', 'Q03', 'Q04', 'Q05', 'Q06_partial')) { $phys[$q] = [ordered]@{ verdict = 'PASS'; reasons = @() } }
    $crec = [ordered]@{ schema = 'MINOTAURO_PHASE_B_ADAPTER_CLASSIFY_RECEIPT_V001'; attempt_id = $qa; mode = 'CLASSIFY'; exit_code = 0; result = 'PASS';
                        adapter_identity_sha256 = $ident16; status_write_failures = 0; status_final_persisted = $true;
                        status_final_sha256 = (Get-Sha256 $ast); qs2_physical = $phys }
    $trec = [ordered]@{ schema = 'MINOTAURO_PHASE_B_ADAPTER_QS2_T31A_RECEIPT_V001'; attempt_id = $qa; exit_code = 0; result = 'PASS' }
    $qrec = [ordered]@{ schema = 'MINOTAURO_PHASE_B_ADAPTER_QS2_Q07_RECEIPT_V001'; attempt_id = $qa; exit_code = 0; result = 'PASS' }
    if ($null -ne $Mut -and $Mut.ContainsKey('child')) { & $Mut['child'] $crec $trec $qrec }
    Write-AtomicText $cr ($crec | ConvertTo-Json -Depth 6)
    Write-AtomicText $tr ($trec | ConvertTo-Json -Depth 3)
    Write-AtomicText $q7 ($qrec | ConvertTo-Json -Depth 3)
    $cs = Get-Sha256 $cr
    Write-AtomicText (Join-Path $ad 'CLASSIFY_RECEIPT.VERIFIED.json') ('{"schema":"MINOTAURO_PHASE_B_ADAPTER_RECEIPT_VERIFIED_V001","receipt_sha256":"' + $cs + '","attempt_id":"' + $qa + '","exit_code":0,"mode":"CLASSIFY","readback":"PASS"}')
    $bsp = Join-Path $qd 'BOOTSTRAP_STATUS.json'
    Write-AtomicText $bsp '{"fields":{"ACTIVE":"NO","PHASE":"FINISHED"},"extra":{"final_exit":0}}'
    $items = [ordered]@{}
    foreach ($q in @('Q01', 'Q02', 'Q03', 'Q04', 'Q05', 'Q06_partial')) { $items[$q] = [ordered]@{ result = 'PASS'; receipt_sha256 = $cs } }
    $items['Q05_HOST'] = [ordered]@{ result = 'COLLECTED' }
    $items['Q08'] = [ordered]@{ result = 'PASS' }
    $items['T26'] = [ordered]@{ result = 'PASS'; historical = [ordered]@{ result = 'PASS' } }
    $items['STATUS_B'] = [ordered]@{ result = 'PASS'; final_exit = 0 }
    $items['CLASSIFY_B'] = [ordered]@{ result = 'PASS'; final_exit = 0; receipt = [ordered]@{ valid = $true; sha256 = $cs } }
    $items['T31a'] = [ordered]@{ result = 'PASS'; final_exit = 0; receipt = [ordered]@{ valid = $true; sha256 = (Get-Sha256 $tr) } }
    $items['Q07'] = [ordered]@{ result = 'PASS'; final_exit = 0; receipt = [ordered]@{ valid = $true; sha256 = (Get-Sha256 $q7) } }
    $rec = [ordered]@{ schema = 'MINOTAURO_PHASE_B_ADAPTER_BOOTSTRAP_QS2_READONLY_RECEIPT_V001'; attempt_id = $qa; stage = 'QS2_READONLY';
                       facts = [ordered]@{ adapter_identity_sha256 = $ident16; package_zip_sha256 = $zipSha16 }; items = $items;
                       required_items = $RequiredItems['QS2_READONLY']; blocked_reason = $null; frontier = 'PACKAGE_EXTRACTION';
                       unproven_effect = $false; interrupted = $false; status_write_failures = 0; final_status_written = $true;
                       final_status_sha256 = (Get-Sha256 $bsp); final_exit = 0; auto_kill = 'NO' }
    if ($null -ne $Mut -and $Mut.ContainsKey('fn')) { & $Mut['fn'] $rec }
    $path = Join-Path $qd 'QS2_RECEIPT.json'
    $sha = Write-StageReceipt $path $rec
    $log = 'ATTEMPT_ID=' + $qa + "`r`n" + 'STAGE_RECEIPT=' + $path + ' sha256=' + $sha + "`r`n" + 'FINAL_EXIT=0' + "`r`n"
    if ($null -ne $Mut -and $Mut.ContainsKey('log')) { $log = & $Mut['log'] $log }
    [System.IO.File]::WriteAllText((Join-Path $qd 'BOOTSTRAP.log'), $log, $Utf8NoBom)
    return [pscustomobject]@{ Path = $path; Sha = $sha; Dir = $qd; Tr = $tr; Bsp = $bsp }
}
$w = New-QS2World $null
$v = Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16
Assert-True ($v.valid -and $v.reason -eq 'OK' -and $v.sha256 -eq $w.Sha) ('H16 positive ' + $v.reason)
$neg = [ordered]@{}
$w = New-QS2World $null; Remove-Item -LiteralPath $w.Path; $neg['missing'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World $null; $neg['relative'] = (Test-PriorQS2Receipt 'QS2_RECEIPT.json' $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World $null; $neg['other_adapter'] = (Test-PriorQS2Receipt $w.Path $w.Sha ('B' * 64) $zipSha16).reason
$w = New-QS2World $null; $neg['other_zip'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 ('D' * 64)).reason
$w = New-QS2World @{ fn = { param($r) $r['items'].Remove('Q08') } }; $neg['item_missing'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World @{ fn = { param($r) $r['items']['Q07']['result'] = 'FAIL' } }; $neg['q07_fail'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World @{ fn = { param($r) $r['items']['T31a']['result'] = 'FAIL' } }; $neg['t31a_fail'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World @{ fn = { param($r) $r['final_exit'] = 2 } }; $neg['final_exit_2'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World $null; [System.IO.File]::AppendAllText($w.Path, ' ', $Utf8NoBom); $neg['tampered'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World @{ fn = { param($r) $r['status_write_failures'] = 1 } }; $neg['status_failures'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World $null; Write-AtomicText $w.Tr '{"x":"t31a-altered"}'; $neg['binding_t31a'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World $null; Remove-Item -LiteralPath (Join-Path $w.Dir 'QS2_RECEIPT.VERIFIED.json'); $neg['companion_missing'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World $null; [System.IO.File]::WriteAllText((Join-Path $w.Dir 'BOOTSTRAP.log'), 'x', $Utf8NoBom); $neg['log_binding'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World $null; $elsewhere = Join-Path $Work 'QS2_RECEIPT.json'; Copy-Item -LiteralPath $w.Path -Destination $elsewhere; $neg['location'] = (Test-PriorQS2Receipt $elsewhere $w.Sha $ident16 $zipSha16).reason
# conteudo fisico dos filhos: QS2 BLOCKED "reescrito" (receipt do QS2 diz PASS, receipt Q07 fisico diz BLOCKED/2)
$w = New-QS2World @{ child = { param($c, $t, $q) $q['exit_code'] = 2; $q['result'] = 'BLOCKED' } }; $neg['q07_child_blocked'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World @{ child = { param($c, $t, $q) $t['exit_code'] = 2; $t['result'] = 'BLOCKED' } }; $neg['t31a_child_blocked'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World @{ child = { param($c, $t, $q) $c['qs2_physical']['Q03']['verdict'] = 'FAIL' } }; $neg['classify_verdict_fail'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World @{ child = { param($c, $t, $q) $c['status_write_failures'] = 1 } }; $neg['classify_status_fail'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World @{ log = { param($l) $l + 'STAGE_RECEIPT=x sha256=y' + "`r`n" } }; $neg['log_duplicate_stage'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World @{ log = { param($l) $l.Replace('FINAL_EXIT=0', 'FINAL_EXIT=2') } }; $neg['log_final_exit_2'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
$w = New-QS2World $null; Write-AtomicText $w.Bsp '{"fields":{"ACTIVE":"NO"},"extra":{"final_exit":2}}'; $neg['bootstrap_status_altered'] = (Test-PriorQS2Receipt $w.Path $w.Sha $ident16 $zipSha16).reason
# fase pre-extracao (identidade adiada) ainda valida todo o resto; identidade declarada e devolvida para a comparacao final
$w = New-QS2World $null; $pre16 = Test-PriorQS2Receipt $w.Path $w.Sha '' $zipSha16
Assert-True ($pre16.valid -and $pre16['adapter_identity'] -eq $ident16) 'H16 precheck deferred identity'
$w = New-QS2World $null; $neg['precheck_other_zip'] = (Test-PriorQS2Receipt $w.Path $w.Sha '' ('D' * 64)).reason
$want16 = [ordered]@{ missing = 'PRIOR_QS2_RECEIPT_MISSING'; relative = 'PRIOR_QS2_RECEIPT_PATH_NOT_ABSOLUTE'; other_adapter = 'PRIOR_QS2_OTHER_ADAPTER';
                     other_zip = 'PRIOR_QS2_OTHER_ZIP'; item_missing = 'PRIOR_QS2_ITEM_MISSING:Q08'; q07_fail = 'PRIOR_QS2_ITEM_NOT_PASS:Q07';
                     t31a_fail = 'PRIOR_QS2_ITEM_NOT_PASS:T31a'; final_exit_2 = 'PRIOR_QS2_FINAL_EXIT_NOT_ZERO'; tampered = 'PRIOR_QS2_RECEIPT_SHA_MISMATCH';
                     status_failures = 'PRIOR_QS2_NOT_CLEAN'; binding_t31a = 'PRIOR_QS2_BINDING:T31a'; companion_missing = 'PRIOR_QS2_COMPANION_MISSING';
                     log_binding = 'PRIOR_QS2_LOG_BINDING'; location = 'PRIOR_QS2_RECEIPT_LOCATION';
                     q07_child_blocked = 'PRIOR_QS2_CHILD_CONTENT:Q07:RECEIPT_EXIT_CODE_NE_NATIVE';
                     t31a_child_blocked = 'PRIOR_QS2_CHILD_CONTENT:T31a:RECEIPT_EXIT_CODE_NE_NATIVE';
                     classify_verdict_fail = 'PRIOR_QS2_CHILD_CONTENT:Q03';
                     classify_status_fail = 'PRIOR_QS2_CHILD_CONTENT:CLASSIFY_B:RECEIPT_STATUS_NOT_PERSISTED';
                     log_duplicate_stage = 'PRIOR_QS2_LOG_BINDING'; log_final_exit_2 = 'PRIOR_QS2_LOG_FINAL_EXIT';
                     bootstrap_status_altered = 'PRIOR_QS2_FINAL_STATUS'; precheck_other_zip = 'PRIOR_QS2_OTHER_ZIP' }
foreach ($k in $want16.Keys) {
    Write-Host ('H16_NEG ' + $k + ' -> ' + $neg[$k])
    Assert-True ($neg[$k] -eq $want16[$k]) ('H16 negative ' + $k + ' got ' + $neg[$k])
}
$results['H16_B07_PRIOR_QS2_REQUIRED'] = 'PASS'

foreach ($k in $results.Keys) { Write-Host ($k + '=' + $results[$k]) }
Write-Host 'HARNESS=PASS'
exit 0
