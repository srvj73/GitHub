"""PHASE_B_ADAPTER_V001 — construtores de fixture para QS1 (sandbox ou alvo; nunca CONTROL real).

Todas as escritas ocorrem em diretórios temporários próprios. O payload E01 é somente lido.
Dados SINTÉTICOS (rotulados): sessões econômicas vazias para T13/T17/T32; barra M1 2025-12-30
apenas para permitir build_expected congelado no T14F.
"""
from __future__ import annotations

import copy
import gzip
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path

ADAPTER = Path(__file__).resolve().parents[1]
if str(ADAPTER) not in sys.path:
    sys.path.insert(0, str(ADAPTER))

from phase_b_contract import load_constants  # noqa: E402
from phase_b_effects import AdapterBlocked, canonical_bytes, sha256_file  # noqa: E402
from phase_b_state import seal_key  # noqa: E402


def payload() -> Path:
    p = os.environ.get("MINOTAURO_E01_PAYLOAD")
    if not p or not Path(p, "CODE", "SHA256SUMS.txt").is_file():
        raise RuntimeError("MINOTAURO_E01_PAYLOAD must point to E01 EVIDENCE/payload")
    return Path(p)


def constants() -> dict:
    return load_constants(ADAPTER / "phase_b_constants.json")


def import_code():
    code = str(payload() / "CODE")
    if code not in sys.path:
        sys.path.insert(0, code)
    import minotauro_v004_core as core
    import minotauro_v004_io as fio
    import minotauro_v004_runner as base
    import r1r11_coordinator as coord
    import r1r11_v4_transaction as tx
    import r1r11_v4_custody as custody
    import minotauro_v005r1_r23_contract as fcontract
    return {"core": core, "io": fio, "base": base, "coord": coord, "tx": tx, "custody": custody, "fcontract": fcontract}


def copy_control(dst: Path) -> Path:
    shutil.copytree(payload() / "CONTROL", dst)
    return dst


def copy_preflight(dst: Path) -> Path:
    shutil.copytree(payload() / "PREFLIGHT", dst)
    # par extrínseco vazio fixado (N-17): o E01 só captura arquivos, a árvore registra os diretórios
    (dst / "_TMP_SAME_VOLUME_PHASE_B" / "_avast_").mkdir(parents=True, exist_ok=True)
    return dst


class FakePlatform:
    """Plataforma de TESTE (não Win32). Nunca usada por phase_b_entry."""

    def __init__(self, free=10 ** 13, observed=None):
        self.free, self.held, self.observed = free, {}, observed or {}

    def acquire_named_mutex(self, name):
        if name in self.held:
            raise AdapterBlocked("MUTEX_ACTIVE_OR_UNAVAILABLE", name)
        self.held[name] = True
        return name

    def release_named_mutex(self, h):
        self.held.pop(h)

    def runtime_observation(self):
        return dict(self.observed)

    def free_bytes(self, path):
        return self.free

    def host_observation(self, paths):
        return {"logical_cpus": os.cpu_count(), "platform": "FIXTURE_FAKE_PLATFORM", "volumes": {},
                "status": "FIXTURE"}


def write_gz_lines(path: Path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as gz:
            for r in rows:
                gz.write((json.dumps(r, sort_keys=True, separators=(",", ":")) + "\n").encode())


def build_in_progress(control: Path, consts: dict, code: dict, sessions: list[str], *,
                      identity: dict | None = None, runtime_hashes: dict | None = None,
                      verified_months: dict | None = None, adapter_identity_sha: str = "A" * 64) -> dict:
    """CONTROL sintético IN_PROGRESS a partir dos 23 PREPARED exatos do E01 (sessões econômicas vazias)."""
    base, core = code["base"], code["core"]
    cells = [c for c in core.valid_cells() if c.cell_id == consts["baseline_cell_id"]]
    keys = ("spec_sha256", "runner_sha256", "grid_sha256", "preflight_status_sha256", "session_calendar_sha256",
            "expected_sessions_sha256", "source_inventory_sha256", "run_source_binding_sha256", "config_sha256", "parser_version")
    identity = identity or {k: "FIXTURE_" + k for k in keys}
    runtime_hashes = runtime_hashes or {"fixture": "hash"}
    po = control / "PHASE_B"
    cp = base._new_checkpoint("B", cells, identity, runtime_hashes)
    cp["completed"] = sorted(sessions)
    cp["last_committed_session_date"] = max(sessions) if sessions else None
    cp["verified_months"] = verified_months or {}
    base._write_checkpoint(po / "CHECKPOINT.json", cp)
    (po / "_commit_journal").mkdir(exist_ok=True)
    (po / "sessions").mkdir(exist_ok=True)
    key = seal_key(control)
    seals = control / "TELEMETRY" / "SESSION_SEALS" / key
    seals.mkdir(parents=True, exist_ok=True)
    for s in sessions:
        d = po / "sessions" / s
        for n in ("trades", "events", "equity", "equity_reconciliation"):
            write_gz_lines(d / f"{n}.jsonl.gz", [])
        (d / "session_receipt.json").write_bytes(canonical_bytes({"session": s, "trades": 0}))
        files = {n: sha256_file(d / n) for n in consts["run_owned_names"]["session_files"]}
        (seals / f"{s}.json").write_bytes(canonical_bytes({"session": s, "out": str(po.resolve()), "files": files}))
    (control / "TELEMETRY" / "R1R11_STATUS.json").write_bytes(canonical_bytes({"PROCESS_TREE_CLEAN": "YES"}))
    rb = {"schema": "MINOTAURO_PHASE_B_ADAPTER_RUN_BINDING_V001", "adapter_identity_sha256": adapter_identity_sha,
          "constants_sha256": consts["_sha256"], "envelope_sha256": consts["envelope"]["sha256"],
          "code_manifest_sha256": consts["frozen_code"]["manifest_sha256"],
          "runner_identity_sha256": consts["frozen_code"]["runner_identity_sha256"],
          "first_attempt_id": "20261002T000000Z_00000000", "phase": "B", "phase_c_authorized": "NO"}
    (control / consts["run_owned_names"]["run_binding"]).write_bytes(canonical_bytes(rb))
    return {"cells": cells, "identity": identity, "runtime_hashes": runtime_hashes, "checkpoint": cp}


def expected_sessions(consts: dict) -> list[str]:
    from phase_b_contract import rows_from_bytes
    rows = rows_from_bytes((payload() / "PREFLIGHT" / "PHASE_B" / "EXPECTED_SESSIONS_PHASE_B.csv").read_bytes())
    return [r["session_date"] for r in rows]


def fixture_constants(**overrides) -> dict:
    c = copy.deepcopy(constants())
    for k, v in overrides.items():
        cur = c
        parts = k.split("__")
        for p in parts[:-1]:
            cur = cur[p]
        cur[parts[-1]] = v
    return c


def sha_hex_lower(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()
