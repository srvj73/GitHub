"""PHASE_B_ADAPTER_V001 — QS1 (fixtures). Executar com: python -B tests/run_qs1.py
Requer MINOTAURO_E01_PAYLOAD. Nunca toca CONTROL/PREFLIGHT/CODE reais: tudo em diretórios temporários.
"""
from __future__ import annotations

import copy
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import qs1_fixtures as fx  # noqa: E402

from phase_b_contract import (config_validate, d1b_validate, final_validate, inputs_validate,  # noqa: E402
                              load_json_strict, preflight_validate, render_d1_extract, rows_from_bytes,
                              run_binding_compare, run_binding_document, tick_rehash)
from phase_b_effects import (AdapterBlocked, canonical_bytes, classify_exit, inventory,  # noqa: E402
                             normalize_trace, sha256_bytes, sha256_file)
from phase_b_state import (BLOCKED, EMPTY, FINAL_VALID, IN_PROGRESS, PREPARED,  # noqa: E402
                           classify_structure, journal_preview)

CODE = fx.import_code()
C = fx.constants()
P = fx.payload()
PO_E01 = P / "CONTROL" / "PHASE_B"
CAL = rows_from_bytes((PO_E01 / "SESSION_CALENDAR_PHASE_B.csv").read_bytes())
EXP = rows_from_bytes((PO_E01 / "EXPECTED_SESSIONS_PHASE_B.csv").read_bytes())
EXT_BYTES = (PO_E01 / "D1_PREDECESSOR_EXTRACT_PHASE_B.csv").read_bytes()
BINDING = json.loads((PO_E01 / "RUN_SOURCE_BINDING_B.json").read_text(encoding="utf-8"))
BARS = CODE["io"].load_d1(P / "DATA" / "IND_D1.csv")
IND_SHA = sha256_file(P / "DATA" / "IND_D1.csv")
COLS = C["d1b"]["columns"]


def ext_from_rows(rows) -> bytes:
    buf = io.StringIO(newline="")
    import csv
    w = csv.DictWriter(buf, fieldnames=COLS, delimiter=";", lineterminator="\n")
    w.writeheader()
    for r in rows:
        w.writerow(r)
    return buf.getvalue().encode()


def code_of(fn):
    try:
        fn()
    except AdapterBlocked as e:
        return e.code
    except Exception as e:  # noqa: BLE001
        return "EXC:" + type(e).__name__ + ":" + str(e)[:80]
    return "NO_ERROR"


class T01_LegacyA(unittest.TestCase):
    def test_legacy_a_identical_and_seam_restores_identity(self):
        base = CODE["base"]
        a = P / "PARENT_2025" / "PHASE_A" / "D1_PREDECESSOR_EXTRACT_PHASE_A.csv"
        rows = base.cal(a)
        cols = list(rows[0].keys())
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            cases = {"physical": rows, "dup": rows[:-1] + [dict(rows[0])], "reversed": list(reversed(rows)),
                     "n249": rows[:-1], "n251": rows + [dict(rows[-1], session_date="2026-01-01")]}
            paths = {}
            for k, rr in cases.items():
                CODE["io"].write_csv(td / f"{k}.csv", cols, rr)
                paths[k] = td / f"{k}.csv"
            (td / "schema.csv").write_bytes((td / "physical.csv").read_bytes().replace(b"session_date", b"sessao", 1))
            paths["schema"] = td / "schema.csv"

            def observe():
                out = {}
                for k, p in paths.items():
                    try:
                        r = base._load_d1_extract(p)
                        out[k] = ("OK", len(r), sha256_bytes(canonical_bytes(r)))
                    except Exception as e:  # noqa: BLE001
                        out[k] = ("ERR", type(e).__name__, str(e)[:60])
                return out
            orig = base._load_d1_extract
            before = observe()
            # mesma instalação/restauração do SeamSet (lista fechada) sem executar run_phase
            from phase_b_shared import Frozen, namespace_snapshot
            fz = Frozen({"base": base, "coord": CODE["coord"]})
            snap0 = namespace_snapshot(P / "CODE")
            base._load_d1_extract = lambda p: {}
            base._load_d1_extract = fz.orig_load_d1_extract
            self.assertIs(base._load_d1_extract, orig)
            self.assertEqual(namespace_snapshot(P / "CODE"), snap0)
            after = observe()
        self.assertEqual(before, after)
        self.assertEqual(before["physical"][0:2], ("OK", 250))
        self.assertEqual(before["dup"][0:2], ("OK", 249))          # defeito legado preservado (W02)
        self.assertEqual(before["reversed"][2], before["physical"][2])
        self.assertEqual(before["n249"][0], "ERR")
        self.assertEqual(before["n251"][0], "ERR")


class T02_B166Pass(unittest.TestCase):
    def test_contract_pass_and_legacy_shape(self):
        s = d1b_validate(EXT_BYTES, CAL, EXP, BARS, C, extract_sha_expected=C["d1b"]["extract_sha256"],
                         binding=BINDING, ind_sha=IND_SHA)
        self.assertEqual((s["sessions"], s["first"], s["last"], s["first_predecessor"]),
                         (166, "2026-01-02", "2026-08-31", "2025-12-30"))
        derived = render_d1_extract(COLS, CAL, BARS)
        self.assertEqual(sha256_bytes(derived), C["d1b"]["extract_sha256"])
        shaped = {r["session_date"]: r for r in CODE["base"].cal(PO_E01 / "D1_PREDECESSOR_EXTRACT_PHASE_B.csv")}
        for row in CAL:
            CODE["base"]._verify_d1_bar(row["session_date"], row, BARS[row["expected_previous_session_date"]], shaped)


class T03_T10_D1Negatives(unittest.TestCase):
    def v(self, ext=None, cal=None, exp=None, binding=None):
        return code_of(lambda: d1b_validate(ext if ext is not None else EXT_BYTES, cal or CAL, exp or EXP, BARS, C,
                                            extract_sha_expected=None, binding=binding))

    def test_matrix(self):
        E = rows_from_bytes(EXT_BYTES)
        self.assertEqual(self.v(ext_from_rows(E[:165])), "D1B_CARDINALITY")                                     # T03
        self.assertEqual(self.v(ext_from_rows(E + [dict(E[-1], session_date="2026-09-01")])), "D1B_CARDINALITY")  # T04
        x = copy.deepcopy(E); x[10] = dict(x[9])
        self.assertEqual(self.v(ext_from_rows(x)), "D1B_DUPLICATE")                                              # T05
        x = copy.deepcopy(E); x[5] = dict(x[5], session_date="2026-01-01")
        self.assertIn(self.v(ext_from_rows(x)), ("D1B_SEQUENCE", "D1B_RANGE"))                                   # T06
        x = copy.deepcopy(E); x[0] = dict(x[0], session_date="2026-01-03")
        self.assertEqual(self.v(ext_from_rows(x)), "D1B_SEQUENCE")                                              # T06b
        x = copy.deepcopy(E); x[3], x[4] = x[4], x[3]
        self.assertEqual(self.v(ext_from_rows(x)), "D1B_ORDER")                                                 # T07
        self.assertEqual(self.v(ext_from_rows(list(reversed(E)))), "D1B_ORDER")
        self.assertEqual(self.v(EXT_BYTES.replace(b"open_micro", b"open", 1)), "D1B_SCHEMA")                     # T08
        self.assertEqual(self.v(b"\xef\xbb\xbf" + EXT_BYTES), "D1B_SCHEMA")
        self.assertEqual(self.v(EXT_BYTES.replace(b"\n", b"\r\n")), "D1B_SCHEMA")
        x = copy.deepcopy(E); x[7]["open_micro"] = "1.5"
        self.assertEqual(self.v(ext_from_rows(x)), "D1B_SCHEMA")
        x = copy.deepcopy(E); x[0]["expected_previous_session_date"] = "2025-12-29"
        self.assertEqual(self.v(ext_from_rows(x)), "D1B_PREDECESSOR_3WAY")                                       # T09a
        # T09b — calendário adulterado + extract rederivado do mesmo calendário (tautologia do congelado)
        calb = copy.deepcopy(CAL); calb[0]["expected_previous_session_date"] = "2025-12-29"
        derived = render_d1_extract(COLS, calb, BARS)
        shaped = {r["session_date"]: r for r in rows_from_bytes(derived)}
        for row in calb:
            CODE["base"]._verify_d1_bar(row["session_date"], row, BARS[row["expected_previous_session_date"]], shaped)
        self.assertEqual(self.v(derived, cal=calb), "D1B_PREDECESSOR_3WAY")
        x = copy.deepcopy(E); x[0]["open_micro"] = str(int(x[0]["open_micro"]) + 1)
        self.assertEqual(self.v(ext_from_rows(x)), "D1B_OHLC")                                                  # T10
        b2 = dict(BINDING); b2["ind_d1_sha256"] = "0" * 64
        self.assertEqual(code_of(lambda: d1b_validate(EXT_BYTES, CAL, EXP, BARS, C, binding=b2, ind_sha=IND_SHA)),
                         "D1B_BINDING_SELF_HASH")
        self.assertEqual(code_of(lambda: d1b_validate(EXT_BYTES, CAL, EXP, BARS, C, extract_sha_expected="0" * 64)),
                         "D1B_EXTRACT_SHA")


class T11_Calendar(unittest.TestCase):
    def test_a_missing_injection_fail_closed(self):
        R = CODE["coord"].Runtime

        class Fake:
            _load_sealed_calendar = R._load_sealed_calendar
        f = Fake()
        with tempfile.TemporaryDirectory() as td:
            f.root, f._calendar_cache, f.synthetic_calendar_rows = Path(td), None, {}
            R.set_synthetic_calendar_row(f, "2026-01-02", {"session_date": "2026-01-02"})
            self.assertEqual(R._calendar_row(f, "2026-01-02"), {"session_date": "2026-01-02"})
            with self.assertRaises(Exception) as cm:
                R._calendar_row(f, "2026-01-05")
            self.assertIn("C1_SEALED_CALENDAR_ARTIFACTS_REQUIRED", str(cm.exception))

    def test_b_phase_a_present_blocks(self):
        with tempfile.TemporaryDirectory() as td:
            ctl = fx.copy_control(Path(td) / "CONTROL")
            (ctl / "PHASE_A").mkdir()
            st = classify_structure(inventory(ctl), C, ctl)
            self.assertEqual(st["state"], BLOCKED)
            self.assertIn("FORBIDDEN_PHASE_ROOT:PHASE_A", st["findings"])


class T12_Config(unittest.TestCase):
    def wanted(self):
        return json.loads((P / "CONTROL" / "FULL_2026_CONFIGURATION.json").read_text(encoding="utf-8"))

    def run_cfg(self, raw: bytes, pin_raw: bool = True):
        c = fx.fixture_constants()
        if pin_raw:
            c["config"]["sha256"] = sha256_bytes(raw)
        return code_of(lambda: config_validate(raw, c, self.wanted()))

    def test_variants(self):
        raw = (P / "CONTROL" / "FULL_2026_CONFIGURATION.json").read_bytes()
        self.assertEqual(code_of(lambda: config_validate(raw, C, self.wanted())), "NO_ERROR")
        w = self.wanted()
        self.assertEqual(self.run_cfg(json.dumps(dict(w, extra=None)).encode(), pin_raw=False), "CONFIG_SHA_DRIFT")
        self.assertEqual(self.run_cfg(json.dumps(dict(w, extra=None)).encode()), "CONFIG_KEYSET_MISMATCH")
        m = dict(w); m.pop("workers")
        self.assertEqual(self.run_cfg(json.dumps(m).encode()), "CONFIG_KEYSET_MISMATCH")
        self.assertEqual(self.run_cfg(json.dumps(dict(w, workers=None)).encode()), "CONFIG_VALUE_MISMATCH")
        self.assertEqual(self.run_cfg(json.dumps(w, sort_keys=False, indent=2).encode()), "NO_ERROR")
        dup = raw.replace(b'"workers"', b'"workers":15,"workers"', 1)
        self.assertEqual(self.run_cfg(dup), "JSON_DUPLICATE_KEY")
        # tuple/list: domínio JSON
        wt = dict(w); wt["phase_ranges"] = {"B": ("2026-01-01", "2026-08-31"), "C": ("2026-09-01", "2026-09-11")}
        self.assertEqual(code_of(lambda: config_validate(raw, C, wt)), "NO_ERROR")


class T13_T32_Final(unittest.TestCase):
    """T32 (finalize congelado em fixture com forma de B, 166 sessões vazias) e T13 (FINAL inválido)."""

    @classmethod
    def setUpClass(cls):
        cls.td = tempfile.TemporaryDirectory()
        root = Path(cls.td.name)
        cls.sessions = fx.expected_sessions(C)
        vm = {t["path"]: t["sha256"] for t in C["inputs"]["ticks"]}
        cls.parent = {"selected": None, "status": "NO_CANDIDATE", "freeze_sha256": C["parent_2025"]["freeze_sha256"],
                      "homologation_sha256": C["parent_2025"]["homologation_sha256"]}
        import r1r11_full_2026 as full
        cls.full = full
        # referência ininterrupta
        cls.ref = fx.copy_control(root / "REF" / "CONTROL")
        cls.ctx = fx.build_in_progress(cls.ref, C, CODE, cls.sessions, verified_months=vm)
        with redirect_stdout(io.StringIO()):
            full.finalize_phase(cls.ref, "B", cls.ctx["cells"], cls.parent)
        cls.vm = vm

    @classmethod
    def tearDownClass(cls):
        cls.td.cleanup()

    def verify_seals(self, control):
        class V:
            pass
        v = V(); v.telemetry = control / "TELEMETRY" / "R1R11_TRANSPORT.jsonl"
        return lambda po, cp: CODE["coord"].Runtime.verify_committed(v, po, cp)

    def test_t32_final_valid_and_refinalization_after_interrupt(self):
        st = classify_structure(inventory(self.ref), C, self.ref)
        self.assertEqual(st["state"], FINAL_VALID, st["findings"])
        r = final_validate(self.ref / "PHASE_B", C, EXP, self.verify_seals(self.ref))
        self.assertGreater(r["manifest_entries"], 160)
        with tempfile.TemporaryDirectory() as td:
            ctl = fx.copy_control(Path(td) / "CONTROL")
            fx.build_in_progress(ctl, C, CODE, self.sessions, verified_months=self.vm)
            sys.path.insert(0, str(fx.ADAPTER / "qualification"))
            import phase_b_qualification_seams as qseams
            try:
                with qseams.InterruptAfter(sys.modules, "FINALIZE_TRADES_CSV"):
                    with self.assertRaises(KeyboardInterrupt), redirect_stdout(io.StringIO()):
                        self.full.finalize_phase(ctl, "B", self.ctx["cells"], self.parent)
            finally:
                sys.modules.pop("phase_b_qualification_seams", None)
                sys.path.remove(str(fx.ADAPTER / "qualification"))
            self.assertFalse((ctl / "PHASE_B" / "PHASE_B_FINAL_REPORT.json").exists())
            st = classify_structure(inventory(ctl), C, ctl)
            self.assertEqual(st["state"], IN_PROGRESS)
            self.assertIn("FINALIZE_PENDING", st["findings"])
            with redirect_stdout(io.StringIO()):
                self.full.finalize_phase(ctl, "B", self.ctx["cells"], self.parent)
            a, b = inventory(ctl / "PHASE_B"), inventory(self.ref / "PHASE_B")
            self.assertEqual(a["files"], b["files"])  # refinalização determinística byte a byte

    def mutate_and_check(self, fn):
        # mesma localização física (seals são chaveados pelo caminho, N-04): ref -> backup, cópia -> ref
        ctl, bak = self.ref, self.ref.with_name("CONTROL_BAK")
        ctl.rename(bak)
        try:
            shutil.copytree(bak, ctl)
            fn(ctl)
            st = classify_structure(inventory(ctl), C, ctl)
            if st["state"] == BLOCKED:
                return "STATE_BLOCKED:" + ";".join(st["findings"])
            return code_of(lambda: final_validate(ctl / "PHASE_B", C, EXP, self.verify_seals(ctl)))
        finally:
            shutil.rmtree(ctl, ignore_errors=True)
            bak.rename(ctl)

    def test_t29_relocated_control_blocks(self):
        with tempfile.TemporaryDirectory() as td:
            moved = Path(td) / "ELSEWHERE" / "CONTROL"
            shutil.copytree(self.ref, moved)
            st = classify_structure(inventory(moved), C, moved)
            self.assertEqual(st["state"], BLOCKED)
            self.assertTrue(any(f.startswith("SEAL_KEY_FOREIGN") for f in st["findings"]), st)

    def test_t13_invalid_final_variants(self):
        fr = "PHASE_B/PHASE_B_FINAL_REPORT.json"

        def w(rel, data):
            return lambda c: (c / rel).write_bytes(data)

        def edit_report(**kv):
            def f(c):
                d = json.loads((c / fr).read_text())
                d.update(kv)
                (c / fr).write_bytes(canonical_bytes(d))
            return f
        self.assertEqual(self.mutate_and_check(w(fr, b"not json")), "JSON_INVALID")
        self.assertEqual(self.mutate_and_check(w(fr, b'{"status":"PASS"}')), "FINAL_REPORT_INVALID")
        self.assertEqual(self.mutate_and_check(edit_report(schema="X")), "FINAL_REPORT_INVALID")
        self.assertEqual(self.mutate_and_check(edit_report(sessions=165)), "FINAL_REPORT_INVALID")
        self.assertEqual(self.mutate_and_check(edit_report(checkpoint_sha256="0" * 64)), "FINAL_REPORT_INVALID")

        def tamper_manifest_member(c):
            p = c / "PHASE_B" / "MONTHLY_2026_FROZEN_ONLY.csv"
            p.write_bytes(p.read_bytes() + b"x")
        self.assertEqual(self.mutate_and_check(tamper_manifest_member), "FINAL_MANIFEST_HASH")
        self.assertTrue(self.mutate_and_check(lambda c: (c / "PHASE_B" / "CHECKPOINT.json").unlink()).startswith("STATE_BLOCKED"))
        self.assertTrue(self.mutate_and_check(lambda c: (c / "PHASE_C").mkdir()).startswith("STATE_BLOCKED:FORBIDDEN_PHASE_ROOT"))

        def tamper_session(c):
            p = c / "PHASE_B" / "sessions" / self.sessions[3] / "events.jsonl.gz"
            p.write_bytes(p.read_bytes() + b"\0")
        # manifesto mestre detecta antes dos seals (ordem de gates do validador); ambos fail-closed
        self.assertIn(self.mutate_and_check(tamper_session), ("FINAL_MANIFEST_HASH", "EXC:ModelError:COMMITTED_SESSION_HASH_DRIFT"))


class T15_Prepared(unittest.TestCase):
    def test_exact_prepared_and_empty(self):
        with tempfile.TemporaryDirectory() as td:
            ctl = fx.copy_control(Path(td) / "CONTROL")
            self.assertEqual(classify_structure(inventory(ctl), C, ctl)["state"], PREPARED)
            for rel in C["prepared_21"]:
                (ctl / rel).unlink()
            self.assertEqual(classify_structure(inventory(ctl), C, ctl)["state"], EMPTY)

    def test_divergences(self):
        with tempfile.TemporaryDirectory() as td:
            ref = fx.copy_control(Path(td) / "REF")
            for i, rel in enumerate(C["prepared_21"]):                         # 21 mutações de 1 byte
                ctl = Path(td) / f"C{i}"
                shutil.copytree(ref, ctl)
                p = ctl / rel
                b = bytearray(p.read_bytes()); b[0] ^= 0x01; p.write_bytes(bytes(b))
                st = classify_structure(inventory(ctl), C, ctl)
                self.assertEqual(st["state"], BLOCKED, rel)
                self.assertIn(f"PREPARED_DIVERGENT:{rel}", st["findings"])
                shutil.rmtree(ctl)
            for name, fn in {
                "extra": lambda c: (c / "PHASE_B" / "EXTRA.txt").write_text("x"),
                "missing": lambda c: (c / C["prepared_21"][3]).unlink(),
                "av": lambda c: (c / "PHASE_B" / "_avast_").mkdir(),
                "base_drift": lambda c: (c / "FULL_2026_CONFIGURATION.json").write_bytes(b"{}"),
                "phase_c": lambda c: (c / "PHASE_C").mkdir(),
            }.items():
                ctl = Path(td) / ("X_" + name)
                shutil.copytree(ref, ctl)
                fn(ctl)
                self.assertEqual(classify_structure(inventory(ctl), C, ctl)["state"], BLOCKED, name)

    def test_ind_extended_blocks(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            ind = td / "IND.csv"
            ind.write_bytes((P / "DATA" / "IND_D1.csv").read_bytes() + b"2026-09-21,1,2,1,2,,\n")

            class L:
                ind_d1 = str(ind)
                m1_root = str(P / "M1_2026")

                @staticmethod
                def tick_path(raw):
                    return Path(raw)
            self.assertEqual(code_of(lambda: inputs_validate(L, C)), "INPUT_IND_DRIFT")


class T17_JournalCheckpoint(unittest.TestCase):
    def build(self, td, sessions):
        ctl = fx.copy_control(Path(td) / "CONTROL")
        ctx = fx.build_in_progress(ctl, C, CODE, sessions)
        return ctl, ctx

    def test_structural_inconsistencies(self):
        s3 = fx.expected_sessions(C)[:3]
        with tempfile.TemporaryDirectory() as td:
            ctl, _ = self.build(td, s3)
            self.assertEqual(classify_structure(inventory(ctl), C, ctl)["state"], IN_PROGRESS)
        cases = {
            "extra_session": lambda c: fx.write_gz_lines(c / "PHASE_B" / "sessions" / "2026-01-07" / "trades.jsonl.gz", []),
            "missing_session": lambda c: shutil.rmtree(c / "PHASE_B" / "sessions" / s3[1]),
            "pending_without_journal": lambda c: fx.write_gz_lines(c / "PHASE_B" / "sessions" / "2026-01-07.pending" / "trades.jsonl.gz", []),
            "two_journals": lambda c: [(c / "PHASE_B" / "_commit_journal" / f"2026-01-0{d}.1_2.json").write_text("{}") for d in (7, 8)],
            "seal_missing": lambda c: (c / "TELEMETRY" / "SESSION_SEALS" / fx.seal_key(c) / f"{s3[0]}.json").unlink(),
            "foreign_seal_key": lambda c: ((c / "TELEMETRY" / "SESSION_SEALS" / ("f" * 64)).mkdir(),
                                           (c / "TELEMETRY" / "SESSION_SEALS" / ("f" * 64) / "2026-01-02.json").write_text("{}")),
            "no_run_binding": lambda c: (c / C["run_owned_names"]["run_binding"]).unlink(),
            "checkpoint_tmp_without_journal": lambda c: (c / "PHASE_B" / "CHECKPOINT.json.v004-next").write_text("{}"),
            "unknown": lambda c: (c / "PHASE_B" / "_orphan").mkdir(),
            "out_of_scope_completed": lambda c: None,
        }
        for name, fn in cases.items():
            if name == "out_of_scope_completed":
                continue
            with tempfile.TemporaryDirectory() as td:
                ctl, _ = self.build(td, s3)
                fn(ctl)
                st = classify_structure(inventory(ctl), C, ctl)
                self.assertEqual(st["state"], BLOCKED, (name, st))

    def test_frozen_checkpoint_identity_and_journal_preview(self):
        base, tx, custody = CODE["base"], CODE["tx"], CODE["custody"]
        s3 = fx.expected_sessions(C)[:3]
        with tempfile.TemporaryDirectory() as td:
            ctl, ctx = self.build(td, s3)
            cp_path = ctl / "PHASE_B" / "CHECKPOINT.json"
            before = cp_path.read_bytes()
            base._load_checkpoint(cp_path, "B", ctx["cells"], ctx["identity"], ctx["runtime_hashes"])
            self.assertEqual(cp_path.read_bytes(), before)                     # somente leitura (DD-3)
            bad = dict(ctx["identity"], config_sha256="other")
            self.assertIn("RESUME_HASH_MISMATCH config_sha256",
                          code_of(lambda: base._load_checkpoint(cp_path, "B", ctx["cells"], bad, ctx["runtime_hashes"])))
            self.assertIn("RESUME_HASH_MISMATCH phase",
                          code_of(lambda: base._load_checkpoint(cp_path, "A", ctx["cells"], ctx["identity"], ctx["runtime_hashes"])))
            # journal sintético válido (roll-back) + preview somente leitura
            po = ctl / "PHASE_B"
            cp = json.loads(cp_path.read_text())
            s = fx.expected_sessions(C)[3]
            nxt = dict(cp); nxt["completed"] = sorted(cp["completed"] + [s]); nxt["last_committed_session_date"] = s
            nxt["completed_sessions_sha256"] = base._hash_completed(nxt["completed"])
            nxt = base._checkpoint_with_hash(nxt)
            nb = canonical_bytes(nxt)
            import hashlib
            j = {"version": "V005R1", "out_root": str(po.resolve()), "session": s, "run_instance": "11_22",
                 "checkpoint_path": str(cp_path.resolve()), "checkpoint_previous_sha256": hashlib.sha256(before).hexdigest(),
                 "checkpoint_next": nxt, "checkpoint_next_sha256": hashlib.sha256(nb).hexdigest(), "files": {}}
            j["journal_sha256"] = hashlib.sha256(canonical_bytes(j)).hexdigest()
            jrel = f"PHASE_B/_commit_journal/{s}.11_22.json"
            (ctl / jrel).write_bytes(canonical_bytes(j))
            (po / "sessions" / (s + ".pending")).mkdir()
            fx.write_gz_lines(po / "sessions" / (s + ".pending") / "trades.jsonl.gz", [])
            st = classify_structure(inventory(ctl), C, ctl)
            self.assertEqual(st["state"], IN_PROGRESS, st)
            pv = journal_preview(ctl, (jrel, s, "11_22"))
            self.assertEqual((pv["outcome"], pv["checkpoint"]), ("ROLL_BACK", "PREVIOUS"))
            cp_path.write_bytes(b"{}\n")
            self.assertEqual(code_of(lambda: journal_preview(ctl, (jrel, s, "11_22"))), "CHECKPOINT_THIRD_STATE")
            cp_path.write_bytes(before)
            (po / "sessions" / s).mkdir()
            self.assertEqual(code_of(lambda: journal_preview(ctl, (jrel, s, "11_22"))), "BOTH_FINAL_AND_PENDING")


class T20_NegativeControls(unittest.TestCase):
    """Controle negativo por gate: com o gate trocado por no-op, o caso violador deixa de ser detectado."""

    def test_mutants_killed(self):
        import phase_b_contract as pc
        import phase_b_shared as ps
        import phase_b_state as pst
        E = rows_from_bytes(EXT_BYTES)
        x = copy.deepcopy(E); x[10] = dict(x[9])
        cfg_raw = json.dumps({"x": None}).encode()
        with tempfile.TemporaryDirectory() as td:
            ctl = fx.copy_control(Path(td) / "CONTROL")
            (ctl / "PHASE_A").mkdir()
            pre = fx.copy_preflight(Path(td) / "PREFLIGHT")
            (pre / "PHASE_B" / "PHASE_STATUS.json").write_bytes(b"{}")
            cases = {
                "G15_d1b": (lambda f: f(ext_from_rows(x), CAL, EXP, BARS, C), pc, "d1b_validate"),
                "G10_config": (lambda f: f(cfg_raw, C, {}), pc, "config_validate"),
                "G13_preflight": (lambda f: f(pre, C), pc, "preflight_validate"),
                "G12_state": (lambda f: (_ for _ in ()).throw(AdapterBlocked("STATE_BLOCKED_AMBIGUOUS"))
                              if f(inventory(ctl), C, ctl)["state"] == BLOCKED else None, pst, "classify_structure"),
                "G03_runtime": (lambda f: f({"python_exe": "x"}, C), ps, "gate_g03_runtime"),
                "G00_entry": (lambda f: f(True, C, "run-b"), ps, "gate_g00"),
            }
            killed = {}
            for name, (call, mod, attr) in cases.items():
                orig = getattr(mod, attr)
                real = code_of(lambda: call(orig))
                self.assertNotEqual(real, "NO_ERROR", name)
                mutant = (lambda *a, **k: {"state": PREPARED}) if attr == "classify_structure" else (lambda *a, **k: {})
                killed[name] = code_of(lambda: call(mutant)) == "NO_ERROR"
            self.assertTrue(all(killed.values()), killed)


class T21_PhaseC(unittest.TestCase):
    def test_argv_and_guards(self):
        from phase_b_entry import parse_argv
        from phase_b_shared import gate_g00, phase_b_only
        self.assertIsNone(parse_argv(["C"]))
        self.assertIsNone(parse_argv(["dry-run-b", "--attempt-id", "20261002T000000Z_0000abcd", "--phase", "C"]))
        self.assertIsNone(parse_argv(["run-c"]))
        self.assertIsNone(parse_argv(["dry-run-b"]))
        self.assertIsNotNone(parse_argv(["dry-run-b", "--attempt-id", "20261002T000000Z_0000abcd"]))
        self.assertEqual(code_of(lambda: phase_b_only(lambda out, phase: phase)("x", "C")), "PHASE_NOT_B")
        self.assertEqual(code_of(lambda: gate_g00(True, C, "run-b")), "RUN_B_DISABLED_IN_PACKAGE_IDENTITY")
        r = subprocess.run([sys.executable, "-B", str(fx.ADAPTER / "phase_b_entry.py"), "run-b", "--attempt-id",
                            "20261002T000000Z_0000abcd", "--policy-receipt", "a", "--run-authorization", "b",
                            "--dry-receipt", "c"], capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        self.assertEqual(r.returncode, 2, r.stdout + r.stderr)
        self.assertIn("RUN_B_DISABLED_IN_PACKAGE_IDENTITY", r.stdout)
        r = subprocess.run([sys.executable, "-B", str(fx.ADAPTER / "phase_b_entry.py"), "run-c"],
                           capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        self.assertEqual(r.returncode, 2)


class T24_ExitClassification(unittest.TestCase):
    def test_matrix(self):
        def ce(mode, **kw):
            base = dict(outcome="BLOCKED", f1_marked=False, control_changed=False, runtime_started=False,
                        runtime_tree_clean=False, reclass_state=None)
            base.update(kw)
            return classify_exit(mode, **base)[0]
        self.assertEqual(ce("DRY", outcome="PASS"), 0)
        self.assertEqual(ce("DRY", outcome="PASS", control_changed=True), 3)
        self.assertEqual(ce("DRY"), 2)
        self.assertEqual(ce("DRY", control_changed=True), 3)
        self.assertEqual(ce("DRY", outcome="INTERRUPT"), 130)
        self.assertEqual(ce("DRY", outcome="INTERRUPT", runtime_started=True), 2)
        self.assertEqual(ce("DRY", outcome="INTERRUPT", runtime_started=True, runtime_tree_clean=True), 130)
        self.assertEqual(ce("RUN", outcome="INTERRUPT"), 130)
        self.assertEqual(ce("RUN", outcome="INTERRUPT", f1_marked=True), 3)
        self.assertEqual(ce("RUN", outcome="INTERRUPT", f1_marked=True, runtime_started=True, runtime_tree_clean=True,
                            reclass_state="IN_PROGRESS"), 130)
        self.assertEqual(ce("RUN", outcome="INTERRUPT", f1_marked=True, runtime_started=True, runtime_tree_clean=True,
                            reclass_state="BLOCKED_AMBIGUOUS"), 3)
        self.assertEqual(ce("RUN", f1_marked=True), 3)
        self.assertEqual(ce("RUN", outcome="ERROR"), 2)

    def test_b01_pass_paths(self):
        """B01: RUN concluído com G24 validado => 0 sem PARTIAL_EFFECT; deriva de PREFLIGHT/CODE nunca é PASS."""
        def ce(mode, **kw):
            base = dict(outcome="PASS", f1_marked=False, control_changed=False, runtime_started=False,
                        runtime_tree_clean=False, reclass_state=None)
            base.update(kw)
            return classify_exit(mode, **base)
        code, labels = ce("RUN", f1_marked=True, control_changed=True, run_post_validated=True)
        self.assertEqual(code, 0)
        self.assertNotIn("PARTIAL_EFFECT", labels)
        self.assertEqual(labels.get("EFFECT"), "COMPLETE_FINAL_VALID")
        self.assertEqual(ce("RUN", run_post_validated=True)[0], 0)  # FINAL_VALID já existente: sem F1
        self.assertEqual(ce("RUN", f1_marked=True, control_changed=True, run_post_validated=False)[0], 3)
        self.assertEqual(ce("RUN", run_post_validated=False)[0], 2)
        for mode in ("RUN", "DRY", "CLASSIFY"):
            code, labels = ce(mode, f1_marked=mode == "RUN", control_changed=mode == "RUN",
                              run_post_validated=True, protected_input_changed=True)
            self.assertEqual(code, 3, mode)
            self.assertEqual(labels["INCIDENT"], "PROTECTED_INPUT_CHANGED_ON_PASS_PATH")
        self.assertEqual(ce("DRY", control_changed=True)[0], 3)
        self.assertEqual(ce("CLASSIFY", control_changed=True)[0], 3)
        self.assertEqual(ce("CLASSIFY")[1], {"PARTIAL_EFFECT": "NO"})
        self.assertEqual(classify_exit("DRY", outcome="INTERRUPT", f1_marked=False, control_changed=False,
                                       runtime_started=False, runtime_tree_clean=False, reclass_state=None,
                                       protected_input_changed=True)[0], 3)
        with self.assertRaises(ValueError):
            classify_exit("C", outcome="PASS", f1_marked=False, control_changed=False, runtime_started=False,
                          runtime_tree_clean=False, reclass_state=None)

    def test_b02_receipt_downgrade(self):
        from phase_b_effects import downgrade_for_missing_receipt
        self.assertEqual(downgrade_for_missing_receipt(0, effect=False), 2)
        self.assertEqual(downgrade_for_missing_receipt(0, effect=True), 3)
        self.assertEqual(downgrade_for_missing_receipt(130, effect=True), 3)
        self.assertEqual(downgrade_for_missing_receipt(130, effect=False), 2)
        self.assertEqual(downgrade_for_missing_receipt(2, effect=False), 2)
        self.assertEqual(downgrade_for_missing_receipt(3, effect=True), 3)


class T24b_RunFinishIntegration(unittest.TestCase):
    """B01 + B02 em finish() real (modo RUN), com raízes temporárias: o RUN concluído altera CONTROL por contrato."""

    def make(self, td, gates):
        from phase_b_shared import Layout, Session, snapshot_digests
        td = Path(td)
        roots = {}
        for n in ("control", "preflight", "code", "package"):
            roots[n] = td / n
            roots[n].mkdir()
            (roots[n] / "f.txt").write_text(n)
        lay = Layout(release_root=str(td / "rel"), code_root=str(roots["code"]), control_root=str(roots["control"]),
                     preflight_root=str(roots["preflight"]), shadow_base=str(td / "shadow"), evidence_base=str(td / "ev"),
                     base_csv_root=str(td / "csv"), ind_d1=str(td / "ind"), m1_root=str(td / "m1"),
                     parent_2025_root=str(td / "parent"), g8_local_receipt="x", g8_evidence_zip="x",
                     phase_b_evidence_zip="x", package_root=str(roots["package"]))
        s = Session(mode="RUN", layout=lay, constants=C, platform=fx.FakePlatform(), attempt_id="20261003T000000Z_000000b1")
        s.open_evidence()
        snap = {"control": inventory(roots["control"]), "preflight": inventory(roots["preflight"]),
                "code": inventory(roots["code"]), "package": inventory(roots["package"]), "release_top": {}, "inputs": {}}
        s.record["before_digests"] = snapshot_digests(snap)
        s.gates = gates
        s.f1_marked = True
        (roots["control"] / "PHASE_B_FINAL_REPORT.json").write_text("{}")  # efeito contratado do RUN
        return s, roots

    def run_finish(self, s):
        from phase_b_shared import finish
        buf = io.StringIO()
        with redirect_stdout(buf):
            code = finish(s, "PASS", None)
        return code, buf.getvalue()

    def test_run_pass_after_g24_is_zero(self):
        with tempfile.TemporaryDirectory() as td:
            s, _ = self.make(td, [{"id": "G24", "status": "PASS"}])
            code, out = self.run_finish(s)
            self.assertEqual(code, 0, out)
            rec = json.loads((s.evidence_dir / "RUN_RECEIPT.json").read_text())
            self.assertEqual((rec["exit_code"], rec["result"], rec["run_post_validated"]), (0, "PASS", True))
            self.assertNotIn("PARTIAL_EFFECT", rec["labels"])
            self.assertNotIn("PARTIAL_EFFECT=", out)
            self.assertEqual(rec["protected_delta_at_finish"], ["control"])
            comp = json.loads((s.evidence_dir / "RUN_RECEIPT.VERIFIED.json").read_text())
            self.assertEqual(comp["receipt_sha256"], sha256_file(s.evidence_dir / "RUN_RECEIPT.json"))
            self.assertIsNone(s.heartbeat_thread)

    def test_run_pass_with_preflight_or_code_drift_is_three(self):
        for root in ("preflight", "code"):
            with tempfile.TemporaryDirectory() as td:
                s, roots = self.make(td, [{"id": "G24", "status": "PASS"}])
                (roots[root] / "f.txt").write_text("drift")
                code, out = self.run_finish(s)
                self.assertEqual(code, 3, root)
                rec = json.loads((s.evidence_dir / "RUN_RECEIPT.json").read_text())
                self.assertEqual(rec["labels"]["INCIDENT"], "PROTECTED_INPUT_CHANGED_ON_PASS_PATH")
                self.assertIn(root, rec["protected_delta_at_finish"])

    def test_run_pass_without_g24_is_three(self):
        with tempfile.TemporaryDirectory() as td:
            s, _ = self.make(td, [{"id": "G22", "status": "PASS"}])
            code, _ = self.run_finish(s)
            self.assertEqual(code, 3)

    def test_run_receipt_write_failure_never_zero(self):
        with tempfile.TemporaryDirectory() as td:
            s, _ = self.make(td, [{"id": "G24", "status": "PASS"}])
            s.write_evidence = lambda name, obj: (_ for _ in ()).throw(OSError("SIMULATED"))
            code, out = self.run_finish(s)
            self.assertEqual(code, 3, out)  # efeito em CONTROL => 3, nunca 0
            self.assertIn("RECEIPT_DOWNGRADE=0->3", out)
            self.assertFalse((s.evidence_dir / "RUN_RECEIPT.json").exists())


class TB08_StatusPersistenceNeverPass(unittest.TestCase):
    """B08: falha de persistência do status obrigatório (total, após heartbeats, intermitente, só a final,
    releitura divergente) nunca termina em 0/130; 2/3 conforme efeito protegido; o receipt reflete o status final."""

    def make(self, td, mode, *, g24=True, effect=False):
        from phase_b_shared import Layout, Session, snapshot_digests
        td = Path(td)
        roots = {}
        for n in ("control", "preflight", "code", "package"):
            roots[n] = td / n
            roots[n].mkdir()
            (roots[n] / "f.txt").write_text(n)
        lay = Layout(release_root=str(td / "rel"), code_root=str(roots["code"]), control_root=str(roots["control"]),
                     preflight_root=str(roots["preflight"]), shadow_base=str(td / "shadow"), evidence_base=str(td / "ev"),
                     base_csv_root=str(td / "csv"), ind_d1=str(td / "ind"), m1_root=str(td / "m1"),
                     parent_2025_root=str(td / "parent"), g8_local_receipt="x", g8_evidence_zip="x",
                     phase_b_evidence_zip="x", package_root=str(roots["package"]))
        s = Session(mode=mode, layout=lay, constants=C, platform=fx.FakePlatform(), attempt_id="20261003T000000Z_000000b8")
        snap = {"control": inventory(roots["control"]), "preflight": inventory(roots["preflight"]),
                "code": inventory(roots["code"]), "package": inventory(roots["package"]), "release_top": {}, "inputs": {}}
        s.record["before_digests"] = snapshot_digests(snap)
        s.gates = [{"id": "G24", "status": "PASS"}] if g24 else []
        if effect:
            s.f1_marked = True
            (roots["control"] / "PHASE_B_FINAL_REPORT.json").write_text("{}")
        return s

    def patched(self, behaviour):
        """behaviour(n) -> True para falhar a n-ésima chamada (1-based) de write_status_atomic."""
        import phase_b_shared as ps
        real = ps.write_status_atomic
        calls = {"n": 0}

        def fake(path, obj, *a, **k):
            calls["n"] += 1
            if behaviour(calls["n"], obj):
                raise AdapterBlocked("STATUS_WRITE_FAILED", "SIMULATED")
            return real(path, obj, *a, **k)
        return ps, real, fake, calls

    def run_case(self, mode, behaviour, *, outcome="PASS", g24=True, effect=False, heartbeats=0, liveness=False):
        from phase_b_shared import finish
        with tempfile.TemporaryDirectory() as td:
            s = self.make(td, mode, g24=g24, effect=effect)
            ps, real, fake, calls = self.patched(behaviour)
            ps.write_status_atomic = fake
            buf = io.StringIO()
            try:
                with redirect_stdout(buf):
                    s.open_evidence()
                    for i in range(heartbeats):
                        s.phase = f"G{i + 1:02d}"
                        s.status()
                    if liveness:
                        import time as _t
                        s.stop_heartbeat()
                        s.start_heartbeat(interval=0.1)
                        _t.sleep(0.6)
                    code = finish(s, outcome, None)
            finally:
                ps.write_status_atomic = real
                s.stop_heartbeat()
            name = {"RUN": "RUN_RECEIPT.json", "DRY": "DRY_RECEIPT.json", "CLASSIFY": "CLASSIFY_RECEIPT.json"}[mode]
            rp = s.evidence_dir / name
            rec = json.loads(rp.read_text()) if rp.exists() else None
            stp = s.evidence_dir / "ADAPTER_STATUS.json"
            s.status_bytes_at_end = stp.read_bytes() if stp.exists() else None
            return code, rec, buf.getvalue(), calls["n"], s

    def test_chatgpt_probe_run_g24_total_failure(self):
        """Reprodução do probe externo: RUN com G24 PASS e write_status_atomic falhando sempre (antes: RC=0)."""
        code, rec, out, n, s = self.run_case("RUN", lambda i, o: True, effect=True)
        self.assertEqual(code, 3, out[-1500:])
        self.assertGreaterEqual(s.status_failures, 2)
        self.assertEqual((rec["exit_code"], rec["result"], rec["status_final_persisted"]), (3, "NOT_PASS", False))
        self.assertIsNone(rec["status_final_sha256"])
        self.assertTrue(rec["labels"]["STATUS_PERSISTENCE"].startswith("FAILED:"))
        self.assertEqual(rec["labels"]["STATUS_DOWNGRADE"], "0->3")

    def test_failure_after_some_heartbeats(self):
        for mode, effect, want in (("RUN", True, 3), ("CLASSIFY", False, 2), ("DRY", False, 2)):
            code, rec, out, n, s = self.run_case(mode, lambda i, o: i > 4, effect=effect, heartbeats=6)
            self.assertEqual(code, want, (mode, out[-1500:]))
            self.assertNotIn(rec["exit_code"], (0, 130))
            self.assertFalse(rec["status_final_persisted"])

    def test_failure_in_liveness_ticks_only(self):
        code, rec, out, n, s = self.run_case("CLASSIFY", lambda i, o: o.get("liveness_tick") is True, liveness=True)
        self.assertEqual(code, 2, out[-1500:])
        self.assertGreater(rec["status_write_failures"], 0)
        self.assertTrue(rec["status_final_persisted"])  # a final persistiu, mas a falha anterior já impede PASS

    def test_intermittent_single_failure(self):
        code, rec, out, n, s = self.run_case("RUN", lambda i, o: i == 3, effect=True, heartbeats=5)
        self.assertEqual(code, 3)
        self.assertEqual(rec["status_write_failures"], 1)
        self.assertTrue(rec["status_final_persisted"])

    def test_final_status_only_failure(self):
        def beh(i, obj):
            return obj.get("fields", {}).get("ACTIVE") == "NO"
        code, rec, out, n, s = self.run_case("RUN", beh, effect=True, heartbeats=3)
        self.assertEqual(code, 3)
        self.assertEqual((rec["status_final_persisted"], rec["labels"]["STATUS_FINAL_PERSISTED"]), (False, "NO"))
        code, rec, out, n, s = self.run_case("CLASSIFY", beh, heartbeats=3)
        self.assertEqual(code, 2)

    def test_safe_stop_130_with_status_failure(self):
        code, rec, out, n, s = self.run_case("DRY", lambda i, o: False, outcome="INTERRUPT")
        self.assertEqual(code, 130)  # controle: sem falha de status, SAFE_STOP permanece
        self.assertTrue(rec["status_final_persisted"])
        code, rec, out, n, s = self.run_case("DRY", lambda i, o: i == 2, outcome="INTERRUPT", heartbeats=3)
        self.assertEqual(code, 2)
        self.assertEqual(rec["labels"]["STATUS_DOWNGRADE"], "130->2")

    def test_readback_mismatch_of_final_status(self):
        import phase_b_shared as ps
        from phase_b_shared import finish
        real = ps.write_status_atomic

        def wrong_sha(path, obj, *a, **k):
            sha = real(path, obj, *a, **k)
            return "0" * 64 if obj.get("fields", {}).get("ACTIVE") == "NO" else sha
        with tempfile.TemporaryDirectory() as td:
            s = self.make(td, "RUN", effect=True)
            buf = io.StringIO()
            with redirect_stdout(buf):
                s.open_evidence()
                ps.write_status_atomic = wrong_sha
                try:
                    code = finish(s, "PASS", None)
                finally:
                    ps.write_status_atomic = real
            rec = json.loads((s.evidence_dir / "RUN_RECEIPT.json").read_text())
            self.assertEqual(code, 3)
            self.assertFalse(rec["status_final_persisted"])

    def test_control_pass_when_status_fully_persisted(self):
        code, rec, out, n, s = self.run_case("RUN", lambda i, o: False, effect=True, heartbeats=4)
        self.assertEqual(code, 0)
        st = s.status_bytes_at_end
        self.assertEqual(rec["status_final_sha256"], sha256_bytes(st))
        self.assertEqual(json.loads(st)["fields"]["ACTIVE"], "NO")
        self.assertEqual(rec["status_write_failures"], 0)


class TB_ClassifyLiteralWorld(unittest.TestCase):
    """B01/B02/B03/B05 no mundo literal (CODE congelado real; classify_flow de produção; um subprocesso por cenário)."""

    def scenario(self, name):
        r = subprocess.run([sys.executable, "-B", str(HERE / "t14f_shadow_fixture.py"), name], capture_output=True, text=True,
                           env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"), timeout=1800)
        self.assertEqual(r.returncode, 0, r.stdout[-4000:] + r.stderr[-4000:])
        self.assertIn(name + "=PASS", r.stdout)

    def test_cl_pass_receipt_verified_physical_details_status(self):
        self.scenario("CL_PASS")

    def test_cl_preflight_drift_on_pass_path(self):
        self.scenario("CL_PREFLIGHT_DRIFT")

    def test_cl_code_drift_on_pass_path(self):
        self.scenario("CL_CODE_DRIFT")

    def test_cl_receipt_write_failure(self):
        self.scenario("CL_RECEIPT_FAIL")

    def test_cl_receipt_readback_failure(self):
        self.scenario("CL_READBACK_FAIL")


class TB05_StatusAtomic(unittest.TestCase):
    def test_fmt_eta(self):
        from phase_b_effects import fmt_eta
        self.assertEqual(fmt_eta(None), "UNKNOWN")
        self.assertEqual(fmt_eta(-1), "UNKNOWN")
        self.assertEqual(fmt_eta(0), "0.00.00.00")
        self.assertEqual(fmt_eta(93784), "1.02.03.04")
        self.assertEqual(fmt_eta("x"), "UNKNOWN")

    def test_replace_retry_and_failure(self):
        import phase_b_effects as pe
        from phase_b_shared import Layout, Session
        with tempfile.TemporaryDirectory() as td:
            target = Path(td) / "S.json"
            real = os.replace
            calls = {"n": 0}

            def flaky(a, b):
                calls["n"] += 1
                if calls["n"] <= 2:
                    raise PermissionError("sharing violation (simulated)")
                return real(a, b)
            pe.os.replace = flaky
            try:
                pe.write_status_atomic(target, {"a": 1}, pause=0.01)
            finally:
                pe.os.replace = real
            self.assertEqual(json.loads(target.read_text()), {"a": 1})
            self.assertEqual(calls["n"], 3)
            self.assertEqual(list(Path(td).glob("*.tmp")), [])

            def always(a, b):
                raise PermissionError("locked")
            pe.os.replace = always
            try:
                self.assertEqual(code_of(lambda: pe.write_status_atomic(target, {"a": 2}, attempts=2, pause=0.01)),
                                 "STATUS_WRITE_FAILED")
                lay = Layout(*([td] * 14))
                s = Session(mode="DRY", layout=lay, constants=C, platform=fx.FakePlatform(), attempt_id="x")
                s.status_path = target
                buf = io.StringIO()
                with redirect_stdout(buf):
                    s.status()  # observacional: não lança, conta a falha
                self.assertEqual(s.status_failures, 1)
            finally:
                pe.os.replace = real
            self.assertEqual(json.loads(target.read_text()), {"a": 1})  # nunca parcialmente escrito

    def test_liveness_thread_time_cadence(self):
        import time as _time
        from phase_b_shared import Layout, Session
        with tempfile.TemporaryDirectory() as td:
            lay = Layout(*([td] * 14))
            s = Session(mode="DRY", layout=lay, constants=C, platform=fx.FakePlatform(), attempt_id="x")
            s.status_path = Path(td) / "ADAPTER_STATUS.json"
            buf = io.StringIO()
            with redirect_stdout(buf):
                s.phase = "G17"
                s.status(progress=10, total=100, rate="1.0MiB/s", eta_s=90)
                seq0 = s.status_seq
                s.start_heartbeat(interval=0.2)
                _time.sleep(1.1)
                s.stop_heartbeat()
            doc = json.loads(s.status_path.read_text())
            self.assertGreaterEqual(s.status_seq - seq0, 3)
            self.assertTrue(doc["liveness_tick"])
            self.assertEqual((doc["fields"]["PHASE"], doc["fields"]["PROGRESS"], doc["fields"]["TOTAL"]), ("G17", "10", "100"))
            self.assertEqual(buf.getvalue().count("HEARTBEAT "), 1)  # vida só no arquivo, nunca no stdout/trace
            self.assertIsNone(s.heartbeat_thread)

    def test_status_document_fields(self):
        from phase_b_effects import STATUS_FIELDS
        from phase_b_shared import Layout, Session
        with tempfile.TemporaryDirectory() as td:
            lay = Layout(*([td] * 14))
            s = Session(mode="DRY", layout=lay, constants=C, platform=fx.FakePlatform(), attempt_id="x")
            s.plan = ["G01", "G02"]
            doc = s.status_document(progress=5, total=10, rate="1.0MiB/s", eta_s=65)
            self.assertEqual(list(doc["fields"]), list(STATUS_FIELDS))
            self.assertEqual(doc["fields"]["ETA"], "0.00.01.05")
            self.assertNotEqual(doc["fields"]["FINISH"], "UNKNOWN")
            self.assertEqual(doc["fields"]["COMMITTED"], "0")
            done = s.status_document(active="NO")
            self.assertEqual((done["fields"]["ACTIVE"], done["fields"]["ETA"]), ("NO", "0.00.00.00"))


class TQS2_ProbesSandbox(unittest.TestCase):
    """B03: T31a (fail-closed fora do Windows após G02/G06 + fórmula do mutex) e Q07 em mundo literal de produção."""

    @classmethod
    def setUpClass(cls):
        cls.work = Path(tempfile.mkdtemp(prefix="qs2probe_"))
        paths = C["paths"]
        shutil.copytree(P / "CODE", cls.work / paths["code_root"])
        shutil.copytree(P / "CONTROL", cls.work / paths["control_root"])

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.work, ignore_errors=True)

    def run_probe(self, *args):
        return subprocess.run([sys.executable, "-B", str(fx.ADAPTER / "qualification" / "qs2_target_probe.py"), *args],
                              cwd=self.work, capture_output=True, text=True,
                              env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"), timeout=900)

    def qs2_dir(self, attempt):
        return self.work / C["paths"]["evidence_base"] / attempt / "QS2"

    def test_t31a_fail_closed_non_windows(self):
        attempt = "20261003T000000Z_0000a31a"
        r = self.run_probe("t31a", "--attempt-id", attempt)
        self.assertEqual(r.returncode, 2, r.stdout + r.stderr)
        rec = json.loads((self.qs2_dir(attempt) / "T31A_RECEIPT.json").read_text())
        self.assertEqual(rec["result"], "BLOCKED")
        self.assertEqual(rec["error"]["code"], "WINDOWS_REQUIRED")
        self.assertTrue(rec["formula_equal"] and rec["frozen_source_formula_present"], rec)
        self.assertEqual(rec["exit_code"], 2)
        self.assertFalse(any(d.name == "__pycache__" for d in (self.work / C["paths"]["code_root"]).rglob("*")))

    def test_q07(self):
        a = C["authority"]
        good = {"schema": "MINOTAURO_LIVE_POLICY_RECHECK_RECEIPT_V001", "cardinality": "1+1", "state": "FROZEN",
                "master_sha256": a["snapshot_master_sha256"], "head_sha256": a["snapshot_head_sha256"]}
        pr = self.work / "policy.json"
        pr.write_text(json.dumps(good))
        attempt = "20261003T000000Z_0000a007"
        r = self.run_probe("q07", "--attempt-id", attempt, "--policy-receipt", str(pr))
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        rec = json.loads((self.qs2_dir(attempt) / "Q07_RECEIPT.json").read_text())
        self.assertEqual((rec["result"], rec["exit_code"]), ("PASS", 0))
        bad = dict(good, head_sha256="0" * 64)
        pr.write_text(json.dumps(bad))
        attempt2 = "20261003T000000Z_0000a008"
        r = self.run_probe("q07", "--attempt-id", attempt2, "--policy-receipt", str(pr))
        self.assertEqual(r.returncode, 2)
        rec = json.loads((self.qs2_dir(attempt2) / "Q07_RECEIPT.json").read_text())
        self.assertEqual(rec["error"]["code"], "LIVE_POLICY_RECEIPT_MISMATCH")

    def test_q07_policy_live_rebind(self):
        """G4 rebind 2026-10-08 v30: aceita live v30; rejeita predecessor do adapter v29."""
        from phase_b_contract import policy_receipt_validate
        new = {"schema": "MINOTAURO_LIVE_POLICY_RECHECK_RECEIPT_V001", "cardinality": "1+1", "state": "FROZEN",
               "master_sha256": "011CFB0CDD39E3B2ECC104A7B967330D2B29D84EA2A506E74A3ABB2B8D231FA2",
               "head_sha256": "8DDDF99F206848471A6A27A9E37637CC51CAD8378C482C3CA3F7C3322A68A1C5"}
        old = dict(new, master_sha256="2B7F681F176009ACA5F5F280B132EA792069027F0DE44A80EF442434C3788DF4",
                   head_sha256="0DB5BEA132E6F423F3B748E73CB94B81C588E308C911D4A573952A3DEFC22A03")
        with tempfile.TemporaryDirectory() as td:
            for doc, want in ((new, "NO_ERROR"), (old, "LIVE_POLICY_RECEIPT_MISMATCH"),
                              (dict(new, head_sha256=old["head_sha256"]), "LIVE_POLICY_RECEIPT_MISMATCH"),
                              (dict(new, master_sha256=old["master_sha256"]), "LIVE_POLICY_RECEIPT_MISMATCH"),
                              (dict(new, cardinality="2+1"), "LIVE_POLICY_RECEIPT_MISMATCH"),
                              (dict(new, state="DRAFT"), "LIVE_POLICY_RECEIPT_MISMATCH")):
                pr = Path(td) / "p.json"
                pr.write_text(json.dumps(doc))
                self.assertEqual(code_of(lambda: policy_receipt_validate(pr, C)), want, doc)
        self.assertEqual(C["authority"]["live_rebind"]["previous_master_sha256"], old["master_sha256"])
        # pela sonda Q07 real (subprocesso), o par anterior também é recusado
        pr = self.work / "policy_old.json"
        pr.write_text(json.dumps(old))
        attempt = "20261003T000000Z_0000a0d5"
        r = self.run_probe("q07", "--attempt-id", attempt, "--policy-receipt", str(pr))
        self.assertEqual(r.returncode, 2)
        rec = json.loads((self.qs2_dir(attempt) / "Q07_RECEIPT.json").read_text())
        self.assertEqual(rec["error"]["code"], "LIVE_POLICY_RECEIPT_MISMATCH")
        self.assertEqual(rec["expected_master_sha256"], new["master_sha256"])

    def test_argv_closed(self):
        r = self.run_probe("t31a", "--attempt-id", "20261003T000000Z_0000a31b", "--extra", "x")
        self.assertEqual(r.returncode, 2)
        self.assertIn("QS2_PROBE_BLOCKED=QS2_PROBE_ARGV", r.stdout)

    def test_probe_exit_stderr_bytes(self):
        for want in (0, 2, 3, 7, 130):
            r = subprocess.run([sys.executable, "-B", str(fx.ADAPTER / "qualification" / "probe_exit.py"), str(want)],
                               capture_output=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
            self.assertEqual(r.returncode, want)
            self.assertEqual(r.stderr, b"PROBE_STDERR=" + str(want).encode() + b"\n")


class TB_BootstrapHarness(unittest.TestCase):
    """B02/B03/B05/B06 no BOOTSTRAP (funções reais via AST; filhos Python reais; pwsh na sandbox)."""

    def test_harness(self):
        pwsh = os.environ.get("MINOTAURO_PWSH")
        self.assertTrue(pwsh and Path(pwsh).is_file(), "MINOTAURO_PWSH obrigatório para QS1")
        with tempfile.TemporaryDirectory() as td:
            r = subprocess.run([pwsh, "-NoProfile", "-NonInteractive", "-File", str(HERE / "bootstrap_harness.ps1"),
                                "-Bootstrap", str(fx.ADAPTER / "BOOTSTRAP_PHASE_B_ADAPTER.ps1"), "-Python", sys.executable,
                                "-Adapter", str(fx.ADAPTER), "-Work", td, "-Pwsh", pwsh],
                               capture_output=True, text=True, timeout=900,
                               env=dict(os.environ, DOTNET_SYSTEM_GLOBALIZATION_INVARIANT="1"))
            self.assertEqual(r.returncode, 0, r.stdout[-4000:] + r.stderr[-4000:])
            self.assertIn("HARNESS=PASS", r.stdout)
            for h in ("H1_T26_EXIT_0_2_3_7_130_STDERR", "H2_T26_HISTORICAL_MINUS_999", "H3_WATCHDOG_NO_AUTOKILL_HEARTBEAT_STATUS",
                      "H4_HEARTBEAT_FROM_ADAPTER_STATUS", "H5_RECEIPT_VERIFY_NATIVE_EXIT_STDERR", "H6_FORMAT_ETA",
                      "H7_ATOMIC_WRITE_STAGE_EXIT", "H8_Q08_ANALOG_PWSH_FILE", "H9_HOST_Q05_NO_THROW",
                      "H10_STDERR_RAW_BYTES_SHA256", "H11_STDERR_DRAIN_BOUNDED_DESCENDANT", "H12_QS3_ITEMS_SUBSTANTIVE_ONLY",
                      "H13_QS2_Q_ITEMS_BY_VERDICT", "H14_PACKAGE_STAGING_AND_REUSE_VERIFY",
                      "H15_B08_STATUS_PERSISTENCE_NEVER_PASS", "H16_B07_PRIOR_QS2_REQUIRED"):
                self.assertIn(h + "=PASS", r.stdout)


class TQ_QS0Mutants(unittest.TestCase):
    """Controle negativo do QS0: cada mutação de B02–B06/T26-H deve derrubar exatamente a regra correspondente."""

    MUTANTS = [
        ("B04_hash_prefix", "BOOTSTRAP_PHASE_B_ADAPTER.ps1", "$PackageDir = Join-Path $PackageBase $zipSha\r",
         "$PackageDir = Join-Path $PackageBase $zipSha.Substring(0, 16)\r", "QS0.30_NO_HASH_PREFIX_AS_IDENTITY"),
        ("B05_auto_kill", "BOOTSTRAP_PHASE_B_ADAPTER.ps1", "                $result.TimedOut = $true\r",
         "                $result.TimedOut = $true; $proc.Kill()\r", "QS0.31_WATCHDOG_FINITE_NO_AUTOKILL"),
        ("B05_field_missing", "BOOTSTRAP_PHASE_B_ADAPTER.ps1", "'CHECKPOINT', 'SAFE_STOP')", "'CHECKPOINT')",
         "QS0.32_HEARTBEAT_CANONICAL_FIELDS_CADENCE_ATOMIC_STATUS"),
        ("B02_no_readback", "phase_b_shared.py", "            verify_receipt_on_disk(s.evidence_dir / name, rsha, s.attempt_id, code, s.mode)\n",
         "", "QS0.33_RECEIPT_PHYSICALLY_VERIFIED_BEFORE_PASS"),
        ("B06_no_stderr", "BOOTSTRAP_PHASE_B_ADAPTER.ps1", "    $psi.RedirectStandardError = $true\r\n", "",
         "QS0.34_DOWNSTREAM_NATIVE_EXIT_AND_STDERR_SHA256"),
        ("B03_no_t31a", "BOOTSTRAP_PHASE_B_ADAPTER.ps1", "'T26', 'T31a', 'STATUS_B'", "'T26', 'STATUS_B'",
         "QS0.35_QS2_ITEMS_MATCH_ENVELOPE"),
        ("A1_qs3_items_dropped", "BOOTSTRAP_PHASE_B_ADAPTER.ps1", "'QS3_DRY' = @('PRIOR_QS2', 'T26', 'DRY_RUN_B', 'T02', 'T11c', 'T14', 'T19_template', 'T23', 'T27', 'T30')",
         "'QS3_DRY' = @('PRIOR_QS2', 'T26', 'DRY_RUN_B')", "QS0.35_QS2_ITEMS_MATCH_ENVELOPE"),
        ("M1_interrupt_exit_removed", "BOOTSTRAP_PHASE_B_ADAPTER.ps1", "    if (-not $script:MainCompleted) { [Environment]::Exit($FinalCode) }\r\n", "",
         "QS0.40_BOOTSTRAP_INTERRUPTION_EXIT_COHERENT"),
        ("B09_companion_check_removed", "BOOTSTRAP_PHASE_B_ADAPTER.ps1", "$r.reason = 'RECEIPT_NOT_VERIFIED_BY_ADAPTER'; return $r",
         "$r.valid = $r.valid", "QS0.41_RECEIPT_VERIFIED_COMPANION"),
        ("B05_liveness_thread_removed", "phase_b_shared.py", "        self.start_heartbeat()\n", "",
         "QS0.43_ADAPTER_STATUS_TIME_CADENCE_THREAD"),
        ("B06_raw_stderr_reverted", "BOOTSTRAP_PHASE_B_ADAPTER.ps1", "$proc.StandardError.BaseStream.CopyToAsync($errBuffer)",
         "$proc.StandardError.ReadToEndAsync()", "QS0.34_DOWNSTREAM_NATIVE_EXIT_AND_STDERR_SHA256"),
        ("B07_prior_not_enforced", "BOOTSTRAP_PHASE_B_ADAPTER.ps1",
         "        if (-not $prior.valid) { throw ('B07_PRIOR_QS2_NOT_PROVEN ' + $prior.reason) }\r\n", "", "QS0.44_B07_QS3_REQUIRES_PROVEN_PRIOR_QS2"),
        ("B07_prior_not_required_item", "BOOTSTRAP_PHASE_B_ADAPTER.ps1", "'QS3_DRY' = @('PRIOR_QS2', ", "'QS3_DRY' = @(",
         "QS0.44_B07_QS3_REQUIRES_PROVEN_PRIOR_QS2"),
        ("B08_adapter_status_downgrade_removed", "phase_b_shared.py",
         '    if s.status_failures:\n        labels["STATUS_PERSISTENCE"] = f"FAILED:{s.status_failures}"\n        downgrade("STATUS")\n', "",
         "QS0.45_B08_STATUS_PERSISTENCE_NEVER_PASS"),
        ("B08_bootstrap_final_status_resolve_removed", "BOOTSTRAP_PHASE_B_ADAPTER.ps1",
         "        $FinalCode = Resolve-FinalExit $FinalCode $script:StatusWriteFailures $script:FinalStatusWritten\r\n", "",
         "QS0.45_B08_STATUS_PERSISTENCE_NEVER_PASS"),
        ("B07_child_content_unchecked", "BOOTSTRAP_PHASE_B_ADAPTER.ps1",
         "    if (-not $cq.valid) { $r.reason = 'PRIOR_QS2_CHILD_CONTENT:Q07:' + $cq.reason; return $r }\r\n", "",
         "QS0.44_B07_QS3_REQUIRES_PROVEN_PRIOR_QS2"),
        ("B07_precheck_after_extraction", "BOOTSTRAP_PHASE_B_ADAPTER.ps1",
         "        $prior0 = Test-PriorQS2Receipt $PriorQS2Receipt $PriorQS2ReceiptSha256 '' $zipSha\r\n",
         "        $prior0 = [ordered]@{ valid = $true; reason = 'SKIPPED' }\r\n", "QS0.44_B07_QS3_REQUIRES_PROVEN_PRIOR_QS2"),
        ("B08_stage_receipt_failure_keeps_130", "BOOTSTRAP_PHASE_B_ADAPTER.ps1",
         "            if ($FinalCode -eq 0 -or $FinalCode -eq 130) {\r\n", "            if ($FinalCode -eq 0) {\r\n",
         "QS0.45_B08_STATUS_PERSISTENCE_NEVER_PASS"),
        ("T26H_sentinel_leak", "BOOTSTRAP_PHASE_B_ADAPTER.ps1", "    $FinalCode = Get-StageExit $Items $RequiredItems[$Stage]\r",
         "    $FinalCode = Get-StageExit $Items $RequiredItems[$Stage]\r\n    $x = $LASTEXITCODE\r", "QS0.23_PS_FORBIDDEN_CONSTRUCTS_ABSENT_OUTSIDE_T26H"),
    ]

    def test_mutants_killed(self):
        pwsh = os.environ.get("MINOTAURO_PWSH")
        killed = []
        for name, rel, old, new, rule in self.MUTANTS:
            with tempfile.TemporaryDirectory() as td:
                dst = Path(td) / "PHASE_B_ADAPTER_V001"
                shutil.copytree(fx.ADAPTER, dst)
                f = dst / rel
                raw = f.read_bytes()
                bold, bnew = old.encode("utf-8"), new.encode("utf-8")
                self.assertEqual(raw.count(bold), 1, name)
                f.write_bytes(raw.replace(bold, bnew))
                subprocess.run([sys.executable, "-B", str(dst / "qualification" / "build_package.py"), str(dst)],
                               check=True, capture_output=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
                out = Path(td) / "qs0.json"
                args = [sys.executable, "-B", str(dst / "qualification" / "qs0_static.py"), str(out)]
                if pwsh:
                    args += ["--pwsh", pwsh]
                subprocess.run(args, capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
                rec = json.loads(out.read_text())
                failed = {c["check"] for c in rec["checks"] if c["result"] == "FAIL"}
                self.assertIn(rule, failed, (name, sorted(failed)))
                self.assertEqual(rec["result"], "FAIL")
                killed.append(name)
        self.assertEqual(len(killed), len(self.MUTANTS))


class T25_TickRehash(unittest.TestCase):
    def test_drift(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            ticks = []
            for i in range(2):
                p = td / f"t{i}.csv"
                p.write_bytes(os.urandom(1000 + i))
                ticks.append({"path": str(p), "bytes": p.stat().st_size, "sha256": sha256_file(p)})
            c = fx.fixture_constants()
            c["inputs"]["ticks"] = ticks
            c["inputs"]["ticks_total_bytes"] = sum(t["bytes"] for t in ticks)

            class L:
                @staticmethod
                def tick_path(raw):
                    return Path(raw)
            self.assertEqual(code_of(lambda: tick_rehash(L, c)), "NO_ERROR")
            b = bytearray(Path(ticks[1]["path"]).read_bytes()); b[500] ^= 1
            Path(ticks[1]["path"]).write_bytes(bytes(b))
            self.assertEqual(code_of(lambda: tick_rehash(L, c)), "TICK_REHASH_DRIFT")


class T28_FreeSpace(unittest.TestCase):
    def test_free_space(self):
        from phase_b_shared import Layout, Session, gate_g16_free_space
        lay = Layout(*(["/nonexistent"] * 14))
        inv = {"files": {"a": {"bytes": 10, "sha256": "x"}}}
        s = Session(mode="DRY", layout=lay, constants=C, platform=fx.FakePlatform(free=100), attempt_id="x")
        self.assertEqual(code_of(lambda: gate_g16_free_space(s, inv)), "FREE_SPACE_INSUFFICIENT")
        s.platform = fx.FakePlatform(free=10 ** 12)
        self.assertEqual(code_of(lambda: gate_g16_free_space(s, inv)), "NO_ERROR")
        s.mode = "RUN"
        # C2: crescimento qualificado a partir do QS4; espaço amplo permite prosseguir.
        self.assertEqual(C["free_space"]["run_growth_bytes"], 1900518140)
        self.assertEqual(code_of(lambda: gate_g16_free_space(s, inv)), "NO_ERROR")
        # Controle negativo preservado: sem crescimento homologado, RUN permanece bloqueado.
        s.constants = copy.deepcopy(C)
        s.constants["free_space"]["run_growth_bytes"] = None
        self.assertEqual(code_of(lambda: gate_g16_free_space(s, inv)), "RUN_GROWTH_NOT_QUALIFIED")
        # Controle negativo: crescimento conhecido não dispensa espaço livre suficiente.
        s.constants["free_space"]["run_growth_bytes"] = 1900518140
        s.platform = fx.FakePlatform(free=100)
        self.assertEqual(code_of(lambda: gate_g16_free_space(s, inv)), "FREE_SPACE_INSUFFICIENT")


class TX_PreflightAndRunBinding(unittest.TestCase):
    """Complementos: G13 exato (inclui par vazio extrínseco N-17) e N-09 (adapter run binding)."""

    def test_preflight(self):
        with tempfile.TemporaryDirectory() as td:
            pre = fx.copy_preflight(Path(td) / "PREFLIGHT")
            self.assertEqual(code_of(lambda: preflight_validate(pre, C)), "NO_ERROR")
            (pre / "_TMP_SAME_VOLUME_PHASE_B" / "_avast_" / "x.tmp").write_text("x")
            self.assertEqual(code_of(lambda: preflight_validate(pre, C)), "PREFLIGHT_FILES_DRIFT")
        with tempfile.TemporaryDirectory() as td:
            pre = fx.copy_preflight(Path(td) / "PREFLIGHT")
            os.rmdir(pre / "_TMP_SAME_VOLUME_PHASE_B" / "_avast_")
            self.assertEqual(code_of(lambda: preflight_validate(pre, C)), "PREFLIGHT_DIRS_DRIFT")

    def test_dry_receipt_requires_verified_companion(self):
        from phase_b_contract import dry_receipt_validate
        from phase_b_shared import verified_companion
        with tempfile.TemporaryDirectory() as td:
            rp = Path(td) / "DRY_RECEIPT.json"
            rec = {"schema": "MINOTAURO_PHASE_B_ADAPTER_DRY_RECEIPT_V001", "result": "PASS", "exit_code": 0, "mode": "DRY",
                   "adapter_identity_sha256": "A" * 64, "state": "PREPARED", "attempt_id": "20261003T000000Z_0000d0d0",
                   "gates": [{"id": "G06", "input_sha256": "X"}]}
            rp.write_bytes(canonical_bytes(rec))
            gt = [{"id": "G06", "input_sha256": "X"}]
            self.assertEqual(code_of(lambda: dry_receipt_validate(rp, "A" * 64, "PREPARED", gt, ["G06"])), "DRY_RECEIPT_NOT_VERIFIED")
            comp = Path(td) / "DRY_RECEIPT.VERIFIED.json"
            comp.write_bytes(canonical_bytes(verified_companion(sha256_file(rp), rec["attempt_id"], 0, "DRY")))
            self.assertEqual(code_of(lambda: dry_receipt_validate(rp, "A" * 64, "PREPARED", gt, ["G06"])), "NO_ERROR")
            comp.write_bytes(canonical_bytes(verified_companion("0" * 64, rec["attempt_id"], 0, "DRY")))
            self.assertEqual(code_of(lambda: dry_receipt_validate(rp, "A" * 64, "PREPARED", gt, ["G06"])), "DRY_RECEIPT_NOT_VERIFIED")

    def test_t30_foreign_entries(self):
        from phase_b_shared import Layout, Session, t30_foreign_entries
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            for n in ("control", "code", "shadow/ATT/CONTROL"):
                (td / n).mkdir(parents=True)
                (td / n / "f.txt").write_text("x")
            lay = Layout(release_root=str(td), code_root=str(td / "code"), control_root=str(td / "control"),
                         preflight_root=str(td), shadow_base=str(td / "shadow"), evidence_base=str(td), base_csv_root=str(td),
                         ind_d1="x", m1_root="x", parent_2025_root="x", g8_local_receipt="x", g8_evidence_zip="x",
                         phase_b_evidence_zip="x", package_root=str(td))
            s = Session(mode="DRY", layout=lay, constants=C, platform=fx.FakePlatform(), attempt_id="x")
            s.record["shadow_root"] = str(td / "shadow" / "ATT" / "CONTROL")
            self.assertEqual(t30_foreign_entries(s)["foreign"], [])
            (td / "shadow" / "ATT" / "_avast_").mkdir()
            (td / "code" / "x._AVAST_.tmp").write_text("q")
            got = t30_foreign_entries(s)["foreign"]
            self.assertEqual(sorted(got), ["code:x._AVAST_.tmp", "shadow:_avast_"])

    def test_run_binding(self):
        ident = {"adapter_identity_sha256": "A" * 64}
        doc = run_binding_document(ident, C, "20261002T000000Z_00000000")
        self.assertEqual(code_of(lambda: run_binding_compare(doc, ident, C)), "NO_ERROR")
        self.assertEqual(code_of(lambda: run_binding_compare(doc, {"adapter_identity_sha256": "B" * 64}, C)),
                         "ADAPTER_IDENTITY_MISMATCH")

    def test_trace_normalization(self):
        lines = ["PREFLIGHT_PHASE_B_REUSE=PASS sessions=166 source=D:\\X",
                 "MEMORY_TELEMETRY event=RUN_START JOB_MEM_MIB=1.0",
                 "RUN_START mode=RUN_B sessions=166 remaining_sessions=166 files_to_read_or_verify=8 total_gib=31.961 frozen_cells=1",
                 "MULTIWORK=YES AUTOCPU=YES CPU_LOGICAL=16 GRANTED_WORKERS=2 WORK_GROUPS_TOTAL=1 MIN_EFFECTIVE_WORKERS=2 MAX_WORKERS=15 BATCH_ROWS=256",
                 "SESSION_START mode=RUN_B session=2026-01-02 cells=1"]
        n = normalize_trace(lines, C["trace"])
        self.assertEqual(n, ["PREFLIGHT_PHASE_B_REUSE sessions=166",
                             "RUN_START mode=RUN_B sessions=166 remaining_sessions=166 files_to_read_or_verify=8 total_gib=31.961 frozen_cells=1",
                             "MULTIWORK WORK_GROUPS_TOTAL=1 MIN_EFFECTIVE_WORKERS=2 MAX_WORKERS=15 BATCH_ROWS=256",
                             "SESSION_START mode=RUN_B session=2026-01-02 cells=1"])


class T14F_ShadowReproduction(unittest.TestCase):
    """Fixture Linux do G18: G06–G16 + G18 (prepare_preflight/build_binding congelados no shadow) + G20 + G21
    (pré-recover) com caminhos literais 'D:\\...' resolvidos relativamente a um cwd de fixture."""

    def test_subprocess(self):
        r = subprocess.run([sys.executable, "-B", str(HERE / "t14f_shadow_fixture.py")], capture_output=True, text=True,
                           env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"), timeout=1800)
        self.assertEqual(r.returncode, 0, r.stdout[-4000:] + r.stderr[-4000:])
        self.assertIn("T14F=PASS", r.stdout)


if __name__ == "__main__":
    unittest.main()
