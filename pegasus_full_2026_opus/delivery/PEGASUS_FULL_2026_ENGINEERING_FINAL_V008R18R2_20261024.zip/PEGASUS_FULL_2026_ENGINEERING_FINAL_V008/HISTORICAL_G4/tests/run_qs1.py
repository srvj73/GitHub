"""PHASE_B_ADAPTER_V001 — executor QS1 com receipt (contagem de testes derivada fisicamente).
Uso: MINOTAURO_E01_PAYLOAD=<payload> MINOTAURO_PWSH=<pwsh> python -B tests/run_qs1.py <receipt_out.json>
Receipt V002: identidade do adapter (+ recomputação do manifesto) e digest da árvore do adapter antes/depois (valores)."""
import hashlib
import json
import os
import sys
import time
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(HERE.parent))


def tree_digest(root):
    h = {}
    for p in sorted(Path(root).rglob("*")):
        if p.is_file():
            h[p.relative_to(root).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest().upper()  # = QS0
    return hashlib.sha256(json.dumps(h, sort_keys=True).encode()).hexdigest().upper(), len(h)


def sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()


def main(out):
    payload = Path(os.environ["MINOTAURO_E01_PAYLOAD"])
    adapter = HERE.parent
    ident = json.loads((adapter / "ADAPTER_IDENTITY.json").read_text(encoding="utf-8"))
    manifest_sha = sha_file(adapter / "MANIFEST_SHA256.txt")
    pwsh = os.environ.get("MINOTAURO_PWSH")
    before = tree_digest(payload)
    adapter_before = tree_digest(adapter)
    suite = unittest.defaultTestLoader.loadTestsFromName("test_qs1")
    results = []

    class R(unittest.TextTestResult):
        def addSuccess(self, t):
            super().addSuccess(t); results.append({"test": t.id(), "result": "PASS"})

        def addFailure(self, t, e):
            super().addFailure(t, e); results.append({"test": t.id(), "result": "FAIL", "detail": self._exc_info_to_string(e, t)[-3000:]})

        def addError(self, t, e):
            super().addError(t, e); results.append({"test": t.id(), "result": "ERROR", "detail": self._exc_info_to_string(e, t)[-3000:]})
    t0 = time.time()
    r = unittest.TextTestRunner(verbosity=2, resultclass=R).run(suite)
    after = tree_digest(payload)
    adapter_after = tree_digest(adapter)
    identity_ok = ident["adapter_identity_sha256"] == manifest_sha == ident["manifest_sha256"]
    rec = {"schema": "MINOTAURO_PHASE_B_ADAPTER_QS1_RECEIPT_V002", "python": sys.version.split()[0], "platform": sys.platform,
           "adapter_identity_sha256": ident["adapter_identity_sha256"],
           "adapter_identity_recomputed_manifest_sha256": manifest_sha, "adapter_identity_matches_manifest": identity_ok,
           "adapter_tree_digest_before": {"sha256": adapter_before[0], "files": adapter_before[1]},
           "adapter_tree_digest_after": {"sha256": adapter_after[0], "files": adapter_after[1]},
           "pwsh": pwsh, "pwsh_sha256": sha_file(pwsh) if pwsh and Path(pwsh).is_file() else None,
           "tests_run": r.testsRun, "passed": sum(1 for x in results if x["result"] == "PASS"),
           "failed": len(r.failures), "errors": len(r.errors), "results": results,
           "e01_payload_digest_before": before, "e01_payload_digest_after": after,
           "e01_payload_unchanged": before == after,
           "adapter_tree_unchanged": adapter_before == adapter_after,
           "seconds": round(time.time() - t0, 1),
           "result": "PASS" if r.wasSuccessful() and before == after and adapter_before == adapter_after and identity_ok else "FAIL"}
    Path(out).write_text(json.dumps(rec, indent=1, sort_keys=True) + "\n", encoding="utf-8")
    print("QS1_RESULT=" + rec["result"], "TESTS=" + str(r.testsRun))
    return 0 if rec["result"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
