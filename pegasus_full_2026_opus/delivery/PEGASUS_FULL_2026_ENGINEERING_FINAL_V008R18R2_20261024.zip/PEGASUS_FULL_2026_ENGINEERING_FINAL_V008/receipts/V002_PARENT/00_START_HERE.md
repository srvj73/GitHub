# PEGASUS ORIGINAL — FULL 2026 candidato V002

**Produtor:** CANDIDATE_PRODUCER / IMPLEMENTADOR. **Não é auditoria independente.**

O pacote integra os fontes completos do sucessor, AUTOCPU com teto 24 e limitação por independência causal, pipeline de B/C, SAFE_STOP cooperativo na fronteira da sessão, checkpoint/commit, journal preservado, resume, observabilidade e bootstrap PowerShell autocontido. O núcleo econômico, parser, preflight econômico, cutoff, pré-registro e os históricos foram preservados byte a byte.

**A qualificação final está PARCIAL / BLOQUEADA. Não execute FULL, B/C econômico, QS2/QS3 protegidos nem promova RUN_RELEASED.** O erro aberto está em `receipts/qualification/INCIDENT_PENDING_RESIDUE.json`. Não trate uma nova tentativa como autorizada pela existência de um launcher.

## Estados distintos

| Objeto | Estado |
|---|---|
| Fontes e artefato candidato integrado | BUILT |
| Integridade e núcleo congelado | ver receipts / MANIFEST_SHA256.json |
| Qualificação offline inicial, identidade anterior | 18 controles PASS; evidência limitada àquela identidade |
| Suíte da revisão seguinte | 7 controles PASS; FAIL em during_pending; cadeia interrompida |
| Recovery final | BLOCKED — causa do resíduo PENDING não provada |
| SAFE_STOP | implementação presente; PASS na identidade inicial; teste de duplo SIGINT da revisão seguinte não chegou a executar |
| AUTOCPU | requests 1..24; seleção funcional limitada por grupos/recursos; hardware de 24 workers NÃO qualificado |
| PowerShell 7 Linux: parse, argv, exit e Int64 | PASS limitado; não substitui Windows PS5.1 |
| Windows PS5.1 / Python 3.14.7 | NOT_EXECUTED aqui |
| QS0 G4 histórico | PASS 46/46 preservado, não repetido |
| QS1 G4 terminal | NOT_QUALIFIED; NumPy privado corrigido e importação 55 demonstrada |
| QS2 / QS3 / QS4 sucessor / QS5 / B06 / R01–R06 | pendentes; autorizações aplicáveis e definições físicas exigidas |
| FULL_QUALIFIED / FULL_RUN_AUTHORIZED / FULL_EXECUTED | false / false / false |

## O que aconteceu no recovery

A primeira suíte integrada passou 18 controles, incluindo streams gzip idênticos ao core serial congelado, multiwork, oito pontos de falha e SAFE_STOP/resume. Após a adição de métricas/backpressure de I/O e controles de interrupção adicionais, a segunda suíte parou na comparação exata do caso `during_pending`: apareceu um arquivo extra `sessions/2000-01-06.pending/trades.jsonl.gz`. Todos os COMMITTED e o checkpoint eram idênticos à referência. Uma reprodução isolada, três repetições exatas e um probe de concorrência do filesystem não reproduziram o resíduo. Isso **não fecha a causa-raiz** e não anula o FAIL. Nenhum patch especulativo foi aplicado ao protocolo para fazê-lo passar. As provas, inclusive o diretório afetado, estão preservadas.

As frentes dependentes de recovery permaneceram suspensas. Transporte, compilação, preservação dos fontes e documentação foram concluídos independentemente. A próxima ação nessa frente é análise/reprodução dirigida deste incidente no root isolado, não FULL e não rerun cego da suíte.

## Execução local

O ZIP externo contém um PS1 autocontido e seu espelho byte idêntico `.txt`. A instrução de uma linha no `EXECUCAO_LOCAL.txt` do ZIP externo verifica o SHA do launcher, carrega somente esse membro, faz parse externo PS5.1 antes de executá-lo e deixa o bootstrap autoextrair o pacote. Não use “Extrair tudo”, `cd`, instalação global ou alteração permanente de ExecutionPolicy.

O bootstrap tem dois modos: `Verify` (default) e `QualifyOffline`. `Verify` autoextrai em pasta nova sob `C:\Users\silvi\OneDrive\Downloads`, verifica todos os hashes, testa argv/exit e grava recibo. Requer exatamente Windows PowerShell 5.1 Desktop e `C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe` 3.14.7. Nenhum caminho histórico é usado como output.

`QualifyOffline` cria venv privado, instala exclusivamente o wheel NumPy CPython 3.14 Windows incluído com `--no-index --require-hashes --no-deps` e roda a suíte sintética em pasta externa ao pacote. **Esse modo está entregue para qualificação posterior, mas a cadeia de recovery está bloqueada: primeiro fechar o incidente e revalidar a política viva; não o lançar cegamente agora.**

O recibo e o stdout ficam no `RUN_ROOT` anunciado. Em timeout, não há auto-kill: preserve o root, PID/creation time e reconcilie. Extração iniciada conta como efeito em pasta própria; falha posterior retorna 3. Não apague evidências de falhas.

## QS1 G4 e NumPy

`bootstrap/qs1_linux.py` é independente do sucessor econômico e jamais deve ser executado diretamente no Windows. Exige Linux x86_64, CPython 3.12, glibc ≥2.28, pwsh 7.6.6 com hash exato (via PATH ou `--pwsh` absoluto). Cria `/tmp/PEGASUS_QS1_G4_*`, valida e extrai a captura reconstruída, usa venv privado e wheel incluído, reproduz ausência de NumPy e hash inválido, verifica importação dos 55 métodos antes do terminal. Mantém `PYTHONNOUSERSITE=1`; não muda HOME nem instalações globais. O terminal 55/55 deve executar no PC/WSL isolado por ser longo. O script salva RESULT ZIP ao lado de PACKAGE mesmo em falha. Não alegamos que esse novo wrapper já passou no WSL local.

Não repita QS0 G4, H1–H16 ou QS4 histórico por rotina. O QS1 terminal pendente não pode ser substituído por somas de testes antigos.

## Autoridade

A autorização expressa do owner permite engenharia sucessora separada e qualificação offline; não é autorização econômica. O envelope aprovado é identificado por seu pacote pai SHA `62A1447C2CA6E58F893532D9BBAF1DBDA812C7D3B9EBE09198D0FA6F948526E6`.

A captura de política incluída é **SNAPSHOT_NON_AUTHORITATIVE**. Revalidar o par vivo da Biblioteca 1+1/FROZEN/hash antes de etapa coberta. O MASTER não foi modificado. R01–R06 só aparecem como referências no handoff; suas definições não foram inventadas. A instalação de um admission/release revisado e autorizado é uma etapa futura; este produtor não fabrica nem instala RUN_RELEASED.
