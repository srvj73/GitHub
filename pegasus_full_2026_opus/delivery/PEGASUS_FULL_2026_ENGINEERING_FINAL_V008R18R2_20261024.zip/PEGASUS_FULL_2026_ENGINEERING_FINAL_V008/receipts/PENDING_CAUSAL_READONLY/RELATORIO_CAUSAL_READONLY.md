# PEGASUS FULL V002 — resultado integral do handoff de investigação PENDING

Data de fechamento: 09/10/2026. Papel: `CANDIDATE_PRODUCER`; este documento não constitui auditoria independente B06.

**HANDOFF_READONLY_EXECUTED=YES · ROOT_CAUSE_NOT_PROVEN · RECOVERY=BLOCKED · FULL_READY=NO · RUN_RELEASED=NO.**

O trabalho permitido pelo handoff foi concluído com uma lacuna de evidência. A inconsistência existe no artefato autenticado; os registros disponíveis não identificam a operação nem o processo que preservou, recriou ou copiou os resíduos. Nenhuma hipótese foi promovida a causa. O incidente permanece aberto.

## 1. Escopo e cadeia autenticada

Foram lidos o handoff, os bytes do candidato, o código pertinente e os registros já existentes. Foram reconstruídas a ordem registrada, as identidades disponíveis, a cadeia journal/checkpoint e a relação entre três cópias do caso. Nenhum módulo do aplicativo foi importado ou executado, nenhuma suíte foi repetida, nenhuma recuperação ou execução FULL/B/C ocorreu. Não houve patch, exclusão de resíduos, promoção de release ou mutação canônica.

| Fonte | SHA-256 | Verificação |
|---|---|---|
| Handoff recebido, ZIP | CA43BCCCEE56B60F1A6C921124E70AE5F5B55B9CD985EDB620A84E9404BE43E2 | CRC e 16 evidências; todas coincidem com o candidato autenticado |
| PEGASUS_FULL_2026_CANDIDATE_V002_20261009.zip | 4A0C775DC94AC46510BD37AC6792CE611474254C6CD1CDD7867AF035CF74EF56 | 16 entradas; CRC PASS; manifesto 15/15 |
| Payload ZIP extraído dos dados Base64 do bootstrap, sem executar PS1 | 2659FAD60696A065BBBCEB380BA46AAE982A592D03163EE6163AADFB18C84F22 | 2.791 entradas; CRC PASS; manifesto 2.790/2.790 |
| MASTER vivo | 011CFB0CDD39E3B2ECC104A7B967330D2B29D84EA2A506E74A3ABB2B8D231FA2 | Par físico 1+1, HEAD consistente, FROZEN |
| HEAD vivo | 8DDDF99F206848471A6A27A9E37637CC51CAD8378C482C3CA3F7C3322A68A1C5 | Revisão 20261008T132913-0300-011CFB0CDD39E3B2, versão 30 |

O par canônico foi novamente obtido e validado no fechamento; seus bytes coincidem com os da abertura. `POLICY_VALIDATION.json` registra a verificação. Este relatório não substitui a política viva.

O controle de conteúdo antes/depois da análise cobriu 829 arquivos, sem alteração. O ZIP de evidências contém 222 arquivos autenticados e seu manifesto separado. Código incluído nesse subconjunto é evidência para leitura, não um executor novo; não executar como parte desta entrega.

## 2. Estado preservado e comparação entre superfícies

O caso `receipts/qualification/suite_final/fault_during_pending` contém 167 arquivos. O conjunto de caminhos e bytes coincide integralmente entre o candidato autenticado, o diretório de qualificação preservado e a cópia de staging preservada. Não há arquivos extras, ausentes ou divergentes entre essas três superfícies.

Isso comprova igualdade no momento da análise. Não comprova que a cópia original capturou um estado atômico, nem determina quando os resíduos foram introduzidos. Datas DOS do ZIP e metadados atuais de extração/reativação do workspace não são registros históricos de rename, unlink, rmtree ou cópia.

Na comparação econômica com `reference_w1`, os 15 arquivos de sessões e o checkpoint — 16 membros comuns — são byte-idênticos. Há um único membro extra:

`sessions/2000-01-06.pending/trades.jsonl.gz`, 4.628 bytes, SHA-256 `C859078A01A8FD897F7797B62B686B7A76AF484E5FCF66B65E30544F065ED930`.

Ele coincide com `sessions/2000-01-06/trades.jsonl.gz` já COMMITTED. Essa igualdade não aprova o conjunto, que continua contendo o membro PENDING extra.

**Precisão adicional sobre o handoff:** o recibo original conserva 7 PASS, `AssertionError('during_pending')` e `FAIL_STOP_CHAIN`. O teste compara os conjuntos econômicos, mas não preserva seus dois inventários nem o diff no instante da asserção. Logo, a diferença de um membro está comprovada nos arquivos preservados; a vinculação dessa diferença exata ao instante original da falha não foi registrada. A falha original permanece válida e não foi revertida. Os 18 PASS da bateria anterior pertencem a outra identidade e não qualificam automaticamente a suíte final.

## 3. Cronologia registrada e seus limites

Os 112 registros de `R1R11_TRANSPORT.jsonl` têm ordem estritamente crescente nos contadores wall e monotonic. Horários abaixo são UTC de 08/10/2026, registrados pelo produtor, sem atestação externa de relógio. SESSION_RESULT é evento do pipeline; isoladamente não é prova de todas as operações do commit.

| Horário UTC registrado | Evento | Evidência |
|---|---|---|
| 20:15:48.888491 | Primeiro SESSION_START do run 199 | Transporte, linha 1 |
| 20:15:50.159089 | Início da sessão 2000-01-06 no run 199 | Linha 22 |
| 20:15:51.228598 | Pipeline antigo finalizado | Linha 48 |
| 20:15:51.296649 | SESSION_RESULT antigo | Linha 50 |
| Sem evento direto de filesystem | Falha injetada durante PENDING, após primeiro rename no fluxo do código | Traceback e `commit`, linha 117 |
| 20:15:51.310758 | PROCESS_TREE_CLEAN do run 199, tracked=20 | Linha 51 |
| Sem horário individual atestado | Retomada informa STALE_SCRATCH_RECONCILED=PASS, removed_run_instances=1 | stdout já preservado |
| 20:15:51.749327 | SESSION_START do run 222 | Linha 52 |
| 20:15:53.045582 | Novo pipeline finalizado | Linha 78 |
| 20:15:53.082223 | Novo SESSION_RESULT | Linha 80 |
| Sem horário individual atestado | SESSION_COMMIT 2000-01-06, trades=250 | stdout já preservado |
| 20:15:53.094563 | Início da sessão 2000-01-11 | Linha 82 |
| 20:15:54.592511 | Último SESSION_RESULT | Linha 110 |
| 20:15:54.616016 | PROCESS_TREE_CLEAN do run 222, tracked=22 | Linha 112 |
| 20:15:54.616312 | Atualização final do status: 3 COMMITTED, 100%, árvore limpa | Arquivo de status |

A soma de início e duração no recibo situa o fim da suíte aproximadamente em 20:15:54.700538; trata-se de cálculo, não de evento de captura atômica. Não há eventos diretos de entrada/saída e retorno de `archive_journal`, conclusão de `safe_remove_scratch`, unlink de RUN.lock, inventário pós-saída nem início/fim da cópia e barreira de congelamento. A sequência de chamadas esperada pelo código não preenche esses registros ausentes.

## 4. Identidades de processo e arquivo

O RUN.lock registra PID 222, `creation_time_100ns=275179` e `run_instance=222_1791490551732768026`. No ramo Linux do código, apesar do nome do campo, o valor de criação é expresso em ticks de início do kernel, não em unidades de 100 ns. O sufixo do run_instance deriva de `time_ns` ao construir o lock e não é o instante de criação do processo.

A criação do coordenador PID 199 não foi retida nos JSON examinados do caso. Há 13 registros de identidade de filhos: dois do run antigo e onze da última sessão do novo run. A lista completa das 20/22 identidades verificadas e as observações individuais de liveness não foram serializadas. Boot e namespace históricos não estão atestados. O lock arquivado não demonstra que esse PID esteja vivo hoje.

`PROCESS_TREE_CLEAN` verifica os filhos rastreados e registra resultado e quantidade. Não reconcilia os arquivos da saída nem estabelece uma fronteira de snapshot. O status de `Runtime.close` antecede o unlink de RUN.lock em `RunLock.__exit__`; por isso, status limpo não equivale a recibo de exclusão do lock.

Há uma distinção física relevante nos manifestos de pipeline:

| Run | volume_serial | file_id registrado | Bytes | SHA |
|---|---:|---:|---:|---|
| 199_1791490548877734909 | 27 | 1972829 | 4.628 | C859078A…65ED930 |
| 222_1791490551732768026 | 27 | 1972880 | 4.628 | C859078A…65ED930 |

As duas execuções produziram conteúdo igual em arquivos de identidades diferentes. O PENDING final não conserva uma vinculação autenticada ao inode original. Portanto, igualdade de hash — mesmo acompanhada de mtime copiado — não distingue sobrevivência do arquivo antigo, recriação ou cópia de conteúdo igual.

## 5. Journals, checkpoint e contrato estático

O journal ativo antigo e seu histórico `RECOVERED_REQUEUE` têm exatamente os mesmos bytes e SHA-256 `B786102D0C98B2B30036E78CB073D09E9BB5BE013EF9B8E09FBCF052B69ED4E6`. As assinaturas dos journals e checkpoints pertinentes foram recalculadas pela serialização canônica, sem chamar o aplicativo. Também existem os journals COMMITTED do novo run.

| Campo | SHA-256 |
|---|---|
| Checkpoint atual, última sessão 2000-01-11 | A50F9F1204E66B3E0EDA9D11849B81FF08177E872EA6F9C991B813716F2B2A9E |
| Previous do journal ativo antigo | 47277480B53B82E9A9F488F09069AE144D9BA2A52665A10CE5FD96A2A3A50FAD |
| Next do journal ativo antigo | 00C161A38E8C72892F15EB38E14AC50CED1E0768AC8AA4C914187034D04CEF8E |

O checkpoint atual tem assinatura válida e não coincide com previous nem next do journal antigo. Entregar esse estado intacto a `recover` implicaria a rejeição `CHECKPOINT_THIRD_STATE` pelas linhas 159–160 de `r1r11_v4_transaction.py`. **Essa é uma conclusão estática; recover não foi executado.**

No código autenticado, `commit` rejeita pending/final pré-existente (97–98), `recover` remove pending sob journal válido (161–169), e `archive_journal` renomeia a origem ou a exclui quando o histórico igual já existe (179–187). `safe_remove_scratch` chama rmtree após suas verificações; `RunLock.__exit__` exclui o lock antes de liberar o mutex. A coexistência final observada exige explicação, mas não identifica automaticamente um defeito nessas rotinas, um escritor externo ou uma falha de filesystem.

## 6. Outros resíduos nos registros já existentes

Esta tabela descreve arquivos preservados; não resulta de novas execuções.

| Caso | Pastas PENDING | Journals ativos | RUN.lock | Arquivos scratch |
|---|---:|---:|---|---:|
| baseline_w24 | 0 | 0 | Presente | 14 |
| fault_after_journal | 0 | 0 | Presente | 91 |
| fault_before_journal | 0 | 0 | Presente | 106 |
| fault_during_pending | 1 | 1 | Presente | 136 |
| multi_w3 | 0 | 0 | Presente | 74 |
| reference_w1 | 0 | 0 | Ausente | 0 |

As três reproduções anteriores preservadas têm inventários de sessões coincidentes com seus recibos, sem PENDING. Os arquivos atuais conservam RUN.lock nas tentativas 0 e 1 e não na 2; não há journals ativos nessas três. Inventários restritos a sessões não comprovam limpeza de lock/scratch. O padrão amplia a lacuna de ciclo de vida/captura; não prova race, overlay ou falha de filesystem.

## 7. Resultado causal e lacuna exata

| Proposição | Resultado |
|---|---|
| Existe inconsistência no candidato autenticado | Comprovada |
| Os três conjuntos de 167 arquivos coincidem | Comprovado na análise |
| Houve corrupção de bytes na cadeia de transporte autenticada | Não observada; verificações de hash passaram |
| O PENDING é necessariamente o mesmo arquivo antigo que sobreviveu | Não comprovado |
| Um processo específico recriou o resíduo | Não identificado |
| Houve overlay, escritor concorrente ou falha de filesystem | Hipóteses sem prova discriminante |
| A cópia foi feita de um único estado congelado | Não comprovado |
| O código de recuperação foi validado por esta investigação | Não; nenhuma execução de recuperação ocorreu |

Faltam os registros originais das operações sobre pending, journals, scratch e RUN.lock, com ator PID + criação + boot/namespace, retorno da operação e identidade dos arquivos antes/depois; faltam os dois inventários no instante da asserção; e faltam a identificação imutável da fonte, os manifestos antes/depois e os recibos de início/fim da cópia e congelamento.

Esses registros não foram encontrados na evidência disponível. Hashes de conteúdo, status agregado, datas de ZIP e metadados de cópias não permitem reconstruir retroativamente qual operação preservou ou recriou o estado. A continuidade causal exige localizar registros históricos existentes que cubram essa lacuna. Se tais registros não existem, a causa histórica permanece não comprovada com este conjunto; uma investigação experimental futura exigiria definição de novo escopo, sem ser apresentada como prova retroativa.

O próprio handoff determina BLOCKED quando falta a prova da operação e condiciona a solicitação de probe dirigido à causa comprovada. Esse gate não foi atendido: nenhum probe foi preparado ou executado, nenhuma suíte bloqueada foi retomada e nenhum patch foi gerado.

## 8. Conteúdo da entrega

`VERDICT.json` resume o estado; `TIMELINE_RECORDED.json` conserva a cronologia; os relatórios de comparação, identidade, journals e outros casos sustentam as conclusões. `METADATA_NOT_OPERATION_TRACE.json` separa metadados de cópia de prova operacional. `SOURCE_GUARD_BEFORE/AFTER.json` documentam a preservação. `AUTHENTICATED_EVIDENCE_SUBSET.zip` e `EVIDENCE_SUBSET_SHA256.json` contêm os 222 arquivos de suporte. `MANIFEST_SHA256.json` autentica todos os membros externos, exceto a si próprio.

O handoff foi executado integralmente dentro do escopo somente leitura. O fechamento é da investigação documental disponível, não da causa-raiz nem da qualificação do candidato.
