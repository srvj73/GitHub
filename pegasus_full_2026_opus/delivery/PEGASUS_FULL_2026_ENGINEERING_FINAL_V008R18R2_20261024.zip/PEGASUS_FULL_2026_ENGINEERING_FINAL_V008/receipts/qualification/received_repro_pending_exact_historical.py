from pathlib import Path
import subprocess,sys,json,hashlib,os
root=Path(__file__).resolve().parent;inputs=root/'qualification/suite_final/inputs';script=root/'PEGASUS_FULL_2026_CANDIDATE_V002/tests/synthetic_chain.py'
def inv(dest):return {p.relative_to(dest).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (dest/'sessions').rglob('*') if p.is_file()}
if __name__=='__main__':
 reports=[]
 for i in range(3):
  dest=root/('qualification/repro_pending_exact_'+str(i))
  for name,args in [('fault',['--fault','during_pending']),('resume',[])]:
   with (root/'qualification'/('repro_exact_'+str(i)+'_'+name+'.log')).open('x') as f:
    p=subprocess.run([sys.executable,'-B',str(script),'--inputs',str(inputs),'--out',str(dest),'--workers','2' if name=='fault' else '3',*args],stdout=f,stderr=subprocess.STDOUT)
   row={'trial':i,'stage':name,'rc':p.returncode,'inventory':inv(dest)};reports.append(row)
   if name=='fault':before={p:hashlib.sha256(p.read_bytes()).hexdigest() for p in (dest/'sessions').rglob('*') if p.is_file() and '.pending' not in str(p)}
   else: row['committed_preserved']=all(hashlib.sha256(p.read_bytes()).hexdigest()==h for p,h in before.items())
   print(i,name,p.returncode,[k for k in row['inventory'] if '.pending' in k],flush=True)
 (root/'qualification/REPRO_PENDING_EXACT.json').write_text(json.dumps(reports,indent=2))
