from pathlib import Path
import subprocess,sys,json,hashlib,os
root=Path(__file__).resolve().parent;dest=root/'qualification/repro_pending';inputs=root/'qualification/suite_final/inputs';script=root/'PEGASUS_FULL_2026_CANDIDATE_V002/tests/synthetic_chain.py'
def inv():return {p.relative_to(dest).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (dest/'sessions').rglob('*') if p.is_file()}
if __name__=='__main__':
 reports=[]
 for name,args in [('fault',['--fault','during_pending']),('resume',[])]:
  with (root/'qualification'/('repro_'+name+'.log')).open('x') as f:
   p=subprocess.run([sys.executable,'-B',str(script),'--inputs',str(inputs),'--out',str(dest),'--workers','3',*args],stdout=f,stderr=subprocess.STDOUT)
  reports.append({'stage':name,'rc':p.returncode,'inventory':inv()})
 (root/'qualification/REPRO_PENDING.json').write_text(json.dumps(reports,indent=2))
 print(json.dumps([{'stage':r['stage'],'rc':r['rc'],'pending':[k for k in r['inventory'] if '.pending' in k]} for r in reports]))
