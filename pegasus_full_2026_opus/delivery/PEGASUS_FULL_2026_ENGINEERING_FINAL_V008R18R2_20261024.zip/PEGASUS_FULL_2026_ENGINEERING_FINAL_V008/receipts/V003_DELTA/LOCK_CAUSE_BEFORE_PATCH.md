# Causa comprovada antes do patch

O probe lock_parent executou os bytes V002 de r1r11_resources.py SHA C7F6278306875BC442C741176937304BC5507713D6A504F864A40C7B7331733F. recover foi substituído por sentinela: nenhum protocolo de recovery nem código econômico foi executado.

Em exceção da sentinela recover, exceção de cleanup scratch e KeyboardInterrupt durante entrada: o corpo with não foi admitido, a exceção original propagou, o mutex foi liberado, mas RUN.lock permaneceu. Saída normal limpa e exclusão mútua funcionaram no probe. Lock preexistente vivo foi preservado.

Causa de código: os dois handlers de __enter__ chamam apenas _release_mutex. __exit__ não é chamado pela linguagem quando __enter__ lança exceção. A remoção do lock owned está em __exit__, portanto esse handler não é alcançado automaticamente. Referência primária: https://docs.python.org/3/reference/compound_stmts.html#the-with-statement (consulta 2026-10-09).

Correção delimitada: reutilizar o cleanup de __exit__ no abort de entrada, ainda sob mutex; se o cleanup falhar, adicionar a falha secundária à exceção original e propagá-la sem substituição. O cleanup existente verifica run_instance antes de unlink. Nenhuma mudança em recover/commit, nenhuma exclusão de árvores históricas.

Não atribuir esse defeito às capturas concluídas de suite_final: seus logs mostram entrada concluída, processamento e status final; falta prova histórica da operação dos resíduos. O caso PENDING continua aberto.
