# PEGASUS FULL 2026 V002. ASCII / no BOM. Windows PowerShell 5.1.
[CmdletBinding()]
param([ValidateSet('Verify','QualifyOffline')][string]$Mode='Verify')
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$Project='Pegasus Original'
$Thread='Implementacao FULL 2026'
Write-Host "RESULT_CONTEXT=ChatGPT | PROJECT=$Project | THREAD=$Thread"
$ResultCode=2
$ExtractStarted=$false
$RunRoot=$null
function ConvertTo-PegasusNativeArgument([string]$Value) {
    # Exactly one Windows argv serialization layer; input values are unquoted.
    $Builder=New-Object System.Text.StringBuilder
    [void]$Builder.Append('"')
    $SlashCount=0
    foreach($Character in $Value.ToCharArray()) {
        if($Character -eq [char]92) { $SlashCount++; continue }
        if($Character -eq [char]34) {
            [void]$Builder.Append(([string][char]92)*($SlashCount*2+1))
            [void]$Builder.Append($Character)
        } else {
            [void]$Builder.Append(([string][char]92)*$SlashCount)
            [void]$Builder.Append($Character)
        }
        $SlashCount=0
    }
    [void]$Builder.Append(([string][char]92)*($SlashCount*2))
    [void]$Builder.Append('"')
    return $Builder.ToString()
}
function Invoke-PegasusNative([string]$Executable,[string[]]$NativeArguments,[string]$WorkingRoot,[int]$TimeoutSeconds=1800) {
    $Info=New-Object System.Diagnostics.ProcessStartInfo
    $Info.FileName=$Executable
    $Serialized=@($NativeArguments | ForEach-Object { ConvertTo-PegasusNativeArgument $_ })
    $Info.Arguments=[string]::Join(' ',[string[]]$Serialized)
    $Info.WorkingDirectory=$WorkingRoot
    $Info.UseShellExecute=$false
    $Info.EnvironmentVariables['PYTHONNOUSERSITE']='1'
    $Info.EnvironmentVariables['PYTHONDONTWRITEBYTECODE']='1'
    $Info.EnvironmentVariables['OPENBLAS_NUM_THREADS']='1'
    $Info.EnvironmentVariables['OMP_NUM_THREADS']='1'
    $Info.EnvironmentVariables.Remove('PYTHONPATH')
    $Info.EnvironmentVariables.Remove('PYTHONHOME')
    $Child=New-Object System.Diagnostics.Process
    $Child.StartInfo=$Info
    $Started=$Child.Start()
    if(-not $Started) { throw 'NATIVE_START_FAILED' }
    $Clock=[System.Diagnostics.Stopwatch]::StartNew()
    while(-not $Child.WaitForExit(10000)) {
        Write-Host "BOOTSTRAP_HEARTBEAT child=$($Child.Id) elapsed_s=$([int]$Clock.Elapsed.TotalSeconds)"
        if($Clock.Elapsed.TotalSeconds -gt $TimeoutSeconds) {
            $TimeoutRecord=@{result='BLOCKED_RECONCILE_LIVE_CHILD';pid=$Child.Id;creation_time_utc=$Child.StartTime.ToUniversalTime().ToString('o');kill_performed=$false}
            $TimeoutRecord | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $WorkingRoot 'TIMEOUT_RECONCILE.json') -Encoding UTF8
            throw 'WATCHDOG_TIMEOUT_NO_KILL_RECONCILE_REQUIRED'
        }
    }
    $Child.WaitForExit()
    $Child.Refresh()
    if($null -eq $Child.ExitCode) { throw 'NATIVE_EXIT_NULL' }
    $NativeCode=[int]$Child.ExitCode
    $Child.Dispose()
    return $NativeCode
}
try {
    if($env:OS -ne 'Windows_NT' -or $PSVersionTable.PSEdition -ne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'WINDOWS_POWERSHELL_5_1_DESKTOP_REQUIRED' }
    $Python='C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe'
    $Downloads='C:\Users\silvi\OneDrive\Downloads'
    if(-not (Test-Path -LiteralPath $Python -PathType Leaf)) { throw 'PINNED_PYTHON_NOT_FOUND' }
    if(-not (Test-Path -LiteralPath $Downloads -PathType Container)) { throw 'CANONICAL_DOWNLOADS_NOT_FOUND' }
    $VersionLines=@(& $Python --version)
    $VersionExit=$LASTEXITCODE
    if($VersionExit -ne 0 -or $VersionLines.Count -ne 1 -or $VersionLines[0] -ne 'Python 3.14.7') { throw 'PYTHON_3_14_7_REQUIRED' }
    [byte[]]$Payload=[Convert]::FromBase64String(@'
@@PAYLOAD@@
'@)
    $Hasher=[System.Security.Cryptography.SHA256]::Create()
    $Actual=[BitConverter]::ToString($Hasher.ComputeHash($Payload)).Replace('-','')
    $Hasher.Dispose()
    if($Actual -ne '@@PAYLOAD_SHA@@') { throw 'EMBEDDED_PAYLOAD_HASH_MISMATCH' }
    Add-Type -AssemblyName System.IO.Compression
    $Memory=New-Object System.IO.MemoryStream(,$Payload)
    $Archive=New-Object System.IO.Compression.ZipArchive($Memory,[System.IO.Compression.ZipArchiveMode]::Read,$false)
    $Seen=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    [Int64]$Expanded=0
    foreach($Entry in $Archive.Entries) {
        $Name=$Entry.FullName
        if([string]::IsNullOrEmpty($Name) -or $Name.Contains('\') -or $Name.Contains(':') -or $Name.StartsWith('/') -or $Name.EndsWith('/') -or @($Name.Split('/') | Where-Object { $_ -eq '..' -or $_ -eq '.' -or $_ -eq '' }).Count -gt 0 -or -not $Seen.Add($Name)) { throw 'ZIP_UNSAFE_OR_DUPLICATE_MEMBER' }
        if(($Entry.ExternalAttributes -shr 16 -band 61440) -eq 40960) { throw 'ZIP_SYMLINK_FORBIDDEN' }
        $Expanded+=[Int64]$Entry.Length
    }
    $Disk=New-Object System.IO.DriveInfo ([System.IO.Path]::GetPathRoot($Downloads))
    [Int64]$Required=$Expanded+[Int64]$Payload.LongLength+[Int64]2147483648
    if([Int64]$Disk.AvailableFreeSpace -lt $Required) { throw 'OFFLINE_SPACE_RESERVE_INSUFFICIENT' }
    $RunRoot=Join-Path $Downloads ('P26_'+[Guid]::NewGuid().ToString('N'))
    if(Test-Path -LiteralPath $RunRoot) { throw 'NEW_ROOT_REQUIRED' }
    $ExtractStarted=$true
    [void][System.IO.Directory]::CreateDirectory($RunRoot)
    $PackageRoot=Join-Path $RunRoot 'PACKAGE'
    [void][System.IO.Directory]::CreateDirectory($PackageRoot)
    foreach($Entry in $Archive.Entries) {
        $Target=Join-Path $PackageRoot ($Entry.FullName.Replace('/','\'))
        [void][System.IO.Directory]::CreateDirectory([System.IO.Path]::GetDirectoryName($Target))
        $SourceStream=$Entry.Open()
        $TargetStream=New-Object System.IO.FileStream($Target,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::Write,[System.IO.FileShare]::None)
        try { $SourceStream.CopyTo($TargetStream); $TargetStream.Flush($true) } finally { $TargetStream.Dispose(); $SourceStream.Dispose() }
    }
    $Archive.Dispose();$Memory.Dispose()
    $EntryPoint=Join-Path $PackageRoot 'CODE\pegasus_entry.py'
    $VerifyCode=Invoke-PegasusNative $Python @('-I','-B',$EntryPoint,'verify') $RunRoot 120
    if($VerifyCode -ne 0) { throw "PACKAGE_VERIFY_EXIT=$VerifyCode" }
    # Native argv and raw exit propagation probe on this exact host, before qualification.
    $Probe=Join-Path $PackageRoot 'tests\argv_probe.py'
    $ProbeOut=Join-Path $RunRoot 'ARGV_PROBE.json'
    $ProbeCode=Invoke-PegasusNative $Python @('-I','-B',$Probe,$ProbeOut,'space value','literal"quote','tail\') $RunRoot 30
    if($ProbeCode -ne 37) { throw 'ARGV_EXIT_PROPAGATION_PROBE_FAILED' }
    $ProbeData=Get-Content -LiteralPath $ProbeOut -Raw | ConvertFrom-Json
    if(-not $ProbeData.pass) { throw 'ARGV_VALUE_PROBE_FAILED' }
    if($Mode -eq 'QualifyOffline') {
        $Venv=Join-Path $RunRoot 'private_venv'
        $VenvCode=Invoke-PegasusNative $Python @('-I','-B','-m','venv',$Venv) $RunRoot 120
        if($VenvCode -ne 0) { throw "VENV_EXIT=$VenvCode" }
        $PrivatePython=Join-Path $Venv 'Scripts\python.exe'
        $Deps=Join-Path $PackageRoot 'dependencies'
        $InstallCode=Invoke-PegasusNative $PrivatePython @('-I','-B','-m','pip','--isolated','--disable-pip-version-check','install','--no-index','--find-links',$Deps,'--only-binary=:all:','--require-hashes','--no-deps','--no-compile','-r',(Join-Path $Deps 'requirements_windows.lock')) $RunRoot 180
        if($InstallCode -ne 0) { throw "PRIVATE_NUMPY_INSTALL_EXIT=$InstallCode" }
        $EnvCode=Invoke-PegasusNative $PrivatePython @('-I','-B',(Join-Path $PackageRoot 'tests\environment_probe.py'),(Join-Path $RunRoot 'ENVIRONMENT.json')) $RunRoot 30
        if($EnvCode -ne 0) { throw "PRIVATE_ENVIRONMENT_EXIT=$EnvCode" }
        $ResultCode=Invoke-PegasusNative $PrivatePython @('-I','-B',$EntryPoint,'qualify-offline','--evidence',(Join-Path $RunRoot 'QUALIFICATION')) $RunRoot 2000
    } else { $ResultCode=0 }
    $RecheckCode=Invoke-PegasusNative $Python @('-I','-B',$EntryPoint,'verify') $RunRoot 120
    if($RecheckCode -ne 0) { $ResultCode=3 }
    Write-Host "RUN_ROOT=$RunRoot"
    Write-Host 'FULL_RUN_AUTHORIZED=NO RUN_RELEASED=NO ECONOMIC_EFFECTS=NONE'
} catch {
    if($ExtractStarted) { $ResultCode=3 } else { $ResultCode=2 }
    Write-Host "PEGASUS_BLOCKED=$($_.Exception.Message)"
    Write-Host "OWNED_EXTRACTION_STARTED=$ExtractStarted ROOT=$RunRoot"
} finally {
    if($null -ne $RunRoot -and (Test-Path -LiteralPath $RunRoot)) {
        try {
            $Receipt=@{schema='PEGASUS_BOOTSTRAP_V002';exit_code=$ResultCode;mode=$Mode;extraction_started=$ExtractStarted;full_run_authorized=$false;run_released=$false;root=$RunRoot}
            $Receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $RunRoot 'BOOTSTRAP_RECEIPT.json') -Encoding UTF8
        } catch { if($ResultCode -eq 0 -or $ResultCode -eq 130) { $ResultCode=3 } }
    }
    Write-Host "RESULT_RETURN_TO=ChatGPT | PROJECT=$Project | THREAD=$Thread"
}
exit $ResultCode
