# PACKAGE INDEX — MINOTAURO V005R1 R1R10

## Evidência governante

- `SPEC_V005R1_R2_3_APPROVED.md` (congelado)
- `AUDIT_OPUS55_R1R9_POSTPILOT_FINAL_20260926.md` (auditoria 25, §7: escopo corretivo)

## Allowlist do delta R1R9 → R1R10

Os arquivos abaixo são os únicos alterados ou acrescentados. Qualquer outro arquivo é byte-idêntico à R1R9, e isso é verificado no `BUILD_SELFTEST_LOG_R1R10.txt`.

**Alterados**

- `minotauro_v004_runner.py`
- `minotauro_v005r1_r23_outputs.py`
- `minotauro_v005r1_r23_contract.py`
- `Minotauro_Launcher_Common.ps1`
- `RUN_PHASE.ps1`
- `RUN_SYNTHETIC_GATES.ps1`
- `test_minotauro_v005r1_r23_operational.py`
- `config.example.json`
- `SHA256SUMS.txt` (regenerado)

**Acrescentados — código**

- `minotauro_v005r1_r1r10_memory.py` (runtime manifest)
- `R1R10_LAUNCHER_SELFTEST.ps1` (gate manifest)

**Acrescentados — documentação e evidência**

- `README_R1R10.md`
- `CHANGELOG_R1R10.md`
- `PACKAGE_INDEX_R1R10.md`
- `R1R10_CORRECTIVE_COMPLIANCE.md`
- `AUDIT_OPUS55_R1R9_POSTPILOT_FINAL_20260926.md`
- `FROZEN_FILES_IDENTITY_R1R10.json`
- `BUILD_SELFTEST_LOG_R1R10.txt`
- `DIFF_R1R9_TO_R1R10.patch`
- `IMPLEMENTATION_RECEIPT_R1R10.json`

**Acrescentados — scripts de evidência do builder** (`BUILDER_EVIDENCE_R1R10/`)

Os scripts foram gravados como `.txt` para ficarem fora dos manifests de runtime e de gates, e servem para reprodução pela auditoria.

- `r1r9_vs_r1r10_differential.py.txt`: diferencial sintético R1R9 × R1R10 (LOG §7).
- `parent_chain_harness.ps1.txt`: cadeia pai → filho com transcript (LOG §6c).
- `negative_control_r1r9_semantics.py.txt`: controle negativo do autoteste (LOG §6b).
- `mutation_testing.py.txt`: 10 mutantes, todos mortos (LOG §8).

## Congelados (byte-idênticos)

- `minotauro_v004_core.py`
- `minotauro_v004_io.py`
- `minotauro_v004_preflight.py`
- `minotauro_v004_metrics.py`
- `minotauro_v005r1_r23_gates.py`
- `minotauro_v005r1_r23_reference.py`
- `MQL5/Minotauro_Geometry_Parity_R23.mq5`
- `SPEC_V005R1_R2_3_APPROVED.md`
- `MINOTAURO_REAL_LIVE_V003R1_R6_REFERENCE.mq5`

## Ausências deliberadas

O pacote não contém:

- pasta de output de mercado;
- receipt de gates 27/28;
- `OWNER_PILOT_AUTHORIZATION.json` ou `OWNER_RUN_A_AUTHORIZATION.json`;
- `config.json` real;
- `__pycache__`.
