"""Synthetic diagnostic only. Timers/profiler observe normal code; no gate PASS."""
from pathlib import Path
import cProfile
import functools
import json
import shutil
import sys
import time

PACKAGE=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(PACKAGE))

def profiled_worker(*args):
    from r1r11_worker import worker_main
    profile=cProfile.Profile();profile.enable()
    try:return worker_main(*args)
    finally:
        profile.disable();profile.dump_stats(str(Path(args[2])/'worker.prof'))

def main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('package');ap.add_argument('--out',required=True)
    ap.add_argument('--inputs',required=True);ap.add_argument('--profile',action='store_true')
    ap.add_argument('--worker-profile',action='store_true')
    ns=ap.parse_args();out=Path(ns.out).resolve();out.mkdir(parents=True,exist_ok=False)
    import r1r11_coordinator as co
    import r1r11_resources as res
    import minotauro_v004_runner as runner
    from r1r11_fixtures import run_chain
    if ns.worker_profile:
        co.worker_main=profiled_worker
        original_close=co.ParallelSession.close
        def close(self):
            original_close(self)
            target=out/'worker_profiles'/self.session;target.mkdir(parents=True,exist_ok=True)
            for path in self.scratch.glob('worker_*/worker.prof'):
                shutil.copy2(path,target/(path.parent.name+'.prof'))
        co.ParallelSession.close=close
    times={};current={'session':'setup'}
    def add(name,dt):
        item=times.setdefault(current['session'],{}).setdefault(name,{'seconds':0.,'calls':0})
        item['seconds']+=dt;item['calls']+=1
    def wrap(obj,name,label,session_start=False):
        original=getattr(obj,name)
        @functools.wraps(original)
        def call(*a,**k):
            if session_start:current['session']=a[1]
            start=time.perf_counter()
            try:return original(*a,**k)
            finally:add(label,time.perf_counter()-start)
        setattr(obj,name,call)
    wrap(co.ParallelSession,'__init__','spawn_setup',True)
    original_receive=co.ParallelSession.receive
    def receive(self,expected):
        start=time.perf_counter()
        try:return original_receive(self,expected)
        finally:add('wait_'+expected,time.perf_counter()-start)
    co.ParallelSession.receive=receive
    for obj,name,label in ((co.ParallelSession,'process_record','feed_compute'),
                           (co.ParallelSession,'finish','worker_finish_and_validation'),
                           (co.ParallelSession,'close','workers_close'),
                           (res.JobMemory,'boundary','memory_probes_telemetry'),
                           (co.Runtime,'log','transport_telemetry'),
                           (runner,'_commit_session','canonical_commit_including_merge'),
                           (co.Runtime,'seal_precommit','canonical_hash_seal')):
        wrap(obj,name,label)
    original_merge=co.merged_stream
    def merge(*a,**k):
        iterator=original_merge(*a,**k)
        while True:
            start=time.perf_counter()
            try:row=next(iterator)
            except StopIteration:
                add('merge',time.perf_counter()-start);return
            add('merge',time.perf_counter()-start)
            yield row
    co.merged_stream=merge
    profile=cProfile.Profile()
    try:
        if ns.profile:profile.enable()
        report=run_chain(ns.inputs,out/'candidate','candidate',4,only='heavy')
    finally:
        if ns.profile:
            profile.disable();profile.dump_stats(str(out/'parent.prof'))
        (out/'STAGE_TIMES.json').write_text(json.dumps(times,indent=2))
    rows=[json.loads(x) for x in (out/'candidate/TELEMETRY/R1R11_TRANSPORT.jsonl').read_text().splitlines()]
    batches=[r for r in rows if r['event']=='BATCH_ACK' and r['session']=='2000-03-01']
    summary={'scope':'DIAGNOSTIC_ONLY_NO_GATE_PROMOTION','profiler':ns.profile,'report':report,
             'heavy_stage_times':times['2000-03-01'],'batches':len(batches),
             'slowest_worker_compute_sum':sum(max((i[2]-i[1])/1e9 for i in r['intervals']) for r in batches)}
    (out/'SUMMARY.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k!='report'},indent=2))

if __name__=='__main__':main()
