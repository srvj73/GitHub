"""One preregistered synthetic diagnostic comparison, never an owner gate."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

def main():
    build=Path(__file__).resolve().parent
    original=build.parent/'R1R11_V003_BUILD_20260926/package'
    candidate=build/'candidate'
    inputs=Path(r'D:\MinotauroRuns\MINOTAURO_R1R11_V003R1_OWNER_GATES_20260926\synthetic_inputs')
    target=build/'measurement';target.mkdir(exist_ok=False)
    results={}
    for name,package,role in [('oracle',original,'oracle'),('baseline',original,'candidate'),('corrected',candidate,'candidate')]:
        out=target/name
        args=[sys.executable,'-X','utf8','-B',str(package/'r1r11_fixtures.py'),
              '--inputs',str(inputs),'--out',str(out),'--role',role,'--workers','4','--only','heavy']
        start=time.monotonic()
        with (target/(name+'.log')).open('w',encoding='utf-8') as log:
            log.write('COMMAND='+json.dumps(args)+'\n');log.flush()
            result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,cwd=package)
        if result.returncode:raise RuntimeError(f'{name} EXIT={result.returncode}')
        report=json.loads((out/'SYNTHETIC_EXECUTION.json').read_text())
        results[name]={'case_seconds':report['case_timings']['2000-03-01'],'total_wall_seconds':time.monotonic()-start}
        print(name,json.dumps(results[name]),flush=True)
    def tree(name):
        out=target/name
        return {p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                for p in [*(out/'sessions').rglob('*'),out/'CHECKPOINT.json'] if p.is_file()}
    assert tree('oracle')==tree('baseline')==tree('corrected'),'ECONOMIC_BYTE_DIFFERENCE'
    results['economic_byte_equality']=True
    results['scope']='DIAGNOSTIC_ONLY_NOT_G4_PROMOTION'
    results['candidate_gain']=results['baseline']['case_seconds']/results['corrected']['case_seconds']
    results['oracle_speedup']=results['oracle']['case_seconds']/results['corrected']['case_seconds']
    results['required']=1.5
    results['meets_numerical_threshold']=results['oracle_speedup']>=1.5
    (target/'COMPARISON.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(results,indent=2))

if __name__=='__main__':main()
