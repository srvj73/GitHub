# CHANGELOG R1R11 V005R4 — compressed streaming scratch performance correction

Date: 2026-09-27

## Proven state before change
- Windows V5 suite: PASS 19/19.
- Development economic byte equality: PASS 3/3.
- Development speedup: ~0.99x, 0.99x, 1.03x; required 1.667x.

## Causal review
The A0 budget measured stream service from gzip-compressed oracle artifacts. The V005R1-R3 implementation instead wrote plain authoritative scratch JSONL. On the heavy fixture the final canonical JSON payload is approximately 760 MB before compression (trades ~434 MB, events ~124 MB, equity ~202 MB). Writer and verifier independently reread this physical volume. A level-1 gzip representation of the same payload is only on the order of tens of MB. This physical mismatch explains why A0 predicted ~6–7 s while owner development benchmark remained ~15.5 s.

## V005R4
1. Worker scratch is gzip level 1, append-only JSONL.
2. `Z_SYNC_FLUSH` at each ACKed batch exposes a complete compressed prefix.
3. Watermarks are physical compressed offsets, not uncompressed JSON byte counts.
4. Writer/verifier keep independent persistent file handles and independent incremental gzip decompressors.
5. Both still parse JSON, recompute merge keys/proofs and hash all physical scratch bytes.
6. Writer reuses the canonical raw JSON line; verifier independently reserializes it. Their final level-6 gzip artifacts must remain byte-identical.
7. Final scratch SHA/rows/physical bytes/uncompressed bytes remain bound to the worker seal.

No economic, oracle, final serializer, final compression level, benchmark, G4 parameter or threshold change.
