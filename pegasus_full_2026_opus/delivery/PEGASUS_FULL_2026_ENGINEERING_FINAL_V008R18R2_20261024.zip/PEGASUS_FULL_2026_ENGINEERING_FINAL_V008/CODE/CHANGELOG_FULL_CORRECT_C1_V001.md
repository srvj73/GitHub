# CHANGELOG — FULL CORRECT C1 V001

Parent: MINOTAURO_R1R11_V005R4_COMPRESSED_STREAM_PERF_20260927

Changed runtime files:
- r1r11_worker.py: enrich CUTOFF trade from sealed preflight row before scratch append; verify fill and bid/ask timestamps.
- r1r11_coordinator.py: load/hash-bind sealed PHASE_A session calendar; pass immutable session row to workers; synthetic calendar override only for synthetic fixtures.
- r1r11_fixtures.py: derive synthetic preflight cutoff row before execution and use it for oracle and candidate publication.
- r1r11_correct_full_controller.py: correctness-first automated chain synthetic -> rebind/seal -> Pilot A -> scalar reconciliation -> FULL 250 -> final C1 homologation.

Unchanged economic surface:
- minotauro_v004_core.py
- minotauro_v004_io.py
- minotauro_v004_metrics.py
- minotauro_v004_preflight.py

Performance thresholds are not authorization gates in this revision.
