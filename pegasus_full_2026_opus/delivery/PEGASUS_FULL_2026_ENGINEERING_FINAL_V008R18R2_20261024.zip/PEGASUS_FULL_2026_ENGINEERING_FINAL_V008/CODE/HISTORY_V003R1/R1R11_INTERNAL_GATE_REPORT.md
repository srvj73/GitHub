# Relatório interno R1R11 — evidência de desenvolvimento

STATE=GREEN. Git root `D:\Teste Rede Neural MQL5\Pegasus\micro_transit`, branch `main`, HEAD `0ff570509dae1d93e487150192cd5d2280423368`. Worktree já estava dirty: quatro arquivos rastreados, 288 inserções/19 remoções, além de arquivos não rastreados do owner. A implementação nova está isolada em `R1R11_V003_BUILD_20260926`; nada foi staged/commitado/resetado.

AUTHORIZED_SCOPE=LOCAL_MUTATION_AUTHORIZED + testes sintéticos pontuais + preparação de homologação owner. REAL_DATA_READ_AUTHORIZED=NO. CURRENT_GATE=implementação V003 para OWNER_PC_G1_TO_G11.

ROOT_CAUSE histórica: exigência impossível de ocorrência causal AMBIGUOUS em G6/V002. DECISION: documentos 28/29/30 e certificado resolvem isso normativamente na V003; nenhum core foi alterado para gerar o evento.

## Execuções observadas

Todos os comandos Python usaram `C:\Users\silvi\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe`, 3.12.14, no diretório package, com `-X utf8 -B -m unittest -v`:

| Sufixo do comando | Resultado | Duração unittest | Log |
|---|---|---:|---|
| `test_r1r11_targeted test_r1r11_guards test_r1r11_integration` na revisão inicial de 12 testes | PASS, exit 0 | 3,809 s | TARGETED_DEVELOPMENT_01.log |
| `test_r1r11_targeted.Targeted.test_deferred_cutoff_global_termination` | PASS, exit 0 | 2,205 s | TARGETED_C2_GLOBAL_TERMINATION.log |
| `test_r1r11_guards.Guards.test_duplicate_lock_and_stale_scratch test_r1r11_guards.Guards.test_stale_lock_recovery_serialized_across_processes test_r1r11_integration` | PASS, exit 0 | 1,384 s | TARGETED_LOCK_PREFIX.log |
| `test_r1r11_targeted.Targeted.test_target_passed_causal_fixture` | PASS, exit 0 | 2,163 s | TARGETED_GROUP_SCRATCH_CAUSAL_FIXTURE.log |

São 15 testes distintos observados em revisões sucessivas, não uma alegação de execução integral da suíte final em uma única invocação. Testes repetidos apenas após alterações pertinentes. As fixtures e outputs temporários foram criados pelo harness; os logs preservam a evidência disponível. Nenhum teste executado falhou. Os dois erros iniciais de ferramenta de leitura (prefixo `./` do ZIP e encoding de stdout) estão no recovery, sem mutação ou mudança de critérios.

EVIDENCE: roundtrip binário; spawn; igualdade de resultado e de cinco arquivos por sessão; r_g diferentes; prefixos físicos; resume sem reprocessar sessões seladas; min/max de workers; cap/probe negativos; CRC/generation; lock/PID; certificado e classificações inválidas. Foram comparados 20 arquivos nos diferenciais pending_cancel, deferred e target_passed (aquecimento + três projeções por cenário).

O unittest de integração usa `_prepare_phase` substituído por uma fixture sintética gerada em diretório temporário. Seus rótulos herdados `PILOT_A_RUN=PASS` e datas de janeiro/2025 NÃO representam Pilot A real, leitura de corpus nem autorização. O entrypoint público com gates reais não foi chamado para executar mercado.

EVIDENCE estática: AST dos módulos, cobertura dos arquivos de código pelos manifests, quatro freezes e parse dos launchers em PowerShell 5.1.26100.9444. Parse não é selftest de execução. O relatório de empacotamento registra hashes e preservação, sem promovê-los a G1–G11 PASS.

## Resultado por gate

G1–G11 = NOT_EXECUTED como homologação integral. Há evidência pontual relacionada a G2/G3/G5/G6/G8/G9/G10; isso não promove os respectivos gates. G4 speedup e overlap pesado permanecem UNKNOWN; G6 cobertura completa permanece UNKNOWN; G7 matriz integral permanece UNKNOWN; G11 regressões completas e selftest de launcher permanecem UNKNOWN.

`G6_CONTRACT_V003=PASS` refere-se ao binding congelado, à implementação do contrato de classificação e aos controles negativos pontuais. O manifesto raiz tem status NOT_EXECUTED, sem atribuir cobertura causal ainda não extraída pelo owner.

Risco residual: throughput e caminhos adversariais não homologados podem produzir FAIL legítimo no owner. É proibido reduzir limiar, retirar caso, substituir oracle ou mudar SPEC para transformar FAIL em PASS. Cada FAIL preserva o primeiro erro causal e bloqueia o avanço.

NEXT_ACTION=executar o comando de README_R1R11.md no PC do owner. Após G1–G11 PASS, encaminhar pacote/evidências à auditoria independente pré-piloto. Pilot A real e Run-A continuam não autorizados.
