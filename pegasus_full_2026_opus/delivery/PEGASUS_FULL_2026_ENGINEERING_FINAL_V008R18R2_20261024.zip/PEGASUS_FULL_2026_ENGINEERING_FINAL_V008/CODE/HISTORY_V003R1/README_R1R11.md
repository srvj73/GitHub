# MINOTAURO R1R11 — SPEC V003 — implementação para gates do owner

`R1R11_IMPLEMENTATION_STATUS=READY_FOR_OWNER_GATES`

DECISION: a autoridade de implementação é a SPEC V003 recebida no handoff V003R1. A R1R10 em `oracle/` é o oracle físico congelado. Os textos, receipts e logs R1R9/R1R10 copiados do parent são históricos; não certificam esta implementação. `AUTHORITY/00B_R1R10_FINAL_ORACLE_CERTIFICATION.md` resolve a narrativa histórica de piloto presente na SPEC, sem alterar seus bytes.

EVIDENCE: core, IO, métricas e preflight permanecem byte-idênticos. Foram observados 15 testes pontuais distintos, todos PASS, em execuções de desenvolvimento separadas. Os logs estão em `DEVELOPMENT_EVIDENCE/`. A sintaxe dos quatro launchers novos/alterados foi verificada no PowerShell 5.1.26100.9444. O selftest completo de launcher ainda pertence ao G11 do owner.

UNKNOWN: G1–G11 completos, speedup G4, matriz 2/3/4/8/12, cobertura G6 completa e matriz de falhas/resumes G7 ainda não foram executados. `READY_FOR_OWNER_GATES` não significa homologação, auditoria independente ou autorização de mercado.

## Comando exato no estado entregue

Pode ser colado em `PS C:\Users\silvi>`. O Python abaixo é o runtime 3.12.14 efetivamente encontrado e usado nos testes pontuais. Requer as dependências herdadas do parent (incluindo NumPy); a implementação operacional não acrescenta dependência de terceiros.

```powershell
& 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -NoProfile -ExecutionPolicy Bypass -File 'D:\Teste Rede Neural MQL5\Pegasus\micro_transit\R1R11_V003_BUILD_20260926\package\RUN_R1R11_OWNER_GATES.ps1' -Python 'C:\Users\silvi\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -EvidenceRoot 'D:\Teste Rede Neural MQL5\Pegasus\micro_transit\R1R11_OWNER_GATES_V003_20260926'
```

O comando foi preparado, NÃO executado pelo Codex. Se extrair o ZIP em outro local, troque apenas o caminho absoluto do launcher. Mantenha EvidenceRoot fora do pacote e fora de qualquer corpus/output existente. O runner não usa `config.json`, não lê mercado, não chama MT5 e não cria autorização de Pilot/Run-A. Gera seus CSVs sintéticos e evidence receipts dentro de EvidenceRoot.

G1 preregistra hashes dos inputs, 1.200 ciclos causais da fixture pesada, matriz de workers e threshold 1,5 antes dos timings. Há uma sessão sintética inicial de aquecimento de recursos: a reserva conservadora de 10.708 MiB/worker pode limitar o primeiro grant a 3; a sessão pesada seguinte deve receber exatamente 4. O aquecimento não entra no speedup. Carga externa que impeça a matriz exigida produz FAIL, sem serial fallback nem alteração do critério.

PASS final requer `G1.json` até `G11.json` e `OWNER_G1_TO_G11_RECEIPT.json`, todos vinculados ao SHA do manifest do pacote e às evidências. Cada gate preserva log, elapsed e hashes. Exit 0 só ocorre após todos os gates; qualquer falha sai nonzero, grava traceback e mantém os artefatos. Exits 2/3/130 de filhos sob falha deliberada são esperados exclusivamente quando o gate comprova a recuperação correspondente.

Uma interrupção externa pode ser retomada com o mesmo comando: receipts PASS são revalidados e pulados; um receipt FAIL exige diagnóstico causal, sem retentativa automática nem remoção de evidência. Não mover a árvore de evidências: ela contém bindings de caminhos físicos. Não editar pacote/fixtures após iniciar gates; divergência bloqueia a retomada.

## O que será executado pelo owner

| Gate | Evidência exigida |
|---|---|
| G1 | pacote, escopo operacional e preregistro dos inputs/benchmark |
| G2 | bindings congelados e certificado V003 |
| G3 | spawn Windows e diferenciais pontuais |
| G4 | quatro workers efetivos, overlap real, speedup ≥1,5 e bytes econômicos |
| G5 | cinco contagens de workers, cinco arquivos/sessão e checkpoints idênticos |
| G6 | doze eventos causais, um certificado, cinco equities e todas as obrigações C8 |
| G7 | mortes, lotes inválidos, ACK antigo, scratch, órfão, Ctrl+C, commits e hard cap; resume 2→3 |
| G8 | parser único, nenhum reader nos workers, integração do loop produtivo com fixture |
| G9 | publicações canônicas pelo coordinator e capability de scratch dos workers |
| G10 | AUTOCPU, probes/process scan, ausência de fallback e memória agregada |
| G11 | compilação, regressão completa do oracle, regressão aplicável ao candidato, selftest PS5.1 e manifest |

As classes legadas específicas do monowork, probes e versão R1R10 são executadas integralmente em `oracle/`. Os testes herdados aplicáveis ao candidato e os novos testes operacionais estão enumerados em `OPERATIONAL_TEST_NAMES`; G4–G10 cobrem os requisitos adicionais. `RUN_OPERATIONAL_GATES.ps1` exige os receipts R1R11 antes de emitir seu receipt histórico de compatibilidade. Não usar diretamente a coleção legada inteira na raiz como se ela fosse uma suíte R1R11.

O manifesto G6 da raiz é um contrato pendente, intencionalmente não aceitável como receipt de cobertura. O runner cria a versão com ocorrências verificadas em EvidenceRoot. Somente `AMBIGUOUS_MULTI_SIGNAL` admite certificado; nenhuma ocorrência é fabricada. A lista/tabela do merger mantém o evento.

## Limites operacionais fixados

15 grupos completos, spawn, um slot de 4 MiB, lote padrão 256 registros (1..4096), linha física até 1 MiB, retenção física por lote até 4 MiB. Antes do cutoff, batches limitados; após cutoff, barreira por registro para impedir feed além de `r_global`. Timeout estrutural 120 s; falha não promove a sessão. Inputs que excedam capacidade param fail-closed.

Scratch comprimido: `_scratch/<run_instance>/<session>/<p_idx>_<t_idx>/`; registros PID ficam em `worker_<n>/`. Mutex Windows serializa a recuperação de `RUN.lock`; ambos protegem o mesmo out_root. Worker só grava nos grupos atribuídos e seu registro. Sessão incompleta permanece diagnosticável; o próximo start recusa órfãos vivos, purga scratch comprovadamente morto e sai nonzero uma vez antes do resume explícito.

`JOB_MEM` e `JOB_PEAK_BOUND` somam coordinator, filhos e shared memory. Target 38.822 MiB influencia apenas o próximo grant; hard cap 48.528 MiB gera exit 3. Falha de probe gera exit 2. Contagem de workers e metadados operacionais não entram no checkpoint econômico.

O único próximo gate autorizado é `OWNER_PC_G1_TO_G11`. Mesmo após PASS, continua necessária auditoria independente pré-piloto e autorização específica do owner. Nenhuma autorização está neste pacote.
