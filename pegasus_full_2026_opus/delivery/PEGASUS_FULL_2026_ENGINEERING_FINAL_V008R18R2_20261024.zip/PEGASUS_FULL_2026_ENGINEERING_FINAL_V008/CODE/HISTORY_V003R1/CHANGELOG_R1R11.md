# CHANGELOG R1R11 V003

DECISION: implementar exclusivamente arquitetura MULTIWORK/AUTOCPU sob SPEC V003, mantendo economia e oracle físico R1R10.

- Coordinator single-reader/single-writer, grupos `(p,t)` completos, spawn 2..12, grants por sessão e scan Win32.
- Transporte binário bit-exato, slot limitado, geração/CRC, ACKs, digest e contadores por processo.
- Terminação em `max(r_g)`, snapshot físico exato, sem lote atravessando sessão.
- Scratch gzip por grupo e merge streaming S1a–S5b; fusão dos três eventos globais com igualdade dos campos não fundidos.
- Memória agregada, cap preregistrado, lock exclusivo protegido por mutex, órfãos, SIGINT e encerramento dos filhos.
- Selos operacionais dos cinco arquivos por sessão, fora do checkpoint econômico; verificação no resume.
- G6 V003 vinculado ao certificado de AMBIGUOUS; runner owner G1–G11, fixtures causais, fault injection e launchers PS5.1.
- Config exemplo versionada, sem config/authorization do owner. Gates antigos de compatibilidade exigem homologação R1R11.

EVIDENCE: os quatro módulos congelados e os arquivos de `oracle/` não foram alterados. `DIFF_R1R10_TO_R1R11.patch` mostra apenas arquivos novos/alterados desta implementação; `CHANGED_FILES_R1R11.json` registra seus hashes. Trabalho local anterior, incluindo diagnóstico V002R2, preservado.

Revisão preventiva: mutex fecha a janela read/unlink/create de lock obsoleto; limite físico por lote impede retenção excessiva; recuperação de canonical orphan no harness fica dentro do lock; fixture target_passed demonstra ocorrência causal. Essas alterações foram validadas pontualmente, sem execução integral dos gates.
