from __future__ import annotations

import argparse
import json
import os
import zipfile
from pathlib import Path

from r1r11_owner_gates import verify_package
from minotauro_v005r1_r23_contract import SPEC_SHA256, runner_identity, sha256_file, write_json_atomic_canonical


def _load(path: Path, label: str) -> dict:
    if not path.is_file():
        raise RuntimeError(f"FINAL_AUDIT_REQUIRED_FILE_MISSING {label} {path}")
    obj = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(obj, dict):
        raise RuntimeError(f"FINAL_AUDIT_REQUIRED_JSON_NOT_OBJECT {label}")
    return obj


def _validate_inputs(pkg: Path, owner: Path, a0: Path, dev: Path, ledger: Path) -> dict:
    package_hash = verify_package()
    owner_receipt = owner / "OWNER_G1_TO_G11_RECEIPT.json"
    robj = _load(owner_receipt, "OWNER_G1_TO_G11_RECEIPT")
    if robj.get("status") != "PASS" or robj.get("package_sha256") != package_hash:
        raise RuntimeError("FINAL_AUDIT_OWNER_RECEIPT_NOT_FRESH_PASS")

    a0_go = _load(a0 / "A0_GO_NO_GO.json", "A0_GO_NO_GO")
    forensic = _load(a0 / "A0_1_FORENSIC" / "A0_1_FORENSIC_REPORT.json", "A0_FORENSIC")
    micro = _load(a0 / "A0_2" / "A0_2_MICROBENCH.json", "A0_MICROBENCH")
    equality = _load(a0 / "A0_3" / "A0_3_ECONOMIC_EQUALITY.json", "A0_EQUALITY")
    if a0_go.get("A0_GO_NO_GO") != "GO":
        raise RuntimeError("FINAL_AUDIT_A0_NOT_GO")
    if forensic.get("A0_1_FORENSIC_RECONSTRUCTION") != "PASS_MECHANICAL":
        raise RuntimeError("FINAL_AUDIT_A0_FORENSIC_NOT_PASS")
    if micro.get("A0_2_MICROBENCH") != "PASS_NON_GATE":
        raise RuntimeError("FINAL_AUDIT_A0_MICROBENCH_NOT_PASS")
    if equality.get("A0_3_ECONOMIC_EQUALITY") != "PASS_EQUAL":
        raise RuntimeError("FINAL_AUDIT_A0_EQUALITY_NOT_PASS")
    if not (a0 / "V004R1_OWNER").is_dir():
        raise RuntimeError("FINAL_AUDIT_V004R1_PRIMARY_TREE_MISSING")
    if not (a0 / "V004R2R1_OWNER").is_dir():
        raise RuntimeError("FINAL_AUDIT_V004R2R1_PRIMARY_TREE_MISSING")

    dev_receipt = dev / "DEVELOPMENT_BENCHMARK_RECEIPT.json"
    dobj = _load(dev_receipt, "DEV_BENCH_RECEIPT")
    if dobj.get("R1R11_V005R1_DEV_BENCH") != "PASS" or len(dobj.get("pairs", [])) != 3 or not all(bool(x.get("pass")) for x in dobj.get("pairs", [])):
        raise RuntimeError("FINAL_AUDIT_DEV_BENCH_NOT_PASS_3_OF_3")

    ledger_receipt = ledger / f"G4_CONTROLLER_RECEIPT_{package_hash}.json"
    lobj = _load(ledger_receipt, "G4_CONTROLLER_RECEIPT")
    if lobj.get("status") != "CONSUMED_COMPLETE" or lobj.get("package_sha256") != package_hash:
        raise RuntimeError("FINAL_AUDIT_G4_LEDGER_NOT_COMPLETE_CURRENT_PACKAGE")
    if int(lobj.get("exit_code", -1)) != 0 or (lobj.get("g4_receipt") or {}).get("status") != "PASS":
        raise RuntimeError("FINAL_AUDIT_G4_LEDGER_NOT_PASS")

    rh, _ = runner_identity(pkg)
    return {
        "package_sha256": package_hash,
        "spec_sha256": SPEC_SHA256,
        "runner_sha256": rh,
        "owner_g1_g11_receipt_sha256": sha256_file(owner_receipt),
        "a0_go_no_go_sha256": sha256_file(a0 / "A0_GO_NO_GO.json"),
        "a0_forensic_sha256": sha256_file(a0 / "A0_1_FORENSIC" / "A0_1_FORENSIC_REPORT.json"),
        "a0_microbench_sha256": sha256_file(a0 / "A0_2" / "A0_2_MICROBENCH.json"),
        "a0_equality_sha256": sha256_file(a0 / "A0_3" / "A0_3_ECONOMIC_EQUALITY.json"),
        "dev_bench_receipt_sha256": sha256_file(dev_receipt),
        "g4_controller_receipt_sha256": sha256_file(ledger_receipt),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--owner-output", required=True)
    ap.add_argument("--a0-evidence", required=True)
    ap.add_argument("--dev-bench", required=True)
    ap.add_argument("--g4-ledger", required=True)
    ap.add_argument("--out-zip", required=True)
    ns = ap.parse_args()

    pkg = Path(__file__).resolve().parent
    owner = Path(ns.owner_output).resolve()
    a0 = Path(ns.a0_evidence).resolve()
    dev = Path(ns.dev_bench).resolve()
    ledger = Path(ns.g4_ledger).resolve()
    dest = Path(ns.out_zip).resolve()
    for label, p in (("OWNER", owner), ("A0", a0), ("DEV_BENCH", dev), ("G4_LEDGER", ledger)):
        if not p.is_dir():
            raise RuntimeError(f"FINAL_AUDIT_{label}_ROOT_MISSING {p}")
    if dest.exists():
        raise RuntimeError("FINAL_AUDIT_ZIP_EXISTS")

    bindings = _validate_inputs(pkg, owner, a0, dev, ledger)
    index = {
        "schema": "R1R11_V005R1_FINAL_AUDIT_PACK_V2",
        **bindings,
        "required_final_audit_marker": "R1R11_FINAL_PREPILOT_AUDIT=PASS",
        "required_pack_binding_marker": "R1R11_FINAL_AUDIT_PACK_SHA256=<THIS_ZIP_SHA256>",
        "entries": [],
    }
    roots = (
        (pkg, "PACKAGE"),
        (owner, "OWNER_EVIDENCE_V005R1"),
        (a0, "A0_EVIDENCE"),
        (dev, "DEVELOPMENT_BENCHMARK"),
        (ledger, "G4_EXTERNAL_LEDGER"),
    )
    tmp = dest.with_suffix(dest.suffix + ".tmp")
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as z:
        for base, label in roots:
            for p in sorted(base.rglob("*")):
                if not p.is_file() or "__pycache__" in p.parts:
                    continue
                arc = f"{label}/{p.relative_to(base).as_posix()}"
                z.write(p, arc)
                index["entries"].append({"path": arc, "sha256": sha256_file(p), "bytes": p.stat().st_size})
        raw = (json.dumps(index, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")
        z.writestr("00_FINAL_AUDIT_PACK_INDEX.json", raw)
    os.replace(tmp, dest)
    zsha = sha256_file(dest)
    side = dest.with_suffix(dest.suffix + ".sha256.json")
    write_json_atomic_canonical(side, {
        "zip": dest.name, "sha256": zsha, "entries": len(index["entries"]),
        **bindings,
        "audit_report_must_contain": [
            "R1R11_FINAL_PREPILOT_AUDIT=PASS",
            f"R1R11_FINAL_AUDIT_PACK_SHA256={zsha}",
        ],
    })
    print(json.dumps({"FINAL_AUDIT_PACK": "PASS", "zip": str(dest), "sha256": zsha,
                      "entries": len(index["entries"])}, sort_keys=True))


if __name__ == "__main__":
    main()
