"""Explicit owner-only G1-G11 homologation; resumable, synthetic inputs only."""
from __future__ import annotations

import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback

PACKAGE=Path(__file__).resolve().parent
OPERATIONAL_TEST_NAMES=(
    'test_minotauro_v005r1_r23_operational.OperationalGateTests',
    'test_minotauro_v005r1_r23_operational.R1R10StreamingEquivalenceTests',
    'test_r1r11_targeted','test_r1r11_guards','test_r1r11_integration',
    'test_r1r11_revision',
)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest().upper()


def atomic(path,obj):
    from minotauro_v005r1_r23_contract import write_json_atomic_canonical
    write_json_atomic_canonical(Path(path),obj)


def verify_package():
    path=PACKAGE/'SHA256SUMS.txt'
    listed={}
    for line in path.read_text().splitlines():
        h,n=line.split(None,1);n=n.strip().removeprefix('./');p=(PACKAGE/n).resolve()
        if not p.is_relative_to(PACKAGE) or n in listed or not p.is_file() or sha(p)!=h.upper():
            raise RuntimeError('PACKAGE_MANIFEST_FAILURE '+n)
        listed[n]=h.upper()
    actual={p.relative_to(PACKAGE).as_posix() for p in PACKAGE.rglob('*') if p.is_file()
            and p!=path}
    if set(listed)!=actual:raise RuntimeError('UNMANIFESTED_PACKAGE_FILES '+str(actual^set(listed)))
    return sha(path)


def tree(root):
    root=Path(root)
    return {p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file()}


def economic(root):
    root=Path(root);result=tree(root/'sessions')
    result['CHECKPOINT.json']=sha(root/'CHECKPOINT.json')
    return result


class OwnerGates:
    def __init__(self,out,stop_after=11):
        self.out=Path(out).resolve()
        if not isinstance(stop_after,int) or isinstance(stop_after,bool) or not 1<=stop_after<=11:
            raise RuntimeError('OWNER_STOP_AFTER_RANGE')
        self.stop_after=stop_after
        if self.out==PACKAGE or self.out.is_relative_to(PACKAGE):raise RuntimeError('OWNER_OUTPUT_MUST_BE_OUTSIDE_PACKAGE')
        if self.out.exists() and any(self.out.iterdir()) and not (self.out/'PREREGISTRATION.json').is_file():
            raise RuntimeError('EXISTING_EVIDENCE_WITHOUT_PREREGISTRATION_REFUSED')
        self.out.mkdir(parents=True,exist_ok=True);self.inputs=self.out/'synthetic_inputs'
        self.package_hash=verify_package();self.started=time.monotonic()

    def command(self,args,name,cwd=None,expected=0):
        log=self.out/(name+'.log')
        with log.open('a',encoding='utf-8') as f:
            f.write('COMMAND '+json.dumps(args)+'\n');f.flush()
            p=subprocess.Popen(args,cwd=cwd or PACKAGE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,
                               encoding='utf-8',errors='replace',env={**os.environ,'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'})
            for line in p.stdout:
                f.write(line);f.flush()
                if 'PROGRESS' in line or 'SESSION_COMMIT' in line or 'GRANTED_WORKERS' in line:print(line.rstrip(),flush=True)
            code=p.wait()
            f.write(f'EXIT_CODE={code}\n')
        if expected is not None and code!=expected:raise RuntimeError(f'COMMAND_FAILED exit={code} expected={expected} log={log}')
        return code

    def child_args(self,out,role='candidate',workers=2,integral='all',only=None,fault=None):
        args=[sys.executable,'-X','utf8','-B',str(PACKAGE/'r1r11_fixtures.py'),
              '--inputs',str(self.inputs),'--out',str(out),'--role',role,'--workers',str(workers),'--integral',integral]
        if only:args+=['--only',only]
        if fault:args+=['--fault',json.dumps(fault)]
        return args

    def chain(self,name,**kwargs):
        out=self.out/name
        marker=out/'SYNTHETIC_EXECUTION.json'
        if marker.exists():
            report=json.loads(marker.read_text())
            if (report['role'],report['workers_requested'],report['integral_mode'])!=(
                    kwargs.get('role','candidate'),kwargs.get('workers',2),kwargs.get('integral','all')):
                raise RuntimeError('SYNTHETIC_COMPLETE_MARKER_MISMATCH')
            print(f'CHILD_RESUME_SKIP completed={name}',flush=True)
            return out
        self.command(self.child_args(out,**kwargs),name)
        return out

    def g1(self):
        from r1r11_fixtures import generate
        from r1r11_revision import operational_parameters
        if not self.inputs.exists():generate(self.inputs)
        # Frozen preregistration: immutable inputs and benchmark before timing.
        prereg={'package_sha256':self.package_hash,'inputs':tree(self.inputs),'heavy_cycles':1200,
                'benchmark_workers':4,'minimum_speedup':1.5,'worker_matrix':[2,3,4,8,12],
                'operational_parameters':operational_parameters()}
        path=self.out/'PREREGISTRATION.json'
        if path.exists() and json.loads(path.read_text())!=prereg:raise RuntimeError('PREREGISTRATION_DRIFT')
        atomic(path,prereg)
        return prereg

    def g2(self):
        from r1r11_contract import validate_bindings
        return validate_bindings()

    def g3(self):
        self.command([sys.executable,'-X','utf8','-B',str(PACKAGE/'run_v4_checks.py'),
                      '--out',str(self.out/'V4_PRE_G4')],'G3_V4_A_TO_H')
        self.command([sys.executable,'-X','utf8','-B','-m','unittest','-v','test_r1r11_targeted'],'G3_targeted')
        import multiprocessing
        if multiprocessing.get_context('spawn').get_start_method()!='spawn':raise RuntimeError('NO_SPAWN')
        return {'spawn':'PASS','small_differential':'PASS','V4_A_to_H':'PASS_BEFORE_OWNER_G4'}

    def g4(self):
        oracle=self.chain('G4_oracle',role='oracle',only='heavy')
        candidate=self.chain('G4_candidate',workers=4,only='heavy')
        a=json.loads((oracle/'SYNTHETIC_EXECUTION.json').read_text())
        b=json.loads((candidate/'SYNTHETIC_EXECUTION.json').read_text())
        heavy=json.loads((self.inputs/'FIXTURES.json').read_text())['heavy']['session']
        speed=a['case_timings'][heavy]/b['case_timings'][heavy]
        telemetry=[json.loads(x) for x in (candidate/'TELEMETRY/R1R11_TRANSPORT.jsonl').read_text().splitlines()]
        granted=[x['decision']['granted'] for x in telemetry if x['event']=='SCHEDULER' and x['session']==heavy]
        overlap=any(max(a[1],b[1])<min(a[2],b[2]) for row in telemetry if row['event']=='BATCH_ACK' and row['session']==heavy
                    for i,a in enumerate(row['intervals']) for b in row['intervals'][i+1:])
        evidence={'speedup':speed,'required':1.5,'granted':granted,'overlap':overlap,
                  'oracle_seconds':a['case_timings'][heavy],'candidate_seconds':b['case_timings'][heavy]}
        atomic(self.out/'G4_MEASURED.json',evidence)
        if granted!=[4] or not overlap or speed<1.5:raise RuntimeError('G4_EFFECTIVE_THROUGHPUT_FAIL '+json.dumps(evidence))
        if economic(oracle)!=economic(candidate):raise RuntimeError('G4_ECONOMIC_DIFFERENCE')
        return evidence

    def g5(self):
        oracle=self.chain('oracle_all',role='oracle')
        expected=economic(oracle);counts={}
        for workers in (2,3,4,8,12):
            path=self.chain(f'candidate_{workers}',workers=workers)
            if economic(path)!=expected:raise RuntimeError(f'G5_BYTE_DIFFERENCE workers={workers}')
            rows=[json.loads(x) for x in (path/'TELEMETRY/R1R11_TRANSPORT.jsonl').read_text().splitlines()]
            grants=[r['decision']['granted'] for r in rows if r['event']=='SCHEDULER' and r['session']!='1999-12-31']
            if not grants or set(grants)!={workers}:raise RuntimeError('G5_REQUESTED_MATRIX_NOT_EXECUTED '+str(grants))
            counts[str(workers)]=len(expected)
        return {'byte_files':counts,'resume_matrix_gate':'G7'}

    def g6(self):
        from r1r11_coverage import construct,verify_manifest_evidence
        baseline=self.chain('oracle_baseline',role='oracle',integral='baseline')
        candidate=self.chain('candidate_baseline',workers=4,integral='baseline')
        manifest=construct(self.inputs,self.out/'oracle_all',self.out/'candidate_4',baseline,candidate,self.out)
        atomic(self.out/'R1R11_ORACLE_COVERAGE_MANIFEST.json',manifest)
        verify_manifest_evidence(manifest,self.out)
        return {'coverage_manifest_sha256':sha(self.out/'R1R11_ORACLE_COVERAGE_MANIFEST.json')}

    def resume_fault(self,name,out,expected):
        # Known scratch cleanup is an explicit, separately logged nonzero start.
        code=self.command(self.child_args(out,workers=3,only='pending_cancel'),name+'_purge_or_resume',expected=None)
        if code:
            log=(self.out/(name+'_purge_or_resume.log')).read_text()
            if 'STALE_SCRATCH_PURGED_RESUME_REQUIRED' not in log:raise RuntimeError('UNEXPECTED_RESUME_FAILURE')
            self.command(self.child_args(out,workers=3,only='pending_cancel'),name+'_resume')
        if economic(out)!=expected:raise RuntimeError('G7_RESUME_TREE_DIFF '+name)

    def g7(self):
        clean=self.chain('G7_clean',workers=2,only='pending_cancel');expected=economic(clean)
        faults=[{'point':'batch','kind':k,'seq':1} for k in
                ('worker_death','lost_batch','duplicate_batch','out_of_order_batch','stale_generation','stale_ack','after_batch')]
        faults += [{'point':p,'kind':'stop'} for p in
                   ('before_merge','during_merge','after_merge_before_commit','after_commit_before_checkpoint')]
        results=[]
        for i,fault in enumerate(faults):
            name=f'G7_{i}_{fault["kind"]}_{fault["point"]}';out=self.out/name
            code=self.command(self.child_args(out,workers=2,only='pending_cancel',fault=fault),name,expected=None)
            if code==0:raise RuntimeError('G7_FAULT_FALSE_PASS '+name)
            cp=json.loads((out/'CHECKPOINT.json').read_text())
            if cp['completed']!=['1999-12-31']:raise RuntimeError('G7_FAILED_SESSION_PROMOTED '+name)
            self.resume_fault(name,out,expected)
            results.append({'fault':fault,'exit':code,'resume_byte_equal':True,'resume_workers':3})
        # Startup stale scratch must purge safely and return nonzero.
        stale=self.out/'G7_stale';(stale/'_scratch'/'dead_instance'/'session').mkdir(parents=True)
        code=self.command(self.child_args(stale,only='pending_cancel'),'G7_stale_first',expected=None)
        if code==0:raise RuntimeError('G7_STALE_FALSE_PASS')
        self.command(self.child_args(stale,workers=3,only='pending_cancel'),'G7_stale_resume')
        if economic(stale)!=expected:raise RuntimeError('G7_STALE_RESUME_DIFF')
        results.extend(self.real_process_faults(expected))
        self.memory_faults(expected)
        return {'faults':results,'stale_scratch':'PASS','memory_boundaries':'PASS'}

    def real_process_faults(self,expected):
        # Dedicated consoles permit a genuine CTRL_C_EVENT without signalling
        # the owner terminal or any unrelated process. Child window stays hidden.
        from r1r11_resources import process_snapshot
        results=[]
        for mode in ('ctrl_c','parent_death'):
            out=self.out/('G7_'+mode);logpath=self.out/('G7_'+mode+'.log')
            startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
            with logpath.open('w',encoding='utf-8') as log:
                proc=subprocess.Popen(self.child_args(out,workers=2,only='pending_cancel',
                    fault={'point':'batch','kind':'orphan_worker','seq':1}),stdout=log,stderr=subprocess.STDOUT,
                    startupinfo=startup,creationflags=subprocess.CREATE_NEW_CONSOLE,
                    env={**os.environ,'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'})
                deadline=time.monotonic()+30;worker_pids=[]
                while time.monotonic()<deadline and proc.poll() is None:
                    regs=list((out/'_scratch').rglob('worker.json')) if (out/'_scratch').exists() else []
                    worker_pids=[json.loads(p.read_text())['pid'] for p in regs]
                    if worker_pids and 'GRANTED_WORKERS' in logpath.read_text(errors='replace'):
                        # Observe the non-warmup session worker registry.
                        if list((out/'_scratch').rglob('ORPHAN_TEST_HOLD.marker')):break
                    time.sleep(.05)
                else:
                    proc.terminate();proc.wait();raise RuntimeError('FAULT_CHILD_NOT_READY')
                if mode=='ctrl_c':
                    self.command([sys.executable,'-B',str(PACKAGE/'r1r11_signal.py'),'--pid',str(proc.pid)],'G7_send_ctrl_c')
                else:proc.terminate()
                code=proc.wait(timeout=20)
                if code==0:raise RuntimeError('G7_PROCESS_FAULT_FALSE_PASS')
            alive={r['pid'] for r in process_snapshot()}
            if mode=='parent_death':
                # The deliberately stuck worker supplies a live orphan for the
                # startup refusal test. Only recorded children of this test are killed.
                orphan=[p for p in worker_pids if p in alive]
                if not orphan:raise RuntimeError('G7_ORPHAN_NOT_OBSERVED')
                rejected=self.command(self.child_args(out,only='pending_cancel'),'G7_orphan_refusal',expected=None)
                if rejected==0:raise RuntimeError('G7_ORPHAN_FALSE_PASS')
                for pid in orphan:os.kill(pid,signal.SIGTERM)
                deadline=time.monotonic()+10
                while any(p in {r['pid'] for r in process_snapshot()} for p in orphan):
                    if time.monotonic()>deadline:raise RuntimeError('G7_ORPHAN_CLEANUP_FAILED')
                    time.sleep(.1)
            self.resume_fault('G7_'+mode,out,expected)
            results.append({'fault':mode,'exit':code,'resume_byte_equal':True})
        return results

    def memory_faults(self,expected):
        # Separate child has test-only Win32 sample injection. No cap changes.
        for boundary in ('BATCH_ACK','PRE_COMMIT','COMMIT_COMPLETE','MONTH_VERIFIED','PRE_PILOT_RECEIPT','PRE_FINALIZE','POST_FINALIZE'):
            name='G7_memory_'+boundary;out=self.out/name
            code=self.command(self.child_args(out,workers=2,only='pending_cancel',
                fault={'point':boundary,'kind':'memory_cap'}),name,expected=None)
            if code!=3:raise RuntimeError('G7_MEMORY_EXPECTED_EXIT_3 '+name)
            self.resume_fault(name,out,expected)

    def g8(self):
        self.command([sys.executable,'-X','utf8','-B','-m','unittest','-v',
                      'test_r1r11_integration'],'G8_production_loop_synthetic')
        for workers in (2,3,4,8,12):
            report=json.loads((self.out/f'candidate_{workers}'/'SYNTHETIC_EXECUTION.json').read_text())
            if report['parser_calls']!=report['source_records'] or report['parser_calls']<=0:
                raise RuntimeError('G8_SINGLE_PARSE_FAILURE')
        worker=ast.parse((PACKAGE/'r1r11_worker.py').read_text())
        imports=[n.module for n in ast.walk(worker) if isinstance(n,ast.ImportFrom)]
        if 'minotauro_v004_io' in imports or 'minotauro_v004_runner' in imports:raise RuntimeError('G8_WORKER_SOURCE_IMPORT')
        return {'parser_calls_per_physical_record':1,'worker_source_parser_imports':0}

    def g9(self):
        report=json.loads((self.out/'candidate_4/SYNTHETIC_EXECUTION.json').read_text())
        if not report['canonical_writes'] or {r['pid'] for r in report['canonical_writes']}!={report['coordinator_pid']}:
            raise RuntimeError('G9_MULTIPLE_WRITERS')
        worker=(PACKAGE/'r1r11_worker.py').read_text()
        if 'WORKER_WRITE_OUTSIDE_SCRATCH' not in worker:raise RuntimeError('G9_WRITE_CAPABILITY_GUARD_ABSENT')
        return {'single_coordinator_pid':report['coordinator_pid'],'worker_scratch_guard':'ACTIVE'}

    def g10(self):
        self.command([sys.executable,'-B','-m','unittest','-v','test_r1r11_guards'],'G10_guards')
        for workers in (2,3,4,8,12):
            path=self.out/f'candidate_{workers}/TELEMETRY/memory.jsonl'
            previous_peak=0
            for line in path.read_text().splitlines():
                r=json.loads(line);current=sum(p['private'] for p in r['pids'])+r['shared_memory_bytes']
                bound=max(current,sum(p['peak'] for p in r['pids'])+r['shared_memory_bytes'])
                if (current,bound)!=(r['JOB_MEM'],r['JOB_PEAK_BOUND']):raise RuntimeError('G10_AGGREGATE_ERROR')
                if bound>48528*1024**2:raise RuntimeError('G10_HARD_CAP_EXCEEDED')
                previous_peak=max(previous_peak,bound)
                if r.get('JOB_PEAK_BOUND_RUN')!=previous_peak:raise RuntimeError('G10_LOST_CHILD_PEAK')
        return {'aggregate_memory':'PASS','policy':'PASS'}

    def g11(self):
        import py_compile
        cache=self.out/'compile';cache.mkdir(exist_ok=True)
        for i,path in enumerate(sorted(PACKAGE.rglob('*.py'))):
            py_compile.compile(str(path),cfile=str(cache/f'{i}.pyc'),doraise=True)
        self.command([sys.executable,'-B','-m','unittest','-v','test_minotauro_v004',
                      'test_minotauro_v005r1_r23_gates','test_minotauro_v005r1_r23_operational'],
                     'G11_frozen_oracle_regression',cwd=PACKAGE/'oracle')
        self.command([sys.executable,'-B','-m','unittest','-v',
                      'test_minotauro_v004','test_minotauro_v005r1_r23_gates',
                      *OPERATIONAL_TEST_NAMES],'G11_candidate_regression')
        ps=Path(os.environ['SystemRoot'])/'System32/WindowsPowerShell/v1.0/powershell.exe'
        self.command([str(ps),'-NoProfile','-ExecutionPolicy','Bypass','-File',
                      str(PACKAGE/'R1R11_LAUNCHER_SELFTEST.ps1'),'-Python',sys.executable],
                     'G11_powershell51_launchers')
        if verify_package()!=self.package_hash:raise RuntimeError('PACKAGE_CHANGED_DURING_GATES')
        return {'compile':'PASS','frozen_oracle_regression':'PASS','candidate_regression':'PASS',
                'powershell51_launchers':'PASS','package_manifest':'PASS'}

    def run(self):
        from r1r11_resources import RunLock
        with RunLock(self.out) as lock:
            for number in range(1,self.stop_after+1):
                p=self.out/f'G{number}.json'
                if p.exists():
                    previous=json.loads(p.read_text())
                    if previous.get('package_sha256')!=self.package_hash:raise RuntimeError('GATE_RECEIPT_BINDING_DRIFT')
                    if previous.get('status')=='PASS':
                        if not isinstance(previous.get('evidence_files'),dict) or not previous['evidence_files']:
                            raise RuntimeError('GATE_EVIDENCE_REQUIRED')
                        for name,expected in previous.get('evidence_files',{}).items():
                            path=(self.out/name).resolve()
                            if not path.is_relative_to(self.out) or not path.is_file() or sha(path)!=expected:
                                raise RuntimeError('GATE_EVIDENCE_DRIFT '+name)
                        print(f'RESUME_SKIP G{number}=PASS',flush=True);continue
                    raise RuntimeError(f'PREVIOUS_G{number}_FAIL_REQUIRES_CAUSAL_REVIEW')
                started=time.monotonic()
                try:
                    result=getattr(self,f'g{number}')()
                    evidence_files=tree(self.out)
                    evidence_files.pop('RUN.lock',None)
                    atomic(p,{'gate':number,'status':'PASS','result':result,'package_sha256':self.package_hash,
                              'evidence_files':evidence_files,
                              'elapsed_seconds':time.monotonic()-started})
                except BaseException as exc:
                    atomic(p,{'gate':number,'status':'FAIL','error':repr(exc),'traceback':traceback.format_exc(),
                              'package_sha256':self.package_hash,'elapsed_seconds':time.monotonic()-started})
                    raise
                elapsed=time.monotonic()-self.started
                print(f'OWNER_GATES_PROGRESS {number}/11 {number/11:.1%} elapsed={elapsed:.1f}s '
                      f'ETA={elapsed/number*(11-number):.1f}s checkpoint={p}',flush=True)
            if self.stop_after==11:
                atomic(self.out/'OWNER_G1_TO_G11_RECEIPT.json',{'status':'PASS','package_sha256':self.package_hash,
                       'real_data_processed':False,'pilot_authorized':False,'run_a_authorized':False})
                print('OWNER_G1_TO_G11=PASS REAL_DATA_PROCESSED=NO PILOT_A_AUTHORIZED=NO RUN_A_AUTHORIZED=NO')
            else:
                print(f'OWNER_GATES_PARTIAL_PASS=G1_TO_G{self.stop_after} NEXT_GATE=G{self.stop_after+1}',flush=True)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--owner-output',required=True);ap.add_argument('--stop-after',type=int,default=11);ns=ap.parse_args()
    try:OwnerGates(ns.owner_output,ns.stop_after).run()
    except BaseException:
        traceback.print_exc();raise SystemExit(2)


if __name__=='__main__':main()
