# CHANGELOG R1R9 — PowerShell 5.1 transcript stdout closure

## Parent
- R1R8 implementation ZIP SHA256: `714F6698A410E655015F69F65B9E39FE37E35ED478B58AE633E946CACBDE4E43`
- Opus R1R8 diff audit: PASS; owner smoke mandatory before other non-economic gates.
- Owner R1R8 smoke: Python 3.14 synthetic suite PASS 44/44 with exit code 0; transcript captured `Ran 44 tests`, `OK`, and `SYNTHETIC_GATE=PASS`, but missed Python stdout JSON `"SYNTHETIC_GATES": "PASS"`. Smoke therefore blocked before rebind.

## Runtime delta
No economic, causal, parser, preflight, metric, gate algorithm, receipt-chain, selection, output, or MQL5 geometry semantics changed.

Exactly three runtime/config files differ from R1R8:
1. `Minotauro_Launcher_Common.ps1`
   - replaces stdout `Out-Host` streaming with a dedicated temporary stdout spool;
   - keeps a dedicated temporary stderr spool;
   - after the native Python process exits, replays **both** spools through `Write-Host`;
   - native `$LASTEXITCODE` remains the sole success/failure authority;
   - temporary files are removed in `finally`;
   - Python 3.14 enforcement, absolute `out_root`, transcript ownership, and nested reuse remain unchanged.
2. `minotauro_v005r1_r23_contract.py`
   - only `RUNNER_VERSION` changes R1R8 → R1R9. The existing manifests automatically bind the changed helper and contract to the new identities.
3. `config.example.json`
   - only `out_root` changes R1R8 → R1R9.

All other runtime/economic/gate/MQL5 files are byte-identical to R1R8.

## Identities
- runner_sha256: `17436F2AB81384DC5250656039035C263E59F4AEA792AE38C25B2D7FEDA34585`
- gate_suite_sha256: `302AA65B1A487195D07DC36EDEEDB5633251C7B668CF40ACCE59ADF160255B83`

## Builder evidence
- Python 3.13.5 py_compile: PASS
- Python tests: PASS 54/54
- Windows PowerShell 5.1 runtime validation: not available in builder; owner smoke required after external diff audit.
- Market data processing: NO
