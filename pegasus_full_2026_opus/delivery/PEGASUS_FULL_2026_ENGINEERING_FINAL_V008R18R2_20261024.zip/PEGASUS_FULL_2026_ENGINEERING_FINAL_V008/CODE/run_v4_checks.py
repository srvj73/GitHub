"""R1R11 V005 owner pre-G4 suite.

Compatibility: G3 is frozen and still invokes run_v4_checks.py and reports
V4_A_to_H. This runner executes V005 A-J and emits compatibility V4-A..H
receipts mapped to the adapted V5-A..H tests. V5-J's measured 3/3 benchmark is
an external non-gate prerequisite enforced by r1r11_g4_controller.py.
"""
import argparse
import json
import os
from pathlib import Path
import time
import unittest


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',required=True);ns=parser.parse_args()
    out=Path(ns.out).resolve();out.mkdir(exist_ok=False)
    os.environ['R1R11_V5_TEST_ROOT']=str(out/'evidence')
    records={}
    class Result(unittest.TextTestResult):
        def startTest(self,test): self.started=time.monotonic();super().startTest(test)
        def addSuccess(self,test): records[test.id()]={'status':'PASS','seconds':time.monotonic()-self.started};super().addSuccess(test)
        def addFailure(self,test,err): records[test.id()]={'status':'FAIL','error':self._exc_info_to_string(err,test)};super().addFailure(test,err)
        def addError(self,test,err): records[test.id()]={'status':'ERROR','error':self._exc_info_to_string(err,test)};super().addError(test,err)
    suite=unittest.defaultTestLoader.loadTestsFromNames(['test_r1r11_v5','test_r1r11_v5_static'])
    discovered=suite.countTestCases()
    result=unittest.TextTestRunner(verbosity=2,resultclass=Result,failfast=True).run(suite)
    # V005 A-J receipts.
    for letter in 'abcdefghij':
        matched=[v for k,v in records.items() if f'.test_v5_{letter}_' in k]
        obj=matched[0] if len(matched)==1 else {'status':'NOT_EXECUTED_OR_NONUNIQUE','matches':len(matched)}
        (out/f'V5-{letter.upper()}.json').write_text(json.dumps(obj,indent=2),encoding='utf-8')
    # Frozen G3 compatibility receipts: V4-A..H are the V005-adapted A..H.
    for letter in 'abcdefgh':
        src=out/f'V5-{letter.upper()}.json'; (out/f'V4-{letter.upper()}.json').write_bytes(src.read_bytes())
    (out/'RESULTS.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    (out/'TEST_DISCOVERY.json').write_text(json.dumps({'discovered_test_count':discovered,'executed_record_count':len(records),
        'suite':'R1R11_V005_A_TO_J_PLUS_STATIC','v4_compatibility':'V5_A_TO_H'},indent=2),encoding='utf-8')
    all_receipts=all(json.loads((out/f'V5-{x}.json').read_text()).get('status')=='PASS' for x in 'ABCDEFGHIJ')
    return 0 if result.wasSuccessful() and len(records)==discovered and all_receipts else 2

if __name__=='__main__':raise SystemExit(main())
