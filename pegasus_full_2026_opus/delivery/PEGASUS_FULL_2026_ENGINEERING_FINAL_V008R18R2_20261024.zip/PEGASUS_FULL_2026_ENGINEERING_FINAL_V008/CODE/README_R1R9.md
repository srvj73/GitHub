# MINOTAURO V005R1 — R1R9

R1R9 is an operational-only successor to R1R8. It exists solely because the owner Windows PowerShell 5.1 smoke proved that R1R8 still omitted Python stdout from `Start-Transcript`, even though stderr replay and PowerShell host output were captured.

## Scope
- Governing economic/methodological specification: V005R1-R2.3.
- Parent physical implementation: R1R8.
- Economic/causal delta: **NONE**.
- Runtime/config delta: exactly `Minotauro_Launcher_Common.ps1`, version label in `minotauro_v005r1_r23_contract.py`, and example `out_root` in `config.example.json`.

## R1R9 transcript strategy
`Invoke-MinotauroPython` captures native stdout and stderr to two temporary files. Once Python exits, both are replayed through `Write-Host`, which the owner smokes have already shown is captured by Windows PowerShell 5.1 `Start-Transcript`. The native exit code is captured immediately after process termination and remains the sole fail-closed authority.

## Required next gate
No owner-PC gate beyond a fresh synthetic transcript smoke is authorized by this package itself. First obtain an independent mechanical R1R8→R1R9 diff re-audit. If PASS authorizes owner smoke, extract R1R9 to a new directory/out_root and run only `RUN_SYNTHETIC_GATES.ps1`. The transcript must contain:
- `TRANSCRIPT=`
- `Ran 44 tests` and `OK`
- JSON `"SYNTHETIC_GATES": "PASS"`
- `SYNTHETIC_GATE=PASS`

Only after that runtime smoke passes may the previously approved non-economic chain proceed. Pilot A, run-a, owner authorization files, and economic processing remain prohibited.
