# PACKAGE INDEX — MINOTAURO R1R11 V004R2

Current implementation revision after V004R1 owner G4 FAIL.

Authoritative current files:
- `SPEC_R1R11_MULTIWORK_AUTOCPU_V004.md` — unchanged V004 normative spec.
- `OPERATIONAL_PREREGISTRATION_V004R2.json` — V004R2 preregistration.
- `V004R2_CAUSAL_PREREGISTRATION.md` — causal rationale frozen before V004R2 G4.
- `CHANGELOG_V004R1_TO_V004R2.md` — implementation delta.
- `V004R2_INTERNAL_DEEP_REVIEW.md` — internal pre-owner review.
- `IMPLEMENTATION_RECEIPT_R1R11.json` — current implementation receipt.
- `RUN_R1R11_OWNER_GATES.ps1` — owner launcher with `-StopAfter 3` safety staging.
- `r1r11_owner_gates.py` — G1–G11; G4 function and fixture semantics unchanged from V004R1.

Historical V003/V004R1 evidence remains inside the package and is not promoted.

No real data, Pilot A or Run-A is authorized by this package.
