# ROLLBACK — PERF NEXT V002

Rollback is abandonment of the V002 output root/package. Baseline and PERF NEXT V001 bytes are never modified. Do not resume a V002 output with V001/baseline code or a different workers/batch configuration.
