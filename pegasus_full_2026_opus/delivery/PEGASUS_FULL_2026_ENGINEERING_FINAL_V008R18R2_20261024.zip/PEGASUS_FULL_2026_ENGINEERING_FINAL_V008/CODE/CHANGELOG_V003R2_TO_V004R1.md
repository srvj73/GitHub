# V003R2 → V004R1

- DECISION: autoridade normativa migrada para a SPEC V004 exata do handoff;
  nenhuma edição da SPEC foi realizada.
- Trades são selados após finish, ordenados localmente por entry_ordinal/idx_global;
  trades e reconciliation passam a scratch comprimido, sem grandes listas no Pipe.
- Sidecars comprimidos 1:1 incluem identidade, sequência, offsets descomprimidos,
  chave completa e SHA256 da linha. JSON permanece autoritativo.
- Quatro processos subordinados fazem o merge e usam o mesmo gzjson em stage.
  O coordinator valida e publica; nenhum helper publica sessão, receipt ou CP.
- Custódia inclui file ID/volume/size/timestamps, SHA antes/consumido/depois,
  SEALED_WAIT, prova de ordem e revalidação após encerramento dos writers.
- Journal exclusivo fecha a janela publicação/CP; rename permanece no mesmo
  volume, sem cópia ou reserialização. Arquivos e diretórios são sincronizados.
- Helpers entram no registro/scan e no agregado de memória; picos de processos
  encerrados permanecem no majorante monotônico do run. Cap continua 48528 MiB.
- Coordinator restaura o atributo Win32 de recebimento de Ctrl+C antes do trabalho,
  após diagnóstico isolado de herança de ignore. Filhos continuam SIG_IGN.
- Batch operacional fixado em 32 e slot único, conforme o prompt V004R1.
  G1 preregistra quatro helpers, heavy=1200, workers G4=4 e threshold=1,5.
- Entry point de mercado desabilitado. Launcher owner e checks V4-A..H preparados;
  nenhum owner G1–G11 foi executado.

EVIDENCE: core/IO/metrics/preflight/SPEC econômica/oracle/gzjson/prefix tracker
permanecem idênticos. C2, C3, C6, grid, geometry, RR, trigger e Rmax não mudaram.
INFERENCE: processos independentes removem a disputa pelo GIL comum entre os
serializers. UNKNOWN: ganho líquido depois dos custos de sidecar, validação e I/O.
