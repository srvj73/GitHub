from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from r1r11_owner_gates import verify_package
from minotauro_v005r1_r23_contract import SPEC_SHA256, runner_identity, sha256_file, write_json_atomic_canonical


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--audit-report", required=True)
    ap.add_argument("--audit-pack", required=True)
    ns = ap.parse_args()

    cfg = json.loads(Path(ns.config).read_text(encoding="utf-8"))
    report = Path(ns.audit_report).resolve()
    audit_pack = Path(ns.audit_pack).resolve()
    pkg = Path(__file__).resolve().parent
    if not report.is_file(): raise RuntimeError("FINAL_AUDIT_REPORT_MISSING")
    if not audit_pack.is_file(): raise RuntimeError("FINAL_AUDIT_PACK_MISSING")
    text = report.read_text(encoding="utf-8", errors="replace")
    pack_sha = sha256_file(audit_pack)
    if not re.search(r"(?m)^R1R11_FINAL_PREPILOT_AUDIT=PASS\s*$", text):
        raise RuntimeError("FINAL_AUDIT_EXACT_PASS_MARKER_MISSING")
    if not re.search(rf"(?m)^R1R11_FINAL_AUDIT_PACK_SHA256={re.escape(pack_sha)}\s*$", text):
        raise RuntimeError("FINAL_AUDIT_PACK_SHA256_BINDING_MISSING_OR_STALE")

    owner = Path(cfg.get("r1r11_owner_gate_receipt", "")).resolve()
    if not owner.is_file(): raise RuntimeError("OWNER_G1_G11_RECEIPT_MISSING")
    o = json.loads(owner.read_text(encoding="utf-8")); package_hash = verify_package()
    if o.get("status") != "PASS" or o.get("package_sha256") != package_hash:
        raise RuntimeError("OWNER_G1_G11_RECEIPT_NOT_FRESH_PASS")
    rh, _ = runner_identity(pkg)
    receipt = {
        "R1R11_FINAL_PREPILOT_AUDIT": "PASS",
        "spec_sha256": SPEC_SHA256,
        "runner_sha256": rh,
        "package_sha256": package_hash,
        "owner_g1_g11_receipt_sha256": sha256_file(owner),
        "audit_pack_path": str(audit_pack),
        "audit_pack_sha256": pack_sha,
        "audit_report_path": str(report),
        "audit_report_sha256": sha256_file(report),
    }
    out = Path(cfg["out_root"]) / "GATES" / "R1R11_FINAL_PREPILOT_AUDIT_RECEIPT.json"
    write_json_atomic_canonical(out, receipt)
    print(json.dumps({"FINAL_AUDIT_BINDING": "PASS", "receipt": str(out),
                      "audit_pack_sha256": pack_sha,
                      "audit_report_sha256": receipt["audit_report_sha256"]}, sort_keys=True))


if __name__ == "__main__":
    main()
