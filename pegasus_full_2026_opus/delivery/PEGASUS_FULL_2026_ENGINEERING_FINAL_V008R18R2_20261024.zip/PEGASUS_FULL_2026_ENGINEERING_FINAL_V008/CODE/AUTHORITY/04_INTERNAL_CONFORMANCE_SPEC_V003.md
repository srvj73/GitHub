# INTERNAL CONFORMANCE — SPEC R1R11 V003 DELTA

- Parent V002 SHA256: `AE6375F5A508638EF5D8B0F87F4B57FA5EF80DEAD2FAE0BA5108179847A207AA`
- V003 SHA256: `552401C071384B921FDF4358EB3CBEB71441E5C8D2500B24183204425CFD91C6`
- Certificate SHA256: `2E5F447BE75D238E583C72272002E34BBF1B0FA3D47478B7B299311AC5433EBB`
- Version metadata change: `V002 -> V003` in title only.
- Normative body change: **C8/G6 only**.
- C1-C7 preserved byte-for-byte outside permitted diff region: YES.
- C9 preserved byte-for-byte outside permitted diff region: YES.
- m-1..m-6 preserved byte-for-byte: YES.
- G7 preserved byte-for-byte: YES.
- G5 strengthened clause preserved byte-for-byte: YES.
- Core changed: NO.
- Economic SPEC changed: NO.
- Grid changed: NO.
- Real data processed: NO.
- Pilot/Run-A authorized: NO.

`DELTA_CONFORMANCE=PASS`
