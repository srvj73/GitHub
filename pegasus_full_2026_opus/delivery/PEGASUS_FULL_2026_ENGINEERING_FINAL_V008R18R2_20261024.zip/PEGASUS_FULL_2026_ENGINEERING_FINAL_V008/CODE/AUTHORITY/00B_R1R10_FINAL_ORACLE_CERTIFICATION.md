# R1R10 FINAL MONOWORK ORACLE CERTIFICATION — LEITURA OBRIGATÓRIA

**Data:** 2026-09-26  
**Escopo:** evidência factual pós-SPEC. Este arquivo NÃO altera a SPEC R1R11 V002.

## Estado final certificado no PC do owner

A R1R10 concluiu o Pilot A e a certificação read-only pós-piloto.

```text
R1R10_POSTPILOT_ORACLE_CERTIFICATION=PASS
PPMR_P1=PASS
PPMR_P2=PASS_BYTE_15_OF_15
PPMR_P3=PASS
PPMR_P4=PASS
PPMR_P5=PASS
PPMR_P6=PASS
R1R10_ORACLE_READY=YES
R1R10_RUN_A_AUTHORIZED=NO
R1R11_MULTIWORK_REQUIRED=YES
```

### Oracle físico

- Pilot A: 3/3 sessões (`2025-01-02`, `2025-01-03`, `2025-01-06`).
- Trades: 1.650 + 12.924 + 14.842 = **29.416**.
- 15/15 arquivos físicos do piloto R1R10 = referência R1R9 **byte a byte**.
- Gate28: PASS, 435 células, mismatch_count=0.
- PRE_RUN_A_GATES: PASS_28_OF_28.
- Native exit: 0.
- Peak memory observado: 10.707,2 MiB.
- Hard cap R1R10: 48.528 MiB; sem excesso.
- Python: 3.14.7.
- zlib compile/runtime: 1.3.1.zlib-ng.
- Processo R1R10 ativo após conclusão: 0.
- Run-A R1R10: **não executado e não autorizado**.

## Dupla identidade correta do config

Estes hashes representam objetos diferentes e ambos são corretos:

```text
CONFIG_FILE_SHA256=0F924E7C05FD3B8C2A17ACEACC69AAED8666DC02948CD1DAC71EABFC8AF662BE
CONFIG_CANONICAL_JSON_SHA256=E47C410DC657402AB878A5DDBE8295A9D92500D105858C54ECBF9256985C5D38
```

O primeiro é o SHA-256 físico de `config.json`; o segundo é o SHA-256 da representação JSON canônica registrada no `RUN_MANIFEST.json`. Não tratar a diferença como drift.

## Hashes finais do oracle

```text
PILOT_RUN_RECEIPT_SHA256=01F52CD12471E68B74F267CC04023343220E4EAA1F41B63A8CFC3FD02FC609A0
PILOT_RUN_MANIFEST_SHA256=D4FAA42463BDD716311AFB89D123D7025BC1EA168C293E56013BC27C735139F3
GATE28_RECEIPT_SHA256=85F50ABB3BF774D58D48FE415EF6C145C75D65E5EB87FD1FF7D8CA979AC5BC7A
PRE_RUN_A_GATE_RECEIPT_SHA256=C6B9B0E89AF107E213A18D19308FBBE596774CEFFE010ABA055FE34E8D86B6EC
PILOT_TELEMETRY_SHA256=D97FFFDC8933C7F9CFB1A91CA4161D146BD7155F8569063B6BE2E4E9F40945B6
```

## Regra para a implementação R1R11

A R1R10 acima é o oracle monowork final para differential testing. A implementação R1R11 deve preservar a SPEC V002 e provar equivalência contra esse oracle. Este certificado NÃO autoriza processamento real de mercado pela R1R11, Pilot A R1R11 ou Run-A.
