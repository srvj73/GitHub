# R1R11 V002 — INTERNAL CONFORMANCE CHECK

SPEC_V001_SHA256=1B0345FB4E2B49444553AF9C2DE6DEBEBA35FEE469C178B1A773A438D2CBACE9
SPEC_V002_SHA256=AE6375F5A508638EF5D8B0F87F4B57FA5EF80DEAD2FAE0BA5108179847A207AA
V002_PREFIX_EQUALS_V001_EXCEPT_TITLE=YES
C1_TO_C9_PRESENT=YES
M1_TO_M6_PRESENT=YES
MERGE_STAGE_AND_GLOBAL_EVENT_TABLES_PRESENT=YES
DOCUMENT_26_CANONICAL_SHA256=181CF8D919149AE032D75A114F405041189B1C72D50B0CD41326D36B63AF7FA2
R_MiB_MEASURED_OWNER_BOOTSTRAP=64704
HARD_CAP_MiB=48528

## Item-by-item

- C1: PASS — stage table, per-stream keys, 3 global fusion rules, 5a/5b separation, post-merge invariants.
- C2: PASS — `r_global=max(r_g)`, all workers feed/ACK through r_global, diagnostics equality/no sum.
- C3: PASS — end-of-line offsets, retained hash state/raw batch, exact r_global prefix, no cross-session batch.
- C4: PASS — compressed scratch, streaming k-way merge, no global events/equity materialization.
- C5: PASS_TEXT — aggregate job memory definitions, 60% target, hard cap 48528, child Win32 probe.
- C6: PASS — seq/generation/CRC, feed digest and counters equality.
- C7: PASS — run_instance, RUN.lock, purge/orphan refusal, SIGINT worker ignore, parent-death detection.
- C8: PASS — G6 coverage manifest, G7 fault injection, G5 worker-count/resume matrix.
- C9: PASS — m-1..m-6 present.

INTERNAL_CONFORMANCE=PASS
IMPLEMENTATION_AUTHORIZED_BY_SPEC_V002=YES
REAL_DATA_PROCESSING_AUTHORIZED=NO
PILOT_A_AUTHORIZED=NO
RUN_A_AUTHORIZED=NO
