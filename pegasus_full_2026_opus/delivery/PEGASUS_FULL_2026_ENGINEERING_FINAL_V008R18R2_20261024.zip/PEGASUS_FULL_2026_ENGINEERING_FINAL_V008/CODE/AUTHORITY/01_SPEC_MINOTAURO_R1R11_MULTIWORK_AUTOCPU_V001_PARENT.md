# SPEC MINOTAURO R1R11 MULTIWORK/AUTOCPU V001

**Data:** 2026-09-26  
**Status:** PRÉ-IMPLEMENTAÇÃO / AUDITORIA INDEPENDENTE OBRIGATÓRIA  
**Parent:** MINOTAURO_PARAMETER_MARKET_DISCOVERY_V005R1_R1R10  
**Parent runner identity:** `189C26D6B05F661A731E94058A0006F7AD8E956B92342854722191AFBA1AA582`  
**Parent gate-suite identity:** `4414304E2CA168218AC811EA4B81A1F88437A28784ECDE0ADF52B066CD93B0C7`  
**SPEC econômica vigente:** `D6D791083870015BF07BF4ABF64718D37F9136FA247D49DB31B4DC8DE2E73747`

## 1. Motivo da R1R11

A R1R10 foi bloqueada antes do Pilot A porque seu executor econômico permanece monowork. O owner revogou operacionalmente a autorização de piloto, preservando o arquivo original como `OWNER_PILOT_AUTHORIZATION.BLOCKED_MONOWORK.json` com SHA-256 `12E4148C1E0CB7E7892148CBD07D87B9E633CC7D8A2824C4CCE12D0B5E19EBC4`.

Estado preservado como evidência, não como autorização de execução:

- S0/S1 bootstrap + preregistro: PASS;
- S2 synthetic: PASS 44/44;
- S3 operational: PASS 34/34;
- S4 lightweight rebind: PASS;
- S5 non-economic gates: PASS;
- S6 geometry parity: PASS, `divergent_rows=0`, `summary_2025_rows=750`;
- S7 seal: PASS 27/27;
- S8: autorização criada e depois bloqueada por violação monowork;
- Pilot A R1R10: **NÃO EXECUTADO**;
- RUN_A R1R10: **NÃO AUTORIZADO**.

A R1R11 deve corrigir exclusivamente a arquitetura de execução pesada. É proibido adaptar economia, causalidade, geometria, seleção ou dados para facilitar a paralelização.

## 2. Regras canônicas vinculantes de execução

A implementação final pesada deve obedecer cumulativamente:

- `MULTIWORK=REQUIRED`;
- `AUTOCPU=REQUIRED`;
- `MONOWORK_FINAL_ACCEPTABLE=NO`;
- `SERIAL_FALLBACK_SILENT=FORBIDDEN`;
- `PARALLELISM_MUST_BE_EFFECTIVE=YES`;
- `MIN_EFFECTIVE_WORKERS=2`;
- `MAX_WORKERS=12`;
- `RAM_TARGET≈60%` da RAM física para scheduling;
- `PROCESS_SCAN_BEFORE_SUBMIT=YES`;
- banner obrigatório com `CPU_LOGICAL`, `REQUESTED_WORKERS`, `GRANTED_WORKERS`, workers externos/concorrentes detectados e razão do grant;
- se uma carga paralelizável não puder receber pelo menos 2 workers, **STOP fail-closed**; não cair silenciosamente para serial;
- checkpoint atômico;
- canonical output single-writer;
- `SAFE_STOP=YES`;
- resume determinístico, inclusive com quantidade diferente de workers após restart;
- nenhum worker pode escrever diretamente em `PHASE_A/sessions/<date>` ou `PILOT_A/sessions/<date>`;
- source read-only;
- lock contra duplicidade da mesma execução;
- progresso ao vivo e ETA no formato operacional já usado pelo projeto;
- execução bruta no PC local/PowerShell 5.1;
- package/runner versionado, hashes e manifests fail-closed.

O `memory_cap_mib=48528` preregistrado na R1R10 é um **hard emergency cap**, não o alvo de scheduling. A R1R11 deve separar explicitamente:

- `RAM_TARGET` de scheduling ≈60%;
- hard cap fail-closed, mantido imutável se reutilizado na nova cadeia.

Qualquer mudança na fórmula ou semântica do hard cap exige preregistro novo e auditoria.

## 3. Invariantes econômicas e causais congeladas

A R1R11 não pode alterar:

- 435 células válidas;
- projeções 38.2 / 50.0 / 61.8;
- trigger 6/8/10/12/14T;
- RR 3/4/5/6/7;
- Rmax OFF/12/14/16/18/20;
- baseline 61.8 / 10T / RR5 / Rmax OFF;
- BUSINESS=`last>0 AND volume>0`;
- decisão em N, execução apenas no primeiro BUSINESS N+1;
- N+1 consumido, sem retry N+2;
- ordem física e `time_msc` preservados;
- BBO causal, inclusive quote rows anteriores ao filtro BUSINESS;
- idade BBO de entrada <=500ms;
- cutoff 18:03 e fechamento causal pós-cutoff;
- sessão nunca cruza fronteira;
- stop FIBO_ORIGIN;
- target ADJACENT_FIBO;
- trailing OFF;
- custos R$0,25 entrada + R$0,25 saída por contrato;
- slippage extra 0T;
- no-lookahead;
- seleção 2025 e isolamento de 2026;
- MacroFibo e geometria já aprovadas.

**Regra preferencial:** `minotauro_v004_core.py`, `minotauro_v004_io.py`, `minotauro_v004_metrics.py` e o contrato econômico devem permanecer byte-idênticos. Se a implementação provar que tocar o core é indispensável, isso é finding material e exige justificativa explícita + reauditoria antes de qualquer piloto.

## 4. Por que a paralelização por pregão é proibida

O runner R1R10 cria cada `SessionEngine` com os arrays do checkpoint vigente:

- `cash`;
- `hwm`;
- `maxdd`;
- `regime_min`;
- `closed_hwm`;
- `closed_maxdd`.

Após cada sessão, esses arrays são substituídos pelos estados finais da sessão e persistidos no checkpoint. Logo, sessões sucessivas formam uma cadeia temporal de estado. Executar 02/01, 03/01 e 06/01 em paralelo com o mesmo estado inicial produziria semântica diferente.

**Conclusão vinculante:** `PARALLEL_UNIT=SESSION` é proibido para a implementação R1R11 enquanto a cadeia de estado permanecer a mesma.

## 5. Unidade paralela autorizável: grupos `(p_idx,t_idx)` dentro da sessão

Os 435 cells formam **15 grupos naturais** de `(projection, trigger)`:

- 3 projeções × 5 triggers = 15 grupos;
- 12 grupos com 30 células;
- 3 grupos com 25 células;
- 145 células por projeção.

O core já declara `SessionEngine` como replay de sessão para um **chosen subset of valid cells** e mantém o estado de episódio (`active`) por `(p_idx,t_idx)`.

Portanto, a unidade atômica proposta é:

`WORK_UNIT = COMPLETE_(p_idx,t_idx)_GROUP`

Regras:

1. nunca dividir um grupo `(p_idx,t_idx)` entre workers;
2. um worker pode receber um ou mais grupos completos;
3. a atribuição de grupos deve ser determinística e registrada;
4. o worker count pode variar 2..12, mas o resultado econômico deve ser independente do worker count;
5. a ordem temporal dos ticks dentro de cada grupo permanece estritamente serial.

## 6. Arquitetura proposta

### 6.1 Coordinator single-writer

Um único processo coordinator é autoridade para:

- abrir/validar config e binding;
- fazer PROCESS_SCAN;
- escolher `GRANTED_WORKERS`;
- ler cada fonte de ticks **uma única vez**;
- manter o source hasher/prefix hasher canônico;
- publicar lotes de TickRecord em shared memory bounded;
- coordenar barriers/acks de workers;
- reunir resultados dos 15 grupos ao fim da sessão;
- reconstruir o `SessionResult` global em ordem canônica;
- executar `_commit_session` uma única vez;
- atualizar checkpoint global;
- emitir telemetry/progress/ETA;
- finalizar outputs e receipts.

Nenhum worker escreve canonical output.

### 6.2 Source broadcaster

É proibido fazer 12 workers relerem o mesmo CSV mensal. Isso multiplicaria I/O/parse e poderia ser mais lento que monowork.

A fonte deve ser parseada uma vez pelo coordinator e distribuída em **shared-memory bounded batches** para todos os workers ativos.

Requisitos:

- ordem de linhas física preservada;
- nenhum sort de ticks;
- nenhuma deduplicação;
- `ordinal`, `date_time`, `time_msc`, bid, ask, last, volume, volume_real e flags preservados;
- BUSINESS deve continuar derivado pela semântica congelada;
- batch size é parâmetro operacional, não econômico;
- memória de batch deve ser bounded e contabilizada;
- slots só podem ser reutilizados depois de ACK de todos os workers relevantes;
- worker atrasado aplica backpressure; perda de batch é proibida;
- source hashing/prefix hashing permanece no coordinator sobre os bytes físicos da fonte, não sobre representação compartilhada.

### 6.3 Workers

Cada worker:

- recebe uma lista determinística de grupos completos `(p_idx,t_idx)`;
- para cada grupo, cria `SessionEngine` com exatamente as células daquele grupo;
- recebe do coordinator os slices corretos de `cash/hwm/maxdd/regime_min/closed_*` derivados do checkpoint global;
- processa todos os batches da sessão, em ordem;
- nunca lê tick futuro fora da sequência recebida;
- ao fim da sessão retorna somente resultados de seus grupos ao coordinator;
- não grava checkpoint, sessão, receipt ou output final;
- não toma decisão de commit.

### 6.4 Estado entre pregões

O estado global só avança depois de todos os 15 grupos do pregão terem sido recebidos, validados, unidos e commitados pelo coordinator.

Fluxo obrigatório:

`GLOBAL_CHECKPOINT[n-1] -> SHARD_SLICES -> PARALLEL_SESSION[n] -> MERGE -> ATOMIC_SESSION_COMMIT -> GLOBAL_CHECKPOINT[n]`

Somente então começa a sessão `n+1`.

Isso preserva causalidade temporal entre pregões e permite paralelismo intrapregão.

## 7. Merge determinístico e byte-equivalência

Este é o principal blocker metodológico da R1R11.

As saídas por sessão precisam permanecer economicamente idênticas e, onde o contrato já exige, byte-idênticas à referência R1R9/R1R10:

- `trades.jsonl.gz`;
- `events.jsonl.gz`;
- `equity.jsonl.gz`;
- `equity_reconciliation.jsonl.gz`;
- `session_receipt.json`.

### 7.1 Proibição de concatenação ingênua

É proibido concatenar “todos os eventos do worker 1, depois worker 2...”. A execução monolítica intercala ações por tick e por estágio do engine.

### 7.2 Contrato do merger

A implementação deve definir, documentar e testar uma `CANONICAL_MERGE_KEY` para cada stream que reproduza a ordem monolítica de emissão sem alterar o conteúdo persistido.

É permitido usar **metadados internos transitórios de merge** que nunca apareçam nos arquivos canônicos, desde que:

- não influenciem decisões econômicas;
- sejam derivados apenas de informações causais já disponíveis naquele ponto;
- sejam removidos antes da serialização canônica;
- sua correção seja provada contra o oracle monowork congelado em testes sintéticos adversariais.

Se não for possível provar uma merge key total e estável para todos os caminhos (STOP, TARGET, CUTOFF, IMMEDIATE_STOP, PENDING_REJECT, crossed BBO, múltiplos sinais, open marks), a arquitetura V001 deve ser reprovada e redesenhada. **Não aceitar equivalência apenas agregada.**

### 7.3 Core congelado

Preferência forte: os metadados de merge devem ser introduzidos no adaptador/executor R1R11, não no core científico. Se o core precisar ser alterado para expor estágio/ordem de emissão, isso deve ser explicitamente classificado como mudança estrutural de risco e auditado como tal.

## 8. AUTOCPU

### 8.1 Processo de decisão

Antes de SUBMIT:

1. medir CPUs lógicas;
2. executar scan de processos;
3. bloquear duplicidade da mesma versão/out_root;
4. contar carga pesada externa relevante;
5. calcular `REQUESTED_WORKERS` com teto 12 e backlog máximo 15 grupos;
6. aplicar grant de CPU e grant de RAM;
7. registrar `GRANTED_WORKERS`;
8. se `GRANTED_WORKERS < 2`, STOP fail-closed.

O algoritmo de grant deve ser determinístico a partir do snapshot registrado e não pode esconder fallback serial.

### 8.2 RAM

- `RAM_TARGET_PERCENT=60` para scheduling;
- hard cap separado;
- memória deve contabilizar coordinator + workers + shared-memory slots controlados pelo job;
- telemetria por boundary de batch e sessão;
- ultrapassar alvo de 60% não pode ser mascarado: registrar pressão e reduzir grant em boundary seguro quando possível;
- ultrapassar hard cap segue regra fail-closed de safe-stop, sem PASS;
- o worker count pode diminuir entre sessões; isso não pode mudar resultados.

## 9. SAFE_STOP, crash e resume

### 9.1 Ctrl+C

- parent/coordinator é dono do SIGINT/KeyboardInterrupt;
- workers não devem competir pelo Ctrl+C;
- ao primeiro Ctrl+C, iniciar safe stop cooperativo;
- nenhum novo batch/session é submetido;
- se a sessão corrente não estiver pronta para commit global, descartar scratch da sessão e manter checkpoint anterior intacto;
- canonical output parcial de sessão é proibido;
- segundo Ctrl+C pode ser abortivo apenas se a política do launcher o declarar explicitamente, preservando o último checkpoint válido.

### 9.2 Crash worker

Qualquer worker perdido, exception, timeout estrutural ou ACK impossível:

- cancela a sessão corrente;
- não promove sessão;
- não altera checkpoint global;
- sai nonzero;
- resume reprocessa a sessão inteira a partir do último checkpoint selado.

### 9.3 Resume

- não depende do mesmo worker count;
- reconstrói shard assignment determinístico;
- revalida todos os hashes/binding/receipts;
- continua pelo primeiro pregão não commitado;
- outputs já commitados são imutáveis;
- orphan/pending seguem recuperação fail-closed já homologada.

## 10. Telemetria/progresso

Banner mínimo obrigatório:

- `MULTIWORK=YES`;
- `AUTOCPU=YES`;
- `CPU_LOGICAL`;
- `PROCESS_SCAN_ACTIVE_MATCHING_RUNNERS`;
- `EXTERNAL_HEAVY_WORKERS`;
- `WORK_GROUPS_TOTAL=15`;
- `REQUESTED_WORKERS`;
- `GRANTED_WORKERS`;
- `MIN_EFFECTIVE_WORKERS=2`;
- `MAX_WORKERS=12`;
- `RAM_TARGET_PERCENT=60`;
- hard cap;
- scheduler/assignment hash;
- shared-memory batch rows/slots;
- SAFE_STOP e RESUME habilitados.

Durante execução:

- worker health;
- batches publicados/acked;
- session atual;
- groups 15/15;
- bytes/rows da fonte;
- memória parent/children/aggregate;
- taxa e ETA;
- `SESSION_COMMIT` somente depois de 15/15 grupos + merge validado.

## 11. Gates de implementação antes de qualquer Pilot A real

### G1 — identidade e escopo

- delta R1R10→R1R11 contém somente executor multiwork, scheduler, merge, telemetria e testes necessários;
- nenhuma mudança econômica/causal/geometria/seleção.

### G2 — core freeze

- core/IO/metrics/preflight byte-idênticos, salvo finding explicitamente aprovado pela auditoria;
- qualquer exceção bloqueia automaticamente o Pilot A até reauditoria.

### G3 — spawn Windows

- multiprocessing com método compatível com Windows (`spawn`);
- import-safe;
- nenhuma execução recursiva de main;
- smoke real em PowerShell 5.1.

### G4 — effective multiwork

Em teste sintético suficientemente pesado:

- `GRANTED_WORKERS>=2`;
- pelo menos 2 workers simultaneamente ativos;
- evidência de overlap temporal real;
- nenhum fallback serial silencioso;
- scheduler mantém backlog alimentado quando possível.

### G5 — worker-count invariance

Mesma fixture executada com workers 2, 3, 4, 8 e 12 (quando disponíveis):

- outputs canônicos byte-idênticos;
- checkpoints byte-idênticos;
- receipts econômicos idênticos;
- apenas telemetria/scheduler metadata pode variar.

### G6 — monowork oracle differential

O parent R1R10 monowork é **oracle de teste**, não executor final.

Fixtures adversariais devem cobrir:

- BUY/SELL;
- STOP/TARGET/CUTOFF/IMMEDIATE_STOP;
- N/N+1 mesmo ms;
- BBO stale/crossed;
- pending reject;
- busy-cell;
- múltiplos sinais;
- RR/Rmax boundaries;
- 435 células;
- todos os 15 `(p,t)` groups;
- vários pregões sequenciais com estado cumulativo.

R1R11 multiwork vs R1R10 oracle: byte equivalence obrigatória para outputs econômicos.

### G7 — safe-stop/resume differential

Interromper em:

- meio de batch;
- final de batch;
- antes do merge;
- durante scratch merge;
- após merge antes do atomic commit;
- após commit antes do checkpoint seguinte;
- memória target pressure;
- hard-cap boundary.

Após resume: árvore econômica idêntica à execução limpa.

### G8 — source single-pass

Provar mecanicamente que cada arquivo fonte mensal é aberto/parseado economicamente pelo coordinator, e não uma vez por worker. Hash físico final deve continuar igual ao binding.

### G9 — single-writer

Provar que workers não têm código/caminho que publique em canonical session dirs/checkpoint/receipts.

### G10 — resource policy

- process scan PASS;
- AUTOCPU PASS;
- target RAM ~60%;
- hard cap separado;
- min 2/max 12;
- workers granted e efetivos registrados.

### G11 — package/full suite

- py_compile;
- synthetic suite;
- operational suite;
- launcher selftest;
- manifest 100%;
- no unmanifested code;
- PowerShell 5.1 runtime gate.

## 12. Pilot A R1R11

Pilot A só pode ocorrer após:

1. implementação fechada;
2. todos os gates locais PASS;
3. auditoria independente pré-piloto PASS;
4. owner authorization específica R1R11.

Pilot obrigatório:

- sessões 2025-01-02, 2025-01-03, 2025-01-06;
- 435 células;
- multiwork efetivo >=2;
- AUTOCPU;
- worker assignment registrado;
- mesma geometria e binding autenticados;
- comparação contra os 15 arquivos R1R9/R1R10 previamente auditados;
- Gate28 mismatch=0;
- outputs byte-idênticos quando aplicável;
- nenhuma autorização RUN_A automática.

## 13. RUN_A

RUN_A continua proibido até pós-piloto mecânico e gate próprio.

Para RUN_A, exigir novamente:

- MULTIWORK efetivo;
- AUTOCPU;
- 250 sessões;
- ordem temporal de commits estritamente crescente;
- same config/binding/spec/runner identities;
- resume determinístico;
- finalização econômica lossless;
- sem fallback serial.

## 14. Findings que bloqueiam implementação desta SPEC

A auditoria independente deve responder explicitamente:

1. `GROUP_SHARDING_(p,t)_SEMANTICALLY_SAFE` = YES/NO;
2. `SOURCE_SINGLE_PARSE_SHARED_MEMORY_ARCHITECTURE_SOUND` = YES/NO;
3. `CANONICAL_MERGE_BYTE_EQUIVALENCE_PROVABLE` = YES/NO;
4. `CORE_CAN_REMAIN_FROZEN` = YES/NO;
5. `AUTOCPU_POLICY_COMPLIANT` = YES/NO;
6. `SAFE_STOP_RESUME_PROTOCOL_SOUND` = YES/NO;
7. `FALSE_PASS_PATHS` = count;
8. `IMPLEMENTATION_AUTHORIZED` = YES/NO.

Qualquer NO nos itens 1–6 ou qualquer caminho de falso PASS material => `IMPLEMENTATION_AUTHORIZED=NO`.

## 15. Estado ao final da SPEC V001

```text
R1R10_EXECUTION_STATUS=BLOCKED_MONOWORK
R1R10_PILOT_EXECUTED=NO
R1R10_RUN_A_AUTHORIZED=NO
R1R11_SPEC_STATUS=READY_FOR_INDEPENDENT_AUDIT
R1R11_CODE_WRITTEN=NO
R1R11_REAL_DATA_PROCESSED=NO
NEXT_GATE=INDEPENDENT_PREIMPLEMENTATION_AUDIT
```
