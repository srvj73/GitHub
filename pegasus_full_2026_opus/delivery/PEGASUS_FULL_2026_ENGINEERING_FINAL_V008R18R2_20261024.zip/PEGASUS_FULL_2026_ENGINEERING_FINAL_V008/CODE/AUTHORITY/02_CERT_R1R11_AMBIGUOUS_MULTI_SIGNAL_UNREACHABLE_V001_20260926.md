# CERTIFICADO FORMAL DE INALCANÇABILIDADE — `AMBIGUOUS_MULTI_SIGNAL`

**Documento:** `CERT_R1R11_AMBIGUOUS_MULTI_SIGNAL_UNREACHABLE_V001_20260926`  
**Data:** 2026-09-26  
**Status:** NORMATIVO PARA C8/G6 DA SPEC V003, PENDENTE CONFIRMAÇÃO INDEPENDENTE DO DELTA  
**Escopo:** exclusivamente a classificação `STRUCTURALLY_UNREACHABLE` do evento `AMBIGUOUS_MULTI_SIGNAL`.

## 1. Bindings imutáveis

- Core congelado SHA256: `97F8F957300D37966913C872B7F04E498D30B0CFF68180993DB80D314B900827`.
- SPEC econômica congelada SHA256: `D6D791083870015BF07BF4ABF64718D37F9136FA247D49DB31B4DC8DE2E73747`.
- Grid canônico SHA256: `A91A923FB38C9BFA85E157AF494B26B3ED5EBF1843F531259820CD345DCD14B1`.
- Células válidas: `435`.
- Grupos `(projection, trigger)`: `15`.
- RR mínimo entre as células válidas: `3`.
- Representação da razão no caminho canônico: inteira, com `D = 10^12`.
- Geometria: linhas distintas, ordenadas e deduplicadas; target = linha imediatamente adjacente na direção do candidato.

Qualquer divergência em um desses bindings torna este certificado inaplicável e força `G6=FAIL` até nova auditoria.

## 2. Ramo certificado

O core contém o evento `AMBIGUOUS_MULTI_SIGNAL`, emitido somente quando, para a **mesma célula**, a lista `candidates` derivada de `eligible[idx]` possui cardinalidade maior que 1.

Cada `eligible` nasce vazio em cada chamada de `_process_episodes`. Cada `idx` pertence a um único grupo `(p_idx,t_idx)`. Cada origem ativa do grupo é percorrida no máximo uma vez por chamada. Um candidato só entra em `eligible[idx]` quando, cumulativamente:

1. a direção é não nula;
2. existe target imediatamente adjacente na direção do movimento;
3. `reward > 0`;
4. o filtro RR passa;
5. o filtro Rmax passa, quando habilitado.

Trigger e Rmax apenas removem candidatos. Não criam um segundo candidato.

## 3. Teorema de cardinalidade

**Teorema.** Sob os bindings da seção 1, para toda célula válida e toda chamada causal permitida do core:

`len(eligible[idx]) <= 1`.

### Prova

Considere o preço corrente `x` e as linhas canônicas distintas e ordenadas.

### Caso A — `L < x < U`, com `L` e `U` adjacentes

Qualquer origem abaixo de `L` possui seu target adjacente em preço `<= L < x`; portanto o reward na direção candidata é não positivo e ela é rejeitada antes de entrar em `eligible`.

Qualquer origem acima de `U` possui seu target adjacente em preço `>= U > x`; portanto o reward na direção candidata também é não positivo.

Assim, antes de RR/Rmax, no máximo duas origens podem restar: `L` e `U`, em direções opostas.

Defina:

- `a = x - L > 0`;
- `b = U - x > 0`;
- `D = 10^12`;
- `r >= 3`, RR da mesma célula.

Para `L`, risco = `a` e reward = `b`. Para `U`, risco = `b` e reward = `a`.

Para ambos passarem simultaneamente pelo filtro RR exato do core, seriam necessárias as duas desigualdades:

`b*D + a >= r*a*D`

`a*D + b >= r*b*D`

Somando:

`(D + 1)(a + b) >= r*D*(a + b)`.

Como `a+b > 0`:

`D + 1 >= r*D`.

Porém, para `r >= 3` e `D = 10^12`:

`r*D - (D + 1) >= 1,999,999,999,999 > 0`.

Contradição. Logo as duas origens adjacentes não podem ser simultaneamente elegíveis para a mesma célula.

### Caso B — `x` coincide com uma linha

A origem coincidente tem direção zero. As origens mais distantes têm target adjacente já alcançado/ultrapassado, resultando em reward não positivo. Não surgem dois candidatos elegíveis.

### Caso C — `x` fora dos extremos

Não existem duas origens com targets adjacentes ainda à frente, na direção requerida, capazes de formar dois candidatos elegíveis para a mesma célula.

Portanto, em todos os casos, `len(eligible[idx]) <= 1`. QED.

## 4. Robustez da prova ao restante do domínio causal

A prova continua válida sob:

- múltiplas linhas cruzadas, gaps e saltos: o core avalia o preço corrente e targets adjacentes; origens distantes têm reward não positivo;
- arredondamento/deduplicação: o domínio aceito contém linhas distintas e ordenadas;
- qualquer subconjunto de `active`: subconjunto não aumenta a cardinalidade máxima;
- trigger e Rmax, inclusive OFF/tolerâncias: apenas restringem;
- BBO stale/crossed: não altera a construção de candidatos de episódio a partir do preço corrente;
- múltiplos grupos: sinais de células distintas não são acumulados no mesmo `eligible[idx]`;
- pending, posição aberta, N→N+1 e immediate stop: candidatos não são transportados entre chamadas;
- cutoff, sessão e resume: após latch não há criação de novos episódios; estados de caixa/equity não alteram linhas, RR ou cardinalidade de candidatos.

## 5. Disposição G6

Para a SPEC V003, e somente enquanto todos os bindings da seção 1 permanecerem exatos:

`AMBIGUOUS_MULTI_SIGNAL = STRUCTURALLY_UNREACHABLE`.

Esta classificação substitui **somente** a exigência de ocorrência causal desse evento em G6. O evento permanece no core e na tabela de merge C1.

Uma ocorrência causal real de `AMBIGUOUS_MULTI_SIGNAL` sob identidades declaradas compatíveis contradiz este certificado e produz `G6=FAIL`, obrigando nova auditoria.

Todos os demais nomes de evento continuam exigindo classificação `COVERED`, salvo futura prova específica e aprovação independente própria. Ausência de ocorrência sem certificado válido permanece `G6=FAIL`.
