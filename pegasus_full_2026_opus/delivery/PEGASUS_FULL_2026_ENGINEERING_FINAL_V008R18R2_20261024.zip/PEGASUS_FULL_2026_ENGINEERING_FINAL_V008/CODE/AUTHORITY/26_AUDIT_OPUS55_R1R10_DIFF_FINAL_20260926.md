```text
OPUS55_R1R10_DIFF_FINAL_AUDIT=PASS
PACKAGE_INTEGRITY=PASS
PARENT_R1R9_IDENTITY=PASS
CHILD_R1R10_IDENTITY=PASS
PATCH_REPRODUCTION=PASS
FROZEN_FILES_9_OF_9=PASS
RUNNER_IDENTITY=PASS
GATE_SUITE_IDENTITY=PASS
ECONOMIC_SEMANTICS_CHANGED=NO
ANNUAL_TRADES_ACCUMULATION_REMOVED=PASS
RESUME_FULL_TRADES_RELOAD_REMOVED=PASS
STREAMING_METRICS_EQUIVALENCE=PASS
STREAMING_TRADES_CSV_EQUIVALENCE=PASS
MEMORY_TELEMETRY_STATIC_DESIGN=PASS
MEMORY_CAP_FAIL_CLOSED_STATIC_DESIGN=PASS
WIN32_MEMORY_PROBE_STATIC_ASSESSMENT=PASS
WINDOWS_PS51_STREAMING_STATIC_ASSESSMENT=PASS
PS51_CROSS_STREAM_ORDERING_DISPOSITION=NONBLOCKING_DIAGNOSTIC
INTRASESSION_OOM_RESIDUAL=ACCEPTABLE_FOR_CONTROLLED_PILOT
TELEMETRY_INTEGRITY_BINDING_DISPOSITION=ADEQUATE
MEMORY_CAP_PREREGISTRATION_POLICY=R_MiB=floor(Win32_ComputerSystem.TotalPhysicalMemory/1048576) medido no PC do owner antes do primeiro comando R1R10 no out_root novo; memory_cap_mib=max(4096,min(floor(0.85*R_MiB),R_MiB-6144)); registrar R_MiB, fórmula, cap, SHA256 do config.json e hash canônico do config (canonical_json_hash) em <out_root>\LOGS\R1R10_MEMORY_CAP_PREREGISTRATION.txt antes do rebind; valor único e imutável para pilot-a e run-a (mesmo config_sha256 nos dois checkpoints); proibido ajustar após observar telemetria
CRITICAL_FINDINGS=0
MAJOR_FINDINGS=0
MINOR_FINDINGS=4
CODE_CORRECTION_REQUIRED_BEFORE_OWNER_RUNTIME=NO
OWNER_WINDOWS_VALIDATION_AUTHORIZED=YES
FULL_PREPILOT_CHAIN_AUTHORIZED_AFTER_LOCAL_WINDOWS_PASS=YES
CONDITIONAL_PILOT_AUTHORIZED_AFTER_PREPILOT_PASS=YES
MT5_GEOMETRY_OUTPUT_REUSE_IF_INPUT_SHA_MATCHES=YES
INTERMEDIATE_EXTERNAL_AUDIT_BEFORE_PILOT_REQUIRED=NO
RUN_A_AUTHORIZED=NO
OWNER_RUN_A_AUTHORIZATION_FILE_CREATION_AUTHORIZED=NO
POSTPILOT_EXTERNAL_AUDIT_REQUIRED=NO
POSTPILOT_MECHANICAL_PROMOTION_RULE=RUN_A promovível sem auditoria externa se e somente se TODOS PP1–PP9 (§9) forem PASS: PP1 identidades R1R10 (runner 189C26D6…, gate 4414304E…, spec D6D79108…) em todos os receipts e hash-chain 27→28 íntegra; PP2 15 arquivos de sessão byte-idênticos a 05_R1R9_PILOT_REFERENCE_HASHES_SHA256.txt + GATE28 PASS mismatch_count=0 + PRE_RUN_A PASS_28_OF_28 + sem .pending/_orphan/INVALID_PHASE; PP3 autoteste PS5.1 16/16 + R1R10_LAUNCHER_SELFTEST=PASS em transcript PSVersion 5.1 e gate operacional 34/34 com os 2 testes Win32 ok; PP4 telemetria PILOT_A íntegra (JSON V1, probe WIN32_*, cap_mib=preregistrado, 1 SESSION_COMMIT por sessão, conferência linha a linha com MEMORY_TELEMETRY do transcript, SHA256 registrado); PP5 max(observed_peak_bytes)<=cap_bytes e zero MEMORY_CAP_SAFE_STOP no piloto; PP6 progresso ao vivo evidenciado (linhas RUN_PROGRESS com sufixo MEM_* no trecho pilot-a + checks LIVE do autoteste); PP7 config_sha256 do checkpoint PILOT_A = hash preregistrado; PP8 nenhum marcador adverso (RUN_BLOCKED, Traceback, TICK_PREFIX_DRIFT, RESUME_HASH_MISMATCH, INVALID_PHASE, MEMORY_CAP_SAFE_STOP); PP9 mesma máquina (R_MiB igual). Qualquer falha → RUN_A bloqueado e escalonamento. RUN_A então sob o protocolo em execução §9.3.
REQUIRED_CORRECTIONS=NONE
NEXT_ACTION=Ratificar este veredito numa instância Opus nova e independente sobre o mesmo handoff (esta execução ocorreu na mesma conversa do builder e não satisfaz a regra de independência do 00_README); ratificado sem correção de código, executar no PC do owner, em out_root novo, a cadeia mecânica §8 (preregistro do cap → synthetic/autoteste PS5.1 → operational/Win32 → rebind → gates 1–27 → geometria com reuso MT5 condicionado → seal 27/27 → autorização de piloto → Pilot A + Gate 28) e aplicar a regra PP1–PP9 antes de qualquer autorização de RUN_A.
```

---

# AUDITORIA R1R10 — DIFF R1R9 → R1R10 (consolidada)

## 0. Condição de validade — independência NÃO atendida por esta execução

> **Declaração obrigatória.** Esta auditoria foi executada **na mesma conversa em que eu, Opus 5.5, atuei como builder da R1R10**. O `00_README_START_HERE.md` e o `01_PROMPT…` exigem **nova instância/conversa**.
>
> - Toda a verificação abaixo foi refeita fisicamente a partir dos ZIPs do handoff, de forma adversarial contra o meu próprio código.
> - Mesmo assim, **não sou auditor independente** deste diff, e nenhuma disciplina de método elimina esse conflito.
>
> **Consequência prática:**
> - O veredito técnico é completo e as autorizações `YES` do bloco são tecnicamente fundamentadas.
> - Porém a **eficácia** dessas autorizações depende de **uma ratificação** por instância independente sobre o mesmo handoff. É exatamente o que a própria regra do handoff determina.
> - Não se trata de auditoria adicional por hábito: é a auditoria independente que o handoff já previa, ainda não realizada.
>
> **Se o owner optar por não ratificar agora**, a mesma auditoria independente passa a ser obrigatória **após o piloto e antes do RUN_A**, e `POSTPILOT_EXTERNAL_AUDIT_REQUIRED` passa a `YES`. Em ambos os casos, o total é **uma** chamada externa.

---

## 1. Integridade, parent/child, patch e identidades (A)

| Verificação | Resultado |
|---|---|
| `06_SHA256SUMS.txt` do handoff | 26/26 OK |
| ZIP R1R9 | `00D04BE1…685C2C4B` ✔; CRC OK; 47 entradas; 0 duplicatas; 0 paths inseguros |
| ZIP R1R10 | `6C6F35B8…23E1CBE` ✔; CRC OK; 60 entradas; 0 duplicatas; 0 paths inseguros |
| Manifesto interno R1R10 | 59/59; 0 faltantes; 0 não manifestados |
| Patch do handoff = patch dentro do child | idêntico |
| `patch -p1` sobre R1R9 fresco | sem `.rej`/`.orig`. Diferenças remanescentes: apenas `DIFF_…patch`, `IMPLEMENTATION_RECEIPT_R1R10.json` e `SHA256SUMS.txt` (as 3 exclusões declaradas) ✔ |
| Congelados 9/9 (R1R9 = R1R10 = esperado) | PASS |
| Hash das definições importadas do core | `5605BE87…` ✔ |
| Runner identity, recalculada por **reimplementação própria** (AST dos manifests + JSON canônico) | `189C26D6…BA1AA582`. Confere com o receipt, e o manifest confere item a item |
| Gate-suite identity | `4414304E…CD93B0C7` ✔ |
| Sanidade do algoritmo sobre o parent | reproduz `17436F2A…` / `302AA65B…` da R1R9 ✔ |
| Código sem manifest | nenhum (`*.py`, `*.ps1`, `MQL5/*.mq5`). Os scripts de evidência estão como `.txt` |

---

## 2. Semântica congelada (B)

**Delta de código:**
- **Modificados:**
  - `minotauro_v004_runner.py`
  - `minotauro_v005r1_r23_outputs.py`
  - `minotauro_v005r1_r23_contract.py`
  - `Minotauro_Launcher_Common.ps1`
  - `RUN_PHASE.ps1`
  - `RUN_SYNTHETIC_GATES.ps1`
  - `test_…_operational.py`
  - `config.example.json`
- **Novos:**
  - `minotauro_v005r1_r1r10_memory.py`
  - `R1R10_LAUNCHER_SELFTEST.ps1`
- Todos foram lidos integralmente.

**Nenhuma alteração** em:
- sinal;
- causalidade N→N+1;
- BBO/idade;
- stop/target;
- cutoff e sua validação no commit (o bloco `CUTOFF_PREFLIGHT_REPLAY_MISMATCH` ficou intacto);
- custos, grid, RR, Rmax;
- seleção (`select_2025`, `selection_diagnostics`);
- geometria;
- métricas;
- gates econômicos (`gates.py` congelado);
- checkpoint (`REQUIRED_CHECKPOINT_KEYS`, hash de conteúdo, `config_sha256` e resume por prefix-hash, todos inalterados).

`metrics.py` é byte-idêntico.

**Os únicos pontos que tocam outputs:**
1. `finalize_phase_a` passa a gerar o CSV por streaming. A equivalência está provada no §3.
2. Os 5 artefatos por sessão continuam sendo gerados pelo mesmo `_commit_session`, com a única diferença de que o sink foi removido.

→ `ECONOMIC_SEMANTICS_CHANGED=NO`.

---

## 3. M-1 — memória cumulativa (C)

**Estrutura:**
- **Commit sem sink global:**
  - não existe mais `trades.extend`;
  - `_commit_session` perdeu o parâmetro de lista;
  - há exatamente 3 call sites, todos seguidos de `res = None; eng = None`.
- **Resume:** `_verify_committed_trades_present` faz apenas a checagem de existência, com o mesmo erro `COMMITTED_TRADES_MISSING`.
- **Finalize:**
  - `aggregate_phase(cells, iter_committed_trades(...), maxdd)`;
  - `aggregate_phase` itera uma única vez e é invariante à ordem: somas, `set` e `sorted`.

**CSV:**
- Duas passagens: união de campos em stream e, depois, uma sessão por vez.
- A verificação `trade.session == diretório` garante que a ordenação estável por sessão seja igual à ordenação estável global da R1R9.
  - A chave global é `(session, int(entry_ordinal), cell_id)`.
  - Os empates preservam a ordem física do arquivo, que é igual à ordem de `res.trades`.
- A contagem de linhas de cada sessão é conferida contra `session_receipt.trades`. Isso barra, de forma fail-closed, truncamento ou duplicação.

**Round-trip JSON (em memória R1R9 × persistido R1R10):**
- **Chaves:**
  - os dicts aninhados do engine (`n_identity`, `n1_identity`) têm apenas chaves `str`;
  - não há dict com chave `int`, cujo `sort_keys` poderia divergir após o round-trip.
- **Valores:**
  - são `int`, `str`, `float`, `bool`, `None` ou `list`;
  - qualquer tipo numpy não serializável já quebraria o `gzjson` no commit, igualmente nas duas versões.
- **Floats:** o `repr` é estável no round-trip.

→ A saída é byte-equivalente para o esquema real.

**Diferencial:**
1. **Harness do builder**, reexecutado a partir dos ZIPs do handoff, sem depender do meu ambiente de build:
   - R1R10 limpo = parada por teto na sessão 100 + resume = Ctrl+C na sessão 100 + resume, com 1.770/1.770 arquivos idênticos;
   - R1R9 × R1R10 diferem somente em `RUNNER_HASH.txt`, `RUN_MANIFEST.json`, `SELECTION_FREEZE.json` e `SHA256SUMS.txt`, todos vinculados à identidade;
   - piloto de 435 células: 15/15 arquivos idênticos.
2. **Fraqueza do harness original:** só gera BUY com saídas CUTOFF/STOP e usa 3 células.
3. **Variante de auditoria** (gerador diferente, escrito nesta auditoria): passeio aleatório semeado de 90 ticks por sessão, 21 células.
   - Produziu **8.633 trades**: STOP 5.674, CUTOFF 2.679, IMMEDIATE_STOP 156, TARGET 124; BUY 4.452 e SELL 4.181; 46 colunas no CSV.
   - Resultados idênticos aos do item 1: R1R9 × R1R10 somente com os 4 arquivos de identidade; parada por teto + resume e Ctrl+C + resume iguais ao limpo.
   - Piloto de 435 células: 15/15 idênticos.

**Caminhos silenciosos:**
- Não há truncamento (contagem por receipt), duplicação (sessões duplicadas rejeitadas; `SESSION_ALREADY_EXISTS` inalterado) nem reordenação.
- Não há falso PASS: as linhas PASS só são impressas depois da última fronteira segura.

---

## 4. Telemetria e teto (D)

| Item | Avaliação |
|---|---|
| Layout `PROCESS_MEMORY_COUNTERS_EX` | 2×`uint32` + 9×`size_t` na ordem oficial; 80 bytes em x64 com offsets 8/16/56/64/72 corretos. DWORD fixado em 32 bits, portável ✔ |
| API | `K32GetProcessMemoryInfo` (Kernel32) com fallback `psapi.GetProcessMemoryInfo`; pseudo-handle de `GetCurrentProcess`; `cb=sizeof(EX)`; `BOOL`→`c_int`; `use_last_error` ✔ |
| Semântica | Conforme a documentação Microsoft: WorkingSet é o atual; PeakWorkingSet é o pico; `PrivateUsage` = commit charge atual; `PeakPagefileUsage` = pico do commit charge na vida do processo |
| Métrica do teto | Máximo entre WS atual, pico de WS, commit atual e pico de commit. Conservadora, porque o commit cobre a memória paginada. Os picos são mantidos pelo SO, então a fronteira vê o **pico real intra-sessão**, não uma amostra ✔ |
| Persistência | append + `flush` + `os.fsync` por linha; arquivo fechado a cada escrita. Auditável após crash ✔ |
| Falha de probe | Em `PROGRESS`: reportada e adiada, sem abortar o engine. Em fronteira: `MemoryProbeError` → exit 2, com checkpoint já consistente ✔ |
| Teto excedido | Linha `MEMORY_CAP_SAFE_STOP` + marcador `… pass=NO` → exit 3 (único; 0/1/2/130 continuam distintos). O `RUN_PHASE` mapeia para `MEMORY_CAP_SAFE_STOP=YES` / `PASS=NO` / `exit 3`, e o `RUN_GATE28_PILOT` faz `throw` ✔ |
| Fronteiras | `RUN_START`; `SESSION_COMMIT` (após checkpoint atômico); `MONTH_VERIFIED` (após o checkpoint `verified_months`); `PRE_PILOT_RECEIPT` (antes do receipt PASS); `PRE_FINALIZE`; `POST_FINALIZE` (antes de `SHA256SUMS` e do PASS, de modo que o resume re-finaliza de forma idêntica). O resume a partir de cada fronteira reproduz a árvore limpa, conferido por teste e pela variante ✔ |

### Riscos residuais — disposições

1. **OOM intra-sessão.** Classificado como **aceitável para o piloto controlado**.
   - O engine congelado, as 3 sessões e os dados são os mesmos do piloto R1R9, que concluiu no mesmo PC.
   - A R1R10 retém **estritamente menos**: remove a lista cumulativa e libera `res`/`eng`.
   - No `run-a`, o conjunto retido por sessão é **subconjunto** do retido no piloto para a mesma sessão. Isso está verificado em `_update_hwm_dd`: com integral, `persist = integral OR new_hwm OR new_regime_min`.
   - Um OOM ou `MemoryError` intra-sessão termina **sem commit**, e o resume parte do checkpoint. É um risco de disponibilidade, não de integridade. Está coberto pelo protocolo §9.3.
2. **`peak_private_bytes` = `PeakPagefileUsage`.** Tecnicamente correto: é o pico do commit charge, que é memória privada comprometida.
   - Classificado como nomenclatura aceitável, sem correção.
   - A regra PP4 fixa essa definição para a verificação.
3. **Telemetria fora de `PHASE_A`/`PILOT_A`, sem hash em receipt.** **ADEQUADO** para o threat model do projeto: owner confiável e risco de erro acidental, não de falsificação. O mesmo padrão já vale para os transcripts em `LOGS`, usados como evidência na auditoria 25.
   - Fechamento procedimental (PP4):
     - conferência linha a linha de cada `SESSION_COMMIT` com a linha `MEMORY_TELEMETRY` correspondente no transcript (dois canais independentes do mesmo processo);
     - SHA256 do arquivo registrado ao empacotar a evidência.
4. **Cap baixo parando em `RUN_START`.** **Risco operacional (m-1)**, não defeito de integridade.
   - O checkpoint da fase é criado antes da fronteira `RUN_START`. Um cap abaixo da memória-base do processo produziria um checkpoint vazio, vinculado a um `config_sha256` sem progresso possível.
   - Com a política abaixo (piso de 4096 MiB, várias ordens acima da base do Python+numpy), o cenário só ocorre por violação da política. Nesse caso, a regra é parar e escalonar; não se aceita edição manual.
   - O mesmo raciocínio cobre o laço teórico em `POST_FINALIZE`.
   - Mudar o cap **entre** o piloto concluído e o `run-a` não afeta nenhum receipt. Ainda assim, a política o proíbe, para evitar ajuste após ver dados.
5. **Política de preregistro.** Ver o bloco. Fundamentos:
   - A fonte é a RAM física medida pelo CIM do Windows no próprio PC. Nenhum valor foi inventado.
   - A folga é o maior valor entre 15% e 6 GiB, reservada para SO, MT5 e cache de arquivos.
   - O piso de 4096 MiB elimina paradas em `RUN_START`.
   - É um valor único, registrado antes do rebind e imutável: o `config_sha256` idêntico nos dois checkpoints prova a imutabilidade.
   - Exemplos: 16 GiB → 10.240 MiB; 32 GiB → 26.624 MiB; 64 GiB → 55.705 MiB.

---

## 5. Windows PowerShell 5.1 / streaming ao vivo (E)

| Ponto | Decisão |
|---|---|
| `2>&1 \| ForEach-Object` | O downstream é um cmdlet de processamento, não `Out-Host`/`Out-Default`, que foi a causa da falha na R1R8. Portanto o stdout nativo é sempre redirecionado ao pipeline e processado linha a linha ✔ |
| stderr como `ErrorRecord` | Cada linha vira um `ErrorRecord` (PowerShell issue #4002). É convertida por `Exception.Message` (fallback `ToString()`) e recebe o prefixo `[stderr] ` ✔ |
| EAP local `Continue` | A variável fica no escopo da função e é restaurada no `finally`. É a mesma mitigação que a R1R9 usou com `2> arquivo` e que foi **comprovada no PS 5.1 do owner** ✔ |
| Autoridade do exit | Sentinela `$global:LASTEXITCODE=$null` antes; leitura logo após o pipeline. Se continuar nulo → `throw`. O texto nunca é analisado ✔ |
| `python -u` | stdout/stderr não-bufferizados (documentação Python). Só afeta buffering ✔ |
| `Write-Host` + `Start-Transcript` | Canal comprovado nos smokes R1R7–R1R9 ✔ |
| Transcript aninhado | Helper inalterado; o autoteste cobre estado inválido, posse, chamada aninhada e stop no-op/owner ✔ |
| Ordenação cruzada stdout↔stderr | Existe no PS 5.1 (issue #5424). É **não bloqueante e apenas diagnóstica**, porque PASS/FAIL depende só do exit code. A ordem dentro de cada stream é preservada. **Regra:** nenhum verificador pode usar a ordem relativa entre linhas de stdout e `[stderr]` |
| Autoteste | Roda como filho do mesmo `powershell.exe`, antes do gate sintético. Faz 16 checks fail-closed. O controle negativo com a semântica de spool da R1R9 falha em `LIVE_STDOUT`, então o teste discrimina |
| Suficiência | **Sim.** Se passar no PC do owner (PS 5.1 + Python 3.14 final), a prova primária do m-c fica estabelecida mecanicamente. Se falhar, a cadeia bloqueia antes de qualquer PASS, e esse falso negativo é seguro |

**Riscos empíricos, que só o runtime decide, todos fail-closed:**
- o formato exato de `Exception.Message` no PS 5.1;
- o encaminhamento do `Write-Host` do processo filho para o stdout redirecionado.

---

## 6. Testes e evidência (F)

**Reexecutei a partir do child do handoff:**
- 44/44 sintéticos + 34/34 operacionais em **Python 3.11.15 e 3.14.0rc2**;
- os comandos congelados `gates.py synthetic` (sem config, sem receipt) e `operational` (num `out_root` temporário descartado): PASS, com as identidades R1R10;
- o autoteste em pwsh 7.4.6, apenas como evidência secundária: 16/16.

**Avaliação da evidência de terceiros:**
- **ChatGPT, Python 3.13.5:** coerente, mas é evidência auxiliar.
- **Mutation testing 10/10:** não foi usado como fundamento, porque é evidência do builder, que sou eu.
- **Diferencial:** o harness do builder foi auditado (ver §3) e complementado por uma variante com gerador diferente.
- **Pendente:** Python 3.14 **final** no PC, provado pelos gates locais (PP3).

---

## 7. Findings

| # | Sev. | Finding | Disposição |
|---|---|---|---|
| m-1 | MINOR | Checkpoint da fase criado antes da fronteira `RUN_START`. Um cap abaixo da memória-base prende a fase sem progresso, e o laço teórico em `POST_FINALIZE` é análogo. | Sem correção. A política (piso de 4096 MiB) torna o cenário impossível sem violá-la; se ocorrer: parar e escalonar. |
| m-2 | MINOR | Telemetria não vinculada por hash a receipt ou manifest. | ADEQUADO com o fechamento procedimental PP4 (conferência cruzada com o transcript + SHA256 no empacotamento). |
| m-3 | MINOR | A aprovação do autoteste do launcher não entra no `SYNTHETIC_GATES_RECEIPT` (`gates.py` congelado), e uma chamada direta ao Python o contorna. Na R1R9 já era assim com o `py_compile`. | PP3 exige a evidência no **mesmo transcript** que imprime o JSON do receipt sintético vinculado ao seal. |
| m-4 | MINOR | Resíduo do m-c: o `pilot-reconcile` do `gates.py` congelado (~22 min na R1R9) não imprime progresso. O streaming ao vivo não cria linhas que não existem. | Não bloqueante e só afeta o piloto. O progresso ao vivo deve ser avaliado na etapa `pilot-a`/`run-a` (runner). |

**Observações (não contadas):**
- Ordenação cruzada stdout/stderr: diagnóstica.
- `peak_private_bytes`: nomenclatura aceitável.
- `rgz` virou código morto no runner (cosmético).
- O-5 (Ctrl+C sob redirecionamento) continua não exercitado. O protocolo de commit é seguro contra kill em qualquer ponto: `.pending` → `os.replace` → checkpoint atômico; o resíduo cai em orphan.
- **O gate operacional exige a pasta do pacote limpa:**
  - `config.example.json` inalterado (o owner edita `config.json`);
  - nenhum `.py`/`.ps1` extra.
- **Os 3 `session_receipt.json` contêm `tick_file_path` absoluto** (`D:\Base CSV\WIN@N\WIN@N_ticks_2025_01.csv`).
  - Esse path vem do calendário preflight R1R4 e é revalidado no rebind (`TICK_PATH_MISSING` / `TICK_HASH_MISMATCH`).
  - Portanto a identidade dos 15 arquivos exige a base física intacta. Qualquer renomeação ou reorganização de `D:\Base CSV` bloqueia o rebind de forma fail-closed.
  - A base (ticks, M1, `IND@N.csv`) não deve ser atualizada entre o rebind e o fim do piloto.

**Totais:** CRITICAL 0 · MAJOR 0 · MINOR 4. A condição de governança G-1 (independência, §0) é tratada à parte e não é defeito do diff.

---

## 8. Cadeia local R1R10 até o novo piloto — autorização condicional consolidada (G)

**Condição de eficácia:** ratificação independente (§0).

Todos os passos abaixo são verificáveis mecanicamente pelo ChatGPT a partir de transcripts e receipts. **Nenhuma auditoria externa intermediária é necessária.** Qualquer critério não atendido significa **PARAR** e é fail-closed.

**Pré-condições:**
- Extrair o ZIP `6C6F35B8…` em uma pasta nova e limpa; o manifesto deve dar 59/59.
- Criar `config.json` a partir do exemplo:
  - mesmos `ticks_root`, `m1_root`, `ind_d1` e `preflight_source_root` da R1R9;
  - `out_root` novo e inexistente;
  - `memory_cap_mib` definido pela política.

| # | Passo | Critério mecânico de PASS |
|---|---|---|
| 1 | Preregistro do cap | Arquivo `LOGS\R1R10_MEMORY_CAP_PREREGISTRATION.txt` com R_MiB, fórmula, cap, SHA256 do `config.json` e hash canônico. **Deve ser gravado antes** do primeiro transcript R1R10 |
| 2 | `RUN_SYNTHETIC_GATES.ps1` (smoke PS 5.1) | Exit 0; cabeçalho `PSVersion: 5.1.*`; os **16** `R1R10_SELFTEST_CHECK=<nome> PASS`; `R1R10_LAUNCHER_SELFTEST=PASS`; `R1R10_LAUNCHER_SELFTEST_GATE=PASS`; `Ran 44 tests`; `"SYNTHETIC_GATES": "PASS"` com runner `189C26D6…` e gate `4414304E…`; `SYNTHETIC_GATE=PASS` |
| 3 | `RUN_OPERATIONAL_GATES.ps1` | Exit 0; `Ran 34 tests` / `OK`; `test_r1r10_live_process_probe_on_this_platform ... ok` e `test_r1r10_main_exit_code_3_marker_no_pass_with_real_probe ... ok` (Win32 real) |
| 4 | `RUN_LIGHT_REBIND_A.ps1` | `LIGHTWEIGHT_HASH_AND_D1_REBIND=PASS`; os 12 `tick_files` (path + SHA) iguais aos do binding R1R9 |
| 5 | `RUN_PRE_RUN_A_GATES.ps1` (gates 1–26 não geométricos) | Repete os critérios 2 e 3; `SOURCE_GATES` PASS; `PREPILOT_NON_ECONOMIC_GATES=PASS_PENDING_MT5_GEOMETRY_VALIDATION` |
| 6 | Geometria | **Reuso MT5 autorizado** somente se o novo `GATES\GEOMETRY_INPUT_R23.csv` tiver SHA **`E28EE2F1…3FB9D2`**, **e** o arquivo reutilizado (preferencialmente `…_R1R9\GATES\GEOMETRY_MT5_R23.csv`) tiver SHA **`800EBC18…D112D404`**, conferido antes do uso, **e** o MQ5 for `1B0024E6…`. `RUN_GEOMETRY_VALIDATE.ps1`: `GEOMETRY_PARITY_GATE=PASS`, `divergent_rows=0`, `summary_2025_rows=750`. Com input divergente: executar o EA no MT5, sem reuso. **Fundamento:** a saída MT5 é função pura do input e do MQ5, e a paridade é recalculada contra o replay Python de qualquer forma |
| 7 | `RUN_SEAL_PREPILOT_GATES.ps1` | `PRE_PILOT_GATES=PASS_27_OF_27`; receipt com as identidades R1R10 |
| 8 | Autorização do piloto (owner) | `GATES\OWNER_PILOT_AUTHORIZATION.json` com `PILOT_AUTHORIZED=YES` + `spec_sha256`, `runner_sha256`, `run_source_binding_sha256` e `pre_pilot_gate_receipt_sha256`, **derivados mecanicamente** dos arquivos do passo 7 |
| 9 | `RUN_GATE28_PILOT.ps1` | `PRE_RUN_A_GATES=PASS_28_OF_28`. Exit 130 → reexecutar (resume). Exit 3 → reexecutar é permitido e seguro, mas **reprova PP5**. Qualquer outro erro → PARAR |
| 10 | Evidência pós-piloto | Empacotar `GATES`, `PILOT_A`, `TELEMETRY`, `LOGS`, o preregistro e o SHA256 de cada arquivo, e aplicar §9 |

---

## 9. Regra mecânica pós-piloto (H)

### 9.1 Por que é defensável

Os fatos que faltam são todos **mensuráveis e comparáveis a limiares prefixados**:
- identidade;
- equivalência econômica, com os 15 arquivos contra uma referência já auditada e a Gate 28;
- runtime Windows (autoteste e probe);
- memória (telemetria contra o cap preregistrado).

Não resta nenhuma decisão de julgamento técnico. Três fatos sustentam isso:
- **Integridade:** está protegida em todos os modos de falha do `run-a`: parada por teto, exit 130, `MemoryError` e kill.
- **Memória do `run-a`:** o conjunto retido por sessão é subconjunto do retido no piloto, e o termo cumulativo foi removido.
- **Resíduo:** o que sobra é apenas de disponibilidade, e é tratado pelo protocolo §9.3.

Uma auditoria externa pós-piloto, portanto, só repetiria verificações mecânicas. → **`POSTPILOT_EXTERNAL_AUDIT_REQUIRED=NO`**, sujeito à condição do §0.

### 9.2 Critérios PP1–PP9 (todos obrigatórios)

1. **PP1 — Identidade.**
   - As identidades recalculadas do pacote no PC são `189C26D6…` e `4414304E…`.
   - Os 8 receipts `GATES` têm esses valores e o spec `D6D79108…`.
   - A hash-chain de `PRE_PILOT`, `GATE28` e `PRE_RUN_A` coincide com os SHA256 reais dos arquivos.
   - O binding está `PASS_SEALED_PREPILOT`.
   - A autorização do piloto é coerente com tudo isso.
2. **PP2 — Economia.**
   - Os 15 arquivos em `PILOT_A\sessions` são byte-idênticos a `05_R1R9_PILOT_REFERENCE_HASHES_SHA256.txt`.
   - Existem exatamente 3 sessões.
   - `PILOT_RUN=PASS`.
   - `GATE28` está PASS com `mismatch_count=0`, e o diff CSV contém só o cabeçalho.
   - Há `PASS_28_OF_28`.
   - Não existem `.pending`, `_orphan` nem `INVALID_PHASE.marker`.
3. **PP3 — Runtime.**
   - Critérios 2 e 3 do §8 cumpridos nos transcripts do passo 5, cujo JSON sintético é o que está vinculado em `component_receipts` do seal.
   - `PSVersion` 5.1 no cabeçalho.
4. **PP4 — Telemetria.** Em `TELEMETRY\PILOT_A_SESSION_TELEMETRY.jsonl`:
   - 100% das linhas são JSON válido com `schema` V1, `mode=PILOT_A` e `probe` iniciando em `WIN32_`;
   - `cap_mib` é igual ao preregistrado;
   - há exatamente um `SESSION_COMMIT` por sessão do piloto, somando todas as invocações;
   - a invocação final contém `RUN_START`, `MONTH_VERIFIED` e `PRE_PILOT_RECEIPT`;
   - cada `SESSION_COMMIT` tem a linha `MEMORY_TELEMETRY event=SESSION_COMMIT … session=<s>` correspondente no transcript, com os MiB coincidentes com uma casa decimal;
   - o SHA256 do arquivo está registrado;
   - `peak_private_bytes` é definido como `PeakPagefileUsage` (pico de commit).
5. **PP5 — Memória.**
   - `max(observed_peak_bytes)` em todas as linhas é ≤ `cap_bytes`.
   - Não há nenhuma linha `MEMORY_CAP_SAFE_STOP` nem `cap_exceeded=true`.
6. **PP6 — Progresso ao vivo.**
   - O transcript do piloto tem `MINOTAURO_V005R1_R1R10 COMMAND=pilot-a`.
   - Há ≥1 `RUN_PROGRESS=` com `MEM_CAP_MIB=` no trecho `pilot-a` (o callback dispara a cada 256 MiB lidos; não exigir posição relativa aos commits).
   - Há as 3 linhas `MEMORY_TELEMETRY event=SESSION_COMMIT`.
   - Os checks `LIVE_*` do autoteste passaram (PP3).
   - O silêncio do `pilot-reconcile` é esperado (m-4).
7. **PP7 — Config.** O hash canônico do `config.json` é igual ao `config_sha256` de `PILOT_A\CHECKPOINT.json` e ao valor preregistrado.
8. **PP8 — Marcadores.**
   - Nenhum `RUN_BLOCKED=`, `Traceback`, `TICK_PREFIX_DRIFT`, `RESUME_HASH_MISMATCH`, `INVALID_PHASE` ou `MEMORY_CAP_SAFE_STOP` em transcript da cadeia.
   - `SAFE_STOP=YES` ou `ORPHAN_MOVED` só são admitidos se PP2 passar, o que prova recuperação correta.
9. **PP9 — Máquina.** O R_MiB medido no início do `run-a` é igual ao preregistrado.

**Resultado:**
- **Tudo PASS** → o owner pode criar `OWNER_RUN_A_AUTHORIZATION.json` (`RUN_A_AUTHORIZED=YES` + spec, runner, binding e `pre_run_a_gate_receipt_sha256`) e executar o `run-a` com o **mesmo** config.
- **Qualquer falha** → RUN_A bloqueado; escalonar citando o critério que falhou.
- O ramo PP5 falho, em que o piloto excedeu o cap, é o único que exige decisão não mecânica: capacidade de hardware ou revisão da política.

### 9.3 Protocolo do `run-a`, preregistrado

| Evento | Ação |
|---|---|
| Exit 3 em `SESSION_COMMIT`, `MONTH_VERIFIED` ou `PRE_FINALIZE` | Retomar com o mesmo comando e o mesmo config. **Escalonar** se duas invocações consecutivas terminarem em exit 3 sem aumento de `completed` nem de `verified_months` |
| Exit 130 | Retomar |
| Exit 2 por `MemoryError`, ou processo morto sem `RUN_BLOCKED` | Uma retomada. Uma segunda falha na mesma sessão → PARAR e escalonar |
| Exit 2 por qualquer outro `RUN_BLOCKED` | PARAR e escalonar |
| PASS | Exige `PHASE_A_RUN=PASS sessions=250`, exit 0, `SHA256SUMS.txt` presente, telemetria `RUN_A` íntegra e `config_sha256` do checkpoint igual ao preregistrado |

A regra cobre **somente a promoção e a execução** do `run-a`. A interpretação dos resultados da seleção segue o fluxo normal de revisão de resultado final do projeto.

---

## 10. Limites

1. **Independência:** esta execução não é independente (§0).
2. **Runtime ainda não observado:** não executei Windows PowerShell 5.1, a chamada Win32 real nem o Python 3.14 final. Os três são gates mecânicos fail-closed da cadeia.
3. **Memória:** nenhuma RAM foi estimada ou inventada. A política usa a medida do próprio PC.
4. **Diferenciais:** usam ticks sintéticos. A equivalência com dados reais será provada pelos 15 arquivos (PP2).
5. **Proibições respeitadas:**
   - nenhum dado real de mercado processado;
   - nenhum `pilot-a`/`run-a` executado;
   - nenhuma autorização criada;
   - nenhum código do pacote alterado.
   - Os scripts de verificação usados nesta auditoria ficaram em área temporária e não foram entregues.
