# CLARIFICAÇÃO DE IDENTIDADES — R1R10 PARENT — V002R1

**Status:** vinculante para a implementação R1R11.  
**Efeito na SPEC V002:** NENHUM. A SPEC V002 permanece byte-idêntica ao handoff V002 anterior.

## 1. Não existe conflito entre os dois hashes

Há duas identidades diferentes e ambas são corretas:

- `R1R10_COMPOSITE_RUNNER_IDENTITY=189C26D6B05F661A731E94058A0006F7AD8E956B92342854722191AFBA1AA582`
  - é a **runner identity composta/lógica** da R1R10;
  - é derivada dos manifests/contratos pelo algoritmo canônico de identidade;
  - aparece nos receipts e foi recalculada independentemente no parecer 26.

- `R1R10_PHYSICAL_MINOTAURO_V004_RUNNER_PY_SHA256=E5E87B55C142159E84E39E44A8AF3E3BA6055CCDADFDAD022599E91A3FED25B9`
  - é o SHA-256 físico do arquivo individual `SOURCE_R1R10/minotauro_v004_runner.py`;
  - aparece no `SOURCE_R1R10/SHA256SUMS.txt` e no `SHA256SUMS_HANDOFF.txt`.

Esses valores **não devem ser comparados entre si**. Eles medem objetos diferentes.

## 2. Regra fail-closed para o Codex

Bloquear somente se ocorrer um destes casos:

1. o arquivo físico `SOURCE_R1R10/minotauro_v004_runner.py` não tiver SHA-256 `E5E87B55...25B9`;
2. a runner identity composta, quando recalculada pelo algoritmo canônico, não resultar em `189C26D6...A582`;
3. algum manifest/receipt parent estiver internamente incoerente.

Não bloquear pelo simples fato de `E5E87...` ser diferente de `189C26...`.

## 3. Evidência

O parecer `26_AUDIT_OPUS55_R1R10_DIFF_FINAL_20260926.md` registra que a runner identity foi recalculada por reimplementação própria a partir de AST dos manifests + JSON canônico e resultou em `189C26D6...BA1AA582`, com os manifests conferidos item a item.

```text
R1R10_PARENT_IDENTITY_RECONCILIATION=PASS
COMPOSITE_RUNNER_IDENTITY=189C26D6B05F661A731E94058A0006F7AD8E956B92342854722191AFBA1AA582
PHYSICAL_RUNNER_FILE_SHA256=E5E87B55C142159E84E39E44A8AF3E3BA6055CCDADFDAD022599E91A3FED25B9
IDENTITY_CONFLICT=NO
SPEC_V002_CHANGED=NO
```
