# PROMPT CODEX — RETOMADA DA IMPLEMENTAÇÃO MINOTAURO R1R11 MULTIWORK/AUTOCPU — SPEC V003

## Aplicativo / modelo / esforço

- APLICATIVO: Codex
- MODELO/CONFIGURAÇÃO: GPT-6 Astra
- RACIOCÍNIO: High

## Regra operacional canônica

Codex deve ser usado para edição, integração e diagnóstico de código. Execução mecânica extensa de suítes, hashes, scanners, full-history ou processamento de mercado deve ser preparada pelo Codex e executada no PC local do owner sempre que tecnicamente possível.

É permitido ao Codex executar somente testes pontuais e estritamente necessários para diagnosticar/validar uma edição durante o desenvolvimento. A homologação integral G1–G11 deve ter runner reproduzível para PC local.

## Leitura obrigatória antes de editar

1. `00A_R1R10_PARENT_IDENTITY_CLARIFICATION.md`
2. `00B_R1R10_FINAL_ORACLE_CERTIFICATION.md`
3. `01_SPEC_MINOTAURO_R1R11_MULTIWORK_AUTOCPU_V003.md`
4. `02_CERT_R1R11_AMBIGUOUS_MULTI_SIGNAL_UNREACHABLE_V001_20260926.md`
5. `03_DIFF_SPEC_V002_TO_V003.patch`
6. `04_INTERNAL_CONFORMANCE_SPEC_V003.md`
7. `28_XHIGH_DISPOSITION_R1R11_G6_AMBIGUOUS_20260926.md`
8. `29_XHIGH_CONFIRMATION_SPEC_V003_DELTA_20260926.md`
9. `30_PRIOR_CODEX_BLOCKER_RESOLUTION.md`

## Estado de recovery

A tentativa anterior no mesmo repositório parou corretamente em BLOCKED antes de concluir a implementação porque G6/V002 exigia `AMBIGUOUS_MULTI_SIGNAL` causal. Esse blocker foi resolvido normativamente pela V003 e confirmado independentemente.

No repositório atual:
- NÃO executar reset/checkout/stash/clean destrutivo;
- NÃO reverter alterações locais preexistentes do owner;
- preservar artefatos diagnósticos da tentativa anterior;
- identificar e reutilizar trabalho R1R11 já válido, se houver, somente após reconciliá-lo contra a SPEC V003;
- se houver código parcial produzido antes do blocker, auditar o diff antes de continuar; não assumir que está correto nem descartá-lo por reflexo.

## Autoridade vigente

- SPEC de implementação: `01_SPEC_MINOTAURO_R1R11_MULTIWORK_AUTOCPU_V003.md`
- SPEC V002 é parent histórico, não autoridade vigente.
- Core/economia permanecem congelados.
- Único delta V002→V003: C8/G6.
- `AMBIGUOUS_MULTI_SIGNAL` permanece no core/tabela de merge, porém G6 deve classificá-lo como `STRUCTURALLY_UNREACHABLE` quando e somente quando o certificado e todos os bindings forem válidos.
- Os demais eventos continuam exigindo `COVERED` por ocorrência causal válida.

## Freeze obrigatório

Devem permanecer byte-idênticos ao parent R1R10:
- `minotauro_v004_core.py`
- `minotauro_v004_io.py`
- `minotauro_v004_metrics.py`
- `minotauro_v004_preflight.py`
- economia/causalidade/geometria/grid/custos/cutoff da R1R10

Qualquer necessidade de tocar nesses itens = STOP + diagnóstico, sem implementação silenciosa.

## Implementação exigida

Implementar integralmente a arquitetura R1R11 MULTIWORK/AUTOCPU da SPEC V003, incluindo:

1. coordinator single-reader/single-writer;
2. 15 grupos completos `(p_idx,t_idx)`; nunca dividir grupo;
3. Windows multiprocessing `spawn`, import-safe;
4. AUTOCPU efetivo 2..12; sem fallback monowork silencioso;
5. grant apenas em fronteira de sessão; RAM target 60%; hard cap agregado 48528 MiB;
6. shared memory bounded com layout binário congelado, batch_seq/generation/CRC;
7. FEED_DIGEST e contadores coordinator/worker;
8. `r_global=max(r_g)` e consumo/ACK até r_global por todos os workers;
9. snapshot de prefixo exato em r_global; lote nunca cruza sessão;
10. scratch comprimido por run_instance/session/group e merge k-way em streaming;
11. merge S1a..S5b + fusão dos 3 eventos globais conforme C1;
12. single canonical writer, sem path de publicação nos workers;
13. RUN.lock, purge de scratch, scan de órfãos, parent-death detection e SIGINT ignorado nos workers;
14. telemetria agregada coordinator + workers + shared memory;
15. SAFE_STOP/resume determinístico por sessão inteira e invariância ao worker count.

## G6 V003 — obrigatório

O manifesto G6 deve listar os 13 eventos e, para cada um, exatamente uma classificação:

- `COVERED`: ocorrência causal válida identificável; ou
- `STRUCTURALLY_UNREACHABLE`: certificado formal válido.

Nesta implementação, somente `AMBIGUOUS_MULTI_SIGNAL` possui certificado previamente aprovado para `STRUCTURALLY_UNREACHABLE`.

O runner/gate deve validar antes de aceitar essa classificação:
- core SHA `97F8F957300D37966913C872B7F04E498D30B0CFF68180993DB80D314B900827`;
- economic spec SHA `D6D791083870015BF07BF4ABF64718D37F9136FA247D49DB31B4DC8DE2E73747`;
- grid SHA `A91A923FB38C9BFA85E157AF494B26B3ED5EBF1843F531259820CD345DCD14B1`;
- 435 células válidas;
- 15 grupos;
- RR mínimo 3;
- target adjacente e demais premissas do certificado.

Qualquer binding divergente, ausência de certificado, classificação dupla, evento não classificado ou ocorrência contraditória de `AMBIGUOUS_MULTI_SIGNAL` => G6 FAIL.

Não fabricar evento impossível apenas para satisfazer cobertura.

## Proibições absolutas

- NÃO processar dados reais de mercado.
- NÃO executar Pilot A real.
- NÃO executar Run-A.
- NÃO criar owner authorization de Pilot/Run-A.
- NÃO tocar em `D:\Base CSV`.
- NÃO alterar SPEC V003 durante implementação.
- NÃO alterar economia/core para facilitar teste.
- NÃO aceitar fallback monowork.
- NÃO reduzir G6/G7.

## Entrega de implementação

Preparar árvore completa R1R11, testes e runners de homologação G1–G11, incluindo um runner PowerShell 5.1 único ou cadeia claramente documentada, executável a partir de `PS C:\Users\silvi>` e que faça fail-closed.

A execução integral mecânica G1–G11 deverá ser realizada no PC local do owner. Codex deve entregar os comandos/runner exatos e as expectativas de PASS/FAIL.

Entregar ZIP versionado contendo no mínimo:
- implementação executável R1R11;
- SPEC V003 e certificado;
- `IMPLEMENTATION_RECEIPT_R1R11.json`;
- `CHANGELOG_R1R11.md`;
- `R1R11_INTERNAL_GATE_REPORT.md` (resultados apenas do que de fato tiver sido executado; não inventar PASS local não executado);
- `R1R11_ORACLE_COVERAGE_MANIFEST.json` com contrato V003;
- testes/runners G1–G11;
- launchers PowerShell 5.1;
- `SHA256SUMS.txt` abrangente;
- nenhum `config.json` do owner.

## Veredito interno obrigatório

```text
R1R11_IMPLEMENTATION_STATUS=<READY_FOR_OWNER_GATES|BLOCKED>
R1R11_MULTIWORK=YES
R1R11_AUTOCPU=YES
MONOWORK_FALLBACK_PATHS=<0|n>
CORE_FREEZE=<PASS|FAIL>
IO_FREEZE=<PASS|FAIL>
METRICS_FREEZE=<PASS|FAIL>
PREFLIGHT_FREEZE=<PASS|FAIL>
SPEC_V003_BINDING=<PASS|FAIL>
AMBIGUOUS_CERTIFICATE_BINDING=<PASS|FAIL>
G6_CONTRACT_V003=<PASS|FAIL|NOT_EXECUTED>
CODEX_TARGETED_TESTS=<PASS|FAIL|NOT_RUN>
OWNER_G1_TO_G11_REQUIRED=YES
REAL_DATA_PROCESSED=NO
PILOT_A_AUTHORIZED=NO
RUN_A_AUTHORIZED=NO
NEXT_GATE=OWNER_PC_G1_TO_G11
```

Se surgir qualquer blocker material, parar e entregar diagnóstico. Não alterar a SPEC ou critérios pós-hoc.
