# NOTA DE GOVERNANÇA — TEXTO HISTÓRICO HERDADO NA SPEC V003

A SPEC V003 foi construída sob autoridade XHigh que autorizou **exclusivamente** a correção normativa de C8/G6.

Consequentemente, trechos factuais históricos herdados da V002 fora de C8/G6 foram preservados literalmente, mesmo quando eventos posteriores da cadeia produziram evidência mais recente (por exemplo, o fechamento posterior do Pilot A R1R10 como oracle monowork).

Isso não reabre nem substitui o estado factual atual. Para o estado operacional/oracle vigente, prevalecem os artefatos separados de certificação final incluídos no handoff, especialmente `00B_R1R10_FINAL_ORACLE_CERTIFICATION.md` e `06_R1R10_S10R1_FINAL_ORACLE_CERTIFICATION.txt`.

Esta nota é documental e não altera nenhuma obrigação da SPEC V003.
