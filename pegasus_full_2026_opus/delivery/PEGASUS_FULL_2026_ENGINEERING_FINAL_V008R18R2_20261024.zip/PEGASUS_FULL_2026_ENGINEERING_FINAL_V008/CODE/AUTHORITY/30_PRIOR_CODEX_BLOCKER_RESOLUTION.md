# RESOLUÇÃO DO BLOCKER QUE PAROU A TENTATIVA ANTERIOR DO CODEX

A tentativa anterior terminou corretamente em `STATE=BLOCKED` antes da implementação final porque a SPEC V002 exigia em G6 ocorrência causal de `AMBIGUOUS_MULTI_SIGNAL`.

O diagnóstico demonstrou que, sob o core e a economia congelados, esse evento é estruturalmente inalcançável. A reauditoria XHigh confirmou a demonstração e classificou a exigência V002 como defeito de SPEC, não defeito do executor.

A SPEC V003 corrige exclusivamente esse ponto. A confirmação independente posterior fechou PASS e autorizou `IMPLEMENTATION_MAY_RESUME=YES`.

Portanto:

- não tratar a ausência de ocorrência de `AMBIGUOUS_MULTI_SIGNAL` como blocker se o certificado V001 estiver válido e todos os bindings conferirem;
- não fabricar fixture economicamente impossível;
- não remover o evento do core;
- não alterar C1–C7, C9, m-1..m-6, G5, G7 ou economia;
- qualquer novo blocker deve ser tratado fail-closed e documentado, não mascarado.
