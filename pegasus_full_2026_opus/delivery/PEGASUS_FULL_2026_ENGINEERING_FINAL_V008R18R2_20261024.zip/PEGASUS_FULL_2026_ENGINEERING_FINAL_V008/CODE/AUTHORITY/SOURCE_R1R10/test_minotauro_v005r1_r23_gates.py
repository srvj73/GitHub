import json
import tempfile
import unittest
from pathlib import Path
from fractions import Fraction
from datetime import datetime

from minotauro_v004_core import *
from minotauro_v004_io import parse_tick_fields, cutoff_msc_for_session, BRT
from minotauro_v004_metrics import pf_ok, score, select_2025
from minotauro_v004_runner import _checkpoint_with_hash, _verify_checkpoint_self, _orphan_reconcile
from minotauro_v005r1_r23_contract import (
    EXPECTED_CORE_IMPORTED_DEFINITIONS_SHA256,
    core_imported_definitions_hash,
)
from minotauro_v005r1_r23_outputs import write_grid_cells
from minotauro_v005r1_r23_reference import ReferencePilotEngine


class GateTests(unittest.TestCase):
    def setUp(self):
        self.cell = [c for c in valid_cells() if c.cell_id == BASELINE_CELL_ID][0]
        self.d1 = D1Bar("2024-12-30", 10000*PRICE_SCALE, 20000*PRICE_SCALE, 10000*PRICE_SCALE, 15000*PRICE_SCALE)

    def rec(self, o, m, b, a, l, v=1.0, session="2025-01-02"):
        return TickRecord(session, o, session.replace("-", ".")+" 10:00:00", m,
                          int(b*PRICE_SCALE), int(a*PRICE_SCALE), int(l*PRICE_SCALE), v, v, 0)

    def seed_position(self, e, direction, entry=100, sl=90, tp=110):
        i=0
        e.realized[i] -= ENTRY_COST_UNITS
        e.pos_open[i]=True; e.pos_dir[i]=direction; e.pos_entry[i]=entry*PRICE_SCALE
        e.pos_sl[i]=sl*PRICE_SCALE; e.pos_tp[i]=tp*PRICE_SCALE
        e.pos_entry_msc[i]=1000; e.pos_entry_ordinal[i]=1
        e.trades.append({"cell_id":e.cell_ids[i],"session":e.session,"direction":"BUY" if direction>0 else "SELL","entry_msc":1000,"entry_ordinal":1,"entry_price_micro":entry*PRICE_SCALE})
        e.pos_trade_index[i]=0

    # Gates 1-2: projection fractions, exact rounding, 97 lines. MT5-double parity is external.
    def test_gate01_projection_pct_division(self):
        self.assertEqual(PROJECTION_PCT_LIST, (Fraction(382,10), Fraction(500,10), Fraction(618,10)))
        self.assertEqual([p/100 for p in PROJECTION_PCT_LIST], [Fraction(191,500), Fraction(1,2), Fraction(309,500)])

    def test_gate02_round_half_up_and_97(self):
        self.assertEqual(round_tick_fraction(Fraction(10002_500000,1)),10005*PRICE_SCALE)
        self.assertEqual(round_tick_fraction(Fraction(10002_499999,1)),10000*PRICE_SCALE)
        for p in PROJECTION_PCT_LIST:
            self.assertEqual(len(build_grid(self.d1.high_micro,self.d1.low_micro,p)),97)

    # Gate 3 boundary tests.
    def test_gate03_eq_trigger_rr_rmax_boundaries(self):
        self.assertTrue(eq_price(Fraction(200,2),Fraction(201,2)))  # +0.5 micro is inside Eq
        self.assertTrue(eq_price(Fraction(200,2),Fraction(199,2)))  # -0.5 micro is inside Eq
        self.assertFalse(eq_price(Fraction(200,2),Fraction(202,2))) # +1 micro is outside Eq
        self.assertFalse(eq_price(Fraction(200,2),Fraction(198,2))) # -1 micro is outside Eq
        self.assertTrue(trigger_reached(10*TICK_MICRO,10)); self.assertFalse(trigger_reached(10*TICK_MICRO-2,10))
        self.assertTrue(rr_pass(5*TICK_MICRO,1*TICK_MICRO,5)); self.assertFalse(rr_pass(5*TICK_MICRO-2,1*TICK_MICRO,5))
        self.assertTrue(rmax_pass(14*TICK_MICRO,14)); self.assertFalse(rmax_pass(14*TICK_MICRO+2,14))

    # Gate 6 physical time semantics.
    def test_gate06_date_time_time_msc(self):
        fields="WIN@N;2025.01.02 08:55:00;1735818900041;0.00;122360;0.00;0;0;4".split(";")
        r=parse_tick_fields(fields,1); self.assertEqual(r.time_msc,1735818900041)
        bad=list(fields); bad[2]=str(1735818900041+2000)
        with self.assertRaisesRegex(ModelError,"TIME_SEMANTICS_MISMATCH"):
            parse_tick_fields(bad,1)

    # Gate 7 BRT cutoff.
    def test_gate07_cutoff_brt_1803(self):
        m=cutoff_msc_for_session("2025-01-02")
        dt=datetime.fromtimestamp(m/1000,tz=BRT)
        self.assertEqual((dt.hour,dt.minute,dt.second),(18,3,0))

    # Gate 8 bilateral 500 inclusive, regression and B1 crossed rejection without abort.
    def test_gate08_bbo_500_inclusive_regression_and_crossed_b1(self):
        e=SessionEngine("2025-01-02",self.d1,[self.cell],9999999999999)
        e.market_bid=100*PRICE_SCALE; e.market_ask=101*PRICE_SCALE; e.bid_msc=1000; e.ask_msc=1000
        self.assertTrue(e._bbo_fresh(1500)[0]); self.assertFalse(e._bbo_fresh(1501)[0])
        self.assertFalse(e._bbo_fresh(999)[0])
        # Crossed state itself no longer aborts pre-cutoff.
        e.process_record(self.rec(1,2000,110,105,0,0))
        self.assertEqual(e.precutoff_crossed_state_count,1)

    # Gate 9 own timestamp and no cutoff age gate.
    def test_gate09_cutoff_own_side_post_cutoff(self):
        e=SessionEngine("2025-01-02",self.d1,[self.cell],5000)
        e.process_record(self.rec(1,1000,99,101,0,0)); self.seed_position(e,1,100,1,1000000)
        self.assertTrue(e.process_record(self.rec(2,5000,0,102,0,0)))
        self.assertTrue(e.pos_open[0])
        self.assertFalse(e.process_record(self.rec(3,10000,100,0,0,0)))
        self.assertEqual(e.trades[0]["cutoff_side_msc"],10000)

    # Gate 10 session confined.
    def test_gate10_cutoff_session_confined(self):
        e=SessionEngine("2025-01-02",self.d1,[self.cell],5000)
        with self.assertRaisesRegex(ModelError,"SESSION_BOUNDARY_CROSSING"):
            e.process_record(self.rec(1,5000,100,101,0,0,session="2025-01-03"))

    # Gate 11 unique realization and no duplicate mark on closing record.
    def test_gate11_cutoff_realization_reconciliation(self):
        e=SessionEngine("2025-01-02",self.d1,[self.cell],5000, integral_open_mark_cell_ids={BASELINE_CELL_ID})
        e.process_record(self.rec(1,1000,99,101,0,0)); self.seed_position(e,1,100,1,1000000)
        e.process_record(self.rec(2,5000,100,101,0,0))
        at=[x for x in e.equity_events if x["time_msc"]==5000]
        self.assertEqual(sum(x["event"]=="CUTOFF_CLOSE_POST_REALIZATION" for x in at),1)
        self.assertEqual(sum(x["event"]=="OPEN_MARK" for x in at),0)

    # Gate 13 N->N+1 same-ms, consumption, no retry.
    def test_gate13_n_n1_consumed_no_retry(self):
        e=SessionEngine("2025-01-02",self.d1,[self.cell],9999999999999)
        line=e.lines[2][48].price_micro//PRICE_SCALE
        e.process_record(self.rec(1,1000,line-5,line,line))
        e.process_record(self.rec(2,2000,line+45,line+50,line+50))
        self.assertTrue(e.pending_active[0])
        e.process_record(self.rec(3,2000,line+70,line+60,line+55)) # crossed -> N+1 rejected, no abort
        self.assertFalse(e.pending_active[0]); self.assertFalse(e.pos_open[0])
        e.process_record(self.rec(4,2001,line+50,line+55,line+55))
        self.assertFalse(e.pos_open[0])

    # Gate 14 stop gap fills observed executable quote.
    def test_gate14_stop_gap(self):
        e=SessionEngine("2025-01-02",self.d1,[self.cell],9999999999999)
        self.seed_position(e,1,100,90,110)
        e.process_record(self.rec(2,2000,80,85,0,0))
        self.assertEqual(e.trades[0]["exit_reason"],"STOP")
        self.assertEqual(e.trades[0]["exit_price_micro"],80*PRICE_SCALE)

    # Gate 15 target jump fills target, no fictitious mark beyond target.
    def test_gate15_target_jump(self):
        e=SessionEngine("2025-01-02",self.d1,[self.cell],9999999999999, integral_open_mark_cell_ids={BASELINE_CELL_ID})
        self.seed_position(e,1,100,90,110)
        e.process_record(self.rec(2,2000,120,121,0,0))
        self.assertEqual(e.trades[0]["exit_reason"],"TARGET")
        self.assertEqual(e.trades[0]["exit_price_micro"],110*PRICE_SCALE)
        self.assertFalse(any(x.get("mark_price_micro")==120*PRICE_SCALE for x in e.equity_events))

    # Gate 16 entry open mark precedes immediate stop.
    def test_gate16_entry_mark_then_immediate_stop(self):
        e=SessionEngine("2025-01-02",self.d1,[self.cell],9999999999999)
        i=0
        e.pending_active[i]=True; e.pending_dir[i]=1; e.pending_origin[i]=100*PRICE_SCALE; e.pending_target[i]=200*PRICE_SCALE
        e.pending_trigger_seq[i]=0; e.pending_n_ordinal[i]=1; e.pending_n_msc[i]=1000; e.pending_n_last[i]=150*PRICE_SCALE
        e.pending_risk[i]=50*PRICE_SCALE; e.pending_reward[i]=50*PRICE_SCALE
        e.business_seq=1
        e.market_bid=99*PRICE_SCALE; e.market_ask=101*PRICE_SCALE; e.bid_msc=2000; e.ask_msc=2000
        rec=self.rec(2,2000,99,101,101,1)
        e._consume_pending(rec)
        ev=[x["event"] for x in e.equity_events]
        self.assertIn("ENTRY_OPEN_MARK",ev); self.assertIn("IMMEDIATE_STOP_POST_REALIZATION",ev)
        self.assertLess(ev.index("ENTRY_OPEN_MARK"),ev.index("IMMEDIATE_STOP_POST_REALIZATION"))

    # Gate 17 cutoff latches once.
    def test_gate17_cutoff_unique(self):
        e=SessionEngine("2025-01-02",self.d1,[self.cell],5000)
        e.process_record(self.rec(1,5000,100,101,0,0)); e.process_record(self.rec(2,5100,100,101,0,0))
        self.assertEqual(sum(x["event"]=="CUTOFF_LATCH" for x in e.events),1)

    # Gate 18 observability failure blocks finish.
    def test_gate18_missing_post_cutoff_side_blocks(self):
        e=SessionEngine("2025-01-02",self.d1,[self.cell],5000)
        e.process_record(self.rec(1,4900,99,101,0,0)); self.seed_position(e,1,100,1,1000000)
        e.process_record(self.rec(2,5000,0,102,0,0))
        with self.assertRaisesRegex(ModelError,"POSITION_NOT_FLAT_AFTER_CUTOFF"):
            e.finish(2,"2025.01.02 18:03:00")

    # Gate 19 independent cell busy state.
    def test_gate19_busy_cell_does_not_block_peer(self):
        cells=[c for c in valid_cells() if c.cell_id in {"P02_T00_R00_M00","P02_T00_R01_M00"}]
        self.assertEqual(len(cells),2)
        e=SessionEngine("2025-01-02",self.d1,cells,9999999999999)
        line=e.lines[2][48].price_micro
        e.have_prev_business=True; e.prev_business=line; e.business_seq=1
        e.pos_open[0]=True; e.pos_dir[0]=1; e.pos_entry[0]=line; e.pos_sl[0]=1; e.pos_tp[0]=10**15
        e.process_record(self.rec(2,2000,(line//PRICE_SCALE)+30,(line//PRICE_SCALE)+35,(line//PRICE_SCALE)+30,1))
        self.assertFalse(e.pending_active[0])
        self.assertTrue(e.pending_active[1])

    # Gate 20 costs and DD exact; plus lossless extrema persistence.
    def test_gate20_costs_equity_dd_and_extrema_lossless(self):
        e=SessionEngine("2025-01-02",self.d1,[self.cell],9999999999999)
        self.seed_position(e,1,100,90,200)
        for o,p in enumerate([101,99,102,98,103,97],2):
            e.process_record(self.rec(o,1000+o,p,p+1,0,0))
        e.process_record(self.rec(20,3000,90,91,0,0))
        persisted=[x for x in e.equity_events if x["cell_id"]==BASELINE_CELL_ID]
        h=0; dd=0
        for x in persisted:
            q=int(x["equity_units"]); h=max(h,q); dd=max(dd,h-q)
        self.assertEqual(dd,int(e.max_dd[0]))
        self.assertEqual(e.trades[0]["cost_units"],ENTRY_COST_UNITS+EXIT_COST_UNITS)

    # Gate 21 baseline insufficient.
    def test_gate21_baseline_insufficient(self):
        cells=valid_cells(); metrics={}
        for c in cells:
            metrics[c.cell_id]={"trade_count":0,"sessions_with_trade":0,"net_units":0,"positive_units":0,"negative_abs_units":0,"pf_num":0,"pf_den":0,"max_dd_units":0,"h1_units":0,"h2_units":0,"positive_months":0,"months_with_trade":0,"monthly_units":[0]*12,"top5_positive_days_units":0,"sum_positive_days_units":0,"net_without_top5_units":0}
        self.assertEqual(select_2025(cells,metrics)["status"],"INSUFFICIENT_EVIDENCE")

    # Gate 22 PF denom zero and DD zero are not selectable.
    def test_gate22_pf_inf_undefined_dd_zero(self):
        m={"pf_den":0,"pf_num":100,"max_dd_units":0}
        self.assertFalse(pf_ok(m)); self.assertIsNone(score(m))

    # Gate 23 symmetric neighborhood relation.
    def test_gate23_neighbors_symmetric(self):
        d={c.cell_id:c for c in valid_cells()}
        for a in list(d.values()):
            for b in cell_neighbors(a,d):
                self.assertIn(a.cell_id,cell_neighbors(d[b],d))

    # Gate 24 deterministic CELL_ID and total tiebreak resolves to baseline on equal metrics.
    def test_gate24_cell_id_tiebreak(self):
        cells=valid_cells(); self.assertEqual(len({c.cell_id for c in cells}),435)
        metrics={}
        for c in cells:
            metrics[c.cell_id]={"trade_count":200,"sessions_with_trade":60,"net_units":1200,"positive_units":2400,"negative_abs_units":1200,"pf_num":2400,"pf_den":1200,"max_dd_units":100,"h1_units":600,"h2_units":600,"positive_months":12,"months_with_trade":12,"monthly_units":[100]*12,"top5_positive_days_units":300,"sum_positive_days_units":1000,"net_without_top5_units":900}
        self.assertEqual(select_2025(cells,metrics)["selected"],BASELINE_CELL_ID)

    # Gate 25 R1R6 runner exposes A only (no B/C economic command).
    def test_gate25_phase_isolation_static(self):
        text=(Path(__file__).parent/"minotauro_v004_runner.py").read_text(encoding="utf-8")
        self.assertIn('choices=["rebind-a", "pilot-a", "run-a"]',text)
        self.assertNotIn('"run-b"',text); self.assertNotIn('"run-c"',text)

    # Gate 26 checkpoint self-hash and orphan handling.
    def test_gate26_checkpoint_orphan_failclosed(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); out=root/"PHASE_A"; (out/"sessions"/"2025-01-02").mkdir(parents=True)
            cp={"completed":[]}
            _orphan_reconcile(out,cp)
            self.assertTrue((out/"_orphan"/"2025-01-02__1").is_dir())
            x={k:None for k in []}; x={"a":1,"checkpoint_content_sha256":""}
            x=_checkpoint_with_hash(x)
            # Low-level content hash is deterministic even though this is not a complete checkpoint.
            self.assertEqual(x["checkpoint_content_sha256"],_checkpoint_with_hash(x)["checkpoint_content_sha256"])

    # Gate 27 clean/resume state equivalence at session boundary, including regime_min.
    def test_gate27_session_state_resume_equivalence(self):
        def run_session(session, state=None):
            kwargs={}
            if state:
                kwargs=dict(initial_cash_units=state[0],initial_hwm_units=state[1],initial_max_dd_units=state[2],initial_regime_min_units=state[3],initial_closed_hwm_units=state[4],initial_closed_max_dd_units=state[5])
            e=SessionEngine(session,self.d1,[self.cell],5000,**kwargs)
            e.process_record(self.rec(1,4900,99,101,0,0,session=session)); self.seed_position(e,1,100,90,110)
            e.process_record(self.rec(2,5000,105,106,0,0,session=session))
            r=e.finish(2,session.replace("-",".")+" 18:03:00")
            return r,(r.end_cash_units,r.hwm_units,r.max_dd_units,r.regime_min_units,r.closed_hwm_units,r.closed_max_dd_units)
        r1,state=run_session("2025-01-02")
        r2a,state2=run_session("2025-01-03",state)
        # Serialize/deserialize checkpoint state as resume would.
        state_json=json.loads(json.dumps(state))
        r2b,state2b=run_session("2025-01-03",tuple(state_json))
        self.assertEqual(state2,state2b); self.assertEqual(r2a.trades,r2b.trades); self.assertEqual(r2a.equity_events,r2b.equity_events)

    def test_r23_core_imported_definitions_frozen(self):
        root=Path(__file__).parent
        self.assertEqual(core_imported_definitions_hash(root/"minotauro_v004_core.py"),EXPECTED_CORE_IMPORTED_DEFINITIONS_SHA256)

    def test_r23_grid_serialization_canonical(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"GRID_CELLS.csv"; h=write_grid_cells(p)
            text=p.read_text(encoding="utf-8")
            self.assertTrue(text.startswith("cell_id;p_idx;t_idx;rr_idx;m_idx;projection_pct;trigger_ticks;rr_min;rmax_ticks;valid\n"))
            self.assertEqual(len(text.splitlines()),451)
            self.assertIn("P02_T02_R02_M00;2;2;2;0;61.8;10;5;;YES",text)
            self.assertEqual(len(h),64)

    def test_gate28_reference_engine_matches_vector_on_synthetic_path(self):
        cells=[c for c in valid_cells() if c.cell_id in {BASELINE_CELL_ID,"P02_T00_R00_M00","P01_T01_R01_M00"}]
        cutoff=5000
        vec=SessionEngine("2025-01-02",self.d1,cells,cutoff, integral_open_mark_cell_ids={c.cell_id for c in cells})
        ref=ReferencePilotEngine("2025-01-02",self.d1,cells,cutoff)
        # A small causal path with business movement, same-ms, quote-only and cutoff.
        line=vec.lines[2][48].price_micro//PRICE_SCALE
        path=[
            self.rec(1,1000,line-5,line,line,1),
            self.rec(2,2000,line+45,line+50,line+50,1),
            self.rec(3,2000,line+50,line+55,line+55,1),
            self.rec(4,3000,line+70,line+75,line+75,1),
            self.rec(5,4900,line+65,line+70,0,0),
            self.rec(6,5000,line+65,line+70,0,0),
            self.rec(7,5100,line+66,line+71,0,0),
        ]
        for r in path:
            vec.process_record(r); ref.process(r)
        vr=vec.finish(path[-1].ordinal,path[-1].date_time); rr=ref.finish()
        by={}
        for t in vr.trades: by.setdefault(t["cell_id"],[]).append(t)
        for c in cells:
            v=[(x.get("direction"),x.get("n_ordinal"),x.get("n1_ordinal"),x.get("entry_ordinal"),x.get("exit_ordinal"),x.get("entry_price_micro"),x.get("exit_price_micro"),x.get("exit_reason"),x.get("net_pnl_units")) for x in by.get(c.cell_id,[])]
            q=[(x.get("direction"),x.get("n_ordinal"),x.get("n1_ordinal"),x.get("entry_ordinal"),x.get("exit_ordinal"),x.get("entry_price_micro"),x.get("exit_price_micro"),x.get("exit_reason"),x.get("net_pnl_units")) for x in rr.get(c.cell_id,[])]
            self.assertEqual(v,q)


if __name__ == "__main__":
    unittest.main(verbosity=2)
