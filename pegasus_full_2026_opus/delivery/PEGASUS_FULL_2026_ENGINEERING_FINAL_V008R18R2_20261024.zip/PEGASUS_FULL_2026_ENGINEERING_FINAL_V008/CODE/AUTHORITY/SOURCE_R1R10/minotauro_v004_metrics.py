
from fractions import Fraction
from collections import defaultdict
import math
from minotauro_v004_core import BASELINE_CELL_ID,cell_neighbors

def aggregate_phase(cells,trade_rows,max_dd_units):
    bycid={c.cell_id:{"trade_count":0,"sessions":set(),"pos":0,"neg":0,"net":0,"monthly":defaultdict(int),"daily":defaultdict(int)} for c in cells}
    for tr in trade_rows:
        if tr.get("net_pnl_units") is None:continue
        cid=tr["cell_id"];net=int(tr["net_pnl_units"]);s=tr["session"];m=s[:7];x=bycid[cid]
        x["trade_count"]+=1;x["sessions"].add(s);x["net"]+=net;x["monthly"][m]+=net;x["daily"][s]+=net
        if net>0:x["pos"]+=net
        elif net<0:x["neg"]+=-net
    out={}
    for c in cells:
        x=bycid[c.cell_id];months=[x["monthly"].get(f"2025-{m:02d}",0) for m in range(1,13)]
        days=sorted([v for v in x["daily"].values() if v>0],reverse=True);top5=sum(days[:5]);posdays=sum(days)
        out[c.cell_id]={"cell_id":c.cell_id,"trade_count":x["trade_count"],"sessions_with_trade":len(x["sessions"]),
            "net_units":x["net"],"positive_units":x["pos"],"negative_abs_units":x["neg"],"pf_num":x["pos"],"pf_den":x["neg"],
            "max_dd_units":int(max_dd_units.get(c.cell_id,0)),"h1_units":sum(months[:6]),"h2_units":sum(months[6:]),
            "positive_months":sum(v>0 for v in months),"months_with_trade":len({s[:7] for s in x["sessions"]}),
            "monthly_units":months,"top5_positive_days_units":top5,"sum_positive_days_units":posdays,"net_without_top5_units":x["net"]-top5}
    return out

def pf_ok(m):return m["pf_den"]>0 and m["pf_num"]>m["pf_den"]
def score(m):return None if m["max_dd_units"]<=0 else Fraction(m["net_units"],m["max_dd_units"])
def median(v):
    v=sorted(v);n=len(v)
    if not n:return Fraction(0,1)
    return v[n//2] if n%2 else Fraction(v[n//2-1]+v[n//2],2)

def select_2025(cells,metrics):
    byid={c.cell_id:c for c in cells};base=metrics[BASELINE_CELL_ID]
    if base["trade_count"]<200 or base["sessions_with_trade"]<60:return {"status":"INSUFFICIENT_EVIDENCE","selected":None}
    passed=[];neighbor_rows=[]
    for c in cells:
        m=metrics[c.cell_id]
        gates=[m["trade_count"]>=200,m["sessions_with_trade"]>=60,m["trade_count"]*2>=base["trade_count"],m["months_with_trade"]>=9,
               m["net_units"]>0,m["pf_den"]>0,pf_ok(m),m["max_dd_units"]>0,m["h1_units"]>0,m["h2_units"]>0,m["positive_months"]>=9,
               m["net_without_top5_units"]>0,m["sum_positive_days_units"]>0 and m["top5_positive_days_units"]*100<=40*m["sum_positive_days_units"]]
        if not all(gates):continue
        nids=cell_neighbors(c,byid)
        if len(nids)<3:continue
        approvals=sum(metrics[n]["net_units"]>0 and pf_ok(metrics[n]) for n in nids)
        ns=[score(metrics[n]) if score(metrics[n]) is not None else Fraction(0,1) for n in nids]
        req=math.ceil(2*len(nids)/3);sc=score(m);med=median(ns);ng=approvals>=req and sc is not None and med*2>=sc
        neighbor_rows.append({"cell_id":c.cell_id,"neighbors":len(nids),"approvals":approvals,"required":req,"gate":ng})
        if ng:passed.append(c.cell_id)
    if not passed:return {"status":"NO_CANDIDATE","selected":None,"neighbor_rows":neighbor_rows}
    def k(cid):
        c=byid[cid];m=metrics[cid];dist=(0 if c.p_idx==2 else 1)+abs(c.t_idx-2)+abs(c.rr_idx-2)+(0 if c.m_idx==0 else 1)
        return (-score(m),-median([Fraction(x,1) for x in m["monthly_units"]]),-Fraction(m["pf_num"],m["pf_den"]),-m["trade_count"],dist,cid)
    return {"status":"SELECTED","selected":sorted(passed,key=k)[0],"neighbor_rows":neighbor_rows}
