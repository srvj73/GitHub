from __future__ import annotations

from pathlib import Path
from fractions import Fraction
import csv
import gzip
import json
import os
import shutil

from minotauro_v004_core import (
    BASELINE_CELL_ID,
    RMAX_LIST,
    ModelError,
    build_all_cells,
    cell_neighbors,
)
from minotauro_v004_io import write_csv
from minotauro_v004_metrics import pf_ok, score, median, select_2025
from minotauro_v005r1_r23_contract import (
    PARENT_SPEC_SHA256,
    RUNNER_VERSION,
    SPEC_SHA256,
    canonical_json_hash,
    runner_identity,
    sha256_file,
    write_json_atomic_canonical,
)


def _decimal_fraction(v: Fraction) -> str:
    # Canonical values used by this fixed grid are finite tenths.
    n, d = v.numerator, v.denominator
    sign = "-" if n < 0 else ""
    n = abs(n)
    if d == 1:
        return sign + str(n)
    # Generic exact finite decimal for denominators of 2^a*5^b.
    x = Fraction(n, d)
    digits = []
    whole = x.numerator // x.denominator
    rem = x.numerator % x.denominator
    if rem == 0:
        return sign + str(whole)
    while rem:
        rem *= 10
        digits.append(str(rem // x.denominator))
        rem %= x.denominator
        if len(digits) > 32:
            raise ValueError("NON_TERMINATING_DECIMAL")
    frac = "".join(digits).rstrip("0")
    return sign + str(whole) + "." + frac


def write_grid_cells(path: Path) -> str:
    rows = []
    for c in build_all_cells():
        rows.append({
            "cell_id": c.cell_id,
            "p_idx": c.p_idx,
            "t_idx": c.t_idx,
            "rr_idx": c.rr_idx,
            "m_idx": c.m_idx,
            "projection_pct": _decimal_fraction(c.projection_pct),
            "trigger_ticks": c.trigger_ticks,
            "rr_min": c.rr_min,
            "rmax_ticks": "" if c.rmax_ticks is None else c.rmax_ticks,
            "valid": "YES" if c.valid else "NO",
        })
    rows.sort(key=lambda r: r["cell_id"])
    write_csv(path, ["cell_id", "p_idx", "t_idx", "rr_idx", "m_idx", "projection_pct", "trigger_ticks", "rr_min", "rmax_ticks", "valid"], rows)
    return sha256_file(path)


def selection_diagnostics(cells, metrics):
    byid = {c.cell_id: c for c in cells}
    base = metrics[BASELINE_CELL_ID]
    gate_rows = []
    rejection_rows = []
    if base["trade_count"] < 200 or base["sessions_with_trade"] < 60:
        for c in cells:
            gate_rows.append({"cell_id": c.cell_id, "gate": "BASELINE_EVIDENCE", "pass": "NO", "detail": "BASELINE_INSUFFICIENT"})
        return gate_rows, [{"cell_id": "", "reason": "BASELINE_INSUFFICIENT_EVIDENCE"}]

    for c in cells:
        m = metrics[c.cell_id]
        raw = [
            ("TRADES_GE_200", m["trade_count"] >= 200),
            ("SESSIONS_GE_60", m["sessions_with_trade"] >= 60),
            ("TRADES_GE_50PCT_BASELINE", m["trade_count"] * 2 >= base["trade_count"]),
            ("MONTHS_WITH_TRADE_GE_9", m["months_with_trade"] >= 9),
            ("NET_POSITIVE", m["net_units"] > 0),
            ("GROSS_LOSS_POSITIVE", m["pf_den"] > 0),
            ("PF_GT_1_FINITE", pf_ok(m)),
            ("MAX_DD_GT_0", m["max_dd_units"] > 0),
            ("H1_POSITIVE", m["h1_units"] > 0),
            ("H2_POSITIVE", m["h2_units"] > 0),
            ("POSITIVE_MONTHS_GE_9", m["positive_months"] >= 9),
            ("NET_WITHOUT_TOP5_POSITIVE", m["net_without_top5_units"] > 0),
            ("TOP5_CONCENTRATION_LE_40PCT", m["sum_positive_days_units"] > 0 and m["top5_positive_days_units"] * 100 <= 40 * m["sum_positive_days_units"]),
        ]
        failed = [name for name, ok in raw if not ok]
        for name, ok in raw:
            gate_rows.append({"cell_id": c.cell_id, "gate": name, "pass": "YES" if ok else "NO", "detail": ""})
        if failed:
            rejection_rows.append({"cell_id": c.cell_id, "reason": "|".join(failed)})
            continue
        nids = cell_neighbors(c, byid)
        approvals = sum(metrics[n]["net_units"] > 0 and pf_ok(metrics[n]) for n in nids)
        ns = [score(metrics[n]) if score(metrics[n]) is not None else Fraction(0, 1) for n in nids]
        req = __import__("math").ceil(2 * len(nids) / 3) if nids else 1
        sc = score(m)
        med = median(ns)
        neighbor_ok = len(nids) >= 3 and approvals >= req and sc is not None and med * 2 >= sc
        gate_rows.append({"cell_id": c.cell_id, "gate": "NEIGHBORHOOD", "pass": "YES" if neighbor_ok else "NO", "detail": f"neighbors={len(nids)} approvals={approvals} required={req}"})
        if not neighbor_ok:
            rejection_rows.append({"cell_id": c.cell_id, "reason": "NEIGHBORHOOD"})
    return gate_rows, rejection_rows


def _serialize_value(v):
    if isinstance(v, (dict, list, tuple)):
        return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    if v is None:
        return ""
    return v


def write_trades_csv(path: Path, trades: list[dict]) -> None:
    # R1R9 reference algorithm (in-memory list). Kept byte-for-byte as the
    # equivalence oracle for the R1R10 streaming writer; not used by run-a.
    fields = sorted({k for tr in trades for k in tr.keys()})
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, delimiter=";", lineterminator="\n", extrasaction="ignore")
        w.writeheader()
        for tr in sorted(trades, key=lambda x: (x.get("session", ""), int(x.get("entry_ordinal", -1)), x.get("cell_id", ""))):
            w.writerow({k: _serialize_value(tr.get(k)) for k in fields})


# ---------------------------------------------------------------------------
# R1R10 M-1/m-d: streaming access to persisted per-session trades.
# At most one session's trades are materialized at a time (for the local sort
# of TRADES_2025_ALL_CELLS.csv); no annual list exists.
# ---------------------------------------------------------------------------

def _committed_sessions(sessions) -> list[str]:
    ordered = sorted(str(s) for s in sessions)
    if len(ordered) != len(set(ordered)):
        raise ModelError("COMMITTED_SESSIONS_DUPLICATED")
    return ordered


def _session_receipt_trade_count(out: Path, session: str) -> int:
    rp = out / "sessions" / session / "session_receipt.json"
    if not rp.is_file():
        raise ModelError(f"COMMITTED_SESSION_RECEIPT_MISSING session={session}")
    obj = json.loads(rp.read_text(encoding="utf-8"))
    n = obj.get("trades")
    if isinstance(n, bool) or not isinstance(n, int) or n < 0:
        raise ModelError(f"COMMITTED_SESSION_RECEIPT_TRADES_INVALID session={session}")
    return n


def _iter_session_trades(out: Path, session: str):
    """Physical order of sessions/<session>/trades.jsonl.gz, count-checked against session_receipt.json."""
    p = out / "sessions" / session / "trades.jsonl.gz"
    if not p.is_file():
        raise ModelError(f"COMMITTED_TRADES_MISSING session={session}")
    expected = _session_receipt_trade_count(out, session)
    n = 0
    with gzip.open(p, "rt", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                n += 1
                yield json.loads(line)
    if n != expected:
        raise ModelError(f"COMMITTED_TRADES_COUNT_MISMATCH session={session} receipt={expected} got={n}")


def iter_committed_trades(out: Path, sessions):
    """Stream of all committed trades (sessions in sorted order, physical order within a session)."""
    for s in _committed_sessions(sessions):
        yield from _iter_session_trades(out, s)


def _trades_csv_sort_key(x: dict):
    # Identical expression to the R1R9 global sort key in write_trades_csv.
    return (x.get("session", ""), int(x.get("entry_ordinal", -1)), x.get("cell_id", ""))


def write_trades_csv_streaming(path: Path, out: Path, sessions) -> dict:
    """R1R10 two-pass writer, byte-identical to write_trades_csv(all trades).

    Pass 1 streams every committed trade to compute the sorted union of fields.
    Pass 2 loads one session at a time, verifies that every trade belongs to that
    session (so the per-session stable sort equals the R1R9 global stable sort),
    sorts it with the identical key and writes it incrementally.
    """
    ordered = _committed_sessions(sessions)
    field_set = set()
    for tr in iter_committed_trades(out, ordered):
        field_set.update(tr.keys())
    fields = sorted(field_set)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows_written = 0
    max_session_rows = 0
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, delimiter=";", lineterminator="\n", extrasaction="ignore")
        w.writeheader()
        for s in ordered:
            session_rows = list(_iter_session_trades(out, s))
            for tr in session_rows:
                if tr.get("session", "") != s:
                    raise ModelError(f"TRADES_CSV_SESSION_FIELD_MISMATCH dir={s} trade_session={tr.get('session')!r}")
            session_rows.sort(key=_trades_csv_sort_key)
            for tr in session_rows:
                w.writerow({k: _serialize_value(tr.get(k)) for k in fields})
            rows_written += len(session_rows)
            max_session_rows = max(max_session_rows, len(session_rows))
            session_rows = None
    return {"rows": rows_written, "fields": len(fields), "sessions": len(ordered), "max_session_rows_in_memory": max_session_rows}


def write_monthly_quarterly(out: Path, cells, metrics) -> None:
    month_rows = []
    quarter_rows = []
    for c in cells:
        vals = metrics[c.cell_id]["monthly_units"]
        for i, v in enumerate(vals, 1):
            month_rows.append({"cell_id": c.cell_id, "month": f"2025-{i:02d}", "net_units": int(v)})
        for q in range(4):
            quarter_rows.append({"cell_id": c.cell_id, "quarter": f"2025-Q{q+1}", "net_units": int(sum(vals[q*3:(q+1)*3]))})
    write_csv(out / "MONTHLY_2025.csv", ["cell_id", "month", "net_units"], month_rows)
    write_csv(out / "QUARTERLY_2025.csv", ["cell_id", "quarter", "net_units"], quarter_rows)


def materialize_ledger_dirs(out: Path, sessions: list[str]) -> None:
    event_root = out / "EVENT_LEDGER_2025"
    equity_root = out / "EQUITY_EVENTS_2025"
    event_root.mkdir(exist_ok=True)
    equity_root.mkdir(exist_ok=True)
    for s in sessions:
        src_e = out / "sessions" / s / "events.jsonl.gz"
        src_q = out / "sessions" / s / "equity.jsonl.gz"
        dst_e = event_root / f"{s}.jsonl.gz"
        dst_q = equity_root / f"{s}.jsonl.gz"
        for src, dst in ((src_e, dst_e), (src_q, dst_q)):
            if dst.exists():
                dst.unlink()
            try:
                os.link(src, dst)
            except OSError:
                shutil.copy2(src, dst)


def reconstruct_max_dd_from_persisted(out: Path, cells, sessions: list[str]) -> dict[str, int]:
    hwm = {c.cell_id: 0 for c in cells}
    maxdd = {c.cell_id: 0 for c in cells}
    for s in sorted(sessions):
        p = out / "sessions" / s / "equity.jsonl.gz"
        with gzip.open(p, "rt", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                row = json.loads(line)
                cid = row["cell_id"]
                eq = int(row["equity_units"])
                if eq > hwm[cid]:
                    hwm[cid] = eq
                dd = hwm[cid] - eq
                if dd > maxdd[cid]:
                    maxdd[cid] = dd
    return maxdd


def _metric_public(m: dict) -> dict:
    return {k: v for k, v in m.items() if k != "monthly_units"}


def write_model_assumptions(out: Path) -> None:
    obj = {
        "equity_events_persistence": "EXTREMA_LOSSLESS_FOR_DD",
        "r6_immediate_stop_same_record_lifecycle_parity": "NOT_CLAIMED",
        "broker_fill_parity": "NOT_CLAIMED",
        "broker_stops_level": "MODEL_0_POINTS_ASSUMPTION",
        "slippage_additional_ticks": 0,
        "entry_cost_brl_per_contract": "0.25",
        "exit_cost_brl_per_contract": "0.25",
    }
    write_json_atomic_canonical(out / "MODEL_ASSUMPTIONS.json", obj)


def write_static_metadata(out: Path, package_root: Path, cfg: dict, binding: dict) -> dict:
    grid_hash = write_grid_cells(out / "GRID_CELLS.csv")
    runner_hash, runner_manifest = runner_identity(package_root)
    (out / "SPEC_HASH.txt").write_text(SPEC_SHA256 + "\n", encoding="ascii")
    (out / "RUNNER_HASH.txt").write_text(runner_hash + "\n", encoding="ascii")
    write_model_assumptions(out)
    return {"grid_sha256": grid_hash, "runner_sha256": runner_hash, "runner_manifest": runner_manifest}


def economic_output_paths(out: Path) -> list[Path]:
    names = [
        "CELL_SUMMARY_2025.csv", "MONTHLY_2025.csv", "QUARTERLY_2025.csv",
        "NEIGHBORHOOD_2025.csv", "SELECTION_GATES_2025.csv", "REJECTIONS_2025.csv",
        "TRADES_2025_ALL_CELLS.csv", "PRECUTOFF_CROSSED_STATE_TELEMETRY_PHASE_A.csv",
        "EQUITY_RECONCILIATION_2025.csv", "EQUITY_LOSSLESS_GATE.json",
    ]
    paths = [out / n for n in names if (out / n).exists()]
    for root_name in ("EVENT_LEDGER_2025", "EQUITY_EVENTS_2025"):
        root = out / root_name
        if root.exists():
            paths.extend(sorted(p for p in root.rglob("*") if p.is_file()))
    return paths


def write_sha_manifest(path: Path, files: list[Path], base: Path) -> str:
    rows = []
    for p in sorted(files, key=lambda x: str(x.relative_to(base)).replace("\\", "/")):
        rel = str(p.relative_to(base)).replace("\\", "/")
        rows.append((sha256_file(p), rel))
    text = "".join(f"{h}  {rel}\n" for h, rel in rows)
    path.write_text(text, encoding="ascii", newline="\n")
    return sha256_file(path)


def finalize_phase_a(out: Path, package_root: Path, cfg: dict, cells, metrics: dict, cp: dict, binding: dict) -> dict:
    sessions = sorted(cp["completed"])
    if len(sessions) != 250:
        raise RuntimeError(f"FINALIZE_PHASE_A_REQUIRES_250_SESSIONS got={len(sessions)}")

    static = write_static_metadata(out, package_root, cfg, binding)
    selection = select_2025(cells, metrics)
    gate_rows, reject_rows = selection_diagnostics(cells, metrics)

    summary_rows = [_metric_public(metrics[c.cell_id]) for c in cells]
    write_csv(out / "CELL_SUMMARY_2025.csv", list(summary_rows[0].keys()), summary_rows)
    write_monthly_quarterly(out, cells, metrics)
    if selection.get("neighbor_rows"):
        write_csv(out / "NEIGHBORHOOD_2025.csv", list(selection["neighbor_rows"][0].keys()), selection["neighbor_rows"])
    else:
        write_csv(out / "NEIGHBORHOOD_2025.csv", ["cell_id", "neighbors", "approvals", "required", "gate"], [])
    write_csv(out / "SELECTION_GATES_2025.csv", ["cell_id", "gate", "pass", "detail"], gate_rows)
    write_csv(out / "REJECTIONS_2025.csv", ["cell_id", "reason"], reject_rows)
    write_trades_csv_streaming(out / "TRADES_2025_ALL_CELLS.csv", out, sessions)
    materialize_ledger_dirs(out, sessions)

    # Reconciliation output from per-session receipts.
    recon_rows = []
    crossed_rows = []
    for s in sessions:
        rp = out / "sessions" / s / "equity_reconciliation.jsonl.gz"
        if rp.exists():
            with gzip.open(rp, "rt", encoding="utf-8") as f:
                recon_rows.extend(json.loads(line) for line in f if line.strip())
        receipt = json.loads((out / "sessions" / s / "session_receipt.json").read_text(encoding="utf-8"))
        crossed_rows.append({"session_date": s, "policy_id": "", "precutoff_crossed_state_count": int(receipt.get("precutoff_crossed_state_count", 0))})
    write_csv(out / "EQUITY_RECONCILIATION_2025.csv", ["session", "cell_id", "open_marks_evaluated", "open_marks_persisted", "session_min_equity", "session_max_equity", "end_equity", "max_dd_to_date"], recon_rows)
    write_csv(out / "PRECUTOFF_CROSSED_STATE_TELEMETRY_PHASE_A.csv", ["session_date", "policy_id", "precutoff_crossed_state_count"], crossed_rows)

    reconstructed = reconstruct_max_dd_from_persisted(out, cells, sessions)
    mismatches = []
    for i, c in enumerate(cells):
        eng = int(cp["maxdd"][i])
        got = int(reconstructed[c.cell_id])
        if eng != got:
            mismatches.append({"cell_id": c.cell_id, "engine_max_dd": eng, "persisted_max_dd": got})
    lossless = {"status": "PASS" if not mismatches else "FAIL", "cells": len(cells), "mismatch_count": len(mismatches), "mismatches": mismatches[:100]}
    write_json_atomic_canonical(out / "EQUITY_LOSSLESS_GATE.json", lossless)
    if mismatches:
        raise RuntimeError(f"EQUITY_LOSSLESS_GATE_FAIL count={len(mismatches)}")

    econ_manifest_hash = write_sha_manifest(out / "ECONOMIC_OUTPUTS_SHA256SUMS.txt", economic_output_paths(out), out)

    baseline_gate_rows = [r for r in gate_rows if r["cell_id"] == BASELINE_CELL_ID]
    selected_id = selection.get("selected")
    selected_gate_rows = [r for r in gate_rows if r["cell_id"] == selected_id] if selected_id else None
    freeze = {
        "spec_sha256": SPEC_SHA256,
        "runner_sha256": static["runner_sha256"],
        "grid_sha256": static["grid_sha256"],
        "expected_sessions_sha256": binding["expected_sessions_sha256"],
        "session_calendar_sha256": binding["session_calendar_sha256"],
        "source_inventory_sha256": binding["source_inventory_sha256"],
        "run_source_binding_sha256": sha256_file(out / "RUN_SOURCE_BINDING_A.json"),
        "preflight_status_sha256": binding["preflight_status_sha256"],
        "status": selection["status"],
        "selected_cell_id": selected_id,
        "baseline_metrics": _metric_public(metrics[BASELINE_CELL_ID]),
        "baseline_gates": baseline_gate_rows,
        "selected_metrics": _metric_public(metrics[selected_id]) if selected_id else None,
        "selected_gates": selected_gate_rows,
        "economic_outputs_sha256sums_sha256": econ_manifest_hash,
    }
    freeze["freeze_sha256"] = canonical_json_hash(freeze)
    write_json_atomic_canonical(out / "SELECTION_FREEZE.json", freeze)
    return freeze
