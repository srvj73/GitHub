from __future__ import annotations
from pathlib import Path
from collections import defaultdict
import argparse, hashlib, json, time, math
from minotauro_v004_core import ModelError
from minotauro_v004_io import *

PHASES={"A":("2025-01-01","2025-12-31"),"B":("2026-01-01","2026-08-31"),"C":("2026-09-01","2026-09-11")}


def _fmt_eta(seconds):
    if seconds is None or seconds < 0:
        return "UNKNOWN"
    seconds=int(seconds)
    h,rem=divmod(seconds,3600)
    m,s=divmod(rem,60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def _progress_line(kind, phase, file_name, overall_bytes, total_bytes, file_bytes, file_size,
                   raw_rows, sessions_done, sessions_total, started):
    elapsed=max(time.monotonic()-started,1e-9)
    rate_bps=overall_bytes/elapsed
    pct=(100.0*overall_bytes/total_bytes) if total_bytes else 100.0
    eta=((total_bytes-overall_bytes)/rate_bps) if rate_bps>0 else None
    width=30
    filled=max(0,min(width,int(width*pct/100.0)))
    bar="#"*filled+"-"*(width-filled)
    print(
        f"{kind}_PROGRESS=[{bar}] {pct:6.2f}% "
        f"PHASE={phase} FILE={file_name} "
        f"FILE_GIB={file_bytes/1024**3:.3f}/{file_size/1024**3:.3f} "
        f"TOTAL_GIB={overall_bytes/1024**3:.3f}/{total_bytes/1024**3:.3f} "
        f"ROWS={raw_rows} SESSIONS={sessions_done}/{sessions_total} "
        f"RATE_MIB_S={rate_bps/1024**2:.2f} ETA={_fmt_eta(eta)}",
        flush=True
    )


def build_expected(m1_root: Path, phase: str, out: Path):
    start,end=PHASES[phase]
    sessions=enumerate_sessions_from_m1(m1_root,start,end)
    if not sessions:
        raise ModelError("EXPECTED_SESSION_UNIVERSE_UNAVAILABLE")
    prior=enumerate_sessions_from_m1(m1_root,"2024-01-01",end)
    pos={d:i for i,d in enumerate(prior)}
    rows=[]
    for d in sessions:
        i=pos.get(d,-1)
        if i<=0:
            raise ModelError(f"EXPECTED_PREDECESSOR_UNAVAILABLE session={d}")
        rows.append({
            "session_date":d,"expected":"YES","expected_previous_session_date":prior[i-1],
            "source_certificate_or_inventory_id":"CANONICAL_WINN_M1_SESSION_INVENTORY",
            "source_hash":"DEFERRED_TO_SOURCE_INVENTORY",
            "predecessor_evidence_id":"CANONICAL_WINN_M1_SESSION_INVENTORY",
            "predecessor_evidence_hash":"DEFERRED_TO_SOURCE_INVENTORY",
        })
    write_csv(out,list(rows[0].keys()),rows)
    return rows


def _validate_d1(rows, d1):
    failures=[]
    good=[]
    for er in rows:
        session=er["session_date"];prev=er["expected_previous_session_date"]
        if prev not in d1:
            failures.append({"session":session,"reason":"EXPECTED_D1_MISSING","detail":prev});continue
        bar=d1[prev]
        if not (bar.high_micro>bar.low_micro>0 and bar.open_micro>0 and bar.close_micro>0 and bar.low_micro<=bar.open_micro<=bar.high_micro and bar.low_micro<=bar.close_micro<=bar.high_micro):
            failures.append({"session":session,"reason":"EXPECTED_D1_OHLC_INVALID","detail":prev});continue
        good.append(er)
    return good,failures


def _nearest_rank(values:list[int], pct:int):
    if not values:
        return ""
    vals=sorted(int(v) for v in values)
    rank=max(1,math.ceil((pct/100.0)*len(vals)))
    return vals[rank-1]


def _write_cutoff_latency_diagnostics(out:Path, rows:list[dict], diag_by_session:dict, failures:list[dict]):
    failure_map=defaultdict(list)
    for f in failures:
        failure_map[f.get("session","")].append(f.get("reason",""))

    fields=[
        "row_type","session_date","direction","rank","metric","metric_value_ms",
        "first_cutoff_bid_msc","first_cutoff_ask_msc","cutoff_long_fill_msc","cutoff_short_fill_msc",
        "cutoff_long_latency_ms","cutoff_short_latency_ms","status","note",
    ]
    out_rows=[]
    for er in sorted(rows,key=lambda x:x["session_date"]):
        s=er["session_date"]
        d=diag_by_session.get(s,{})
        reasons=failure_map.get(s,[])
        out_rows.append({
            "row_type":"SESSION","session_date":s,"direction":"","rank":"","metric":"","metric_value_ms":"",
            "first_cutoff_bid_msc":d.get("first_cutoff_bid_msc","") or "",
            "first_cutoff_ask_msc":d.get("first_cutoff_ask_msc","") or "",
            "cutoff_long_fill_msc":d.get("cutoff_long_fill_msc","") or "",
            "cutoff_short_fill_msc":d.get("cutoff_short_fill_msc","") or "",
            "cutoff_long_latency_ms":d.get("cutoff_long_latency_ms","") if d.get("cutoff_long_latency_ms") is not None else "",
            "cutoff_short_latency_ms":d.get("cutoff_short_latency_ms","") if d.get("cutoff_short_latency_ms") is not None else "",
            "status":"BLOCKED" if reasons else ("PASS" if d.get("cutoff_long_fill_msc") and d.get("cutoff_short_fill_msc") else "UNRESOLVED"),
            "note":"|".join(reasons),
        })

    for direction,key in (("LONG","cutoff_long_latency_ms"),("SHORT","cutoff_short_latency_ms")):
        vals=[]
        ranked=[]
        for er in rows:
            s=er["session_date"]
            v=diag_by_session.get(s,{}).get(key)
            if v is not None:
                vals.append(int(v));ranked.append((int(v),s))
        for metric,pct in (("P50",50),("P95",95),("P99",99)):
            out_rows.append({
                "row_type":"SUMMARY","session_date":"","direction":direction,"rank":"","metric":metric,
                "metric_value_ms":_nearest_rank(vals,pct),"first_cutoff_bid_msc":"","first_cutoff_ask_msc":"",
                "cutoff_long_fill_msc":"","cutoff_short_fill_msc":"","cutoff_long_latency_ms":"",
                "cutoff_short_latency_ms":"","status":"DIAGNOSTIC_ONLY","note":"nearest-rank; missing latency=empty",
            })
        out_rows.append({
            "row_type":"SUMMARY","session_date":"","direction":direction,"rank":"","metric":"MAX",
            "metric_value_ms":max(vals) if vals else "","first_cutoff_bid_msc":"","first_cutoff_ask_msc":"",
            "cutoff_long_fill_msc":"","cutoff_short_fill_msc":"","cutoff_long_latency_ms":"",
            "cutoff_short_latency_ms":"","status":"DIAGNOSTIC_ONLY","note":"missing latency=empty",
        })
        for rank,(lat,sess) in enumerate(sorted(ranked,reverse=True)[:10],1):
            out_rows.append({
                "row_type":"TOP10","session_date":sess,"direction":direction,"rank":rank,"metric":"LATENCY",
                "metric_value_ms":lat,"first_cutoff_bid_msc":"","first_cutoff_ask_msc":"",
                "cutoff_long_fill_msc":"","cutoff_short_fill_msc":"","cutoff_long_latency_ms":"",
                "cutoff_short_latency_ms":"","status":"DIAGNOSTIC_ONLY","note":"descending latency",
            })
    write_csv(out/"CUTOFF_LATENCY_DIAGNOSTICS.csv",fields,out_rows)


def preflight_phase(cfg:dict,phase:str):
    out=Path(cfg["out_root"])/f"PHASE_{phase}";out.mkdir(parents=True,exist_ok=True)
    rows=build_expected(Path(cfg["m1_root"]),phase,out/f"EXPECTED_SESSIONS_PHASE_{phase}.csv")
    d1=load_d1(Path(cfg["ind_d1"]))
    good_rows,failures=_validate_d1(rows,d1)
    diag_by_session={er["session_date"]:{
        "first_cutoff_bid_msc":None,"first_cutoff_ask_msc":None,
        "cutoff_long_fill_msc":None,"cutoff_short_fill_msc":None,
        "cutoff_long_latency_ms":None,"cutoff_short_latency_ms":None,
    } for er in rows}

    # Group expected sessions by canonical monthly tick file. Each monthly file is scanned exactly once.
    by_file=defaultdict(list)
    for er in good_rows:
        tp=find_tick_file_for_session(Path(cfg["ticks_root"]),er["session_date"])
        by_file[tp].append(er)

    inventories=[];cal=[]
    sorted_files=sorted(by_file.items(),key=lambda kv:str(kv[0]))
    total_bytes=sum(tp.stat().st_size for tp,_ in sorted_files)
    total_sessions=len(rows)
    completed_bytes=0
    completed_sessions=0
    started=time.monotonic()

    print(f"PREFLIGHT_START phase={phase} sessions={total_sessions} monthly_files={len(sorted_files)} total_gib={total_bytes/1024**3:.3f}",flush=True)

    for tp,ers in sorted_files:
        sessions={er["session_date"] for er in ers}
        file_size=tp.stat().st_size
        print(f"MONTH_START phase={phase} file={tp.name} size_gib={file_size/1024**3:.3f} sessions={len(sessions)}",flush=True)
        state={s:{
            "found":False,"last_msc":None,"bid":0,"ask":0,"bid_msc":0,"ask_msc":0,
            "saw_cutoff_record":False,"first_cutoff_bid_msc":None,"first_cutoff_ask_msc":None,
            "cutoff_long_fill_msc":None,"cutoff_short_fill_msc":None,
        } for s in sessions}
        cutoffs={s:cutoff_msc_for_session(s) for s in sessions}
        h=hashlib.sha256()
        try:
            def progress_cb(file_bytes,raw_rows,file_size_cb,is_final):
                overall=completed_bytes+file_bytes
                _progress_line("PREFLIGHT",phase,tp.name,overall,total_bytes,file_bytes,file_size_cb,
                               raw_rows,completed_sessions,total_sessions,started)

            for rec in iter_tick_file(tp,include_sessions=sessions,hasher=h,progress_cb=progress_cb):
                st=state[rec.session];st["found"]=True
                if st["last_msc"] is not None and rec.time_msc<st["last_msc"]:
                    raise ModelError(f"TIME_MSC_REGRESSION session={rec.session} ordinal={rec.ordinal}")
                st["last_msc"]=rec.time_msc
                cutoff=cutoffs[rec.session]

                if rec.time_msc>=cutoff:
                    st["saw_cutoff_record"]=True

                # Each nonzero side updates its own causal timestamp on this physical record.
                if rec.bid_micro>0:
                    st["bid"]=rec.bid_micro;st["bid_msc"]=rec.time_msc
                    if rec.time_msc>=cutoff and st["first_cutoff_bid_msc"] is None:
                        st["first_cutoff_bid_msc"]=rec.time_msc
                if rec.ask_micro>0:
                    st["ask"]=rec.ask_micro;st["ask_msc"]=rec.time_msc
                    if rec.time_msc>=cutoff and st["first_cutoff_ask_msc"] is None:
                        st["first_cutoff_ask_msc"]=rec.time_msc

                if rec.time_msc<cutoff:
                    continue

                crossed=st["bid"]>0 and st["ask"]>0 and st["ask"]<st["bid"]
                if crossed:
                    # V005R1: invalid/crossed cutoff state is skipped; causal search continues.
                    continue

                if (st["cutoff_long_fill_msc"] is None and st["bid"]>0 and
                    st["bid_msc"]>=cutoff and st["bid_msc"]<=rec.time_msc):
                    st["cutoff_long_fill_msc"]=rec.time_msc
                if (st["cutoff_short_fill_msc"] is None and st["ask"]>0 and
                    st["ask_msc"]>=cutoff and st["ask_msc"]<=rec.time_msc):
                    st["cutoff_short_fill_msc"]=rec.time_msc
        except Exception as e:
            # One physical source failure blocks every expected session mapped to that monthly file.
            for s in sorted(sessions):
                failures.append({"session":s,"reason":"SOURCE_OR_TIME_FAILURE","detail":str(e)})
            inventories.append({"file":str(tp),"size":tp.stat().st_size,"sha256":"UNAVAILABLE_DUE_TO_SCAN_FAILURE"})
            continue
        inventories.append({"file":str(tp),"size":tp.stat().st_size,"sha256":h.hexdigest().upper()})
        completed_bytes += file_size
        completed_sessions += len(sessions)
        print(f"MONTH_SCAN_DONE phase={phase} file={tp.name} sha256={h.hexdigest().upper()} sessions={len(sessions)}",flush=True)

        er_by_session={er["session_date"]:er for er in ers}
        for s in sorted(sessions):
            st=state[s];prev=er_by_session[s]["expected_previous_session_date"];cutoff=cutoffs[s]
            diag={
                "first_cutoff_bid_msc":st["first_cutoff_bid_msc"],
                "first_cutoff_ask_msc":st["first_cutoff_ask_msc"],
                "cutoff_long_fill_msc":st["cutoff_long_fill_msc"],
                "cutoff_short_fill_msc":st["cutoff_short_fill_msc"],
                "cutoff_long_latency_ms":(st["cutoff_long_fill_msc"]-cutoff) if st["cutoff_long_fill_msc"] is not None else None,
                "cutoff_short_latency_ms":(st["cutoff_short_fill_msc"]-cutoff) if st["cutoff_short_fill_msc"] is not None else None,
            }
            diag_by_session[s]=diag
            if not st["found"]:
                failures.append({"session":s,"reason":"SESSION_MISSING_PHYSICALLY","detail":str(tp)});continue
            if not st["saw_cutoff_record"] or st["cutoff_long_fill_msc"] is None or st["cutoff_short_fill_msc"] is None:
                detail=(
                    f"saw_cutoff_record={st['saw_cutoff_record']} "
                    f"first_bid_msc={st['first_cutoff_bid_msc']} first_ask_msc={st['first_cutoff_ask_msc']} "
                    f"long_fill_msc={st['cutoff_long_fill_msc']} short_fill_msc={st['cutoff_short_fill_msc']}"
                )
                failures.append({"session":s,"reason":"CUTOFF_EXECUTION_OBSERVABILITY_UNAVAILABLE","detail":detail});continue
            cal.append({
                "session_date":s,"expected_previous_session_date":prev,"tick_file":str(tp),"cutoff_msc":cutoff,
                "first_cutoff_bid_msc":st["first_cutoff_bid_msc"],"first_cutoff_ask_msc":st["first_cutoff_ask_msc"],
                "cutoff_long_fill_msc":st["cutoff_long_fill_msc"],"cutoff_short_fill_msc":st["cutoff_short_fill_msc"],
                "cutoff_long_latency_ms":diag["cutoff_long_latency_ms"],"cutoff_short_latency_ms":diag["cutoff_short_latency_ms"],
                "status":"COMMON_ELIGIBLE",
            })

    write_json_atomic(out/"SOURCE_INVENTORY.json",{"phase":phase,"files":inventories,"monthly_tick_passes":len(by_file),"tick_scan_policy":"ONE_PHYSICAL_PASS_PER_MONTH"})
    write_json_atomic(out/"PREFLIGHT_FAILURES.json",sorted(failures,key=lambda x:(x["session"],x["reason"])))
    _write_cutoff_latency_diagnostics(out,rows,diag_by_session,failures)
    if failures:
        write_json_atomic(out/"PHASE_STATUS.json",{"phase":phase,"PHASE_DATA_STATUS":"BLOCKED","failure_count":len(failures)})
        raise ModelError(f"PHASE_DATA_STATUS=BLOCKED failures={len(failures)}")
    cal=sorted(cal,key=lambda x:x["session_date"])
    if len(cal)!=len(rows):
        raise ModelError(f"CALENDAR_CARDINALITY_MISMATCH expected={len(rows)} got={len(cal)}")
    write_csv(out/f"SESSION_CALENDAR_PHASE_{phase}.csv",list(cal[0].keys()),cal)
    write_json_atomic(out/"PHASE_STATUS.json",{"phase":phase,"PHASE_DATA_STATUS":"PASS","sessions":len(cal),"monthly_tick_passes":len(by_file)})
    return cal


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--config",required=True);ap.add_argument("--phase",choices=["A","B","C"],required=True)
    ns=ap.parse_args();cfg=json.loads(Path(ns.config).read_text(encoding="utf-8"))
    cal=preflight_phase(cfg,ns.phase);print(f"PREFLIGHT_PHASE_{ns.phase}=PASS");print(f"SESSIONS={len(cal)}")

if __name__=="__main__":main()
