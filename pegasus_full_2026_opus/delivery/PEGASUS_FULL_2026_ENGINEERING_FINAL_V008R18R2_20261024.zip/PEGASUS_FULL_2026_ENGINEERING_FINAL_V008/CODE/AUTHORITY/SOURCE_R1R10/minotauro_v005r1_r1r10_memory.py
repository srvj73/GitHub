"""MINOTAURO V005R1 R1R10 — operational memory telemetry and fail-closed memory cap.

Operational only. This module has no economic, causal, geometric, selection or
checkpoint semantics. It observes the Python process memory with standard
library facilities only (ctypes + Win32 K32GetProcessMemoryInfo on Windows,
/proc/self/status on Linux) and never interrupts the session engine: the cap is
evaluated exclusively at safe boundaries chosen by the runner (after an atomic
session commit / checkpoint write, or before a PASS artifact is emitted).
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import ctypes
import json
import os
import sys
import time

MIB = 1024 * 1024
MEMORY_CAP_EXIT_CODE = 3
MEMORY_CAP_MIB_MIN = 1
MEMORY_CAP_MIB_MAX = 1024 * 1024
TELEMETRY_SCHEMA = "MINOTAURO_V005R1_R1R10_SESSION_TELEMETRY_V1"
TELEMETRY_DIR_NAME = "TELEMETRY"

_SAMPLE_KEYS = (
    "current_working_set_bytes",
    "peak_working_set_bytes",
    "current_private_bytes",
    "peak_private_bytes",
)


class MemoryProbeError(RuntimeError):
    pass


class MemoryCapConfigError(ValueError):
    pass


class MemoryCapSafeStop(Exception):
    """Raised only at a safe boundary; the runner maps it to MEMORY_CAP_EXIT_CODE."""

    def __init__(self, row: dict):
        self.row = dict(row)
        super().__init__(safe_stop_marker(self.row))


def parse_memory_cap_mib(cfg: dict) -> int:
    """Fail-closed: pilot-a/run-a require an explicit integer cap in MiB."""
    value = cfg.get("memory_cap_mib") if isinstance(cfg, dict) else None
    if isinstance(value, bool) or not isinstance(value, int):
        raise MemoryCapConfigError(f"MEMORY_CAP_MIB_REQUIRED_INTEGER got={value!r}")
    if value < MEMORY_CAP_MIB_MIN or value > MEMORY_CAP_MIB_MAX:
        raise MemoryCapConfigError(f"MEMORY_CAP_MIB_OUT_OF_RANGE got={value}")
    return int(value)


def telemetry_path(out_root: Path, mode: str) -> Path:
    return Path(out_root) / TELEMETRY_DIR_NAME / f"{mode}_SESSION_TELEMETRY.jsonl"


def windows_counters_struct():
    """PROCESS_MEMORY_COUNTERS_EX with fixed-width DWORD (portable layout check)."""

    class PROCESS_MEMORY_COUNTERS_EX(ctypes.Structure):
        _fields_ = [
            ("cb", ctypes.c_uint32),
            ("PageFaultCount", ctypes.c_uint32),
            ("PeakWorkingSetSize", ctypes.c_size_t),
            ("WorkingSetSize", ctypes.c_size_t),
            ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
            ("QuotaPagedPoolUsage", ctypes.c_size_t),
            ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
            ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
            ("PagefileUsage", ctypes.c_size_t),
            ("PeakPagefileUsage", ctypes.c_size_t),
            ("PrivateUsage", ctypes.c_size_t),
        ]

    return PROCESS_MEMORY_COUNTERS_EX


def _probe_windows() -> dict:
    counters_type = windows_counters_struct()
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]
    get_current_process = kernel32.GetCurrentProcess
    get_current_process.argtypes = []
    get_current_process.restype = ctypes.c_void_p
    fn = getattr(kernel32, "K32GetProcessMemoryInfo", None)
    api = "K32GetProcessMemoryInfo"
    if fn is None:
        psapi = ctypes.WinDLL("psapi", use_last_error=True)  # type: ignore[attr-defined]
        fn = psapi.GetProcessMemoryInfo
        api = "GetProcessMemoryInfo"
    fn.argtypes = [ctypes.c_void_p, ctypes.POINTER(counters_type), ctypes.c_uint32]
    fn.restype = ctypes.c_int
    counters = counters_type()
    counters.cb = ctypes.sizeof(counters_type)
    if not fn(get_current_process(), ctypes.byref(counters), counters.cb):
        raise MemoryProbeError(f"MEMORY_PROBE_WINDOWS_FAILED api={api} winerror={ctypes.get_last_error()}")  # type: ignore[attr-defined]
    return {
        "current_working_set_bytes": int(counters.WorkingSetSize),
        "peak_working_set_bytes": int(counters.PeakWorkingSetSize),
        "current_private_bytes": int(counters.PrivateUsage),
        "peak_private_bytes": int(counters.PeakPagefileUsage),
        "probe": "WIN32_" + api,
    }


def _probe_linux() -> dict:
    values = {}
    with open("/proc/self/status", "r", encoding="ascii", errors="replace") as f:
        for line in f:
            key, _, rest = line.partition(":")
            if key in ("VmRSS", "VmHWM"):
                parts = rest.split()
                if len(parts) != 2 or parts[1] != "kB":
                    raise MemoryProbeError(f"MEMORY_PROBE_PROC_STATUS_FORMAT key={key}")
                values[key] = int(parts[0]) * 1024
    if "VmRSS" not in values or "VmHWM" not in values:
        raise MemoryProbeError("MEMORY_PROBE_PROC_STATUS_INCOMPLETE")
    return {
        "current_working_set_bytes": values["VmRSS"],
        "peak_working_set_bytes": values["VmHWM"],
        "current_private_bytes": None,
        "peak_private_bytes": None,
        "probe": "LINUX_PROC_SELF_STATUS",
    }


def probe_process_memory() -> dict:
    """Current/peak memory of this Python process. Raises MemoryProbeError (fail-closed)."""
    try:
        if sys.platform == "win32":
            return _probe_windows()
        if sys.platform.startswith("linux"):
            return _probe_linux()
    except MemoryProbeError:
        raise
    except Exception as e:  # pragma: no cover - platform failure path
        raise MemoryProbeError(f"MEMORY_PROBE_FAILED {type(e).__name__}:{e}") from e
    raise MemoryProbeError(f"MEMORY_PROBE_UNSUPPORTED_PLATFORM {sys.platform}")


def _validated_sample(raw: dict) -> dict:
    if not isinstance(raw, dict):
        raise MemoryProbeError("MEMORY_PROBE_SAMPLE_NOT_DICT")
    sample = {}
    for key in _SAMPLE_KEYS:
        value = raw.get(key)
        if value is None and key in ("current_private_bytes", "peak_private_bytes"):
            sample[key] = None
            continue
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise MemoryProbeError(f"MEMORY_PROBE_SAMPLE_INVALID {key}={value!r}")
        sample[key] = int(value)
    if sample["current_working_set_bytes"] <= 0:
        raise MemoryProbeError("MEMORY_PROBE_SAMPLE_INVALID current_working_set_bytes<=0")
    sample["probe"] = str(raw.get("probe", "UNKNOWN"))
    return sample


def _mib(value) -> str:
    return "NA" if value is None else f"{value / MIB:.1f}"


def observed_peak_bytes(sample: dict) -> int:
    """Conservative cap metric: max of current/peak working set and private commit."""
    return max(int(v) for k, v in sample.items() if k in _SAMPLE_KEYS and v is not None)


def safe_stop_marker(row: dict) -> str:
    return (
        "MEMORY_CAP_SAFE_STOP=YES"
        f" mode={row.get('mode')}"
        f" boundary={row.get('boundary_event')}"
        f" session={row.get('session') or 'NONE'}"
        f" sessions_done={row.get('sessions_done')}"
        f" current_ws_mib={_mib(row.get('current_working_set_bytes'))}"
        f" peak_ws_mib={_mib(row.get('peak_working_set_bytes'))}"
        f" current_private_mib={_mib(row.get('current_private_bytes'))}"
        f" peak_private_mib={_mib(row.get('peak_private_bytes'))}"
        f" observed_peak_mib={_mib(row.get('observed_peak_bytes'))}"
        f" limit_mib={row.get('cap_mib')}"
        f" limit_bytes={row.get('cap_bytes')}"
        " pass=NO recovery=RESUME_FROM_CHECKPOINT"
    )


class MemoryMonitor:
    """Per-invocation telemetry writer (append + flush + fsync per row) and boundary cap guard."""

    def __init__(self, path: Path, cap_mib: int, mode: str, probe=None, clock=None):
        if isinstance(cap_mib, bool) or not isinstance(cap_mib, int) or cap_mib < MEMORY_CAP_MIB_MIN or cap_mib > MEMORY_CAP_MIB_MAX:
            raise MemoryCapConfigError(f"MEMORY_CAP_MIB_OUT_OF_RANGE got={cap_mib!r}")
        self.path = Path(path)
        self.cap_mib = int(cap_mib)
        self.cap_bytes = int(cap_mib) * MIB
        self.mode = str(mode)
        self.probe = probe if probe is not None else probe_process_memory
        self.clock = clock if clock is not None else time.monotonic
        self.started = self.clock()
        self.pid = os.getpid()
        self.run_instance = f"{self.pid}_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')}"
        self.rows_written = 0
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _append(self, row: dict) -> None:
        line = json.dumps(row, ensure_ascii=True, sort_keys=True, separators=(",", ":")) + "\n"
        with self.path.open("a", encoding="utf-8", newline="\n") as f:
            f.write(line)
            f.flush()
            os.fsync(f.fileno())
        self.rows_written += 1

    def record(self, event: str, session: str | None = None, sessions_done: int | None = None, **extra) -> dict:
        sample = _validated_sample(self.probe())
        observed = observed_peak_bytes(sample)
        row = {
            "schema": TELEMETRY_SCHEMA,
            "event": str(event),
            "mode": self.mode,
            "session": session,
            "sessions_done": sessions_done,
            "utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
            "elapsed_s": round(float(self.clock() - self.started), 3),
            "pid": self.pid,
            "run_instance": self.run_instance,
            **sample,
            "observed_peak_bytes": observed,
            "cap_mib": self.cap_mib,
            "cap_bytes": self.cap_bytes,
            "cap_exceeded": bool(observed > self.cap_bytes),
        }
        for k, v in extra.items():
            if k not in row:
                row[k] = v
        self._append(row)
        return row

    def progress(self, session: str | None, sessions_done: int, **extra) -> dict | None:
        """Observational only (mid-session). Never stops or aborts the engine.

        A probe/telemetry failure here is reported and deferred: the next safe
        boundary() call re-probes and fails closed there if the probe is broken.
        """
        try:
            return self.record("PROGRESS", session, sessions_done, **extra)
        except Exception as e:
            print(f"MEMORY_TELEMETRY_PROGRESS_UNAVAILABLE={type(e).__name__}:{e} deferred_to=NEXT_SAFE_BOUNDARY", flush=True)
            return None

    def boundary(self, event: str, session: str | None = None, sessions_done: int | None = None) -> dict:
        """Safe boundary: telemetry row + fail-closed cap evaluation."""
        row = self.record(event, session, sessions_done)
        print(
            f"MEMORY_TELEMETRY event={event} mode={self.mode} session={session or 'NONE'} "
            f"sessions_done={sessions_done} ws_mib={_mib(row['current_working_set_bytes'])} "
            f"peak_ws_mib={_mib(row['peak_working_set_bytes'])} "
            f"private_mib={_mib(row['current_private_bytes'])} "
            f"peak_private_mib={_mib(row['peak_private_bytes'])} "
            f"cap_mib={self.cap_mib} cap_exceeded={'YES' if row['cap_exceeded'] else 'NO'}",
            flush=True,
        )
        if row["cap_exceeded"]:
            stop = dict(row)
            stop["event"] = "MEMORY_CAP_SAFE_STOP"
            stop["boundary_event"] = str(event)
            self._append(stop)
            raise MemoryCapSafeStop(stop)
        return row


def progress_suffix(row: dict | None) -> str:
    if not row:
        return ""
    return (
        f" MEM_WS_MIB={_mib(row.get('current_working_set_bytes'))}"
        f" MEM_PEAK_MIB={_mib(row.get('observed_peak_bytes'))}"
        f" MEM_CAP_MIB={row.get('cap_mib')}"
        f" MEM_CAP_EXCEEDED={'YES_STOP_AT_NEXT_SAFE_BOUNDARY' if row.get('cap_exceeded') else 'NO'}"
    )
