param([string]$Config = "$PSScriptRoot\config.json")
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Minotauro_Launcher_Common.ps1"
$TranscriptOwned = Start-MinotauroTranscript -Config $Config -LauncherName $MyInvocation.MyCommand.Name
try {
    # This launcher is intentionally fail-closed inside the runner unless
    # GATES\OWNER_PILOT_AUTHORIZATION.json binds the exact current identities.
    & "$PSScriptRoot\RUN_PHASE.ps1" -Command 'pilot-a' -Config $Config
    if ($LASTEXITCODE -ne 0) { throw "PILOT_RUN_FAIL=$LASTEXITCODE" }
    $Python=Resolve-RealPython
    $ExitCode = Invoke-MinotauroPython -Python $Python -Arguments @("$PSScriptRoot\minotauro_v005r1_r23_gates.py",'pilot-reconcile','--config',$Config)
    if ($ExitCode -ne 0) { throw "PILOT_RECONCILE_FAIL=$ExitCode" }
    $ExitCode = Invoke-MinotauroPython -Python $Python -Arguments @("$PSScriptRoot\minotauro_v005r1_r23_gates.py",'finalize','--config',$Config)
    if ($ExitCode -ne 0) { throw "PRE_RUN_GATE_FINALIZE_FAIL=$ExitCode" }
    Write-Host 'PRE_RUN_A_GATES=PASS_28_OF_28'
    Write-Host 'RUN_A_AUTHORIZED=NO_PENDING_OWNER_AND_POSTIMPLEMENTATION_AUDIT'
}
finally {
    Stop-MinotauroTranscriptSafe -Owned $TranscriptOwned
}
