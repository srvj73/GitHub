# SPEC AMENDMENT — MINOTAURO_PARAMETER_MARKET_DISCOVERY V005R1-R2.3
## Crossed-BBO pre-cutoff + preflight reuse binding + provenance/freeze + lossless DD persistence + pre-run gates

**Projeto:** PEGASUS MT5 / MINOTAURO  
**Versão:** V005R1-R2.3  
**Data:** 2026-09-25  
**Status:** FINAL_MECHANICAL_DIFF_CONFIRMATION_REQUIRED — NÃO AUTORIZA PATCH, RUN-A OU DADOS  
**Parent normativo:** `SPEC_V005R1_APPROVED.md` SHA256 `60CBE1A203C65D6C9290987B85B4F61F348FB2FAAECBCF8A211B310990D80AAF`  
**Parent imediato:** `MINOTAURO_PARAMETER_MARKET_DISCOVERY V005R1-R2.2`  
**Fonte R6:** SHA256 `1A950132E51700232D31636163EA1C98A64CF7AF1CBB4FED892AA71DEE059FA5`  
**Auditoria motivadora:** Opus 5.5 short reaudit 2026-09-25 SHA256 `86953496C6B718AB65B4E492DBF8267998DA12E60E96217CBE0B1CB511060644`  
**Owner decision preservada:** `A_M1_RESOLUTION=B1`

---

## 0. PRECEDÊNCIA, ESCOPO E NÃO-ALTERAÇÃO ECONÔMICA

Esta emenda substitui apenas o texto da V005R1-R2.2 nos pontos explicitamente enumerados abaixo. Todo contrato anterior não citado permanece idêntico.

Precedência no escopo alterado:
`V005R1-R2.3 > V005R1-R2.2 > V005R1-R2.1 > V005R1-R2 > V005R1`.

```text
R6_OPERATIONAL_SOURCE_IMMUTABLE=YES
STUDY_A_GRID_UNCHANGED=YES
SELECTION_2025_RULES_UNCHANGED=YES
N_TO_N1_UNCHANGED=YES
N1_500MS_UNCHANGED=YES
CUTOFF_V005R1_UNCHANGED=YES
COSTS_UNCHANGED=YES
A_M1_OWNER_DECISION=B1
NEW_HEAVY_PREFLIGHT_REQUIRED=NO_IF_REUSE_GATES_PASS
```

Nenhum texto desta R2.3 autoriza código, patch, processamento econômico ou seleção.

---

## 1. BBO CRUZADO PRÉ-CUTOFF — B1 PRESERVADO

### 1.1 Definição

`PRECUTOFF_CROSSED_STATE := BID>0 AND ASK>0 AND ASK<BID AND record.time_msc<cutoff_msc`, avaliado **após** as atualizações causais de BID/ASK do registro.

Esse estado:
- não aborta sessão/fase;
- não corrige BID/ASK;
- não cria midpoint/spread sintético;
- não altera calendário;
- não é gate econômico global.

### 1.2 Entrada N+1

A entrada mantém integralmente V005R1 §8.4: ambos os lados conhecidos/causais, `ASK>=BID`, idades independentes `<=500 ms`, BUY=ASK, SELL=BID, pending consumido antes do gate, falha sem N+2.

Logo, estado cruzado em N+1 rejeita aquela entrada, mas não aborta a sessão.

### 1.3 Posição preexistente

- BUY: stop, target e OPEN_MARK usam exclusivamente BID quando o lado executável é atualizado/causalmente disponível conforme o contrato herdado;
- SELL: stop, target e OPEN_MARK usam exclusivamente ASK;
- o lado oposto não participa da decisão econômica;
- crossedness do BBO não impede por si só o processamento do lado executável.

### 1.4 Cutoff

Nada muda no cutoff V005R1. Após latch, `ASK<BID` não é estado executável para cutoff; a busca causal continua dentro da mesma `session_date`, com timestamp próprio pós-cutoff e sem gate de 500 ms.

### 1.5 Telemetria operacional fechada

`PRECUTOFF_CROSSED_STATE_COUNT` = número de registros físicos da sessão com `time_msc<cutoff_msc` cujo estado causal, **após** os passos de atualização BID/ASK herdados de V005R1 §10.2, satisfaz `BID>0 AND ASK>0 AND ASK<BID`.

Publicar:
`PRECUTOFF_CROSSED_STATE_TELEMETRY_PHASE_A.csv`

Schema fixo:
`session_date;policy_id;precutoff_crossed_state_count`

- Study A: `policy_id` vazio;
- `precutoff_crossed_state_count` I64 >= 0;
- sort `session_date,policy_id`;
- diagnóstico apenas, sem gate econômico/seleção/exclusão.

---

## 2. PROVENIÊNCIA / CHECKPOINT / RESUME

### 2.1 Identidade do runner

`runner_sha256` = SHA256 de manifest canônico contendo, por caminho relativo ASCII, SHA256 de todos os módulos executáveis/launchers aplicáveis. Alteração de qualquer membro muda `runner_sha256`.

### 2.2 Checkpoint obrigatório

Cada checkpoint contém, no mínimo:
- `phase`;
- `last_committed_session_date`;
- `spec_sha256`;
- `runner_sha256`;
- `grid_sha256`;
- `preflight_status_sha256`;
- `session_calendar_sha256`;
- `expected_sessions_sha256`;
- `source_inventory_sha256`;
- `run_source_binding_sha256`;
- `config_sha256`;
- `parser_version`;
- lista/hash das sessões commitadas;
- caixa/HWM/DD necessários ao resume;
- `checkpoint_content_sha256` sobre JSON canônico sem o próprio campo de hash.

Checkpoint legado sem **qualquer** chave obrigatória acima => `RESUME_HASH_MISMATCH`.

No resume, qualquer divergência de identidade/hash vinculante => `RESUME_HASH_MISMATCH` e nenhuma sessão nova é processada.

### 2.3 Janela commit/checkpoint e órfãos

Publicação de bundle e checkpoint formam transação lógica:
- bundle final existente, mas ausente do checkpoint = órfão;
- mover para `_orphan/<session_date>__<n>`, onde `n` é o menor inteiro >=1 ainda livre;
- reprocessar a sessão desde o início;
- proibido aceitar órfão como commit implícito.

---

## 3. REAPROVEITAMENTO DO PREFLIGHT A — CONTRATO CUMULATIVO R2.3

O preflight físico de 55,3 GiB já concluído só pode ser reutilizado se **todas** as condições abaixo passarem. Qualquer falha => `PREFLIGHT_REUSE_AUTHORIZED=NO`.

### 3.1 Módulos físicos congelados

Obrigatório:

```text
minotauro_v004_preflight.py=3A2398FD86F93C1EBD8AF5C1BD64D4BC839185AC26FABA775C8152FD29750390
minotauro_v004_io.py=DC816C617AA6586828CEC769B21741D5BC4106FA8A72B933F1BE76D4E1BCAF4F
```

### 3.2 Definições importadas do core congeladas

`io.py` importa `PRICE_SCALE`, `TickRecord`, `D1Bar` e `ModelError` do `core.py`. O patch B1 pode alterar outras partes de `core.py`, mas o texto-fonte exato dessas definições deve permanecer semanticamente e textualmente congelado.

Algoritmo canônico de extração:
1. extrair a linha completa da atribuição `PRICE_SCALE`;
2. extrair a definição completa de `ModelError`;
3. extrair `TickRecord` **incluindo decorators**;
4. extrair `D1Bar` **incluindo decorators**;
5. concatenar nessa ordem, com exatamente uma linha vazia entre blocos e `\n` final;
6. UTF-8 sem BOM.

Hash R1R4 congelado do texto extraído:

```text
CORE_IMPORTED_DEFINITIONS_SHA256=5605BE8765744FAE14DD77265E17DD8E27959D40F954470005BF8A7A89DB4208
```

Depois do patch, divergência => `PREFLIGHT_REUSE_AUTHORIZED=NO`.

Teste dourado obrigatório, sem dados econômicos:
- tick físico de teste `WIN@N;2025.01.02 08:55:00;1735818900041;0.00;122360;0.00;0;0;4` deve produzir `session=2025-01-02`, `time_msc=1735818900041`, `ask_micro=122360000000`, `business=NO`;
- D1 de teste 2019-08-22 deve produzir `high_micro=102420000000`;
- D1 de teste 2019-08-23 deve produzir `low_micro=97525000000`.

### 3.3 Hash físico dos 12 arquivos de ticks

Recalcular SHA256 integral, **somente leitura e sem parsing**, dos 12 `WIN@N_ticks_2025_MM.csv` nos caminhos exatos gravados em `SESSION_CALENDAR_PHASE_A.csv`.

Cada hash deve ser igual ao hash do mesmo arquivo registrado no `SOURCE_INVENTORY.json` do preflight aprovado.

Regras:
- caminho inexistente => bloqueio;
- arquivo relocado/renomeado => bloqueio;
- sem remapeamento silencioso de caminho;
- hash diferente => bloqueio.

Esse passo é I/O puro e não reexecuta o preflight econômico/estrutural.

### 3.4 Re-derivação leve de calendário e validação D1

Em diretório separado e sem tocar artefatos congelados:
- reutilizar as funções congeladas de `minotauro_v004_preflight.py` responsáveis por `build_expected` e `_validate_d1`;
- usar M1 atual somente para rederivar o universo esperado;
- usar `IND@N.csv` atual para repetir a validação D1;
- `EXPECTED_SESSIONS` rederivado deve ser **byte-idêntico** ao congelado;
- nenhuma falha D1 é admitida.

### 3.5 Extrato D1 predecessor vinculante

Gerar `D1_PREDECESSOR_EXTRACT_PHASE_A.csv`, sort `session_date`, com colunas exatamente:

`session_date;expected_previous_session_date;open_micro;high_micro;low_micro;close_micro`

Deve conter exatamente 250 linhas de sessão 2025.

No run-a, após carregar D1, o runner deve conferir que a barra predecessor efetivamente usada por cada sessão é idêntica ao extrato. Divergência => `RUN_BLOCKED_D1_DRIFT` antes de processar economia daquela sessão.

### 3.6 RUN_SOURCE_BINDING_A.json

O binding deve registrar, no mínimo:
- hashes de `preflight.py` e `io.py`;
- `CORE_IMPORTED_DEFINITIONS_SHA256`;
- hash do manifest com os 12 hashes físicos de ticks recalculados;
- hash do `EXPECTED_SESSIONS` rederivado;
- hash do `D1_PREDECESSOR_EXTRACT_PHASE_A.csv`;
- hash/identidade do `IND@N.csv` atual validado;
- hashes dos M1 usados na rederivação;
- hash do `PHASE_STATUS.json` congelado;
- hash do `PREFLIGHT_FAILURES.json` congelado;
- hash do `SESSION_CALENDAR_PHASE_A.csv` congelado;
- hash do `EXPECTED_SESSIONS_PHASE_A.csv` congelado;
- hash do `SOURCE_INVENTORY.json` congelado;
- hash do `CUTOFF_LATENCY_DIAGNOSTICS.csv` congelado.

Os hashes das §§3.2–3.5 entram também no checkpoint e no FREEZE_A.

```text
HEAVY_55_3_GIB_PREFLIGHT_RERUN_REQUIRED=NO
LIGHTWEIGHT_HASH_AND_D1_REBIND_REQUIRED=YES
```

### 3.7 Verificação no momento do uso — obrigatória para run-a e piloto

(a) No início de toda execução, clean ou resume, o runner recalcula os SHA256 de `minotauro_v004_preflight.py`, `minotauro_v004_io.py`, `CORE_IMPORTED_DEFINITIONS`, `SESSION_CALENDAR_PHASE_A.csv`, `PHASE_STATUS.json` e `D1_PREDECESSOR_EXTRACT_PHASE_A.csv` e exige igualdade com `RUN_SOURCE_BINDING_A.json`. Divergência => `RUN_BLOCKED_BINDING_MISMATCH`; nenhuma sessão é processada.

(b) Durante a leitura econômica de cada arquivo mensal, o runner alimenta um SHA256 com **todos os bytes lidos**. Como a leitura econômica já percorre o arquivo até EOF, essa verificação não cria uma segunda leitura. Ao fim do arquivo, o SHA256 efetivamente lido deve ser igual ao hash vinculado pela §3.3. Divergência => `RUN_BLOCKED_TICK_DRIFT`: a fase inteira fica inválida, nenhum resultado é selecionável e qualquer reexecução exige novo rebind §3.3 em `out_root` limpo.

(c) Um arquivo mensal só é considerado verificado quando o SHA256 de fim de arquivo da alínea (b) foi comparado e gravado no checkpoint. Em resume, todo mês sem esse registro é relido integralmente e verificado conforme (b), ainda que todas as suas sessões já estejam commitadas.

(d) Os hashes dos módulos/definições conferidos no início e os hashes mensais efetivamente lidos durante a execução são gravados no checkpoint e em `RUN_MANIFEST.json`.

(e) A verificação desta §3.7 é vinculante também para o piloto da §6.3.

```text
USE_TIME_BINDING_CHECK=MANDATORY
CLEAN_RUN_BINDING_CHECK=MANDATORY
RESUME_BINDING_CHECK=MANDATORY
MONTHLY_TICK_HASH_DURING_ECONOMIC_READ=MANDATORY
EXTRA_FULL_FILE_READ_FOR_HASH=NO
HEAVY_PREFLIGHT_RERUN_REQUIRED=NO
```

---

## 4. FREEZE_A / SELECTION_FREEZE CONFORME

O freeze final adota **exatamente** estas chaves mínimas, com nomes fixos:
- `spec_sha256`;
- `runner_sha256`;
- `grid_sha256`;
- `expected_sessions_sha256`;
- `session_calendar_sha256`;
- `source_inventory_sha256`;
- `run_source_binding_sha256`;
- `preflight_status_sha256`;
- `status` (`SELECTED|NO_CANDIDATE|INSUFFICIENT_EVIDENCE|PHASE_DATA_BLOCKED`);
- `selected_cell_id` nullable;
- `baseline_metrics`;
- `baseline_gates`;
- `selected_metrics` nullable;
- `selected_gates` nullable;
- `economic_outputs_sha256sums_sha256`;
- `freeze_sha256`.

`grid_sha256` := SHA256 de `GRID_CELLS.csv` canônico com exatamente 450 linhas ordenadas por `CELL_ID`, colunas:

`cell_id;p_idx;t_idx;rr_idx;m_idx;projection_pct;trigger_ticks;rr_min;rmax_ticks;valid`

Serialização canônica de `GRID_CELLS.csv`:
- UTF-8 sem BOM;
- separador `;`;
- terminador de linha `\n`;
- cabeçalho obrigatório exatamente como acima;
- `projection_pct` em DECIMAL canônico V002R2: `38.2`, `50`, `61.8`;
- `rmax_ticks` vazio quando `OFF`;
- `valid` exatamente `YES` ou `NO`;
- todos os inteiros sem zeros à esquerda;
- nenhuma coluna adicional.

`freeze_sha256` é calculado sobre conteúdo canônico sem o próprio campo. Timestamp operacional, se existir fora do hash econômico, não participa do conteúdo canônico.

Ausência de qualquer chave => freeze não conforme e qualquer consumidor B/C deve bloquear.

---

## 5. OUTPUTS STUDY A E PERSISTÊNCIA LOSSLESS PARA MAX DD

Antes de `RUN_A_COMPLETE`, produzir os artefatos obrigatórios da V005R1 §19, incluindo `RUN_MANIFEST.json`, `MODEL_ASSUMPTIONS.json`, `GRID_CELLS.csv`, hashes, métricas agregadas, ledgers/trades e `SELECTION_FREEZE.json` conforme §4.

### 5.1 EQUITY_EVENTS_2025 — contrato R2.3

Persistir por célula e em ordem causal:

**A. Todos os subeventos de entrada/realização**
- `ENTRY_OPEN_MARK`;
- `IMMEDIATE_STOP_POST_REALIZATION`;
- `PREEXISTING_EXIT_POST_REALIZATION`;
- `CUTOFF_CLOSE_POST_REALIZATION`.

**B. OPEN_MARK extremos, sem perda para max DD**
HWM e “mínimo desde o HWM” são avaliados sobre a **curva primária completa**, contendo todos os subeventos normativos, inclusive os eventos do grupo A acima.

Persistir todo `OPEN_MARK` que satisfaça **estritamente** uma das condições:
1. `equity > HWM_corrente` da curva primária completa; **ou**
2. `equity < menor_equity_desde_o_HWM_corrente` da curva primária completa.

Igualdade não persiste o `OPEN_MARK`. Após cada subevento normativo, inclusive os do grupo A, os estados de HWM e menor equity do regime são atualizados na ordem causal. A projeção B00 da V002R2 deve aplicar exatamente esta mesma regra.

Esse subconjunto é rotulado `EXTREMA_LOSSLESS_FOR_DD`.

**C. Reconciliação sessão × célula**
Uma linha por sessão × célula com, no mínimo:
- `open_marks_evaluated`;
- `open_marks_persisted`;
- `session_min_equity`;
- `session_max_equity`;
- `end_equity`;
- `max_dd_to_date`.

### 5.2 Gate matemático de losslessness

Para cada uma das 435 células:
- `max_dd` recalculado somente a partir dos eventos persistidos em 5.1 A+B deve ser **exatamente igual** ao max DD calculado pelo engine completo;
- divergência => fase inválida e nenhum resultado selecionável.

A razão de correção é estrutural: entre HWMs sucessivos, o DD máximo depende do HWM do regime e do menor equity observado desde esse HWM; pontos que não são novo HWM nem novo mínimo do regime não podem aumentar o máximo DD.

### 5.3 Persistência integral de validação

Persistência **integral, sem filtro**, de todos os `OPEN_MARK` é obrigatória apenas:
- para a célula baseline em todo 2025; e
- para **todas** as células nas sessões do piloto pré-registrado da §6.3.

Essa persistência integral serve como evidência/golden para provar a equivalência da regra `EXTREMA_LOSSLESS_FOR_DD`.

### 5.4 MODEL_ASSUMPTIONS

Obrigatório:

```text
equity_events_persistence=EXTREMA_LOSSLESS_FOR_DD
r6_immediate_stop_same_record_lifecycle_parity=NOT_CLAIMED
```

Após `IMMEDIATE_STOP` em N+1, o mesmo registro pode processar novo sinal conforme a ordem normativa do replay; não alegar paridade literal de lifecycle da R6.

---

## 6. 28 GATES / FIXTURES ANTES DO FULL RUN-A

A V005R1 §22 permanece vinculante: **nenhum full-run econômico antes dos 28 gates** com resultados esperados e evidência owner-PC.

Continuam explicitamente obrigatórios: fronteiras Eq/trigger/RR/Rmax, stop em gap, target com salto, entry+immediate stop, busy/ambiguidade, caixa/equity/HWM/DD, baseline insuficiente, PF INF/UNDEFINED, DD zero, CELL_ID/desempate, isolamento A/B/C, SAFE_STOP, clean×resume e piloto local.

### 6.1 Fixture R6-double × replay-exato

O lado R6 deve ser produzido por **cópia verbatim** das rotinas `RoundTick`/`AddLine`/`SortDedup`/`BuildGrid` executada no **MT5 com `double`**. Emulação Python é apenas verificação secundária declarada.

Incluir:
- casos construídos em/ao redor de meio tick;
- D1 reais de 2024 fora da seleção;
- **as 250 grades predecessoras de 2025 × 3 projections**, usando apenas D1/calendário, sem P&L.

Publicar `GEOMETRY_PARITY_2025.csv` com, no mínimo:
`session_date;projection_pct;r6_line_count;replay_line_count;divergent_line_count;status`.

Qualquer divergência de linha => `GEOMETRY_PARITY_REVIEW_REQUIRED`; run-a continua bloqueado até decisão documental.

### 6.2 Gate 97 linhas

Para cada sessão esperada 2025 × 3 projections, exigir 97 linhas. Falha => bloqueio.

Os hashes/resultados de §§6.1–6.2 entram em `RUN_MANIFEST.json` e `RUN_SOURCE_BINDING_A.json`.

### 6.3 Piloto pré-registrado §22.28

Piloto fixo = **as três primeiras sessões** de `SESSION_CALENDAR_PHASE_A.csv`.

Reconciliação obrigatória:
- recomputação independente de todos os trades da célula baseline; e
- recomputação independente do primeiro trade de cada célula em cada sessão piloto, definido por menor `entry_ordinal`, com desempate por `CELL_ID` ASCII.

Correção de código pós-piloto só pode restaurar conformidade à SPEC, com diff auditado; nunca pode alterar regra econômica/seleção.

---

## 7. FASES POSTERIORES

Fases 2026 da V005R1 continuam não implementadas/autorizadas até seus gates §17/§18 e `CONFIRMATION_GATE.json` existirem.

---

## 8. STATUS R2.3

```text
V005R1_R2_3_DOCUMENTAL_STATUS=MECHANICAL_DIFF_CONFIRMATION_REQUIRED
A_M1_B1_SEMANTICS=FROZEN
PREFLIGHT_REUSE_CONTRACT=REVISED
HEAVY_55_3_GIB_PREFLIGHT_RERUN_REQUIRED=NO
LIGHTWEIGHT_HASH_AND_D1_REBIND_REQUIRED=YES
CHECKPOINT_PROVENANCE=FROZEN
FREEZE_A_CONTRACT=FROZEN
EQUITY_PERSISTENCE=EXTREMA_LOSSLESS_FOR_DD
SECTION22_GATE_PLAN=FROZEN
R1R4_PATCH_IMPLEMENTATION_AUTHORIZED=NO_PENDING_FINAL_MECHANICAL_CONFIRMATION
RUN_A_AUTHORIZED=NO
DATA_PROCESSING_AUTHORIZED=NO
```

## 9. CONFIRMAÇÃO FINAL EXIGIDA DO AUDITOR

Escopo da confirmação: **somente** conferir o diff R2.2 → R2.3, verificando as novas alíneas §3.7(a) e §3.7(c), as correções editoriais de referência/rótulo e a inexistência de qualquer outra mudança normativa.

Não reabrir contratos econômicos já aprovados sem identificar nova contradição concreta.

Confirmação mecânica obrigatória:
- §3.7(a) deve coincidir literalmente com o texto corretivo do parecer Opus R2.2;
- §3.7(c) deve coincidir literalmente com o texto corretivo do parecer Opus R2.2;
- `R21-m1` e `R21-m2` permanecem fechados e não devem ser reabertos sem nova contradição concreta;
- §5.3 deve apontar para §6.3;
- rótulos residuais R2.1 devem estar corrigidos para R2.3 onde descrevem a versão corrente;
- nenhuma outra regra econômica, causal, estatística, de seleção ou escopo pode mudar.

Formato obrigatório:

```text
OPUS55_V005R1R23_FINAL_MECHANICAL_CONFIRMATION=PASS|PASS_WITH_BLOCKERS|FAIL
R21_M1_USE_TIME_BINDING_CLOSED=YES|NO
R21_M1_FALSE_PASS_REMAINING=0|<n>
R21_m1_EXTREMA_DETERMINISM_CLOSED=YES|NO
R21_m2_GRID_SERIALIZATION_CLOSED=YES|NO
HEAVY_55_3_GIB_PREFLIGHT_RERUN_REQUIRED=NO|YES
CRITICAL_FINDINGS=<n>
MAJOR_FINDINGS=<n>
MINOR_FINDINGS=<n>
R1R4_PATCH_IMPLEMENTATION_AUTHORIZED=YES|NO
RUN_A_AUTHORIZED=NO
DATA_PROCESSING_AUTHORIZED=NO
```

Se `R1R4_PATCH_IMPLEMENTATION_AUTHORIZED=NO`, enumerar exclusivamente o(s) caminho(s) de falso-pass ainda abertos e a correção textual mínima. Não escrever código nem processar dados.
