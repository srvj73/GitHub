# R1R10 — RELATÓRIO DE CONFORMIDADE CORRETIVA

- **Fonte dos requisitos:**
  - `AUDIT_OPUS55_R1R9_POSTPILOT_FINAL_20260926.md` §7;
  - handoff builder `02_R1R10_CHANGE_SPEC.md` e `03_ACCEPTANCE_AND_EVIDENCE.md`.
- **Referências:** as linhas citadas são da árvore R1R10. Os testes estão em `test_minotauro_v005r1_r23_operational.py` (gate operacional), salvo indicação em contrário.

> **Conflito de interesse declarado:** o modelo que implementou esta revisão (Opus 5.5, no papel de builder) também redigiu a auditoria 25 que prescreveu os requisitos. A auditoria de diff R1R9→R1R10 precisa, portanto, ser **independente** deste builder.

## 1. Mapeamento da auditoria 25, §7

### §7.1 — Acúmulo de trades
**Status: PASS**

- **Remoção do acúmulo:**
  - `runner.py` l.351: `_commit_session` sem o parâmetro `trades`; o `trades.extend` foi removido.
  - l.650, 666 e 673: `res = None; eng = None` após cada commit.
- **Resume sem recarga:**
  - `runner.py` l.417-427: `_verify_committed_trades_present` faz só a checagem de existência.
  - l.583: chamada no resume.
- **Métricas em stream:**
  - `runner.py` l.727: `aggregate_phase(cells, iter_committed_trades(out, sorted(done)), maxdd)`.
  - `metrics.py` byte-idêntico.
- **CSV em streaming:**
  - `outputs.py` l.147-222 (`iter_committed_trades`, `write_trades_csv_streaming`).
  - `finalize_phase_a` l.328.
- **Testes:**
  - `test_r1r10_b1_metrics_list_vs_stream_identical`
  - `test_r1r10_b2_*` (3 testes)
  - `test_r1r10_finalize_equals_r1r9_list_algorithm`
  - `test_r1r10_c_*`
  - `test_r1r10_commit_releases_trades_after_checkpoint`

### §7.2 — Telemetria de memória
**Status: PASS (runtime Windows pendente)**

- **Implementação:**
  - `memory.py` l.86-145 (probe Win32/Linux) e l.193-275 (`MemoryMonitor`).
  - `runner.py` l.607-732: fronteiras de telemetria.
  - `runner.py` l.632-633: sufixo `MEM_*` na linha `RUN_PROGRESS`.
  - Arquivo `<out_root>/TELEMETRY/<MODE>_SESSION_TELEMETRY.jsonl`.
- **`session_receipt.json`:** inalterado; os 15 arquivos de sessão do piloto sintético são byte-idênticos aos da R1R9.
- **Testes:**
  - `test_r1r10_b4_telemetry_rows_flushed_and_fsynced_incrementally`
  - `test_r1r10_b4_run_a_telemetry_per_session`
  - `test_r1r10_live_process_probe_on_this_platform`
  - `test_r1r10_windows_counters_layout`

### §7.3 — Teto de memória
**Status: PASS**

- **Implementação:**
  - `memory.py` l.51-58 (`parse_memory_cap_mib`, fail-closed) e l.256-274 (`boundary`).
  - `runner.py` l.576: o cap é exigido antes de `_prepare_phase`.
  - `runner.py` l.772-775: exit 3.
  - `RUN_PHASE.ps1` l.16.
- **Testes:**
  - `test_r1r10_b5_b6_b3_cap_stop_mid_month_then_resume_identical_no_global_load`
  - `test_r1r10_cap_stop_at_month_and_finalize_boundaries_then_resume_identical`
  - `test_r1r10_pilot_435_cells_cap_stop_resume_session_files_identical`
  - `test_r1r10_main_exit_code_3_marker_no_pass_with_real_probe`
  - `test_r1r10_main_missing_cap_is_blocked_exit_2`
  - `test_r1r10_cap_config_fail_closed`
  - `test_r1r10_boundary_cap_exceeded_raises_safe_stop_marker`

### §7.4 — Progresso ao vivo
**Status: PASS na evidência secundária (PS 7.4.6); PS 5.1 pendente no owner**

- **Implementação:**
  - `Minotauro_Launcher_Common.ps1` l.59-97 (`Invoke-MinotauroNative`) e l.99-115 (`-u`).
  - `RUN_SYNTHETIC_GATES.ps1` l.10-16.
  - `R1R10_LAUNCHER_SELFTEST.ps1`: 16 verificações.
- **Evidência:**
  - `BUILD_SELFTEST_LOG_R1R10.txt` §6: PASS em pwsh 7.4.6.
  - O controle negativo com a semântica R1R9 falha no check `LIVE_STDOUT_BEFORE_PROCESS_EXIT`.

### §7.5 — Rótulo
**Status: PASS**

- `RUN_PHASE.ps1` l.12.
- Teste: `test_r1r10_identity_labels_and_exit_codes`.

## 2. Evidência corretiva, auditoria 25 §7(a)–(d)

| Item | Estado no builder |
|---|---|
| (a) Auditoria de diff; congelados; testes sintéticos de teto e de equivalência stream × código atual | Pacote pronto. `FROZEN_FILES_IDENTITY_R1R10.json` (9/9 PASS), testes B1–B6 e diferencial R1R9×R1R10 (LOG §7). A auditoria independente está **pendente**. |
| (b) Cadeia completa em `out_root` novo | Não executada, pois é proibida ao builder. O `config.example.json` já aponta para `…_R1R10`. |
| (c) 15 arquivos de sessão byte-idênticos aos da R1R9 (`05_…SHA256SUMS`) | Não executável sem dados reais. **Equivalente sintético:** piloto de 435 células, R1R9 × R1R10, com os 15 arquivos idênticos, inclusive após uma parada por teto seguida de resume (LOG §7 e teste `test_r1r10_pilot_435_…`). |
| (d) Nova auditoria pós-piloto com memória medida | Pendente. A telemetria necessária foi implementada. |

## 3. Mapeamento da change-spec (02) e da aceitação (03)

| Requisito | Evidência | Status |
|---|---|---|
| 02 §2.1 — 5 artefatos por sessão; nada retido após o checkpoint | `_commit_session` inalterado exceto pela remoção do sink; diferencial sintético com `sessions/**` byte-idêntico | PASS |
| 02 §2.2 — resume só por checkpoint/receipts | `_verify_committed_trades_present`; instrumentação de `gzip.open` mostra **zero leituras de `trades.jsonl.gz` antes de `PRE_FINALIZE`** | PASS |
| 02 §2.3 — métricas em iterador, igual à lista; `metrics.py` byte-idêntico | B1; `aggregate_phase` recebe um `generator` (espião no teste de resume) | PASS |
| 02 §2.4 — CSV byte-idêntico; ≤1 sessão em memória | B2 (casos de borda + aleatório + fail-closed); `max_session_rows_in_memory` | PASS |
| 02 §3 — telemetria por sessão, arquivo separado, flush, auditável após crash | append + flush + `os.fsync` por linha; o teste conta as chamadas de fsync; após a parada, o arquivo termina em `MEMORY_CAP_SAFE_STOP` | PASS |
| 02 §4 — teto: fronteira, nunca PASS, checkpoint consistente, exit próprio, marcador, resume sem recarga, sem kill assíncrono | Fronteiras exclusivamente pós-commit ou pré-PASS; exit 3; marcador `MEMORY_CAP_SAFE_STOP=YES … current/peak/limit … pass=NO`; `progress()` nunca aborta o engine | PASS |
| 02 §5 — stdout/stderr ao vivo, host + transcript, exit como autoridade, sem falso PASS | Autoteste (16 checks) + controle negativo + harness de cadeia aninhada (LOG §6) | PASS secundário; PS 5.1 pendente |
| 02 §6 — rótulo R1R8 | `RUN_PHASE.ps1` l.12; teste estático | PASS |
| 02 §7 — congelados; gates não relaxados | 9/9 congelados byte-idênticos. O único teste existente alterado foi o de operacional, 4 linhas: remoção do argumento `trades`, sem asserção alterada. | PASS |
| 02 §8 — `out_root` novo; sem promoção de receipts; MT5 só com `E28EE2F1…` | `config.example.json`; o README documenta a condição do MT5; o builder não executou nada | PASS |
| 03 A — tabela de byte-identidade | `FROZEN_FILES_IDENTITY_R1R10.json` | PASS |
| 03 B1–B6 | Testes Python listados acima | PASS |
| 03 B7–B10 | `R1R10_LAUNCHER_SELFTEST.ps1` | PASS secundário (pwsh 7.4.6); PS 5.1 pendente |
| 03 C — memória limitada | §4 abaixo + testes estruturais (AST) + instrumentação | PASS |
| 03 D — identidades | `IMPLEMENTATION_RECEIPT_R1R10.json`; `RUNNER_VERSION` R1R10; manifests; config | PASS |
| 03 E — entregáveis | ZIP com árvore, `SHA256SUMS`, patch, changelog, receipt, frozen JSON, log e este relatório | PASS |
| 03 F — estado final | `RUN_A_AUTHORIZED=NO`; `PILOT_A_AUTHORIZED=NO`; `READY_FOR_INDEPENDENT_DIFF_AUDIT=YES` | PASS |

## 4. Prova estrutural de memória limitada (03 C)

### Estado que não existe mais

No caminho `run-a`:

- nenhuma lista anual de trades;
- nenhuma chamada de recarga no resume;
- `finalize` com streaming e no máximo **uma sessão** de trades materializada, para a ordenação local do CSV.

### Coleções globais remanescentes

Todas têm cardinalidade limitada por 435 células, 250 sessões, 12 meses ou metadados.

**Runner**

| Objeto | Cardinalidade |
|---|---|
| `rows` | 250 |
| `d1_extract` | 250 |
| `d1` | histórico `IND@N` (metadado, independe da execução) |
| `cells` | 435 |
| `cp` | 6 listas × 435, `completed` ≤ 250, `verified_months` ≤ 12 |
| `done` | ≤ 250 |
| `by_file` / `sorted_files` / `tick_hash_map` / `active_files` | ≤ 12 meses |
| `row_by_session`, `expected_prefixes`, `_PrefixHashTracker.checked` | ≤ sessões de um mês |
| `binding` | metadado |
| `eng` / `res` | **uma sessão**, liberada após o commit; o conteúdo interno é do engine congelado |
| `files_for_master` | ≈ 1.770 paths |

**Finalize**

| Objeto | Cardinalidade |
|---|---|
| `metrics` e o `bycid` interno de `aggregate_phase` | 435 × (set ≤ 250, mensal 12, diário ≤ 250) |
| `field_set` | união das chaves, ~45 |
| `session_rows` | uma sessão |
| `gate_rows` | 435 × 14 |
| `reject_rows` / `summary_rows` | ≤ 435 |
| `month_rows` | 435 × 12 |
| `quarter_rows` | 435 × 4 |
| `crossed_rows` | 250 |
| `hwm` / `maxdd` | 435 |
| `economic_output_paths` | ≈ 510 |

**`recon_rows`**

- Até 435 × 250 = 108.750 dicts escalares (8 campos), vindos de `equity_reconciliation`.
- É limitado por células × sessões e **inalterado em relação à R1R9**.
- Fica listado por transparência.

### Pico intra-sessão

- É determinado pelo engine congelado (`SessionEngine`) e não é alterável na R1R10.
- A telemetria `PROGRESS` o registra.
- O teto o avalia na fronteira seguinte.

## 5. Diferencial sintético R1R9 × R1R10 (evidência do builder, LOG §7)

**Cenário do `run-a`**

- Mesmos arquivos de tick sintéticos: 250 sessões, 12 meses, 3 células e 400 trades (CUTOFF/STOP).
- `run_phase_a` real com `_prepare_phase` substituído por mock.

**Resultados**

- R1R10 limpo = R1R10 com parada por teto na sessão 100 + resume = R1R10 com KeyboardInterrupt na sessão 100 + resume. Árvore `PHASE_A` 100% idêntica, 1.770 arquivos.
- R1R9 limpo × R1R10 diferem **somente** em arquivos vinculados à identidade do runner:
  - `RUNNER_HASH.txt`;
  - `RUN_MANIFEST.json` (`runner_version`);
  - `SELECTION_FREEZE.json` (`runner_sha256`, `freeze_sha256`);
  - `SHA256SUMS.txt`, apenas nas 3 linhas correspondentes.
- Todos os outputs econômicos são idênticos, inclusive:
  - `TRADES_2025_ALL_CELLS.csv`;
  - `CELL_SUMMARY_2025.csv`;
  - `ECONOMIC_OUTPUTS_SHA256SUMS.txt`;
  - `CHECKPOINT.json`;
  - `sessions/**`.

**Cenário do piloto**

- 435 células, com integral completo.
- R1R9 × R1R10: os 15 arquivos de sessão são idênticos. Diferem apenas `RUN_MANIFEST.json` (`runner_version`) e `PILOT_RUN_RECEIPT.json` (`run_manifest_sha256`).

## 6. Limitações

1. **Windows PowerShell 5.1:** não disponível no builder.
   - A evidência de B7–B10 é secundária (pwsh 7.4.6, Linux).
   - A prova primária é o autoteste no PC do owner, dentro do `RUN_SYNTHETIC_GATES.ps1`, e ele é fail-closed.
2. **Probe Win32:** chamada real não executada no builder.
   - É exercida pelos testes operacionais no PC do owner.
   - Uma falha do probe → exit 2, gate operacional FAIL (fail-closed).
3. **Python:** builder em 3.11.15 e 3.14.0rc2 (uv). O owner usa 3.14 final.
4. **Teto de memória:** é um guarda de fronteira, não um limite rígido. Não protege contra OOM dentro de uma única sessão, e o `SessionEngine` é congelado.
5. **`memory_cap_mib`:**
   - Integra o `config_sha256` do checkpoint.
   - Alterá-lo durante uma fase em andamento provoca `RESUME_HASH_MISMATCH` (fail-closed, sem mudança na semântica de checkpoint).
   - Alterá-lo entre o piloto concluído e o `run-a` não afeta receipts.
   - Se `POST_FINALIZE` exceder o teto de forma reprodutível, o resume repete o finalize. A decisão passa a ser do owner/auditoria, com novo teto em cadeia nova.
6. **Reconciliação do GATE28:** executada pelo `minotauro_v005r1_r23_gates.py`, que é congelado. Não tem telemetria nem teto, fora do escopo da R1R10.
7. **O-5 (Ctrl+C sob saída redirecionada):** continua não exercitado.
