from __future__ import annotations
from decimal import Decimal
from pathlib import Path
from datetime import datetime, timezone, timedelta
import csv, hashlib, json, os
from typing import Iterator, Optional

from minotauro_v004_core import TickRecord, D1Bar, PRICE_SCALE, ModelError

BRT = timezone(timedelta(hours=-3))
BAR_HEADER = ["symbol","timeframe","date","time","open","high","low","close","tick_count","volume","volume_real","first_msc","last_msc"]
IND_D1_HEADER = ["data","abertura","maxima","minima","fechamento","financeiro","contratos"]


def sha256_file(path: Path, chunk: int = 8*1024*1024) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(chunk), b""):
            h.update(b)
    return h.hexdigest().upper()


def price_to_micro(text: str) -> int:
    d=Decimal(text.strip() or "0")
    q=d*PRICE_SCALE
    if q != q.to_integral_value():
        raise ModelError(f"PRICE_MORE_THAN_6_DECIMALS value={text!r}")
    return int(q)


def date_time_to_epoch_ms_floor(date_time: str) -> int:
    dt=datetime.strptime(date_time.strip(), "%Y.%m.%d %H:%M:%S").replace(tzinfo=BRT)
    return int(dt.timestamp())*1000


def session_from_date_time(date_time: str) -> str:
    return datetime.strptime(date_time[:10], "%Y.%m.%d").date().isoformat()


def cutoff_msc_for_session(session: str) -> int:
    dt=datetime.strptime(session+" 18:03:00", "%Y-%m-%d %H:%M:%S").replace(tzinfo=BRT)
    return int(dt.timestamp())*1000


def _split_semicolon_bytes(line: bytes) -> list[str]:
    return [x.decode("utf-8","strict").strip() for x in line.rstrip(b"\r\n").split(b";")]


def parse_tick_fields(fields: list[str], ordinal: int) -> TickRecord:
    if len(fields)!=9:
        raise ModelError(f"TICK_FIELD_COUNT expected=9 got={len(fields)}")
    symbol,date_time,time_msc,bid,ask,last,volume,volume_real,flags=fields
    if symbol != "WIN@N":
        raise ModelError(f"TICK_SYMBOL_UNEXPECTED symbol={symbol!r}")
    session=session_from_date_time(date_time)
    msc=int(time_msc)
    if msc//1000 != date_time_to_epoch_ms_floor(date_time)//1000:
        raise ModelError(f"TIME_SEMANTICS_MISMATCH ordinal={ordinal} date_time={date_time} time_msc={msc}")
    return TickRecord(
        session=session, ordinal=ordinal, date_time=date_time, time_msc=msc,
        bid_micro=price_to_micro(bid), ask_micro=price_to_micro(ask),
        last_micro=price_to_micro(last), volume=float(Decimal(volume or "0")),
        volume_real=float(Decimal(volume_real or "0")), flags=int(flags or "0")
    )


def iter_tick_file(path: Path, include_sessions: Optional[set[str]]=None, hasher=None,
                   progress_cb=None, progress_step_bytes: int=256*1024*1024) -> Iterator[TickRecord]:
    """Physical-order iterator.

    If include_sessions is provided, rows outside that set are ignored without imposing
    out-of-scope semantic validation. A supplied hashlib object is updated for every raw byte read.

    progress_cb, when supplied, is called as:
        progress_cb(bytes_read, raw_rows_read, file_size, is_final)
    It is observational only and does not alter filtering or economics.
    """
    ordinal_by_session={}
    file_size=path.stat().st_size
    bytes_read=0
    raw_rows_read=0
    next_report=max(1,int(progress_step_bytes))
    last_reported=-1

    with path.open("rb") as f:
        first=True
        for raw in f:
            bytes_read += len(raw)
            raw_rows_read += 1
            if hasher is not None:
                hasher.update(raw)

            if progress_cb is not None and bytes_read >= next_report:
                progress_cb(bytes_read,raw_rows_read,file_size,False)
                last_reported=bytes_read
                while next_report <= bytes_read:
                    next_report += max(1,int(progress_step_bytes))

            if not raw.strip():
                continue
            fields=_split_semicolon_bytes(raw)
            if first and fields and fields[0].lower()=="symbol":
                first=False
                continue
            first=False
            if len(fields)!=9:
                # Field-count corruption is physical source corruption and cannot be scoped away safely.
                raise ModelError(f"TICK_FIELD_COUNT file={path} got={len(fields)}")
            try:
                session=session_from_date_time(fields[1])
            except Exception as e:
                raise ModelError(f"TICK_DATE_PARSE file={path} value={fields[1]!r}") from e
            if include_sessions is not None and session not in include_sessions:
                continue
            ordinal_by_session[session]=ordinal_by_session.get(session,0)+1
            yield parse_tick_fields(fields, ordinal_by_session[session])

    if progress_cb is not None and (last_reported != bytes_read or bytes_read == 0):
        progress_cb(bytes_read,raw_rows_read,file_size,True)


def read_m1_bar_csv(path: Path) -> list[dict]:
    """Canonical headerless WIN@N_M1 physical schema (13 semicolon-delimited fields), with optional header support."""
    rows=[]
    with path.open("r",encoding="utf-8-sig",newline="") as f:
        first=f.readline()
        if not first:
            return rows
        ff=[x.strip() for x in first.rstrip("\r\n").split(";")]
        has_header=ff and ff[0].lower()=="symbol"
        if has_header:
            header=[x.lower() for x in ff]
            if header != BAR_HEADER:
                raise ModelError(f"M1_HEADER_UNEXPECTED file={path} header={header}")
        else:
            header=BAR_HEADER
            if len(ff)!=len(header):
                raise ModelError(f"BAR_FIELD_COUNT file={path} got={len(ff)}")
            rows.append(dict(zip(header,ff)))
        for line in f:
            if not line.strip():
                continue
            vals=[x.strip() for x in line.rstrip("\r\n").split(";")]
            if len(vals)!=len(header):
                raise ModelError(f"BAR_FIELD_COUNT file={path} got={len(vals)}")
            rows.append(dict(zip(header,vals)))
    return rows


def load_d1(path: Path) -> dict[str,D1Bar]:
    """Canonical IND@N D1 parser: comma-delimited Portuguese header.
    Expected physical header: data,abertura,maxima,minima,fechamento,financeiro,contratos
    """
    out={};dup=set()
    with path.open("r",encoding="utf-8-sig",newline="") as f:
        reader=csv.DictReader(f,delimiter=",")
        if reader.fieldnames is None:
            raise ModelError("IND_D1_HEADER_MISSING")
        header=[x.strip().lower() for x in reader.fieldnames]
        if header != IND_D1_HEADER:
            raise ModelError(f"IND_D1_HEADER_UNEXPECTED header={header}")
        for raw in reader:
            r={str(k).strip().lower():(v or "").strip() for k,v in raw.items()}
            date=r["data"]
            try:
                datetime.strptime(date,"%Y-%m-%d")
            except Exception as e:
                raise ModelError(f"IND_D1_DATE_INVALID date={date!r}") from e
            bar=D1Bar(date,price_to_micro(r["abertura"]),price_to_micro(r["maxima"]),price_to_micro(r["minima"]),price_to_micro(r["fechamento"]))
            if date in out: dup.add(date)
            out[date]=bar
    if dup:
        raise ModelError("D1_DUPLICATE_DATES "+",".join(sorted(dup)))
    if not out:
        raise ModelError("IND_D1_EMPTY")
    return out


def enumerate_sessions_from_m1(root: Path, start: str, end: str) -> list[str]:
    sessions=set()
    start_ym=start[:7].replace("-","_");end_ym=end[:7].replace("-","_")
    for p in sorted(root.glob("WIN@N_M1_*.csv")):
        name=p.stem
        ym=name[-7:]
        if ym < start_ym or ym > end_ym:
            continue
        for r in read_m1_bar_csv(p):
            tf=r.get("timeframe","").upper()
            if tf and tf!="M1":
                raise ModelError(f"M1_TIMEFRAME_UNEXPECTED file={p} tf={tf}")
            if r.get("symbol") != "WIN@N":
                raise ModelError(f"M1_SYMBOL_UNEXPECTED file={p} symbol={r.get('symbol')!r}")
            d=r["date"].replace(".","-")
            if start<=d<=end:
                sessions.add(d)
    return sorted(sessions)


def find_tick_file_for_session(ticks_root: Path, session: str) -> Path:
    ym=session[:7].replace("-","_")
    p=ticks_root/f"WIN@N_ticks_{ym}.csv"
    if p.is_file():
        return p
    raise ModelError(f"TICK_FILE_MISSING expected={p}")


def write_json_atomic(path: Path, obj) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    os.replace(tmp,path)


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fieldnames,delimiter=";",lineterminator="\n")
        w.writeheader()
        for r in rows:
            w.writerow(r)
