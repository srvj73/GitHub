import json
import tempfile
import unittest
from pathlib import Path

from minotauro_v004_core import BASELINE_CELL_ID, SessionResult, valid_cells, ModelError
from minotauro_v004_runner import (
    _commit_session,
    _month_requires_read,
    _PrefixHashTracker,
    _new_checkpoint,
    _orphan_reconcile,
    _verify_checkpoint_self,
    _verify_use_time_binding,
    _write_checkpoint,
)
from minotauro_v005r1_r23_gates import seal_prepilot_gates, pilot_reconcile, validate_geometry
from minotauro_v005r1_r23_contract import (
    EXPECTED_CORE_IMPORTED_DEFINITIONS_SHA256,
    EXPECTED_IO_SHA256,
    EXPECTED_PREFLIGHT_SHA256,
    canonical_json_hash,
    sha256_file,
    runner_identity,
    gate_identity,
    write_json_atomic_canonical,
)


class OperationalGateTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(__file__).resolve().parent
        self.cell = next(c for c in valid_cells() if c.cell_id == BASELINE_CELL_ID)
        self.cells = [self.cell]
        self.identity = {
            "spec_sha256": "S" * 64,
            "runner_sha256": "R" * 64,
            "grid_sha256": "G" * 64,
            "preflight_status_sha256": "P" * 64,
            "session_calendar_sha256": "C" * 64,
            "expected_sessions_sha256": "E" * 64,
            "source_inventory_sha256": "I" * 64,
            "run_source_binding_sha256": "B" * 64,
            "config_sha256": "F" * 64,
            "parser_version": "TEST",
        }
        self.runtime = {
            "preflight_py_sha256": EXPECTED_PREFLIGHT_SHA256,
            "io_py_sha256": EXPECTED_IO_SHA256,
            "core_imported_definitions_sha256": EXPECTED_CORE_IMPORTED_DEFINITIONS_SHA256,
        }

    def calendar_row(self):
        return {
            "first_cutoff_bid_msc": "100",
            "first_cutoff_ask_msc": "100",
            "cutoff_long_fill_msc": "100",
            "cutoff_short_fill_msc": "100",
            "cutoff_long_latency_ms": "0",
            "cutoff_short_latency_ms": "0",
        }

    def result(self, session, cash):
        return SessionResult(
            session=session,
            cell_ids=[BASELINE_CELL_ID],
            trades=[],
            events=[{"event": "TEST", "ordinal": 1, "time_msc": 1, "cell_ids": [BASELINE_CELL_ID]}],
            equity_events=[{"event": "OPEN_MARK", "cell_id": BASELINE_CELL_ID, "ordinal": 1, "time_msc": 1, "equity_units": cash}],
            equity_reconciliation=[{"session": session, "cell_id": BASELINE_CELL_ID, "open_marks_evaluated": 1, "open_marks_persisted": 1, "session_min_equity": cash, "session_max_equity": cash, "end_equity": cash, "max_dd_to_date": 0}],
            end_cash_units=[cash], hwm_units=[max(0, cash)], max_dd_units=[0], regime_min_units=[cash],
            closed_hwm_units=[max(0, cash)], closed_max_dd_units=[0], trade_counts=[0],
            cutoff_diagnostics={"cutoff_msc": 1, "first_cutoff_bid_msc": 1, "first_cutoff_ask_msc": 1},
            precutoff_crossed_state_count=0,
        )

    def new_cp(self, path):
        cp = _new_checkpoint("TEST", self.cells, self.identity, self.runtime)
        _write_checkpoint(path, cp)
        return cp

    def test_gate26_safe_stop_before_commit_pending_is_replaced(self):
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "PHASE_A"
            pending = out / "sessions" / "2025-01-02.pending"
            pending.mkdir(parents=True)
            (pending / "partial.tmp").write_text("partial", encoding="utf-8")
            cp_path = out / "CHECKPOINT.json"
            cp = self.new_cp(cp_path); done = set()
            _orphan_reconcile(out, cp)
            _commit_session(out, "2025-01-02", self.result("2025-01-02", 10), self.cells, cp, done, self.calendar_row(), cp_path)
            self.assertFalse(pending.exists())
            self.assertTrue((out / "sessions" / "2025-01-02").is_dir())
            self.assertIn("2025-01-02", cp["completed"])

    def test_gate26_safe_stop_during_commit_final_without_checkpoint_becomes_orphan(self):
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "PHASE_A"
            final = out / "sessions" / "2025-01-02"
            final.mkdir(parents=True)
            (final / "session_receipt.json").write_text("{}", encoding="utf-8")
            cp = {"completed": []}
            _orphan_reconcile(out, cp)
            self.assertFalse(final.exists())
            self.assertTrue((out / "_orphan" / "2025-01-02__1").is_dir())

    def test_gate26_safe_stop_after_commit_is_preserved(self):
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "PHASE_A"; cp_path = out / "CHECKPOINT.json"
            cp = self.new_cp(cp_path); done = set()
            _commit_session(out, "2025-01-02", self.result("2025-01-02", 10), self.cells, cp, done, self.calendar_row(), cp_path)
            loaded = json.loads(cp_path.read_text(encoding="utf-8")); _verify_checkpoint_self(loaded)
            _orphan_reconcile(out, loaded)
            self.assertTrue((out / "sessions" / "2025-01-02").is_dir())
            self.assertFalse((out / "_orphan").exists())

    def test_gate27_clean_resume_session_bundle_hashes_identical(self):
        sessions = ["2025-01-02", "2025-01-03"]
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            outs = []
            for name, reload_between in (("clean", False), ("resume", True)):
                out = base / name; cp_path = out / "CHECKPOINT.json"
                cp = self.new_cp(cp_path); done = set()
                _commit_session(out, sessions[0], self.result(sessions[0], 10), self.cells, cp, done, self.calendar_row(), cp_path)
                if reload_between:
                    cp = json.loads(cp_path.read_text(encoding="utf-8")); _verify_checkpoint_self(cp); done = set(cp["completed"])
                _commit_session(out, sessions[1], self.result(sessions[1], 20), self.cells, cp, done, self.calendar_row(), cp_path)
                outs.append(out)
            for sess in sessions:
                rels = ["trades.jsonl.gz", "events.jsonl.gz", "equity.jsonl.gz", "equity_reconciliation.jsonl.gz", "session_receipt.json"]
                for rel in rels:
                    self.assertEqual(sha256_file(outs[0]/"sessions"/sess/rel), sha256_file(outs[1]/"sessions"/sess/rel), (sess, rel))
            self.assertEqual(json.loads((outs[0]/"CHECKPOINT.json").read_text()), json.loads((outs[1]/"CHECKPOINT.json").read_text()))

    def test_r23_month_all_committed_but_unverified_must_be_read(self):
        rows = [{"session_date": "2025-01-02"}, {"session_date": "2025-01-03"}]
        done = {"2025-01-02", "2025-01-03"}; tp = Path("X.csv"); h = "A"*64
        self.assertTrue(_month_requires_read(rows, done, {}, tp, h))
        self.assertFalse(_month_requires_read(rows, done, {str(tp): h}, tp, h))
        self.assertTrue(_month_requires_read(rows, {"2025-01-02"}, {str(tp): h}, tp, h))

    def test_r23_clean_use_time_binding_checks_frozen_artifacts(self):
        with tempfile.TemporaryDirectory() as td:
            phase = Path(td)
            paths = {
                "session_calendar_sha256": phase/"SESSION_CALENDAR_PHASE_A.csv",
                "preflight_status_sha256": phase/"PHASE_STATUS.json",
                "d1_predecessor_extract_sha256": phase/"D1_PREDECESSOR_EXTRACT_PHASE_A.csv",
            }
            for i, p in enumerate(paths.values()): p.write_text(f"x{i}\n", encoding="utf-8")
            binding = {
                "preflight_py_sha256": EXPECTED_PREFLIGHT_SHA256,
                "io_py_sha256": EXPECTED_IO_SHA256,
                "core_imported_definitions_sha256": EXPECTED_CORE_IMPORTED_DEFINITIONS_SHA256,
                **{k: sha256_file(p) for k,p in paths.items()},
            }
            binding["binding_content_sha256"] = canonical_json_hash(binding)
            _verify_use_time_binding(self.root, phase, binding)
            paths["session_calendar_sha256"].write_text("drift\n", encoding="utf-8")
            with self.assertRaisesRegex(ModelError, "RUN_BLOCKED_BINDING_MISMATCH session_calendar_sha256"):
                _verify_use_time_binding(self.root, phase, binding)

    def test_r1r6_prefix_receipt_detects_restored_file_after_divergent_commits(self):
        canonical = [b"A;one\n", b"B;two\n", b"C;three\n"]
        divergent = [b"A;ONE\n", b"B;two\n", b"C;three\n"]
        h = _PrefixHashTracker()
        h.update(divergent[0])
        offset, digest = h.snapshot()
        verifier = _PrefixHashTracker({offset: digest})
        with self.assertRaisesRegex(ModelError, "TICK_PREFIX_DRIFT"):
            verifier.update(canonical[0])

    def test_r1r6_gate28_stale_pass_is_invalidated_before_reconcile(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "out"; gates = root / "GATES"; gates.mkdir(parents=True)
            stale = gates / "GATE28_PILOT_RECONCILIATION_RECEIPT.json"
            write_json_atomic_canonical(stale, {"GATE28_PILOT_RECONCILIATION":"PASS"})
            with self.assertRaisesRegex(RuntimeError, "GATE28_BINDING_REQUIRED"):
                pilot_reconcile({"out_root":str(root)})
            self.assertFalse(stale.exists())

    def test_r1r6_geometry_stale_pass_is_invalidated_before_validate(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "out"; gates = root / "GATES"; gates.mkdir(parents=True)
            stale = gates / "GEOMETRY_PARITY_RECEIPT.json"
            write_json_atomic_canonical(stale, {"GEOMETRY_PARITY":"PASS"})
            with self.assertRaisesRegex(RuntimeError, "GEOMETRY_PREPARE_REQUIRED"):
                validate_geometry({"out_root":str(root)}, Path(td)/"missing.csv")
            self.assertFalse(stale.exists())

    def test_prepilot_seal_binds_geometry_and_current_suite(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "out"; phase = root / "PHASE_A"; gates = root / "GATES"
            phase.mkdir(parents=True); gates.mkdir(parents=True)
            d1_extract = phase / "D1_PREDECESSOR_EXTRACT_PHASE_A.csv"; d1_extract.write_text("x\n", encoding="utf-8")
            ind = phase / "IND@N.csv"; ind.write_text("x\n", encoding="utf-8")
            binding = {
                "status": "PASS_REBOUND_UNSEALED", "binding_version": "V005R1_R2_3",
                "d1_predecessor_extract_sha256": sha256_file(d1_extract),
                "ind_d1_sha256": sha256_file(ind),
            }
            binding["binding_content_sha256"] = canonical_json_hash(binding, exclude_keys={"binding_content_sha256"})
            binding_path = phase / "RUN_SOURCE_BINDING_A.json"
            write_json_atomic_canonical(binding_path, binding)
            preseal_hash = sha256_file(binding_path)
            rh,_ = runner_identity(self.root); gh,_ = gate_identity(self.root)
            common = {"spec_sha256": "D6D791083870015BF07BF4ABF64718D37F9136FA247D49DB31B4DC8DE2E73747", "runner_sha256": rh, "gate_suite_sha256": gh}
            write_json_atomic_canonical(gates/"SYNTHETIC_GATES_RECEIPT.json", {"SYNTHETIC_GATES":"PASS", **common})
            write_json_atomic_canonical(gates/"SOURCE_GATES_RECEIPT.json", {"SOURCE_GATES":"PASS", "run_source_binding_sha256_before_seal":preseal_hash, **common})
            write_json_atomic_canonical(gates/"OPERATIONAL_GATES_RECEIPT.json", {"OPERATIONAL_GATES":"PASS", **common})
            for name in ("GEOMETRY_INPUT_R23.csv","GEOMETRY_REPLAY_EXACT_R23.csv","GEOMETRY_MT5_R23.csv","GEOMETRY_PARITY_2025.csv"):
                (gates/name).write_text("x\n", encoding="utf-8")
            prep = {
                "GEOMETRY_PREPARE":"PASS", **common,
                "input_sha256":sha256_file(gates/"GEOMETRY_INPUT_R23.csv"),
                "replay_sha256":sha256_file(gates/"GEOMETRY_REPLAY_EXACT_R23.csv"),
                "d1_predecessor_extract_sha256":sha256_file(d1_extract),
                "ind_d1_sha256":sha256_file(ind),
                "run_source_binding_sha256_before_seal":preseal_hash,
            }
            write_json_atomic_canonical(gates/"GEOMETRY_PREPARE_RECEIPT.json", prep)
            parity = {
                "GEOMETRY_PARITY":"PASS", **common,
                "input_sha256":sha256_file(gates/"GEOMETRY_INPUT_R23.csv"),
                "replay_sha256":sha256_file(gates/"GEOMETRY_REPLAY_EXACT_R23.csv"),
                "mt5_output_sha256":sha256_file(gates/"GEOMETRY_MT5_R23.csv"),
                "d1_predecessor_extract_sha256":sha256_file(d1_extract),
                "ind_d1_sha256":sha256_file(ind),
                "run_source_binding_sha256_before_seal":preseal_hash,
                "prepare_receipt_sha256":sha256_file(gates/"GEOMETRY_PREPARE_RECEIPT.json"),
            }
            write_json_atomic_canonical(gates/"GEOMETRY_PARITY_RECEIPT.json", parity)
            cfg={"out_root":str(root), "ind_d1":str(ind)}
            receipt=seal_prepilot_gates(cfg,self.root)
            self.assertEqual(receipt["PRE_PILOT_GATES"],"PASS")
            self.assertEqual(receipt["gates_passed"],27)
            sealed=json.loads(binding_path.read_text(encoding="utf-8"))
            self.assertEqual(sealed["status"],"PASS_SEALED_PREPILOT")
            self.assertIn("geometry_parity_2025_sha256",sealed)
            self.assertEqual(sealed["binding_content_sha256"],canonical_json_hash(sealed,exclude_keys={"binding_content_sha256"}))


# =====================================================================================
# R1R10 operational tests (M-1/m-d streaming, memory telemetry/cap, identities).
# Synthetic only: no market data. The end-to-end fixture replaces _prepare_phase
# (gate/binding/authorization loading) with an in-memory synthetic calendar via
# unittest.mock inside a temporary directory; no gate receipt or owner
# authorization file is created anywhere.
# =====================================================================================
import ast
import contextlib
import csv as _csv
import ctypes
import gzip
import inspect
import io
import os
import random
import sys
from datetime import date, timedelta
from unittest import mock

import minotauro_v004_runner as r1r10_runner
import minotauro_v005r1_r23_outputs as r1r10_outputs
import minotauro_v005r1_r1r10_memory as r1r10_memory
from minotauro_v004_core import D1Bar, PRICE_SCALE, SessionEngine
from minotauro_v004_io import cutoff_msc_for_session, date_time_to_epoch_ms_floor
from minotauro_v004_metrics import aggregate_phase
from minotauro_v005r1_r23_contract import (
    GATE_MANIFEST_MEMBERS,
    RUNNER_VERSION,
    RUNTIME_MANIFEST_MEMBERS,
    canonical_json_bytes,
)

R1R10_PACKAGE_ROOT = Path(__file__).resolve().parent
R1R10_SMALL_CELL_IDS = (BASELINE_CELL_ID, "P02_T00_R00_M00", "P01_T01_R01_M00")


def _weekdays(start: date, n: int) -> list[str]:
    out, d = [], start
    while len(out) < n:
        if d.weekday() < 5:
            out.append(d.isoformat())
        d += timedelta(days=1)
    return out


def _previous_weekday(iso: str) -> str:
    d = date.fromisoformat(iso) - timedelta(days=1)
    while d.weekday() >= 5:
        d -= timedelta(days=1)
    return d.isoformat()


class _ScriptedProbe:
    """Deterministic probe: LOW until exceed=True, then HIGH (> any test cap)."""
    LOW = 64 * 1024 * 1024
    HIGH = 64 * 1024 * 1024 * 1024

    def __init__(self):
        self.exceed = False
        self.calls = 0

    def __call__(self):
        self.calls += 1
        v = self.HIGH if self.exceed else self.LOW
        return {"current_working_set_bytes": self.LOW, "peak_working_set_bytes": v,
                "current_private_bytes": self.LOW, "peak_private_bytes": v, "probe": "TEST_SCRIPTED"}


class _SyntheticPhase:
    """Synthetic tick months + calendar + binding for run_phase_a (RUN_A: 250 sessions / 12 months)."""

    def __init__(self, base: Path, n_sessions: int, cell_ids=None):
        self.base = base
        all_cells = valid_cells()
        self.cells = all_cells if cell_ids is None else [c for c in all_cells if c.cell_id in set(cell_ids)]
        self.bar_ohlc = (10000 * PRICE_SCALE, 20000 * PRICE_SCALE, 10000 * PRICE_SCALE, 15000 * PRICE_SCALE)
        probe_engine = SessionEngine("2025-01-02", D1Bar("2024-12-31", *self.bar_ohlc), self.cells, cutoff_msc_for_session("2025-01-02"))
        self.line = probe_engine.lines[2][48].price_micro // PRICE_SCALE
        self.sessions = _weekdays(date(2025, 1, 2), n_sessions)
        ticks = base / "ticks"; ticks.mkdir(parents=True, exist_ok=True)
        by_month = {}
        for s in self.sessions:
            by_month.setdefault(s[:7], []).append(s)
        self.rows, self.tick_files = [], []
        for ym, month_sessions in sorted(by_month.items()):
            tp = ticks / f"WIN@N_ticks_{ym.replace('-', '_')}.csv"
            lines = []
            for s in month_sessions:
                lines.extend(self._session_lines(s, self.sessions.index(s)))
                cut = cutoff_msc_for_session(s)
                self.rows.append({
                    "session_date": s, "tick_file": str(tp),
                    "expected_previous_session_date": _previous_weekday(s),
                    "cutoff_msc": str(cut), "first_cutoff_bid_msc": str(cut), "first_cutoff_ask_msc": str(cut),
                    "cutoff_long_fill_msc": str(cut), "cutoff_short_fill_msc": str(cut),
                    "cutoff_long_latency_ms": "0", "cutoff_short_latency_ms": "0",
                })
            tp.write_text("".join(lines), encoding="utf-8", newline="")
            self.tick_files.append(tp)
        self.d1 = {r["expected_previous_session_date"]: D1Bar(r["expected_previous_session_date"], *self.bar_ohlc) for r in self.rows}
        self.d1_extract = {r["session_date"]: {
            "session_date": r["session_date"], "expected_previous_session_date": r["expected_previous_session_date"],
            "open_micro": str(self.bar_ohlc[0]), "high_micro": str(self.bar_ohlc[1]),
            "low_micro": str(self.bar_ohlc[2]), "close_micro": str(self.bar_ohlc[3]),
        } for r in self.rows}
        self.binding = {
            "status": "PASS_SEALED_PREPILOT", "binding_content_sha256": "B" * 64,
            "expected_sessions_sha256": "E" * 64, "session_calendar_sha256": "C" * 64,
            "source_inventory_sha256": "I" * 64, "preflight_status_sha256": "P" * 64,
            "tick_files": [{"path": str(tp), "sha256": sha256_file(tp)} for tp in self.tick_files],
        }
        self.identity = {
            "spec_sha256": "S" * 64, "runner_sha256": "R" * 64, "runner_manifest": [], "grid_sha256": "G" * 64,
            "preflight_status_sha256": "P" * 64, "session_calendar_sha256": "C" * 64,
            "expected_sessions_sha256": "E" * 64, "source_inventory_sha256": "I" * 64,
            "run_source_binding_sha256": "B" * 64, "config_sha256": "F" * 64, "parser_version": "TEST_R1R10",
        }
        self.runtime = {"preflight_py_sha256": EXPECTED_PREFLIGHT_SHA256, "io_py_sha256": EXPECTED_IO_SHA256,
                        "core_imported_definitions_sha256": EXPECTED_CORE_IMPORTED_DEFINITIONS_SHA256}

    def _session_lines(self, s: str, i: int) -> list[str]:
        d = s.replace("-", ".")
        L = self.line

        def t(hms, off, b, a, l, v):
            dt = f"{d} {hms}"
            return f"WIN@N;{dt};{date_time_to_epoch_ms_floor(dt) + off};{b};{a};{l};{v};{v};0\n"

        x = 65 + ((i * 37) % 11 - 5) * 20
        if i % 5 == 4:  # quiet session: no trade, cutoff observed
            return [t("10:00:00", 0, L - 5, L, L, 1), t("18:03:00", 0, L - 5, L, 0, 0), t("18:03:00", 100, L - 5, L, 0, 0)]
        return [
            t("10:00:00", 0, L - 5, L, L, 1), t("10:00:01", 0, L + 45, L + 50, L + 50, 1),
            t("10:00:01", 0, L + 50, L + 55, L + 55, 1), t("10:00:02", 0, L + 70, L + 75, L + 75, 1),
            t("18:02:59", 500, L + x, L + x + 5, 0, 0), t("18:03:00", 0, L + x, L + x + 5, 0, 0),
            t("18:03:00", 100, L + x + 5, L + x + 10, 0, 0),
        ]

    def cfg(self, name: str, cap_mib: int = 4096) -> dict:
        return {"out_root": str(self.base / name), "memory_cap_mib": cap_mib}

    def fake_prepare(self, cfg: dict, mode: str):
        root = Path(cfg["out_root"]); phase = root / "PHASE_A"; phase.mkdir(parents=True, exist_ok=True)
        write_json_atomic_canonical(phase / "RUN_SOURCE_BINDING_A.json", self.binding)
        if mode == "RUN_A":
            out, rows, integral = phase, self.rows, {BASELINE_CELL_ID}
        elif mode == "PILOT_A":
            out, rows, integral = root / "PILOT_A", self.rows[:3], {c.cell_id for c in self.cells}
            out.mkdir(parents=True, exist_ok=True)
        else:
            raise ModelError("MODE_INVALID")
        return (R1R10_PACKAGE_ROOT, root, phase, out, self.binding, self.runtime, self.identity, rows,
                self.d1, self.d1_extract, self.cells, integral, "H" * 64)

    def run(self, cfg: dict, mode: str, probe=None, stop_after_commits=None, extra_patches=()):
        """Returns (stdout_text, exception_or_None). stop_after_commits flips the probe to HIGH."""
        probe = probe or _ScriptedProbe()
        original_commit = r1r10_runner._commit_session
        counter = {"n": 0}

        def counting_commit(*a, **k):
            original_commit(*a, **k)
            counter["n"] += 1
            if stop_after_commits is not None and counter["n"] >= stop_after_commits:
                probe.exceed = True

        buf = io.StringIO(); exc = None
        with contextlib.ExitStack() as st:
            st.enter_context(mock.patch.object(r1r10_runner, "_prepare_phase", self.fake_prepare))
            st.enter_context(mock.patch.object(r1r10_runner, "_commit_session", counting_commit))
            for p in extra_patches:
                st.enter_context(p)
            st.enter_context(contextlib.redirect_stdout(buf))
            try:
                r1r10_runner.run_phase_a(cfg, mode, memory_probe=probe)
            except Exception as e:  # MemoryCapSafeStop / ModelError are inspected by the tests
                exc = e
        return buf.getvalue(), exc


def _tree_hashes(root: Path) -> dict:
    return {str(p.relative_to(root)).replace("\\", "/"): sha256_file(p) for p in sorted(root.rglob("*")) if p.is_file()}


def _telemetry_rows(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def _write_session_bundle(out: Path, session: str, trades: list[dict]) -> None:
    r1r10_runner.gzjson(out / "sessions" / session / "trades.jsonl.gz", trades)
    write_json_atomic_canonical(out / "sessions" / session / "session_receipt.json", {"session": session, "trades": len(trades)})


class R1R10StreamingEquivalenceTests(unittest.TestCase):
    def _edge_case_sessions(self):
        """Out-of-order ordinals, several cell_ids per ordinal, a tie, late union field, nested dict/list/None."""
        return {
            "2025-01-03": [
                {"session": "2025-01-03", "cell_id": "P02_T02_R02_M00", "entry_ordinal": 9, "net_pnl_units": 5, "nested": {"b": [1, 2], "a": None}},
                {"session": "2025-01-03", "cell_id": "P01_T01_R01_M00", "entry_ordinal": 2, "net_pnl_units": -3, "tags": ["x", "ação"], "maybe": None},
                {"session": "2025-01-03", "cell_id": "A_FIRST", "entry_ordinal": 2, "net_pnl_units": 0, "flt": 1.25},
                {"session": "2025-01-03", "cell_id": "P01_T01_R01_M00", "entry_ordinal": 2, "net_pnl_units": 7, "tie": "second"},
            ],
            "2025-01-02": [
                {"session": "2025-01-02", "cell_id": "P02_T02_R02_M00", "entry_ordinal": 40, "net_pnl_units": 11},
                {"session": "2025-01-02", "cell_id": "P02_T02_R02_M00", "entry_ordinal": 3, "net_pnl_units": None},
                {"session": "2025-01-02", "cell_id": "P02_T00_R00_M00", "net_pnl_units": 1, "no_ordinal": True},
            ],
            "2025-01-06": [],
            "2025-02-10": [
                {"session": "2025-02-10", "cell_id": "P02_T00_R00_M00", "entry_ordinal": 1, "net_pnl_units": -8, "rmax_ticks": None},
                {"session": "2025-02-10", "cell_id": "P02_T02_R02_M00", "entry_ordinal": 1, "net_pnl_units": 13, "zz_late_field": {"k": [None, True, "é"]}},
            ],
        }

    def test_r1r10_b2_trades_csv_list_vs_stream_byte_identical(self):
        data = self._edge_case_sessions()
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "PHASE_A"
            commit_order = ["2025-01-03", "2025-01-02", "2025-01-06", "2025-02-10"]
            in_memory = []
            for s in commit_order:
                _write_session_bundle(out, s, data[s]); in_memory.extend(data[s])
            persisted = list(r1r10_outputs.iter_committed_trades(out, commit_order))
            ref_mem = Path(td) / "ref_memory.csv"; ref_disk = Path(td) / "ref_persisted.csv"; got = Path(td) / "stream.csv"
            r1r10_outputs.write_trades_csv(ref_mem, in_memory)
            r1r10_outputs.write_trades_csv(ref_disk, persisted)
            stats = r1r10_outputs.write_trades_csv_streaming(got, out, commit_order)
            self.assertEqual(ref_mem.read_bytes(), ref_disk.read_bytes())
            self.assertEqual(ref_disk.read_bytes(), got.read_bytes())
            text = got.read_text(encoding="utf-8")
            self.assertIn("zz_late_field", text.splitlines()[0])
            self.assertEqual(stats["rows"], sum(len(v) for v in data.values()))
            self.assertEqual(stats["max_session_rows_in_memory"], max(len(v) for v in data.values()))
            rows = list(_csv.DictReader(io.StringIO(text), delimiter=";"))
            self.assertEqual(len(rows), stats["rows"])
            tie = [r for r in rows if r["cell_id"] == "P01_T01_R01_M00" and r["session"] == "2025-01-03"]
            self.assertEqual([r["tie"] for r in tie], ["", "second"])  # stable order preserved

    def test_r1r10_b2_trades_csv_random_list_vs_stream(self):
        rnd = random.Random(20260926)
        sessions = _weekdays(date(2025, 1, 2), 12)
        fields = ["exit_reason", "gross_pnl_units", "direction", "n_identity", "model_assumptions"]
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "PHASE_A"; in_memory = []
            for s in sessions:
                rows = []
                for _ in range(rnd.randint(0, 25)):
                    tr = {"session": s, "cell_id": rnd.choice(R1R10_SMALL_CELL_IDS), "entry_ordinal": rnd.randint(1, 6), "net_pnl_units": rnd.randint(-50, 50)}
                    for f in rnd.sample(fields, rnd.randint(0, len(fields))):
                        tr[f] = rnd.choice([None, 3, "TARGET", [1, "a"], {"z": 1, "a": [None]}])
                    rows.append(tr)
                _write_session_bundle(out, s, rows); in_memory.extend(rows)
            a = Path(td) / "a.csv"; b = Path(td) / "b.csv"
            r1r10_outputs.write_trades_csv(a, in_memory)
            r1r10_outputs.write_trades_csv_streaming(b, out, list(reversed(sessions)))
            self.assertEqual(a.read_bytes(), b.read_bytes())

    def test_r1r10_b2_streaming_writer_fail_closed(self):
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "PHASE_A"
            _write_session_bundle(out, "2025-01-02", [{"session": "2025-01-03", "cell_id": "X", "entry_ordinal": 1}])
            with self.assertRaisesRegex(ModelError, "TRADES_CSV_SESSION_FIELD_MISMATCH"):
                r1r10_outputs.write_trades_csv_streaming(Path(td) / "x.csv", out, ["2025-01-02"])
            write_json_atomic_canonical(out / "sessions" / "2025-01-02" / "session_receipt.json", {"trades": 2})
            with self.assertRaisesRegex(ModelError, "COMMITTED_TRADES_COUNT_MISMATCH"):
                list(r1r10_outputs.iter_committed_trades(out, ["2025-01-02"]))
            with self.assertRaisesRegex(ModelError, "COMMITTED_TRADES_MISSING session=2025-01-05"):
                list(r1r10_outputs.iter_committed_trades(out, ["2025-01-05"]))
            with self.assertRaisesRegex(ModelError, "COMMITTED_SESSIONS_DUPLICATED"):
                list(r1r10_outputs.iter_committed_trades(out, ["2025-01-02", "2025-01-02"]))

    def test_r1r10_b1_metrics_list_vs_stream_identical(self):
        rnd = random.Random(7)
        cells = valid_cells()
        sessions = _weekdays(date(2025, 1, 2), 40)
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "PHASE_A"; in_memory = []
            for s in sessions:
                rows = [{"session": s, "cell_id": rnd.choice(cells).cell_id, "entry_ordinal": k,
                         "net_pnl_units": (None if rnd.random() < 0.05 else rnd.randint(-900, 900))} for k in range(rnd.randint(0, 30))]
                _write_session_bundle(out, s, rows); in_memory.extend(rows)
            maxdd = {c.cell_id: rnd.randint(0, 5000) for c in cells}
            as_list = aggregate_phase(cells, in_memory, maxdd)
            stream = r1r10_outputs.iter_committed_trades(out, sessions)
            self.assertTrue(inspect.isgenerator(stream))
            as_stream = aggregate_phase(cells, stream, maxdd)
            shuffled = list(in_memory); rnd.shuffle(shuffled)
            self.assertEqual(canonical_json_bytes(as_list), canonical_json_bytes(as_stream))
            self.assertEqual(canonical_json_bytes(as_list), canonical_json_bytes(aggregate_phase(cells, shuffled, maxdd)))


class R1R10MemoryTelemetryTests(unittest.TestCase):
    def test_r1r10_cap_config_fail_closed(self):
        for bad in ({}, {"memory_cap_mib": None}, {"memory_cap_mib": True}, {"memory_cap_mib": 4096.0},
                    {"memory_cap_mib": "4096"}, {"memory_cap_mib": 0}, {"memory_cap_mib": -1},
                    {"memory_cap_mib": r1r10_memory.MEMORY_CAP_MIB_MAX + 1}):
            with self.assertRaises(r1r10_memory.MemoryCapConfigError, msg=repr(bad)):
                r1r10_memory.parse_memory_cap_mib(bad)
        self.assertEqual(r1r10_memory.parse_memory_cap_mib({"memory_cap_mib": 4096}), 4096)

    def test_r1r10_config_example_requires_owner_cap_and_new_out_root(self):
        cfg = json.loads((R1R10_PACKAGE_ROOT / "config.example.json").read_text(encoding="utf-8"))
        self.assertTrue(cfg["out_root"].endswith("MINOTAURO_PARAMETER_MARKET_DISCOVERY_V005R1_R1R10"))
        self.assertIn("memory_cap_mib", cfg)
        with self.assertRaises(r1r10_memory.MemoryCapConfigError):
            r1r10_memory.parse_memory_cap_mib(cfg)  # placeholder forces an explicit owner decision

    def test_r1r10_live_process_probe_on_this_platform(self):
        # Exercises the real stdlib probe (Win32 K32GetProcessMemoryInfo on the owner PC).
        s = r1r10_memory._validated_sample(r1r10_memory.probe_process_memory())
        self.assertGreater(s["current_working_set_bytes"], 0)
        self.assertGreaterEqual(s["peak_working_set_bytes"], s["current_working_set_bytes"])
        if sys.platform == "win32":
            self.assertTrue(s["probe"].startswith("WIN32_"))
            self.assertIsNotNone(s["current_private_bytes"])
            self.assertGreaterEqual(s["peak_private_bytes"], s["current_private_bytes"])

    def test_r1r10_windows_counters_layout(self):
        t = r1r10_memory.windows_counters_struct()
        ptr = ctypes.sizeof(ctypes.c_void_p)
        self.assertEqual(ctypes.sizeof(t), 80 if ptr == 8 else 44)
        if ptr == 8:
            offsets = {name: getattr(t, name).offset for name, _ in t._fields_}
            self.assertEqual((offsets["PeakWorkingSetSize"], offsets["WorkingSetSize"], offsets["PagefileUsage"],
                              offsets["PeakPagefileUsage"], offsets["PrivateUsage"]), (8, 16, 56, 64, 72))

    def test_r1r10_b4_telemetry_rows_flushed_and_fsynced_incrementally(self):
        with tempfile.TemporaryDirectory() as td:
            path = r1r10_memory.telemetry_path(Path(td), "RUN_A")
            probe = _ScriptedProbe()
            real_fsync = os.fsync; calls = []
            with mock.patch.object(r1r10_memory.os, "fsync", side_effect=lambda fd: (calls.append(fd), real_fsync(fd))):
                mon = r1r10_memory.MemoryMonitor(path, 2048, "RUN_A", probe=probe)
                with contextlib.redirect_stdout(io.StringIO()):
                    mon.boundary("SESSION_COMMIT", "2025-01-02", 1)
                    self.assertEqual(len(_telemetry_rows(path)), 1)  # visible before any further write
                    mon.progress("2025-01-03", 1, file="x.csv", file_bytes=10, raw_rows=2)
            rows = _telemetry_rows(path)
            self.assertEqual(len(calls), 2)
            self.assertEqual([r["event"] for r in rows], ["SESSION_COMMIT", "PROGRESS"])
            r = rows[0]
            for k in ("session", "current_working_set_bytes", "peak_working_set_bytes", "cap_bytes", "cap_mib", "utc", "elapsed_s", "observed_peak_bytes"):
                self.assertIn(k, r)
            self.assertEqual((r["session"], r["cap_mib"], r["cap_bytes"], r["cap_exceeded"]), ("2025-01-02", 2048, 2048 * 1024 * 1024, False))

    def test_r1r10_progress_probe_failure_never_aborts_engine_but_boundary_fails_closed(self):
        def broken():
            raise r1r10_memory.MemoryProbeError("MEMORY_PROBE_TEST_BROKEN")
        with tempfile.TemporaryDirectory() as td:
            mon = r1r10_memory.MemoryMonitor(Path(td) / "t.jsonl", 1024, "RUN_A", probe=broken)
            with contextlib.redirect_stdout(io.StringIO()) as buf:
                self.assertIsNone(mon.progress("2025-01-02", 0))
            self.assertIn("MEMORY_TELEMETRY_PROGRESS_UNAVAILABLE", buf.getvalue())
            with self.assertRaisesRegex(r1r10_memory.MemoryProbeError, "MEMORY_PROBE_TEST_BROKEN"):
                mon.boundary("SESSION_COMMIT", "2025-01-02", 1)

    def test_r1r10_boundary_cap_exceeded_raises_safe_stop_marker(self):
        with tempfile.TemporaryDirectory() as td:
            probe = _ScriptedProbe(); probe.exceed = True
            mon = r1r10_memory.MemoryMonitor(Path(td) / "t.jsonl", 1024, "PILOT_A", probe=probe)
            with contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaises(r1r10_memory.MemoryCapSafeStop) as cm:
                    mon.boundary("SESSION_COMMIT", "2025-01-03", 2)
            marker = str(cm.exception)
            for token in ("MEMORY_CAP_SAFE_STOP=YES", "boundary=SESSION_COMMIT", "session=2025-01-03",
                          "current_ws_mib=", "peak_ws_mib=", "limit_mib=1024", "pass=NO"):
                self.assertIn(token, marker)
            rows = _telemetry_rows(Path(td) / "t.jsonl")
            self.assertEqual([r["event"] for r in rows], ["SESSION_COMMIT", "MEMORY_CAP_SAFE_STOP"])
            self.assertTrue(rows[-1]["cap_exceeded"])


class R1R10EndToEndSyntheticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._td = tempfile.TemporaryDirectory()
        cls.fx = _SyntheticPhase(Path(cls._td.name), 250, R1R10_SMALL_CELL_IDS)
        cls.clean_cfg = cls.fx.cfg("clean")
        out, exc = cls.fx.run(cls.clean_cfg, "RUN_A")
        if exc is not None:
            raise exc
        cls.clean_stdout = out
        cls.clean_tree = _tree_hashes(Path(cls.clean_cfg["out_root"]) / "PHASE_A")

    @classmethod
    def tearDownClass(cls):
        cls._td.cleanup()

    def test_r1r10_clean_synthetic_run_a_passes_with_trades(self):
        self.assertIn("PHASE_A_RUN=PASS sessions=250", self.clean_stdout)
        phase = Path(self.clean_cfg["out_root"]) / "PHASE_A"
        total = sum(json.loads((phase / "sessions" / s / "session_receipt.json").read_text(encoding="utf-8"))["trades"] for s in self.fx.sessions)
        self.assertGreater(total, 250)
        with (phase / "TRADES_2025_ALL_CELLS.csv").open("r", encoding="utf-8", newline="") as f:
            self.assertEqual(sum(1 for _ in f) - 1, total)
        self.assertEqual(json.loads((phase / "EQUITY_LOSSLESS_GATE.json").read_text(encoding="utf-8"))["status"], "PASS")

    def test_r1r10_finalize_equals_r1r9_list_algorithm(self):
        phase = Path(self.clean_cfg["out_root"]) / "PHASE_A"
        all_trades = list(r1r10_outputs.iter_committed_trades(phase, self.fx.sessions))  # oracle only
        ref = Path(self._td.name) / "ref_trades.csv"
        r1r10_outputs.write_trades_csv(ref, all_trades)
        self.assertEqual(ref.read_bytes(), (phase / "TRADES_2025_ALL_CELLS.csv").read_bytes())
        cp = json.loads((phase / "CHECKPOINT.json").read_text(encoding="utf-8"))
        maxdd = {c.cell_id: int(cp["maxdd"][i]) for i, c in enumerate(self.fx.cells)}
        m = aggregate_phase(self.fx.cells, all_trades, maxdd)
        with (phase / "CELL_SUMMARY_2025.csv").open("r", encoding="utf-8", newline="") as f:
            summary = {r["cell_id"]: r for r in _csv.DictReader(f, delimiter=";")}
        for c in self.fx.cells:
            self.assertEqual(int(summary[c.cell_id]["net_units"]), m[c.cell_id]["net_units"])
            self.assertEqual(int(summary[c.cell_id]["trade_count"]), m[c.cell_id]["trade_count"])

    def _assert_stopped_consistently(self, cfg, exc, expected_boundary):
        self.assertIsInstance(exc, r1r10_memory.MemoryCapSafeStop)
        self.assertEqual(exc.row["boundary_event"], expected_boundary)
        phase = Path(cfg["out_root"]) / "PHASE_A"
        cp = json.loads((phase / "CHECKPOINT.json").read_text(encoding="utf-8"))
        _verify_checkpoint_self(cp)
        committed = sorted(p.name for p in (phase / "sessions").iterdir())
        self.assertEqual(committed, sorted(cp["completed"]))
        self.assertFalse(any(n.endswith(".pending") for n in committed))
        self.assertFalse((phase / "_orphan").exists())
        rows = _telemetry_rows(r1r10_memory.telemetry_path(Path(cfg["out_root"]), "RUN_A"))
        self.assertEqual(rows[-1]["event"], "MEMORY_CAP_SAFE_STOP")
        self.assertTrue(rows[-1]["cap_exceeded"])
        return cp

    def _resume_with_instrumentation(self, cfg):
        seen = {"aggregate_arg_types": [], "finalize_started": False, "trades_reads_before_finalize": [], "trades_reads": {}}
        original_aggregate = r1r10_runner.aggregate_phase
        original_boundary = r1r10_memory.MemoryMonitor.boundary
        original_gzip_open = gzip.open

        def spy_aggregate(cells, rows, maxdd):
            seen["aggregate_arg_types"].append(type(rows).__name__)
            self.assertTrue(inspect.isgenerator(rows), "aggregate_phase must receive a stream")
            return original_aggregate(cells, rows, maxdd)

        def spy_boundary(mon, event, session=None, sessions_done=None):
            if event == "PRE_FINALIZE":
                seen["finalize_started"] = True
            return original_boundary(mon, event, session, sessions_done)

        def spy_gzip_open(filename, *a, **k):
            name = Path(str(filename))
            if name.name == "trades.jsonl.gz":
                if not seen["finalize_started"]:
                    seen["trades_reads_before_finalize"].append(str(name))
                seen["trades_reads"][name.parent.name] = seen["trades_reads"].get(name.parent.name, 0) + 1
            return original_gzip_open(filename, *a, **k)

        stream_writer = mock.patch.object(r1r10_outputs, "write_trades_csv_streaming", wraps=r1r10_outputs.write_trades_csv_streaming)
        patches = (
            mock.patch.object(r1r10_runner, "aggregate_phase", spy_aggregate),
            mock.patch.object(r1r10_outputs, "write_trades_csv", side_effect=AssertionError("R1R9_LIST_WRITER_CALLED")),
            mock.patch.object(r1r10_memory.MemoryMonitor, "boundary", spy_boundary),
            mock.patch.object(gzip, "open", spy_gzip_open),
        )
        with stream_writer as sw:
            out, exc = self.fx.run(cfg, "RUN_A", extra_patches=patches)
        if exc is not None:
            raise exc
        self.assertEqual(seen["aggregate_arg_types"], ["generator"])
        self.assertEqual(sw.call_count, 1)
        # B3: resume/session loop never reads committed trades; finalize streams each
        # session file exactly three times (metrics, CSV field union, CSV write).
        self.assertEqual(seen["trades_reads_before_finalize"], [])
        self.assertEqual(sorted(seen["trades_reads"]), self.fx.sessions)
        self.assertEqual(set(seen["trades_reads"].values()), {3})
        return out, sw

    def test_r1r10_b5_b6_b3_cap_stop_mid_month_then_resume_identical_no_global_load(self):
        cfg = self.fx.cfg("cap_mid_month")
        out1, exc = self.fx.run(cfg, "RUN_A", stop_after_commits=100)
        self.assertNotIn("PHASE_A_RUN=PASS", out1)
        cp = self._assert_stopped_consistently(cfg, exc, "SESSION_COMMIT")
        self.assertEqual(sorted(cp["completed"]), self.fx.sessions[:100])
        self.assertEqual(exc.row["session"], self.fx.sessions[99])
        phase = Path(cfg["out_root"]) / "PHASE_A"
        for name in ("SELECTION_FREEZE.json", "SHA256SUMS.txt", "TRADES_2025_ALL_CELLS.csv", "RUN_MANIFEST.json"):
            self.assertFalse((phase / name).exists(), name)
        out2, sw = self._resume_with_instrumentation(cfg)
        self.assertIn("PHASE_A_RUN=PASS sessions=250", out2)
        self.assertEqual(out2.count("SESSION_COMMIT session="), 150)  # resume never re-commits
        stats = sw.call_args  # called with (path, out, sessions)
        self.assertEqual(len(stats.args[2]), 250)
        self.assertEqual(_tree_hashes(phase), self.clean_tree)
        commits = [r["session"] for r in _telemetry_rows(r1r10_memory.telemetry_path(Path(cfg["out_root"]), "RUN_A")) if r["event"] == "SESSION_COMMIT"]
        self.assertEqual(sorted(commits), self.fx.sessions)  # each session committed exactly once over both invocations

    def test_r1r10_cap_stop_at_month_and_finalize_boundaries_then_resume_identical(self):
        for boundary in ("MONTH_VERIFIED", "PRE_FINALIZE", "POST_FINALIZE"):
            with self.subTest(boundary=boundary):
                cfg = self.fx.cfg("cap_" + boundary.lower())
                probe = _ScriptedProbe()
                original_boundary = r1r10_memory.MemoryMonitor.boundary

                def flip(mon, event, session=None, sessions_done=None, _b=boundary, _p=probe):
                    if event == _b:
                        _p.exceed = True
                    return original_boundary(mon, event, session, sessions_done)

                with mock.patch.object(r1r10_memory.MemoryMonitor, "boundary", flip):
                    out1, exc = self.fx.run(cfg, "RUN_A", probe=probe)
                self.assertNotIn("PHASE_A_RUN=PASS", out1)
                self._assert_stopped_consistently(cfg, exc, boundary)
                out2, _ = self._resume_with_instrumentation(cfg)
                self.assertIn("PHASE_A_RUN=PASS sessions=250", out2)
                self.assertEqual(_tree_hashes(Path(cfg["out_root"]) / "PHASE_A"), self.clean_tree)

    def test_r1r10_b4_run_a_telemetry_per_session(self):
        rows = _telemetry_rows(r1r10_memory.telemetry_path(Path(self.clean_cfg["out_root"]), "RUN_A"))
        events = [r["event"] for r in rows]
        self.assertEqual(events[0], "RUN_START")
        commits = [r for r in rows if r["event"] == "SESSION_COMMIT"]
        self.assertEqual([r["session"] for r in commits], self.fx.sessions)
        self.assertEqual([r["sessions_done"] for r in commits], list(range(1, 251)))
        self.assertEqual(events.count("MONTH_VERIFIED"), 12)
        self.assertEqual(events[-2:], ["PRE_FINALIZE", "POST_FINALIZE"])
        for r in rows:
            self.assertEqual(r["schema"], r1r10_memory.TELEMETRY_SCHEMA)
            self.assertFalse(r["cap_exceeded"])
        self.assertFalse((Path(self.clean_cfg["out_root"]) / "PHASE_A" / "SESSION_TELEMETRY.jsonl").exists())


class R1R10PilotAndMainTests(unittest.TestCase):
    def test_r1r10_pilot_435_cells_cap_stop_resume_session_files_identical(self):
        with tempfile.TemporaryDirectory() as td:
            fx = _SyntheticPhase(Path(td), 5, None)
            clean = fx.cfg("clean"); out, exc = fx.run(clean, "PILOT_A")
            self.assertIsNone(exc); self.assertIn("PILOT_A_RUN=PASS sessions=3", out)
            cfg = fx.cfg("stopped"); out1, exc = fx.run(cfg, "PILOT_A", stop_after_commits=2)
            self.assertIsInstance(exc, r1r10_memory.MemoryCapSafeStop)
            pilot = Path(cfg["out_root"]) / "PILOT_A"
            self.assertFalse((pilot / "PILOT_RUN_RECEIPT.json").exists())
            self.assertNotIn("PILOT_A_RUN=PASS", out1)
            out2, exc2 = fx.run(cfg, "PILOT_A")
            self.assertIsNone(exc2); self.assertIn("PILOT_A_RUN=PASS sessions=3", out2)
            a = _tree_hashes(Path(clean["out_root"]) / "PILOT_A" / "sessions")
            b = _tree_hashes(pilot / "sessions")
            self.assertEqual(len(a), 15)
            self.assertEqual(a, b)
            self.assertEqual(sha256_file(Path(clean["out_root"]) / "PILOT_A" / "PILOT_RUN_RECEIPT.json"), sha256_file(pilot / "PILOT_RUN_RECEIPT.json"))

    def test_r1r10_main_exit_code_3_marker_no_pass_with_real_probe(self):
        with tempfile.TemporaryDirectory() as td:
            fx = _SyntheticPhase(Path(td), 5, R1R10_SMALL_CELL_IDS)
            cfg = fx.cfg("main_cap", cap_mib=1)  # real process is always > 1 MiB
            cfg_path = Path(td) / "config.json"; cfg_path.write_text(json.dumps(cfg), encoding="utf-8")
            buf = io.StringIO()
            with mock.patch.object(r1r10_runner, "_prepare_phase", fx.fake_prepare), \
                    mock.patch.object(sys, "argv", ["minotauro_v004_runner.py", "pilot-a", "--config", str(cfg_path)]), \
                    contextlib.redirect_stdout(buf):
                with self.assertRaises(SystemExit) as cm:
                    r1r10_runner.main()
            self.assertEqual(cm.exception.code, r1r10_memory.MEMORY_CAP_EXIT_CODE)
            text = buf.getvalue()
            self.assertIn("MEMORY_CAP_SAFE_STOP=YES", text)
            self.assertIn("boundary=RUN_START", text)
            self.assertIn("limit_mib=1 ", text)
            self.assertNotIn("_RUN=PASS", text)
            cp = json.loads((Path(cfg["out_root"]) / "PILOT_A" / "CHECKPOINT.json").read_text(encoding="utf-8"))
            _verify_checkpoint_self(cp)
            self.assertEqual(cp["completed"], [])

    def test_r1r10_main_missing_cap_is_blocked_exit_2(self):
        with tempfile.TemporaryDirectory() as td:
            cfg_path = Path(td) / "config.json"
            cfg_path.write_text(json.dumps({"out_root": str(Path(td) / "o"), "memory_cap_mib": None}), encoding="utf-8")
            prep = mock.Mock(side_effect=AssertionError("must fail before preparing"))
            err = io.StringIO()
            with mock.patch.object(r1r10_runner, "_prepare_phase", prep), \
                    mock.patch.object(sys, "argv", ["minotauro_v004_runner.py", "run-a", "--config", str(cfg_path)]), \
                    contextlib.redirect_stderr(err), contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaises(SystemExit) as cm:
                    r1r10_runner.main()
            self.assertEqual(cm.exception.code, 2)
            self.assertIn("MEMORY_CAP_MIB_REQUIRED_INTEGER", err.getvalue())
            prep.assert_not_called()


class R1R10StructuralTests(unittest.TestCase):
    def _runner_ast(self):
        return ast.parse((R1R10_PACKAGE_ROOT / "minotauro_v004_runner.py").read_text(encoding="utf-8"))

    def test_r1r10_c_no_annual_trades_list_in_runner(self):
        tree = self._runner_ast()
        funcs = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
        self.assertNotIn("_load_existing_trades", funcs)
        self.assertNotIn("trades", [a.arg for a in funcs["_commit_session"].args.args])
        self.assertNotIn("trades", inspect.signature(r1r10_runner._commit_session).parameters)
        run = funcs["run_phase_a"]
        self.assertFalse([n for n in ast.walk(run) if isinstance(n, ast.Name) and n.id == "trades"])
        for n in ast.walk(tree):
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "extend":
                self.assertFalse(isinstance(n.func.value, ast.Name) and n.func.value.id == "trades")
        agg = [n for n in ast.walk(run) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "aggregate_phase"]
        self.assertEqual(len(agg), 1)
        self.assertTrue(isinstance(agg[0].args[1], ast.Call) and agg[0].args[1].func.id == "iter_committed_trades")

    def test_r1r10_c_finalize_uses_streaming_writer_only(self):
        self.assertNotIn("trades", inspect.signature(r1r10_outputs.finalize_phase_a).parameters)
        tree = ast.parse(inspect.getsource(r1r10_outputs.finalize_phase_a))
        called = {n.func.id for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)}
        self.assertIn("write_trades_csv_streaming", called)
        self.assertNotIn("write_trades_csv", called)

    def test_r1r10_commit_releases_trades_after_checkpoint(self):
        # _commit_session keeps no sink: the only references to res.trades live inside the function.
        src = inspect.getsource(r1r10_runner._commit_session)
        self.assertNotIn(".extend(", src)
        run_src = inspect.getsource(r1r10_runner.run_phase_a)
        self.assertEqual(run_src.count("_commit_session("), 3)
        self.assertEqual(run_src.count("res = None; eng = None"), 3)

    def test_r1r10_identity_labels_and_exit_codes(self):
        self.assertEqual(RUNNER_VERSION, "MINOTAURO_PARAMETER_MARKET_DISCOVERY_V005R1_R1R10")
        phase_ps1 = (R1R10_PACKAGE_ROOT / "RUN_PHASE.ps1").read_text(encoding="utf-8")
        self.assertIn('Write-Host "MINOTAURO_V005R1_R1R10 COMMAND=$Command"', phase_ps1)
        self.assertIn("if ($ExitCode -eq 3) { Write-Host 'MEMORY_CAP_SAFE_STOP=YES'; Write-Host 'PASS=NO'; exit 3 }", phase_ps1)
        for p in sorted(R1R10_PACKAGE_ROOT.glob("*.ps1")):
            text = p.read_text(encoding="utf-8")
            self.assertNotIn("R1R8 COMMAND", text, p.name)
            self.assertNotIn("R1R9 COMMAND", text, p.name)
        self.assertEqual(r1r10_memory.MEMORY_CAP_EXIT_CODE, 3)
        self.assertNotIn(r1r10_memory.MEMORY_CAP_EXIT_CODE, (0, 1, 2, 130))
        common = (R1R10_PACKAGE_ROOT / "Minotauro_Launcher_Common.ps1").read_text(encoding="utf-8")
        self.assertIn("2>&1 | ForEach-Object {", common)
        self.assertNotIn("MINOTAURO_NATIVE_STDOUT_", common)  # R1R9 post-exit spool/replay removed
        body = common.split("function Invoke-MinotauroNative")[1].split("function Invoke-MinotauroPython")[0]
        code_lines = [ln for ln in body.splitlines() if not ln.strip().startswith("#")]
        self.assertFalse([ln for ln in code_lines if "Out-Host" in ln or "Out-Default" in ln or "Get-Content" in ln])

    def test_r1r10_every_code_file_is_bound_by_a_manifest(self):
        covered = set(RUNTIME_MANIFEST_MEMBERS) | set(GATE_MANIFEST_MEMBERS)
        code = {p.name for p in R1R10_PACKAGE_ROOT.glob("*.py")} | {p.name for p in R1R10_PACKAGE_ROOT.glob("*.ps1")}
        code |= {"MQL5/" + p.name for p in (R1R10_PACKAGE_ROOT / "MQL5").glob("*.mq5")}
        self.assertEqual(sorted(code - covered), [])
        self.assertIn("minotauro_v005r1_r1r10_memory.py", RUNTIME_MANIFEST_MEMBERS)
        self.assertIn("R1R10_LAUNCHER_SELFTEST.ps1", GATE_MANIFEST_MEMBERS)


if __name__ == "__main__":
    unittest.main(verbosity=2)
