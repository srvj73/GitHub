# MINOTAURO launcher common helpers — R1R10 operational live-output/transcript hardening only.
# No economic semantics live here.
Set-StrictMode -Version 2.0

function Test-Python314Candidate {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [switch]$Launcher
    )
    try {
        if ($Launcher) {
            & $Path -3.14 -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,14) else 14)" *> $null
        } else {
            & $Path -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,14) else 14)" *> $null
        }
        return ($LASTEXITCODE -eq 0)
    }
    catch {
        return $false
    }
}

function Resolve-RealPython {
    $Candidates = @(
        @{ Path = "$env:LOCALAPPDATA\Python\pythoncore-3.14-64\python.exe"; Launcher = $false },
        @{ Path = "$env:LOCALAPPDATA\Programs\Python\Python314\python.exe"; Launcher = $false },
        @{ Path = "$env:LOCALAPPDATA\Programs\Python\Launcher\py.exe"; Launcher = $true }
    )
    foreach ($Candidate in $Candidates) {
        $Path = [string]$Candidate.Path
        if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { continue }
        if (Test-Python314Candidate -Path $Path -Launcher:([bool]$Candidate.Launcher)) { return $Path }
    }

    $PathPy = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($null -ne $PathPy -and (Test-Python314Candidate -Path $PathPy.Source -Launcher)) {
        return $PathPy.Source
    }

    $PathPython = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($null -ne $PathPython -and $PathPython.Source -notlike '*\WindowsApps\*' -and (Test-Python314Candidate -Path $PathPython.Source)) {
        return $PathPython.Source
    }

    throw 'PYTHON_3_14_REAL_NOT_FOUND'
}

function ConvertTo-MinotauroNativeLine {
    param($Item)
    if ($Item -is [System.Management.Automation.ErrorRecord]) {
        $Text = $null
        if ($null -ne $Item.Exception) { $Text = $Item.Exception.Message }
        if ($null -eq $Text) { $Text = $Item.ToString() }
        return ('[stderr] ' + [string]$Text)
    }
    return [string]$Item
}

function Invoke-MinotauroNative {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(Mandatory=$true)][AllowEmptyCollection()][string[]]$Arguments,
        [scriptblock]$LineObserver = $null
    )
    # R1R10 (m-c): the native process is streamed line by line WHILE it runs.
    # stdout and stderr are merged into the pipeline (stderr arrives as
    # ErrorRecord objects and is re-labelled '[stderr] '), and every line is
    # re-emitted exclusively through Write-Host, the host stream that Windows
    # PowerShell 5.1 Start-Transcript captures (proven by the R1R7/R1R8/R1R9
    # owner smokes). The downstream command is ForEach-Object, never Out-Host or
    # Out-Default, so the native stdout is always redirected into the pipeline
    # (R1R8 Out-Host lesson). No temporary spool file exists anymore.
    # The native exit code ($LASTEXITCODE right after the pipeline) is the sole
    # pass/fail authority; the printed text is never parsed for success.
    # -LineObserver is used only by R1R10_LAUNCHER_SELFTEST.ps1 to timestamp
    # each line right after Write-Host (live-arrival proof); launchers omit it.
    $PreviousEap = $ErrorActionPreference
    $ExitCode = $null
    try {
        # Local 'Continue' so that merged native stderr lines are data, not
        # terminating NativeCommandError exceptions (EAP=Stop in callers).
        $ErrorActionPreference = 'Continue'
        $global:LASTEXITCODE = $null
        & $FilePath @Arguments 2>&1 | ForEach-Object {
            $Line = ConvertTo-MinotauroNativeLine $_
            Write-Host $Line
            if ($null -ne $LineObserver) { & $LineObserver $Line | Out-Null }
        }
        $ExitCode = $global:LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $PreviousEap
    }
    if ($null -eq $ExitCode) { throw "NATIVE_EXIT_CODE_MISSING=$FilePath" }
    return [int]$ExitCode
}

function Invoke-MinotauroPython {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Python,
        [Parameter(Mandatory=$true)][string[]]$Arguments,
        [scriptblock]$LineObserver = $null
    )
    if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { throw "PYTHON_MISSING=$Python" }

    $EffectiveArguments = @()
    if ($Python -like '*\py.exe') { $EffectiveArguments += '-3.14' }
    # R1R10 (m-c): -u = unbuffered stdout/stderr so each line reaches the host
    # while Python runs. Buffering only; no semantic effect on the program.
    $EffectiveArguments += '-u'
    $EffectiveArguments += $Arguments
    return (Invoke-MinotauroNative -FilePath $Python -Arguments $EffectiveArguments -LineObserver $LineObserver)
}

function Start-MinotauroTranscript {
    param(
        [Parameter(Mandatory=$true)][string]$Config,
        [Parameter(Mandatory=$true)][string]$LauncherName
    )
    if ($env:MINOTAURO_TRANSCRIPT_ACTIVE -eq '1') {
        if ([string]::IsNullOrWhiteSpace($env:MINOTAURO_TRANSCRIPT_PATH) -or -not (Test-Path -LiteralPath $env:MINOTAURO_TRANSCRIPT_PATH -PathType Leaf)) {
            throw 'TRANSCRIPT_ACTIVE_STATE_INVALID'
        }
        return $false
    }
    if (-not (Test-Path -LiteralPath $Config -PathType Leaf)) { throw "CONFIG_MISSING=$Config" }

    $Cfg = Get-Content -LiteralPath $Config -Raw | ConvertFrom-Json
    $OutRoot = [string]$Cfg.out_root
    if ([string]::IsNullOrWhiteSpace($OutRoot)) { throw 'CONFIG_OUT_ROOT_MISSING' }
    if (-not [System.IO.Path]::IsPathRooted($OutRoot)) { throw "CONFIG_OUT_ROOT_NOT_ABSOLUTE=$OutRoot" }
    $LogRoot = Join-Path $OutRoot 'LOGS'
    New-Item -ItemType Directory -Force -Path $LogRoot | Out-Null

    $Base = [System.IO.Path]::GetFileNameWithoutExtension($LauncherName)
    $Stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $LogPath = Join-Path $LogRoot ("{0}_{1}_PID{2}.log" -f $Stamp,$Base,$PID)
    Start-Transcript -LiteralPath $LogPath -Force | Out-Null
    $env:MINOTAURO_TRANSCRIPT_ACTIVE = '1'
    $env:MINOTAURO_TRANSCRIPT_PATH = $LogPath
    Write-Host "TRANSCRIPT=$LogPath"
    return $true
}

function Stop-MinotauroTranscriptSafe {
    param([bool]$Owned)
    if (-not $Owned) { return }
    try { Stop-Transcript | Out-Null } catch { }
    Remove-Item Env:MINOTAURO_TRANSCRIPT_ACTIVE -ErrorAction SilentlyContinue
    Remove-Item Env:MINOTAURO_TRANSCRIPT_PATH -ErrorAction SilentlyContinue
}
