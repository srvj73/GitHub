# R1R10 MONOWORK BLOCKER — EVIDENCE

## Parent physical identities

- `minotauro_v004_runner.py`: `E5E87B55C142159E84E39E44A8AF3E3BA6055CCDADFDAD022599E91A3FED25B9`
- `minotauro_v004_core.py`: `97F8F957300D37966913C872B7F04E498D30B0CFF68180993DB80D314B900827`
- `minotauro_v004_io.py`: `DC816C617AA6586828CEC769B21741D5BC4106FA8A72B933F1BE76D4E1BCAF4F`
- `minotauro_v005r1_r23_outputs.py`: `4507A1D9479E3EABC3FA74204D708F6B67F9884321D2D9D46CF12BDC48C48124`
- `SPEC_V005R1_R2_3_APPROVED.md`: `D6D791083870015BF07BF4ABF64718D37F9136FA247D49DB31B4DC8DE2E73747`

## Physical code facts

`run_phase_a()` in the parent R1R10:

1. loads one global checkpoint;
2. iterates tick files serially;
3. iterates records serially;
4. builds one `SessionEngine` containing all 435 cells;
5. initializes each new session from global checkpoint arrays;
6. commits one session;
7. replaces global state arrays with that session's final state;
8. only then begins the next session.

No ProcessPoolExecutor/multiprocessing worker scheduler exists in the parent economic path.

## Cross-session state proving session-parallelism unsafe

The next session receives:

- `cp["cash"]`;
- `cp["hwm"]`;
- `cp["maxdd"]`;
- `cp["regime_min"]`;
- `cp["closed_hwm"]`;
- `cp["closed_maxdd"]`.

`_commit_session()` then overwrites those arrays with the completed session's result and atomically writes the checkpoint.

Therefore sessions cannot be independently submitted with the same initial state.

## Natural intra-session decomposition

`SessionEngine` explicitly supports a chosen subset of cells. The 435 valid cells form 15 complete `(p_idx,t_idx)` groups. `active` episode state and `group_cells` are keyed by `(p_idx,t_idx)`, which makes the complete group the proposed atomic shard boundary.

## Main unresolved risk

Canonical output order from a monolithic engine interleaves events across cells/groups at each tick and engine stage. Naive concatenation of per-worker day-level outputs would change physical ordering and gzip bytes.

R1R11 must prove a deterministic total merge order reproducing the parent oracle exactly. If this cannot be done without altering economic semantics, the design must fail closed.
