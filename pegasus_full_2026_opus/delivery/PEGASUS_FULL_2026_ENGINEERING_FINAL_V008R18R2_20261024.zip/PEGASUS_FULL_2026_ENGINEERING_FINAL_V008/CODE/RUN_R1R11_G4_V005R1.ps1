#requires -Version 5.1
[CmdletBinding()] param(
 [Parameter(Mandatory=$true)][string]$OwnerEvidenceRoot,
 [Parameter(Mandatory=$true)][string]$LedgerRoot,
 [Parameter(Mandatory=$true)][string]$A0GoReceipt,
 [Parameter(Mandatory=$true)][string]$DevBenchReceipt
)
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'POWERSHELL_5_1_REQUIRED' }
. (Join-Path $PSScriptRoot 'Minotauro_Launcher_Common.ps1'); $Python=Resolve-RealPython
Write-Host 'AMBIENTE=PowerShell R1R11_V005R1_G4 ONE_SHOT=YES SAME_IDENTITY_RERUN=NO'
& $Python -X utf8 -B (Join-Path $PSScriptRoot 'r1r11_g4_controller.py') --owner-output ([IO.Path]::GetFullPath($OwnerEvidenceRoot)) --ledger-root ([IO.Path]::GetFullPath($LedgerRoot)) --a0-receipt ([IO.Path]::GetFullPath($A0GoReceipt)) --dev-bench-receipt ([IO.Path]::GetFullPath($DevBenchReceipt))
exit $LASTEXITCODE
