from __future__ import annotations

import argparse
import json
from pathlib import Path

from r1r11_owner_gates import verify_package
from minotauro_v005r1_r23_contract import (
    SPEC_SHA256, canonical_json_hash, runner_identity, sha256_file, write_json_atomic_canonical,
)

CANONICAL_SESSION_FILES = {
    "trades.jsonl.gz", "events.jsonl.gz", "equity.jsonl.gz",
    "equity_reconciliation.jsonl.gz", "session_receipt.json",
}


def _load(path: Path, label: str) -> dict:
    if not path.is_file(): raise RuntimeError(f"FULL_HOMOLOGATION_REQUIRED_FILE_MISSING {label} {path}")
    obj = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(obj, dict): raise RuntimeError(f"FULL_HOMOLOGATION_JSON_NOT_OBJECT {label}")
    return obj


def _verify_manifest(path: Path, root: Path, *, exact_actual: bool = False) -> tuple[int, str]:
    if not path.is_file(): raise RuntimeError("FULL_HOMOLOGATION_MANIFEST_MISSING " + str(path))
    listed = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        if not raw.strip(): continue
        h, rel = raw.split(None, 1); rel = rel.strip().removeprefix("./")
        p = (root / rel).resolve()
        if not p.is_relative_to(root.resolve()) or rel in listed or not p.is_file():
            raise RuntimeError("FULL_HOMOLOGATION_MANIFEST_MEMBER_INVALID " + rel)
        got = sha256_file(p)
        if got != h.upper(): raise RuntimeError(f"FULL_HOMOLOGATION_MANIFEST_HASH_MISMATCH {rel}")
        listed[rel] = got
    if exact_actual:
        actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and p != path and p.name != "CHECKPOINT.json" and not p.name.endswith(".tmp")}
        if set(listed) != actual:
            raise RuntimeError("FULL_HOMOLOGATION_MASTER_MANIFEST_SET_MISMATCH " + repr(actual ^ set(listed)))
    return len(listed), sha256_file(path)


def homologate(cfg: dict, transcript: Path, pkg: Path) -> dict:
    package_hash = verify_package()
    rh, _ = runner_identity(pkg)
    root = Path(cfg["out_root"]).resolve()
    out = root / "PHASE_A"
    if not out.is_dir(): raise RuntimeError("FULL_HOMOLOGATION_PHASE_A_MISSING")
    if not transcript.is_file(): raise RuntimeError("FULL_HOMOLOGATION_TRANSCRIPT_MISSING")
    text = transcript.read_text(encoding="utf-8", errors="replace")
    if "PHASE_A_RUN=PASS sessions=250" not in text:
        raise RuntimeError("FULL_HOMOLOGATION_PASS_LINE_MISSING")
    if "RUN_BLOCKED=" in text or "Traceback" in text or "MEMORY_CAP_SAFE_STOP" in text:
        raise RuntimeError("FULL_HOMOLOGATION_ADVERSE_TRANSCRIPT_MARKER")

    cp = _load(out / "CHECKPOINT.json", "CHECKPOINT")
    completed = list(cp.get("completed", [])); verified = cp.get("verified_months", {})
    if len(completed) != 250 or len(set(completed)) != 250:
        raise RuntimeError(f"FULL_HOMOLOGATION_COMPLETED_NOT_250 got={len(completed)}")
    if not isinstance(verified, dict) or len(verified) != 12:
        raise RuntimeError(f"FULL_HOMOLOGATION_MONTHS_NOT_12 got={len(verified) if isinstance(verified,dict) else -1}")

    sessions = out / "sessions"
    actual = {p.name for p in sessions.iterdir() if p.is_dir()} if sessions.is_dir() else set()
    if actual != set(completed):
        raise RuntimeError("FULL_HOMOLOGATION_SESSION_SET_MISMATCH")
    for s in sorted(actual):
        names = {p.name for p in (sessions / s).iterdir() if p.is_file()}
        if names != CANONICAL_SESSION_FILES:
            raise RuntimeError(f"FULL_HOMOLOGATION_SESSION_FILE_SET {s} {sorted(names)}")

    lossless = _load(out / "EQUITY_LOSSLESS_GATE.json", "EQUITY_LOSSLESS_GATE")
    if lossless.get("status") != "PASS" or int(lossless.get("mismatch_count", -1)) != 0:
        raise RuntimeError("FULL_HOMOLOGATION_EQUITY_LOSSLESS_NOT_PASS")
    freeze_p = out / "SELECTION_FREEZE.json"; freeze = _load(freeze_p, "SELECTION_FREEZE")
    if freeze.get("spec_sha256") != SPEC_SHA256 or freeze.get("runner_sha256") != rh:
        raise RuntimeError("FULL_HOMOLOGATION_FREEZE_IDENTITY_DRIFT")
    expected_freeze = canonical_json_hash(freeze, exclude_keys=("freeze_sha256",))
    if freeze.get("freeze_sha256") != expected_freeze:
        raise RuntimeError("FULL_HOMOLOGATION_FREEZE_HASH_INVALID")

    econ_count, econ_manifest_sha = _verify_manifest(out / "ECONOMIC_OUTPUTS_SHA256SUMS.txt", out)
    master_count, master_manifest_sha = _verify_manifest(out / "SHA256SUMS.txt", out, exact_actual=True)
    run_manifest = _load(out / "RUN_MANIFEST.json", "RUN_MANIFEST")

    gates = root / "GATES"
    auth_p = gates / "OWNER_RUN_A_AUTHORIZATION.json"
    pp_p = gates / "R1R11_POSTPILOT_PROMOTION_RECEIPT.json"
    audit_p = gates / "R1R11_FINAL_PREPILOT_AUDIT_RECEIPT.json"
    auth = _load(auth_p, "OWNER_RUN_A_AUTHORIZATION")
    pp = _load(pp_p, "POSTPILOT_PROMOTION")
    audit = _load(audit_p, "FINAL_PREPILOT_AUDIT")
    if auth.get("RUN_A_AUTHORIZED") != "YES": raise RuntimeError("FULL_HOMOLOGATION_OWNER_RUN_AUTH_NOT_PASS")
    if pp.get("R1R11_POSTPILOT_PROMOTION") != "PASS" or pp.get("PP1_PP9") != "PASS_9_OF_9":
        raise RuntimeError("FULL_HOMOLOGATION_PP1_PP9_NOT_PASS")
    if audit.get("R1R11_FINAL_PREPILOT_AUDIT") != "PASS":
        raise RuntimeError("FULL_HOMOLOGATION_FINAL_AUDIT_NOT_PASS")

    receipt = {
        "FULL_RUN_HOMOLOGATION": "PASS",
        "sessions": 250, "verified_months": 12,
        "package_sha256": package_hash, "spec_sha256": SPEC_SHA256, "runner_sha256": rh,
        "checkpoint_sha256": sha256_file(out / "CHECKPOINT.json"),
        "run_manifest_sha256": sha256_file(out / "RUN_MANIFEST.json"),
        "selection_freeze_sha256": sha256_file(freeze_p),
        "selection_status": freeze.get("status"), "selected_cell_id": freeze.get("selected_cell_id"),
        "equity_lossless_gate_sha256": sha256_file(out / "EQUITY_LOSSLESS_GATE.json"),
        "economic_manifest_sha256": econ_manifest_sha, "economic_manifest_entries": econ_count,
        "master_manifest_sha256": master_manifest_sha, "master_manifest_entries": master_count,
        "owner_run_authorization_sha256": sha256_file(auth_p),
        "postpilot_promotion_sha256": sha256_file(pp_p),
        "final_prepilot_audit_receipt_sha256": sha256_file(audit_p),
        "full_run_transcript_sha256": sha256_file(transcript),
        "run_manifest": run_manifest,
    }
    dest = gates / "R1R11_FULL_RUN_HOMOLOGATION_RECEIPT.json"
    write_json_atomic_canonical(dest, receipt)
    return receipt


def main() -> None:
    ap = argparse.ArgumentParser(); ap.add_argument("--config", required=True); ap.add_argument("--transcript", required=True)
    ns = ap.parse_args(); cfg = json.loads(Path(ns.config).read_text(encoding="utf-8")); pkg = Path(__file__).resolve().parent
    r = homologate(cfg, Path(ns.transcript).resolve(), pkg)
    print(json.dumps({"FULL_RUN_HOMOLOGATION": r["FULL_RUN_HOMOLOGATION"], "sessions": r["sessions"],
                      "master_manifest_sha256": r["master_manifest_sha256"]}, sort_keys=True))


if __name__ == "__main__":
    main()
