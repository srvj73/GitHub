# R1R6 — Nota de endurecimento FP-3

A V005R1-R2.3 exige releitura integral de mês não verificado e conferência do SHA256 EOF. O parecer Opus 5.5 pós-R1R5 identificou um caso adicional: sessões podiam ter sido commitadas sob bytes divergentes e o arquivo ser restaurado byte a byte antes do resume, fazendo o SHA256 EOF voltar a conferir.

A R1R6 adiciona uma guarda estritamente fail-closed e não econômica: para cada sessão commitada, persiste o SHA256 do prefixo físico do arquivo no offset de bytes observado no instante do commit. Em releitura de mês não verificado, esses prefixos são reconferidos nos mesmos offsets.

A guarda não altera parsing, sinais, fills, custos, cutoff, seleção ou P&L. Ela apenas impede reutilização de sessão cujo histórico físico antes do commit não corresponda ao arquivo atualmente vinculado.
