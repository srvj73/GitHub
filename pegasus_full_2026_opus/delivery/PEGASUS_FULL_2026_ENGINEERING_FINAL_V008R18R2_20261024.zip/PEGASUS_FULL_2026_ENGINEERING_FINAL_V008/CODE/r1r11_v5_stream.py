"""R1R11 V005 streaming closeout.

E1-E6 implementation:
- authoritative append-only JSONL scratch, no per-line sidecar on the hot path;
- one canonical writer process per stream, active during feed;
- one independent verifier process per stream, active during feed;
- ACK-derived watermarks, bounded one-watermark lag;
- binary order proof and physical SHA binding;
- deterministic canonical gzip bytes identical to frozen gzjson for the same row order.
"""
from __future__ import annotations

import gzip
import hashlib
import io
import json
import multiprocessing as mp
import os
from pathlib import Path
import signal
import struct
import sys
import time
import traceback
import zlib
from dataclasses import dataclass

from minotauro_v004_core import ModelError, valid_cells
from r1r11_transport import GLOBAL_EVENTS, merge_key
from r1r11_v4_custody import STREAMS, identity, seal_file


def _canonical_line(row: dict) -> bytes:
    return (json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")


def _proof_key_bytes(key: tuple) -> bytes:
    if not all(isinstance(v, int) and not isinstance(v, bool) for v in key):
        raise ModelError("V5_ORDER_KEY_NON_INTEGER")
    return bytes([len(key)]) + b"".join(struct.pack(">q", int(v)) for v in key)


class V5OrderProof:
    def __init__(self, kind: str, cells):
        self.kind = kind
        self.index = {c.cell_id: i for i, c in enumerate(cells)}
        groups = sorted({(c.p_idx, c.t_idx) for c in cells})
        self.ranks = {c.cell_id: groups.index((c.p_idx, c.t_idx)) for c in cells}
        self.first = None
        self.last = None
        self.rows = 0
        self.digest = hashlib.sha256()

    def add(self, row: dict, key: tuple | None = None):
        key = merge_key(self.kind, row, self.index, self.ranks) if key is None else tuple(key)
        if self.last is not None and (key < self.last or (self.kind in ("trades", "equity_reconciliation") and key == self.last)):
            raise ModelError("V5_STAGE_ORDER_REGRESSION_OR_DUPLICATE")
        if self.kind == "events":
            ids = [self.index[c] for c in row["cell_ids"]]
            if ids != sorted(set(ids)):
                raise ModelError("V5_STAGE_EVENT_CELL_ORDER")
        if self.first is None:
            self.first = key
        self.last = key
        self.rows += 1
        self.digest.update(_proof_key_bytes(key))

    def result(self):
        return {
            "rows": self.rows,
            "first": list(self.first) if self.first is not None else None,
            "last": list(self.last) if self.last is not None else None,
            "order_sha256_binary": self.digest.hexdigest(),
        }


class V5ScratchSink:
    """Transient authoritative compressed JSONL scratch.

    V005R4 restores the V004 compressed-scratch contract while preserving E1:
    workers append canonical JSONL to gzip level 1, Z_SYNC_FLUSH once per ACKed
    feed batch, and expose the *physical compressed byte offset* as watermark.
    Writer and verifier therefore tail the same durable-visible compressed
    prefix independently without rereading hundreds of MiB of raw JSON.
    """
    def __init__(self, path, kind, cells):
        self.path = Path(path)
        self.kind = kind
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.index = {c.cell_id: i for i, c in enumerate(cells)}
        groups = sorted({(c.p_idx, c.t_idx) for c in cells})
        self.rank = {c.cell_id: groups.index((c.p_idx, c.t_idx)) for c in cells}
        self.binding = {
            "group": self.path.parent.name,
            "session": self.path.parent.parent.name,
            "run_instance": self.path.parent.parent.parent.name,
            "stream": kind,
            "generation": 1,
            "encoding": "gzip-jsonl-level1-sync-v1",
        }
        self.raw = self.path.open("xb")
        self.gz = gzip.GzipFile(filename="", mode="wb", fileobj=self.raw, mtime=0, compresslevel=1)
        self.encoder = json.JSONEncoder(sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        self.last = None
        self.count = 0
        self.uncompressed_bytes = 0
        self.physical_bytes = 0
        self.closed = False
        self.trade_line_sha256: list[str] = []

    def append(self, row: dict):
        key = merge_key(self.kind, row, self.index, self.rank)
        if self.last is not None and (key < self.last or (self.kind in ("trades", "equity_reconciliation") and key == self.last)):
            raise ModelError("V5_SCRATCH_TOTAL_ORDER")
        payload = self.encoder.encode(row).encode("utf-8")
        raw = payload + b"\n"
        self.gz.write(raw)
        self.last = key
        self.count += 1
        self.uncompressed_bytes += len(raw)
        if self.kind == "trades":
            self.trade_line_sha256.append(hashlib.sha256(payload).hexdigest())

    def flush_batch(self):
        if self.closed:
            return
        # Make every complete JSONL line in the ACKed batch visible to the two
        # independent tailers without closing the gzip member.
        self.gz.flush(zlib.Z_SYNC_FLUSH)
        self.raw.flush()
        self.physical_bytes = self.raw.tell()

    def close(self):
        if self.closed:
            return
        primary_error = None
        try:
            self.gz.close()
        except BaseException as exc:
            primary_error = exc
        try:
            self.raw.flush()
            self.physical_bytes = self.raw.tell()
            self.raw.close()
        except BaseException as cleanup_exc:
            if primary_error is None:
                primary_error = cleanup_exc
            else:
                try: primary_error.add_note(f"V5_SCRATCH_RAW_CLOSE_ERROR: {cleanup_exc!r}")
                except Exception: pass
        self.closed = bool(self.raw.closed)
        if primary_error is not None:
            raise primary_error

    def manifest(self):
        if not self.closed:
            raise ModelError("V5_SCRATCH_NOT_CLOSED")
        return {
            "binding": self.binding,
            "rows": self.count,
            "uncompressed_bytes": self.uncompressed_bytes,
            "physical_bytes": self.physical_bytes,
            "scratch": seal_file(self.path),
        }

    def recheck_final_trade_indices(self, rows: list[dict], indices):
        """Recheck only trades that can still have changed after first emission.

        The hot path records the canonical payload hash at append time.  The
        frozen economic core makes closed trades unreachable after close, so
        the future runner reserializes only the final mutable suffix plus every
        CUTOFF-enriched trade.  Cardinality still has to match the complete
        emitted stream; an omitted/duplicated append therefore remains fatal.
        """
        if self.kind != "trades":
            raise ModelError("V5_TRADE_RECHECK_WRONG_STREAM")
        if len(rows) != len(self.trade_line_sha256):
            raise ModelError("V5_TRADE_FINALITY_RECHECK_CARDINALITY")
        normalized = sorted(set(int(i) for i in indices))
        for i in normalized:
            if i < 0 or i >= len(rows):
                raise ModelError("V5_TRADE_FINALITY_RECHECK_INDEX")
            expected = hashlib.sha256(_canonical_line(rows[i])[:-1]).hexdigest()
            if expected != self.trade_line_sha256[i]:
                raise ModelError("V5_TRADE_FINALITY_RECHECK_MISMATCH")

    def recheck_final_trades(self, rows: list[dict]):
        # Legacy/public test contract retained verbatim in meaning.
        self.recheck_final_trade_indices(rows, range(len(rows)))


class _CanonicalGzip:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            raise ModelError("V5_STAGE_EXISTS")
        self.raw = self.path.open("xb")
        self.gz = gzip.GzipFile(filename="", mode="wb", fileobj=self.raw, mtime=0, compresslevel=6)
        # Keep TextIOWrapper: the frozen oracle gzjson uses this buffering path,
        # and byte identity of gzip output is part of the contract.
        self.text = io.TextIOWrapper(self.gz, encoding="utf-8", newline="\n")
        self.encoder = json.JSONEncoder(sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        self.closed = False

    def write(self, row: dict):
        self.text.write(self.encoder.encode(row) + "\n")

    def write_raw_canonical(self, raw: bytes):
        if not raw.endswith(b"\n"):
            raise ModelError("V5_STAGE_RAW_LINE_FRAME")
        # Writer may reuse the already-canonical scratch line. The independent
        # verifier reserializes the parsed dict; final gzip equality proves the
        # writer passthrough was canonical without duplicating json.dumps here.
        self.text.write(raw.decode("utf-8"))

    def close(self):
        if self.closed:
            return
        primary_error = None
        try:
            self.text.flush()
            self.text.close()
        except BaseException as exc:
            primary_error = exc
        try:
            if not self.raw.closed:
                self.raw.close()
        except BaseException as cleanup_exc:
            if primary_error is None:
                primary_error = cleanup_exc
            else:
                try: primary_error.add_note(f"V5_CANONICAL_GZIP_RAW_CLOSE_ERROR: {cleanup_exc!r}")
                except Exception: pass
        self.closed = bool(self.raw.closed)
        if primary_error is not None:
            raise primary_error


def _restrict_stage_writes(stage_root: Path):
    stage_root = stage_root.resolve()
    def audit(event, args):
        paths = []
        if event == "open" and isinstance(args[0], (str, bytes, os.PathLike)):
            p = Path(os.fsdecode(args[0])).resolve()
            mode = args[1] or ""
            flags = args[2]
            if str(p).casefold().startswith("d:\\base csv") or p.suffix.casefold() == ".csv":
                raise ModelError("V5_STREAM_SOURCE_READ_FORBIDDEN")
            if any(c in mode for c in "wax+") or flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC):
                paths = [p]
        elif event in ("os.mkdir", "os.remove", "os.rmdir"):
            paths = [Path(os.fsdecode(args[0])).resolve()]
        elif event in ("os.rename", "os.replace"):
            paths = [Path(os.fsdecode(x)).resolve() for x in args[:2]]
        if any(p != stage_root and not p.is_relative_to(stage_root) for p in paths):
            raise ModelError("V5_STREAM_WRITE_OUTSIDE_STAGE")
    sys.addaudithook(audit)


def _scratch_state(path: str):
    p = Path(path).resolve()
    return {
        "path": p,
        "group": p.parent.name,
        "file": p.open("rb"),
        "offset": 0,
        "sha": hashlib.sha256(),
        "rows": 0,
        "last": None,
        "inflater": zlib.decompressobj(16 + zlib.MAX_WBITS),
        "pending": b"",
        "uncompressed_bytes": 0,
        "finalized": False,
    }


def _close_scratch_state(state: dict):
    f = state.get("file")
    if f is not None and not f.closed:
        f.close()


def _read_delta(state: dict, kind: str, index: dict, ranks: dict, limit: int, *, final: bool = False):
    if state["finalized"]:
        raise ModelError("V5_SCRATCH_READ_AFTER_FINAL")
    remaining = int(limit) - int(state["offset"])
    if remaining < 0:
        raise ModelError("V5_SCRATCH_LIMIT_REGRESSION")
    data = state["file"].read(remaining)
    if len(data) != remaining:
        raise ModelError("V5_SCRATCH_LIMIT_NOT_VISIBLE")
    state["offset"] += len(data)
    state["sha"].update(data)
    try:
        decoded = state["inflater"].decompress(data)
        if final:
            decoded += state["inflater"].flush()
    except zlib.error as exc:
        raise ModelError("V5_SCRATCH_GZIP_DECODE") from exc
    state["pending"] += decoded
    lines = state["pending"].splitlines(keepends=True)
    if lines and not lines[-1].endswith(b"\n"):
        state["pending"] = lines.pop()
    else:
        state["pending"] = b""
    if state["pending"]:
        # Worker Z_SYNC_FLUSH happens only after complete JSONL records. Seeing
        # a partial line at an ACK watermark means visibility/custody drift.
        raise ModelError("V5_SCRATCH_PARTIAL_LINE_VISIBLE")
    if final:
        if not state["inflater"].eof or state["inflater"].unused_data:
            raise ModelError("V5_SCRATCH_GZIP_FINAL_INVALID")
        state["finalized"] = True
    rows = []
    for raw in lines:
        if not raw.endswith(b"\n"):
            raise ModelError("V5_SCRATCH_FRAME")
        try:
            row = json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ModelError("V5_SCRATCH_JSON") from exc
        if not isinstance(row, dict):
            raise ModelError("V5_SCRATCH_JSON_TYPE")
        key = merge_key(kind, row, index, ranks)
        last = state["last"]
        if last is not None and (key < last or (kind in ("trades", "equity_reconciliation") and key == last)):
            raise ModelError("V5_SCRATCH_ORDER_MISMATCH")
        state["last"] = key
        state["rows"] += 1
        state["uncompressed_bytes"] += len(raw)
        rows.append((key, row, raw))
    return rows


def _merge_materialized(kind: str, items: list[tuple], index: dict):
    items.sort(key=lambda x: x[0])
    out = []
    i = 0
    while i < len(items):
        key, row, raw = items[i]
        prefix = key[:2]
        j = i + 1
        while j < len(items) and items[j][0][:2] == prefix:
            j += 1
        block = items[i:j]
        if kind == "events" and row["event"] in GLOBAL_EVENTS:
            rows = [x[1] for x in block]
            base = {k: v for k, v in rows[0].items() if k not in ("cell_ids", "open_positions")}
            for r in rows:
                if {k: v for k, v in r.items() if k not in ("cell_ids", "open_positions")} != base:
                    raise ModelError("V5_GLOBAL_EVENT_FIELDS_DIVERGE")
            ids = [cid for r in rows for cid in r["cell_ids"]]
            if len(ids) != len(set(ids)):
                raise ModelError("V5_GLOBAL_EVENT_DUPLICATE_CELL")
            ids.sort(key=index.__getitem__)
            merged = dict(rows[0]); merged["cell_ids"] = ids
            if merged["event"] == "CUTOFF_LATCH":
                merged["open_positions"] = sum(r["open_positions"] for r in rows)
            out.append((key, merged, None))
        else:
            out.extend(block)
        i = j
    return out


def stream_main(conn, role: str, kind: str, group_paths: list[str], output_path: str, stage_root: str, binding: dict):
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    parent = mp.parent_process()
    if parent is None or not parent.is_alive():
        return
    writer = None
    try:
        stage_root = Path(stage_root).resolve()
        _restrict_stage_writes(stage_root)
        if role not in ("writer", "verifier") or kind not in STREAMS:
            raise ModelError("V5_STREAM_ROLE_OR_KIND")
        cells = valid_cells()
        index = {c.cell_id: i for i, c in enumerate(cells)}
        groups = sorted({(c.p_idx, c.t_idx) for c in cells})
        ranks = {c.cell_id: groups.index((c.p_idx, c.t_idx)) for c in cells}
        states = [_scratch_state(p) for p in group_paths]
        proof = V5OrderProof(kind, cells)

        # Only the canonical writer creates the physical gzip stage.  The
        # verifier remains an independent process and independently parses,
        # merges, reserializes and proves every canonical row, but binds its
        # result with a canonical uncompressed-line digest rather than writing
        # a second gzip copy that is deleted immediately after verification.
        if role == "writer":
            writer = _CanonicalGzip(Path(output_path))
        canonical_sha = hashlib.sha256()
        canonical_rows = 0
        canonical_bytes = 0
        conn.send({"type": "STREAM_READY", "pid": os.getpid(), "role": role, "kind": kind})
        while parent.is_alive():
            if not conn.poll(0.2):
                continue
            command = conn.recv()
            ctype = command.get("type")
            if ctype == "STOP":
                return
            if ctype not in ("WATERMARK", "FINAL"):
                raise ModelError("V5_STREAM_COMMAND")
            started = time.perf_counter_ns()
            read_started = started
            batch = []
            limits = command.get("limits") or {}
            for state in states:
                limit = limits.get(state["group"], {}).get(kind)
                if limit is None:
                    raise ModelError("V5_WATERMARK_LIMIT_MISSING")
                batch.extend(_read_delta(state, kind, index, ranks, limit, final=(ctype == "FINAL")))
            read_ended = time.perf_counter_ns()
            merge_started = read_ended
            merged = _merge_materialized(kind, batch, index)
            merge_ended = time.perf_counter_ns()
            emit_started = merge_ended
            for key, row, raw in merged:
                proof.add(row, key)
                if role == "writer" and raw is not None:
                    canonical = raw
                    writer.write_raw_canonical(raw)
                else:
                    canonical = _canonical_line(row)
                    if role == "writer":
                        writer.write(row)
                canonical_sha.update(canonical)
                canonical_rows += 1
                canonical_bytes += len(canonical)
            emit_ended = time.perf_counter_ns()
            timing = {
                "read_delta_ns": read_ended - read_started,
                "merge_ns": merge_ended - merge_started,
                "canonical_emit_ns": emit_ended - emit_started,
            }
            if ctype == "FINAL":
                if role == "writer":
                    writer.close()
                    sealed = seal_file(Path(output_path))
                else:
                    sealed = None
                consumed = {
                    str(state["path"]): {
                        "sha256": state["sha"].hexdigest(),
                        "rows": state["rows"],
                        "physical_bytes": state["offset"],
                        "uncompressed_bytes": state["uncompressed_bytes"],
                    }
                    for state in states
                }
                conn.send({
                    "type": "STREAM_FINAL",
                    "pid": os.getpid(), "role": role, "kind": kind,
                    "binding": binding, "file": sealed, "proof": proof.result(),
                    "canonical_sha256": canonical_sha.hexdigest(),
                    "canonical_rows": canonical_rows,
                    "canonical_bytes": canonical_bytes,
                    "consumed": consumed,
                    "timing_ns": timing,
                    "elapsed_ns": time.perf_counter_ns() - started,
                })
                while parent.is_alive():
                    if conn.poll(0.2):
                        if conn.recv().get("type") in ("EXIT_ACK", "STOP"):
                            return
                        raise ModelError("V5_STREAM_AFTER_FINAL_COMMAND")
                return
            conn.send({
                "type": "WATERMARK_ACK", "pid": os.getpid(), "role": role, "kind": kind,
                "watermark": int(command["watermark"]), "rows": proof.rows,
                "timing_ns": timing,
                "elapsed_ns": time.perf_counter_ns() - started,
            })
    except (EOFError, BrokenPipeError):
        pass
    except BaseException:
        try:
            conn.send({"type": "ERROR", "pid": os.getpid(), "role": role, "kind": kind, "traceback": traceback.format_exc()})
        except (EOFError, BrokenPipeError, OSError):
            pass
        raise
    finally:
        for state in locals().get("states", []):
            _close_scratch_state(state)
        conn.close()


@dataclass
class _Endpoint:
    role: str
    kind: str
    proc: object
    conn: object
    pending_watermark: int | None = None
    registry_path: str | None = None
    creation_time_100ns: int | None = None


class StreamPipeline:
    """Coordinator-owned, bounded streaming closeout pipeline."""
    def __init__(self, active):
        self.active = active
        self.runtime = active.runtime
        self.stage = active.scratch / "_canonical_stage"
        self.stage.mkdir(exist_ok=False)
        self.registry_dir = active.scratch / "_helper_registry"
        self.registry_dir.mkdir(exist_ok=False)
        self.endpoints: list[_Endpoint] = []
        context = mp.get_context("spawn")
        try:
            for kind in STREAMS:
                group_paths = [str(active.scratch / f"{g[0]}_{g[1]}" / f"{kind}.jsonl") for g in active.groups]
                for role in ("writer", "verifier"):
                    suffix = "sealed" if role == "writer" else "verify"
                    output = self.stage / f"{kind}.jsonl.gz.{suffix}"
                    parent, child = context.Pipe(duplex=True)
                    binding = {"session": active.session, "run_instance": self.runtime.instance, "stream": kind, "role": role}
                    proc = context.Process(target=stream_main, args=(child, role, kind, group_paths, str(output), str(self.stage), binding))
                    proc.start(); child.close()
                    from r1r11_resources import process_identity
                    from minotauro_v005r1_r23_contract import write_json_atomic_canonical
                    ident=process_identity(proc.pid)
                    registry_path=self.registry_dir/f'stream_{proc.pid}.helper.json'
                    endpoint=_Endpoint(role, kind, proc, parent,
                                       registry_path=str(registry_path),
                                       creation_time_100ns=int(ident['creation_time_100ns']))
                    self.endpoints.append(endpoint)
                    write_json_atomic_canonical(registry_path,{
                        'pid':int(proc.pid),'creation_time_100ns':int(ident['creation_time_100ns']),
                        'parent':os.getpid(),'role':role,'stream':kind,'run_instance':self.runtime.instance,
                    })
                    # Record ownership as each helper appears so constructor interruption
                    # cannot leave an untracked process that later passes tree-clean proof.
                    self.runtime.memory.set_processes([p.pid for p in active.children], self.pids)
            self._wait_ready()
        except BaseException as exc:
            if isinstance(exc, KeyboardInterrupt):
                self.runtime.safe_stop_requested=True
            self.close(cooperative_only=bool(getattr(self.runtime,'safe_stop_requested',False)))
            raise

    def _retire_registry(self, e):
        if not e.registry_path:
            return
        p = Path(e.registry_path)
        if not p.is_file():
            return
        obj = json.loads(p.read_text(encoding='utf-8'))
        if (int(obj.get('pid',-1)) != int(e.proc.pid) or
                int(obj.get('creation_time_100ns',-1)) != int(e.creation_time_100ns or -1) or
                str(obj.get('role')) != e.role or str(obj.get('stream')) != e.kind or
                str(obj.get('run_instance')) != str(self.runtime.instance)):
            raise ModelError('STREAM_HELPER_REGISTRY_IDENTITY_CHANGED')
        if e.proc.is_alive():
            raise ModelError(f'STREAM_HELPER_REGISTRY_RETIRE_WHILE_LIVE pid={e.proc.pid}')
        if e.proc.exitcode is None:
            raise ModelError(f'STREAM_HELPER_REGISTRY_RETIRE_WITHOUT_TERMINAL_EXIT pid={e.proc.pid}')
        p.unlink()
        try:
            p.parent.rmdir()
        except OSError:
            pass

    @property
    def pids(self):
        return [e.proc.pid for e in self.endpoints]

    def _wait_ready(self):
        deadline = time.monotonic() + self.runtime.timeout
        waiting = set(range(len(self.endpoints)))
        while waiting:
            for i in list(waiting):
                e = self.endpoints[i]
                if e.conn.poll(0.01):
                    row = e.conn.recv()
                    if row.get("type") != "STREAM_READY" or row.get("pid") != e.proc.pid or row.get("role") != e.role or row.get("kind") != e.kind:
                        raise ModelError("V5_STREAM_READY_INVALID " + json.dumps(row))
                    waiting.remove(i)
                elif not e.proc.is_alive():
                    raise ModelError("V5_STREAM_EARLY_DEATH")
            if time.monotonic() > deadline:
                raise ModelError("V5_STREAM_READY_TIMEOUT")
        self.runtime.log("STREAM_PIPELINE_READY", session=self.active.session, pids=self.pids)

    def _drain_pending(self):
        pending = [e for e in self.endpoints if e.pending_watermark is not None]
        if not pending:
            return
        deadline = time.monotonic() + self.runtime.timeout
        waiting = set(range(len(pending)))
        while waiting:
            for i in list(waiting):
                e = pending[i]
                if e.conn.poll(0.01):
                    row = e.conn.recv()
                    if (row.get("type") != "WATERMARK_ACK" or row.get("pid") != e.proc.pid or
                            row.get("role") != e.role or row.get("kind") != e.kind or
                            int(row.get("watermark", -1)) != e.pending_watermark):
                        raise ModelError("V5_STREAM_WATERMARK_ACK_INVALID " + json.dumps(row))
                    self.runtime.log(
                        "STREAM_WATERMARK_ACK", session=self.active.session,
                        **{k: row[k] for k in ("role", "kind", "watermark", "rows", "elapsed_ns")},
                        timing_ns=row.get("timing_ns", {}),
                    )
                    e.pending_watermark = None
                    waiting.remove(i)
                elif not e.proc.is_alive():
                    raise ModelError("V5_STREAM_DEATH_DURING_WATERMARK")
            if time.monotonic() > deadline:
                raise ModelError("V5_STREAM_LAG_TIMEOUT")

    def watermark(self, ordinal: int, limits: dict):
        # Bound lag to exactly one outstanding watermark per process.
        self._drain_pending()
        fault = self.runtime.fault_at('v5_stream', self.active.seq)
        if fault in ('writer_death', 'verifier_death'):
            victim = next(e for e in self.endpoints if e.role == fault.split('_')[0])
            victim.proc.terminate(); victim.proc.join(5)
        for e in self.endpoints:
            e.conn.send({"type": "WATERMARK", "watermark": int(ordinal), "limits": limits})
            e.pending_watermark = int(ordinal)

    def finalize(self, worker_groups: list[dict]):
        self._drain_pending()
        final_limits = {f"{g['group'][0]}_{g['group'][1]}": {k: int(g[k]['physical_bytes']) for k in STREAMS} for g in worker_groups}
        for e in self.endpoints:
            e.conn.send({"type": "FINAL", "watermark": int(self.active.n_records), "limits": final_limits})
        deadline = time.monotonic() + self.runtime.timeout
        waiting = set(range(len(self.endpoints))); finals = {}
        while waiting:
            for i in list(waiting):
                e = self.endpoints[i]
                if e.conn.poll(0.01):
                    row = e.conn.recv()
                    if row.get("type") != "STREAM_FINAL" or row.get("pid") != e.proc.pid:
                        raise ModelError("V5_STREAM_FINAL_INVALID " + json.dumps(row))
                    finals[(e.role, e.kind)] = row; waiting.remove(i)
                elif not e.proc.is_alive():
                    raise ModelError("V5_STREAM_DEATH_BEFORE_FINAL")
            if time.monotonic() > deadline:
                raise ModelError("V5_STREAM_FINAL_TIMEOUT")

        # The writer is the sole canonical physical publisher.  The verifier
        # independently consumes the same sealed scratch, reproduces merge and
        # canonical serialization, and must agree on canonical line digest,
        # row/byte cardinality and order proof.  This removes only the duplicate
        # verifier gzip write; semantic and physical scratch custody remain
        # independently checked.
        outputs = {}
        for kind in STREAMS:
            w = finals[("writer", kind)]; v = finals[("verifier", kind)]
            if w.get("file") is None or v.get("file") is not None:
                raise ModelError("V5_STREAM_PHYSICAL_ROLE_BINDING " + kind)
            if (w["canonical_sha256"] != v["canonical_sha256"] or
                    int(w["canonical_rows"]) != int(v["canonical_rows"]) or
                    int(w["canonical_bytes"]) != int(v["canonical_bytes"]) or
                    w["proof"] != v["proof"]):
                raise ModelError("V5_WRITER_VERIFIER_DIVERGENCE " + kind)
            for g in worker_groups:
                expected = g[kind]["scratch"]
                p = str(Path(expected["path"]).resolve())
                for row in (w, v):
                    got = row["consumed"].get(p)
                    if (got is None or got["sha256"] != expected["sha256"] or
                            int(got["rows"]) != int(g[kind]["rows"]) or
                            int(got["physical_bytes"]) != int(g[kind]["physical_bytes"]) or
                            int(got["uncompressed_bytes"]) != int(g[kind]["uncompressed_bytes"])):
                        raise ModelError("V5_SCRATCH_CONSUMPTION_BINDING " + kind)
            outputs[kind] = {
                "stream": kind,
                "binding": w["binding"],
                "file": w["file"],
                "proof": w["proof"],
                "writer_canonical_sha256": w["canonical_sha256"],
                "verifier_canonical_sha256": v["canonical_sha256"],
                "canonical_rows": w["canonical_rows"],
                "canonical_bytes": w["canonical_bytes"],
                "writer_timing_ns": w.get("timing_ns", {}),
                "verifier_timing_ns": v.get("timing_ns", {}),
            }
        for e in self.endpoints:
            e.conn.send({"type": "EXIT_ACK"})
        for e in self.endpoints:
            e.proc.join(self.runtime.timeout)
            if e.proc.is_alive() or e.proc.exitcode != 0:
                raise ModelError("V5_STREAM_EXIT_UNCONFIRMED")
            e.conn.close()
            self._retire_registry(e)
        self.runtime.log("STREAM_PIPELINE_FINALIZED", session=self.active.session, manifests=outputs)
        return outputs

    def close(self, cooperative_only=False):
        cooperative_only=True
        for e in self.endpoints:
            try:
                e.conn.send({"type": "STOP"})
            except (EOFError, OSError, BrokenPipeError):
                pass
        for e in self.endpoints:
            e.proc.join(self.runtime.timeout if cooperative_only else 2)
            if e.proc.is_alive():
                if cooperative_only:
                    raise ModelError(f'SAFE_STOP_STREAM_COOPERATIVE_TIMEOUT pid={e.proc.pid}')
                e.proc.terminate(); e.proc.join(5)
            if e.proc.is_alive():
                raise ModelError(f'V5_STREAM_STOP_UNCONFIRMED pid={e.proc.pid}')
            try:
                e.conn.close()
            except OSError:
                pass
            self._retire_registry(e)
