#requires -Version 5.1
[CmdletBinding()] param([Parameter(Mandatory=$true)][string]$Config)
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'POWERSHELL_5_1_REQUIRED' }
. (Join-Path $PSScriptRoot 'Minotauro_Launcher_Common.ps1')
$ConfigPath=[IO.Path]::GetFullPath($Config);$Owned=Start-MinotauroTranscript -Config $ConfigPath -LauncherName $MyInvocation.MyCommand.Name
try {
 $Python=Resolve-RealPython;$HostExe=(Get-Process -Id $PID).Path
 $code=Invoke-MinotauroNative -FilePath $HostExe -Arguments @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $PSScriptRoot 'R1R11_LAUNCHER_SELFTEST.ps1'),'-Python',$Python)
 if($code-ne 0){throw "R1R11_LAUNCHER_SELFTEST_FAIL=$code"};Write-Host 'R1R11_LAUNCHER_SELFTEST=PASS'
 $code=Invoke-MinotauroPython -Python $Python -Arguments @((Join-Path $PSScriptRoot 'minotauro_v005r1_r23_gates.py'),'synthetic','--config',$ConfigPath)
 if($code-ne 0){throw "SYNTHETIC_GATE_FAIL=$code"};Write-Host 'SYNTHETIC_GATE=PASS';Write-Host 'DATA_PROCESSING=NO'
} finally {Stop-MinotauroTranscriptSafe -Owned $Owned}
