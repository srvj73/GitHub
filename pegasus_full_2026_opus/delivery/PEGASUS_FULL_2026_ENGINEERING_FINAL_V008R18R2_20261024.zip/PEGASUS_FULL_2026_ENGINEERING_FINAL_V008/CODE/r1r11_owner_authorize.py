from __future__ import annotations

import argparse
import json
from pathlib import Path

from minotauro_v005r1_r23_contract import SPEC_SHA256, runner_identity, read_json, sha256_file, write_json_atomic_canonical

FINAL_AUDIT_NAME = "R1R11_FINAL_PREPILOT_AUDIT_RECEIPT.json"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["pilot-a", "run-a"])
    ap.add_argument("--config", required=True)
    ap.add_argument("--approve", required=True)
    ns = ap.parse_args()

    cfg = json.loads(Path(ns.config).read_text(encoding="utf-8"))
    root = Path(cfg["out_root"]); pkg = Path(__file__).resolve().parent
    rh, _ = runner_identity(pkg)
    bind = root / "PHASE_A" / "RUN_SOURCE_BINDING_A.json"
    final_audit = root / "GATES" / FINAL_AUDIT_NAME
    if not bind.is_file(): raise RuntimeError("OWNER_AUTH_BINDING_MISSING")
    if not final_audit.is_file(): raise RuntimeError("OWNER_AUTH_FINAL_AUDIT_MISSING")
    audit = read_json(final_audit)
    if audit.get("R1R11_FINAL_PREPILOT_AUDIT") != "PASS" or audit.get("runner_sha256") != rh or audit.get("spec_sha256") != SPEC_SHA256:
        raise RuntimeError("OWNER_AUTH_FINAL_AUDIT_NOT_FRESH_PASS")

    if ns.mode == "pilot-a":
        if ns.approve != "I_APPROVE_PILOT_A": raise RuntimeError("EXPLICIT_PILOT_APPROVAL_TOKEN_REQUIRED")
        pre = root / "GATES" / "PRE_PILOT_GATE_RECEIPT.json"; obj = read_json(pre)
        if obj.get("PRE_PILOT_GATES") != "PASS" or int(obj.get("gates_passed", 0)) != 27:
            raise RuntimeError("OWNER_AUTH_PREPILOT_NOT_27_PASS")
        receipt = {
            "PILOT_AUTHORIZED": "YES", "spec_sha256": SPEC_SHA256, "runner_sha256": rh,
            "run_source_binding_sha256": sha256_file(bind),
            "pre_pilot_gate_receipt_sha256": sha256_file(pre),
            "final_audit_receipt_sha256": sha256_file(final_audit),
        }
        out = root / "GATES" / "OWNER_PILOT_AUTHORIZATION.json"
    else:
        if ns.approve != "I_APPROVE_RUN_A": raise RuntimeError("EXPLICIT_RUN_APPROVAL_TOKEN_REQUIRED")
        pre = root / "GATES" / "PRE_RUN_A_GATE_RECEIPT.json"
        pp = root / "GATES" / "R1R11_POSTPILOT_PROMOTION_RECEIPT.json"
        pobj = read_json(pre); ppobj = read_json(pp)
        if pobj.get("PRE_RUN_A_GATES") != "PASS" or int(pobj.get("gates_passed", 0)) != 28:
            raise RuntimeError("OWNER_AUTH_PRERUN_NOT_28_PASS")
        if ppobj.get("R1R11_POSTPILOT_PROMOTION") != "PASS" or ppobj.get("PP1_PP9") != "PASS_9_OF_9":
            raise RuntimeError("OWNER_AUTH_PP1_PP9_NOT_PASS")
        receipt = {
            "RUN_A_AUTHORIZED": "YES", "spec_sha256": SPEC_SHA256, "runner_sha256": rh,
            "run_source_binding_sha256": sha256_file(bind),
            "pre_run_a_gate_receipt_sha256": sha256_file(pre),
            "postpilot_promotion_receipt_sha256": sha256_file(pp),
            "final_audit_receipt_sha256": sha256_file(final_audit),
        }
        out = root / "GATES" / "OWNER_RUN_A_AUTHORIZATION.json"
    write_json_atomic_canonical(out, receipt)
    print(json.dumps({"OWNER_AUTHORIZATION": "PASS_CREATED", "mode": ns.mode, "path": str(out)}, sort_keys=True))


if __name__ == "__main__":
    main()
