"""Point integration of production coordinator loop with synthetic source binding."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch


class Integration(unittest.TestCase):
    def test_production_loop_single_source_and_prefixes(self):
        import minotauro_v004_runner as runner
        from r1r11_coordinator import Runtime
        from r1r11_resources import RunLock,JobMemory
        spec=importlib.util.spec_from_file_location('parent_fixture_definitions',Path(__file__).parent/'oracle/test_minotauro_v005r1_r23_operational.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as td:
            fixture=module._SyntheticPhase(Path(td),3,None)
            cfg=fixture.cfg('synthetic_multi',48528);root=Path(cfg['out_root'])
            with RunLock(root) as lock:
                runtime=Runtime(lock,JobMemory(root/'TELEMETRY/memory.jsonl'),2,32)
                try:
                    with patch.object(runner,'_prepare_phase',fixture.fake_prepare):
                        runner._run_phase_a_multi(cfg,'PILOT_A',runtime)
                finally:runtime.close()
            import json,hashlib
            cp=json.loads((root/'PILOT_A/CHECKPOINT.json').read_text())
            self.assertEqual(len(cp['completed']),3)
            for session in cp['completed']:
                receipt=json.loads((root/'PILOT_A/sessions'/session/'session_receipt.json').read_text())
                raw=Path(receipt['tick_file_path']).read_bytes()[:receipt['tick_prefix_bytes']]
                self.assertEqual(hashlib.sha256(raw).hexdigest().upper(),receipt['tick_prefix_sha256'])
            # Resume validates all sealed canonical files without reprocessing.
            with RunLock(root) as lock:
                runtime=Runtime(lock,JobMemory(root/'TELEMETRY/memory.jsonl'),3,32)
                try:
                    with patch.object(runner,'_prepare_phase',fixture.fake_prepare):
                        runner._run_phase_a_multi(cfg,'PILOT_A',runtime)
                finally:runtime.close()


if __name__=='__main__':unittest.main(verbosity=2)
