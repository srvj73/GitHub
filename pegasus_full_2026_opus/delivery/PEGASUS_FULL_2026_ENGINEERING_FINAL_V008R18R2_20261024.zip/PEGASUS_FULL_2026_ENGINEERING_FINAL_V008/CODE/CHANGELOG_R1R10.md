# CHANGELOG — MINOTAURO V005R1 R1R10 (parent R1R9)

Revisão operacional. Não altera economia, causalidade, geometria, seleção, gates, checkpoint nem formato canônico de outputs.

## Runtime (runner manifest)

- **`minotauro_v004_runner.py`**
  - `_commit_session` perde o parâmetro `trades`.
    - O `trades.extend(res.trades)` foi removido.
    - Os cinco artefatos por sessão continuam idênticos.
  - `_load_existing_trades` foi substituída por `_verify_committed_trades_present`.
    - Faz apenas a verificação de existência, com o mesmo erro `COMMITTED_TRADES_MISSING`.
    - Não carrega nenhum trade em memória.
  - `res`/`eng` são liberados logo após cada commit.
  - No finalize do `run-a`, `aggregate_phase(cells, iter_committed_trades(...), maxdd)`, e `finalize_phase_a` não recebe mais a lista de trades.
  - `run_phase_a(cfg, mode, memory_probe=None)`.
    - Exige `memory_cap_mib` e cria o `MemoryMonitor`.
    - Aplica fronteiras seguras de teto: `RUN_START`, `SESSION_COMMIT`, `MONTH_VERIFIED`, `PRE_PILOT_RECEIPT`, `PRE_FINALIZE` e `POST_FINALIZE`.
    - `POST_FINALIZE` fica antes de `SHA256SUMS.txt` e do PASS.
    - As linhas `RUN_PROGRESS` ganham o sufixo `MEM_*`.
  - `main()`: `MemoryCapSafeStop` → marcador + `SystemExit(3)`.
- **`minotauro_v005r1_r23_outputs.py`**
  - Acrescenta `iter_committed_trades` e `write_trades_csv_streaming`.
    - A contagem de cada sessão é verificada contra `session_receipt.json["trades"]`.
    - A sessão de cada trade é verificada contra o diretório.
    - Duplicatas de sessão são rejeitadas.
  - `finalize_phase_a` usa o writer em streaming.
  - `write_trades_csv` (R1R9) foi mantido sem mudança de código, como oráculo.
- **`minotauro_v005r1_r1r10_memory.py` (novo)**
  - Probe stdlib, `MemoryMonitor`, `MemoryCapSafeStop` e exit code 3.
  - Telemetria em `<out_root>/TELEMETRY/<MODE>_SESSION_TELEMETRY.jsonl`.
- **`minotauro_v005r1_r23_contract.py`**
  - `RUNNER_VERSION` → R1R10.
  - O novo módulo entra em `RUNTIME_MANIFEST_MEMBERS`.
  - `R1R10_LAUNCHER_SELFTEST.ps1` entra em `GATE_MANIFEST_MEMBERS`.
- **`Minotauro_Launcher_Common.ps1`**
  - Novo `Invoke-MinotauroNative`: streaming ao vivo `2>&1 | ForEach-Object { Write-Host }`, stderr com o prefixo `[stderr] ` e `$LASTEXITCODE` como autoridade.
  - `Invoke-MinotauroPython` adiciona `-u` e delega ao `Invoke-MinotauroNative`.
  - O spool temporário e o replay pós-saída foram removidos.
  - Novo parâmetro opcional `-LineObserver`, usado só pelo autoteste.
- **`RUN_PHASE.ps1`**
  - O rótulo passa a `MINOTAURO_V005R1_R1R10 COMMAND=`.
  - O exit 3 é mapeado para `MEMORY_CAP_SAFE_STOP=YES` / `PASS=NO` / `exit 3`.
- **`config.example.json`**
  - `out_root` → `…_R1R10`.
  - `"memory_cap_mib": null`: placeholder fail-closed que exige decisão do owner.

## Gates (gate manifest)

- **`RUN_SYNTHETIC_GATES.ps1`:** executa `R1R10_LAUNCHER_SELFTEST.ps1` em um processo filho do mesmo host, antes do gate sintético.
- **`R1R10_LAUNCHER_SELFTEST.ps1` (novo):** 16 verificações fail-closed (B7–B10).
- **`test_minotauro_v005r1_r23_operational.py`**
  - As 4 chamadas existentes a `_commit_session` deixam de passar a lista `trades`. Nenhuma asserção foi alterada ou removida.
  - Foram adicionados 24 testes R1R10 (B1–B6, C, D e telemetria).
  - O total de testes operacionais passa de 10 para 34.

## Documentação e evidência (fora dos manifests)

- Novos:
  - `README_R1R10.md`
  - `PACKAGE_INDEX_R1R10.md`
  - `CHANGELOG_R1R10.md`
  - `R1R10_CORRECTIVE_COMPLIANCE.md`
  - `AUDIT_OPUS55_R1R9_POSTPILOT_FINAL_20260926.md` (cópia da auditoria governante)
  - `FROZEN_FILES_IDENTITY_R1R10.json`
  - `BUILD_SELFTEST_LOG_R1R10.txt`
  - `DIFF_R1R9_TO_R1R10.patch`
  - `IMPLEMENTATION_RECEIPT_R1R10.json`
- `SHA256SUMS.txt` foi regenerado.
- Os documentos históricos R1R9 e anteriores permanecem byte-idênticos.
