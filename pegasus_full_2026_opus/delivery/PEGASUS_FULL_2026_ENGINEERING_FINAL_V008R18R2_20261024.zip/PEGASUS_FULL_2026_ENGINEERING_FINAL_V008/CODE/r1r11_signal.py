"""Owner fault test only: deliver real Ctrl+C to a dedicated hidden test console."""
import argparse
import ctypes
import time


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pid',type=int,required=True);ns=ap.parse_args()
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.FreeConsole()
    if not k.AttachConsole(ns.pid):raise ctypes.WinError(ctypes.get_last_error())
    if not k.SetConsoleCtrlHandler(None,True):raise ctypes.WinError(ctypes.get_last_error())
    if not k.GenerateConsoleCtrlEvent(0,0):raise ctypes.WinError(ctypes.get_last_error())
    time.sleep(0.5);k.FreeConsole()


if __name__=='__main__':main()
