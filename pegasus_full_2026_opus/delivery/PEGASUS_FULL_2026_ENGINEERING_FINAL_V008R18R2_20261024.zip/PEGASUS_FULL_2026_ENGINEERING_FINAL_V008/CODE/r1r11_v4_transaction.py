"""Coordinator-only V004 journal -> pending -> session -> checkpoint protocol."""
import hashlib
import json
import os
from pathlib import Path
import re
from minotauro_v004_core import ModelError
from minotauro_v005r1_r23_contract import canonical_json_bytes
from r1r11_v4_custody import STREAMS, sha, sync_directory, sync_file, verify_file

NAMES=tuple(k+'.jsonl.gz' for k in STREAMS)+('session_receipt.json',)
FAULTS=('before_journal','after_journal','during_pending','after_pending',
        'before_publish','after_commit_before_checkpoint','during_checkpoint_replace',
        'after_checkpoint_before_cleanup')


def digest(data):return hashlib.sha256(data).hexdigest()


def durable_exclusive(path,data):
    with Path(path).open('xb') as f:
        f.write(data);f.flush();os.fsync(f.fileno())


def replace_checkpoint(path,data,inject=lambda p:None):
    path=Path(path);tmp=path.with_name(path.name+'.v004-next')
    if tmp.exists():
        if tmp.read_bytes()!=data:raise ModelError('CHECKPOINT_TEMP_UNEXPECTED')
    else:durable_exclusive(tmp,data)
    inject('during_checkpoint_replace')
    os.replace(tmp,path);sync_file(path);sync_directory(path.parent)


def validate_tree(path,files):
    if set(files)!=set(NAMES) or {p.name for p in Path(path).iterdir()}!=set(NAMES):
        raise ModelError('TRANSACTION_FILES_MISMATCH')
    for n,m in files.items():
        p=Path(path)/n
        if not p.is_file() or p.stat().st_size!=m['bytes'] or sha(p)!=m['sha256']:
            raise ModelError('TRANSACTION_FILE_HASH '+n)


def prepare_volume(out,scratch):
    out=Path(out).resolve();scratch=Path(scratch).resolve()
    for p in (out/'_commit_journal',out/'sessions',scratch):
        p.mkdir(parents=True,exist_ok=True)
        if p.stat().st_dev!=out.stat().st_dev:raise ModelError('TRANSACTION_CROSS_VOLUME')
        for parent in (p,*p.parents):
            if parent.is_symlink() or parent.is_junction():raise ModelError('TRANSACTION_REPARSE_PATH')
    sync_directory(out)


def commit(out,s,res,cells,cp,done,calendar_row,cp_path,tick_path,source_hasher,runtime):
    from minotauro_v004_runner import _hash_completed,_checkpoint_with_hash
    out=Path(out).resolve();cp_path=Path(cp_path).resolve();active=runtime.active
    if active is None or active.session!=s:raise ModelError('TRANSACTION_ACTIVE_SESSION')
    legacy_fields=('first_cutoff_bid_msc','first_cutoff_ask_msc','cutoff_long_fill_msc',
                   'cutoff_short_fill_msc','cutoff_long_latency_ms','cutoff_short_latency_ms')
    metadata={}
    for k in legacy_fields:
        v=calendar_row.get(k)
        metadata[k]=None if v in (None,'') else int(v)
    for side in ('long','short'):
        kind_key=f'r3_{side}_x_kind'
        kind=str(calendar_row.get(kind_key,''))
        if kind not in ('L0','L1'):
            raise ModelError('R3_CUTOFF_KIND_INVALID '+side)
        metadata[kind_key]=kind
        for suffix in ('ordinal','time_msc','price_micro','last_micro'):
            k=f'r3_{side}_x_{suffix}'
            v=calendar_row.get(k)
            if v in (None,''):
                raise ModelError('R3_CUTOFF_METADATA_MISSING '+k)
            metadata[k]=int(v)
    stages=active.stage_outputs
    if not isinstance(stages,dict) or set(stages)!=set(STREAMS):
        raise ModelError('V5_STREAM_STAGE_OUTPUTS_REQUIRED')
    expected_fills={'BUY':metadata['r3_long_x_time_msc'],'SELL':metadata['r3_short_x_time_msc']}
    for direction,fill in active.cutoff_fills.items():
        if int(fill)!=int(expected_fills[direction]):
            raise ModelError('CUTOFF_PREFLIGHT_REPLAY_MISMATCH')
    prefix_bytes,prefix_sha=(source_hasher.snapshot() if source_hasher is not None else (None,None))
    receipt={'session':s,'trades':sum(g['trades']['rows'] for g in active.final_groups),
        'end_cash_units':res.end_cash_units,'hwm_units':res.hwm_units,'max_dd_units':res.max_dd_units,
        'regime_min_units':res.regime_min_units,'closed_hwm_units':res.closed_hwm_units,
        'closed_max_dd_units':res.closed_max_dd_units,'cutoff_diagnostics_runtime':res.cutoff_diagnostics,
        'cutoff_diagnostics_preflight':metadata,'precutoff_crossed_state_count':res.precutoff_crossed_state_count,
        'tick_file_path':str(tick_path) if tick_path is not None else None,
        'tick_prefix_bytes':prefix_bytes,'tick_prefix_sha256':prefix_sha}
    receipt_bytes=canonical_json_bytes(receipt)
    next_cp=dict(cp)
    next_cp.update(cash=res.end_cash_units,hwm=res.hwm_units,maxdd=res.max_dd_units,
        regime_min=res.regime_min_units,closed_hwm=res.closed_hwm_units,closed_maxdd=res.closed_max_dd_units)
    next_cp['completed']=sorted(done|{s});next_cp['last_committed_session_date']=max(next_cp['completed'])
    next_cp['completed_sessions_sha256']=_hash_completed(next_cp['completed'])
    next_cp=_checkpoint_with_hash(next_cp);next_bytes=canonical_json_bytes(next_cp)
    final=out/'sessions'/s;pending=final.with_name(s+'.pending')
    if final.exists() or pending.exists():raise ModelError('TRANSACTION_DESTINATION_EXISTS')
    files={k+'.jsonl.gz':{'sha256':stages[k]['file']['sha256'],
        'bytes':stages[k]['file']['identity']['bytes'],'rows':stages[k]['proof']['rows']} for k in STREAMS}
    files['session_receipt.json']={'sha256':digest(receipt_bytes),'bytes':len(receipt_bytes)}
    journal={'version':'V005R1','out_root':str(out),'session':s,'run_instance':runtime.instance,
        'checkpoint_path':str(cp_path),'checkpoint_previous_sha256':sha(cp_path),
        'checkpoint_next':next_cp,'checkpoint_next_sha256':digest(next_bytes),'files':files}
    journal['journal_sha256']=digest(canonical_json_bytes(journal))
    jp=out/'_commit_journal'/(s+'.'+runtime.instance+'.json')
    runtime.memory.boundary('PRE_COMMIT_TRANSACTION',s)
    runtime.inject('before_journal');durable_exclusive(jp,canonical_json_bytes(journal));sync_directory(jp.parent)
    runtime.inject('after_journal');pending.mkdir(exist_ok=False)
    for i,k in enumerate(STREAMS):
        verify_file(stages[k]['file'])
        p=Path(stages[k]['file']['path'])
        if p.stat().st_dev!=pending.stat().st_dev:raise ModelError('STAGE_RENAME_CROSS_VOLUME')
        os.rename(p,pending/(k+'.jsonl.gz'))
        if i==0:
            runtime.inject('during_merge')  # legacy G7 fault point mapped to V5 stage transfer
            runtime.inject('during_pending')
    durable_exclusive(pending/'session_receipt.json',receipt_bytes)
    validate_tree(pending,files)
    for p in pending.iterdir():sync_file(p)
    sync_directory(pending);runtime.inject('after_pending')
    runtime.seal_precommit(out,s,pending,files)
    runtime.inject('after_merge_before_commit');runtime.inject('before_publish')
    os.rename(pending,final);sync_directory(final.parent);validate_tree(final,files)
    runtime.inject('after_commit_before_checkpoint')
    replace_checkpoint(cp_path,next_bytes,runtime.inject)
    cp.clear();cp.update(next_cp);done.add(s)
    runtime.inject('after_checkpoint_before_cleanup')
    archive_journal(jp,'COMMITTED')
    print(f'SESSION_COMMIT session={s} trades={receipt["trades"]}',flush=True)


def recover(out):
    """Called under the exclusive run lock, before any scratch purge."""
    from r1r11_resources import safe_remove_scratch
    from minotauro_v004_runner import _verify_checkpoint_self
    out=Path(out).resolve()
    for phase in ('PILOT_A','PHASE_A','PHASE_B','PHASE_C'):
        if (out/phase/'_commit_journal').exists():recover(out/phase)
    journal_root=out/'_commit_journal'
    paths=sorted(journal_root.iterdir()) if journal_root.exists() else []
    if len(paths)>1:raise ModelError('MULTIPLE_UNRESOLVED_JOURNALS')
    for jp in paths:
        j=json.loads(jp.read_text(encoding='utf-8'))
        signature=j.pop('journal_sha256',None)
        if digest(canonical_json_bytes(j))!=signature:raise ModelError('JOURNAL_HASH')
        s=j['session'];instance=j['run_instance']
        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',s) or not re.fullmatch(r'\d+_\d+',instance):
            raise ModelError('JOURNAL_IDENTITY')
        if jp.name!=s+'.'+instance+'.json' or j['out_root']!=str(out) or j['version']!='V005R1':
            raise ModelError('JOURNAL_BINDING')
        cp_path=Path(j['checkpoint_path'])
        if cp_path!=out/'CHECKPOINT.json':raise ModelError('JOURNAL_CHECKPOINT_PATH')
        next_bytes=canonical_json_bytes(j['checkpoint_next'])
        if digest(next_bytes)!=j['checkpoint_next_sha256']:raise ModelError('JOURNAL_NEXT_HASH')
        _verify_checkpoint_self(j['checkpoint_next'])
        if s not in j['checkpoint_next']['completed']:raise ModelError('JOURNAL_NEXT_SESSION')
        if not cp_path.exists():raise ModelError('JOURNAL_PREVIOUS_MISSING')
        cp_hash=sha(cp_path);old=j['checkpoint_previous_sha256'];nxt=j['checkpoint_next_sha256']
        if cp_hash not in (old,nxt):raise ModelError('CHECKPOINT_THIRD_STATE')
        final=out/'sessions'/s;pending=final.with_name(s+'.pending')
        if final.exists():
            if pending.exists():raise ModelError('BOTH_FINAL_AND_PENDING')
            validate_tree(final,j['files'])
            if cp_hash==old:replace_checkpoint(cp_path,next_bytes)
        else:
            if cp_hash!=old:raise ModelError('CHECKPOINT_ADVANCED_WITHOUT_SESSION')
            if pending.exists():safe_remove_scratch(pending,out/'sessions')
        archive_journal(jp,'RECOVERED_COMMITTED' if final.exists() else 'RECOVERED_REQUEUE')
    cp_path=out/'CHECKPOINT.json'
    if cp_path.exists():
        cp=json.loads(cp_path.read_text());_verify_checkpoint_self(cp)
        sessions=out/'sessions';actual={p.name for p in sessions.iterdir() if p.is_dir()} if sessions.exists() else set()
        if actual!=set(cp['completed']):raise ModelError('SESSION_CHECKPOINT_WITHOUT_JOURNAL')
    elif (out/'sessions').exists() and any((out/'sessions').iterdir()):
        raise ModelError('SESSION_WITHOUT_CHECKPOINT')


def archive_journal(jp,outcome):
    """Preserve original journal bytes; never replace a prior archive."""
    jp=Path(jp);dest=jp.parent.parent/'_journal_history';dest.mkdir(exist_ok=True)
    target=dest/(jp.name+'.'+outcome)
    if target.exists():
        if target.read_bytes()!=jp.read_bytes(): raise ModelError('JOURNAL_ARCHIVE_CONFLICT')
        jp.unlink()
    else: os.rename(jp,target)
    sync_directory(dest);sync_directory(jp.parent)
