"""R1R11 V005 economic worker.

Writable capability remains restricted to assigned scratch. V005 emits canonical
scratch prefixes during feed and performs trade-finality recheck at FINISH.
"""
from __future__ import annotations

from dataclasses import fields
import hashlib
import json
import multiprocessing as mp
from multiprocessing import shared_memory
import os
from pathlib import Path
import signal
import sys
import time
import traceback

from minotauro_v004_core import ModelError, SessionEngine, valid_cells
from r1r11_transport import read_slot, merge_key
from r1r11_v5_stream import V5ScratchSink
from ff_cutoff_r3_runtime import sidecar_from_calendar_row


def _parent_alive():
    parent = mp.parent_process()
    return parent is not None and parent.is_alive()


def _trade_key(tr, index):
    return (int(tr['entry_ordinal']), index[tr['cell_id']])


def _validate_trade_order_incremental(eng, index, state):
    """Validate each trade key exactly once.

    Trade keys are immutable after creation in the frozen core.  The worker keeps
    the last validated key and resumes from the first unseen trade instead of
    rescanning the complete history on every batch.
    """
    pos = int(state.get('validated', 0))
    last = state.get('last_key')
    if pos < 0 or pos > len(eng.trades):
        raise ModelError('V5_TRADE_ORDER_STATE_INVALID')
    while pos < len(eng.trades):
        key = _trade_key(eng.trades[pos], index)
        if last is not None and key <= tuple(last):
            raise ModelError('V5_TRADE_LIST_ORDER')
        last = key
        pos += 1
    state['validated'] = pos
    state['last_key'] = last


def _enrich_cutoff_trade(tr, calendar_row):
    if tr.get('exit_reason') != 'CUTOFF':
        return tr
    direction = tr.get('direction')
    if direction not in ('BUY','SELL'):
        raise ModelError('C1_CUTOFF_DIRECTION_INVALID')
    side = 'long' if direction == 'BUY' else 'short'
    expected = int(calendar_row[f'r3_{side}_x_time_msc'])
    expected_ordinal = int(calendar_row[f'r3_{side}_x_ordinal'])
    expected_price = int(calendar_row[f'r3_{side}_x_price_micro'])
    kind = str(calendar_row[f'r3_{side}_x_kind'])
    got = int(tr.get('cutoff_fill_msc', -1))
    if got != expected or int(tr.get('exit_ordinal', -1)) != expected_ordinal or int(tr.get('exit_price_micro', -1)) != expected_price:
        raise ModelError(f'R3_CUTOFF_PREFLIGHT_REPLAY_MISMATCH direction={direction} kind={kind}')
    if kind == 'L1':
        if tr.get('cutoff_level') != 'L1' or tr.get('cutoff_modeled_price') is not True or int(tr.get('side_uncertainty_ticks', -1)) != 1:
            raise ModelError('R3_L1_TRADE_METADATA_MISMATCH')
        if int(tr.get('cutoff_business_last_micro', -1)) != int(calendar_row[f'r3_{side}_x_last_micro']):
            raise ModelError('R3_L1_TRADE_LAST_MISMATCH')
    elif kind != 'L0':
        raise ModelError('R3_CUTOFF_KIND_INVALID')
    tr['first_cutoff_bid_msc'] = int(calendar_row.get('first_cutoff_bid_msc') or 0)
    tr['first_cutoff_ask_msc'] = int(calendar_row.get('first_cutoff_ask_msc') or 0)
    return tr


def _emit_trade_prefix(eng, sink, state, index, calendar_row, safe_key=None, final=False):
    _validate_trade_order_incremental(eng, index, state)
    pos = int(state['emitted'])
    while pos < len(eng.trades):
        tr = eng.trades[pos]
        key = _trade_key(tr, index)
        if 'exit_reason' not in tr:
            if final:
                raise ModelError('V5_TRADE_NOT_FINAL_AT_FINISH')
            break
        if not final and safe_key is not None and key >= tuple(safe_key):
            break
        _enrich_cutoff_trade(tr, calendar_row)
        sink.append(tr)
        if tr.get('exit_reason') == 'CUTOFF':
            state['cutoff_indices'].append(pos)
        pos += 1
    state['emitted'] = pos


def _min_open_trade_key(engines, index, count):
    """Return the global floor from the core's open-position indices.

    Each engine exposes `pos_open` and `pos_trade_index`; therefore an open trade
    can be found without scanning every historical trade accumulated so far.
    Because incremental order validation proves the trade list is strictly
    increasing, the minimum open trade index inside an engine is also that
    engine's minimum open trade key.
    """
    floor = (int(count) + 1, -1)
    for eng in engines.values():
        open_trade_indices = eng.pos_trade_index[eng.pos_open]
        if getattr(open_trade_indices, 'size', 0):
            trade_idx = int(open_trade_indices.min())
            if trade_idx < 0 or trade_idx >= len(eng.trades):
                raise ModelError('V5_OPEN_TRADE_INDEX_INVALID')
            floor = min(floor, _trade_key(eng.trades[trade_idx], index))
    return floor


def worker_main(conn, slot_name, scratch, session, d1, specs, cutoff, integral_ids, calendar_row):
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    if not _parent_alive():
        return
    slot = None; sinks = []; engines = {}; stream_sinks = {}; trade_state = {}
    last_seq = 0; last_gen = 0
    digest = hashlib.sha256(); count = 0; business = 0; rg = {}
    try:
        scratch = Path(scratch)
        allowed = [scratch.resolve(), *[(scratch.parent/f'{group[0]}_{group[1]}').resolve()
                                        for group, cells, states in specs]]
        def audit_write(event, args):
            paths=[]
            if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
                p=Path(os.fsdecode(args[0])).resolve()
                if str(p).lower().startswith('d:\\base csv'):
                    raise ModelError('WORKER_MARKET_SOURCE_ACCESS_PROHIBITED')
                mode=args[1] or '';flags=args[2]
                if any(x in mode for x in 'wax+') or flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC):
                    paths=[p]
            elif event in ('os.mkdir','os.remove','os.rmdir'):
                paths=[Path(os.fsdecode(args[0])).resolve()]
            elif event in ('os.rename','os.replace'):
                paths=[Path(os.fsdecode(x)).resolve() for x in args[:2]]
            if any(not any(p==root or p.is_relative_to(root) for root in allowed) for p in paths):
                raise ModelError('WORKER_WRITE_OUTSIDE_SCRATCH')
        sys.addaudithook(audit_write)
        scratch.mkdir(parents=True,exist_ok=False)
        from r1r11_resources import process_creation_time_100ns
        (scratch/'worker.json').write_text(json.dumps({'pid':os.getpid(),'creation_time_100ns':process_creation_time_100ns(os.getpid()),'parent':os.getppid(),'role':'economic_worker','session':session,'run_instance':scratch.parent.parent.name}),encoding='utf-8')
        slot = shared_memory.SharedMemory(name=slot_name)
        all_cells = valid_cells(); index = {c.cell_id:i for i,c in enumerate(all_cells)}
        try:
            r3_sidecar = sidecar_from_calendar_row(calendar_row)
        except Exception as e:
            raise ModelError(f'R3_CALENDAR_SIDECAR_INVALID {type(e).__name__}:{e}') from e
        for group, cells, states in specs:
            eng = SessionEngine(session,d1,cells,cutoff,True,*states,integral_ids,r3_sidecar=r3_sidecar)
            directory = scratch.parent/f'{group[0]}_{group[1]}'
            ss = {kind: V5ScratchSink(directory/f'{kind}.jsonl',kind,all_cells)
                  for kind in ('trades','events','equity','equity_reconciliation')}
            eng.events = ss['events']; eng.equity_events = ss['equity']
            engines[tuple(group)] = eng; stream_sinks[tuple(group)] = ss
            trade_state[tuple(group)] = {'emitted':0, 'validated':0, 'last_key':None, 'cutoff_indices':[]}
            sinks.extend(ss.values())
        conn.send({'type':'READY','pid':os.getpid(),'groups':list(engines)})
        while _parent_alive():
            if not conn.poll(0.2):
                continue
            command = conn.recv()
            if command['type'] == 'STOP':
                return
            if command['type'] == 'FINISH':
                if set(rg) != set(engines) or command['ordinal'] != count:
                    raise ModelError('FINISH_WITHOUT_GLOBAL_TERMINATION')
                results = []
                finish_timing = {'engine_finish_ns':0, 'trade_emit_ns':0, 'reconciliation_ns':0,
                                 'sink_close_ns':0, 'finality_recheck_ns':0, 'manifest_ns':0}
                for group, eng in engines.items():
                    t0 = time.perf_counter_ns()
                    result = eng.finish(count,command['date_time'])
                    t1 = time.perf_counter_ns()
                    ss = stream_sinks[group]
                    state = trade_state[group]
                    final_start = int(state['emitted'])
                    _emit_trade_prefix(eng,ss['trades'],state,index,calendar_row,final=True)
                    t2 = time.perf_counter_ns()
                    if int(state['emitted']) != len(result.trades) or int(state['validated']) != len(result.trades):
                        raise ModelError('V5_FINAL_TRADE_STATE_INCOMPLETE')
                    for row in result.equity_reconciliation:
                        ss['equity_reconciliation'].append(row)
                    t3 = time.perf_counter_ns()
                    for sink in ss.values():
                        sink.close()
                    t4 = time.perf_counter_ns()
                    # Closed trades are immutable in the frozen economic core.  Recheck
                    # only the suffix that was still un-emitted at FINISH plus every C1
                    # CUTOFF row, which is the only worker-side post-core enrichment.
                    recheck_indices = sorted(set(state['cutoff_indices']) | set(range(final_start, len(result.trades))))
                    ss['trades'].recheck_final_trade_indices(result.trades, recheck_indices)
                    fills = {}
                    for trade_idx in state['cutoff_indices']:
                        tr = result.trades[int(trade_idx)]
                        _enrich_cutoff_trade(tr, calendar_row)
                        if int(tr.get('first_cutoff_bid_msc', -1)) != int(calendar_row['first_cutoff_bid_msc']):
                            raise ModelError('C1_CUTOFF_BID_ENRICHMENT_DRIFT')
                        if int(tr.get('first_cutoff_ask_msc', -1)) != int(calendar_row['first_cutoff_ask_msc']):
                            raise ModelError('C1_CUTOFF_ASK_ENRICHMENT_DRIFT')
                        direction=tr['direction'];fill=tr['cutoff_fill_msc']
                        if direction in fills and fills[direction]!=fill:raise ModelError('CUTOFF_FILL_DIVERGENCE')
                        fills[direction]=fill
                    t5 = time.perf_counter_ns()
                    result.events=[];result.equity_events=[];result.trades=[];result.equity_reconciliation=[]
                    group_result={'group':group,'result':{f.name:getattr(result,f.name) for f in fields(result)},
                        'cutoff_fills':fills, **{kind:ss[kind].manifest() for kind in ss}}
                    t6 = time.perf_counter_ns()
                    finish_timing['engine_finish_ns'] += t1-t0
                    finish_timing['trade_emit_ns'] += t2-t1
                    finish_timing['reconciliation_ns'] += t3-t2
                    finish_timing['sink_close_ns'] += t4-t3
                    finish_timing['finality_recheck_ns'] += t5-t4
                    finish_timing['manifest_ns'] += t6-t5
                    results.append(group_result)
                conn.send({'type':'FINAL_SCRATCH_MANIFEST','pid':os.getpid(),'groups':results,
                           'digest':digest.hexdigest(),'n_records':count,'business_seq':business,'r_g':rg,
                           'finish_timing_ns':finish_timing})
                while _parent_alive():
                    if conn.poll(0.2):
                        if conn.recv()['type'] in ('EXIT_ACK','STOP'):
                            return
                        raise ModelError('COMMAND_AFTER_FINISH')
                return
            if command['type'] != 'BATCH':
                raise ModelError('UNKNOWN_WORKER_COMMAND')
            # E2: emit only the globally safe trade prefix computed from the prior ACK.
            prefix_started = time.perf_counter_ns()
            safe_key = command.get('trade_safe_key')
            if safe_key is not None:
                for group, eng in engines.items():
                    _emit_trade_prefix(eng,stream_sinks[group]['trades'],trade_state[group],index,calendar_row,safe_key=safe_key)
            prefix_ended = time.perf_counter_ns()
            seq, generation = command['seq'], command['generation']
            if seq != last_seq+1 or generation != last_gen+1:
                raise ModelError('LOST_DUPLICATE_OR_OUT_OF_ORDER_BATCH')
            records = read_slot(slot.buf,session,seq,generation)
            if command.get('fault')=='orphan_worker':
                (scratch/'ORPHAN_TEST_HOLD.marker').write_text(str(os.getpid()))
                time.sleep(30)
            started = time.perf_counter_ns()
            for i,(rec,raw) in enumerate(records):
                if rec.session != session or rec.ordinal != count+1:
                    raise ModelError('FEED_ORDINAL_OR_SESSION')
                if command.get('fault') == 'worker_death' and i == len(records)//2:
                    os._exit(71)
                for group, eng in engines.items():
                    alive = eng.process_record(rec)
                    if not alive and group not in rg:
                        rg[group] = rec.ordinal
                digest.update(raw); count += 1
                business += int(rec.business and rec.time_msc < cutoff)
            if any(e.business_seq != business for e in engines.values()):
                raise ModelError('WORKER_BUSINESS_SEQ_DIVERGENCE')
            compute_ended = time.perf_counter_ns()
            validate_started = compute_ended
            for group, eng in engines.items():
                _validate_trade_order_incremental(eng,index,trade_state[group])
            validate_ended = time.perf_counter_ns()
            # Flush once per batch so stream writer/verifier can tail a complete JSONL prefix.
            flush_started = validate_ended
            for ss in stream_sinks.values():
                for sink in ss.values(): sink.flush_batch()
            flush_ended = time.perf_counter_ns()
            floor_started = flush_ended
            min_open_trade_key = _min_open_trade_key(engines,index,count)
            floor_ended = time.perf_counter_ns()
            ack = {'type':'ACK','pid':os.getpid(),'seq':seq,'generation':generation,
                   'digest':digest.hexdigest(),'n_records':count,'business_seq':business,
                   'r_g':dict(rg),'started_ns':started,'ended_ns':flush_ended,
                   'min_open_trade_key':list(min_open_trade_key),
                   'timing_ns':{
                       'prefix_emit':prefix_ended-prefix_started,
                       'engine_compute':compute_ended-started,
                       'order_validate':validate_ended-validate_started,
                       'scratch_flush':flush_ended-flush_started,
                       'open_floor':floor_ended-floor_started,
                   },
                   'scratch_offsets':{f'{g[0]}_{g[1]}':{k:ss[k].physical_bytes for k in ss} for g,ss in stream_sinks.items()}}
            if command.get('fault') == 'stale_ack':
                ack['generation'] -= 1
            conn.send(ack); last_seq = seq; last_gen = generation
    except (EOFError,BrokenPipeError):
        pass
    except BaseException:
        try:
            conn.send({'type':'ERROR','pid':os.getpid(),'traceback':traceback.format_exc()})
        except (EOFError,BrokenPipeError,OSError):
            pass
        raise
    finally:
        for sink in sinks:
            sink.close()
        if slot is not None:
            slot.close()
        conn.close()
