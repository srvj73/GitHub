from __future__ import annotations
import json, os
from pathlib import Path
DEFAULT_MAX_BYTES=64*1024*1024
DEFAULT_KEEP=4

def _rotate(path: Path, keep: int):
    keep=max(1,int(keep)); oldest=path.with_name(path.name+f'.{keep}')
    if oldest.exists(): oldest.unlink()
    for i in range(keep-1,0,-1):
        src=path.with_name(path.name+f'.{i}')
        if src.exists(): os.replace(src,path.with_name(path.name+f'.{i+1}'))
    if path.exists(): os.replace(path,path.with_name(path.name+'.1'))

def append_line(path: Path, text: str, *, max_bytes: int=DEFAULT_MAX_BYTES, keep: int=DEFAULT_KEEP, durable: bool=False):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); data=(text+'\n').encode('utf-8')
    max_bytes=int(max_bytes)
    if max_bytes<=0 or len(data)>max_bytes: raise ValueError('TELEMETRY_RECORD_EXCEEDS_BOUND')
    size=path.stat().st_size if path.exists() else 0
    if size and size+len(data)>max_bytes: _rotate(path,keep)
    with path.open('ab') as f:
        f.write(data); f.flush()
        if durable: os.fsync(f.fileno())

def append_json(path: Path, row: dict, **kwargs):
    append_line(path,json.dumps(row,sort_keys=True,separators=(',',':')),**kwargs)
