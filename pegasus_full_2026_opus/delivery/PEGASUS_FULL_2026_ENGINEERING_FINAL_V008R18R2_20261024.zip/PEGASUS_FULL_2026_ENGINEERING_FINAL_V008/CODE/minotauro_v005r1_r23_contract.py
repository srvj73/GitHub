from __future__ import annotations

from pathlib import Path
import ast
import csv
import hashlib
import json
import os
from typing import Iterable

SPEC_SHA256 = "AF6B6230BA9D6A7622F2A7CED480B78DA0C89CB3CBFDAD04837DA8B55ADD190F"
PARENT_SPEC_SHA256 = "60CBE1A203C65D6C9290987B85B4F61F348FB2FAAECBCF8A211B310990D80AAF"
R6_SHA256 = "1A950132E51700232D31636163EA1C98A64CF7AF1CBB4FED892AA71DEE059FA5"
RUNNER_VERSION = "MINOTAURO_PARAMETER_MARKET_DISCOVERY_R1R11_V005R1_FF_CUTOFF_R3_RELEASE_20261001"
EXPECTED_PREFLIGHT_SHA256 = "3A2398FD86F93C1EBD8AF5C1BD64D4BC839185AC26FABA775C8152FD29750390"
EXPECTED_IO_SHA256 = "DC816C617AA6586828CEC769B21741D5BC4106FA8A72B933F1BE76D4E1BCAF4F"
EXPECTED_CORE_IMPORTED_DEFINITIONS_SHA256 = "5605BE8765744FAE14DD77265E17DD8E27959D40F954470005BF8A7A89DB4208"

BINDING_ARTIFACT_KEYS = {
    "SESSION_CALENDAR_PHASE_A.csv": "session_calendar_sha256",
    "PHASE_STATUS.json": "preflight_status_sha256",
    "D1_PREDECESSOR_EXTRACT_PHASE_A.csv": "d1_predecessor_extract_sha256",
}

RUNTIME_MANIFEST_MEMBERS = (
    'r1r11_v4_custody.py', 'r1r11_v4_stage.py', 'r1r11_v4_transaction.py',
    'r1r11_v5_stream.py',
    'ff_cutoff_r3_runtime.py', 'r1r11_preflight_2026_resumable.py', 'r1r11_full_2026.py',
    'SPEC_R1R11_MULTIWORK_AUTOCPU_V004.md', 'SPEC_R1R11_MULTIWORK_AUTOCPU_V005.md',
    'OPERATIONAL_PREREGISTRATION_V005R1.json', 'A0_PREREGISTRATION_V005R1.json',
    'r1r11_revision.py',
    'r1r11_transport.py',
    'r1r11_worker.py',
    'r1r11_resources.py',
    'r1r11_coordinator.py',
    'r1r11_prefix.py',
    'r1r11_contract.py',
    'r1r11_coverage.py',
    'r1r11_owner_gates.py',
    'SPEC_R1R11_MULTIWORK_AUTOCPU_V003.md',
    'CERT_AMBIGUOUS_V001.md',

    "minotauro_v004_core.py",
    "minotauro_v004_io.py",
    "minotauro_v004_metrics.py",
    "minotauro_v004_preflight.py",
    "minotauro_v004_runner.py",
    "minotauro_v005r1_r23_contract.py",
    "minotauro_v005r1_r23_binding.py",
    "minotauro_v005r1_r23_outputs.py",
    "minotauro_v005r1_r1r10_memory.py",
    "RUN_PHASE.ps1",
    "RUN_LIGHT_REBIND_A.ps1",
    "Minotauro_Launcher_Common.ps1",
)

GATE_MANIFEST_MEMBERS = (
    'test_r1r11_revision.py',
    'r1r11_fixtures.py',
    'r1r11_signal.py',
    'test_r1r11_targeted.py',
    'test_r1r11_guards.py',
    'test_r1r11_integration.py',
    'RUN_R1R11_OWNER_GATES.ps1',
    'RUN_R1R11_TARGETED.ps1',
    'R1R11_LAUNCHER_SELFTEST.ps1',
    'r1r11_g4_controller.py',
    'r1r11_activation_controller.py',
    'r1r11_postpilot_promotion.py',
    'r1r11_a0.py',
    'r1r11_dev_benchmark.py',
    'r1r11_final_audit_pack.py',
    'r1r11_owner_authorize.py',
    'r1r11_bind_final_audit.py',
    'r1r11_full_homologation.py',
    'FINAL_AUDIT_RECEIPT_SCHEMA.json',
    'RUN_R1R11_A0_V005R1.ps1',
    'RUN_R1R11_DEV_BENCH_V005R1.ps1',
    'RUN_R1R11_OWNER_GATES_V005R1.ps1',
    'RUN_R1R11_G4_V005R1.ps1',
    'RUN_R1R11_ACTIVATION_V005R1.ps1',
    'RUN_R1R11_PROMOTE_PP_V005R1.ps1',
    'RUN_R1R11_FINAL_AUDIT_PACK_V005R1.ps1',
    'RUN_R1R11_BIND_FINAL_AUDIT_V005R1.ps1',
    'RUN_R1R11_OWNER_AUTHORIZE_V005R1.ps1',
    'RUN_SYNTHETIC_GATES_V005R1.ps1',
    'RUN_GATE28_PILOT_V005R1.ps1',
    'RUN_R1R11_FULL_HOMOLOGATE_V005R1.ps1',
    'test_r1r11_v5.py',
    'test_r1r11_v5_static.py',
    'test_ff_cutoff_r3_release.py',

    "test_minotauro_v004.py",
    "test_minotauro_v005r1_r23_gates.py",
    "test_minotauro_v005r1_r23_operational.py",
    "minotauro_v005r1_r23_gates.py",
    "minotauro_v005r1_r23_reference.py",
    "RUN_SYNTHETIC_GATES.ps1",
    "RUN_PRE_RUN_A_GATES.ps1",
    "RUN_OPERATIONAL_GATES.ps1",
    "RUN_SEAL_PREPILOT_GATES.ps1",
    "RUN_GEOMETRY_PREPARE.ps1",
    "RUN_GEOMETRY_VALIDATE.ps1",
    "RUN_GATE28_PILOT.ps1",
    "MQL5/Minotauro_Geometry_Parity_R23.mq5",
    "Minotauro_Launcher_Common.ps1",
    "R1R10_LAUNCHER_SELFTEST.ps1",
)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def sha256_file(path: Path, chunk_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(chunk_size)
            if not b:
                break
            h.update(b)
    return h.hexdigest().upper()


def canonical_json_bytes(obj) -> bytes:
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def canonical_json_hash(obj, exclude_keys: Iterable[str] = ()) -> str:
    if isinstance(obj, dict) and exclude_keys:
        obj = {k: v for k, v in obj.items() if k not in set(exclude_keys)}
    return sha256_bytes(canonical_json_bytes(obj))


def write_json_atomic_canonical(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_bytes(canonical_json_bytes(obj))
    os.replace(tmp, path)


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def extract_core_imported_definitions_text(core_path: Path) -> str:
    text = core_path.read_text(encoding="utf-8")
    lines = text.splitlines()
    tree = ast.parse(text)

    price_line = None
    for line in lines:
        if line.startswith("PRICE_SCALE ="):
            price_line = line.rstrip()
            break
    if price_line is None:
        raise RuntimeError("CORE_IMPORTED_PRICE_SCALE_NOT_FOUND")

    nodes = {}
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name in {"ModelError", "TickRecord", "D1Bar"}:
            start = node.lineno
            if node.decorator_list:
                start = min([start] + [d.lineno for d in node.decorator_list])
            nodes[node.name] = "\n".join(lines[start - 1: node.end_lineno]).rstrip()
    missing = {"ModelError", "TickRecord", "D1Bar"} - set(nodes)
    if missing:
        raise RuntimeError("CORE_IMPORTED_DEFINITION_NOT_FOUND " + ",".join(sorted(missing)))
    return "\n\n".join([price_line, nodes["ModelError"], nodes["TickRecord"], nodes["D1Bar"]]) + "\n"


def core_imported_definitions_hash(core_path: Path) -> str:
    return sha256_bytes(extract_core_imported_definitions_text(core_path).encode("utf-8"))


def manifest_for_files(root: Path, members: Iterable[str]) -> list[dict]:
    rows = []
    for rel in sorted(set(members)):
        p = root / rel
        if not p.is_file():
            raise RuntimeError(f"RUNNER_MANIFEST_MEMBER_MISSING {rel}")
        rows.append({"path": rel.replace("\\", "/"), "sha256": sha256_file(p)})
    return rows


def runner_identity(root: Path) -> tuple[str, list[dict]]:
    manifest = manifest_for_files(root, RUNTIME_MANIFEST_MEMBERS)
    return sha256_bytes(canonical_json_bytes(manifest)), manifest


def gate_identity(root: Path) -> tuple[str, list[dict]]:
    manifest = manifest_for_files(root, GATE_MANIFEST_MEMBERS)
    return sha256_bytes(canonical_json_bytes(manifest)), manifest


def config_hash(cfg: dict) -> str:
    return canonical_json_hash(cfg)


def parse_source_inventory(path: Path) -> dict[str, dict]:
    obj = read_json(path)
    out = {}
    for row in obj.get("files", []):
        fp = str(row.get("file", ""))
        if not fp:
            continue
        out[fp] = row
    return out


def csv_rows(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f, delimiter=";"))


def hash_manifest_rows(rows: list[dict]) -> str:
    normalized = sorted(rows, key=lambda x: (str(x.get("path", "")), str(x.get("file", ""))))
    return sha256_bytes(canonical_json_bytes(normalized))
