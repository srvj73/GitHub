from __future__ import annotations

from collections import defaultdict
from bisect import bisect_left, bisect_right

from minotauro_v004_core import (
    BASELINE_CELL_ID, ENTRY_COST_UNITS, EXIT_COST_UNITS, MAX_QUOTE_AGE_MS,
    PROJECTION_PCT_LIST, TRIGGER_T_LIST, build_grid, pnl_units, rmax_pass, rr_pass, trigger_reached,
)


class ReferencePilotEngine:
    """Independent scalar/list replay used only for Gate 28 reconciliation.

    It intentionally does not call SessionEngine and does not share its numpy state machine.
    It reuses only frozen pure math contracts (grid, RR/Rmax/trigger, P&L).
    """
    def __init__(self, session, d1, cells, cutoff_msc):
        self.session=session; self.cells=cells; self.cutoff_msc=int(cutoff_msc)
        self.lines={}; self.prices={}
        for pi in sorted({c.p_idx for c in cells}):
            g=build_grid(d1.high_micro,d1.low_micro,PROJECTION_PCT_LIST[pi]); self.lines[pi]=g; self.prices[pi]=[x.price_micro for x in g]
        self.group=defaultdict(list)
        for c in cells: self.group[(c.p_idx,c.t_idx)].append(c)
        self.active={k:set() for k in self.group}
        self.state={c.cell_id:{"pending":None,"pos":None,"first_done":False} for c in cells}
        self.byid={c.cell_id:c for c in cells}
        self.pending_ids=set(); self.open_ids=set()
        self.market_bid=0; self.market_ask=0; self.bid_msc=0; self.ask_msc=0
        self.have_prev=False; self.prev=0; self.business_seq=0; self.cutoff=False
        self.trades=defaultdict(list)

    def _needed(self,cid): return cid==BASELINE_CELL_ID or not self.state[cid]["first_done"]
    def _fresh(self,now):
        if self.bid_msc<=0 or self.ask_msc<=0 or self.market_bid<=0 or self.market_ask<=0 or self.market_ask<self.market_bid:return False
        if now<self.bid_msc or now<self.ask_msc:return False
        return now-self.bid_msc<=MAX_QUOTE_AGE_MS and now-self.ask_msc<=MAX_QUOTE_AGE_MS
    def _close(self,c,rec,fill,reason):
        st=self.state[c.cell_id]; pos=st["pos"]
        gross=pnl_units(pos["entry"],fill,pos["dir"]); net=gross-ENTRY_COST_UNITS-EXIT_COST_UNITS
        tr=pos["trade"]
        tr.update({"exit_ordinal":rec.ordinal,"exit_msc":rec.time_msc,"exit_price_micro":int(fill),"exit_reason":reason,"net_pnl_units":int(net)})
        self.trades[c.cell_id].append(tr); st["pos"]=None; self.open_ids.discard(c.cell_id)
        if c.cell_id!=BASELINE_CELL_ID:
            st["first_done"]=True; st["pending"]=None; self.pending_ids.discard(c.cell_id)
    def _positions(self,rec,bid_updated,ask_updated):
        for cid in list(self.open_ids):
            c=self.byid[cid]
            if not self._needed(cid): continue
            pos=self.state[cid]["pos"]
            if not pos: continue
            if pos["dir"]>0:
                if not bid_updated: continue
                mark=self.market_bid
                if mark<=pos["sl"]: self._close(c,rec,mark,"STOP")
                elif mark>=pos["tp"]: self._close(c,rec,pos["tp"],"TARGET")
            else:
                if not ask_updated: continue
                mark=self.market_ask
                if mark>=pos["sl"]: self._close(c,rec,mark,"STOP")
                elif mark<=pos["tp"]: self._close(c,rec,pos["tp"],"TARGET")
    def _consume(self,rec):
        for cid in list(self.pending_ids):
            c=self.byid[cid]
            if not self._needed(cid): self.pending_ids.discard(cid); continue
            st=self.state[cid]; p=st["pending"]
            if not p or p["seq"]>=self.business_seq: continue
            st["pending"]=None; self.pending_ids.discard(cid)
            if not self._fresh(rec.time_msc): continue
            direction=p["dir"]; origin=p["origin"]; target=p["target"]
            entry=self.market_ask if direction>0 else self.market_bid
            if direction>0 and not(origin<entry<target): continue
            if direction<0 and not(origin>entry>target): continue
            if st["pos"] is not None: raise RuntimeError("REFERENCE_PENDING_WITH_OPEN_POSITION")
            tr={"cell_id":c.cell_id,"session":self.session,"direction":"BUY" if direction>0 else "SELL","n_ordinal":p["n_ordinal"],"n1_ordinal":rec.ordinal,"entry_ordinal":rec.ordinal,"entry_msc":rec.time_msc,"entry_price_micro":int(entry)}
            st["pos"]={"dir":direction,"entry":int(entry),"sl":origin,"tp":target,"trade":tr}; self.open_ids.add(c.cell_id)
            if direction>0 and self.market_bid<=origin:self._close(c,rec,self.market_bid,"IMMEDIATE_STOP")
            elif direction<0 and self.market_ask>=origin:self._close(c,rec,self.market_ask,"IMMEDIATE_STOP")
    def _activate(self,prev,cur):
        lo=min(prev,cur); hi=max(prev,cur)
        for pi,prices in self.prices.items():
            a=bisect_left(prices,lo); b=bisect_right(prices,hi)
            if a>=b: continue
            for ti in sorted({k[1] for k in self.group if k[0]==pi}): self.active[(pi,ti)].update(range(a,b))
    def _episodes(self,rec):
        self._activate(self.prev,rec.last_micro); eligible=defaultdict(list)
        for (pi,ti),aset in self.active.items():
            if not aset: continue
            lines=self.lines[pi]; trig=TRIGGER_T_LIST[ti]; triggered=[]
            for li in list(aset):
                if trigger_reached(abs(rec.last_micro-lines[li].price_micro),trig): triggered.append(li)
            for li in triggered:
                aset.remove(li); origin=lines[li].price_micro; risk=abs(rec.last_micro-origin); direction=1 if rec.last_micro>origin else -1 if rec.last_micro<origin else 0
                if direction==0: continue
                ti2=li+direction
                if ti2<0 or ti2>=len(lines): continue
                target=lines[ti2].price_micro; reward=(target-rec.last_micro)*direction
                if reward<=0: continue
                for c in self.group[(pi,ti)]:
                    if not self._needed(c.cell_id): continue
                    if not rr_pass(reward,risk,c.rr_min) or not rmax_pass(risk,c.rmax_ticks): continue
                    eligible[c.cell_id].append((direction,origin,target))
        for c in self.cells:
            cid=c.cell_id
            if not self._needed(cid): continue
            cand=eligible.get(cid,[]); st=self.state[cid]
            if not cand: continue
            if st["pending"] is not None or st["pos"] is not None: continue
            if len(cand)>1: continue
            d,o,t=cand[0]; st["pending"]={"dir":d,"origin":o,"target":t,"seq":self.business_seq,"n_ordinal":rec.ordinal}; self.pending_ids.add(cid)
    def _cutoff_close(self,rec):
        crossed=self.market_bid>0 and self.market_ask>0 and self.market_ask<self.market_bid
        if crossed:return
        for cid in list(self.open_ids):
            c=self.byid[cid]
            if not self._needed(cid): continue
            st=self.state[cid]; pos=st["pos"]
            if not pos: continue
            if pos["dir"]>0:
                if self.market_bid>0 and self.bid_msc>=self.cutoff_msc and self.bid_msc<=rec.time_msc:self._close(c,rec,self.market_bid,"CUTOFF")
            else:
                if self.market_ask>0 and self.ask_msc>=self.cutoff_msc and self.ask_msc<=rec.time_msc:self._close(c,rec,self.market_ask,"CUTOFF")
    def process(self,rec):
        if rec.session!=self.session: raise RuntimeError("REFERENCE_SESSION_BOUNDARY")
        if rec.time_msc>=self.cutoff_msc and not self.cutoff:
            self.cutoff=True
            for cid in list(self.pending_ids): self.state[cid]["pending"]=None
            self.pending_ids.clear()
        bid_updated=rec.bid_micro>0; ask_updated=rec.ask_micro>0
        if bid_updated:self.market_bid=rec.bid_micro;self.bid_msc=rec.time_msc
        if ask_updated:self.market_ask=rec.ask_micro;self.ask_msc=rec.time_msc
        if self.cutoff:
            self._cutoff_close(rec); return
        self._positions(rec,bid_updated,ask_updated)
        if not rec.business:return
        self.business_seq+=1; self._consume(rec)
        if self.have_prev:self._episodes(rec)
        self.prev=rec.last_micro; self.have_prev=True
    def finish(self):
        if not self.cutoff: raise RuntimeError("REFERENCE_CUTOFF_NOT_REACHED")
        still=[cid for cid,st in self.state.items() if st["pos"] is not None and self._needed(cid)]
        if still: raise RuntimeError("REFERENCE_POSITION_NOT_FLAT "+",".join(still[:5]))
        return self.trades
