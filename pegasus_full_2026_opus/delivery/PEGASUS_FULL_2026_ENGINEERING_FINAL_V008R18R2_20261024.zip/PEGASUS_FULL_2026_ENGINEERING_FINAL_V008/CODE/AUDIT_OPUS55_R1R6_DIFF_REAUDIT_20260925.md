# REAUDITORIA MECÂNICA OPUS 5.5 — DELTA R1R5 → R1R6 — MINOTAURO V005R1

**Pacote:** `MINOTAURO_PARAMETER_MARKET_DISCOVERY_V005R1_R1R6_IMPLEMENTACAO_20260925.zip` (íntegro; `SHA256SUMS.txt` 38/38 OK).

**Governante:** V005R1-R2.3 (`D6D79108…`). **Parent físico:** R1R5 (ZIP `F66FA39D…`, idêntico ao auditado em `19_…`).

**Regime:** mecânico, restrito ao diff, independente, adversarial e fail-closed.
- Nenhum código escrito ou alterado.
- Nenhum teste executado.
- Nenhum dado de mercado lido.
- A V002R2 não foi reaberta.

> **Ressalva de handoff.** Os arquivos `00_README_START_HERE.md`, `01_PROMPT_OPUS55_R1R6_DIFF_REAUDIT.md` e `02_REQUIRED_VERDICT_FORMAT.md` não vieram no upload; o ZIP contém apenas o pacote de implementação, e o `README_R1R6.md` remete a um "handoff pós-implementação R1R6 preparado separadamente".
> - **Formato:** reproduzi o formato obrigatório da auditoria R1R5, apenas com o rótulo da primeira linha atualizado para R1R6.
> - **Escopo:** usei o diff R1R5 → R1R6 e o §6 da auditoria `19_…`.
>
> Se o `02_…` da R1R6 tiver chaves diferentes, reemito o bloco sem nova análise.

```text
OPUS55_R1R6_POSTIMPLEMENTATION_AUDIT=PASS
R2_3_IMPLEMENTATION_PARITY=PASS
R1R4_PARENT_PRESERVATION=PASS
B1_IMPLEMENTATION=PASS
PREFLIGHT_REUSE_BINDING=PASS
USE_TIME_BINDING=PASS
CHECKPOINT_RESUME=PASS
EXTREMA_LOSSLESS=PASS
FREEZE_A_OUTPUTS=PASS
SECTION22_GATE_SUITE=PASS
GEOMETRY_MT5_FIXTURE_STATIC=PASS
POWERSHELL_LAUNCHERS=PASS
FALSE_PASS_PATHS_REMAINING=0
CRITICAL_FINDINGS=0
MAJOR_FINDINGS=0
MINOR_FINDINGS=6
OWNER_PC_NON_ECONOMIC_GATES_AUTHORIZED=YES
PILOT_A_AUTHORIZED=NO
RUN_A_AUTHORIZED=NO
DATA_PROCESSING_AUTHORIZED=NO
```

```text
R1R5_FP1_GATE28_IDENTITY_CLOSED=YES
R1R5_FP2_GEOMETRY_BINDING_CLOSED=YES
R1R5_FP3_SESSION_PREFIX_DRIFT_CLOSED=YES
NEW_FALSE_PASS_INTRODUCED_BY_DELTA=NO
ECONOMIC_OR_CAUSAL_RULE_CHANGED=NO
HEAVY_55_3_GIB_PREFLIGHT_RERUN_REQUIRED=NO
```

---

## 1. Integridade do delta

- [x] O `DIFF_R1R5_TO_R1R6.patch`, aplicado a uma cópia de rascunho da R1R5, reproduz byte a byte os 7 arquivos alterados.
- [x] **Alterados (7):**
  - `minotauro_v004_runner.py`
  - `minotauro_v005r1_r23_gates.py`
  - os dois arquivos de teste R2.3
  - `minotauro_v005r1_r23_contract.py` — só `RUNNER_VERSION`
  - `RUN_PHASE.ps1` — só o rótulo
  - `config.example.json` — só o `out_root`
- [x] **Byte-idênticos à R1R5:**
  - Python: `core`, `io`, `preflight`, `metrics`, `outputs`, `binding`, `reference` e `test_minotauro_v004.py`.
  - MQL5, R6 e SPECs: fixture MQ5, R6 e as duas SPECs.
  - Launchers: os outros 8 `.ps1`.
- [x] **Congelados continuam iguais:**
  - `CORE_IMPORTED_DEFINITIONS_SHA256` recalculado = `5605BE87…`
  - `io` = `DC816C61…`
  - `preflight` = `3A2398FD…`
  - `metrics` = `8CE1292F…`
- [x] **Identidades recalculadas conferem com as declaradas:**
  - `runner_sha256` = `E7600DC0…FEE7C1`
  - `gate_suite_sha256` = `846567C8…879229`
  - Nenhum executável ou launcher fica fora dos manifests.
- [x] Nenhuma alteração em sinal, fill, custo, cutoff, seleção, persistência de equity ou outputs econômicos.

---

## 2. Fechamento dos falsos-pass da R1R5

| FP | Exigência (§6 de `19_…`) | Fonte R1R6 | Resultado |
|---|---|---|---|
| **FP-1** | Recibo GATE28 anterior invalidado antes do trabalho | gates l.494 | ✅ |
| | Conferência de binding selado, `PRE_PILOT` (identidade, grid, binding) e `RUN_MANIFEST` do piloto (spec, runner, grid, binding, `gate_receipt_sha256` = `PRE_PILOT` corrente) | gates l.498-521 | ✅ |
| | Hashes mensais do piloto = hashes de ticks do binding | gates l.523-529 | ✅ |
| | Recibo com spec, runner, suite, binding, `pre_pilot`, `pilot_run` e manifest; independência declarada como parcial | gates l.571-580 | ✅ |
| | `finalize` exige igualdade de todas as identidades correntes | gates l.607-614 | ✅ |
| **FP-2** | `prepare` invalida recibos anteriores e exige binding `UNSEALED`, extrato D1 e `IND@N` iguais aos do binding | gates l.244-262 | ✅ |
| | `prepare` grava extrato, `IND@N` e binding pré-selo | gates l.304-310 | ✅ |
| | `validate` invalida PASS anterior, confronta o recibo do prepare com binding, extrato e `IND@N`, e grava `prepare_receipt_sha256`, input, replay, MT5, extrato, `IND@N` e binding | gates l.320-336, l.372-381 | ✅ |
| | O selo confronta cada hash declarado com arquivos e binding correntes antes de selar | gates l.423-440 | ✅ |
| | Defesa adicional: `rebind-a` recusa recibos vinculantes remanescentes | runner l.705-716, l.727 | ✅ (ver m-F) |
| **FP-3** | `session_receipt` grava `tick_file_path`, `tick_prefix_bytes` e `tick_prefix_sha256` no instante do commit | runner l.368-385 | ✅ |
| | A releitura de mês não verificado confere cada prefixo no offset exato; offset saltado ou não alcançado bloqueia | runner l.192-246, l.608-609, l.660-664 | ✅ |
| | Divergência ⇒ `RUN_BLOCKED_TICK_DRIFT` + `INVALID_PHASE.marker` | runner l.654-657, l.660-664 | ✅ |
| | `io` não tocado; o proxy entra pelo parâmetro `hasher` existente | io l.90-91 (congelado) | ✅ |

**Por que FP-3 fecha:**
- **O snapshot cobre os bytes efetivamente lidos.** `io` chama `hasher.update(raw)` antes de produzir o registro, então o snapshot no commit cobre exatamente os bytes lidos até a linha que disparou o commit. Os três pontos de commit existentes — próxima sessão, cutoff resolvido e EOF — caem em fronteiras de linha.
- **A releitura passa pelos mesmos offsets.** Os offsets são reprodutíveis, e as conferências ocorrem antes de a próxima sessão ser processada.
- **Qualquer divergência é detectada.** Um prefixo lido com bytes divergentes e depois restaurado produz digest diferente. Um deslocamento de linhas faz o offset ser saltado. Nos dois casos a fase é invalidada.

**Novos caminhos introduzidos pelo delta:** nenhum falso-pass.
- `_session_prefix_expectations` falha fechado (`RESUME_HASH_MISMATCH`) se o recibo não existir, se os campos faltarem ou se o arquivo não coincidir.
- Os commits continuam atômicos: o snapshot é gravado dentro do `.pending` antes do `os.replace`.
- O `PRE_RUN_A_GATE_RECEIPT` remanescente continua bloqueado pela identidade em `_require_run_a_gates`.

---

## 3. Recomendações da R1R5 (não obrigatórias)

| R1R5 | Situação na R1R6 |
|---|---|
| m2 — independência parcial da referência | ✅ declarada no recibo (`PARTIAL_SHARED_PRIMITIVES_DECLARED`) |
| m3 — asserções fracas | ✅ G03 com Eq ±0,5/±1 micro; G19 isolado; G23 nas 435 · ⏳ G25 segue textual |
| m4 — G26/G27 por simulação | ✅ rótulos corrigidos (`…_SIMULATION`) · ⏳ sem teste ponta a ponta |
| m5 — hashes §§3.2–3.5 só transitivos no FREEZE | ⏳ `outputs.py` inalterado |
| m6 — manifest econômico tolerante a ausência | ⏳ inalterado |
| m7 — launchers | ⏳ inalterado |
| m8 — amostra 2024 | ✅ primeira barra válida do mês; falha se ≠ 12 (gates l.271-280) |

---

## 4. Findings por severidade

**CRITICAL:** nenhum. **MAJOR:** nenhum.

**MINOR (6, nenhum abre falso-pass):**

| # | Finding | Fonte |
|---|---|---|
| m-A | Cobertura de teste limitada. G25 é textual e G26/G27 são simulações de estado. As novas guardas R1R6 só têm testes unitários ou de caminho negativo mínimo. Faltam testes de: selo rejeitando hash divergente; `finalize` rejeitando GATE28 de outra identidade; `OFFSET_SKIPPED` e `EXPECTED_PREFIX_NOT_REACHED` via `run_phase_a`. | test_operational l.164-191 |
| m-B | (carregado de m5) Os hashes das §§3.2–3.5 entram no FREEZE_A só via `run_source_binding_sha256`. | outputs l.292-308 |
| m-C | (carregado de m6) `economic_output_paths` omite em silêncio arquivo ausente. | outputs l.223 |
| m-D | (carregado de m7) Três problemas nos launchers: o fallback do PATH não exige Python 3.14; não há log ou transcript persistido; o nome `RUN_PRE_RUN_A_GATES.ps1` descreve passos pré-piloto. | `Resolve-RealPython`; todos os `.ps1` |
| m-E | (novo) Em `pilot_reconcile`, a leitura de ticks da referência não confere hash EOF, e o D1 da referência não é confrontado com o extrato nem com o hash de `IND@N`. A deriva só leva a divergência de trades (FAIL), não a PASS indevido. | gates l.531-538 |
| m-F | (novo) A guarda de rebind existe só no comando `rebind-a` do runner. O `main()` próprio de `minotauro_v005r1_r23_binding.py` a contorna. É defesa adicional: o fechamento de FP-2 não depende dela, porque o selo confronta os hashes. | binding l.201-213 |

---

## 5. Falso-pass nominal

`FALSE_PASS_PATHS_REMAINING=0`. Os três cenários da R1R5 foram refeitos contra o código R1R6.

- **FP-1** — um recibo GATE28 de vX é apagado no início do `pilot-reconcile` vY. Se o `reconcile` não rodar, o `finalize` rejeita por `runner_sha256`, `gate_suite_sha256`, `pre_pilot_gate_receipt_sha256` e hashes do piloto.
- **FP-2** — um rebind com recibos presentes é recusado. Se o bloqueio for contornado, o selo rejeita recibos com binding pré-selo, extrato, `IND@N`, input, replay ou saída MT5 diferentes dos correntes. Um `prepare` ou `validate` refeito apaga o PASS anterior.
- **FP-3** — sessões commitadas sob bytes divergentes e arquivo restaurado: o prefixo do commit diverge na releitura, a fase é invalidada e nenhuma sessão nova é processada.

---

## 6. Correções

**Obrigatórias:** nenhuma.

**Opcionais (R1R7 cosmética, se desejado):** m-A a m-F.

**Aviso:** qualquer mudança altera `runner_sha256` e `gate_suite_sha256` e torna obsoletos os recibos já emitidos. Se o owner quiser aplicar sua regra de log nos launchers (m-D), o momento é **antes** de rodar os gates abaixo.

---

## 7. O que o owner pode rodar no PC (somente não econômico)

1. **Configuração**
   - Copiar `config.example.json` para `config.json`.
   - O `out_root` `…\MINOTAURO_PARAMETER_MARKET_DISCOVERY_V005R1_R1R6` deve ser uma pasta nova e limpa.
   - O `preflight_source_root` aponta para a saída R1R4.
   - Os scripts usam `$PSScriptRoot` e podem ser chamados de `C:\Users\silvi`.
2. **`RUN_LIGHT_REBIND_A.ps1`** — hash de leitura pura dos 12 arquivos de ticks de 2025, re-derivação M1 e validação D1. Não faz processamento econômico.
3. **`RUN_PRE_RUN_A_GATES.ps1`** — `py_compile`, sintéticos, operacionais, source (gates 4, 5, 12, 18 e 97 linhas), `geometry-prepare` e status.
4. **MetaEditor/MT5**
   - Copiar `GATES\GEOMETRY_INPUT_R23.csv` para `MQL5\Files\MINOTAURO_GEOMETRY_INPUT_R23.csv`.
   - Compilar e executar o script `Minotauro_Geometry_Parity_R23.mq5`.
5. **`RUN_GEOMETRY_VALIDATE.ps1 -Mt5Output <…\MQL5\Files\MINOTAURO_GEOMETRY_MT5_R23.csv>`**
6. **`RUN_SEAL_PREPILOT_GATES.ps1`** — **parar** em `PRE_PILOT_GATES=PASS_27_OF_27` e trazer os recibos de `GATES\` para auditoria.

**Comportamentos fail-closed esperados, que não indicam defeito:**
- **`IND@N.csv`:** alterá-lo entre o rebind e o selo bloqueia `prepare`, `validate` e selo. Para acrescentar dados de 2026, faça isso depois do selo.
- **Rodar de novo o passo 3 depois do 5:** o recibo de paridade é apagado. Basta repetir o passo 5 com a mesma saída MT5, pois o input é determinístico.
- **Novo rebind com recibos em `GATES\`:** é recusado. Mova os recibos para uma pasta de arquivo antes.
- **Leitura do CSV pelo MT5:** se o MT5 ler mal o CSV com terminador `\n`, o `validate` falha pelo conjunto de casos.

**Nunca nesta etapa:**
- `RUN_GATE28_PILOT.ps1`;
- `RUN_PHASE.ps1 -Command pilot-a` ou `-Command run-a`;
- criação de `OWNER_PILOT_AUTHORIZATION.json` ou `OWNER_RUN_A_AUTHORIZATION.json`.

---

## 8. Limites

- **Fixture MQL5:** não foi compilado nem executado. O PASS é estático.
- **Testes:** nenhum foi executado. O log 54/54 do builder (Python 3.13) foi tratado apenas como alegação; o gate em Python 3.14 fica para o PC do owner.
- **Escopo:** restrito ao delta R1R5 → R1R6. As conclusões da auditoria `19_…` sobre os arquivos não alterados continuam válidas.
