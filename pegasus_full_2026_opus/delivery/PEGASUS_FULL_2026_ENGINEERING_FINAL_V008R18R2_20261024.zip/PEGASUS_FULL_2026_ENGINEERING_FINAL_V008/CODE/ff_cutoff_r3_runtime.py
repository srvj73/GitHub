from __future__ import annotations

import hashlib
import json
from typing import Any

SCHEMA = "FF_CUTOFF_R3_SIDECAR_V001"
PRICE_SCALE = 1_000_000
TICK_POINTS = 5
TICK_MICRO = TICK_POINTS * PRICE_SCALE
SIDES = ("LONG", "SHORT")
KINDS = ("L0", "L1")


def canonical_json_bytes(obj: Any) -> bytes:
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def canonical_json_hash(obj: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(obj)).hexdigest().upper()


def crossed(bid_micro: int, ask_micro: int) -> bool:
    return int(bid_micro) > 0 and int(ask_micro) > 0 and int(ask_micro) < int(bid_micro)


def invalid_side(side: str, bid_micro: int, ask_micro: int) -> bool:
    if side == "LONG":
        return int(bid_micro) <= 0 or crossed(bid_micro, ask_micro)
    if side == "SHORT":
        return int(ask_micro) <= 0 or crossed(bid_micro, ask_micro)
    raise ValueError("R3_SIDE_INVALID")


def modeled_l1_price(side: str, last_micro: int) -> int:
    last = int(last_micro)
    if last <= 0 or last % TICK_MICRO != 0:
        raise ValueError("R3_L1_LAST_INVALID")
    if side == "LONG":
        return last - TICK_MICRO
    if side == "SHORT":
        return last + TICK_MICRO
    raise ValueError("R3_SIDE_INVALID")


def event_dict(kind: str, ordinal: int, time_msc: int, price_micro: int, last_micro: int | None = None) -> dict:
    if kind not in KINDS:
        raise ValueError("R3_X_KIND_INVALID")
    out = {
        "x_kind": kind,
        "x_ordinal": int(ordinal),
        "x_time_msc": int(time_msc),
        "x_price_micro": int(price_micro),
    }
    if kind == "L1":
        if last_micro is None:
            raise ValueError("R3_L1_LAST_MISSING")
        out["x_last_micro"] = int(last_micro)
        out["modeled"] = True
        out["side_uncertainty_ticks"] = 1
    else:
        out["x_last_micro"] = None if last_micro is None else int(last_micro)
        out["modeled"] = False
        out["side_uncertainty_ticks"] = 0
    return out


def make_sidecar(session: str, cutoff_msc: int, long_event: dict, short_event: dict) -> dict:
    body = {
        "schema": SCHEMA,
        "session": str(session),
        "cutoff_msc": int(cutoff_msc),
        "availability_phase": "POST_RECORD",
        "LONG": dict(long_event),
        "SHORT": dict(short_event),
    }
    validate_sidecar(body, require_hash=False)
    body["content_sha256"] = canonical_json_hash(body)
    return body


def validate_sidecar(sidecar: dict, *, require_hash: bool = True) -> dict:
    if not isinstance(sidecar, dict) or sidecar.get("schema") != SCHEMA:
        raise ValueError("R3_SIDECAR_SCHEMA")
    if not str(sidecar.get("session", "")):
        raise ValueError("R3_SIDECAR_SESSION")
    cutoff = int(sidecar.get("cutoff_msc", 0))
    if cutoff <= 0:
        raise ValueError("R3_SIDECAR_CUTOFF")
    if sidecar.get("availability_phase") != "POST_RECORD":
        raise ValueError("R3_AVAILABILITY_PHASE")
    for side in SIDES:
        ev = sidecar.get(side)
        if not isinstance(ev, dict):
            raise ValueError("R3_SIDE_EVENT_MISSING_" + side)
        kind = str(ev.get("x_kind", ""))
        if kind not in KINDS:
            raise ValueError("R3_X_KIND_INVALID_" + side)
        ordinal = int(ev.get("x_ordinal", 0))
        time_msc = int(ev.get("x_time_msc", 0))
        price = int(ev.get("x_price_micro", 0))
        if ordinal <= 0 or time_msc < cutoff or price <= 0 or price % TICK_MICRO != 0:
            raise ValueError("R3_X_EVENT_INVALID_" + side)
        if kind == "L1":
            last = int(ev.get("x_last_micro", 0))
            if price != modeled_l1_price(side, last):
                raise ValueError("R3_L1_PRICE_MISMATCH_" + side)
            if ev.get("modeled") is not True or int(ev.get("side_uncertainty_ticks", -1)) != 1:
                raise ValueError("R3_L1_METADATA_INVALID_" + side)
        else:
            if ev.get("modeled") not in (False, 0):
                raise ValueError("R3_L0_MODELED_INVALID_" + side)
            if int(ev.get("side_uncertainty_ticks", 0)) != 0:
                raise ValueError("R3_L0_UNCERTAINTY_INVALID_" + side)
    if require_hash:
        given = str(sidecar.get("content_sha256", "")).upper()
        if len(given) != 64:
            raise ValueError("R3_SIDECAR_HASH_MISSING")
        body = {k: v for k, v in sidecar.items() if k != "content_sha256"}
        if canonical_json_hash(body) != given:
            raise ValueError("R3_SIDECAR_HASH_MISMATCH")
    return sidecar


def sidecar_from_calendar_row(row: dict) -> dict:
    def _one(side: str) -> dict:
        p = "r3_" + side.lower() + "_"
        kind = str(row[p + "x_kind"])
        last_raw = row.get(p + "x_last_micro")
        last = None if last_raw in (None, "", "None") else int(last_raw)
        return event_dict(
            kind,
            int(row[p + "x_ordinal"]),
            int(row[p + "x_time_msc"]),
            int(row[p + "x_price_micro"]),
            last,
        )
    sc = make_sidecar(str(row["session_date"]), int(row["cutoff_msc"]), _one("LONG"), _one("SHORT"))
    expected = str(row.get("r3_sidecar_content_sha256", "")).upper()
    if expected and sc["content_sha256"] != expected:
        raise ValueError("R3_CALENDAR_SIDECAR_HASH_MISMATCH")
    return sc


def calendar_fields(sidecar: dict) -> dict:
    validate_sidecar(sidecar)
    out = {"r3_sidecar_content_sha256": sidecar["content_sha256"]}
    for side in SIDES:
        p = "r3_" + side.lower() + "_"
        ev = sidecar[side]
        out[p + "x_kind"] = ev["x_kind"]
        out[p + "x_ordinal"] = ev["x_ordinal"]
        out[p + "x_time_msc"] = ev["x_time_msc"]
        out[p + "x_price_micro"] = ev["x_price_micro"]
        out[p + "x_last_micro"] = ev.get("x_last_micro")
    return out
