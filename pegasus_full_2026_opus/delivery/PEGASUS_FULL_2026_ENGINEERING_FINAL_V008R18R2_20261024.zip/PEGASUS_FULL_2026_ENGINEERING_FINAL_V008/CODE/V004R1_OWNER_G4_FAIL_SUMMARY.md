# V004R1 OWNER G4 FAIL — preserved summary

Source: owner console and subsequent `CollectExisting` output supplied on 27/09/2026.

```text
G1=PASS
G2=PASS
G3=PASS
G4=FAIL
G4_SPEEDUP=0.338345652733696
G4_REQUIRED=1.5
G4_ORACLE_SECONDS=15.3265179000009
G4_CANDIDATE_SECONDS=45.2984034999972
G4_OVERLAP=True
G4_GRANTED=4
G4_EXTERNAL_HEAVY_WORKERS=0
G5_G11=NOT_RUN
OWNER_GATES_RERUN=NO
REAL_DATA=NO
PILOT_A=NO
RUN_A=NO
```

This summary does not replace the physical V004R1 owner evidence tree, which must be included in the final external handoff later.
