# CHANGELOG R1R11 V005R2R1 — manifest closure correction

Date: 2026-09-27

V005R2R1 is a packaging-only correction over V005R2.

## Physical defect found before owner execution
The V005R2 root `SHA256SUMS.txt` excluded every file named `SHA256SUMS.txt`, including five historical nested manifests.
`r1r11_owner_gates.py::verify_package()` excludes only the root manifest from its physical census, therefore the nested manifests would be reported as unmanifested files.

## Correction
The root manifest now lists every physical file under the package except the root `SHA256SUMS.txt` itself.
No runtime Python implementation file changed from V005R2.
The Windows handle-lifecycle fix remains exactly the V005R2 implementation.

## Authorization
V5 Windows qualification is authorized.
Development benchmark only after V5 PASS.
Fresh G1-G3 only after V5 + benchmark PASS.
G4, real data, Pilot A and Full Run remain unauthorized.
