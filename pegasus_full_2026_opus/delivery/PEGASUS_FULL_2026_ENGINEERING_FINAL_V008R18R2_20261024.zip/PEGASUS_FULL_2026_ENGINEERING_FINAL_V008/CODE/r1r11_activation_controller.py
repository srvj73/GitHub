from __future__ import annotations

import argparse
import json
import sys
import traceback
from pathlib import Path

from minotauro_v004_core import ModelError
from minotauro_v004_io import read_json, sha256_file
from minotauro_v005r1_r23_binding import build_binding
from minotauro_v005r1_r23_contract import SPEC_SHA256, runner_identity
import minotauro_v004_runner as runner

FINAL_AUDIT_NAME = "R1R11_FINAL_PREPILOT_AUDIT_RECEIPT.json"
POSTPILOT_NAME = "R1R11_POSTPILOT_PROMOTION_RECEIPT.json"


def _cfg(path: Path) -> dict:
    obj = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(obj, dict):
        raise ModelError("CONFIG_NOT_OBJECT")
    return obj


def _require_final_audit(cfg: dict, package_root: Path) -> dict:
    p = Path(cfg["out_root"]) / "GATES" / FINAL_AUDIT_NAME
    if not p.is_file():
        raise ModelError("R1R11_FINAL_PREPILOT_AUDIT_REQUIRED")
    obj = read_json(p)
    rh, _ = runner_identity(package_root)
    from r1r11_owner_gates import verify_package
    package_hash = verify_package()
    owner_receipt_raw = cfg.get('r1r11_owner_gate_receipt')
    if not isinstance(owner_receipt_raw, str):
        raise ModelError('R1R11_OWNER_G1_TO_G11_RECEIPT_REQUIRED')
    owner_receipt = Path(owner_receipt_raw)
    if not owner_receipt.is_file():
        raise ModelError('R1R11_OWNER_G1_TO_G11_RECEIPT_REQUIRED')
    audit_report_raw = obj.get('audit_report_path')
    if not isinstance(audit_report_raw, str) or not Path(audit_report_raw).is_file():
        raise ModelError('R1R11_FINAL_AUDIT_REPORT_REQUIRED')
    audit_pack_raw = obj.get('audit_pack_path')
    if not isinstance(audit_pack_raw, str) or not Path(audit_pack_raw).is_file():
        raise ModelError('R1R11_FINAL_AUDIT_PACK_REQUIRED')
    checks = {
        "R1R11_FINAL_PREPILOT_AUDIT": "PASS",
        "spec_sha256": SPEC_SHA256,
        "runner_sha256": rh,
        "package_sha256": package_hash,
        "owner_g1_g11_receipt_sha256": sha256_file(owner_receipt),
        "audit_pack_sha256": sha256_file(Path(audit_pack_raw)),
        "audit_report_sha256": sha256_file(Path(audit_report_raw)),
    }
    for k, v in checks.items():
        if obj.get(k) != v:
            raise ModelError(f"R1R11_FINAL_PREPILOT_AUDIT_STALE {k}")
    return obj


def _require_owner_authorization(cfg: dict, package_root: Path, mode: str) -> dict:
    root = Path(cfg["out_root"])
    rh, _ = runner_identity(package_root)
    binding = root / "PHASE_A" / "RUN_SOURCE_BINDING_A.json"
    final_audit = root / "GATES" / FINAL_AUDIT_NAME
    if not binding.is_file():
        raise ModelError("R1R11_OWNER_AUTH_BINDING_MISSING")
    if not final_audit.is_file():
        raise ModelError("R1R11_OWNER_AUTH_FINAL_AUDIT_MISSING")
    if mode == "pilot-a":
        p = root / "GATES" / "OWNER_PILOT_AUTHORIZATION.json"
        pre = root / "GATES" / "PRE_PILOT_GATE_RECEIPT.json"
        if not p.is_file() or not pre.is_file():
            raise ModelError("R1R11_OWNER_PILOT_AUTHORIZATION_REQUIRED")
        obj = read_json(p)
        checks = {
            "PILOT_AUTHORIZED": "YES",
            "spec_sha256": SPEC_SHA256,
            "runner_sha256": rh,
            "run_source_binding_sha256": sha256_file(binding),
            "pre_pilot_gate_receipt_sha256": sha256_file(pre),
            "final_audit_receipt_sha256": sha256_file(final_audit),
        }
    elif mode == "run-a":
        p = root / "GATES" / "OWNER_RUN_A_AUTHORIZATION.json"
        pre = root / "GATES" / "PRE_RUN_A_GATE_RECEIPT.json"
        pp = root / "GATES" / POSTPILOT_NAME
        if not p.is_file() or not pre.is_file() or not pp.is_file():
            raise ModelError("R1R11_OWNER_RUN_A_AUTHORIZATION_REQUIRED")
        obj = read_json(p)
        checks = {
            "RUN_A_AUTHORIZED": "YES",
            "spec_sha256": SPEC_SHA256,
            "runner_sha256": rh,
            "run_source_binding_sha256": sha256_file(binding),
            "pre_run_a_gate_receipt_sha256": sha256_file(pre),
            "postpilot_promotion_receipt_sha256": sha256_file(pp),
            "final_audit_receipt_sha256": sha256_file(final_audit),
        }
    else:
        raise ModelError("R1R11_OWNER_AUTH_MODE")
    for k, v in checks.items():
        if obj.get(k) != v:
            raise ModelError(f"R1R11_OWNER_AUTHORIZATION_STALE {mode} {k}")
    return obj


def _require_postpilot_promotion(cfg: dict, package_root: Path) -> dict:
    p = Path(cfg["out_root"]) / "GATES" / POSTPILOT_NAME
    if not p.is_file():
        raise ModelError("R1R11_POSTPILOT_PROMOTION_REQUIRED")
    obj = read_json(p)
    rh, _ = runner_identity(package_root)
    checks = {
        "R1R11_POSTPILOT_PROMOTION": "PASS",
        "PP1_PP9": "PASS_9_OF_9",
        "spec_sha256": SPEC_SHA256,
        "runner_sha256": rh,
    }
    for k, v in checks.items():
        if obj.get(k) != v:
            raise ModelError(f"R1R11_POSTPILOT_PROMOTION_STALE {k}")
    return obj


def execute(command: str, cfg: dict, workers: int, batch_rows: int) -> None:
    if batch_rows != 32:
        raise ModelError(f"R1R11_BATCH_ROWS_FROZEN expected=32 got={batch_rows}")
    if not 2 <= workers <= 12:
        raise ModelError("R1R11_WORKERS_MUST_BE_2_TO_12")
    package_root = Path(__file__).resolve().parent

    # The final independent implementation audit is the canonical bridge from
    # synthetic owner gates to any real-data activation. Rebind is deliberately
    # behind it too, so no real-source binding starts from an unaudited build.
    _require_final_audit(cfg, package_root)

    if command == "rebind-a":
        runner._guard_rebind_gate_state(cfg)
        receipt = build_binding(cfg, package_root)
        print("R1R11_ACTIVATION_COMMAND=rebind-a")
        print("PREFLIGHT_REUSE_AUTHORIZED=YES")
        print("HEAVY_55_3_GIB_PREFLIGHT_RERUN_REQUIRED=NO")
        print(f"RUN_SOURCE_BINDING_SHA256={receipt['run_source_binding_sha256']}")
        return

    if command == "pilot-a":
        _require_owner_authorization(cfg, package_root, "pilot-a")
        runner.run_phase_a(cfg, "PILOT_A", workers=workers, batch_rows=32)
        return

    if command == "run-a":
        _require_postpilot_promotion(cfg, package_root)
        _require_owner_authorization(cfg, package_root, "run-a")
        runner.run_phase_a(cfg, "RUN_A", workers=workers, batch_rows=32)
        return

    raise ModelError(f"UNKNOWN_ACTIVATION_COMMAND {command}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["rebind-a", "pilot-a", "run-a"])
    ap.add_argument("--config", required=True)
    ap.add_argument("--workers", type=int, default=12)
    ap.add_argument("--batch-rows", type=int, default=32)
    ns = ap.parse_args()
    cfg = _cfg(Path(ns.config))
    try:
        execute(ns.command, cfg, ns.workers, ns.batch_rows)
    except KeyboardInterrupt:
        print("SAFE_STOP=YES", flush=True)
        raise SystemExit(130)
    except Exception as exc:
        print(f"RUN_BLOCKED={type(exc).__name__}:{exc}", file=sys.stderr)
        traceback.print_exc()
        raise SystemExit(2)


if __name__ == "__main__":
    main()
