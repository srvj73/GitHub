# CHANGELOG R1R11 V005R3 — session-scoped ACK test + late scratch tamper fail-closed

Date: 2026-09-27

## Trigger
Windows owner V005R2R1 executed 19 tests in 86.794 s and failed only 2:
- V5-B ACK/watermark test;
- V5-D independent verifier/tamper fail-closed.

## V5-B root cause
`ParallelSession.seq` is explicitly initialized to zero for every session and increments per batch.
The test filtered multiple non-warmup sessions and incorrectly required the union of those independent
session-local counters to equal a single global sequence `1..N`.

Correction: preserve runtime semantics; validate ACK sequence continuity separately within each session,
and validate watermark bounds within the same session.

## V5-D root cause
The `scratch_append` fault is injected after worker scratch is sealed. Streaming verifier/writer processes
can already have consumed the complete sealed prefix. Final limits intentionally stop at the sealed byte
count, so an append beyond that prefix was not consumed and therefore did not alter the consumed digest.

Correction: immediately before stream finalization, revalidate each sealed scratch file's physical identity
against the worker manifest. Append/truncate/replacement therefore fail closed without a second full-file
hash scan.

## Frozen surface
No economic/causal E0 file changed. The Windows raw-handle lifecycle fix from V005R2 remains unchanged.
No G4 parameter, threshold, fixture, cycles, workers, batch or slots changed.
