#property strict
#property script_show_inputs

// Geometry parity fixture for V005R1-R2.3 §6.1.
// The R6 geometry routines RoundTick/Eq/AddLine/SortDedup/BuildGrid below are copied
// verbatim in their geometric semantics. PreviousIND/DrawGrid/WriteState are fixture stubs
// so BuildGrid consumes the pre-registered hi/lo/projection cases from CSV while executing
// under native MT5 double arithmetic.

input string InpInputFile = "MINOTAURO_GEOMETRY_INPUT_R23.csv";
input string InpOutputFile = "MINOTAURO_GEOMETRY_MT5_R23.csv";

double tick_size=5.0;
double InpProjectionPct=61.8;
double MICRO_PCTS[11]={0.056,0.090,0.146,0.236,0.382,0.500,0.618,0.764,0.854,0.910,0.944};

struct FiboLine
{
   double price;
   bool macro;
   string label;
   bool active;
};
FiboLine lines[];

// Globals referenced by the copied R6 BuildGrid body.
double fixture_hi=0.0,fixture_lo=0.0;
double ref_high=0.0,ref_low=0.0,ref_range=0.0;
string refinfo="",state_fault="",status_text="";
int effective_d1_date=0,expected_d1_date=0,grid_day=0,state_session_day=0;
bool grid_ok=false;
string VERSION_NAME="MINOTAURO_GEOMETRY_PARITY_R23";

int DateKey(datetime t)
{
   MqlDateTime d; TimeToStruct(t,d);
   return d.year*10000+d.mon*100+d.day;
}

double RoundTick(double x)
{
   return MathFloor(x/tick_size+0.5+1e-12)*tick_size;
}
bool Eq(double a,double b)
{
   return MathAbs(a-b)<=tick_size*1e-7;
}

// Fixture-only source adapter. It intentionally does no market-data lookup.
bool PreviousIND(datetime now,double &hi,double &lo,string &info)
{
   hi=fixture_hi; lo=fixture_lo; info="FIXTURE_D1";
   effective_d1_date=expected_d1_date;
   return (hi>lo && lo>0.0);
}
void WriteState(){}
void DrawGrid(){}

void AddLine(double price,bool macro,string label)
{
   int n=ArraySize(lines); ArrayResize(lines,n+1);
   lines[n].price=RoundTick(price); lines[n].macro=macro;
   lines[n].label=label; lines[n].active=false;
}
void SortDedup()
{
   int n=ArraySize(lines);
   for(int i=1;i<n;i++)
   {
      FiboLine k=lines[i]; int j=i-1;
      while(j>=0 && lines[j].price>k.price){ lines[j+1]=lines[j]; j--; }
      lines[j+1]=k;
   }
   FiboLine tmp[]; ArrayResize(tmp,0);
   for(int i=0;i<n;i++)
   {
      int m=ArraySize(tmp);
      if(m==0 || !Eq(tmp[m-1].price,lines[i].price))
      {
         ArrayResize(tmp,m+1); tmp[m]=lines[i];
      }
      else if(lines[i].macro && !tmp[m-1].macro) tmp[m-1]=lines[i];
   }
   ArrayResize(lines,ArraySize(tmp));
   for(int i=0;i<ArraySize(tmp);i++) lines[i]=tmp[i];
}

// Copied R6 BuildGrid body. The fixture stubs above supply PreviousIND and no-op UI/state calls.
bool BuildGrid(datetime now)
{
   double hi,lo; string info;
   if(!PreviousIND(now,hi,lo,info))
   {
      grid_ok=false; status_text="GRID_BLOCKED_REFERENCE "+state_fault; return false;
   }
   double rg=hi-lo; if(rg<=0){ grid_ok=false; state_fault="D1_RANGE_INVALID"; return false; }
   ref_high=hi; ref_low=lo; ref_range=rg; refinfo=info;
   double anchor_raw=lo+rg*(InpProjectionPct/100.0);

   ArrayResize(lines,0);
   double macro_raw[9]; int z=0;
   for(int k=-4;k<=4;k++)
   {
      macro_raw[z]=anchor_raw+k*rg;
      AddLine(macro_raw[z],true,StringFormat("MACRO k=%d",k)); z++;
   }
   for(int b=0;b<8;b++)
   {
      for(int p=0;p<11;p++)
      {
         double micro_raw=macro_raw[b]+rg*MICRO_PCTS[p];
         AddLine(micro_raw,false,StringFormat("MICRO b=%d %.1f%%",b,MICRO_PCTS[p]*100.0));
      }
   }
   SortDedup();
   if(ArraySize(lines)!=97)
   {
      grid_ok=false; state_fault="GEOMETRY_LINE_COUNT_NOT_97"; return false;
   }
   // Nao limpar pending aqui: startup recovery pode ter restaurado N valido.
   grid_day=DateKey(now); state_session_day=grid_day;
   grid_ok=true; state_fault=""; status_text="GRID_READY";
   WriteState(); DrawGrid();
   Print(VERSION_NAME," GRID READY ",grid_day," ",refinfo," range=",rg,
         " lines=",ArraySize(lines)," expected_d1=",expected_d1_date,
         " effective_d1=",effective_d1_date);
   return true;
}

long PriceToMicro(double price)
{
   return (long)MathRound(price*1000000.0);
}

void OnStart()
{
   int h=FileOpen(InpInputFile,FILE_READ|FILE_CSV|FILE_ANSI,';');
   if(h==INVALID_HANDLE){ Print("GEOMETRY_GATE_INPUT_OPEN_FAIL ",GetLastError()); return; }
   int o=FileOpen(InpOutputFile,FILE_WRITE|FILE_CSV|FILE_ANSI,';');
   if(o==INVALID_HANDLE){ Print("GEOMETRY_GATE_OUTPUT_OPEN_FAIL ",GetLastError()); FileClose(h); return; }

   for(int i=0;i<8;i++) FileReadString(h); // consume header
   FileWrite(o,"case_type","case_id","line_idx","price_micro");

   int cases=0; int outrows=0;
   while(!FileIsEnding(h))
   {
      string case_type=FileReadString(h);
      if(FileIsEnding(h) && case_type=="") break;
      string case_id=FileReadString(h);
      string session_date=FileReadString(h);
      string source_kind=FileReadString(h);
      string projection_text=FileReadString(h);
      string high_micro_text=FileReadString(h);
      string low_micro_text=FileReadString(h);
      string raw_micro_text=FileReadString(h);
      if(case_type=="" || case_id=="") continue;
      cases++;

      if(case_type=="ROUND")
      {
         long raw_micro=(long)StringToInteger(raw_micro_text);
         double raw_price=(double)raw_micro/1000000.0;
         long result_micro=PriceToMicro(RoundTick(raw_price));
         FileWrite(o,"ROUND",case_id,-1,result_micro); outrows++;
         continue;
      }
      if(case_type!="GRID")
      {
         Print("GEOMETRY_GATE_UNKNOWN_CASE_TYPE ",case_type," ",case_id);
         continue;
      }
      long hi_micro=(long)StringToInteger(high_micro_text);
      long lo_micro=(long)StringToInteger(low_micro_text);
      fixture_hi=(double)hi_micro/1000000.0;
      fixture_lo=(double)lo_micro/1000000.0;
      InpProjectionPct=StringToDouble(projection_text);
      expected_d1_date=0;
      if(!BuildGrid(0))
      {
         Print("GEOMETRY_GATE_BUILD_FAIL ",case_id," ",state_fault);
         continue;
      }
      for(int j=0;j<ArraySize(lines);j++)
      {
         FileWrite(o,"GRID",case_id,j,PriceToMicro(lines[j].price)); outrows++;
      }
   }
   FileFlush(o); FileClose(o); FileClose(h);
   Print("MINOTAURO_GEOMETRY_R23_DONE cases=",cases," rows=",outrows," output=",InpOutputFile);
}
