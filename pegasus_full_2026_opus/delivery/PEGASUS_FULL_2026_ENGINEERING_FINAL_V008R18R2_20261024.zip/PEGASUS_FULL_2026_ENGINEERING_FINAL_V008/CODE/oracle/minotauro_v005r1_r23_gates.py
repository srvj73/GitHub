from __future__ import annotations

from pathlib import Path
from decimal import Decimal
from fractions import Fraction
from datetime import datetime
import argparse
import csv
import json
import math
import os
import shutil
import subprocess
import sys
import unittest

from minotauro_v004_core import PROJECTION_PCT_LIST, BASELINE_CELL_ID, build_grid, round_tick_fraction, valid_cells
from minotauro_v004_io import load_d1, iter_tick_file
from minotauro_v005r1_r23_reference import ReferencePilotEngine
from minotauro_v005r1_r23_outputs import write_grid_cells
from minotauro_v005r1_r23_contract import (
    RUNNER_VERSION,
    SPEC_SHA256,
    canonical_json_hash,
    gate_identity,
    runner_identity,
    read_json,
    sha256_file,
    write_json_atomic_canonical,
)


def _phase(cfg):
    return Path(cfg["out_root"]) / "PHASE_A"


def _gates(cfg):
    p = Path(cfg["out_root"]) / "GATES"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _read_csv(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f, delimiter=";"))


def _write_csv(path: Path, fields, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, delimiter=";", lineterminator="\n")
        w.writeheader(); w.writerows(rows)


def run_synthetic(package_root: Path, cfg: dict | None = None):
    suite = unittest.TestSuite()
    loader = unittest.TestLoader()
    suite.addTests(loader.loadTestsFromName("test_minotauro_v004"))
    suite.addTests(loader.loadTestsFromName("test_minotauro_v005r1_r23_gates"))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        raise RuntimeError(f"SYNTHETIC_TESTS_FAIL failures={len(result.failures)} errors={len(result.errors)}")
    receipt = {
        "SYNTHETIC_GATES": "PASS",
        "tests_run": result.testsRun,
        "legacy_r1r4_regression": "PASS",
        "r23_new_contract_tests": "PASS",
        "gate_components": {
            "1": "PASS", "2": "PASS_PYTHON_COMPONENT_PENDING_MT5_DOUBLE", "3": "PASS",
            "6": "PASS", "7": "PASS", "8": "PASS", "9": "PASS", "10": "PASS", "11": "PASS",
            "13": "PASS", "14": "PASS", "15": "PASS", "16": "PASS", "17": "PASS", "18": "PASS_SYNTHETIC_COMPONENT",
            "19": "PASS", "20": "PASS", "21": "PASS", "22": "PASS", "23": "PASS", "24": "PASS", "25": "PASS",
            "26": "PASS_SYNTHETIC_TRANSACTION_COMPONENT", "27": "PASS_SYNTHETIC_SESSION_BOUNDARY_COMPONENT",
        },
        "gate_4_5_12_source_checks": "PENDING",
        "gate_28_pilot": "PENDING",
        "data_processing": "NO",
    }
    if cfg is not None:
        gates = _gates(cfg)
        rh, _ = runner_identity(package_root)
        gh, _ = gate_identity(package_root)
        receipt["runner_sha256"] = rh
        receipt["gate_suite_sha256"] = gh
        receipt["spec_sha256"] = SPEC_SHA256
        write_json_atomic_canonical(gates / "SYNTHETIC_GATES_RECEIPT.json", receipt)
    return receipt


def run_operational(package_root: Path, cfg: dict):
    suite = unittest.TestLoader().loadTestsFromName("test_minotauro_v005r1_r23_operational")
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        raise RuntimeError(f"OPERATIONAL_GATES_FAIL failures={len(result.failures)} errors={len(result.errors)}")
    rh, _ = runner_identity(package_root)
    gh, _ = gate_identity(package_root)
    receipt = {
        "OPERATIONAL_GATES": "PASS",
        "tests_run": result.testsRun,
        "gate_26_safe_stop_before_commit": "PASS_TRANSACTIONAL_STATE_SIMULATION",
        "gate_26_safe_stop_during_commit": "PASS_ORPHAN_RECOVERY_SIMULATION",
        "gate_26_safe_stop_after_commit": "PASS_COMMITTED_PRESERVED_SIMULATION",
        "gate_27_clean_resume_economic_hash_equivalence": "PASS_SYNTHETIC_BUNDLES",
        "r23_month_eof_hash_resume_rule": "PASS",
        "r23_clean_use_time_binding_artifact_check": "PASS",
        "r1r6_prefix_commit_drift_guard": "PASS_SYNTHETIC",
        "r1r6_gate28_stale_receipt_invalidation": "PASS_SYNTHETIC",
        "r1r6_geometry_stale_receipt_invalidation": "PASS_SYNTHETIC",
        "runner_sha256": rh,
        "gate_suite_sha256": gh,
        "spec_sha256": SPEC_SHA256,
        "data_processing": "NO",
    }
    write_json_atomic_canonical(_gates(cfg) / "OPERATIONAL_GATES_RECEIPT.json", receipt)
    return receipt


def _independent_m1_sessions(m1_root: Path):
    header = ["symbol","timeframe","date","time","open","high","low","close","tick_count","volume","volume_real","first_msc","last_msc"]
    sessions = set()
    for p in sorted(m1_root.glob("WIN@N_M1_*.csv")):
        ym = p.stem[-7:]
        if not ("2024_01" <= ym <= "2025_12"):
            continue
        with p.open("r", encoding="utf-8-sig", newline="") as f:
            first = f.readline()
            if not first:
                continue
            vals = first.rstrip("\r\n").split(";")
            has_header = vals and vals[0].strip().lower() == "symbol"
            rows = [] if has_header else [vals]
            rows.extend(line.rstrip("\r\n").split(";") for line in f if line.strip())
            for vals in rows:
                if len(vals) != 13:
                    raise RuntimeError(f"GATE4_M1_FIELD_COUNT {p}")
                r = dict(zip(header, [x.strip() for x in vals]))
                if r["symbol"] != "WIN@N" or r["timeframe"].upper() != "M1":
                    raise RuntimeError(f"GATE4_M1_IDENTITY {p}")
                d = r["date"].replace(".", "-")
                if "2024-01-01" <= d <= "2025-12-31":
                    sessions.add(d)
    return sorted(sessions)


def _independent_d1(ind_path: Path):
    out = {}
    with ind_path.open("r", encoding="utf-8-sig", newline="") as f:
        rd = csv.DictReader(f, delimiter=",")
        for r in rd:
            d = r["data"].strip()
            def micro(k): return int(Decimal(r[k].strip()) * 1_000_000)
            out[d] = (micro("abertura"), micro("maxima"), micro("minima"), micro("fechamento"))
    return out


def run_source_gates(cfg: dict, package_root: Path):
    phase = _phase(cfg); gates = _gates(cfg)
    bind = read_json(phase / "RUN_SOURCE_BINDING_A.json")
    if bind.get("status") != "PASS_REBOUND_UNSEALED":
        raise RuntimeError("SOURCE_GATES_BINDING_NOT_REBOUND_UNSEALED")
    if bind.get("binding_content_sha256") != canonical_json_hash(bind, exclude_keys={"binding_content_sha256"}):
        raise RuntimeError("SOURCE_GATES_BINDING_CONTENT_HASH_MISMATCH")
    calendar = _read_csv(phase / "SESSION_CALENDAR_PHASE_A.csv")
    expected = _read_csv(phase / "EXPECTED_SESSIONS_PHASE_A.csv")
    if len(calendar) != 250 or len(expected) != 250:
        raise RuntimeError("GATE4_CARDINALITY_NOT_250")

    prior = _independent_m1_sessions(Path(cfg["m1_root"]))
    pos = {d:i for i,d in enumerate(prior)}
    independent = []
    for d in [x for x in prior if "2025-01-01" <= x <= "2025-12-31"]:
        i = pos[d]
        if i <= 0: raise RuntimeError("GATE4_PREDECESSOR_MISSING")
        independent.append((d, prior[i-1]))
    frozen = [(r["session_date"],r["expected_previous_session_date"]) for r in expected]
    if independent != frozen:
        raise RuntimeError("GATE4_EXPECTED_SESSION_INVENTORY_MISMATCH")

    d1 = _independent_d1(Path(cfg["ind_d1"]))
    extract = _read_csv(phase / "D1_PREDECESSOR_EXTRACT_PHASE_A.csv")
    for r in extract:
        prev = r["expected_previous_session_date"]
        if prev not in d1:
            raise RuntimeError(f"GATE5_D1_PREDECESSOR_MISSING {prev}")
        got = d1[prev]
        exp = tuple(int(r[k]) for k in ("open_micro","high_micro","low_micro","close_micro"))
        if got != exp:
            raise RuntimeError(f"GATE5_D1_MISMATCH session={r['session_date']}")

    diag = _read_csv(phase / "CUTOFF_LATENCY_DIAGNOSTICS.csv")
    sess = [r for r in diag if r["row_type"] == "SESSION"]
    if len(sess) != 250 or any(r["status"] != "PASS" for r in sess):
        raise RuntimeError("GATE12_CUTOFF_SESSION_DIAGNOSTICS_NOT_250_PASS")
    for direction, key in (("LONG","cutoff_long_latency_ms"),("SHORT","cutoff_short_latency_ms")):
        vals = sorted(int(r[key]) for r in sess if r[key] != "")
        summaries = {(r["metric"],r["direction"]):r for r in diag if r["row_type"] == "SUMMARY"}
        for metric,pct in (("P50",50),("P95",95),("P99",99)):
            rank=max(1,math.ceil((pct/100)*len(vals))); expected_val=vals[rank-1]
            if int(summaries[(metric,direction)]["metric_value_ms"]) != expected_val:
                raise RuntimeError(f"GATE12_{direction}_{metric}_MISMATCH")
        if int(summaries[("MAX",direction)]["metric_value_ms"]) != max(vals):
            raise RuntimeError(f"GATE12_{direction}_MAX_MISMATCH")
        top=[r for r in diag if r["row_type"]=="TOP10" and r["direction"]==direction]
        if len(top) != min(10,len(vals)):
            raise RuntimeError(f"GATE12_{direction}_TOP10_COUNT")

    # R2.3 §6.2: exact replay geometry 97 lines for all 250 sessions x 3 projections.
    line_failures=[]
    for r in extract:
        hi=int(r["high_micro"]); lo=int(r["low_micro"])
        for p in PROJECTION_PCT_LIST:
            n=len(build_grid(hi,lo,p))
            if n != 97:
                line_failures.append((r["session_date"],str(p),n))
    if line_failures:
        raise RuntimeError(f"GATE97_FAILURES={len(line_failures)}")

    rh,_=runner_identity(package_root); gh,_=gate_identity(package_root)
    receipt={
        "SOURCE_GATES":"PASS",
        "gate_4_expected_session_inventory":"PASS_INDEPENDENT",
        "gate_5_d1_predecessor":"PASS_INDEPENDENT",
        "gate_12_cutoff_latency_diagnostics":"PASS",
        "gate_18_preflight_cutoff_observability":"PASS_250_OF_250",
        "r23_97_lines_2025_x3":"PASS_750_OF_750",
        "calendar_rows":250,
        "data_processing":"NO_ECONOMIC_PROCESSING",
        "run_source_binding_sha256_before_seal":sha256_file(phase/"RUN_SOURCE_BINDING_A.json"),
        "spec_sha256":SPEC_SHA256,"runner_sha256":rh,"gate_suite_sha256":gh,
    }
    write_json_atomic_canonical(gates/"SOURCE_GATES_RECEIPT.json",receipt)
    return receipt


def _projection_fraction(text: str) -> Fraction:
    d=Decimal(text)
    return Fraction(int(d*10),10)


def prepare_geometry(cfg: dict):
    phase=_phase(cfg); gates=_gates(cfg)
    prep_receipt = gates / "GEOMETRY_PREPARE_RECEIPT.json"
    parity_receipt = gates / "GEOMETRY_PARITY_RECEIPT.json"
    # Any new prepare invalidates prior geometry receipts before work starts.
    for stale in (prep_receipt, parity_receipt):
        if stale.exists(): stale.unlink()

    binding_path = phase / "RUN_SOURCE_BINDING_A.json"
    if not binding_path.is_file(): raise RuntimeError("GEOMETRY_BINDING_REQUIRED")
    binding = read_json(binding_path)
    if binding.get("status") != "PASS_REBOUND_UNSEALED": raise RuntimeError("GEOMETRY_BINDING_NOT_REBOUND_UNSEALED")
    if binding.get("binding_content_sha256") != canonical_json_hash(binding, exclude_keys={"binding_content_sha256"}):
        raise RuntimeError("GEOMETRY_BINDING_CONTENT_HASH_MISMATCH")
    binding_hash = sha256_file(binding_path)
    d1_extract_path = phase / "D1_PREDECESSOR_EXTRACT_PHASE_A.csv"
    d1_extract_hash = sha256_file(d1_extract_path)
    ind_path = Path(cfg["ind_d1"])
    ind_hash = sha256_file(ind_path)
    if d1_extract_hash != binding.get("d1_predecessor_extract_sha256"):
        raise RuntimeError("GEOMETRY_D1_EXTRACT_BINDING_MISMATCH")
    if ind_hash != binding.get("ind_d1_sha256"):
        raise RuntimeError("GEOMETRY_IND_D1_BINDING_MISMATCH")

    extract=_read_csv(d1_extract_path)
    rows=[]
    for r in extract:
        for p in ("38.2","50","61.8"):
            rows.append({"case_type":"GRID","case_id":f"Y2025_{r['session_date']}_P{p}","session_date":r["session_date"],"source_kind":"D1_2025_PREDECESSOR","projection_pct":p,"high_micro":r["high_micro"],"low_micro":r["low_micro"],"raw_micro":""})

    # Deterministic 2024 sample: first VALID D1 row in each calendar month.
    d1=_independent_d1(ind_path)
    by_month={}
    for d in sorted(d1):
        if not d.startswith("2024-"):
            continue
        o,hi,lo,c=d1[d]
        if hi>lo>0:
            by_month.setdefault(d[:7],d)
    if len(by_month) != 12:
        raise RuntimeError(f"GEOMETRY_2024_VALID_MONTH_SAMPLE_NOT_12 got={len(by_month)}")
    for ym,d in sorted(by_month.items()):
        o,hi,lo,c=d1[d]
        for p in ("38.2","50","61.8"):
            rows.append({"case_type":"GRID","case_id":f"Y2024_{d}_P{p}","session_date":d,"source_kind":"D1_2024_FIRST_VALID_OF_MONTH","projection_pct":p,"high_micro":hi,"low_micro":lo,"raw_micro":""})

    for base in (100002,130002,150002):
        half=base*1_000_000+500_000
        for delta,label in ((-1,"MINUS1MICRO"),(0,"EXACT_HALF"),(1,"PLUS1MICRO")):
            rows.append({"case_type":"ROUND","case_id":f"ROUND_{base}_{label}","session_date":"","source_kind":"SYNTH_HALF_TICK","projection_pct":"","high_micro":"","low_micro":"","raw_micro":half+delta})

    fields=["case_type","case_id","session_date","source_kind","projection_pct","high_micro","low_micro","raw_micro"]
    inp=gates/"GEOMETRY_INPUT_R23.csv"; _write_csv(inp,fields,rows)
    replay=[]
    for r in rows:
        if r["case_type"]=="ROUND":
            replay.append({"case_type":"ROUND","case_id":r["case_id"],"line_idx":-1,"price_micro":round_tick_fraction(Fraction(int(r["raw_micro"]),1))})
        else:
            p=_projection_fraction(str(r["projection_pct"]))
            grid=build_grid(int(r["high_micro"]),int(r["low_micro"]),p)
            for i,line in enumerate(grid):
                replay.append({"case_type":"GRID","case_id":r["case_id"],"line_idx":i,"price_micro":line.price_micro})
    replay_path=gates/"GEOMETRY_REPLAY_EXACT_R23.csv"; _write_csv(replay_path,["case_type","case_id","line_idx","price_micro"],replay)
    package_root=Path(__file__).resolve().parent; rh,_=runner_identity(package_root); gh,_=gate_identity(package_root)
    receipt={
        "GEOMETRY_PREPARE":"PASS","input_cases":len(rows),"replay_rows":len(replay),
        "input_sha256":sha256_file(inp),"replay_sha256":sha256_file(replay_path),"mt5_output_required":"YES",
        "d1_predecessor_extract_sha256":d1_extract_hash,"ind_d1_sha256":ind_hash,
        "run_source_binding_sha256_before_seal":binding_hash,
        "spec_sha256":SPEC_SHA256,"runner_sha256":rh,"gate_suite_sha256":gh
    }
    write_json_atomic_canonical(prep_receipt,receipt)
    return receipt


def validate_geometry(cfg: dict, mt5_output: Path):
    gates=_gates(cfg); replay_path=gates/"GEOMETRY_REPLAY_EXACT_R23.csv"
    prep_path=gates/"GEOMETRY_PREPARE_RECEIPT.json"
    parity_path=gates/"GEOMETRY_PARITY_RECEIPT.json"
    # Fail closed: a failed new validation can never leave an older PASS receipt behind.
    if parity_path.exists(): parity_path.unlink()
    if not replay_path.is_file() or not prep_path.is_file(): raise RuntimeError("GEOMETRY_PREPARE_REQUIRED")
    phase=_phase(cfg); binding_path=phase/"RUN_SOURCE_BINDING_A.json"
    if not binding_path.is_file(): raise RuntimeError("GEOMETRY_BINDING_REQUIRED")
    binding=read_json(binding_path)
    if binding.get("status")!="PASS_REBOUND_UNSEALED": raise RuntimeError("GEOMETRY_BINDING_NOT_REBOUND_UNSEALED")
    if binding.get("binding_content_sha256") != canonical_json_hash(binding, exclude_keys={"binding_content_sha256"}): raise RuntimeError("GEOMETRY_BINDING_CONTENT_HASH_MISMATCH")
    binding_hash=sha256_file(binding_path)
    d1_extract_path=phase/"D1_PREDECESSOR_EXTRACT_PHASE_A.csv"
    d1_extract_hash=sha256_file(d1_extract_path)
    ind_hash=sha256_file(Path(cfg["ind_d1"]))
    package_root=Path(__file__).resolve().parent; rh,_=runner_identity(package_root); gh,_=gate_identity(package_root)
    prep=read_json(prep_path)
    for k,v in (("GEOMETRY_PREPARE","PASS"),("spec_sha256",SPEC_SHA256),("runner_sha256",rh),("gate_suite_sha256",gh),("replay_sha256",sha256_file(replay_path)),("run_source_binding_sha256_before_seal",binding_hash),("d1_predecessor_extract_sha256",d1_extract_hash),("ind_d1_sha256",ind_hash)):
        if prep.get(k)!=v: raise RuntimeError(f"GEOMETRY_PREPARE_STALE_OR_MISMATCH {k}")
    if d1_extract_hash != binding.get("d1_predecessor_extract_sha256") or ind_hash != binding.get("ind_d1_sha256"):
        raise RuntimeError("GEOMETRY_BINDING_SOURCE_DRIFT")
    inp=gates/"GEOMETRY_INPUT_R23.csv"
    if not inp.is_file() or prep.get("input_sha256")!=sha256_file(inp): raise RuntimeError("GEOMETRY_PREPARE_INPUT_HASH_MISMATCH")
    exp=_read_csv(replay_path); got=_read_csv(mt5_output)
    key=lambda r:(r["case_type"],r["case_id"],int(r["line_idx"]))
    exp_keys=[key(r) for r in exp]; got_keys=[key(r) for r in got]
    if len(exp_keys)!=len(set(exp_keys)):
        raise RuntimeError("GEOMETRY_REPLAY_DUPLICATE_KEY")
    if len(got_keys)!=len(set(got_keys)):
        raise RuntimeError("GEOMETRY_MT5_DUPLICATE_KEY")
    em={key(r):int(r["price_micro"]) for r in exp}; gm={key(r):int(r["price_micro"]) for r in got}
    allkeys=sorted(set(em)|set(gm)); diffs=[]
    for k in allkeys:
        if em.get(k)!=gm.get(k):
            diffs.append({"case_type":k[0],"case_id":k[1],"line_idx":k[2],"replay_price_micro":em.get(k,""),"mt5_price_micro":gm.get(k,"")})
    diff_path=gates/"GEOMETRY_PARITY_DIFF_R23.csv"; _write_csv(diff_path,["case_type","case_id","line_idx","replay_price_micro","mt5_price_micro"],diffs)
    # Required summary for 2025 grid cases.
    summary=[]
    for case in sorted({r["case_id"] for r in exp if r["case_type"]=="GRID" and r["case_id"].startswith("Y2025_")}):
        e=[r for r in exp if r["case_id"]==case]; g=[r for r in got if r["case_id"]==case]
        d=sum(1 for r in diffs if r["case_id"]==case)
        parts=case.split("_P",1); session=parts[0].replace("Y2025_",""); proj=parts[1]
        summary.append({"session_date":session,"projection_pct":proj,"r6_line_count":len(g),"replay_line_count":len(e),"divergent_line_count":d,"status":"PASS" if len(g)==97 and len(e)==97 and d==0 else "REVIEW_REQUIRED"})
    _write_csv(gates/"GEOMETRY_PARITY_2025.csv",["session_date","projection_pct","r6_line_count","replay_line_count","divergent_line_count","status"],summary)
    if len(summary) != 750:
        raise RuntimeError(f"GEOMETRY_2025_SUMMARY_CARDINALITY expected=750 got={len(summary)}")
    exp_cases={(r["case_type"],r["case_id"]) for r in exp}; got_cases={(r["case_type"],r["case_id"]) for r in got}
    if exp_cases != got_cases:
        raise RuntimeError("GEOMETRY_MT5_CASESET_MISMATCH")
    for ct,cid in sorted(exp_cases):
        n=sum(1 for r in got if r["case_type"]==ct and r["case_id"]==cid)
        expected_n=1 if ct=="ROUND" else 97
        if n != expected_n:
            raise RuntimeError(f"GEOMETRY_MT5_CASE_ROWCOUNT case={ct}:{cid} expected={expected_n} got={n}")
    mt5_canonical = gates / "GEOMETRY_MT5_R23.csv"
    shutil.copy2(mt5_output, mt5_canonical)
    receipt={
        "GEOMETRY_PARITY":"PASS" if not diffs else "REVIEW_REQUIRED",
        "input_sha256":sha256_file(inp),"prepare_receipt_sha256":sha256_file(prep_path),
        "mt5_output_sha256":sha256_file(mt5_canonical),"mt5_output_canonical_path":"GATES/GEOMETRY_MT5_R23.csv",
        "replay_sha256":sha256_file(replay_path),"d1_predecessor_extract_sha256":d1_extract_hash,
        "ind_d1_sha256":ind_hash,"run_source_binding_sha256_before_seal":binding_hash,
        "divergent_rows":len(diffs),"summary_2025_rows":len(summary),
        "spec_sha256":SPEC_SHA256,"runner_sha256":rh,"gate_suite_sha256":gh
    }
    write_json_atomic_canonical(parity_path,receipt)
    if diffs:
        raise RuntimeError(f"GEOMETRY_PARITY_REVIEW_REQUIRED divergent_rows={len(diffs)}")
    return receipt


def seal_prepilot_gates(cfg: dict, package_root: Path):
    root = Path(cfg["out_root"]); phase = root / "PHASE_A"; gates = _gates(cfg)
    # No economic session/checkpoint may exist before binding is sealed.
    if (phase / "CHECKPOINT.json").exists() or ((phase / "sessions").exists() and any((phase / "sessions").iterdir())):
        raise RuntimeError("PREPILOT_SEAL_BLOCKED_ECONOMIC_STATE_EXISTS")
    if (root / "PILOT_A").exists() and any((root / "PILOT_A").iterdir()):
        raise RuntimeError("PREPILOT_SEAL_BLOCKED_PILOT_STATE_EXISTS")

    req = {
        "SYNTHETIC_GATES_RECEIPT.json": ("SYNTHETIC_GATES", "PASS"),
        "SOURCE_GATES_RECEIPT.json": ("SOURCE_GATES", "PASS"),
        "OPERATIONAL_GATES_RECEIPT.json": ("OPERATIONAL_GATES", "PASS"),
        "GEOMETRY_PREPARE_RECEIPT.json": ("GEOMETRY_PREPARE", "PASS"),
        "GEOMETRY_PARITY_RECEIPT.json": ("GEOMETRY_PARITY", "PASS"),
    }
    rh, rmanifest = runner_identity(package_root); gh, gmanifest = gate_identity(package_root)
    component_hashes = {}
    for name, (key, expected) in req.items():
        rp = gates / name
        if not rp.is_file(): raise RuntimeError(f"PREPILOT_GATE_MISSING {name}")
        obj = read_json(rp)
        if obj.get(key) != expected: raise RuntimeError(f"PREPILOT_GATE_NOT_PASS {name}")
        for ik,iv in (("spec_sha256",SPEC_SHA256),("runner_sha256",rh),("gate_suite_sha256",gh)):
            if obj.get(ik) != iv: raise RuntimeError(f"PREPILOT_GATE_STALE {name} {ik}")
        component_hashes[name] = sha256_file(rp)

    binding_path = phase / "RUN_SOURCE_BINDING_A.json"
    binding = read_json(binding_path)
    if binding.get("status") != "PASS_REBOUND_UNSEALED":
        raise RuntimeError("PREPILOT_BINDING_NOT_REBOUND_UNSEALED")
    if binding.get("binding_content_sha256") != canonical_json_hash(binding, exclude_keys={"binding_content_sha256"}):
        raise RuntimeError("PREPILOT_BINDING_CONTENT_HASH_MISMATCH")
    source_receipt = read_json(gates / "SOURCE_GATES_RECEIPT.json")
    preseal_binding_hash = sha256_file(binding_path)
    if source_receipt.get("run_source_binding_sha256_before_seal") != preseal_binding_hash:
        raise RuntimeError("PREPILOT_SOURCE_RECEIPT_BINDING_MISMATCH")
    prep_path = gates / "GEOMETRY_PREPARE_RECEIPT.json"
    parity_path = gates / "GEOMETRY_PARITY_RECEIPT.json"
    prep = read_json(prep_path); parity = read_json(parity_path)
    geometry_actual = {
        "input_sha256": sha256_file(gates / "GEOMETRY_INPUT_R23.csv"),
        "replay_sha256": sha256_file(gates / "GEOMETRY_REPLAY_EXACT_R23.csv"),
        "mt5_output_sha256": sha256_file(gates / "GEOMETRY_MT5_R23.csv"),
        "d1_predecessor_extract_sha256": sha256_file(phase / "D1_PREDECESSOR_EXTRACT_PHASE_A.csv"),
        "ind_d1_sha256": sha256_file(Path(cfg["ind_d1"])),
        "run_source_binding_sha256_before_seal": preseal_binding_hash,
    }
    for k in ("input_sha256","replay_sha256","d1_predecessor_extract_sha256","ind_d1_sha256","run_source_binding_sha256_before_seal"):
        if prep.get(k) != geometry_actual[k]: raise RuntimeError(f"PREPILOT_GEOMETRY_PREPARE_BINDING_MISMATCH {k}")
    if prep.get("d1_predecessor_extract_sha256") != binding.get("d1_predecessor_extract_sha256") or prep.get("ind_d1_sha256") != binding.get("ind_d1_sha256"):
        raise RuntimeError("PREPILOT_GEOMETRY_PREPARE_SOURCE_MISMATCH")
    if parity.get("prepare_receipt_sha256") != sha256_file(prep_path): raise RuntimeError("PREPILOT_GEOMETRY_PARITY_PREP_RECEIPT_MISMATCH")
    for k in ("input_sha256","replay_sha256","mt5_output_sha256","d1_predecessor_extract_sha256","ind_d1_sha256","run_source_binding_sha256_before_seal"):
        if parity.get(k) != geometry_actual[k]: raise RuntimeError(f"PREPILOT_GEOMETRY_PARITY_BINDING_MISMATCH {k}")
    geometry_files = {
        "geometry_input_sha256": gates / "GEOMETRY_INPUT_R23.csv",
        "geometry_replay_exact_sha256": gates / "GEOMETRY_REPLAY_EXACT_R23.csv",
        "geometry_mt5_output_sha256": gates / "GEOMETRY_MT5_R23.csv",
        "geometry_parity_2025_sha256": gates / "GEOMETRY_PARITY_2025.csv",
        "geometry_prepare_receipt_sha256": gates / "GEOMETRY_PREPARE_RECEIPT.json",
        "geometry_parity_receipt_sha256": gates / "GEOMETRY_PARITY_RECEIPT.json",
        "source_gates_receipt_sha256": gates / "SOURCE_GATES_RECEIPT.json",
        "synthetic_gates_receipt_sha256": gates / "SYNTHETIC_GATES_RECEIPT.json",
        "operational_gates_receipt_sha256": gates / "OPERATIONAL_GATES_RECEIPT.json",
    }
    for key, fp in geometry_files.items():
        if not fp.is_file(): raise RuntimeError(f"PREPILOT_BINDING_ARTIFACT_MISSING {fp.name}")
        binding[key] = sha256_file(fp)
    binding["geometry_97_lines_2025_x3"] = "PASS_750_OF_750"
    binding["status"] = "PASS_SEALED_PREPILOT"
    binding["binding_content_sha256"] = canonical_json_hash(binding, exclude_keys={"binding_content_sha256"})
    write_json_atomic_canonical(binding_path, binding)

    grid_hash = write_grid_cells(phase / "GRID_CELLS.csv")
    receipt = {
        "PRE_PILOT_GATES": "PASS",
        "gates_passed": 27,
        "spec_sha256": SPEC_SHA256,
        "runner_sha256": rh,
        "runner_manifest": rmanifest,
        "grid_sha256": grid_hash,
        "run_source_binding_sha256": sha256_file(binding_path),
        "binding_content_sha256": binding["binding_content_sha256"],
        "gate_suite_sha256": gh,
        "gate_manifest": gmanifest,
        "component_receipts": component_hashes,
        "HEAVY_55_3_GIB_PREFLIGHT_RERUN_REQUIRED": "NO",
        "PILOT_AUTHORIZED": "NO_PENDING_OWNER_AND_POSTIMPLEMENTATION_AUDIT",
        "DATA_PROCESSING_AUTHORIZED": "NO",
    }
    write_json_atomic_canonical(gates / "PRE_PILOT_GATE_RECEIPT.json", receipt)
    return receipt


def _trade_key(tr: dict):
    return (
        tr.get("direction"), int(tr.get("n_ordinal", -1)), int(tr.get("n1_ordinal", -1)),
        int(tr.get("entry_ordinal", -1)), int(tr.get("exit_ordinal", -1)),
        int(tr.get("entry_price_micro", 0)), int(tr.get("exit_price_micro", 0)),
        tr.get("exit_reason"), int(tr.get("net_pnl_units", 0)),
    )


def pilot_reconcile(cfg: dict):
    root=Path(cfg["out_root"]); phase=root/"PHASE_A"; pilot=root/"PILOT_A"; gates=_gates(cfg)
    out_receipt=gates/"GATE28_PILOT_RECONCILIATION_RECEIPT.json"
    # Fail closed: any new reconciliation invalidates prior PASS before doing work.
    if out_receipt.exists(): out_receipt.unlink()
    package_root=Path(__file__).resolve().parent
    rh,rmanifest=runner_identity(package_root); gh,gmanifest=gate_identity(package_root)
    binding_path=phase/"RUN_SOURCE_BINDING_A.json"
    if not binding_path.is_file(): raise RuntimeError("GATE28_BINDING_REQUIRED")
    binding=read_json(binding_path)
    if binding.get("status")!="PASS_SEALED_PREPILOT": raise RuntimeError("GATE28_BINDING_NOT_SEALED")
    if binding.get("binding_content_sha256") != canonical_json_hash(binding, exclude_keys={"binding_content_sha256"}): raise RuntimeError("GATE28_BINDING_CONTENT_HASH_MISMATCH")
    binding_hash=sha256_file(binding_path)
    pre_path=gates/"PRE_PILOT_GATE_RECEIPT.json"
    if not pre_path.is_file(): raise RuntimeError("GATE28_PREPILOT_RECEIPT_REQUIRED")
    pre=read_json(pre_path); pre_hash=sha256_file(pre_path)
    grid_hash=write_grid_cells(phase/"GRID_CELLS.csv")
    for k,v in (("PRE_PILOT_GATES","PASS"),("gates_passed",27),("spec_sha256",SPEC_SHA256),("runner_sha256",rh),("gate_suite_sha256",gh),("grid_sha256",grid_hash),("run_source_binding_sha256",binding_hash)):
        if pre.get(k)!=v: raise RuntimeError(f"GATE28_PREPILOT_STALE {k}")

    receipt_path=pilot/"PILOT_RUN_RECEIPT.json"
    if not receipt_path.is_file(): raise RuntimeError("GATE28_PILOT_RUN_PASS_REQUIRED")
    pilot_run=read_json(receipt_path)
    if pilot_run.get("PILOT_RUN")!="PASS": raise RuntimeError("GATE28_PILOT_RUN_PASS_REQUIRED")
    sessions=pilot_run["sessions"]
    if len(sessions)!=3: raise RuntimeError("GATE28_PILOT_SESSION_COUNT_NOT_3")
    manifest_path=pilot/"RUN_MANIFEST.json"
    if not manifest_path.is_file() or pilot_run.get("run_manifest_sha256")!=sha256_file(manifest_path): raise RuntimeError("GATE28_PILOT_RUN_MANIFEST_HASH_MISMATCH")
    manifest=read_json(manifest_path)
    manifest_checks=(("spec_sha256",SPEC_SHA256),("runner_sha256",rh),("grid_sha256",grid_hash),("run_source_binding_sha256",binding_hash),("gate_receipt_sha256",pre_hash))
    for k,v in manifest_checks:
        if manifest.get(k)!=v: raise RuntimeError(f"GATE28_PILOT_RUN_MANIFEST_STALE {k}")

    calendar={r["session_date"]:r for r in _read_csv(phase/"SESSION_CALENDAR_PHASE_A.csv")}
    tick_map={str(r["path"]):str(r["sha256"]).upper() for r in binding.get("tick_files",[])}
    pilot_paths={str(calendar[s]["tick_file"]) for s in sessions}
    verified={str(k):str(v).upper() for k,v in pilot_run.get("verified_months",{}).items()}
    if set(verified)!=pilot_paths: raise RuntimeError("GATE28_PILOT_MONTH_HASH_SET_MISMATCH")
    for tp in sorted(pilot_paths):
        if verified.get(tp)!=tick_map.get(tp): raise RuntimeError(f"GATE28_PILOT_MONTH_HASH_MISMATCH {tp}")

    d1=load_d1(Path(cfg["ind_d1"])); cells=valid_cells()
    by_file={}
    for sess in sessions:
        row=calendar[sess]; by_file.setdefault(Path(row["tick_file"]),[]).append(sess)
    refs={}
    for tp,file_sessions in sorted(by_file.items(),key=lambda kv:str(kv[0])):
        wanted=set(file_sessions); engines={}
        for rec in iter_tick_file(tp,include_sessions=wanted):
            if rec.session not in engines:
                row=calendar[rec.session]; bar=d1[row["expected_previous_session_date"]]
                engines[rec.session]=ReferencePilotEngine(rec.session,bar,cells,int(row["cutoff_msc"]))
            engines[rec.session].process(rec)
        for sess in file_sessions:
            if sess not in engines: raise RuntimeError(f"GATE28_REFERENCE_SESSION_MISSING {sess}")
            refs[sess]=engines[sess].finish()
    mismatches=[]
    for sess in sessions:
        pilot_rows=[]
        import gzip as _gzip
        with _gzip.open(pilot/"sessions"/sess/"trades.jsonl.gz","rt",encoding="utf-8") as f:
            pilot_rows=[json.loads(line) for line in f if line.strip()]
        pby={}
        for tr in pilot_rows:pby.setdefault(tr["cell_id"],[]).append(tr)
        for c in cells:
            cid=c.cell_id
            pv=sorted(pby.get(cid,[]),key=lambda x:(int(x.get("entry_ordinal",-1)),int(x.get("exit_ordinal",-1))))
            rv=refs[sess].get(cid,[])
            if cid==BASELINE_CELL_ID:
                pa=[_trade_key(x) for x in pv]; ra=[_trade_key(x) for x in rv]
            else:
                pa=[_trade_key(pv[0])] if pv else []; ra=[_trade_key(rv[0])] if rv else []
            if pa!=ra:
                mismatches.append({"session":sess,"cell_id":cid,"pilot":json.dumps(pa,separators=(",",":")),"reference":json.dumps(ra,separators=(",",":"))})
        recon=[]
        with _gzip.open(pilot/"sessions"/sess/"equity_reconciliation.jsonl.gz","rt",encoding="utf-8") as f:
            recon=[json.loads(line) for line in f if line.strip()]
        for r in recon:
            if int(r["open_marks_evaluated"])!=int(r["open_marks_persisted"]):
                mismatches.append({"session":sess,"cell_id":r["cell_id"],"pilot":"OPEN_MARK_NOT_INTEGRAL","reference":"EXPECTED_INTEGRAL"})
    _write_csv(gates/"GATE28_PILOT_RECONCILIATION_DIFF.csv",["session","cell_id","pilot","reference"],mismatches)
    receipt={
        "GATE28_PILOT_RECONCILIATION":"PASS" if not mismatches else "FAIL",
        "sessions":sessions,"cells":len(cells),"mismatch_count":len(mismatches),
        "reference_engine":"INDEPENDENT_SCALAR_LIST_NO_SESSIONENGINE",
        "reference_independence":"PARTIAL_SHARED_PRIMITIVES_DECLARED",
        "spec_sha256":SPEC_SHA256,"runner_sha256":rh,"gate_suite_sha256":gh,
        "run_source_binding_sha256":binding_hash,"pre_pilot_gate_receipt_sha256":pre_hash,
        "pilot_run_receipt_sha256":sha256_file(receipt_path),
        "pilot_run_manifest_sha256":sha256_file(manifest_path),
    }
    write_json_atomic_canonical(out_receipt,receipt)
    if mismatches: raise RuntimeError(f"GATE28_PILOT_RECONCILIATION_FAIL count={len(mismatches)}")
    return receipt


def finalize_pre_run_gates(cfg: dict, package_root: Path):
    root=Path(cfg["out_root"]); phase=root/"PHASE_A"; pilot_root=root/"PILOT_A"; gates=_gates(cfg)
    pre=gates/"PRE_PILOT_GATE_RECEIPT.json"; pilot=gates/"GATE28_PILOT_RECONCILIATION_RECEIPT.json"
    if not pre.is_file() or read_json(pre).get("PRE_PILOT_GATES")!="PASS" or int(read_json(pre).get("gates_passed",0))!=27:
        raise RuntimeError("PRE_RUN_A_PREPILOT_27_PASS_REQUIRED")
    if not pilot.is_file() or read_json(pilot).get("GATE28_PILOT_RECONCILIATION")!="PASS":
        raise RuntimeError("PRE_RUN_A_GATE28_PASS_REQUIRED")
    binding_path=phase/"RUN_SOURCE_BINDING_A.json"; binding=read_json(binding_path)
    if binding.get("status")!="PASS_SEALED_PREPILOT": raise RuntimeError("PRE_RUN_A_BINDING_NOT_SEALED")
    grid_hash=write_grid_cells(phase/"GRID_CELLS.csv")
    rh,rmanifest=runner_identity(package_root); gh,gmanifest=gate_identity(package_root)
    pre_obj=read_json(pre); pilot_obj=read_json(pilot)
    current_binding_hash=sha256_file(binding_path); pre_hash=sha256_file(pre)
    pilot_run_path=pilot_root/"PILOT_RUN_RECEIPT.json"; pilot_manifest_path=pilot_root/"RUN_MANIFEST.json"
    if not pilot_run_path.is_file() or not pilot_manifest_path.is_file(): raise RuntimeError("PRE_RUN_A_PILOT_ARTIFACTS_REQUIRED")
    checks={
        "spec_sha256":SPEC_SHA256,"runner_sha256":rh,"grid_sha256":grid_hash,
        "run_source_binding_sha256":current_binding_hash,"gate_suite_sha256":gh,
    }
    for k,v in checks.items():
        if pre_obj.get(k)!=v: raise RuntimeError(f"PRE_RUN_A_PREPILOT_BINDING_DRIFT {k}")
    pilot_checks={
        "spec_sha256":SPEC_SHA256,"runner_sha256":rh,"gate_suite_sha256":gh,
        "run_source_binding_sha256":current_binding_hash,"pre_pilot_gate_receipt_sha256":pre_hash,
        "pilot_run_receipt_sha256":sha256_file(pilot_run_path),
        "pilot_run_manifest_sha256":sha256_file(pilot_manifest_path),
    }
    for k,v in pilot_checks.items():
        if pilot_obj.get(k)!=v: raise RuntimeError(f"PRE_RUN_A_GATE28_BINDING_DRIFT {k}")
    receipt={
        "PRE_RUN_A_GATES":"PASS","gates_passed":28,"spec_sha256":SPEC_SHA256,
        "runner_sha256":rh,"runner_manifest":rmanifest,"grid_sha256":grid_hash,
        "run_source_binding_sha256":current_binding_hash,"gate_suite_sha256":gh,"gate_manifest":gmanifest,
        "pre_pilot_gate_receipt_sha256":pre_hash,
        "gate28_pilot_reconciliation_receipt_sha256":sha256_file(pilot),
        "pilot_run_receipt_sha256":sha256_file(pilot_run_path),
        "pilot_run_manifest_sha256":sha256_file(pilot_manifest_path),
        "HEAVY_55_3_GIB_PREFLIGHT_RERUN_REQUIRED":"NO",
        "RUN_A_AUTHORIZED":"NO_PENDING_OWNER_AND_POSTIMPLEMENTATION_AUDIT","DATA_PROCESSING_AUTHORIZED":"NO_FULL_RUN",
    }
    write_json_atomic_canonical(gates/"PRE_RUN_A_GATE_RECEIPT.json",receipt)
    return receipt


def status(cfg: dict, package_root: Path):
    root=Path(cfg["out_root"]); gates=_gates(cfg); phase=root/"PHASE_A"
    needed=["SYNTHETIC_GATES_RECEIPT.json","SOURCE_GATES_RECEIPT.json","OPERATIONAL_GATES_RECEIPT.json","GEOMETRY_PREPARE_RECEIPT.json","GEOMETRY_PARITY_RECEIPT.json"]
    missing=[x for x in needed if not (gates/x).is_file()]
    obj={"PRE_PILOT_GATES":"BLOCKED" if missing else "READY_TO_SEAL","missing":missing,"gate28":"PENDING","RUN_A_AUTHORIZED":"NO","DATA_PROCESSING_AUTHORIZED":"NO"}
    if not missing:
        expected={needed[0]:("SYNTHETIC_GATES","PASS"),needed[1]:("SOURCE_GATES","PASS"),needed[2]:("OPERATIONAL_GATES","PASS"),needed[3]:("GEOMETRY_PREPARE","PASS"),needed[4]:("GEOMETRY_PARITY","PASS")}
        for name,(k,v) in expected.items():
            if read_json(gates/name).get(k)!=v: obj["PRE_PILOT_GATES"]="BLOCKED"
    if (gates/"PRE_PILOT_GATE_RECEIPT.json").is_file():
        obj["PRE_PILOT_GATES"]="PASS" if read_json(gates/"PRE_PILOT_GATE_RECEIPT.json").get("PRE_PILOT_GATES")=="PASS" else "BLOCKED"
    if (phase/"RUN_SOURCE_BINDING_A.json").is_file(): obj["binding_status"]=read_json(phase/"RUN_SOURCE_BINDING_A.json").get("status")
    gh,manifest=gate_identity(package_root); obj["gate_suite_sha256"]=gh; obj["gate_manifest"]=manifest
    write_json_atomic_canonical(gates/"PRE_PILOT_GATE_STATUS.json",obj)
    return obj


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("command",choices=["synthetic","source","operational","geometry-prepare","geometry-validate","seal-prepilot","pilot-reconcile","finalize","status"]); ap.add_argument("--config"); ap.add_argument("--mt5-output")
    ns=ap.parse_args(); package_root=Path(__file__).resolve().parent
    cfg=json.loads(Path(ns.config).read_text(encoding="utf-8")) if ns.config else None
    if ns.command=="synthetic": r=run_synthetic(package_root,cfg)
    elif ns.command=="source": r=run_source_gates(cfg,package_root)
    elif ns.command=="operational": r=run_operational(package_root,cfg)
    elif ns.command=="geometry-prepare": r=prepare_geometry(cfg)
    elif ns.command=="geometry-validate": r=validate_geometry(cfg,Path(ns.mt5_output))
    elif ns.command=="seal-prepilot": r=seal_prepilot_gates(cfg,package_root)
    elif ns.command=="pilot-reconcile": r=pilot_reconcile(cfg)
    elif ns.command=="finalize": r=finalize_pre_run_gates(cfg,package_root)
    elif ns.command=="status": r=status(cfg,package_root)
    print(json.dumps(r,ensure_ascii=False,sort_keys=True,indent=2))

if __name__=="__main__": main()
