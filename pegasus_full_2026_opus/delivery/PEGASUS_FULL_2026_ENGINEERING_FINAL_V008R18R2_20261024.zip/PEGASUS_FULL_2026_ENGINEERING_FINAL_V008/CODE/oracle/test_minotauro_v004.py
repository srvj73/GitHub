import tempfile, unittest
from pathlib import Path
from fractions import Fraction
from minotauro_v004_core import *
from minotauro_v004_io import parse_tick_fields, read_m1_bar_csv, load_d1, price_to_micro, iter_tick_file

class Tests(unittest.TestCase):
    def test_cells(self):
        a=build_all_cells();self.assertEqual(len(a),450);self.assertEqual(sum(c.valid for c in a),435);self.assertEqual(sum(not c.valid for c in a),15)
    def test_grid(self):
        g=build_grid(20000*PRICE_SCALE,10000*PRICE_SCALE,Fraction(618,10));self.assertEqual(len(g),97);self.assertEqual(sum(x.macro for x in g),9);self.assertEqual(sum(not x.macro for x in g),88)
    def test_round(self):
        self.assertEqual(round_tick_fraction(Fraction(10002_500000,1)),10005*PRICE_SCALE);self.assertEqual(round_tick_fraction(Fraction(10002_499999,1)),10000*PRICE_SCALE)
    def test_neighbor_off_symmetric(self):
        d={c.cell_id:c for c in valid_cells()};a=d["P02_T02_R02_M00"];b=d["P02_T02_R02_M03"];self.assertIn(b.cell_id,cell_neighbors(a,d));self.assertIn(a.cell_id,cell_neighbors(b,d))
    def rec(self,o,m,b,a,l,v=1):
        return TickRecord("2025-01-02",o,"2025.01.02 10:00:00",m,b*PRICE_SCALE,a*PRICE_SCALE,l*PRICE_SCALE,v,v,0)
    def test_n_n1_same_ms(self):
        c=[x for x in valid_cells() if x.cell_id==BASELINE_CELL_ID][0];d=D1Bar("2024-12-30",10000*PRICE_SCALE,20000*PRICE_SCALE,10000*PRICE_SCALE,15000*PRICE_SCALE)
        e=SessionEngine("2025-01-02",d,[c],9999999999999);line=e.lines[2][48].price_micro//PRICE_SCALE
        e.process_record(self.rec(1,1000,line-5,line,line));e.process_record(self.rec(2,2000,line+45,line+50,line+50));self.assertTrue(e.pending_active[0]);e.process_record(self.rec(3,2000,line+50,line+55,line+55));self.assertFalse(e.pending_active[0]);self.assertTrue(e.trades);self.assertEqual(e.trades[0]["n_ordinal"],2);self.assertEqual(e.trades[0]["n1_ordinal"],3)
    def test_stale_bbo_consumes(self):
        c=[x for x in valid_cells() if x.cell_id==BASELINE_CELL_ID][0];d=D1Bar("2024-12-30",10000*PRICE_SCALE,20000*PRICE_SCALE,10000*PRICE_SCALE,15000*PRICE_SCALE)
        e=SessionEngine("2025-01-02",d,[c],9999999999999);line=e.lines[2][48].price_micro//PRICE_SCALE
        e.process_record(self.rec(1,1000,line-5,line,line));e.process_record(self.rec(2,2000,line+45,line+50,line+50));self.assertTrue(e.pending_active[0]);e.process_record(self.rec(3,3001,0,0,line+55));self.assertFalse(e.pending_active[0]);self.assertFalse(e.pos_open[0])
    def test_physical_tick_schema_actual_sample(self):
        f="WIN@N;2025.01.02 08:55:00;1735818900041;0.00;122360;0.00;0;0;4".split(";")
        r=parse_tick_fields(f,1);self.assertEqual(r.session,"2025-01-02");self.assertEqual(r.time_msc,1735818900041);self.assertEqual(r.ask_micro,122360*PRICE_SCALE);self.assertFalse(r.business)
    def test_physical_m1_schema_actual_sample(self):
        line="WIN@N;M1;2025.01.02;09:00:00;121790.00;121890.00;121750.00;121825.00;10611;23062;23062.00;1735819238125;1735819259992\n"
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"WIN@N_M1_2025_01.csv";p.write_text(line,encoding="utf-8")
            rows=read_m1_bar_csv(p);self.assertEqual(len(rows),1);self.assertEqual(rows[0]["date"],"2025.01.02");self.assertEqual(rows[0]["timeframe"],"M1")
    def test_ind_d1_actual_schema(self):
        text="data,abertura,maxima,minima,fechamento,financeiro,contratos\n2019-08-22,101935,102420,100620,100810,,\n2019-08-23,101000,101005,97525,98395,,\n"
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"IND@N.csv";p.write_text(text,encoding="utf-8")
            d=load_d1(p);self.assertEqual(len(d),2);self.assertEqual(d["2019-08-22"].high_micro,102420*PRICE_SCALE);self.assertEqual(d["2019-08-23"].low_micro,97525*PRICE_SCALE)


    def test_progress_callback_reports_final_bytes(self):
        lines=[
            "WIN@N;2025.01.02 08:55:00;1735818900041;0.00;122360;0.00;0;0;4\n",
            "WIN@N;2025.01.02 08:55:00;1735818900044;121000;122360;0.00;0;0;6\n",
            "WIN@N;2025.01.02 09:00:00;1735819200000;121800;121805;121805;1;1;0\n",
        ]
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"ticks.csv"
            p.write_text("".join(lines),encoding="utf-8")
            calls=[]
            rows=list(iter_tick_file(p,include_sessions={"2025-01-02"},
                                     progress_cb=lambda b,r,s,f:calls.append((b,r,s,f)),
                                     progress_step_bytes=1))
            self.assertEqual(len(rows),3)
            self.assertTrue(calls)
            self.assertEqual(calls[-1][0],p.stat().st_size)
            self.assertEqual(calls[-1][2],p.stat().st_size)


    def _cutoff_engine(self, cutoff=5000):
        c=[x for x in valid_cells() if x.cell_id==BASELINE_CELL_ID][0]
        d=D1Bar("2024-12-30",10000*PRICE_SCALE,20000*PRICE_SCALE,10000*PRICE_SCALE,15000*PRICE_SCALE)
        return SessionEngine("2025-01-02",d,[c],cutoff)

    def _seed_position(self,e,direction,entry=100):
        idx=0
        e.realized[idx]-=ENTRY_COST_UNITS
        e.pos_open[idx]=True;e.pos_dir[idx]=direction;e.pos_entry[idx]=entry*PRICE_SCALE
        e.pos_sl[idx]=(1 if direction>0 else 1_000_000)*PRICE_SCALE
        e.pos_tp[idx]=(1_000_000 if direction>0 else 1)*PRICE_SCALE
        e.pos_entry_msc[idx]=1000;e.pos_entry_ordinal[idx]=1
        e.trades.append({"cell_id":e.cell_ids[idx],"session":e.session,"direction":"BUY" if direction>0 else "SELL","entry_msc":1000,"entry_ordinal":1,"entry_price_micro":entry*PRICE_SCALE})
        e.pos_trade_index[idx]=0

    def test_cutoff_inherited_pre_cutoff_quote_marks_but_does_not_fill(self):
        e=self._cutoff_engine();e.process_record(self.rec(1,4900,99,101,0,0));self._seed_position(e,1,100)
        keep=e.process_record(self.rec(2,5000,0,0,0,0))
        self.assertTrue(keep);self.assertTrue(e.cutoff_pending[0]);self.assertTrue(e.pos_open[0])
        self.assertTrue(any(x.get("event")=="OPEN_MARK" and x.get("cutoff_pending") is True for x in e.equity_events))
        keep=e.process_record(self.rec(3,5200,100,0,0,0))
        self.assertFalse(keep);self.assertFalse(e.pos_open[0]);self.assertEqual(e.trades[0]["exit_reason"],"CUTOFF")
        self.assertEqual(e.trades[0]["cutoff_fill_msc"],5200);self.assertEqual(e.trades[0]["cutoff_side_msc"],5200)

    def test_cutoff_short_requires_own_post_cutoff_ask_timestamp(self):
        e=self._cutoff_engine();e.process_record(self.rec(1,4900,99,101,0,0));self._seed_position(e,-1,100)
        self.assertTrue(e.process_record(self.rec(2,5000,100,0,0,0)))
        self.assertTrue(e.pos_open[0])
        self.assertFalse(e.process_record(self.rec(3,5100,0,102,0,0)))
        self.assertEqual(e.trades[0]["cutoff_side"],"ASK");self.assertEqual(e.trades[0]["cutoff_side_msc"],5100)

    def test_cutoff_crossed_state_deferred_then_resolved(self):
        e=self._cutoff_engine();e.process_record(self.rec(1,4900,100,105,0,0));self._seed_position(e,1,100)
        self.assertTrue(e.process_record(self.rec(2,5000,110,0,0,0)))  # inherited ask=105 => crossed
        self.assertTrue(e.pos_open[0])
        self.assertFalse(e.process_record(self.rec(3,5100,0,115,0,0)))
        self.assertEqual(e.trades[0]["cutoff_fill_msc"],5100)
        self.assertEqual(e.trades[0]["cutoff_side_msc"],5000)

    def test_cutoff_update_exactly_at_cutoff_same_ms_is_eligible(self):
        e=self._cutoff_engine();e.process_record(self.rec(1,4900,99,101,0,0));self._seed_position(e,1,100)
        self.assertFalse(e.process_record(self.rec(2,5000,100,101,0,0)))
        self.assertEqual(e.trades[0]["cutoff_fill_msc"],5000)
        self.assertEqual(e.trades[0]["cutoff_execution_latency_ms"],0)

    def test_cutoff_close_has_no_duplicate_open_mark_same_record(self):
        e=self._cutoff_engine();e.process_record(self.rec(1,4900,99,101,0,0));self._seed_position(e,1,100)
        e.process_record(self.rec(2,5000,100,101,0,0))
        at=[x for x in e.equity_events if x.get("time_msc")==5000]
        self.assertEqual(sum(x.get("event")=="CUTOFF_CLOSE_POST_REALIZATION" for x in at),1)
        self.assertEqual(sum(x.get("event")=="OPEN_MARK" for x in at),0)

    def test_cutoff_session_boundary_never_crosses(self):
        e=self._cutoff_engine()
        bad=TickRecord("2025-01-03",1,"2025.01.03 18:03:00",5000,100*PRICE_SCALE,101*PRICE_SCALE,0,0,0,0)
        with self.assertRaisesRegex(ModelError,"SESSION_BOUNDARY_CROSSING"):
            e.process_record(bad)

    def test_cutoff_pending_without_post_cutoff_side_blocks_finish(self):
        e=self._cutoff_engine();e.process_record(self.rec(1,4900,99,101,0,0));self._seed_position(e,1,100)
        self.assertTrue(e.process_record(self.rec(2,5000,0,102,0,0)))
        with self.assertRaisesRegex(ModelError,"POSITION_NOT_FLAT_AFTER_CUTOFF"):
            e.finish(2,"2025.01.02 18:03:00")

if __name__=="__main__":unittest.main(verbosity=2)
