param([string]$Config = "$PSScriptRoot\config.json")
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Minotauro_Launcher_Common.ps1"
$TranscriptOwned = Start-MinotauroTranscript -Config $Config -LauncherName $MyInvocation.MyCommand.Name
try {
    $Python=Resolve-RealPython
    $ExitCode = Invoke-MinotauroPython -Python $Python -Arguments @("$PSScriptRoot\minotauro_v005r1_r23_gates.py",'operational','--config',$Config)
    if ($ExitCode -ne 0) { throw "OPERATIONAL_GATES_FAIL=$ExitCode" }
    Write-Host 'GATE26_SAFE_STOP_TRANSACTIONAL=PASS'
    Write-Host 'GATE27_CLEAN_RESUME_EQUIVALENCE=PASS'
    Write-Host 'DATA_PROCESSING=NO'
}
finally {
    Stop-MinotauroTranscriptSafe -Owned $TranscriptOwned
}
