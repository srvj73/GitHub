# MINOTAURO V005R1 R1R10 - launcher self-test (operational only, no market data).
# Proves on the executing PowerShell host, with a synthetic Python child:
#   B7  live stdout   : lines reach Write-Host while the child is still running;
#   B8  live stderr   : idem for stderr (re-labelled '[stderr] ');
#   B9  exit authority: PASS-looking text + non-zero exit stays non-zero/fail-closed;
#   B10 nested transcript rule of Start-MinotauroTranscript is preserved, and the
#       streamed lines are captured by Start-Transcript.
# Any failed check throws; the process exit code is 0 only after every check passed.
param(
    [Parameter(Mandatory=$true)][string]$Python
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
. "$PSScriptRoot\Minotauro_Launcher_Common.ps1"

function Assert-R1R10Check {
    param([bool]$Condition, [string]$Name, [string]$Detail = '')
    if (-not $Condition) { throw "R1R10_LAUNCHER_SELFTEST_FAIL=$Name $Detail" }
    Write-Host "R1R10_SELFTEST_CHECK=$Name PASS $Detail"
}

$SavedActive = $env:MINOTAURO_TRANSCRIPT_ACTIVE
$SavedPath = $env:MINOTAURO_TRANSCRIPT_PATH
$Work = Join-Path ([System.IO.Path]::GetTempPath()) ("MINOTAURO_R1R10_SELFTEST_{0}_{1}" -f $PID, ([guid]::NewGuid().ToString('N')))
$Owned = $false
$Failed = $null
try {
    New-Item -ItemType Directory -Force -Path $Work | Out-Null
    $Child = Join-Path $Work 'r1r10_selftest_child.py'
    $ChildLines = @(
        'import sys, time',
        'code = int(sys.argv[1])',
        'delay = float(sys.argv[2])',
        'for i in range(1, 4):',
        '    print("R1R10_CHILD_STDOUT_%d" % i, flush=True)',
        '    time.sleep(delay)',
        '    print("R1R10_CHILD_STDERR_%d" % i, file=sys.stderr, flush=True)',
        '    time.sleep(delay)',
        'print("SYNTHETIC_GATE=PASS", flush=True)',
        'print("PRE_RUN_A_GATES=PASS_28_OF_28", flush=True)',
        'time.sleep(delay * 2)',
        'sys.exit(code)'
    )
    [System.IO.File]::WriteAllLines($Child, [string[]]$ChildLines)
    $Cfg = Join-Path $Work 'selftest_config.json'
    $OutRoot = Join-Path $Work 'out'
    [System.IO.File]::WriteAllText($Cfg, ('{"out_root": ' + (ConvertTo-Json -InputObject ([string]$OutRoot)) + '}'))

    # ---- B10: nested transcript rule -------------------------------------------------
    $env:MINOTAURO_TRANSCRIPT_ACTIVE = '1'
    $env:MINOTAURO_TRANSCRIPT_PATH = (Join-Path $Work 'missing_transcript.log')
    $InvalidThrew = $false
    try { [void](Start-MinotauroTranscript -Config $Cfg -LauncherName 'R1R10_INVALID_STATE.ps1') }
    catch { $InvalidThrew = ([string]$_.Exception.Message -like '*TRANSCRIPT_ACTIVE_STATE_INVALID*') }
    Assert-R1R10Check $InvalidThrew 'NESTED_INVALID_ACTIVE_STATE_THROWS'

    Remove-Item Env:MINOTAURO_TRANSCRIPT_ACTIVE -ErrorAction SilentlyContinue
    Remove-Item Env:MINOTAURO_TRANSCRIPT_PATH -ErrorAction SilentlyContinue
    $Owned = Start-MinotauroTranscript -Config $Cfg -LauncherName 'R1R10_LAUNCHER_SELFTEST.ps1'
    $TranscriptPath = $env:MINOTAURO_TRANSCRIPT_PATH
    Assert-R1R10Check ($Owned -eq $true) 'OWNED_TRANSCRIPT_STARTED'
    Assert-R1R10Check (($env:MINOTAURO_TRANSCRIPT_ACTIVE -eq '1') -and (Test-Path -LiteralPath $TranscriptPath -PathType Leaf)) 'TRANSCRIPT_ENV_SET'

    $Nested = Start-MinotauroTranscript -Config $Cfg -LauncherName 'R1R10_NESTED.ps1'
    $LogCount = @(Get-ChildItem -LiteralPath (Join-Path $OutRoot 'LOGS') -Filter '*.log' -File).Count
    Assert-R1R10Check (($Nested -eq $false) -and ($env:MINOTAURO_TRANSCRIPT_PATH -eq $TranscriptPath) -and ($LogCount -eq 1)) 'NESTED_CALL_SHARES_OUTER_TRANSCRIPT' ("logs=$LogCount")
    Stop-MinotauroTranscriptSafe -Owned $false
    Assert-R1R10Check (($env:MINOTAURO_TRANSCRIPT_ACTIVE -eq '1') -and ($env:MINOTAURO_TRANSCRIPT_PATH -eq $TranscriptPath)) 'NESTED_STOP_IS_NOOP'

    # ---- B7/B8/B9: live stdout/stderr, exit authority ----------------------------------
    $Seen = New-Object 'System.Collections.Generic.List[object]'
    $Observer = { param($L) $Seen.Add([pscustomobject]@{ T = [DateTime]::UtcNow; Line = [string]$L }) }.GetNewClosure()
    $Code = Invoke-MinotauroPython -Python $Python -Arguments @($Child, '7', '0.7') -LineObserver $Observer
    $Returned = [DateTime]::UtcNow
    Assert-R1R10Check ($Code -eq 7) 'NATIVE_EXIT_NONZERO_PRESERVED_DESPITE_PASS_TEXT' ("exit=$Code")

    $Expected = @(
        'R1R10_CHILD_STDOUT_1', '[stderr] R1R10_CHILD_STDERR_1',
        'R1R10_CHILD_STDOUT_2', '[stderr] R1R10_CHILD_STDERR_2',
        'R1R10_CHILD_STDOUT_3', '[stderr] R1R10_CHILD_STDERR_3',
        'SYNTHETIC_GATE=PASS', 'PRE_RUN_A_GATES=PASS_28_OF_28'
    )
    $When = @{}
    foreach ($Item in $Seen) { if (-not $When.ContainsKey($Item.Line)) { $When[$Item.Line] = $Item.T } }
    $Missing = @($Expected | Where-Object { -not $When.ContainsKey($_) })
    Assert-R1R10Check ($Missing.Count -eq 0) 'ALL_STDOUT_STDERR_LINES_STREAMED' ("missing=" + ($Missing -join ','))

    $LeadOut = ($Returned - $When['R1R10_CHILD_STDOUT_1']).TotalSeconds
    $LeadErr = ($Returned - $When['[stderr] R1R10_CHILD_STDERR_1']).TotalSeconds
    $Spread = ($When['R1R10_CHILD_STDOUT_3'] - $When['R1R10_CHILD_STDOUT_1']).TotalSeconds
    Assert-R1R10Check ($LeadOut -ge 2.5) 'LIVE_STDOUT_BEFORE_PROCESS_EXIT' ("lead_s={0:N3}" -f $LeadOut)
    Assert-R1R10Check ($LeadErr -ge 2.0) 'LIVE_STDERR_BEFORE_PROCESS_EXIT' ("lead_s={0:N3}" -f $LeadErr)
    Assert-R1R10Check ($Spread -ge 1.5) 'INCREMENTAL_ARRIVAL_NOT_BATCH_REPLAY' ("spread_s={0:N3}" -f $Spread)

    $Code0 = Invoke-MinotauroPython -Python $Python -Arguments @($Child, '0', '0')
    Assert-R1R10Check ($Code0 -eq 0) 'STDERR_WITH_EXIT_ZERO_IS_NOT_FAILURE' ("exit=$Code0")
    $Code3 = Invoke-MinotauroPython -Python $Python -Arguments @($Child, '3', '0')
    Assert-R1R10Check ($Code3 -eq 3) 'MEMORY_CAP_EXIT_CODE_PRESERVED' ("exit=$Code3")

    $LauncherThrew = $false
    $ReachedPass = $false
    try {
        $CodeFail = Invoke-MinotauroPython -Python $Python -Arguments @($Child, '1', '0')
        if ($CodeFail -ne 0) { throw "COMMAND_FAIL=$CodeFail" }
        $ReachedPass = $true
    }
    catch { $LauncherThrew = ([string]$_.Exception.Message -eq 'COMMAND_FAIL=1') }
    Assert-R1R10Check ($LauncherThrew -and -not $ReachedPass) 'LAUNCHER_PATTERN_FAIL_CLOSED_ON_NONZERO'

    $MissingThrew = $false
    try { [void](Invoke-MinotauroPython -Python (Join-Path $Work 'no_such_python.exe') -Arguments @('-c', 'pass')) }
    catch { $MissingThrew = ([string]$_.Exception.Message -like 'PYTHON_MISSING=*') }
    Assert-R1R10Check $MissingThrew 'MISSING_PYTHON_FAIL_CLOSED'

    # ---- transcript capture of the streamed lines --------------------------------------
    Stop-MinotauroTranscriptSafe -Owned $Owned
    $Owned = $false
    Assert-R1R10Check (-not (Test-Path Env:MINOTAURO_TRANSCRIPT_ACTIVE)) 'OWNED_STOP_CLEARS_ENV'
    $Text = [System.IO.File]::ReadAllText($TranscriptPath)
    $NotCaptured = @($Expected | Where-Object { -not $Text.Contains($_) })
    Assert-R1R10Check ($NotCaptured.Count -eq 0) 'TRANSCRIPT_CAPTURED_LIVE_LINES' ("missing=" + ($NotCaptured -join ','))
}
catch {
    $Failed = [string]$_.Exception.Message
}
finally {
    if ($Owned) { Stop-MinotauroTranscriptSafe -Owned $true }
    if ($null -ne $SavedActive) { $env:MINOTAURO_TRANSCRIPT_ACTIVE = $SavedActive } else { Remove-Item Env:MINOTAURO_TRANSCRIPT_ACTIVE -ErrorAction SilentlyContinue }
    if ($null -ne $SavedPath) { $env:MINOTAURO_TRANSCRIPT_PATH = $SavedPath } else { Remove-Item Env:MINOTAURO_TRANSCRIPT_PATH -ErrorAction SilentlyContinue }
    Remove-Item -LiteralPath $Work -Recurse -Force -ErrorAction SilentlyContinue
}
if ($null -ne $Failed) {
    Write-Host "R1R10_LAUNCHER_SELFTEST=FAIL $Failed"
    exit 1
}
Write-Host 'R1R10_LAUNCHER_SELFTEST=PASS'
exit 0
