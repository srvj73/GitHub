#requires -Version 5.1
[CmdletBinding()] param(
 [Parameter(Mandatory=$true)][string]$OwnerEvidenceRoot,
 [Parameter(Mandatory=$true)][string]$A0EvidenceRoot,
 [Parameter(Mandatory=$true)][string]$DevBenchRoot,
 [Parameter(Mandatory=$true)][string]$G4LedgerRoot,
 [Parameter(Mandatory=$true)][string]$OutputZip
)
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'POWERSHELL_5_1_REQUIRED' }
. (Join-Path $PSScriptRoot 'Minotauro_Launcher_Common.ps1'); $Python=Resolve-RealPython
Write-Host 'AMBIENTE=PowerShell R1R11_V005R1_FINAL_AUDIT_PACK INCLUDES=A0+DEV_BENCH+G4_LEDGER+OWNER+PACKAGE'
& $Python -X utf8 -B (Join-Path $PSScriptRoot 'r1r11_final_audit_pack.py') `
  --owner-output ([IO.Path]::GetFullPath($OwnerEvidenceRoot)) `
  --a0-evidence ([IO.Path]::GetFullPath($A0EvidenceRoot)) `
  --dev-bench ([IO.Path]::GetFullPath($DevBenchRoot)) `
  --g4-ledger ([IO.Path]::GetFullPath($G4LedgerRoot)) `
  --out-zip ([IO.Path]::GetFullPath($OutputZip))
exit $LASTEXITCODE
