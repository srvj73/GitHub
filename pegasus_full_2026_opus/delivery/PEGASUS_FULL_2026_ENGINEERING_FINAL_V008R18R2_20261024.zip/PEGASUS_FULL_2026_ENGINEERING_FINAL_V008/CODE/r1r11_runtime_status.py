from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path


REQUIRED = (
    'schema','PHASE','COMMITTED','TOTAL','PCT','RATE','ETA','FINISH',
    'ACTIVE','READY_WAITING','CHECKPOINT','SAFE_STOP','PROCESS_TREE_CLEAN',
    'run_instance','out_root','mode','updated_at'
)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_status(*, run_instance: str, out_root: Path, mode: str,
               committed: int = 0, total: int = 0) -> dict:
    total = int(total); committed = int(committed)
    pct = (100.0 * committed / total) if total > 0 else 0.0
    return {
        'schema': 'MINOTAURO_R1R11_RUNTIME_STATUS_V001',
        'PHASE': 'RUNTIME_CREATED',
        'COMMITTED': committed,
        'TOTAL': total,
        'PCT': pct,
        'RATE': 'UNKNOWN',
        'ETA': 'UNKNOWN',
        'FINISH': 'UNKNOWN',
        'ACTIVE': 0,
        'READY_WAITING': 0,
        'CHECKPOINT': 'NONE',
        'SAFE_STOP': 'NO',
        'PROCESS_TREE_CLEAN': 'UNKNOWN',
        'run_instance': str(run_instance),
        'out_root': str(Path(out_root).resolve()),
        'mode': str(mode),
        'updated_at': _now(),
    }


def write_status_atomic(path: Path, state: dict, **updates) -> dict:
    from minotauro_v005r1_r23_contract import write_json_atomic_canonical
    obj = dict(state)
    obj.update(updates)
    obj['COMMITTED'] = int(obj.get('COMMITTED', 0))
    obj['TOTAL'] = int(obj.get('TOTAL', 0))
    if obj['COMMITTED'] < 0 or obj['TOTAL'] < 0 or obj['COMMITTED'] > obj['TOTAL']:
        raise RuntimeError('RUNTIME_STATUS_COMMITTED_TOTAL_INVALID')
    obj['PCT'] = (100.0 * obj['COMMITTED'] / obj['TOTAL']) if obj['TOTAL'] > 0 else 0.0
    if obj['PCT']==100.0 and obj.get('PROCESS_TREE_CLEAN')!='YES': obj['PCT']=99.99
    obj['updated_at'] = _now()
    missing = [k for k in REQUIRED if k not in obj]
    if missing:
        raise RuntimeError('RUNTIME_STATUS_REQUIRED_FIELDS ' + ','.join(missing))
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    write_json_atomic_canonical(path, obj)
    return obj
