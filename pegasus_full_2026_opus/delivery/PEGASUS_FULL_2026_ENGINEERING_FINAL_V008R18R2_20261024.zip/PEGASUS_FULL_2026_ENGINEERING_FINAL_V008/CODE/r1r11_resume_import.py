from __future__ import annotations
import argparse, csv, hashlib, json, os, shutil, sys, traceback
from pathlib import Path

PACKAGE=Path(__file__).resolve().parent
SESSION_FILES=(
    'trades.jsonl.gz','events.jsonl.gz','equity.jsonl.gz',
    'equity_reconciliation.jsonl.gz','session_receipt.json',
)
SOURCE_BINDING_KEYS=(
    'binding_version','runner_version','spec_sha256','preflight_py_sha256','io_py_sha256',
    'core_imported_definitions_sha256','tick_files','tick_manifest_sha256',
    'expected_sessions_rederived_sha256','d1_predecessor_extract_sha256','ind_d1_path',
    'ind_d1_sha256','m1_files','m1_manifest_sha256','preflight_status_sha256',
    'preflight_failures_sha256','session_calendar_sha256','expected_sessions_sha256',
    'source_inventory_sha256','cutoff_latency_diagnostics_sha256',
)

def sha(path:Path)->str:
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest().upper()

def read(path:Path): return json.loads(path.read_text(encoding='utf-8'))

def fail(msg): raise RuntimeError(msg)

def exact_session_set(root:Path, completed:list[str]):
    sessions=root/'PHASE_A'/'sessions'
    actual={p.name for p in sessions.iterdir() if p.is_dir()} if sessions.is_dir() else set()
    if actual!=set(completed):
        fail(f'SOURCE_SESSION_SET_MISMATCH completed={len(completed)} actual={len(actual)}')

def validate_stop_receipt(source:Path, receipt_path:Path, cp_sha:str, completed:list[str]):
    receipt_path=Path(receipt_path).resolve()
    if not receipt_path.is_file(): fail('SOURCE_STOP_RECEIPT_MISSING')
    obj=read(receipt_path)
    if obj.get('status')!='PASS': fail('SOURCE_STOP_RECEIPT_NOT_PASS')
    if obj.get('source_root') is not None and Path(str(obj['source_root'])).resolve()!=source.resolve():
        fail('SOURCE_STOP_RECEIPT_ROOT_MISMATCH')
    if int(obj.get('source_completed',-1))!=len(completed): fail('SOURCE_STOP_RECEIPT_COUNT_MISMATCH')
    last=completed[-1] if completed else None
    if obj.get('source_last')!=last: fail('SOURCE_STOP_RECEIPT_LAST_MISMATCH')
    if str(obj.get('source_checkpoint_sha256','')).upper()!=cp_sha.upper(): fail('SOURCE_STOP_RECEIPT_CHECKPOINT_MISMATCH')
    if obj.get('source_lock_absent')!='YES': fail('SOURCE_STOP_RECEIPT_LOCK_NOT_PROVEN_ABSENT')
    if obj.get('journal_empty')!='YES': fail('SOURCE_STOP_RECEIPT_JOURNAL_NOT_PROVEN_EMPTY')
    return obj

def validate_source(source:Path, expected_cp_sha:str|None=None, expected_count:int|None=None, expected_last:str|None=None, *, stop_receipt:Path|None=None, dynamic=False):
    if (source/'RUN.lock').exists(): fail('SOURCE_RUN_LOCK_PRESENT')
    journal=source/'PHASE_A'/'_commit_journal'
    if journal.is_dir() and any(p.is_file() for p in journal.iterdir()): fail('SOURCE_COMMIT_JOURNAL_NOT_EMPTY')
    cp_path=source/'PHASE_A'/'CHECKPOINT.json'
    if not cp_path.is_file(): fail('SOURCE_CHECKPOINT_MISSING')
    cp_sha=sha(cp_path)
    cp=read(cp_path)
    import minotauro_v004_runner as runner
    runner._verify_checkpoint_self(cp)
    completed=sorted(str(x) for x in cp.get('completed',[]))
    if len(completed)!=len(set(completed)): fail('SOURCE_COMPLETED_DUPLICATE')
    actual_last=completed[-1] if completed else None
    if cp.get('last_committed_session_date')!=actual_last: fail('SOURCE_CP_LAST_COMMITTED_FIELD_MISMATCH')
    exact_session_set(source,completed)
    for sess in completed:
        d=source/'PHASE_A'/'sessions'/sess
        names={p.name for p in d.iterdir() if p.is_file()}
        if names!=set(SESSION_FILES): fail('SOURCE_SESSION_FILE_SET '+sess)
    if dynamic:
        if stop_receipt is None: fail('SOURCE_STOP_RECEIPT_REQUIRED_DYNAMIC')
        stop_obj=validate_stop_receipt(source,Path(stop_receipt),cp_sha,completed)
    else:
        if expected_cp_sha is None or expected_count is None or expected_last is None:
            fail('STATIC_SOURCE_BINDING_ARGUMENTS_REQUIRED')
        if cp_sha!=str(expected_cp_sha).upper(): fail('SOURCE_CHECKPOINT_SHA_MISMATCH')
        if len(completed)!=int(expected_count): fail('SOURCE_COMPLETED_COUNT_MISMATCH')
        if actual_last!=expected_last: fail('SOURCE_LAST_COMMITTED_MISMATCH')
        stop_obj=None
    return cp,completed,cp_sha,stop_obj

def compare_bindings(source:Path,target:Path):
    sb=read(source/'PHASE_A'/'RUN_SOURCE_BINDING_A.json')
    tb=read(target/'PHASE_A'/'RUN_SOURCE_BINDING_A.json')
    mism=[k for k in SOURCE_BINDING_KEYS if sb.get(k)!=tb.get(k)]
    if mism: fail('SOURCE_BINDING_SEMANTIC_MISMATCH '+','.join(mism))
    return sb,tb

def validate_verified_months(cp:dict,target_binding:dict):
    tick_map={str(r['path']):str(r['sha256']).upper() for r in target_binding.get('tick_files',[])}
    verified=dict(cp.get('verified_months',{}))
    for p,h in verified.items():
        if tick_map.get(str(p))!=str(h).upper(): fail('VERIFIED_MONTH_NOT_BOUND '+str(p))
    return verified

def copy_sessions_atomic(source:Path,target:Path,completed:list[str]):
    phase=target/'PHASE_A'; final=phase/'sessions'; staging=phase/'.import_sessions_staging'
    src_sessions=source/'PHASE_A'/'sessions'
    if final.exists():
        actual={p.name for p in final.iterdir() if p.is_dir()}
        if actual!=set(completed): fail('TARGET_PARTIAL_SESSION_SET_UNRECONCILABLE')
        # Verify existing imported bytes for idempotent recovery.
        for s in completed:
            for n in SESSION_FILES:
                if sha(final/s/n)!=sha(src_sessions/s/n): fail('TARGET_IMPORTED_HASH_DRIFT '+s+'/'+n)
        return final
    if staging.exists(): shutil.rmtree(staging)
    staging.mkdir(parents=True)
    try:
        for s in completed:
            dst=staging/s
            shutil.copytree(src_sessions/s,dst,copy_function=shutil.copy2)
            for n in SESSION_FILES:
                if sha(dst/n)!=sha(src_sessions/s/n): fail('IMPORT_COPY_HASH_MISMATCH '+s+'/'+n)
        os.replace(staging,final)
    except BaseException:
        # Staging is run-owned and not committed; remove only this owned staging tree.
        if staging.exists(): shutil.rmtree(staging,ignore_errors=True)
        raise
    return final

def build_import_manifest(source:Path,target:Path,completed:list[str]):
    src=source/'PHASE_A'/'sessions'; dst=target/'PHASE_A'/'sessions'
    lines=[]
    for s in completed:
        for n in SESSION_FILES:
            hs=sha(src/s/n); ht=sha(dst/s/n)
            if hs!=ht: fail('IMPORTED_HASH_MISMATCH '+s+'/'+n)
            lines.append(f'{ht}  {s}/{n}')
    text='\n'.join(lines)+'\n'
    p=target/'GATES'/'COMMITTED_IMPORT_SHA256SUMS.txt'; p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix('.txt.tmp'); tmp.write_text(text,encoding='ascii',newline='\n'); os.replace(tmp,p)
    return p,len(lines)

def rebuild_candidate_checkpoint(source_cp:dict,target:Path,target_binding:dict,completed:list[str]):
    import minotauro_v004_runner as runner
    from minotauro_v004_core import valid_cells
    import r1r11_perf_next_controller as controller
    cfg=controller.config(target); phase=target/'PHASE_A'
    runtime_hashes=runner._verify_use_time_binding(PACKAGE,phase,target_binding)
    identity=runner._static_identity(PACKAGE,phase,cfg,target_binding)
    cells=valid_cells()
    if source_cp.get('cell_ids')!=[c.cell_id for c in cells]: fail('SOURCE_CELL_IDS_MISMATCH')
    state_keys=('cash','hwm','maxdd','regime_min','closed_hwm','closed_maxdd')
    for k in state_keys:
        if not isinstance(source_cp.get(k),list) or len(source_cp[k])!=len(cells): fail('SOURCE_STATE_VECTOR '+k)
    cp=runner._new_checkpoint('RUN_A',cells,identity,runtime_hashes)
    for k in state_keys: cp[k]=list(source_cp[k])
    cp['completed']=list(completed)
    cp['last_committed_session_date']=max(completed) if completed else None
    cp['verified_months']=validate_verified_months(source_cp,target_binding)
    cp_path=phase/'CHECKPOINT.json'
    if cp_path.exists():
        old=read(cp_path)
        # Idempotent recovery only if already the exact migrated economic state.
        if old.get('completed')!=cp['completed'] or any(old.get(k)!=cp[k] for k in state_keys):
            fail('TARGET_CHECKPOINT_PREEXISTS_INCOMPATIBLE')
    runner._write_checkpoint(cp_path,cp)
    # Seed per-session physical source anchor for the first pending session. The
    # economic state remains the imported committed state; only resume metadata is added.
    calendar_path=phase/'SESSION_CALENDAR_PHASE_A.csv'
    with calendar_path.open('r',encoding='utf-8-sig',newline='') as f:
        calendar=sorted(csv.DictReader(f,delimiter=';'),key=lambda r:r['session_date'])
    pending=[r for r in calendar if r['session_date'] not in set(completed)]
    source_anchor=None
    if pending:
        from r1r11_fast_resume import anchor_for_first_pending, write_anchor_checkpoint
        first=pending[0]
        source_anchor=anchor_for_first_pending(Path(first['tick_file']),first['session_date'])
        write_anchor_checkpoint(cp_path,cp,source_anchor)
    return cp,identity,cp_path,source_anchor

def write_seals(target:Path,completed:list[str]):
    from minotauro_v005r1_r23_contract import write_json_atomic_canonical
    phase=target/'PHASE_A'
    key=hashlib.sha256(str(phase.resolve()).encode()).hexdigest()
    root=target/'TELEMETRY'/'SESSION_SEALS'/key
    root.mkdir(parents=True,exist_ok=True)
    for s in completed:
        files={n:sha(phase/'sessions'/s/n) for n in SESSION_FILES}
        write_json_atomic_canonical(root/(s+'.json'),{'session':s,'out':str(phase.resolve()),'files':files})
    return root

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-root',required=True)
    ap.add_argument('--target-root',required=True)
    ap.add_argument('--dynamic-final-state',action='store_true')
    ap.add_argument('--source-stop-receipt')
    ap.add_argument('--expected-source-checkpoint-sha256')
    ap.add_argument('--expected-completed',type=int)
    ap.add_argument('--expected-last')
    ns=ap.parse_args()
    source=Path(ns.source_root); target=Path(ns.target_root)
    try:
        import r1r11_perf_next_controller as controller
        pkg_hash=controller.verify_package()
        source_cp,completed,source_cp_sha,stop_obj=validate_source(
            source,ns.expected_source_checkpoint_sha256,ns.expected_completed,ns.expected_last,
            stop_receipt=Path(ns.source_stop_receipt) if ns.source_stop_receipt else None,
            dynamic=bool(ns.dynamic_final_state))
        cfg_path=target/'PERF_NEXT_CONFIGURATION.json'
        if not cfg_path.is_file(): fail('TARGET_PERF_CONFIGURATION_MISSING')
        cfg=read(cfg_path)
        if cfg!={'schema':'MINOTAURO_PERF_NEXT_CONFIGURATION_V003','workers':15,'batch_rows':256}: fail('TARGET_PERF_CONFIGURATION_MISMATCH')
        if not (target/'GATES'/'CORRECTNESS_SYNTHETIC_RECEIPT.json').is_file(): fail('TARGET_SYNTHETIC_RECEIPT_MISSING')
        if not (target/'GATES'/'CORRECTNESS_PILOT_RECONCILIATION.json').is_file(): fail('TARGET_PILOT_RECONCILIATION_MISSING')
        if not (target/'GATES'/'CORRECTNESS_FULL_AUTHORIZATION.json').is_file(): fail('TARGET_FULL_AUTHORIZATION_MISSING')
        sb,tb=compare_bindings(source,target)
        copy_sessions_atomic(source,target,completed)
        manifest_path,file_count=build_import_manifest(source,target,completed)
        cp,identity,cp_path,source_anchor=rebuild_candidate_checkpoint(source_cp,target,tb,completed)
        seals=write_seals(target,completed)
        from r1r11_coordinator import Runtime
        class Dummy: pass
        dummy=Dummy(); dummy.telemetry=target/'TELEMETRY'/'R1R11_TRANSPORT.jsonl'
        Runtime.verify_committed(dummy,target/'PHASE_A',cp)
        from minotauro_v005r1_r23_contract import write_json_atomic_canonical
        receipt={
            'schema':'MINOTAURO_COMMITTED_MIGRATION_RECEIPT_V003',
            'status':'PASS','source_root':str(source),'target_root':str(target),
            'binding_mode':'DYNAMIC_FINAL_STATE' if ns.dynamic_final_state else 'STATIC_EXPECTED_STATE',
            'source_checkpoint_sha256':source_cp_sha,
            'source_runner_sha256':source_cp.get('runner_sha256'),
            'source_stop_receipt':str(Path(ns.source_stop_receipt).resolve()) if ns.source_stop_receipt else None,
            'source_stop_receipt_sha256':sha(Path(ns.source_stop_receipt)) if ns.source_stop_receipt else None,
            'target_checkpoint_sha256':sha(cp_path),'target_runner_sha256':identity.get('runner_sha256'),
            'candidate_package_manifest_sha256':pkg_hash,
            'completed_sessions':len(completed),'last_committed_session':completed[-1] if completed else None,
            'first_pending_session':source_anchor.get('session') if source_anchor else None,
            'source_resume_offset':source_anchor.get('offset') if source_anchor else None,
            'source_resume_fingerprint':source_anchor.get('fingerprint') if source_anchor else None,
            'imported_file_count':file_count,'import_manifest_sha256':sha(manifest_path),
            'source_binding_semantic_match':'YES','session_byte_identity':'PASS',
            'session_seals_rebuilt_for_target_root':'YES','old_root_mutated':'NO',
            'uncommitted_source_scratch_imported':'NO',
        }
        rp=target/'GATES'/'COMMITTED_MIGRATION_RECEIPT.json'; write_json_atomic_canonical(rp,receipt)
        print('COMMITTED_MIGRATION=PASS',flush=True)
        print(f'IMPORTED_SESSIONS={len(completed)}',flush=True)
        print(f'LAST_COMMITTED_SESSION={completed[-1] if completed else "NONE"}',flush=True)
        print(f'FIRST_PENDING_SESSION={receipt["first_pending_session"] or "NONE"}',flush=True)
        print(f'SOURCE_RESUME_OFFSET={receipt["source_resume_offset"] if receipt["source_resume_offset"] is not None else "NONE"}',flush=True)
        print(f'TARGET_CHECKPOINT_SHA256={sha(cp_path)}',flush=True)
        print(f'MIGRATION_RECEIPT={rp}',flush=True)
    except Exception as exc:
        print('COMMITTED_MIGRATION=BLOCKED',flush=True)
        print(f'ERROR={type(exc).__name__}:{exc}',flush=True)
        traceback.print_exc()
        raise SystemExit(2)
if __name__=='__main__': main()
