from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

import r1r11_worker as worker
import r1r11_v5_stream as stream

ROOT = Path(__file__).resolve().parent
FROZEN = {
    'minotauro_v004_core.py': '97F8F957300D37966913C872B7F04E498D30B0CFF68180993DB80D314B900827',
    'minotauro_v004_io.py': 'DC816C617AA6586828CEC769B21741D5BC4106FA8A72B933F1BE76D4E1BCAF4F',
    'minotauro_v004_metrics.py': '8CE1292F5E0580E98DCB3743350416C0C559F6C6189305250371F2E05D22970F',
    'minotauro_v004_preflight.py': '3A2398FD86F93C1EBD8AF5C1BD64D4BC839185AC26FABA775C8152FD29750390',
}
BASELINE_ZIP_SHA = '207531E97C9818D00E0D61B0379A8D94A13AD5CEB8FF9450EAE466A8C2DBB064'
BASELINE_MANIFEST_SHA = 'D5B62B0FCA549174A2733608B35FA08DFE852EB755E9B0AC3C1313DBB3A731C4'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


class DummyEngine:
    def __init__(self, trades, pos_open, pos_trade_index):
        self.trades = trades
        self.pos_open = np.asarray(pos_open, dtype=bool)
        self.pos_trade_index = np.asarray(pos_trade_index, dtype=np.int64)


class PerfNextTests(unittest.TestCase):
    def test_01_baseline_identity_recorded(self):
        rec = json.loads((ROOT/'PERF_NEXT_BASELINE_HASHES.json').read_text(encoding='utf-8'))
        self.assertEqual(rec['source_zip_sha256'], BASELINE_ZIP_SHA)
        self.assertEqual(rec['source_manifest_sha256'], BASELINE_MANIFEST_SHA)
        self.assertEqual(rec['source_manifest_members'], 439)

    def test_02_economic_frozen_bytes_unchanged(self):
        for name, expected in FROZEN.items():
            self.assertEqual(sha(ROOT/name), expected, name)

    def test_03_incremental_order_validates_only_suffix(self):
        idx = {'A': 0, 'B': 1}
        eng = DummyEngine([
            {'entry_ordinal': 10, 'cell_id': 'A'},
            {'entry_ordinal': 10, 'cell_id': 'B'},
        ], [], [])
        state = {'validated': 0, 'last_key': None}
        worker._validate_trade_order_incremental(eng, idx, state)
        self.assertEqual(state['validated'], 2)
        self.assertEqual(state['last_key'], (10, 1))
        eng.trades.append({'entry_ordinal': 11, 'cell_id': 'A'})
        worker._validate_trade_order_incremental(eng, idx, state)
        self.assertEqual(state['validated'], 3)
        # A newly appended regression must still fail closed.
        eng.trades.append({'entry_ordinal': 9, 'cell_id': 'A'})
        with self.assertRaisesRegex(Exception, 'V5_TRADE_LIST_ORDER'):
            worker._validate_trade_order_incremental(eng, idx, state)

    def test_04_open_floor_matches_historical_full_scan(self):
        idx = {'A': 0, 'B': 1, 'C': 2}
        a = DummyEngine([
            {'entry_ordinal': 3, 'cell_id': 'A', 'exit_reason': 'TP'},
            {'entry_ordinal': 9, 'cell_id': 'B'},
        ], [False, True], [-1, 1])
        b = DummyEngine([
            {'entry_ordinal': 5, 'cell_id': 'C'},
        ], [True], [0])
        engines = {'a': a, 'b': b}
        expected = (100, -1)
        for eng in engines.values():
            for tr in eng.trades:
                if 'exit_reason' not in tr:
                    expected = min(expected, (int(tr['entry_ordinal']), idx[tr['cell_id']]))
        self.assertEqual(worker._min_open_trade_key(engines, idx, 99), expected)

    def test_05_subset_finality_recheck_tracks_cutoff_or_final_suffix(self):
        rows = [
            {'cell_id':'P382_T1_N1_NONE','entry_ordinal':1,'x':1},
            {'cell_id':'P382_T1_N1_NONE','entry_ordinal':2,'x':2},
            {'cell_id':'P382_T1_N1_NONE','entry_ordinal':3,'x':3},
        ]
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)/'run'/'session'/'group'/'trades.jsonl'
            sink = stream.V5ScratchSink(p, 'trades', [])
            try:
                sink.trade_line_sha256 = [hashlib.sha256(stream._canonical_line(r)[:-1]).hexdigest() for r in rows]
                sink.recheck_final_trade_indices(rows, [1,2])
                mutated = [dict(r) for r in rows]; mutated[1]['x'] = 99
                with self.assertRaisesRegex(Exception, 'V5_TRADE_FINALITY_RECHECK_MISMATCH'):
                    sink.recheck_final_trade_indices(mutated, [1,2])
                with self.assertRaisesRegex(Exception, 'V5_TRADE_FINALITY_RECHECK_CARDINALITY'):
                    sink.recheck_final_trade_indices(rows[:2], [1])
            finally:
                sink.close()

    def test_06_worker_cutoff_write_set_does_not_touch_trade_key(self):
        tree = ast.parse((ROOT/'r1r11_worker.py').read_text(encoding='utf-8'))
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_enrich_cutoff_trade')
        assigned = set()
        for n in ast.walk(fn):
            if isinstance(n, ast.Assign):
                for t in n.targets:
                    if isinstance(t, ast.Subscript) and isinstance(t.value, ast.Name) and t.value.id == 'tr':
                        sl = t.slice
                        if isinstance(sl, ast.Constant) and isinstance(sl.value, str):
                            assigned.add(sl.value)
        self.assertEqual(assigned, {'first_cutoff_bid_msc','first_cutoff_ask_msc'})
        self.assertTrue({'entry_ordinal','cell_id'}.isdisjoint(assigned))

    def test_07_verifier_is_digest_only_not_second_physical_gzip(self):
        src = (ROOT/'r1r11_v5_stream.py').read_text(encoding='utf-8')
        self.assertIn('if role == "writer":\n            writer = _CanonicalGzip', src)
        self.assertIn('canonical_sha256', src)
        self.assertIn('v.get("file") is not None', src)
        self.assertNotIn('verifier_cleanup_paths', src)

    def test_08_batch_matrix_is_explicit_and_v002_default_is_256(self):
        src = (ROOT/'r1r11_coordinator.py').read_text(encoding='utf-8')
        self.assertIn('if batch_rows not in (32,64,128,256):', src)
        self.assertIn('batch_rows=256', src)

    def test_09_future_controller_cannot_target_current_full(self):
        src = (ROOT/'r1r11_perf_next_controller.py').read_text(encoding='utf-8')
        self.assertIn("MINOTAURO_R1R11_PERF_NEXT_V003R3_W15_B256_20260929", src)
        self.assertIn("CURRENT_FULL_ACTIVE_INTERFERENCE_FORBIDDEN", src)
        self.assertIn("PERF_NEXT_OUT_MUST_NOT_EQUAL_CURRENT_FULL_ROOT", src)
        self.assertIn("PERF_NEXT_CONFIGURATION_MISMATCH_NEW_ROOT_REQUIRED", src)


if __name__ == '__main__':
    unittest.main(verbosity=2)
