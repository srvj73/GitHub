# CONFIRMAÇÃO FINAL OPUS 5.5 — TRACK A — V005R1-R2.2

**Pacote:** `HANDOFF_CONFIRMACAO_FINAL_TRACK_A_MINOTAURO_V005R1_R2_2_20260925`. `SHA256SUMS` 9/9 OK. R2.2 = `CB7F4C8C…DDAD1`. A auditoria-fonte `03_…` é byte-idêntica à minha entrega `16_…` (`BF593A9B…`).
**Regime:** documental, independente, adversarial, fail-closed. A V002R2 não foi reaberta. Nenhum código escrito, nenhum dado processado.
**Delta R2.1 → R2.2 conferido por `diff`:** só três mudanças — §3.7 nova, §4 com a serialização de `GRID_CELLS.csv` e §5.1.B com a regra de extremos — além de rótulos. Nenhuma regra econômica foi alterada.

```text
OPUS55_V005R1R22_FINAL_ONE_PARAGRAPH_CONFIRMATION=PASS_WITH_BLOCKERS
R21_M1_USE_TIME_BINDING_CLOSED=NO
R21_M1_FALSE_PASS_REMAINING=2
R21_m1_EXTREMA_DETERMINISM_CLOSED=YES
R21_m2_GRID_SERIALIZATION_CLOSED=YES
HEAVY_55_3_GIB_PREFLIGHT_RERUN_REQUIRED=NO
CRITICAL_FINDINGS=0
MAJOR_FINDINGS=1
MINOR_FINDINGS=2
R1R4_PATCH_IMPLEMENTATION_AUTHORIZED=NO
RUN_A_AUTHORIZED=NO
DATA_PROCESSING_AUTHORIZED=NO
```

**Confirmado:**
- **R21-m1:** curva completa, desigualdade estrita e atualização causal após cada subevento, com a mesma regra em B00. É determinístico e continua sem perda para o max DD.
- **R21-m2:** a serialização de `GRID_CELLS.csv` está integralmente fixada, e o `grid_sha256` é reproduzível.
- **Preflight pesado:** continua desnecessário. A §3.7(b) usa a leitura econômica que já existe.
- **§3.7:** fecha o drift de ticks em execução clean e o drift de módulos em qualquer execução. Restam os dois caminhos abaixo, ambos resíduos do próprio texto que propus para R21-M1.

## Falsos-pass remanescentes

**FP-1 (MAJOR) — Mês com todas as sessões commitadas, mas sem hash de fim de arquivo verificado.**
- A §3.7(c) só obriga a reler meses "parcialmente processados".
- O R1R4 considera um mês concluído quando todas as suas sessões estão commitadas e, no resume, o pula (`MONTH_SKIP_ALL_COMMITTED`, runner l.141-142).
- A última sessão do mês é commitada logo após o cutoff, mas a leitura segue até o fim do arquivo. Um Ctrl+C ou uma falha nesse intervalo — por exemplo, logo depois da mensagem `SESSION_COMMIT` do último pregão — deixa o mês sem hash de fim de arquivo gravado. No resume, esse mês nunca é verificado.

**FP-2 (MINOR) — Artefatos congelados lidos pelo runner sem conferência na execução clean.**
- O `run-a` lê `SESSION_CALENDAR_PHASE_A.csv` (sessões, caminhos, `cutoff_msc`, predecessor), `PHASE_STATUS.json` e o extrato D1 (runner l.109-114; R2.2 §3.5).
- A §3.7(a) confere apenas os módulos. Em uma execução clean, um artefato alterado depois do rebind seria usado e gravado no checkpoint e no freeze com o hash novo, sem nada que o compare ao binding.

**Correção textual mínima (substituir as alíneas (a) e (c) da §3.7):**
> *(a) No início de toda execução, clean ou resume, o runner recalcula os SHA256 de `minotauro_v004_preflight.py`, `minotauro_v004_io.py`, `CORE_IMPORTED_DEFINITIONS`, `SESSION_CALENDAR_PHASE_A.csv`, `PHASE_STATUS.json` e `D1_PREDECESSOR_EXTRACT_PHASE_A.csv` e exige igualdade com `RUN_SOURCE_BINDING_A.json`. Divergência ⇒ `RUN_BLOCKED_BINDING_MISMATCH`; nenhuma sessão é processada.*
>
> *(c) Um arquivo mensal só é considerado verificado quando o SHA256 de fim de arquivo da alínea (b) foi comparado e gravado no checkpoint. Em resume, todo mês sem esse registro é relido integralmente e verificado conforme (b), ainda que todas as suas sessões já estejam commitadas.*

**Não bloqueante (sem falso-pass):** referências internas desatualizadas.
- §5.3 cita "piloto da §7.3"; o piloto está na §6.3, e é o único piloto definido, então a referência se resolve sem ambiguidade.
- §0 e §8 ainda trazem os rótulos "R2.1".

Corrigir junto, sem efeito normativo.

Com essas duas alíneas incorporadas literalmente, não resta outro ponto aberto no TRACK A. A confirmação seguinte é mecânica: conferir apenas o diff dessas duas alíneas.
