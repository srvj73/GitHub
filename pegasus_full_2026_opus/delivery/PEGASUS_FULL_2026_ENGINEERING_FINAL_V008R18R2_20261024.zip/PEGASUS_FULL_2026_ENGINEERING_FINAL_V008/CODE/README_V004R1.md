# R1R11 V004R1 — implementação exclusivamente sintética

EVIDENCE: implementação e validações pontuais concluídas. **G4 NÃO EXECUTADO;
G1–G11 owner NÃO EXECUTADOS; ganho de 1,5x NÃO COMPROVADO.**

DECISION: SPEC V004 é a autoridade vigente desta cópia. Core, IO, metrics,
preflight, SPEC econômica, oracle e função gzjson foram preservados.
Nenhum mercado real, Pilot A operacional ou Run-A foi executado.

Consulte R1R11_INTERNAL_GATE_REPORT.md, CHANGELOG_R1R11.md,
IMPLEMENTATION_RECEIPT_R1R11.json e EVIDENCE_V004R1. Os diretórios HISTORY,
AUTHORITY anteriores e DIAGNOSTICS_V003R2 são evidência histórica, sem promoção.

## Próximo passo elegível — execução posterior pelo owner

Este launcher está preparado; não foi executado pelo Codex nesta entrega.
Usar PowerShell 5.1 e Python owner validado, com EvidenceRoot NOVO, externo
ao pacote. Não reutilizar nenhuma árvore V003 ou de profiling.

```powershell
& .\RUN_R1R11_OWNER_GATES.ps1 -Python 'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe' -EvidenceRoot 'D:\MinotauroRuns\MINOTAURO_R1R11_V004R1_OWNER_GATES_NEW'
```

O caminho de saída acima é uma proposta para uma nova árvore, não evidência
de diretório existente. O launcher recusa evidência preexistente sem preregistro
compatível. Manifesto do pacote é verificado antes dos gates.

G1 vincula SPEC/hash do pacote/inputs e todos os parâmetros operacionais.
G3 executa os checks V4-A..H e negativos antes de G4. G4 mantém o par
oracle/candidato, heavy_cycles=1200, quatro workers e threshold=1,5.
Se G4 falhar, G5–G11 não avançam e a tentativa V004R1 termina, sem tuning.
Uma retomada de gate FAIL é recusada pelo runner.

Qualquer dado real continua proibido. Os comandos rebind-a/pilot-a/run-a
do entrypoint candidato saem com código 2 antes de ler config. Mesmo um futuro
PASS owner exige a auditoria independente final e autorização própria de piloto.

## Observações dos testes

As validações locais usaram Python bundled 3.12.14. Isso não certifica o runtime
owner 3.14.7 nem sua performance. O teste de integração herdado usa a string
PILOT_A internamente, com _SyntheticPhase/fake_prepare e 21 registros artificiais
em diretório temporário; seus logs não representam um Pilot A operacional.

Interrupções preservam estado anterior. Em recovery, o journal é reconciliado
antes de qualquer purga de scratch; a purga histórica provoca exit 2 explícito
e exige uma segunda invocação de resume. Não equivale a fallback serial.
