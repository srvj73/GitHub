# SPEC — MINOTAURO PERF NEXT V003 — FAST RESUME / BOUNDED TELEMETRY / PROVED SAFE_STOP

STATUS=DEVELOPMENT_CANDIDATE_NOT_OPERATIONALLY_RELEASED
BASE_OPERATIONAL_PACKAGE_SHA256=11347EB450B41C5BF3129DD96548D1EDD0A23CA2C156318638364F74E2619DDE
DEVELOPMENT_WHILE_ORIGINAL_FULL_RUNS=AUTHORIZED
ORIGINAL_FULL_MUTATION_DURING_DEVELOPMENT=FORBIDDEN
CUTOVER_ONLY_AFTER_SUCCESSOR_QUALIFICATION=YES

## 1. Objetivo

Evoluir o candidato de performance W15/B256 sem alterar economia, C1/cutoff, geometria,
ordem causal, bytes econômicos canônicos ou publisher. O novo delta fecha recovery,
resume físico e observabilidade para permitir cortar do FULL antigo para o sucessor sem
esperar o histórico original terminar.

## 2. Contrato obrigatório solicitado

```text
CHECKPOINT_GRANULARITY=1_PREGÃO
MAX_RECOMPUTE_AFTER_FAILURE=1_PREGÃO
SOURCE_RESUME_OFFSET=POR_PREGÃO
TELEMETRY=BOUNDED
PID_OWNERSHIP=PID+CREATION_TIME
SAFE_STOP=PROVADO_APÓS_TREE_CLEAN
```

Complementos de enforcement:

```text
ORPHAN_RECONCILIATION=BEFORE_RESUME
DYNAMIC_CUTOVER_BINDING=POST_SAFE_STOP_FINAL_CHECKPOINT
HARD_CODED_SOURCE_COMMITTED_COUNT=FORBIDDEN
COMMITTED_SESSION_RECOMPUTE=FORBIDDEN
FIRST_PENDING_SESSION=DERIVED_FROM_FINAL_CHECKPOINT
```

## 3. Checkpoint e recompute

A unidade econômica atômica continua sendo um pregão. A sequência permanece:
`PROCESS -> STAGE -> VALIDATE -> ATOMIC SESSION COMMIT -> CHECKPOINT`.

Antes de iniciar economicamente um pregão, o checkpoint recebe `source_resume` com:
- session_date;
- offset físico no CSV mensal no início daquele pregão;
- fingerprint físico da fonte.

Uma falha durante o pregão pode exigir recomputar aquele pregão; pregão já COMMITTED
não é economicamente recalculado. Se a falha ocorrer depois do commit e antes de gravar
o anchor seguinte, o anchor anterior pode causar no máximo a releitura física do último
pregão COMMITTED, que é filtrado economicamente.

## 4. SOURCE_RESUME_OFFSET=POR_PREGÃO

O parser econômico retomado usa `seek(offset)` no início do pregão. Para preservar a
semântica canônica de `tick_prefix_sha256` e o SHA mensal, o estado SHA-256 anterior ao
offset é reconstruído por leitura binária/hash-only do prefixo físico, sem parse econômico.

```text
SOURCE_PREFIX_REHYDRATION=HASH_ONLY_NO_ECONOMIC_PARSE
SOURCE_ECONOMIC_PARSE_BEFORE_ANCHOR=NO
SOURCE_PREFIX_DISK_IO_BEFORE_ANCHOR=MAY_OCCUR
```

Portanto V003 não promete zero I/O histórico: promete eliminar o parse econômico dos
pregões anteriores ao anchor e retomar a computação econômica na fronteira do pregão.

O `minotauro_v004_io.py` congelado permanece byte-identical à baseline; o seek-resume
fica em módulo novo e delega parsing de campos às funções canônicas do parser congelado.

## 5. Binding dinâmico no cutover

Durante desenvolvimento, o FULL antigo pode continuar avançando. O sucessor não é
amarrado a 55, 56, 61 ou qualquer cardinalidade observada durante desenvolvimento.

Após o sucessor ficar pronto:
1. SAFE_STOP cooperativo do FULL antigo;
2. receipt comprova árvore limpa, RUN.lock ausente e journal vazio;
3. importador lê o checkpoint físico final naquele instante;
4. valida exact session set e hashes dos arquivos de cada pregão COMMITTED;
5. copia somente COMMITTED para nova raiz;
6. reconstrói seals/checkpoint sob a identidade V003;
7. grava anchor do primeiro pregão pendente;
8. FULL V003 somente inicia se a fonte continuar byte/state-identical ao receipt.

## 6. TELEMETRY=BOUNDED

Logs JSONL de telemetria usam rotação bounded. Contrato inicial do candidato:
- active file <= 64 MiB antes da próxima rotação;
- até 4 arquivos históricos rotacionados;
- escrita de boundary crítico pode ser durable/fsync;
- rotação não altera checkpoint/economia.

A telemetria de progresso global usa COMMITTED/TOTAL como PCT. SOURCE_PCT é rotulado
separadamente e nunca é apresentado como conclusão global.

## 7. PID_OWNERSHIP e órfãos

Todo processo filho produtivo/auxiliar é vinculado por `(PID, creation_time)`.
Workers econômicos e stream writer/verifier possuem registry persistido em scratch.
Antes de resume, PID vivo com identidade divergente, registry legado sem creation_time,
processo próprio vivo ou falha de probe de identidade bloqueia fail-closed.

## 8. SAFE_STOP

Primeiro Ctrl+C:
- marca `SAFE_STOP_REQUESTED`;
- envia STOP cooperativo;
- não usa terminate no caminho cooperativo;
- espera workers e stream helpers até deadline;
- reconcilia handles/shared-memory/scratch;
- prova todas as identidades owned encerradas;
- somente então a superfície externa pode emitir `SAFE_STOP=YES` / exit 130.

Se algum filho não fechar cooperativamente no deadline, o run bloqueia/falha; não há
segundo sinal nem kill automático implícito.

## 9. Performance preservada

```text
REQUESTED_WORKERS_DEFAULT=15
BATCH_ROWS_DEFAULT=256
WORK_GROUPS=15
SHARED_SLOTS=1
RAM_TARGET_PERCENT=60
HARD_CAP_MIB=48528
```

Não são introduzidos multi-slot, feed-ahead especulativo, mudança econômica ou mudança
do cutoff/C1.

## 10. Qualificação enquanto original roda

Enquanto o FULL antigo estiver ACTIVE, somente qualificação sintética/estática em raiz
isolada é admitida. Pilot real, rebind de fonte, import, FULL e cutover bloqueiam.

```text
ORIGINAL_FULL_ACTIVE + QUALIFY_SYNTHETIC=ALLOWED_ISOLATED
ORIGINAL_FULL_ACTIVE + REAL_SOURCE_PILOT/IMPORT/FULL=BLOCKED
```

## 11. Status de release

Este documento descreve um candidato de desenvolvimento. Nenhum PASS em Linux/sandbox
substitui PowerShell 5.1/Windows target qualification. Antes de uso operacional são
obrigatórios parse/probes no alvo, testes de recovery, byte equality, C1 parity e cutover
DRY_RUN contra a árvore real já SAFE_STOPPED.
