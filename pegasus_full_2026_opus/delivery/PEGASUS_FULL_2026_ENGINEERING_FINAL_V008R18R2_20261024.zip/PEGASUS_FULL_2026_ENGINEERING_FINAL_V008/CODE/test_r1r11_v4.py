"""V4-A..H synthetic development tests. Evidence is retained outside package.

Set R1R11_V4_TEST_ROOT to a NEW directory. Does not run G4 or owner G1-G11.
"""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest
from unittest.mock import patch

PACKAGE=Path(__file__).resolve().parent


def tree(root):
    files=[p for p in (root/'sessions').rglob('*') if p.is_file()]+[root/'CHECKPOINT.json']
    return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}


class V004(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from r1r11_fixtures import generate
        cls.root=Path(os.environ['R1R11_V4_TEST_ROOT']).resolve()
        if cls.root.is_relative_to(PACKAGE):raise RuntimeError('TEST_OUTPUT_OUTSIDE_PACKAGE_REQUIRED')
        cls.root.mkdir(exist_ok=False);cls.commands=[]
        generate(cls.root/'inputs')
        cls.invoke('oracle',role='oracle')
        cls.invoke('clean')
        cls.expected=tree(cls.root/'oracle')
        if cls.expected!=tree(cls.root/'clean'):raise AssertionError('V4_INITIAL_DIFFERENTIAL')

    @classmethod
    def invoke(cls,name,role='candidate',workers=2,fault=None,scenario='pending_cancel',expected=0):
        args=[sys.executable,'-X','utf8','-B',str(PACKAGE/'r1r11_fixtures.py'),
            '--inputs',str(cls.root/'inputs'),'--out',str(cls.root/name),'--role',role,
            '--workers',str(workers),'--only',scenario]
        if fault:args+=['--fault',json.dumps(fault)]
        idx=len(cls.commands);log=cls.root/f'{idx:03d}_{name}.log';start=time.perf_counter()
        with log.open('x',encoding='utf-8') as f:
            result=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1'})
        cls.commands.append({'command':args,'log':str(log),'exit_code':result.returncode,'seconds':time.perf_counter()-start})
        (cls.root/'COMMANDS.json').write_text(json.dumps(cls.commands,indent=2),encoding='utf-8')
        text=log.read_text(encoding='utf-8')
        if expected is not None and result.returncode!=expected:
            raise AssertionError(f'{name}: expected {expected}, got {result.returncode}\n{text}')
        return result.returncode,text

    def test_v4_a_final_trades_no_pipe_payload(self):
        source=(PACKAGE/'r1r11_worker.py').read_text()
        self.assertIn('result.trades=[]',source)
        rows=[json.loads(l) for l in (self.root/'clean/TELEMETRY/R1R11_TRANSPORT.jsonl').read_text().splitlines()]
        stages=[r for r in rows if r['event']=='STAGE_VALIDATED']
        self.assertTrue(stages)
        for row in stages:
            self.assertEqual(set(row['manifests']),{'trades','events','equity','equity_reconciliation'})
            receipt=json.loads((self.root/'clean/sessions'/row['session']/'session_receipt.json').read_text())
            self.assertEqual(receipt['trades'],row['manifests']['trades']['proof']['rows'])
        self.invoke('oracle_final_trades',role='oracle',scenario='deferred')
        code,text=self.invoke('final_trade_scratch',scenario='deferred',
                             fault={'point':'before_journal','kind':'stop'},expected=None)
        self.assertEqual(code,2,text)
        from minotauro_v004_core import valid_cells
        from r1r11_v4_stage import enrich
        paths=list((self.root/'final_trade_scratch/_scratch').glob('*/*/0_0/trades.jsonl.gz'))
        self.assertEqual(len(paths),1)
        session=paths[0].parent.parent;date=session.name
        receipt=json.loads((self.root/'oracle_final_trades/sessions'/date/'session_receipt.json').read_text())
        actual=[]
        for p in session.glob('*/trades.jsonl.gz'):
            with gzip.open(p,'rt') as f:
                actual.extend(enrich(json.loads(l),receipt['cutoff_diagnostics_preflight']) for l in f)
        index={c.cell_id:i for i,c in enumerate(valid_cells())}
        actual.sort(key=lambda r:(r['entry_ordinal'],index[r['cell_id']]))
        with gzip.open(self.root/'oracle_final_trades/sessions'/date/'trades.jsonl.gz','rt') as f:
            expected=[json.loads(l) for l in f]
        self.assertTrue(actual,'Trade finality requires a nonempty trade fixture')
        self.assertEqual(actual,expected)
        self.assertTrue(all(r.get('exit_reason') for r in actual))

    def test_v4_b_sidecar_bijection(self):
        from r1r11_v4_custody import ScratchSink,checked_rows,seal_file
        from minotauro_v004_core import valid_cells,ModelError
        cells=valid_cells()
        for fault in ('missing','duplicate','reordered','offset','line_sha'):
            sink=ScratchSink(self.root/f'sidecar_{fault}/1_1/2000-01-01/0_0/events.gz','events',cells)
            for ordinal in (1,2):sink.append({'event':'ENTRY','ordinal':ordinal,'cell_ids':[cells[0].cell_id]})
            sink.close();m=sink.manifest()
            with gzip.open(sink.side_path,'rb') as f:lines=f.readlines()
            if fault=='missing':lines.pop()
            elif fault=='duplicate':lines.append(lines[-1])
            elif fault=='reordered':lines.reverse()
            else:
                row=json.loads(lines[0]);row['uncompressed_offset_start' if fault=='offset' else 'line_sha256']=123
                lines[0]=json.dumps(row).encode()+b'\n'
            with gzip.open(sink.side_path,'wb') as f:f.writelines(lines)
            # Re-seal physical bytes to exercise bijection, not merely outer hash.
            m['sidecar']=seal_file(sink.side_path)
            with self.assertRaisesRegex(ModelError,'SIDECAR'):
                list(checked_rows(m,'events',sink.index,sink.rank))

    def test_v4_c_c1_unknown_and_global_merge(self):
        from minotauro_v004_core import ModelError,valid_cells
        from r1r11_transport import merge_key
        cells=valid_cells();index={c.cell_id:i for i,c in enumerate(cells)}
        with self.assertRaisesRegex(ModelError,'UNKNOWN_EVENT'):
            merge_key('events',{'event':'UNKNOWN','ordinal':1,'cell_ids':[cells[0].cell_id]},index,index)
        self.assertEqual(tree(self.root/'clean'),self.expected)
        # Differential has cutoff globals emitted in all 15 groups.
        events=[json.loads(l) for f in (self.root/'clean/sessions').glob('*/events.jsonl.gz') for l in gzip.open(f,'rt')]
        self.assertTrue(any(r['event']=='CUTOFF_LATCH' and len(r['cell_ids'])==435 for r in events))

    def test_v4_d_helper_write_isolation(self):
        code,text=self.invoke('isolation',fault={'point':'stage','kind':'canonical_write'},expected=None)
        self.assertEqual(code,2,text);self.assertIn('HELPER_WRITE_OUTSIDE_STAGE',text)
        self.assertFalse((self.root/'isolation/sessions/FORBIDDEN').exists())

    def test_v4_e_transaction_recovery(self):
        from r1r11_v4_transaction import FAULTS
        evidence=[]
        for point in FAULTS:
            name='recovery_'+point
            code,text=self.invoke(name,fault={'point':point,'kind':'stop'},expected=None)
            self.assertEqual(code,2,text);self.assertIn('FAULT_'+point.upper(),text)
            before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (self.root/name/'sessions').rglob('*') if p.is_file() and '.pending' not in str(p)}
            code,text=self.invoke(name,workers=3,expected=None)
            if code:
                self.assertIn('STALE_SCRATCH_PURGED_RESUME_REQUIRED',text)
                self.invoke(name,workers=3)
            self.assertEqual(tree(self.root/name),self.expected,point)
            self.assertTrue(all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items()))
            evidence.append({'point':point,'fault_exit':2,'resume_workers':3,'byte_identical':True})
        (self.root/'V4_E.json').write_text(json.dumps(evidence,indent=2))

    def test_v4_f_toctou_and_helper_loss(self):
        faults=[('scratch_sealed',k) for k in ('append','sidecar','file_id','sha')]
        faults += [('stage_sealed',k) for k in ('truncate','file_id','sha')]
        faults += [('stage','helper_death'),('helper_before_probe','kill'),('staging_sigint','interrupt')]
        evidence=[]
        for i,(point,kind) in enumerate(faults):
            name=f'toctou_{i}'
            code,text=self.invoke(name,fault={'point':point,'kind':kind},expected=None)
            self.assertEqual(code,130 if point=='staging_sigint' else 2,text)
            cp=json.loads((self.root/name/'CHECKPOINT.json').read_text())
            self.assertEqual(cp['completed'],['1999-12-31'])
            self.assertEqual({p.name for p in (self.root/name/'sessions').iterdir()},{'1999-12-31'})
            evidence.append({'point':point,'kind':kind,'exit':code,'no_partial_promotion':True})
        (self.root/'V4_F.json').write_text(json.dumps(evidence,indent=2))
        self.native_stage_interruptions()

    def native_stage_interruptions(self):
        from r1r11_resources import process_snapshot
        evidence=[]
        for mode in ('native_ctrl_c','parent_death'):
            out=self.root/mode;log=self.root/(mode+'.log')
            args=[sys.executable,'-X','utf8','-B',str(PACKAGE/'r1r11_fixtures.py'),
                '--inputs',str(self.root/'inputs'),'--out',str(out),'--role','candidate',
                '--workers','2','--only','pending_cancel','--fault',
                json.dumps({'point':'stage','kind':'hold_for_signal'})]
            startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
            with log.open('x',encoding='utf-8') as f:
                proc=subprocess.Popen(args,stdout=f,stderr=subprocess.STDOUT,startupinfo=startup,
                    creationflags=subprocess.CREATE_NEW_CONSOLE,
                    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1'})
                try:
                    deadline=time.monotonic()+30
                    while (not list((out/'_scratch').rglob('HOLD_FOR_SIGNAL.marker')) or
                           len(list((out/'_scratch').rglob('*.helper.json')))!=4):
                        if proc.poll() is not None or time.monotonic()>deadline:
                            raise AssertionError('STAGE_SIGNAL_READY_NOT_OBSERVED')
                        time.sleep(.02)
                    pids=[json.loads(p.read_text())['pid'] for p in (out/'_scratch').rglob('*.helper.json')]
                    self.assertEqual(len(pids),4)
                    if mode=='native_ctrl_c':
                        signal_args=[sys.executable,'-B',str(PACKAGE/'r1r11_signal.py'),'--pid',str(proc.pid)]
                        sent=subprocess.run(signal_args,capture_output=True,text=True)
                        self.assertEqual(sent.returncode,0,sent.stderr)
                    else:proc.terminate()
                    code=proc.wait(timeout=15);self.assertNotEqual(code,0)
                    deadline=time.monotonic()+10
                    while set(pids)&{r['pid'] for r in process_snapshot()}:
                        if time.monotonic()>deadline:raise AssertionError('HELPER_SURVIVED_PARENT')
                        time.sleep(.02)
                    cp=json.loads((out/'CHECKPOINT.json').read_text())
                    self.assertEqual(cp['completed'],['1999-12-31'])
                    self.assertEqual({p.name for p in (out/'sessions').iterdir()},{'1999-12-31'})
                    evidence.append({'mode':mode,'command':args,'child_exit':code,'helper_pids':pids,
                        'helpers_exited':True,'no_promotion':True})
                finally:
                    if proc.poll() is None:proc.terminate();proc.wait(timeout=10)
        (self.root/'V4_F_NATIVE.json').write_text(json.dumps(evidence,indent=2))

    def test_v4_g_memory_and_orphan_registry(self):
        from r1r11_resources import RunLock,JobMemory
        from minotauro_v004_core import ModelError
        rows=[json.loads(l) for l in (self.root/'clean/TELEMETRY/memory.jsonl').read_text().splitlines()]
        peaks=[r['JOB_PEAK_BOUND_RUN'] for r in rows]
        self.assertEqual(peaks,sorted(peaks))
        self.assertTrue(any(r['event']=='HELPERS_SEALED_WAIT' and len(r['pids'])==5 for r in rows))
        for r in rows:
            bound=max(sum(p['private'] for p in r['pids']),sum(p['peak'] for p in r['pids']))+r['shared_memory_bytes']
            self.assertEqual(bound,r['JOB_PEAK_BOUND'])
        code,text=self.invoke('cap_helpers',fault={'point':'HELPERS_SEALED_WAIT','kind':'memory_cap'},expected=None)
        self.assertEqual(code,3,text)
        root=self.root/'orphan_registry';reg=root/'_scratch/123_456/2000-01-01/_canonical_stage/events.helper.json'
        reg.parent.mkdir(parents=True);reg.write_text(json.dumps({'pid':os.getpid(),'role':'stage_helper'}))
        with self.assertRaisesRegex(ModelError,'ORPHAN_WORKER_ACTIVE'):
            with RunLock(root):pass
        memory=JobMemory(self.root/'probe_failure.jsonl')
        from minotauro_v005r1_r1r10_memory import MemoryProbeError
        with patch('r1r11_resources.process_memory',side_effect=MemoryProbeError('TEST_PROBE_FAILURE')):
            with self.assertRaises(MemoryProbeError):memory.boundary('HELPERS_SEALED_WAIT')

    def test_v4_h_byte_differential_cutoff_and_s5(self):
        results=[]
        for scenario in ('deferred','target_passed','immediate_stop'):
            self.invoke('oracle_'+scenario,role='oracle',scenario=scenario)
            self.invoke('candidate_'+scenario,scenario=scenario)
            expected=tree(self.root/('oracle_'+scenario));actual=tree(self.root/('candidate_'+scenario))
            self.assertEqual(expected,actual,scenario)
            results.append({'scenario':scenario,'files':len(expected),'byte_identical':True})
        (self.root/'V4_H.json').write_text(json.dumps(results,indent=2))


if __name__=='__main__':unittest.main(verbosity=2)
