# PACKAGE INDEX — MINOTAURO V005R1 R1R9

## Governing / audit evidence
- `SPEC_V005R1_R2_3_APPROVED.md`
- `AUDIT_OPUS55_R1R8_OPERATIONAL_DIFF_REAUDIT_20260925.md`
- `OWNER_SMOKE_R1R8_TRANSCRIPT_PARTIAL_FAILURE_20260925.txt`

## Runtime delta R1R8 → R1R9
- `Minotauro_Launcher_Common.ps1`
- `minotauro_v005r1_r23_contract.py` — version only
- `config.example.json` — out_root only

All other runtime, test, economic and MQL5 files are byte-identical to R1R8.

## Build / comparison evidence
- `DIFF_R1R8_TO_R1R9.patch`
- `IMPLEMENTATION_RECEIPT_R1R9.json`
- `BUILD_SELFTEST_LOG_R1R9.txt`
- `CHANGELOG_R1R9.md`
- `SHA256SUMS.txt`
