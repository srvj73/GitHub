"""V003 operational binary transport and canonical streaming merge (stdlib)."""
from __future__ import annotations

import gzip
import hashlib
import heapq
import itertools
import json
import struct
import zlib
from pathlib import Path

from minotauro_v004_core import ModelError, TickRecord

RECORD = struct.Struct('<qqqqqddqII')
HEADER = struct.Struct('<8sqqIIII')
MAGIC = b'R1R11V03'
SLOT_BYTES = 4 * 1024 * 1024
EVENT_STAGE = {
    'CUTOFF_PENDING_CANCELLED': 10, 'CUTOFF_LATCH': 11,
    'CUTOFF_FILL_DEFERRED': 20, 'PENDING_REJECT': 40, 'ENTRY': 40,
    'TARGET_ALREADY_PASSED': 50, 'TRIGGER': 50, 'RR_REJECT': 50,
    'RMAX_REJECT': 50, 'ELIGIBLE': 50, 'ELIGIBLE_SKIPPED_BUSY': 51,
    'AMBIGUOUS_MULTI_SIGNAL': 51, 'PENDING_N': 51,
}
EQUITY_STAGE = {
    'CUTOFF_CLOSE_POST_REALIZATION': 20,
    'PREEXISTING_EXIT_POST_REALIZATION': 30,
    'ENTRY_OPEN_MARK': 40, 'IMMEDIATE_STOP_POST_REALIZATION': 40,
}
GLOBAL_EVENTS = frozenset(('CUTOFF_PENDING_CANCELLED', 'CUTOFF_LATCH', 'CUTOFF_FILL_DEFERRED'))


def encode_record(rec):
    dt, session = rec.date_time.encode('utf-8'), rec.session.encode('utf-8')
    return RECORD.pack(rec.ordinal, rec.time_msc, rec.bid_micro, rec.ask_micro,
                       rec.last_micro, rec.volume, rec.volume_real, rec.flags,
                       len(dt), len(session)) + dt + session


def decode_records(payload, count):
    offset = 0
    for _ in range(count):
        if len(payload) - offset < RECORD.size:
            raise ModelError('FEED_RECORD_TRUNCATED')
        o, m, b, a, last, v, vr, flags, nd, ns = RECORD.unpack_from(payload, offset)
        start = offset
        offset += RECORD.size
        if nd + ns > len(payload) - offset:
            raise ModelError('FEED_STRING_TRUNCATED')
        dt = payload[offset:offset+nd].decode('utf-8'); offset += nd
        session = payload[offset:offset+ns].decode('utf-8'); offset += ns
        rec = TickRecord(session, o, dt, m, b, a, last, v, vr, flags)
        raw = payload[start:offset]
        if encode_record(rec) != raw:
            raise ModelError('FEED_NONCANONICAL_ROUNDTRIP')
        yield rec, raw
    if offset != len(payload):
        raise ModelError('FEED_RECORD_COUNT_MISMATCH')


def write_slot(buf, session, seq, generation, records):
    encoded = [encode_record(rec) for rec in records]
    payload = b''.join(encoded)
    ses = session.encode('utf-8')
    data = HEADER.pack(MAGIC, seq, generation, len(records), len(payload),
                       zlib.crc32(payload), len(ses)) + ses + payload
    if len(data) > len(buf):
        raise ModelError('SHARED_SLOT_CAPACITY_EXCEEDED')
    buf[:len(data)] = data
    return encoded


def read_slot(buf, session, seq, generation):
    magic, actual_seq, actual_gen, count, size, crc, ns = HEADER.unpack_from(buf)
    end = HEADER.size + ns + size
    if (magic, actual_seq, actual_gen) != (MAGIC, seq, generation):
        raise ModelError('FEED_SEQUENCE_OR_GENERATION')
    if not count or count > 4096 or ns > 128 or end > len(buf):
        raise ModelError('FEED_INVALID_HEADER')
    if bytes(buf[HEADER.size:HEADER.size+ns]).decode('utf-8') != session:
        raise ModelError('FEED_SESSION_MISMATCH')
    payload = bytes(buf[HEADER.size+ns:end])
    if zlib.crc32(payload) != crc:
        raise ModelError('FEED_CRC_MISMATCH')
    return list(decode_records(payload, count))


def merge_key(kind, row, cell_index, group_rank):
    if kind == 'trades': return (int(row['entry_ordinal']), cell_index[row['cell_id']])
    if kind == 'equity_reconciliation': return (cell_index[row['cell_id']],)
    name = row['event']
    if kind == 'events':
        if name not in EVENT_STAGE:
            raise ModelError('UNKNOWN_EVENT '+str(name))
        ids = row['cell_ids']
        if not ids:
            raise ModelError('EMPTY_EVENT_CELLS')
        rank = group_rank[ids[0]]
        return (int(row['ordinal']), EVENT_STAGE[name], rank)
    if name == 'OPEN_MARK':
        stage = 21 if 'cutoff_pending' in row else 30
    elif name in EQUITY_STAGE:
        stage = EQUITY_STAGE[name]
    else:
        raise ModelError('UNKNOWN_EQUITY_EVENT '+str(name))
    return (int(row['ordinal']), stage, cell_index[row['cell_id']])


class ScratchSink:
    """Append-only compressed stream. Never contains a canonical publication path."""
    def __init__(self, path, kind, cells):
        self.path = Path(path)
        self.kind = kind
        self.index = {c.cell_id: i for i, c in enumerate(cells)}
        groups = sorted({(c.p_idx, c.t_idx) for c in cells})
        self.rank = {c.cell_id: groups.index((c.p_idx, c.t_idx)) for c in cells}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.stream = gzip.open(self.path, 'wt', encoding='utf-8', newline='\n', compresslevel=1)
        self.last_key = None
        self.count = 0
        self.encoder = json.JSONEncoder(ensure_ascii=False, separators=(',', ':'))

    def append(self, row):
        key = merge_key(self.kind, row, self.index, self.rank)
        if self.last_key is not None and key < self.last_key:
            raise ModelError('SCRATCH_ORDER_REGRESSION')
        self.last_key = key
        self.stream.write(self.encoder.encode(row)+'\n')
        self.count += 1

    def close(self):
        self.stream.close()


def read_scratch(path, kind, cell_index, group_rank):
    last = None
    decode = json.JSONDecoder().raw_decode
    with gzip.open(path, 'rt', encoding='utf-8') as stream:
        for line in stream:
            row, end = decode(line)
            if line[end:] != '\n' or not isinstance(row, dict):
                raise ModelError('SCRATCH_JSON_FRAME_INVALID')
            key = merge_key(kind, row, cell_index, group_rank)
            if last is not None and key < last:
                raise ModelError('SCRATCH_MERGE_ORDER_REGRESSION')
            last = key
            yield key, row


def merged_stream(paths, kind, cells, read_fn=read_scratch, yield_key=False):
    index = {c.cell_id: i for i, c in enumerate(cells)}
    groups = sorted({(c.p_idx, c.t_idx) for c in cells})
    ranks = {c.cell_id: groups.index((c.p_idx, c.t_idx)) for c in cells}
    streams = [read_fn(p, kind, index, ranks) for p in paths]
    merged = heapq.merge(*streams, key=lambda pair: pair[0])
    last = None
    # Identical ordinal/stage rows are bounded by the 435 cells. Only global
    # event rows are fused; ordinary rows are yielded individually, stably.
    try:
        for _, block in itertools.groupby(merged, key=lambda pair: pair[0][:2]):
            head = next(block)
            if kind == 'events' and head[1]['event'] in GLOBAL_EVENTS:
                rows = [head[1], *(row for key, row in block)]
                base = {k:v for k,v in rows[0].items() if k not in ('cell_ids','open_positions')}
                for row in rows:
                    if {k:v for k,v in row.items() if k not in ('cell_ids','open_positions')} != base:
                        raise ModelError('GLOBAL_EVENT_FIELDS_DIVERGE')
                ids = [cid for row in rows for cid in row['cell_ids']]
                if len(ids) != len(set(ids)):
                    raise ModelError('GLOBAL_EVENT_DUPLICATE_CELL')
                ids.sort(key=index.__getitem__)
                row = dict(rows[0]); row['cell_ids'] = ids
                if row['event'] == 'CUTOFF_LATCH':
                    row['open_positions'] = sum(r['open_positions'] for r in rows)
                output = [(head[0], row)]
            else:
                output = itertools.chain((head,), block)
            for key, row in output:
                if last is not None and key[:2] < last:
                    raise ModelError('MERGED_STAGE_REGRESSION')
                last = key[:2]
                yield (key,row) if yield_key else row
    finally:
        for stream in streams:
            stream.close()
