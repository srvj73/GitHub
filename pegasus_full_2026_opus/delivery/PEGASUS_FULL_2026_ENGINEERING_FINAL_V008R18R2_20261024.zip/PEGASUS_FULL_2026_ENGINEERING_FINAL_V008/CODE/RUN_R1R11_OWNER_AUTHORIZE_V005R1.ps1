#requires -Version 5.1
[CmdletBinding()] param(
 [Parameter(Mandatory=$true)][ValidateSet('pilot-a','run-a')][string]$Mode,
 [Parameter(Mandatory=$true)][string]$Config,
 [Parameter(Mandatory=$true)][string]$ApprovalToken
)
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'POWERSHELL_5_1_REQUIRED' }
. (Join-Path $PSScriptRoot 'Minotauro_Launcher_Common.ps1'); $Python=Resolve-RealPython
Write-Host ('AMBIENTE=PowerShell R1R11_V005R1_OWNER_AUTH MODE=' + $Mode)
& $Python -X utf8 -B (Join-Path $PSScriptRoot 'r1r11_owner_authorize.py') $Mode --config ([IO.Path]::GetFullPath($Config)) --approve $ApprovalToken
exit $LASTEXITCODE
