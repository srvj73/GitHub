# R1R11 V003R2 — BLOCKED_G4

Melhoria parcial legítima, não homologada: 22,1679 → 18,8676 s na comparação diagnóstica; ganho 1,1749× sobre V003R1, mas somente 0,88075× o oracle. G4 exige 1,5× e permanece não atendido. Nenhum gate V003R2 foi promovido.

Leia primeiro `CAUSAL_PERFORMANCE_REPORT_V003R2.md`. O ZIP preserva o oracle, SPEC e evidências; os documentos ativos desta raiz prevalecem sobre os históricos em HISTORY_V003R1 e DEVELOPMENT_EVIDENCE.

Foram executados somente cinco testes pontuais e diagnósticos sintéticos. G1–G11 completos NÃO foram executados. Mercado, Pilot A e Run-A NÃO foram executados/autorizados. Sem alteração de heavy_cycles=1200, threshold, economia, causalidade ou gzjson do parent.

## Runner preparado, não recomendado como retentativa sem nova evidência

O comando abaixo é a interface exata para eventual decisão do owner de executar a homologação. Não foi executado pelo Codex. Ele usa uma árvore NOVA; jamais usar o EvidenceRoot V003R1 falho. O pacote não inclui config.json nem owner authorization.

```powershell
& 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -NoProfile -ExecutionPolicy Bypass -File 'D:\Teste Rede Neural MQL5\Pegasus\micro_transit\R1R11_V003R2_BUILD_20260926\candidate\RUN_R1R11_OWNER_GATES.ps1' -Python 'C:\Users\silvi\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -EvidenceRoot 'D:\MinotauroRuns\MINOTAURO_R1R11_V003R2_OWNER_GATES_20260926'
```

Executável a partir de PS C:\Users\silvi>. Se extrair o ZIP em outro local, ajustar apenas o launcher. Requer PowerShell 5.1 e as dependências herdadas do parent. Outputs dos gates devem ficar fora do pacote, que é selado pelo SHA256SUMS.txt.

G1 inclui `operational_parameters` com todos os parâmetros da revisão: batch fixture 32, default normal 256, slot único de 4 MiB, threads de commit 4, spawn por sessão, codecs, timeout, memória e timing completo. **Não houve tuning de batch.** G4 mantém quatro workers, overlap, 1200 ciclos e threshold 1,5. G5/G6/G7 continuam integrais; G11 inclui os testes novos de falha do commit concorrente.

O runner sai nonzero em FAIL, preserva receipts e exige revisão causal antes de retomar um gate falho. PASS exigiria todos os G1–G11 e ainda não autorizaria execução real. A evidência diagnóstica atual não recomenda repetir mecanicamente o mesmo G4. Próximo passo: revisão causal da arquitetura de fechamento, sem relaxar SPEC/gates.
