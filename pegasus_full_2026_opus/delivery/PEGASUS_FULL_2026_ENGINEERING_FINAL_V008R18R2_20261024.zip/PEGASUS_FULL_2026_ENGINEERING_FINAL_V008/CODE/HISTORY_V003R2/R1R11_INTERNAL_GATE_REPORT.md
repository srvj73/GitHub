# Relatório interno V003R2

R1R11_IMPLEMENTATION_STATUS=BLOCKED
BLOCKER=G4_THRESHOLD_NOT_MET_IN_SYNTHETIC_DIAGNOSTIC

EVIDENCE: 5 testes pontuais PASS em duas invocações (2 testes/4,264 s e 3 testes/5,613 s; ambos exit 0). Comparação sintética pareada dos três executores: árvore econômica/checkpoint byte-idênticos; candidato corrigido 18,8675672 s, baseline 22,1678577 s, oracle 16,6175579 s. Speedup 0,88074725, required 1,5. Sem promoção de gates.

G1–G11 V003R2=NOT_EXECUTED. G1/G2/G3 históricos do owner=PASS; G4 histórico=FAIL e preservado. Mesmo com ganho parcial legítimo de 17,49% em vazão, G4 permanece bloqueado. A análise completa, comandos, tempos sobrepostos/profiling e limitações estão em CAUSAL_PERFORMANCE_REPORT_V003R2.md e DIAGNOSTICS_V003R2.

SPEC/core/IO/metrics/preflight/oracle/gzjson/PrefixHashTracker preservados. Seq/generation/CRC, FEED_DIGEST, r_global, prefixos, merge, C5 e casos G5/G6/G7 não relaxados. REAL_DATA_PROCESSED=NO; PILOT_A_AUTHORIZED=NO; RUN_A_AUTHORIZED=NO. OWNER_G1_TO_G11_REQUIRED=YES antes de qualquer promoção futura, seguido de auditoria independente.

NEXT_ACTION=REVISÃO_CAUSAL_DO_FECHAMENTO; nenhuma retentativa automática ou autorização de mercado.
