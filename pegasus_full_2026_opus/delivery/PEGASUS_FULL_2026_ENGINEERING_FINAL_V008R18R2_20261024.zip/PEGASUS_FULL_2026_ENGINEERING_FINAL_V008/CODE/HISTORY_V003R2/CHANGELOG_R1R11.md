# V003R1 → V003R2

STATUS=BLOCKED_G4. Melhoria parcial demonstrada, insuficiente para 1,5×.

- Projeção rasa de resultados após FINISH elimina deepcopy recursivo redundante; Pipe preserva cópia/isolamento do transporte.
- Encoder de scratch reutilizado; decoder estrito exige objeto JSON+LF, sem conteúdo extra.
- Quatro streams gzjson independentes em threads do único coordinator; join antes de receipt/publicação/checkpoint, inclusive em falha. Função gzjson intacta.
- G1 preregistra todos os parâmetros operacionais; batch/slots/threshold/heavy_cycles não alterados.
- Testes pontuais de byte equivalence, frame inválido e fault/resume do commit; G5/G6/G7 mantidos.
- Identidade explícita R1R11_V003R2, novo manifest/ZIP. Oracle, SPEC e quatro módulos congelados inalterados.

Os hashes e receipts V003R1, inclusive FAIL original, são históricos preservados. Não há promoção G4/G1–G11 nesta revisão.
