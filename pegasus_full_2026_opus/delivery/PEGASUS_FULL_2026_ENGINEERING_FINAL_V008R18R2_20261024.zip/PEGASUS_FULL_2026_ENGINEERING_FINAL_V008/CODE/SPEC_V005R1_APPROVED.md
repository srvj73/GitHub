# SPEC — MINOTAURO_PARAMETER_MARKET_DISCOVERY_V005R1 — CUTOFF EXECUTION AMENDMENT R1

**Projeto:** PEGASUS MT5 / MINOTAURO  
**Estudo:** MINOTAURO_PARAMETER_MARKET_DISCOVERY  
**Versão:** V005R1  
**Data:** 2026-09-24  
**Status:** CUTOFF_REAUDIT_R1_REQUIRED  
**Parent documental:** V005, reauditoria Work/Astra = `PASS_WITH_BLOCKERS`; `V004_PREVIOUS_GATES_PRESERVED=YES`; blocker material M1 restrito à ambiguidade de timestamp próprio do BBO pós-cutoff; quatro minors documentais m1–m4  
**Objetivo:** preservar integralmente a metodologia econômica V004 e a correção conceitual V005, fechando exclusivamente os achados M1/m1–m4 da reauditoria V005: exigir timestamp próprio pós-cutoff para o lado usado no fill, definir `CUTOFF_CLOSE_POST_REALIZATION`, explicitar equity/HWM enquanto `CUTOFF_CLOSE_PENDING`, tornar a telemetria de latência obrigatória sem criar gate econômico e impedir busca além da própria `session_date`. Seleção continua usando apenas 2025; confirmação retrospectiva usa 2026-01..08; 2026-09-01..11 permanece descritivo. Nenhuma etapa desta V005R1 é OOS virgem ou autorização de dinheiro real.

---

## 0. PAPÉIS E GATES

### 0.1 Work / Astra
Somente auditoria metodológica independente. Não escreve código, não cria runner, não executa dados, não calcula resultados e não escolhe configuração.

### 0.2 ChatGPT Desktop / GPT-5.6 Sol
Constrói/corrige a SPEC. Só pode construir o runner após:
`RUNNER_IMPLEMENTATION_AUTHORIZED=YES`.

### 0.3 Owner / PC local
Único executor de testes, piloto, full-history, hashes, manifests, SAFE_STOP/resume e validações mecânicas.

### 0.4 Gate atual
A V004 já foi reauditada com `RUNNER_IMPLEMENTATION_AUTHORIZED=YES` e originou R1/R1R1/R1R2/R1R3. O preflight A da R1R2 bloqueou fail-closed antes de qualquer replay econômico:
- `PHASE_DATA_STATUS=BLOCKED`;
- `EXPECTED_SESSIONS=250`;
- `CUTOFF_BBO_UNAVAILABLE=196`;
- todos os 196 bloqueios pertencem ao mesmo gate de frescor <=500 ms no cutoff;
- nenhuma seleção econômica foi iniciada e nenhum vencedor/ranking foi observado.

A V005 removeu o gate de idade somente do cutoff e foi reauditada com:
- `MINOTAURO_PARAMETER_MARKET_DISCOVERY_V005_CUTOFF_REAUDIT=PASS_WITH_BLOCKERS`;
- `V004_PREVIOUS_GATES_PRESERVED=YES`;
- `N1_500MS_PRESERVED=PASS`;
- `CUTOFF_CAUSAL_MODEL=PASS`;
- `CUTOFF_NO_LOOKAHEAD=PASS`;
- `COMMON_CALENDAR_INDEPENDENCE=PASS`;
- `POSTHOC_CHANGE_RISK=CLOSED`;
- `MAJOR_FINDINGS=1` e `MINOR_FINDINGS=4`;
- `FALSE_PASS_PATHS_REMAINING=2`.

O único blocker material descrito foi M1: a V005 não explicitava que o lado usado no fill compulsório deve ter **seu próprio** `bid_msc`/`ask_msc >= cutoff_msc`; um valor herdado somente de antes do corte não pode executar o fechamento. Os quatro minors são fechados documentalmente nesta V005R1.

Enquanto esta V005R1 não for reauditada com `FALSE_PASS_PATHS_REMAINING=0`:
- `RUNNER_CUTOFF_PATCH_AUTHORIZED=NO`;
- `R1R3_PREFLIGHT_RERUN_AUTHORIZED=NO`;
- `ECONOMIC_RUN_A_AUTHORIZED=NO`;
- `PARAMETER_SELECTION_AUTHORIZED=NO`;
- `DATA_PROCESSING_AUTHORIZED=NO`.

---

## 1. NATUREZA, PARIDADE E LIMITES

1. Descoberta econômica retrospectiva controlada, não OOS virgem.
2. Seleção = 2025.
3. Confirmação retrospectiva não virgem = 2026-01-01..2026-08-31.
4. Stress descritivo = 2026-09-01..2026-09-11.
5. Dados posteriores a 11/09/2026 não são consumidos.
6. O verdadeiro OOS começa somente em sessão futura após freeze prospectivo separado.
7. O estudo modela **estratégia sob fonte histórica disponível**, não lifecycle literal do terminal/broker.
8. Permissões de conta, attach/restart, trade mode, login/server binding e retcodes históricos não participam da seleção.
9. A R6 operacional permanece imutável.
10. O modelo de pesquisa não declara broker-fill parity.
11. Esta V005R1 altera somente a determinação documental de `CUTOFF_EXECUTION_MODEL`, sua contabilidade/telemetria e o respectivo preflight; nenhum parâmetro, gate de seleção, regra de N→N+1 ou custo é alterado.
12. A motivação da V005 permanece anterior a qualquer P&L da grade: a auditoria independente Sonnet 5 já havia recomendado cutoff por BBO causal oposto **sem gate de idade**, e o primeiro preflight real posteriormente demonstrou 196/250 falhas exclusivamente no gate de 500 ms do cutoff.
13. A V005R1 não muda a direção econômica da V005; fecha apenas a ambiguidade detectada pela reauditoria: quote pré-cutoff pode continuar existindo no estado causal para **marcação**, mas nunca pode ser usado como **fill** de cutoff se seu próprio timestamp for anterior ao corte.

---

## 2. BASELINE CONGELADO

Fonte operacional de referência:
`MINOTAURO_REAL_LIVE_V003R1_R6.mq5`

SHA256:
`1A950132E51700232D31636163EA1C98A64CF7AF1CBB4FED892AA71DEE059FA5`

Baseline:
- projection_pct = 61.8;
- trigger = 10T;
- RR_N mínimo = 5;
- Rmax_N = OFF;
- BUSINESS = `last>0 AND volume>0`;
- decisão = N;
- única oportunidade de entrada = primeiro BUSINESS N+1;
- sem retry em N+2;
- SL = origem congelada em N;
- TP = linha adjacente congelada em N;
- geometria deduplicada obrigatoriamente = 97 linhas;
- micros canônicos 5.6/94.4, nunca 4.4/95.6;
- cutoff decision = 18:03:00 UTC−03; fechamento histórico conforme §12.5;
- 1 contrato por célula;
- custo = R$0,25 por lado;
- slippage adicional = 0T;
- BBO causal bilateral com idade independente <=500 ms **somente na entrada N+1**, sob hipótese `LEGACY_TIME_MSC_SIMULATION_HYPOTHESIS`; cutoff não usa gate de idade.

---

## 3. CONTRATOS NÃO OTIMIZÁVEIS

Iguais em todas as células:

1. ordem física;
2. multiplicidade same-ms;
3. BUSINESS canônico;
4. quote state atualizado por todo registro físico antes do BUSINESS;
5. decisão em N;
6. pending criado em N;
7. execução somente no primeiro BUSINESS N+1;
8. pending consumido antes dos gates de execução em N+1;
9. sem recuperação em N+2;
10. sem rechecagem do RR mínimo em N+1;
11. geometria canônica e 97 linhas;
12. D1 predecessor esperado exato;
13. cutoff 18:03;
14. custos;
15. uma posição própria no máximo por célula;
16. nenhuma informação futura como feature;
17. nenhuma alteração pós-resultado das regras desta SPEC.

---

## 4. GRADE CANDIDATA E CELL_ID

### 4.1 Listas ordenadas canônicas

`PROJECTION_PCT_LIST=[38.2,50.0,61.8]`  
`TRIGGER_T_LIST=[6,8,10,12,14]`  
`RR_LIST=[3,4,5,6,7]`  
`RMAX_LIST=[OFF,12,14,16,18,20]`

### 4.2 Índices e CELL_ID

Índices são zero-based segundo as listas acima.

Formato canônico, largura fixa:
`P{p_idx:02d}_T{t_idx:02d}_R{rr_idx:02d}_M{rmax_idx:02d}`

Exemplos:
- baseline = `P02_T02_R02_M00`;
- projection 38.2 / trigger 6 / RR3 / Rmax12 = `P00_T00_R00_M01`.

O último desempate é lexicográfico sobre este `CELL_ID` ASCII exato.

### 4.3 Rmax

Em N:
1. detectar episódio/interação;
2. `riskT_N = abs(cur-line)/tick_size`;
3. se `riskT_N + 1e-9 < trigger`, não atingiu trigger;
4. ao atingir trigger, consumir o episódio;
5. target adjacente;
6. exigir reward >0;
7. `RR_N=rewardT_N/riskT_N`;
8. exigir `RR_N + 1e-12 >= RR_min`;
9. se Rmax finito, exigir `riskT_N <= Rmax + 1e-9`;
10. somente então incrementar `eligible_count`.

Rmax não reabre episódio e não é rechecado em N+1.
`riskT_N1` é somente diagnóstico.

### 4.4 Células inválidas

Rmax finito `< trigger` => `STRUCTURALLY_INVALID` a priori.

Exatamente 15 células inválidas:
3 projections × trigger 14 × 5 RR × Rmax12.

Nominal = 450.  
Válidas = 435.  
Alternativas ao baseline = 434.

Células válidas sem trades permanecem nos outputs.

---

## 5. ARITMÉTICA, UNIDADES E GEOMETRIA

### 5.1 Representação numérica normativa

Valores de preço, percentuais, custos e quantidades derivados de textos de entrada são representados exatamente como números decimais/racionais.

Nenhuma decisão econômica pode depender de precisão decimal finita arbitrária.

Constantes:
- tick_size = `5`;
- Eq epsilon = `0.0000005` (=5×1e-7);
- trigger epsilon = `0.000000001`;
- RR epsilon = `0.000000000001`;
- Rmax epsilon = `0.000000001`.

Comparações que envolvem quocientes não terminantes devem usar representação racional exata ou cross-multiplication matematicamente equivalente:
- `RR = reward/risk`;
- `PF = gross_positive/abs(gross_negative)`;
- `score = net_pnl/max_drawdown`.

Valores decimais exibidos em CSV/relatório são somente apresentação e nunca autoridade para ranking/gate.

### 5.2 Projection

`projection_pct ∈ {38.2,50.0,61.8}`

`projection_fraction = projection_pct / 100`

Logo:
- 38.2% = 0.382;
- 50.0% = 0.500;
- 61.8% = 0.618.

### 5.3 Geometria canônica — 9 macros, 8 intervalos, 11 micros internos

Para a sessão S e seu D1 predecessor esperado:

`range_raw = high_prev - low_prev`

`anchor_raw = low_prev + projection_fraction * range_raw`

#### 5.3.1 Nove níveis macro

Existem exatamente nove macros brutos:

`M_k = anchor_raw + k*range_raw`, para `k ∈ {-4,-3,-2,-1,0,1,2,3,4}`.

Esses nove macros são sempre inseridos como níveis candidatos antes da deduplicação final.

#### 5.3.2 Oito intervalos de interpolação

Existem exatamente oito intervalos entre macros consecutivos:

`I_k = [M_k, M_(k+1)]`, para `k ∈ {-4,-3,-2,-1,0,1,2,3}`.

**Não existe intervalo iniciado em `M_4`.**
Logo, nenhum micro é projetado acima de `M_4` por esta construção.

#### 5.3.3 Onze micros internos por intervalo

A lista micro canônica interna é exatamente:

`MICRO_PCT_LIST = [5.6,9.0,14.6,23.6,38.2,50.0,61.8,76.4,85.4,91.0,94.4]`

Ela **não contém 0% nem 100%**, porque os endpoints do intervalo já são os macros `M_k` e `M_(k+1)`.

Para cada intervalo `I_k`, com `k=-4..3`, e para cada `p` da lista acima:

`micro_fraction = p/100`

`L_(k,p) = M_k + micro_fraction*range_raw`

Portanto, antes de arredondamento/deduplicação:
- 9 macros;
- 8 × 11 = 88 micros internos;
- total nominal = 97 níveis.

Esta formulação é equivalente ao `BuildGrid` da R6:
- `macro_raw[9]`;
- `b=0..7`;
- `MICRO_PCTS[11]={0.056,0.090,0.146,0.236,0.382,0.500,0.618,0.764,0.854,0.910,0.944}`.

### 5.4 Round final

Cada macro e micro é arredondado **somente no nível final**, sem arredondamento intermediário:

`final = 5 * floor(raw/5 + 0.5 + 0.000000000001)`

O `+1e-12` reproduz explicitamente o `RoundTick` da R6.

Depois:
1. ordenar por preço;
2. deduplicar usando `Eq`;
3. se uma colisão contiver macro e micro no mesmo preço, preservar identidade macro para fins de label/diagnóstico;
4. exigir exatamente 97 linhas.

Se, após round/dedup, `line_count != 97`:
- motivo = `GEOMETRY_97_FAILURE`;
- mapear para `PHASE_DATA_STATUS=BLOCKED`;
- não excluir célula nem sessão silenciosamente;
- nenhum resultado selecionável da fase é publicado.

### 5.5 Eq e fronteiras

`Eq(a,b) := abs(a-b) <= 0.0000005`.

Trigger alcançado quando:
`riskT_N + 0.000000001 >= trigger`.

RR passa quando a comparação racional exata satisfaz matematicamente:
`RR_N + 0.000000000001 >= RR_min`.

Rmax passa quando OFF ou:
`riskT_N <= Rmax + 0.000000001`.

Fixtures pós-implementação devem verificar paridade de fronteira com a R6. Divergência exige revisão documental antes do full-run.

---

## 6. FONTES, INSTRUMENTO E INVENTÁRIO DE SESSÕES ESPERADAS

### 6.1 Ticks

Fonte lógica: base canônica/homologada `WIN@N`.

Campos:
- date_time;
- time_msc;
- bid;
- ask;
- last;
- volume;
- volume_real diagnóstico;
- flags diagnóstico/identidade física.

BUSINESS não usa flags nem volume_real.

### 6.2 D1

Fonte lógica: `IND@N` D1 canônico/homologado.

A presença de uma linha IND **não define o calendário esperado**.

### 6.3 Instrumento econômico

Modelo de pesquisa do WIN:
- tick = 5 pontos;
- R$0,20 por ponto por contrato;
- R$1,00 por tick por contrato;
- lote = 1.

A referência oficial B3 que comprova as constantes deve ser congelada por hash no pacote do runner antes do full-run.

### 6.4 Série contínua

O runner consome WIN@N literalmente:
- sem reconstruir símbolos mensais;
- sem ajuste adicional de rolagem;
- sem alegar paridade de símbolo/broker;
- sem posição overnight.

Label obrigatório:
`CONTINUOUS_WINN_RESEARCH_MODEL`.

### 6.5 Fonte independente de sessões esperadas

Antes de qualquer replay deve existir um artefato congelado:
`EXPECTED_SESSIONS_<PHASE>.csv`

Ele será derivado **exclusivamente do inventário homologado de sessões do projeto**, e não da presença/ausência de linhas IND nem de quotes às 18:03.

Campos mínimos:
- session_date;
- source_certificate_or_inventory_id;
- source_hash;
- expected=YES;
- expected_previous_session_date;
- predecessor_evidence_id;
- predecessor_evidence_hash.

Para a primeira sessão de cada fase, o pacote deve materializar explicitamente a evidência do predecessor necessário, inclusive quando esse predecessor pertence à fase/mês/ano anterior. A ausência dessa evidência bloqueia a fase.

Se não existir inventário/certificado homologado capaz de fornecer o universo esperado de sessões para a fase, a fase é:
`EXPECTED_SESSION_UNIVERSE_UNAVAILABLE` e não roda.

O predecessor D1 esperado é o predecessor imediato de S nessa sequência homologada de sessões esperadas.

### 6.6 Inventário físico

`SOURCE_INVENTORY.json` por fase:
- arquivo;
- tamanho;
- SHA256;
- primeira/última data;
- contagem;
- schema/parser;
- status de homologação.

---

## 7. FASES E CALENDÁRIOS — SEM EXCLUSÃO RETROSPECTIVA

### 7.1 PHASE_A_2025_SELECTION

Faixa:
2025-01-01..2025-12-31.

Pode ler:
- dados 2025;
- apenas a evidência D1 anterior necessária de dezembro/2024.

É proibido construir, consultar ou filtrar economicamente qualquer dado 2026.

Produz:
`SESSION_CALENDAR_PHASE_A.csv`.

### 7.2 PHASE_B_2026_CONFIRMATION

Só inicia após freeze válido de 2025.

Faixa:
2026-01-01..2026-08-31.

Processa somente baseline + selecionado.

Produz:
`SESSION_CALENDAR_PHASE_B.csv`.

### 7.3 PHASE_C_SEP2026_STRESS

Só após PHASE_B.

Faixa:
2026-09-01..2026-09-11.

Processa somente baseline + selecionado.

Produz:
`SESSION_CALENDAR_PHASE_C.csv`.

### 7.4 Regra conservadora de cobertura

Para cada fase, **toda sessão esperada** deve passar antes do replay econômico:

1. ticks íntegros e pertencentes à fonte homologada;
2. sessão presente fisicamente;
3. D1 predecessor esperado único e OHLC válido;
4. relação date_time/time_msc válida em toda linha;
5. monotonicidade não decrescente de time_msc, iguais permitidos;
6. observabilidade causal do fechamento de cutoff: após `cutoff_msc`, deve existir sequência física suficiente para tornar executável causalmente tanto uma posição LONG quanto SHORT sob §12.5, sem qualquer limite de idade de quote.

Se qualquer sessão esperada falhar qualquer item:
- registrar todas as falhas e seus motivos específicos;
- mapear qualquer `DATA_MODEL_BLOCKED`, `GEOMETRY_97_FAILURE`, `TIME_SEMANTICS_MISMATCH`, `EXPECTED_D1_*`, `CUTOFF_EXECUTION_OBSERVABILITY_UNAVAILABLE` ou falha equivalente para `PHASE_DATA_STATUS=BLOCKED`;
- nenhum resultado econômico da fase é publicado como selecionável/confirmatório;
- nenhuma sessão é retirada automaticamente;
- não existe tolerância percentual nem máximo de exclusões.

Isso elimina condicionamento retrospectivo da amostra por direção/posição no fim do dia: a sessão só entra no calendário comum se ambas as direções possíveis forem causalmente liquidáveis após o cutoff sob a mesma regra.

### 7.5 Calendário comum

Se e somente se todos os dias esperados passarem o preflight:
`COMMON_ELIGIBLE = EXPECTED_SESSIONS`.

Todas as células da fase usam exatamente esse calendário.

---

## 8. RELÓGIO, DATE_TIME, TIME_MSC E CUTOFF

### 8.1 Fuso fixo

Para 2025–2026:
`EXCHANGE_OFFSET=UTC-03:00`.

Nunca usar timezone do computador.

### 8.2 Validação por linha

Interpretar `date_time` como `YYYY.MM.DD HH:MM:SS` em UTC−03.

Para cada linha:
1. converter `date_time` para epoch seconds UTC;
2. calcular `floor(time_msc/1000)`;
3. exigir igualdade exata entre ambos os epoch seconds.

Falha em qualquer linha:
`TIME_SEMANTICS_MISMATCH` => fase bloqueada.

### 8.3 Cutoff_msc

Para sessão S:
`cutoff_local = S 18:03:00 UTC−03`.

`cutoff_msc = epoch_utc(cutoff_local) * 1000`.

A **decisão** de cutoff ocorre uma única vez, logicamente em `cutoff_msc`:
- cancelar pending;
- bloquear qualquer nova entrada;
- se houver posição, criar `CUTOFF_CLOSE_PENDING`.

O fill histórico pode ocorrer após 18:03 exclusivamente para executar essa decisão já tomada. Isso não reabre sinal nem usa informação posterior como feature.

Para fins de **execução do cutoff**, um lado só se torna elegível se o timestamp próprio daquele lado tiver sido observado em/apos o corte:
- BID executável de cutoff: `bid>0 AND bid_msc>=cutoff_msc AND bid_msc<=record.time_msc`;
- ASK executável de cutoff: `ask>0 AND ask_msc>=cutoff_msc AND ask_msc<=record.time_msc`.

Um BID/ASK cujo último timestamp próprio seja `< cutoff_msc` pode permanecer no estado causal para marcação de posição aberta, mas **não satisfaz** a condição de fill compulsório, mesmo que continue sendo o último valor conhecido daquele lado.

Se não existir qualquer registro físico da própria sessão com `time_msc >= cutoff_msc`, a sessão falha com `CUTOFF_EXECUTION_OBSERVABILITY_UNAVAILABLE`.

### 8.4 Gate de 500 ms — exclusivo de N+1

BID e ASK possuem timestamps independentes.

Em N+1:
- bid>0;
- ask>0;
- ask>=bid;
- N1_msc>=bid_msc;
- N1_msc>=ask_msc;
- N1_msc-bid_msc<=500;
- N1_msc-ask_msc<=500.

No cutoff:
- **não existe gate de idade de 500 ms**;
- a ausência de limite de idade **não** autoriza quote herdado somente de antes do corte a executar o fechamento;
- LONG exige BID cujo próprio `bid_msc>=cutoff_msc`;
- SHORT exige ASK cujo próprio `ask_msc>=cutoff_msc`;
- `bid_age_ms`, `ask_age_ms` e `cutoff_execution_latency_ms` continuam diagnósticos e nunca alteram elegibilidade econômica por limiar;
- nenhum quote futuro é usado para decidir o cutoff; atualizações em/apos o corte podem somente executar causalmente a decisão já determinada.

`QUOTE_AGE_CLOCK=LEGACY_TIME_MSC_SIMULATION_HYPOTHESIS`  
`NATIVE_FRESHNESS_PARITY=NOT_CLAIMED`.

---

## 9. STOPSVALID E HIPÓTESES DE BROKER

Em N+1:
- BUY: SL < ASK_entry e TP > ASK_entry;
- SELL: SL > BID_entry e TP < BID_entry.

Falha:
`ENTRY_INVALIDATED_N1`, pending consumido, sem N+2.

`BROKER_STOPS_LEVEL_MODEL=0_POINTS_ASSUMPTION`  
`BROKER_STOPS_LEVEL_PARITY=NOT_AVAILABLE`.

Permissões, trade mode, foreign positions, queue e OrderSend histórico não são simulados.

---

## 10. ESTADO POR CÉLULA E ORDEM DE EVENTOS

### 10.1 Carteira independente

Cada célula:
- 1 contrato;
- <=1 posição;
- <=1 pending;
- nenhuma interferência com outra célula.

No início de cada sessão:
- flat;
- pending vazio;
- BBO vazio;
- episódios inativos;
- business_seq=0;
- have_prev_business=false.

`realized_cash_brl` **não reinicia entre sessões do mesmo bloco**; reinicia somente no início do bloco/fase econômica.

### 10.2 Ordem por registro físico

Cada registro recebe `physical_ordinal`.

Processar:

1. se cutoff ainda não aplicado e `record.time_msc >= cutoff_msc`, latchear **uma única** decisão de cutoff: cancelar pending, bloquear reentrada e, se houver posição, marcar `CUTOFF_CLOSE_PENDING`;
2. atualizar BID se bid>0 e seu bid_msc;
3. atualizar ASK se ask>0 e seu ask_msc;
4. se `CUTOFF_CLOSE_PENDING`, tentar primeiro o fill compulsório segundo §12.5; se executar, realizar caixa/custo e publicar `CUTOFF_CLOSE_POST_REALIZATION` conforme §13.1 Caso C;
5. somente se **não** houver `CUTOFF_CLOSE_PENDING`, resolver stop/TP de **posições preexistentes** usando o lado executável atualizado neste registro;
6. aplicar caixa/custo de qualquer saída preexistente;
7. publicar equity/HWM segundo §13.1: se o cutoff executou, não publicar marca duplicada; se `CUTOFF_CLOSE_PENDING` persistir, publicar `OPEN_MARK` apenas como marcação causal da posição ainda aberta (`cutoff_pending=YES`), mesmo que o lado de marcação seja herdado de antes do corte; essa marcação jamais pode ser reutilizada como fill de cutoff; se não houver lado causal disponível para marcar, nenhum preço é fabricado e nenhum novo subevento HWM/DD é publicado naquele registro;
8. se não BUSINESS, terminar;
9. se horário >=cutoff, não sinalizar/entrar;
10. incrementar business_seq;
11. consumir/executar pending anterior;
12. se houver nova entrada, executar os subeventos de entrada/immediate-stop da seção 13;
13. processar episódios/sinais do próprio BUSINESS;
14. prev_business_price=last.

ExecutePending precede ProcessEpisodes no BUSINESS N+1.

---

## 11. EPISÓDIOS, SINAL E BUSY

### 11.1 Interação

`Eq(prev,line)` ou `Eq(cur,line)` ou travessia estrita.

### 11.2 Trigger

Quando linha ativa alcança trigger:
- consumir episódio antes dos filtros;
- direção = lado de cur;
- target adjacente;
- reward>0;
- RR;
- Rmax em N;
- eligible_count.

### 11.3 Busy / ambiguidade

Após eligible_count:
- 0 => nada;
- posição ou pending => `ELIGIBLE_SKIPPED_BUSY`;
- >1 => `AMBIGUOUS_MULTI_SIGNAL`, sem tiebreak;
- =1 e flat => pending N.

Após recusa em N+1, o próprio N+1 pode criar **novo sinal independente**; isso não é retry.

---

## 12. MODELO ÚNICO DE FILL

### 12.1 Entrada
Primeiro BUSINESS N+1:
- BUY no ASK causal;
- SELL no BID causal;
- custo entrada -R$0,25;
- SL/TP congelados em N.

### 12.2 Lado executável
- BUY marcada/saída pelo BID;
- SELL marcada/saída pelo ASK.

### 12.3 Stop
Market-on-trigger:
- BUY: novo BID<=SL => fill no BID observado;
- SELL: novo ASK>=SL => fill no ASK observado.

Gap usa preço observado, não SL.

### 12.4 Target
Limit-fill-on-touch:
- BUY: novo BID>=TP => fill exatamente TP;
- SELL: novo ASK<=TP => fill exatamente TP.

Nunca marcar economicamente a posição a um preço além do TP **antes** de realizar a saída limitada a TP.

### 12.5 Cutoff — market close causal sem gate de idade
Às 18:03:00.000:
- cancelar pending;
- proibir novas entradas;
- se houver posição, criar `CUTOFF_CLOSE_PENDING`;
- a decisão de fechar é definitiva e não depende de quote posterior.

Execução histórica:
1. percorrer os registros físicos em ordem a partir de `time_msc >= cutoff_msc`, **sem ultrapassar a própria `session_date` S**;
2. em cada registro, atualizar primeiro o estado BID/ASK com os campos fisicamente presentes e seus timestamps próprios;
3. definir `cutoff_bid_eligible = (bid>0 AND bid_msc>=cutoff_msc AND bid_msc<=record.time_msc)` e `cutoff_ask_eligible = (ask>0 AND ask_msc>=cutoff_msc AND ask_msc<=record.time_msc)`;
4. LONG: preencher no primeiro estado causal em que `cutoff_bid_eligible=YES`; o fill é o BID desse estado;
5. SHORT: preencher no primeiro estado causal em que `cutoff_ask_eligible=YES`; o fill é o ASK desse estado;
6. um lado cujo último timestamp próprio seja `< cutoff_msc` **não pode** preencher o cutoff, ainda que seja o último valor causal conhecido e possa ser usado para `OPEN_MARK` enquanto a posição segue aberta;
7. se ambos os lados estiverem conhecidos no estado corrente, exigir `ASK>=BID`; estado cruzado/inválido não é executável e a busca causal continua dentro da mesma sessão;
8. não aplicar idade máxima de quote; idade é somente diagnóstico;
9. não usar `last`, midpoint, spread sintético, SL/TP ou preço anterior substituto;
10. `fill_msc` é o `record.time_msc` do primeiro estado que satisfaz a regra de execução; `cutoff_execution_latency_ms = fill_msc - cutoff_msc` é output obrigatório;
11. depois do latch do cutoff, stop/TP/sinal não têm precedência sobre o fechamento compulsório;
12. a busca termina no último registro físico cuja `session_date=S`; é proibido usar qualquer registro de outra sessão/data para preencher a saída.

Preflight comum, antes de qualquer célula:
- simular a observabilidade de LONG e SHORT de forma independente sob exatamente a regra acima;
- para LONG, exigir existência de um estado executável com BID cujo **próprio** `bid_msc>=cutoff_msc` dentro de S;
- para SHORT, exigir existência de um estado executável com ASK cujo **próprio** `ask_msc>=cutoff_msc` dentro de S;
- se qualquer direção não for executável até o fim físico da própria sessão S, `CUTOFF_EXECUTION_OBSERVABILITY_UNAVAILABLE` => `PHASE_DATA_STATUS=BLOCKED`;
- nenhuma sessão é censurada/excluída para salvar resultados; nenhuma célula escolhe seu próprio calendário.

Telemetria diagnóstica obrigatória, **sem poder de bloqueio/seleção**:
- gravar por sessão `first_cutoff_bid_msc`, `first_cutoff_ask_msc`, `cutoff_long_fill_msc`, `cutoff_short_fill_msc`, `cutoff_long_latency_ms`, `cutoff_short_latency_ms`;
- produzir `CUTOFF_LATENCY_DIAGNOSTICS.csv` com todas as sessões esperadas, além de P50/P95/P99/MAX por direção e ranking decrescente das 10 maiores latências por fase;
- não existe limiar de latência que transforme PASS em FAIL nesta V005R1; a telemetria serve para revisão manual e detecção de outliers sem ajuste econômico pós-hoc.

Definição normativa de **fim físico da sessão** para esta seção: último registro físico do arquivo de ticks que, após a semântica de `date_time/time_msc` da §8 e o inventário homologado da §6.5–6.6, pertence à mesma `session_date=S`. A busca forward jamais cruza para `session_date != S`.

Esse modelo aproxima a `trade.PositionClose(sym)` da R6: a ordem econômica de saída é determinada no cutoff e o histórico apenas fornece o primeiro preço causal executável posterior com atualização própria pós-cutoff. Não se alega paridade de latência/fill do broker.

### 12.6 Custo saída
-R$0,25 em qualquer saída modelada.

---

## 13. EQUITY/HWM — SUBEVENTOS NORMATIVOS

Esta seção fecha a ordem contábil.

### 13.1 Posição preexistente no início do registro

Após atualizar o lado executável:

**Caso A — saída por stop/TP**
1. determinar fill segundo seção 12;
2. realizar P&L bruto;
3. debitar custo de saída;
4. tornar posição flat;
5. publicar `EQUITY_SUBEVENT=PREEXISTING_EXIT_POST_REALIZATION`;
6. atualizar HWM/DD.

É proibido publicar antes disso uma marcação no quote que já atravessou o TP se o fill será limitado ao TP.

**Caso B — nenhuma saída / posição ainda aberta**
1. marcar posição pelo lado executável causal disponível naquele registro;
2. subtrair o custo futuro de saída de R$0,25;
3. publicar `EQUITY_SUBEVENT=OPEN_MARK`;
4. se `CUTOFF_CLOSE_PENDING=YES`, publicar também o campo `cutoff_pending=YES`; um quote pré-cutoff pode servir apenas para esta marcação causal, nunca para o fill compulsório;
5. atualizar HWM/DD;
6. se nenhum lado causal de marcação existir, não fabricar preço: não publicar novo `OPEN_MARK` nem novo HWM/DD naquele registro.

**Caso C — saída por cutoff**
1. determinar o fill exclusivamente segundo §12.5;
2. realizar P&L bruto nesse fill;
3. debitar custo de saída de R$0,25;
4. tornar posição flat e limpar `CUTOFF_CLOSE_PENDING`;
5. publicar `EQUITY_SUBEVENT=CUTOFF_CLOSE_POST_REALIZATION` com `fill_msc`, `cutoff_execution_latency_ms` e lado usado;
6. definir `equity=realized_cash` pós-realização;
7. atualizar HWM/DD uma única vez nesse subevento;
8. é proibido publicar, no mesmo registro e para a mesma posição, `OPEN_MARK`, stop/TP ou qualquer segunda saída após `CUTOFF_CLOSE_POST_REALIZATION`.

### 13.2 Nova entrada em N+1

Após o fill:
1. debitar custo de entrada;
2. posição passa a aberta;
3. calcular equity líquida de liquidação com BBO causal atual, incluindo reserva do custo futuro de saída de R$0,25;
4. publicar `EQUITY_SUBEVENT=ENTRY_OPEN_MARK`;
5. atualizar HWM/DD;
6. somente depois testar stop imediato pelo spread/BBO causal.

Se stop imediato:
7. realizar saída no lado executável causal;
8. debitar custo de saída;
9. flat;
10. publicar `EQUITY_SUBEVENT=IMMEDIATE_STOP_POST_REALIZATION`;
11. atualizar HWM/DD novamente.

Portanto a perda transitória da nova entrada é registrada mesmo quando entrada e stop imediato ocorrem no mesmo registro.

### 13.3 Caixa e equity

Sem posição:
`equity = realized_cash`.

Com posição:
`equity = realized_cash + unrealized_gross - 0.25`.

O custo de entrada já está no realized_cash; o `-0.25` aberto é somente custo futuro de liquidação.

### 13.4 Drawdown

Curva primária = sequência ordenada de todos os `EQUITY_SUBEVENT` econômicos + cutoff.

`HWM_t=max(HWM_{t-1},equity_t)`  
`DD_t=HWM_t-equity_t`.

Equity/HWM **não reiniciam entre sessões** da mesma fase/bloco.

Max DD primário = maior DD_t.

Closed-equity DD é apenas diagnóstico.

---

## 14. MÉTRICAS E CASOS DEGENERADOS

Por célula:
- trade_count;
- sessions_with_trade;
- wins/losses/breakeven líquidos;
- gross/net P&L;
- PF líquido;
- expectancy;
- avg win/loss;
- payoff;
- max DD primário;
- closed DD diagnóstico;
- recovery factor;
- mensal/trimestral/H1/H2;
- BUY/SELL;
- por hora;
- BEFORE_12/FROM_12_TO_CUTOFF apenas relatório;
- concentração top1/5/10;
- sequences;
- tempo em mercado;
- rejeições;
- riskT_N/riskT_N1.

### 14.1 PF

`PF=sum(net_positive_trades)/abs(sum(net_negative_trades))`.

- perdas>0 => PF finito e avaliável;
- perdas=0 e ganhos>0 => `PF=INF`, **não avaliável para aprovação de gate**;
- ganhos=0 e perdas=0 => `PF=UNDEFINED`.

### 14.2 DD zero

Max DD=0 => score `net/DD` não avaliável; célula não passa seleção.

### 14.3 Concentração

Denominador:
soma dos resultados diários positivos.

Top5 concentration =
soma dos cinco maiores resultados diários positivos / soma de todos os dias positivos.

Denominador zero => UNDEFINED e gate falha.

### 14.4 Mediana

Para n ímpar: valor central após ordenação.

Para n par: média aritmética exata dos dois centrais.

---

## 15. SELEÇÃO 2025

### 15.1 Suficiência do baseline

Baseline é **amostralmente suficiente** se, independentemente de lucratividade:
- >=200 trades completos;
- >=60 sessões com trade.

Se não:
`SELECTION_STATUS=INSUFFICIENT_EVIDENCE`
e não existe seleção.

### 15.2 Gates da célula

Após baseline suficiente, célula candidata precisa:
1. >=200 trades;
2. >=60 sessões com trade;
3. trade_count >=50% do baseline;
4. trades em >=9 meses;
5. net_pnl>0;
6. perdas líquidas acumuladas>0;
7. PF finito e >1;
8. max DD>0;
9. H1 net>0;
10. H2 net>0;
11. >=9 meses positivos;
12. P&L sem top5 dias >0;
13. top5 concentration <=40%.

### 15.3 Grafo de vizinhança não direcionado

Duas células são vizinhas se diferem em **uma** coordenada conforme:

- projection: qualquer uma das outras duas projections;
- trigger: predecessor/sucessor;
- RR: predecessor/sucessor;
- Rmax OFF: todos os cinco Rmax finitos;
- Rmax finito: predecessor/sucessor entre finitos **mais OFF**.

A relação é explicitamente simétrica.

Remover somente vizinho estruturalmente inválido.
Vizinho válido sem trades permanece no denominador.

### 15.4 Gate da vizinhança

- >=3 vizinhos válidos;
- pelo menos `ceil(2/3 * n_valid_neighbors)` aprovam:
  - net_pnl>0;
  - perdas líquidas acumuladas>0;
  - PF **finito** e >1;
- PF INF/UNDEFINED não aprova;
- score não avaliável recebe zero **somente para a mediana deste gate**;
- score negativo avaliável permanece negativo;
- mediana dos scores da vizinhança >=50% do score da célula.

### 15.5 Score e desempate

`score = net_pnl / max_drawdown`.

Comparações usam valores internos sem arredondamento de apresentação.
Para `score`, `PF` e demais razões não terminantes, ordenar/comparar por fração exata/cross-multiplication; strings decimais exportadas não participam do desempate.

Ordenação:
1. maior score;
2. maior mediana dos 12 resultados mensais (mês coberto sem trade=0);
3. maior PF líquido finito;
4. maior trade_count;
5. menor distância ao baseline;
6. menor CELL_ID lexicográfico.

Distância:
- projection: 0 se baseline, senão 1;
- trigger: distância de índice;
- RR: distância de índice;
- Rmax: 0 se OFF, 1 se finito;
- soma total.

### 15.6 Resultado

Exatamente um:
- `SELECTED=<CELL_ID>`;
- `NO_CANDIDATE`;
- `INSUFFICIENT_EVIDENCE`;
- `PHASE_DATA_BLOCKED`.

Sem segunda busca adaptativa.

---

## 16. FREEZE E ISOLAMENTO

### 16.1 Freeze

PHASE_A produz `SELECTION_FREEZE.json` antes de qualquer leitura econômica 2026.

Conteúdo:
- SPEC hash;
- runner hash;
- grade hash;
- expected-session inventory hash;
- source hashes 2025;
- CELL_ID ou status;
- gates/métricas;
- timestamp;
- hash do freeze.

### 16.2 PHASE_B

Só abre:
- baseline;
- selecionado.

Se NO_CANDIDATE/INSUFFICIENT_EVIDENCE:
não procura alternativa.

Se PHASE_B tiver qualquer falha de dados:
`CONFIRMATION_STATUS=DATA_BLOCKED`.
Nunca converter em NOT_CONFIRMED econômico.

---

## 17. CONFIRMAÇÃO 2026-01..08

### 17.1 Selecionado diferente do baseline

CONFIRMED somente se:
1. selected net>0;
2. selected net>baseline;
3. selected DD<=baseline DD;
4. selected>=100 trades;
5. selected>=40 sessões com trade;
6. >=6/8 meses positivos;
7. net sem top5 dias>0.

Falha econômica:
`NOT_CONFIRMED`.

Falha de dados:
`DATA_BLOCKED`.

### 17.2 Baseline selecionado

`BASELINE_RETAINED_CONFIRMED` se:
- net>0;
- >=100 trades;
- >=40 sessões;
- >=6/8 meses positivos;
- net sem top5 dias>0;
- DD avaliável.

Senão:
`BASELINE_RETAINED_NOT_CONFIRMED`.

Sem substituição em 2026.

---

## 18. STRESS SETEMBRO/2026

Faixa fechada:
2026-09-01..2026-09-11.

Somente baseline + selecionado.

Stress descritivo.
Nunca seleciona, desempata, resgata ou rejeita retroativamente 2025.

Falha de dados:
`SEP_STRESS_DATA_BLOCKED`.

---

## 19. OUTPUTS OBRIGATÓRIOS

Metadados:
- RUN_MANIFEST.json
- SOURCE_INVENTORY_<PHASE>.json
- EXPECTED_SESSIONS_<PHASE>.csv
- SESSION_CALENDAR_<PHASE>.csv
- GRID_CELLS.csv
- MODEL_ASSUMPTIONS.json
- SPEC_HASH.txt
- RUNNER_HASH.txt
- SHA256SUMS.txt
- CUTOFF_LATENCY_DIAGNOSTICS.csv

2025:
- CELL_SUMMARY_2025.csv
- MONTHLY_2025.csv
- QUARTERLY_2025.csv
- NEIGHBORHOOD_2025.csv
- SELECTION_GATES_2025.csv
- REJECTIONS_2025.csv
- TRADES_2025_ALL_CELLS.csv
- EVENT_LEDGER_2025
- EQUITY_EVENTS_2025
- SELECTION_FREEZE.json

2026:
- SUMMARY_2026_FROZEN_ONLY.csv
- MONTHLY_2026_FROZEN_ONLY.csv
- TRADES_2026_FROZEN_ONLY.csv
- EVENT_LEDGER_2026_FROZEN_ONLY
- CONFIRMATION_GATE.json

Setembro:
- SUMMARY_SEP2026_FROZEN_ONLY.csv
- TRADES_SEP2026_FROZEN_ONLY.csv
- EVENT_LEDGER_SEP2026_FROZEN_ONLY

Ledgers devem conter identidade física N/N+1, BBO/timestamps/idades, fills, SL/TP, saída, custos, gross/net, model assumptions, rejeições e subeventos de equity. Para cutoff, registrar obrigatoriamente `cutoff_msc`, `first_cutoff_bid_msc`, `first_cutoff_ask_msc`, `cutoff_fill_msc`, `cutoff_execution_latency_ms`, lado executável, timestamp próprio do lado usado, preço de fill, `cutoff_pending` nos `OPEN_MARK` intermediários e idades BID/ASK apenas diagnósticas.

---

## 20. OVERFITTING E MULTIPLICIDADE

1. Grade inteira publicada antes do código.
2. Uma única seleção.
3. Vizinhança pré-definida e simétrica.
4. Nenhuma exclusão retrospectiva de sessão para produzir seleção.
5. 2026 não reseleciona.
6. Sem segunda grade adaptativa.
7. Sem p-values individuais como certificado do vencedor.
8. Sem bootstrap nesta V003.
9. Resultado = `exploratory_candidate`, nunca “ótimo demonstrado”.
10. Falha de dados bloqueia o bloco; não é convertida em resultado econômico.

---

## 21. SAFE_STOP / RESUME

Contrato do futuro runner:

- checkpoint atômico por sessão;
- commit só após concluir todas as células da sessão;
- Ctrl+C solicita SAFE_STOP;
- interrupção intrassessão descarta trabalho parcial daquela sessão;
- resume reexecuta a sessão desde o início;
- commits anteriores são preservados;
- checkpoint inclui fase, última sessão commitada e hashes;
- PHASE_A nunca abre dados econômicos 2026;
- execução limpa e resume devem gerar hashes idênticos **somente nos artefatos econômicos determinísticos**;
- logs/timestamps/recibos operacionais podem diferir e ficam separados;
- SAFE_STOP=YES;
- DELETE=NO.

Não se alega retomada intrassessão.

---

## 22. GATES PÓS-IMPLEMENTAÇÃO / PRÉ-FULL-RUN

Obrigatórios:

1. projection_pct/100 e fixtures 38.2/50/61.8;
2. decimal exato, round-half-up e 97 linhas;
3. Eq/trigger/RR/Rmax nas fronteiras;
4. expected-session inventory independente;
5. D1 predecessor exato;
6. date_time↔time_msc por linha;
7. cutoff_msc UTC−03;
8. BBO bilateral de N+1 com 500 ms inclusivo e regressões; cutoff explicitamente sem gate de idade;
9. cutoff LONG/SHORT exige timestamp próprio do lado `>=cutoff_msc`; quote herdado pré-cutoff pode marcar, mas não preencher;
10. busca de cutoff confinada à própria `session_date`;
11. `CUTOFF_CLOSE_POST_REALIZATION` e `OPEN_MARK` durante `CUTOFF_CLOSE_PENDING` reconciliados;
12. `CUTOFF_LATENCY_DIAGNOSTICS.csv` com todas as sessões, P50/P95/P99/MAX e top-10 por direção, sem gate econômico;
13. N→N+1, same-ms, pending consumido, sem N+2;
14. stop gap;
15. target com salto além de TP sem pico fictício de equity;
16. entry open mark + stop imediato no mesmo registro;
17. cutoff único;
18. ausência de observabilidade causal pós-cutoff para LONG ou SHORT => fase bloqueada;
19. busy/carteiras independentes;
20. custos/caixa/equity/DD reconciliados;
21. baseline insuficiente;
22. PF INF/UNDEFINED e DD zero;
23. vizinhança simétrica;
24. CELL_ID e desempate total;
25. isolamento A/B/C;
26. SAFE_STOP antes/durante/depois de commit;
27. equivalência econômica clean/resume;
28. piloto local reconciliado.

Nenhum full-run antes desses gates.

---

## 23. FUTURO OOS

Protocolo separado, congelado antes do início:

- primeira sessão elegível futura posterior ao freeze prospectivo e ainda não ocorrida;
- 60 sessões elegíveis consecutivas;
- baseline + uma configuração final;
- nenhuma troca intermediária;
- >=100 trades ao final ou INSUFFICIENT_EVIDENCE sem extensão oportunista;
- modelo/custos/critério congelados.

Esta V005 não abre OOS e não autoriza dinheiro real.

---

## 24. STATUS V005R1

`SPEC_STATUS=CUTOFF_REAUDIT_R1_REQUIRED`  
`PARENT_V005_REAUDIT=PASS_WITH_BLOCKERS`  
`V004_PREVIOUS_GATES_PRESERVED=YES`  
`R1R2_PREFLIGHT_A=BLOCKED_196_OF_250_CUTOFF_ONLY`  
`ECONOMIC_RESULTS_OBSERVED=NO`  
`M1_POST_CUTOFF_OWN_TIMESTAMP=DOCUMENTALLY_CLOSED_PENDING_REAUDIT`  
`MINOR_M1_CUTOFF_POST_REALIZATION=DOCUMENTALLY_CLOSED_PENDING_REAUDIT`  
`MINOR_M2_PENDING_HWM=DOCUMENTALLY_CLOSED_PENDING_REAUDIT`  
`MINOR_M3_LATENCY_DIAGNOSTICS=DOCUMENTALLY_CLOSED_PENDING_REAUDIT`  
`MINOR_M4_SESSION_BOUNDARY=DOCUMENTALLY_CLOSED_PENDING_REAUDIT`  
`RUNNER_CUTOFF_PATCH_AUTHORIZED=NO`  
`R1R3_PREFLIGHT_RERUN_AUTHORIZED=NO`  
`ECONOMIC_RUN_A_AUTHORIZED=NO`  
`DATA_PROCESSING_AUTHORIZED=NO`  
`REAL_MONEY_AUTHORIZATION_FROM_THIS_STUDY=NO`

Objetivo da reauditoria V005R1:
1. confirmar que o fill de cutoff exige timestamp próprio do lado `>=cutoff_msc`, fechando M1 sem reintroduzir gate de 500 ms;
2. confirmar que quote herdado pré-cutoff pode ser usado somente para marcação `OPEN_MARK`, nunca como fill;
3. confirmar `CUTOFF_CLOSE_POST_REALIZATION` como subevento contábil determinado e sem dupla marca/saída;
4. confirmar a marcação de equity/HWM durante `CUTOFF_CLOSE_PENDING`;
5. confirmar telemetria de latência completa e estritamente diagnóstica, sem limiar econômico;
6. confirmar que a busca nunca cruza `session_date`;
7. confirmar que N1<=500 ms e todos os demais gates V004/V005 permanecem preservados;
8. reconciliar o contador anterior `FALSE_PASS_PATHS_REMAINING=2`: a nova auditoria deve enumerar nominalmente cada falso-pass remanescente; autorização só pode ser `YES` quando o contador for exatamente zero.
