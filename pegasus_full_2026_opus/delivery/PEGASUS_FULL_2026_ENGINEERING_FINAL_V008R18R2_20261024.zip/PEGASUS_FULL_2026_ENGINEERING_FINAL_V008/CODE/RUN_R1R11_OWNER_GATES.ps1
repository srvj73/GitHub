﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$Python,
    [Parameter(Mandatory=$true)][string]$EvidenceRoot,
    [ValidateRange(1,11)][int]$StopAfter = 11
)
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) {
    throw 'POWERSHELL_5_1_REQUIRED'
}
if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { throw 'PYTHON_EXECUTABLE_NOT_FOUND' }
$packageRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$evidencePath = [IO.Path]::GetFullPath($EvidenceRoot)
if ($evidencePath.Equals($packageRoot,[StringComparison]::OrdinalIgnoreCase) -or
    $evidencePath.StartsWith($packageRoot + '\',[StringComparison]::OrdinalIgnoreCase)) {
    throw 'EVIDENCE_ROOT_MUST_BE_OUTSIDE_PACKAGE'
}
if ((Test-Path -LiteralPath $evidencePath) -and
    (@(Get-ChildItem -LiteralPath $evidencePath -Force).Count -gt 0) -and
    -not (Test-Path -LiteralPath (Join-Path $evidencePath 'PREREGISTRATION.json') -PathType Leaf)) {
    throw 'EXISTING_EVIDENCE_WITHOUT_PREREGISTRATION_REFUSED'
}
Write-Output ('PSVersion=' + $PSVersionTable.PSVersion.ToString())
Write-Output 'R1R11_V004R2_OWNER_GATES_ONLY SYNTHETIC=YES REAL_DATA=NO PILOT_A=NO RUN_A=NO'
& $Python -X utf8 -B (Join-Path $PSScriptRoot 'r1r11_owner_gates.py') --owner-output $evidencePath --stop-after $StopAfter
$code = $LASTEXITCODE
if ($code -ne 0) {
    Write-Output "OWNER_G1_TO_G11=FAIL EXIT_CODE=$code"
    exit $code
}
if ($StopAfter -lt 11) {
    Write-Output ("OWNER_PARTIAL_PASS=G1_TO_G$StopAfter NEXT=RETURN_TO_CHAT_BEFORE_G$($StopAfter+1)")
} else {
    Write-Output 'NEXT_GATE=INDEPENDENT_PREPILOT_IMPLEMENTATION_AUDIT'
}
exit 0
