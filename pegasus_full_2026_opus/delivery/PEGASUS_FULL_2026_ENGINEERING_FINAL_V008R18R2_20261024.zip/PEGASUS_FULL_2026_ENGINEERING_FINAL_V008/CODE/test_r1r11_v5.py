"""R1R11 V005 E1-E7 synthetic tests. Windows owner execution is authoritative."""
from __future__ import annotations

import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

PACKAGE=Path(__file__).resolve().parent


def economic(root: Path):
    rows={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
          for p in sorted((root/'sessions').rglob('*')) if p.is_file()}
    rows['CHECKPOINT.json']=hashlib.sha256((root/'CHECKPOINT.json').read_bytes()).hexdigest()
    return rows


def _canonical_for_test(row):
    return (json.dumps(row,sort_keys=True,separators=(",",":"),ensure_ascii=False)+"\n").encode("utf-8")


class V005Integration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from r1r11_fixtures import generate
        base=os.environ.get('R1R11_V5_TEST_ROOT') or os.environ.get('R1R11_V4_TEST_ROOT')
        if not base: raise RuntimeError('R1R11_V5_TEST_ROOT_REQUIRED')
        cls.root=Path(base).resolve()
        if cls.root.is_relative_to(PACKAGE): raise RuntimeError('TEST_OUTPUT_OUTSIDE_PACKAGE_REQUIRED')
        cls.root.mkdir(exist_ok=False); generate(cls.root/'inputs'); cls.counter=0

    @classmethod
    def invoke(cls,name,*,role='candidate',workers=2,only=None,fault=None,expected=0):
        out=cls.root/name
        args=[sys.executable,'-X','utf8','-B',str(PACKAGE/'r1r11_fixtures.py'),'--inputs',str(cls.root/'inputs'),
              '--out',str(out),'--role',role,'--workers',str(workers),'--integral','all']
        if only: args += ['--only',only]
        if fault: args += ['--fault',json.dumps(fault)]
        log=cls.root/f'{cls.counter:03d}_{name}.log'; cls.counter+=1
        with log.open('x',encoding='utf-8') as f:
            p=subprocess.run(args,cwd=PACKAGE,stdout=f,stderr=subprocess.STDOUT,
                env={**os.environ,'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'})
        text=log.read_text(encoding='utf-8',errors='replace')
        if expected is not None and p.returncode!=expected:
            raise AssertionError(f'{name}: expected={expected} got={p.returncode}\n{text[-6000:]}')
        return p.returncode,text,out

    def test_v5_a_full_differential_39_plus_heavy(self):
        _,_,oa=self.invoke('v5a_oracle_all',role='oracle')
        _,_,ca=self.invoke('v5a_candidate_all',workers=4)
        self.assertEqual(economic(oa),economic(ca))
        _,_,oh=self.invoke('v5a_oracle_heavy',role='oracle',only='heavy')
        _,_,ch=self.invoke('v5a_candidate_heavy',workers=4,only='heavy')
        self.assertEqual(economic(oh),economic(ch))

    def test_v5_b_ack_watermark_and_multiwork(self):
        _,_,out=self.invoke('v5b_watermark',workers=4,only='pending_cancel')
        rows=[json.loads(x) for x in (out/'TELEMETRY/R1R11_TRANSPORT.jsonl').read_text().splitlines()]
        sched=[r for r in rows if r.get('event')=='SCHEDULER' and r.get('session')!='1999-12-31']
        self.assertTrue(sched); self.assertGreaterEqual(min(int(r['decision']['granted']) for r in sched),2)
        ack=[r for r in rows if r.get('event')=='BATCH_ACK' and r.get('session')!='1999-12-31']
        wm=[r for r in rows if r.get('event')=='STREAM_WATERMARK_ACK' and r.get('session')!='1999-12-31']
        self.assertTrue(ack and wm)
        # `seq` is a ParallelSession-local batch counter and intentionally resets to 1
        # for every new session. Validate continuity inside each declared scope instead
        # of incorrectly concatenating independent session counters.
        sessions=sorted({r['session'] for r in ack})
        self.assertTrue(sessions)
        for session in sessions:
            session_ack=[r for r in ack if r['session']==session]
            session_wm=[r for r in wm if r['session']==session]
            self.assertTrue(session_ack and session_wm)
            seqs=[int(r['seq']) for r in session_ack]
            self.assertEqual(seqs,list(range(1,len(seqs)+1)))
            self.assertLessEqual(max(int(r['watermark']) for r in session_wm),
                                 max(int(r['n_records']) for r in session_ack))

    def test_v5_c_trade_finality_recheck_mutation(self):
        from minotauro_v004_core import ModelError,valid_cells
        from r1r11_v5_stream import V5ScratchSink
        cells=valid_cells(); row={'entry_ordinal':1,'cell_id':cells[0].cell_id,'exit_reason':'TARGET'}
        with tempfile.TemporaryDirectory() as td:
            s=V5ScratchSink(Path(td)/'g/trades.jsonl','trades',cells); s.append(dict(row)); s.flush_batch(); s.close()
            # V005R4: authoritative scratch is a streaming gzip member (level 1),
            # while its decompressed payload remains canonical JSONL.
            with gzip.open(s.path,'rb') as f:
                scratch_line=f.read()
            self.assertEqual(json.loads(scratch_line),row)
            self.assertEqual(s.physical_bytes,s.path.stat().st_size)
            self.assertGreater(s.physical_bytes,0)
            mutated=dict(row); mutated['exit_reason']='STOP'
            with self.assertRaisesRegex(ModelError,'FINALITY'):
                s.recheck_final_trades([mutated])

    def test_v5_c_canonical_gzip_releases_external_raw_handle(self):
        from r1r11_v5_stream import _CanonicalGzip
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'probe.jsonl.gz.verify'
            writer=_CanonicalGzip(path)
            writer.write({'probe':1})
            writer.close()
            self.assertTrue(writer.raw.closed)
            path.unlink()
            self.assertFalse(path.exists())

    def test_v5_d_independent_verifier_and_tamper_fail_closed(self):
        cases=[
            ('scratch_append',{'point':'scratch_sealed','kind':'append'}),
            ('stage_truncate',{'point':'v5_stage_sealed','kind':'truncate'}),
            ('writer_death',{'point':'v5_stream','kind':'writer_death','seq':1}),
            ('verifier_death',{'point':'v5_stream','kind':'verifier_death','seq':1}),
        ]
        for name,fault in cases:
            code,text,out=self.invoke('v5d_'+name,workers=2,only='pending_cancel',fault=fault,expected=None)
            self.assertNotEqual(code,0,text)
            cp=json.loads((out/'CHECKPOINT.json').read_text())
            self.assertEqual(cp['completed'],['1999-12-31'])

    def test_v5_e_transaction_resume_deterministic(self):
        _,_,clean=self.invoke('v5e_clean',workers=2,only='pending_cancel')
        expected=economic(clean)
        code,text,out=self.invoke('v5e_fault',workers=2,only='pending_cancel',fault={'point':'after_merge_before_commit','kind':'stop'},expected=None)
        self.assertNotEqual(code,0,text)
        code,text,_=self.invoke_existing(out,'v5e_resume',workers=3,only='pending_cancel')
        if code:
            self.assertIn('STALE_SCRATCH_PURGED_RESUME_REQUIRED',text)
            code,text,_=self.invoke_existing(out,'v5e_resume2',workers=3,only='pending_cancel')
        self.assertEqual(code,0,text); self.assertEqual(economic(out),expected)

    @classmethod
    def invoke_existing(cls,out,name,*,workers,only):
        args=[sys.executable,'-X','utf8','-B',str(PACKAGE/'r1r11_fixtures.py'),'--inputs',str(cls.root/'inputs'),
              '--out',str(out),'--role','candidate','--workers',str(workers),'--integral','all','--only',only]
        log=cls.root/f'{cls.counter:03d}_{name}.log'; cls.counter+=1
        with log.open('x',encoding='utf-8') as f:
            p=subprocess.run(args,cwd=PACKAGE,stdout=f,stderr=subprocess.STDOUT,
                env={**os.environ,'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'})
        return p.returncode,log.read_text(encoding='utf-8',errors='replace'),out

    def test_v5_f_memory_accounts_aux_roles(self):
        _,_,out=self.invoke('v5f_memory',workers=2,only='pending_cancel')
        rows=[json.loads(x) for x in (out/'TELEMETRY/memory.jsonl').read_text().splitlines()]
        self.assertTrue(rows); self.assertTrue(all(r.get('schema')=='R1R11_MEMORY_V1' for r in rows))
        self.assertTrue(any('stream_closeout' in set(r.get('pid_roles',{}).values()) for r in rows))
        peaks=[int(r['JOB_PEAK_BOUND_RUN']) for r in rows]
        self.assertEqual(peaks,sorted(peaks))

    def test_v5_g_frozen_contract_static(self):
        frozen={
          'minotauro_v004_core.py':'97F8F957300D37966913C872B7F04E498D30B0CFF68180993DB80D314B900827',
          'minotauro_v004_io.py':'DC816C617AA6586828CEC769B21741D5BC4106FA8A72B933F1BE76D4E1BCAF4F',
          'minotauro_v004_metrics.py':'8CE1292F5E0580E98DCB3743350416C0C559F6C6189305250371F2E05D22970F',
          'minotauro_v004_preflight.py':'3A2398FD86F93C1EBD8AF5C1BD64D4BC839185AC26FABA775C8152FD29750390',
          'r1r11_owner_gates.py':'100B26F54E81E49B1A47CD7AAA142F12AEBEB3070C8466C824B8716CA2EE8710',
          'r1r11_fixtures.py':'73368AEBF232F20A052485A7255CE85723D2B3847414E21C485289435BA595F7',
        }
        for n,h in frozen.items(): self.assertEqual(hashlib.sha256((PACKAGE/n).read_bytes()).hexdigest().upper(),h,n)
        self.assertEqual(hashlib.sha256((PACKAGE/'minotauro_v004_runner.py').read_bytes()).hexdigest().upper(),
                         '514ED69A4B2D042EA5283334CABE4B7E4C2F4A9A3472EEF372CE3DB78D077FC0')

    def test_v5_h_phase_telemetry_monotonic(self):
        _,_,out=self.invoke('v5h_telemetry',workers=2,only='pending_cancel')
        rows=[json.loads(x) for x in (out/'TELEMETRY/R1R11_TRANSPORT.jsonl').read_text().splitlines()]
        stamps=[int(r['monotonic_ns']) for r in rows]
        self.assertEqual(stamps,sorted(stamps)); phases=[r.get('phase') for r in rows if r.get('event')=='SESSION_PHASE']
        self.assertIn('SESSION_START',phases); self.assertIn('STREAM_PIPELINE_READY',phases); self.assertIn('STREAM_PIPELINE_FINALIZED',phases)

    def test_v5_i_g4_controller_one_shot_contract(self):
        src=(PACKAGE/'r1r11_g4_controller.py').read_text(encoding='utf-8')
        for needle in ('PRIOR_G4_ARTIFACT','MANIFEST_ALREADY_CONSUMED','--stop-after','economic_diagnostic','A0_NOT_GO','DEV_BENCH_NOT_PASS_3_OF_3'):
            self.assertIn(needle,src)

    def test_v5_j_development_benchmark_contract(self):
        src=(PACKAGE/'r1r11_dev_benchmark.py').read_text(encoding='utf-8')
        self.assertIn('REQUIRED_SPEEDUP=1.667',src); self.assertIn('PAIRS=3',src)
        self.assertIn('heavy_byte_equal',src); self.assertIn('NON_GATE_DEVELOPMENT_BENCHMARK',src)


if __name__=='__main__': unittest.main(verbosity=2)
