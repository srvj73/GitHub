# Relatório causal — V004R1 sintética

## Escopo e conclusão

DECISION: implementação one-shot da arquitetura V004, exclusivamente sintética.
EVIDENCE: verificações pontuais de byte identity, recuperação, integridade,
memória e sinais nativos passaram nas revisões de desenvolvimento registradas.
UNKNOWN: desempenho da V004R1. G4 e homologação owner completa não foram executados.
Não há alegação de aceleração medida, PASS owner ou elegibilidade de mercado real.

## Fundamento da alteração

EVIDENCE histórica, já preservada: o perfil macro V003R2 registrou commit de
12,6457962 s em total de 18,3376825 s; havia quatro threads no mesmo processo,
GIL habilitado e grande retorno de trades por Pipe. Esses tempos não medem V004R1.

HYPOTHESIS preregistrada: processos distintos para os quatro streams permitem
CPU paralela de merge/JSON/gzip; scratch final de trades elimina sua grande
serialização, decode e ordenação global no coordinator. Sidecars e validações
adicionam custo real. Não foi atribuído ganho fictício a essas etapas, nem
deduzido um orçamento futuro a partir da medição histórica.

DECISION: manter a fronteira case_timings original, inclusive spawn, feed,
finish, staging, publicação, cleanup, EOF, CP e boundary final. Nenhum sleep,
caminho de benchmark ou modificação do oracle foi usado para performance.
O único hold adicionado é uma injeção explícita de lifecycle, usada para
entregar Ctrl+C enquanto helpers estão presentes; G4 nunca a solicita.

## Arquitetura e custódia

EVIDENCE no código: quinze grupos completos conservam o engine congelado.
O feed continua com seq/generation/CRC, digest, ACK de todos, r_global e
prefix snapshot físico. O commit usa resultados finais selados e sidecars
validados integralmente. Helpers não executam engine e gravam apenas stage.

Cada helper passa JSON por gzjson inalterado, fecha o stage, apresenta hashes,
prova de ordem e bindings e espera EXIT_ACK. Coordinator coleta memória,
confirma exit, revalida stage/scratch e só então prepara a transação.
Memória agrega workers/helpers; JOB_PEAK_BOUND_RUN conserva o maior bound
observado após suas saídas. Falha de probe é exit 2; excesso do cap é exit 3.

Journal exclusivo contém hash do CP anterior, snapshot/hash do CP seguinte e
hashes/tamanhos/contagens dos streams/receipt. Pending é validado antes do rename
atômico; checkpoint vem depois. Recovery recusa terceiro estado, sessão sem
journal/CP compatível e CP avançado sem sessão. Scratch é tratado por último.

EVIDENCE: a primitiva de FlushFileBuffers com handle gravável de diretório
funcionou no NTFS local. Isso verifica a chamada, não constitui teste físico de
queda de energia. Referências: [FlushFileBuffers](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-flushfilebuffers)
e [Directory Handles](https://learn.microsoft.com/en-us/windows/win32/fileio/obtaining-a-handle-to-a-directory).

## Falhas encontradas e fechamento causal

1. EVIDENCE: primeiro driver tentou enumerar sessions ausente antes do engine.
   Correção limitada à criação do diretório estrutural. Novo diferencial: 21
   arquivos iguais; tentativa anterior preservada.
2. EVIDENCE: teste adicional de finality escolheu pending_cancel, que produz
   zero trades. O assert não vazio impediu PASS vacuoso. Substituiu-se somente a
   fonte do teste por deferred existente; trades finais não vazios conferiram.
3. EVIDENCE: primeiro harness nativo observou o marker do segundo helper antes
   do quarto registro. O teste passou a esperar ambos, sem reduzir o assert.
4. EVIDENCE: Ctrl+C ainda não chegou ao coordinator. Controle isolado sem o
   executor reproduziu o problema com default_int_handler. Restaurar o atributo
   Win32 via SetConsoleCtrlHandler(NULL,FALSE) fez o mesmo controle sair 130.
   A correção foi aplicada ao Runtime normal. O teste final observou exit 130,
   quatro helpers encerrados e zero promoção; morte forçada do parent também
   encerrou os quatro filhos. [Semântica de herança documentada](https://learn.microsoft.com/windows/console/setconsolectrlhandler).

As saídas negativas não foram apagadas nem convertidas em PASS histórico.
CAUSAL_DEVELOPMENT_LOG.md e COMMANDS.json registram comandos, exits e durations.

## Validação e limites

EVIDENCE: V4_TESTS_01 passou 8 testes, com oito fronteiras de crash/recovery e
dez falhas de custódia/lifecycle. V4_FINALITY_02 reforçou a prova de trades.
V4_NEGATIVE_02 passou os três checks adicionais. V4_NATIVE_03 passou Ctrl+C
nativo e parent-death. TARGETED_INTEGRATION_01 passou 13 checks de integração,
transporte, congelamento e recursos. PS5.1 analisou 14 launchers sem executá-los.

O diferencial principal cobriu pending_cancel/deferred/target_passed/immediate_stop:
20 arquivos canônicos + checkpoint por cenário, total 84 comparações no conjunto
V4_TESTS_01. São evidências pontuais, não substituem G5 matrix nem G6 completo.
Não houve execução da fixture heavy. A presença de seu CSV gerado com 1200 ciclos
nas pastas de teste não significa replay ou medição de G4.

EVIDENCE: Python dos checks locais = 3.12.14 bundled; PS = 5.1.26100.9444.
UNKNOWN: certificação owner 3.14.7 e resultado G4. Runner owner está preparado
para checks V4 antes de G4 e para parar imediatamente se G4 <1,5x.
Nenhuma autorização real resulta desta entrega.
