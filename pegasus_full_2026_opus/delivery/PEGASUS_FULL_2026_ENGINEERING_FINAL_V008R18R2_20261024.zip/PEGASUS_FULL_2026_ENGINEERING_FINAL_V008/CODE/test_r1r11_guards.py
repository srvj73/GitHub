"""Operational negative controls; no market input and no owner authorization."""
import copy
import ctypes
import json
import multiprocessing.shared_memory as shm
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from minotauro_v004_core import ModelError,TickRecord
from minotauro_v005r1_r1r10_memory import MemoryCapSafeStop,MemoryProbeError
from r1r11_contract import validate_bindings,validate_coverage,CERT_SHA256
from r1r11_resources import grant_workers,JobMemory,process_snapshot,process_memory,RunLock,MIB
from r1r11_transport import write_slot,read_slot,EVENT_STAGE,SLOT_BYTES,HEADER


class Guards(unittest.TestCase):
    def snapshot(self):return {'cpu_logical':24,'ram_mib':64704,'coordinator_private':100*MIB,'shared_bytes':SLOT_BYTES,'external_heavy_workers':0}

    def test_grant_initial_registered_reserve_and_measured_next_session(self):
        s=self.snapshot()
        self.assertEqual(grant_workers(s,12)['granted'],3)
        self.assertEqual(grant_workers(s,12,100*MIB)['granted'],12)
        self.assertEqual(grant_workers(s,12)['ram_target_mib'],38822)
        self.assertEqual(grant_workers(s,12)['hard_cap_mib'],48528)

    def test_no_serial_fallback(self):
        s=self.snapshot();s['external_heavy_workers']=22
        with self.assertRaisesRegex(ModelError,'INSUFFICIENT_GRANT'):grant_workers(s,12)
        for n in (0,1,13,True):
            with self.assertRaises(ModelError):grant_workers(self.snapshot(),n)

    def test_target_pressure_reduces_only_next_grant(self):
        normal=grant_workers(self.snapshot(),12,100*MIB)
        pressure=grant_workers(self.snapshot(),12,12000*MIB)
        self.assertEqual(normal['granted'],12);self.assertEqual(pressure['granted'],3)

    def test_aggregate_cap_and_probe_fail_closed(self):
        with tempfile.TemporaryDirectory() as td:
            job=JobMemory(Path(td)/'m.jsonl');job.pids=[12,13];job.shared_bytes=4096
            sample={'private':17000*MIB,'peak':18000*MIB,'working_set':20*MIB}
            with patch('r1r11_resources.process_memory',side_effect=lambda pid:dict(sample,pid=pid)):
                with self.assertRaises(MemoryCapSafeStop):job.boundary('BATCH_ACK')
            row=json.loads(job.path.read_text().splitlines()[0])
            self.assertEqual(row['JOB_MEM'],3*17000*MIB+4096)
            self.assertEqual(row['JOB_PEAK_BOUND'],3*18000*MIB+4096)
            with patch('r1r11_resources.process_memory',side_effect=MemoryProbeError('probe')):
                with self.assertRaises(MemoryProbeError):job.boundary('PRE_COMMIT')

    def test_toolhelp_and_real_process_memory(self):
        import os
        self.assertIn(os.getpid(),[r['pid'] for r in process_snapshot()])
        sample=process_memory(os.getpid());self.assertGreater(sample['private'],0)

    def test_duplicate_lock_and_stale_scratch(self):
        with tempfile.TemporaryDirectory() as td:
            with RunLock(td):
                with self.assertRaises(ModelError):
                    with RunLock(td):pass
            (Path(td)/'_scratch'/'dead').mkdir(parents=True)
            with self.assertRaisesRegex(ModelError,'STALE_SCRATCH_PURGED'):
                with RunLock(td):pass
            with RunLock(td):pass

    def test_stale_lock_recovery_serialized_across_processes(self):
        import os
        import subprocess
        import sys
        with tempfile.TemporaryDirectory() as td:
            # PID zero is never a Python coordinator. Its presence in the OS
            # process table would intentionally fail closed, so use a PID
            # proved absent from the current process snapshot instead.
            absent = max(r['pid'] for r in process_snapshot()) + 1000000
            (Path(td)/'RUN.lock').write_text(json.dumps({'pid':absent,'run_instance':'stale'}))
            with RunLock(td):
                code = ('from r1r11_resources import RunLock; import sys; '
                        'lock=RunLock(sys.argv[1]); lock.__enter__()')
                p = subprocess.run([sys.executable,'-B','-c',code,td],capture_output=True,
                                   text=True,cwd=Path(__file__).resolve().parent,
                                   env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
                self.assertNotEqual(p.returncode,0)
                self.assertIn('RUN_MUTEX_ACTIVE_OR_UNAVAILABLE',p.stderr)
            with RunLock(td):pass

    def test_crc_generation_count_session_and_duplicate_slot(self):
        buf=bytearray(SLOT_BYTES);rec=TickRecord('2000-01-03',1,'2000.01.03 10:00:00',1,2,3,2,1.,1.,0)
        write_slot(buf,rec.session,1,1,[rec]);self.assertEqual(read_slot(buf,rec.session,1,1)[0][0],rec)
        for seq,gen,session in ((2,1,rec.session),(1,2,rec.session),(1,1,'bad')):
            with self.assertRaises(ModelError):read_slot(buf,session,seq,gen)
        buf[HEADER.size+len(rec.session)+10]^=1
        with self.assertRaisesRegex(ModelError,'CRC'):read_slot(buf,rec.session,1,1)

    def test_certificate_bindings_and_missing_coverage(self):
        bindings=validate_bindings()
        m={'bindings':bindings,'events':[{'event':n,'classification':'STRUCTURALLY_UNREACHABLE' if n=='AMBIGUOUS_MULTI_SIGNAL' else 'COVERED',
                                        'certificate_sha256':CERT_SHA256,'occurrences':[]} for n in EVENT_STAGE]}
        with self.assertRaises(ModelError):validate_coverage(m)
        bad=copy.deepcopy(m);bad['events'].append(bad['events'][0])
        with self.assertRaisesRegex(ModelError,'DUPLICATE'):validate_coverage(bad)
        bad=copy.deepcopy(m);bad['bindings']['rr_min']=2
        with self.assertRaisesRegex(ModelError,'BINDINGS'):validate_coverage(bad)
        # Contradictory ambiguous observation is independently tested even when
        # every other row has syntactically present occurrence metadata.
        for row in m['events']:
            row['occurrences']=[{'fixture':'x','ordinal':1,'oracle_file_sha256':'x','row_index':0,'cell_ids':[]}]
        with self.assertRaisesRegex(ModelError,'UNREACHABLE_CONTRADICTION'):validate_coverage(m)


if __name__=='__main__':unittest.main(verbosity=2)
