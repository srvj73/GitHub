from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import argparse, csv, gzip, hashlib, json, os, shutil, tempfile, time, traceback

from minotauro_v004_core import ModelError, valid_cells, BASELINE_CELL_ID, pnl_units, ENTRY_COST_UNITS, EXIT_COST_UNITS
from minotauro_v004_io import load_d1, write_csv
from minotauro_v004_metrics import pf_ok
from minotauro_v004_preflight import PHASES, build_expected, _validate_d1
from minotauro_v005r1_r23_contract import SPEC_SHA256
# The frozen parser/version helpers live in the runner/contract modules.
import minotauro_v004_runner as base
from minotauro_v005r1_r23_contract import (
    canonical_json_hash, config_hash, core_imported_definitions_hash,
    runner_identity, sha256_file, write_json_atomic_canonical,
    EXPECTED_PREFLIGHT_SHA256, EXPECTED_IO_SHA256, EXPECTED_CORE_IMPORTED_DEFINITIONS_SHA256,
)
from minotauro_v005r1_r23_outputs import (
    iter_committed_trades, write_grid_cells, write_model_assumptions,
    write_sha_manifest, write_trades_csv_streaming, reconstruct_max_dd_from_persisted,
)
from r1r11_resources import RunLock, JobMemory, HARD_CAP_MIB
from r1r11_coordinator import Runtime
from r1r11_v4_transaction import prepare_volume, recover

PACKAGE=Path(__file__).resolve().parent
PARSER_VERSION=base.PARSER_VERSION
PARENT_2025=Path(r'D:\MinotauroRuns\MINOTAURO_R1R11_PERF_NEXT_V003R1_W15_B256_20260929')
PREFLIGHT_SOURCE_DEFAULT=None
DEFAULT_OUT=Path(r'D:\MinotauroRuns\MINOTAURO_R1R11_FULL_2026_R3_RELEASE_20261001\CONTROL')
EXPECTED_PARENT_HOMOLOGATION_SHA='A0BD69C2907C0526701E62B51DEDDF06304DD1C0B0E90AA81D73FF20D10909F0'
R3_G0_SHA256='27155865D7BFD2A98A2B912DB203EFC11E493FFD38B1988385E74F9C41F0D1FF'
G7_OFFICIAL_RECEIPT_SHA256='51D35FD2E4ADBB0E63991962EAC2947856B7AD7635239BED1EF32CE0AA739F88'
PHASE_ORDER=('B','C')
REQUIRED_PREFLIGHT=('PHASE_STATUS.json','PREFLIGHT_FAILURES.json','SOURCE_INVENTORY.json',
                    'CUTOFF_LATENCY_DIAGNOSTICS.csv')


def _atomic(path: Path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    write_json_atomic_canonical(path,obj)


def _sha(path: Path)->str:
    return sha256_file(path)


def verify_package()->str:
    mf=PACKAGE/'SHA256SUMS.txt'; listed={}
    for line in mf.read_text(encoding='ascii').splitlines():
        if not line.strip(): continue
        h,n=line.split(None,1); n=n.strip().removeprefix('./'); p=(PACKAGE/n).resolve()
        if not p.is_relative_to(PACKAGE) or n in listed or not p.is_file() or _sha(p)!=h.upper():
            raise ModelError('PACKAGE_MANIFEST_FAILURE '+n)
        listed[n]=h.upper()
    actual={p.relative_to(PACKAGE).as_posix() for p in PACKAGE.rglob('*') if p.is_file() and p!=mf}
    if set(listed)!=actual:
        raise ModelError('PACKAGE_MANIFEST_SET_MISMATCH '+repr(sorted(actual^set(listed))[:20]))
    return _sha(mf)


def cfg(out: Path)->dict:
    return {'ticks_root':r'D:\Base CSV\WIN@N','m1_root':r'D:\Base CSV\WIN@N_M1',
            'ind_d1':r'D:\Base CSV\IND@N\IND@N.csv','out_root':str(out),
            'memory_cap_mib':48528,'correctness_fast_full_v001':True}


def validate_parent_2025():
    hom=PARENT_2025/'GATES'/'CORRECTNESS_FULL_HOMOLOGATION_RECEIPT.json'
    freeze=PARENT_2025/'PHASE_A'/'SELECTION_FREEZE.json'
    if not hom.is_file() or _sha(hom)!=EXPECTED_PARENT_HOMOLOGATION_SHA:
        raise ModelError('PARENT_2025_HOMOLOGATION_IDENTITY_MISMATCH')
    h=json.loads(hom.read_text(encoding='utf-8'))
    if h.get('CORRECTNESS_FULL_HOMOLOGATION')!='PASS' or int(h.get('sessions',-1))!=250:
        raise ModelError('PARENT_2025_HOMOLOGATION_NOT_PASS')
    if not freeze.is_file(): raise ModelError('PARENT_2025_SELECTION_FREEZE_MISSING')
    f=json.loads(freeze.read_text(encoding='utf-8'))
    given=str(f.get('freeze_sha256','')).upper(); body=dict(f); body.pop('freeze_sha256',None)
    if given!=canonical_json_hash(body): raise ModelError('PARENT_2025_FREEZE_SELF_HASH_MISMATCH')
    status=str(f.get('status',''))
    selected=f.get('selected_cell_id')
    if status=='SELECTED':
        if not selected: raise ModelError('PARENT_2025_SELECTED_ID_MISSING')
    elif status in ('NO_CANDIDATE','INSUFFICIENT_EVIDENCE'):
        if selected is not None: raise ModelError('PARENT_2025_UNEXPECTED_SELECTED_ID')
    else:
        raise ModelError('PARENT_2025_FREEZE_STATUS '+status)
    allcells=valid_cells(); known={c.cell_id for c in allcells}
    ids=[BASELINE_CELL_ID]
    if selected and selected!=BASELINE_CELL_ID: ids.append(str(selected))
    if any(x not in known for x in ids): raise ModelError('PARENT_2025_FREEZE_CELL_UNKNOWN')
    keep=set(ids); cells=[c for c in allcells if c.cell_id in keep]
    if [c.cell_id for c in cells] != [x for x in [c.cell_id for c in allcells] if x in keep]:
        raise ModelError('FROZEN_CELL_ORDER_INTERNAL')
    return {'freeze':f,'freeze_path':freeze,'freeze_sha256':_sha(freeze),'cells':cells,'selected':selected,'status':status,
            'homologation_sha256':_sha(hom)}


def _required_names(phase):
    return (*REQUIRED_PREFLIGHT,f'SESSION_CALENDAR_PHASE_{phase}.csv',f'EXPECTED_SESSIONS_PHASE_{phase}.csv',f'R3_CUTOFF_SIDECARS_PHASE_{phase}.jsonl')


def _copy_or_validate(src: Path,dst: Path):
    if dst.exists():
        if _sha(dst)!=_sha(src): raise ModelError('PREFLIGHT_DEST_CONFLICT '+str(dst))
        return
    dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)


def prepare_preflight(out: Path, phase: str, preflight_source: Path):
    if phase not in PHASE_ORDER: raise ModelError('PHASE_INVALID')
    if preflight_source is None: raise ModelError('PREFLIGHT_SOURCE_REQUIRED')
    src=preflight_source/f'PHASE_{phase}'; dest=out/'PREFLIGHT'/f'PHASE_{phase}'
    for name in _required_names(phase):
        if not (src/name).is_file():
            raise ModelError(f'PREFLIGHT_SOURCE_PHASE_{phase}_ARTIFACT_MISSING {name}')
    st=json.loads((src/'PHASE_STATUS.json').read_text(encoding='utf-8'))
    if st.get('PHASE_DATA_STATUS')!='PASS': raise ModelError(f'PREFLIGHT_SOURCE_PHASE_{phase}_NOT_PASS')
    failures=json.loads((src/'PREFLIGHT_FAILURES.json').read_text(encoding='utf-8'))
    if failures not in ([],None): raise ModelError(f'PREFLIGHT_SOURCE_PHASE_{phase}_FAILURES_NONEMPTY')
    for name in _required_names(phase): _copy_or_validate(src/name,dest/name)
    # Cheap current-authority re-derivation: M1 session universe + D1 predecessor.
    with tempfile.TemporaryDirectory(prefix=f'minotauro_2026_{phase}_') as td:
        tmp=Path(td)/f'EXPECTED_SESSIONS_PHASE_{phase}.csv'
        rows=build_expected(Path(r'D:\Base CSV\WIN@N_M1'),phase,tmp)
        if tmp.read_bytes()!=(dest/f'EXPECTED_SESSIONS_PHASE_{phase}.csv').read_bytes():
            raise ModelError(f'PHASE_{phase}_EXPECTED_SESSIONS_DRIFT')
    d1=load_d1(Path(r'D:\Base CSV\IND@N\IND@N.csv'))
    good,dfail=_validate_d1(rows,d1)
    if dfail or len(good)!=len(rows): raise ModelError(f'PHASE_{phase}_D1_REVALIDATION_FAILURES={len(dfail)}')
    with (dest/f'SESSION_CALENDAR_PHASE_{phase}.csv').open('r',encoding='utf-8-sig',newline='') as f:
        cal=list(csv.DictReader(f,delimiter=';'))
    if len(cal)!=len(rows) or [r['session_date'] for r in cal] != [r['session_date'] for r in rows]:
        raise ModelError(f'PHASE_{phase}_CALENDAR_SESSION_SET_MISMATCH')
    lo,hi=PHASES[phase]
    if any(not (lo<=r['session_date']<=hi) for r in cal): raise ModelError(f'PHASE_{phase}_CALENDAR_RANGE')
    print(f'PREFLIGHT_PHASE_{phase}_REUSE=PASS sessions={len(cal)} source={src}',flush=True)
    return dest,cal,rows,d1


def build_binding(out: Path, phase: str, preflight: Path, cells, parent):
    po=out/f'PHASE_{phase}'; po.mkdir(parents=True,exist_ok=True)
    # Copy frozen phase evidence into the economic phase root.
    for name in _required_names(phase): _copy_or_validate(preflight/name,po/name)
    shutil.copy2(preflight/'SOURCE_INVENTORY.json',po/f'SOURCE_INVENTORY_PHASE_{phase}.json') if not (po/f'SOURCE_INVENTORY_PHASE_{phase}.json').exists() else None
    cal_path=po/f'SESSION_CALENDAR_PHASE_{phase}.csv'
    exp_path=po/f'EXPECTED_SESSIONS_PHASE_{phase}.csv'
    with cal_path.open('r',encoding='utf-8-sig',newline='') as f: cal=list(csv.DictReader(f,delimiter=';'))
    d1=load_d1(Path(r'D:\Base CSV\IND@N\IND@N.csv'))
    extract=[]
    for er in cal:
        prev=er['expected_previous_session_date']; bar=d1[prev]
        extract.append({'session_date':er['session_date'],'expected_previous_session_date':prev,
                        'open_micro':int(bar.open_micro),'high_micro':int(bar.high_micro),
                        'low_micro':int(bar.low_micro),'close_micro':int(bar.close_micro)})
    d1_path=po/f'D1_PREDECESSOR_EXTRACT_PHASE_{phase}.csv'
    write_csv(d1_path,['session_date','expected_previous_session_date','open_micro','high_micro','low_micro','close_micro'],extract)
    inv=json.loads((po/'SOURCE_INVENTORY.json').read_text(encoding='utf-8'))
    invmap={str(r['file']):r for r in inv.get('files',[])}
    tick_paths=sorted({str(r['tick_file']) for r in cal})
    tick=[]
    for raw in tick_paths:
        rr=invmap.get(raw)
        if rr is None or len(str(rr.get('sha256','')))!=64: raise ModelError(f'PHASE_{phase}_TICK_INVENTORY_MISSING '+raw)
        p=Path(raw)
        if not p.is_file(): raise ModelError(f'PHASE_{phase}_TICK_FILE_MISSING '+raw)
        tick.append({'path':raw,'size':int(p.stat().st_size),'sha256':str(rr['sha256']).upper()})
    binding={'schema':'MINOTAURO_RUN_SOURCE_BINDING_2026_R3_V001','phase':phase,
             'spec_sha256':SPEC_SHA256,'r3_g0_sha256':R3_G0_SHA256,'g7_official_receipt_sha256':G7_OFFICIAL_RECEIPT_SHA256,'preflight_py_sha256':_sha(PACKAGE/'minotauro_v004_preflight.py'),
             'io_py_sha256':_sha(PACKAGE/'minotauro_v004_io.py'),
             'core_imported_definitions_sha256':core_imported_definitions_hash(PACKAGE/'minotauro_v004_core.py'),
             'preflight_status_sha256':_sha(po/'PHASE_STATUS.json'),'preflight_failures_sha256':_sha(po/'PREFLIGHT_FAILURES.json'),
             'session_calendar_sha256':_sha(cal_path),'expected_sessions_sha256':_sha(exp_path),
             'source_inventory_sha256':_sha(po/'SOURCE_INVENTORY.json'),'cutoff_latency_diagnostics_sha256':_sha(po/'CUTOFF_LATENCY_DIAGNOSTICS.csv'),
             'r3_cutoff_sidecars_sha256':_sha(po/f'R3_CUTOFF_SIDECARS_PHASE_{phase}.jsonl'),
             'd1_predecessor_extract_sha256':_sha(d1_path),'ind_d1_path':r'D:\Base CSV\IND@N\IND@N.csv',
             'ind_d1_sha256':_sha(Path(r'D:\Base CSV\IND@N\IND@N.csv')),'tick_files':tick,
             'parent_2025_freeze_sha256':parent['freeze_sha256'],'parent_2025_homologation_sha256':parent['homologation_sha256'],
             'frozen_cell_ids':[c.cell_id for c in cells],'status':'PASS_SEALED_2026'}
    binding['binding_content_sha256']=canonical_json_hash(binding,exclude_keys={'binding_content_sha256'})
    bp=po/f'RUN_SOURCE_BINDING_{phase}.json'; _atomic(bp,binding)
    grid=write_grid_cells(po/'GRID_CELLS.csv'); write_model_assumptions(po)
    runner_hash,runner_manifest=runner_identity(PACKAGE)
    (po/'SPEC_HASH.txt').write_text(SPEC_SHA256+'\n',encoding='ascii')
    (po/'RUNNER_HASH.txt').write_text(runner_hash+'\n',encoding='ascii')
    identity={'spec_sha256':SPEC_SHA256,'runner_sha256':runner_hash,'runner_manifest':runner_manifest,
              'grid_sha256':grid,'preflight_status_sha256':binding['preflight_status_sha256'],
              'session_calendar_sha256':binding['session_calendar_sha256'],'expected_sessions_sha256':binding['expected_sessions_sha256'],
              'source_inventory_sha256':binding['source_inventory_sha256'],'r3_cutoff_sidecars_sha256':binding['r3_cutoff_sidecars_sha256'],'run_source_binding_sha256':_sha(bp),
              'config_sha256':config_hash(cfg(out)),'parser_version':PARSER_VERSION}
    runtime_hashes=base._runtime_module_hashes(PACKAGE)
    if runtime_hashes['preflight_py_sha256']!=EXPECTED_PREFLIGHT_SHA256 or runtime_hashes['io_py_sha256']!=EXPECTED_IO_SHA256 or runtime_hashes['core_imported_definitions_sha256']!=EXPECTED_CORE_IMPORTED_DEFINITIONS_SHA256:
        raise ModelError('FROZEN_ECONOMIC_MODULE_IDENTITY_MISMATCH')
    return po,binding,identity,runtime_hashes,cal,d1_path


def _metric_aggregate(cells,out: Path,sessions,months,maxdd):
    data={c.cell_id:{'trade_count':0,'sessions':set(),'pos':0,'neg':0,'net':0,'monthly':defaultdict(int),'daily':defaultdict(int)} for c in cells}
    for tr in iter_committed_trades(out,sessions):
        if tr.get('net_pnl_units') is None: continue
        cid=tr['cell_id']; x=data[cid]; net=int(tr['net_pnl_units']); s=tr['session']
        x['trade_count']+=1;x['sessions'].add(s);x['net']+=net;x['monthly'][s[:7]]+=net;x['daily'][s]+=net
        if net>0:x['pos']+=net
        elif net<0:x['neg']+=-net
    result={}
    for c in cells:
        x=data[c.cell_id]; vals=[x['monthly'].get(m,0) for m in months]
        days=sorted((v for v in x['daily'].values() if v>0),reverse=True);top5=sum(days[:5]);posdays=sum(days)
        result[c.cell_id]={'cell_id':c.cell_id,'trade_count':x['trade_count'],'sessions_with_trade':len(x['sessions']),
          'net_units':x['net'],'positive_units':x['pos'],'negative_abs_units':x['neg'],'pf_num':x['pos'],'pf_den':x['neg'],
          'max_dd_units':int(maxdd.get(c.cell_id,0)),'positive_months':sum(v>0 for v in vals),
          'months_with_trade':len({s[:7] for s in x['sessions']}),'monthly_units':vals,
          'top5_positive_days_units':top5,'sum_positive_days_units':posdays,'net_without_top5_units':x['net']-top5}
    return result


def _public(m): return {k:v for k,v in m.items() if k!='monthly_units'}


def _ledger(out: Path,sessions,dirname):
    dst=out/dirname; dst.mkdir(exist_ok=True)
    for s in sessions:
        src=out/'sessions'/s/'events.jsonl.gz'; target=dst/f'{s}.jsonl.gz'
        if target.exists(): target.unlink()
        try: os.link(src,target)
        except OSError: shutil.copy2(src,target)


def finalize_phase(out: Path,phase: str,cells,parent):
    po=out/f'PHASE_{phase}'; cp=json.loads((po/'CHECKPOINT.json').read_text(encoding='utf-8'))
    sessions=sorted(cp.get('completed',[]))
    with (po/f'EXPECTED_SESSIONS_PHASE_{phase}.csv').open('r',encoding='utf-8-sig',newline='') as f: expected=list(csv.DictReader(f,delimiter=';'))
    if sessions!=[r['session_date'] for r in expected]: raise ModelError(f'PHASE_{phase}_FINAL_SESSION_SET')
    expected_months=8 if phase=='B' else 1
    if len(cp.get('verified_months',{}))!=expected_months: raise ModelError(f'PHASE_{phase}_MONTH_HASH_COUNT')
    reconstructed=reconstruct_max_dd_from_persisted(po,cells,sessions)
    for i,c in enumerate(cells):
        if int(cp['maxdd'][i])!=int(reconstructed[c.cell_id]): raise ModelError(f'PHASE_{phase}_EQUITY_LOSSLESS '+c.cell_id)
    months=[f'2026-{m:02d}' for m in range(1,9)] if phase=='B' else ['2026-09']
    metrics=_metric_aggregate(cells,po,sessions,months,{c.cell_id:int(cp['maxdd'][i]) for i,c in enumerate(cells)})
    if phase=='B':
        rows=[_public(metrics[c.cell_id]) for c in cells]
        write_csv(po/'SUMMARY_2026_FROZEN_ONLY.csv',list(rows[0].keys()),rows)
        monthly=[]
        for c in cells:
            for m,v in zip(months,metrics[c.cell_id]['monthly_units']): monthly.append({'cell_id':c.cell_id,'month':m,'net_units':int(v)})
        write_csv(po/'MONTHLY_2026_FROZEN_ONLY.csv',['cell_id','month','net_units'],monthly)
        write_trades_csv_streaming(po/'TRADES_2026_FROZEN_ONLY.csv',po,sessions)
        _ledger(po,sessions,'EVENT_LEDGER_2026_FROZEN_ONLY')
        base_m=metrics[BASELINE_CELL_ID]; sid=parent['selected']
        if sid and sid!=BASELINE_CELL_ID:
            sel=metrics[sid]
            gates={'selected_net_positive':sel['net_units']>0,'selected_net_gt_baseline':sel['net_units']>base_m['net_units'],
                   'selected_dd_lte_baseline':sel['max_dd_units']<=base_m['max_dd_units'],
                   'selected_trades_gte_100':sel['trade_count']>=100,'selected_sessions_gte_40':sel['sessions_with_trade']>=40,
                   'selected_positive_months_gte_6':sel['positive_months']>=6,'selected_net_without_top5_positive':sel['net_without_top5_units']>0}
            status='CONFIRMED' if all(gates.values()) else 'NOT_CONFIRMED'
        else:
            sel=base_m; gates={'baseline_net_positive':base_m['net_units']>0,'baseline_trades_gte_100':base_m['trade_count']>=100,
                  'baseline_sessions_gte_40':base_m['sessions_with_trade']>=40,'baseline_positive_months_gte_6':base_m['positive_months']>=6,
                  'baseline_net_without_top5_positive':base_m['net_without_top5_units']>0,'baseline_dd_evaluable':isinstance(base_m['max_dd_units'],int)}
            status='BASELINE_RETAINED_CONFIRMED' if all(gates.values()) else 'BASELINE_RETAINED_NOT_CONFIRMED'
        gate={'schema':'MINOTAURO_CONFIRMATION_GATE_2026_V001','data_status':'PASS','status':status,
              'parent_selection_status':parent['status'],'selected_cell_id':sid,'baseline_cell_id':BASELINE_CELL_ID,
              'gates':gates,'baseline_metrics':_public(base_m),'selected_metrics':_public(sel),
              'sessions':len(sessions),'range':[sessions[0],sessions[-1]]}
        _atomic(po/'CONFIRMATION_GATE.json',gate)
    else:
        rows=[_public(metrics[c.cell_id]) for c in cells]
        write_csv(po/'SUMMARY_SEP2026_FROZEN_ONLY.csv',list(rows[0].keys()),rows)
        write_trades_csv_streaming(po/'TRADES_SEP2026_FROZEN_ONLY.csv',po,sessions)
        _ledger(po,sessions,'EVENT_LEDGER_SEP2026_FROZEN_ONLY')
        gate={'schema':'MINOTAURO_SEP2026_STRESS_V001','status':'PASS_DESCRIPTIVE_ONLY','selected_cell_id':parent['selected'],
              'baseline_cell_id':BASELINE_CELL_ID,'sessions':len(sessions),'range':[sessions[0],sessions[-1]],
              'metrics':{c.cell_id:_public(metrics[c.cell_id]) for c in cells}}
        _atomic(po/'SEP2026_STRESS_REPORT.json',gate)
    # Master manifest excludes checkpoint and itself, matching Run-A convention.
    master=po/'SHA256SUMS.txt'
    files=[p for p in po.rglob('*') if p.is_file() and p.name!='CHECKPOINT.json' and not p.name.endswith('.tmp') and p!=master and p.name!=f'PHASE_{phase}_FINAL_REPORT.json']
    write_sha_manifest(master,files,po)
    report={'schema':f'MINOTAURO_PHASE_{phase}_FINAL_REPORT_V001','status':'PASS','phase':phase,'sessions':len(sessions),
            'first_session':sessions[0],'last_session':sessions[-1],'verified_months':len(cp.get('verified_months',{})),
            'checkpoint_sha256':_sha(po/'CHECKPOINT.json'),'master_manifest_sha256':_sha(master),
            'frozen_cell_ids':[c.cell_id for c in cells]}
    if phase=='B': report['confirmation_gate_sha256']=_sha(po/'CONFIRMATION_GATE.json')
    else: report['sep_stress_report_sha256']=_sha(po/'SEP2026_STRESS_REPORT.json')
    _atomic(po/f'PHASE_{phase}_FINAL_REPORT.json',report)
    print(f'PHASE_{phase}_FINALIZE=PASS sessions={len(sessions)} range={sessions[0]}..{sessions[-1]}',flush=True)
    return report


def run_phase(out: Path,phase: str,cells,binding,identity,runtime_hashes,calendar,d1_path,workers,batch_rows):
    po=out/f'PHASE_{phase}'
    if (po/f'PHASE_{phase}_FINAL_REPORT.json').is_file():
        print(f'PHASE_{phase}=RESUME_FINAL_PASS',flush=True); return
    d1=load_d1(Path(r'D:\Base CSV\IND@N\IND@N.csv')); d1_extract=load_phase_d1_extract(out,phase,d1_path,binding,calendar)
    tick_hash_map={str(r['path']):str(r['sha256']).upper() for r in binding['tick_files']}
    from r1r11_prefix import PhysicalPrefixTap
    from r1r11_fast_resume import iter_tick_file_from_offset,rehydrate_prefix_tracker,write_anchor_checkpoint,clear_anchor_checkpoint,make_anchor,validate_fingerprint
    with RunLock(out) as lock:
        monitor=JobMemory(out/'TELEMETRY'/f'RUN_{phase}_R1R11_MEMORY.jsonl')
        runtime=Runtime(lock,monitor,workers,batch_rows,mode=f'RUN_{phase}',transaction_root=po)
        try:
            for row in calendar: runtime.set_synthetic_calendar_row(row['session_date'],row)
            prepare_volume(po,runtime.scratch); recover(po)
            cp_path=po/'CHECKPOINT.json'; cp=base._load_checkpoint(cp_path,phase,cells,identity,runtime_hashes)
            (po/'sessions').mkdir(exist_ok=True)
            if {p.name for p in (po/'sessions').iterdir() if p.is_dir()}!=set(cp['completed']):
                raise ModelError('SESSION_CHECKPOINT_WITHOUT_JOURNAL')
            done=set(cp['completed']); base._verify_committed_trades_present(po,done); runtime.verify_committed(po,cp)
            target={r['session_date'] for r in calendar}
            if not done.issubset(target): raise ModelError('CHECKPOINT_CONTAINS_OUT_OF_SCOPE_SESSION')
            by_file=defaultdict(list)
            for row in calendar: by_file[Path(row['tick_file'])].append(row)
            sorted_files=sorted(by_file.items(),key=lambda kv:str(kv[0]))
            active=[]
            for tp,mrows in sorted_files:
                eh=tick_hash_map.get(str(tp))
                if not eh: raise ModelError('TICK_NOT_BOUND '+str(tp))
                if base._month_requires_read(mrows,done,cp.get('verified_months',{}),tp,eh): active.append((tp,mrows))
            total_bytes=sum(tp.stat().st_size for tp,_ in active); completed_bytes=0; started=time.monotonic(); initial_done=len(done)
            runtime.configure_status(total=len(calendar),committed=len(done))
            print(f'RUN_START mode=RUN_{phase} sessions={len(calendar)} remaining_sessions={len(calendar)-len(done)} files_to_read_or_verify={len(active)} total_gib={total_bytes/1024**3:.3f} frozen_cells={len(cells)}',flush=True)
            monitor.boundary('RUN_START',None,len(done))
            integral_ids={c.cell_id for c in cells}
            for tp,mrows in sorted_files:
                mrows=sorted(mrows,key=lambda r:r['session_date']); wanted={r['session_date'] for r in mrows if r['session_date'] not in done}
                expected_hash=tick_hash_map[str(tp)]; already=cp.get('verified_months',{}).get(str(tp))==expected_hash
                if not wanted and already:
                    print(f'MONTH_SKIP_ALL_COMMITTED_AND_HASH_VERIFIED file={tp.name}',flush=True); continue
                row_by={r['session_date']:r for r in mrows}; current=None; eng=None; lasto=0; lastdt=''; early=False
                expected_prefixes=base._session_prefix_expectations(po,mrows,done,tp)
                resume=cp.get('source_resume') if isinstance(cp.get('source_resume'),dict) else None; start_offset=0
                if resume and resume.get('fingerprint',{}).get('path')==str(tp.resolve()):
                    rs=str(resume.get('session','')); months=[r['session_date'] for r in mrows]; dim=sorted(set(months)&done)
                    valid_stale=(rs in done and (not dim or rs==dim[-1]))
                    if rs not in wanted and not valid_stale: raise ModelError('SOURCE_RESUME_SESSION_NOT_PENDING_OR_LAST_COMMITTED '+rs)
                    start_offset=int(resume.get('offset',-1));validate_fingerprint(tp,resume['fingerprint'])
                    h=rehydrate_prefix_tracker(tp,resume,expected_prefixes)
                    print(f'SOURCE_RESUME_REHYDRATE=PASS file={tp.name} session={rs} offset={start_offset}',flush=True)
                else: h=base._PrefixHashTracker(expected_prefixes)
                tap=PhysicalPrefixTap(h); starts={}
                def boundary_cb(session,offset): starts[str(session)]=int(offset)
                file_size=tp.stat().st_size
                print(f'RUN_MONTH_START mode=RUN_{phase} file={tp.name} size_gib={file_size/1024**3:.3f} wanted_sessions={len(wanted)} verify_only={"YES" if not wanted else "NO"}',flush=True)
                def progress_cb(file_bytes,raw_rows,file_size_cb,is_final):
                    if is_final or file_bytes==0 or file_bytes%(256*1024*1024)<131072:
                        base._run_progress(f'RUN_{phase}',tp.name,completed_bytes+file_bytes,total_bytes,file_bytes,file_size_cb,raw_rows,len(done),len(calendar),started,None,initial_done)
                try:
                    for rec in iter_tick_file_from_offset(tp,start_offset=start_offset,include_sessions=wanted,hasher=tap,progress_cb=progress_cb,session_boundary_cb=boundary_cb):
                        s=rec.session
                        if s not in wanted: continue
                        if current is None:
                            if s not in starts: raise ModelError('SOURCE_RESUME_BOUNDARY_MISSING '+s)
                            write_anchor_checkpoint(cp_path,cp,make_anchor(tp,s,starts[s])); row=row_by[s];bar=d1[row['expected_previous_session_date']]
                            base._verify_d1_bar(s,row,bar,d1_extract)
                            eng=runtime.engine(s,bar,cells,int(row['cutoff_msc']),True,cp['cash'],cp['hwm'],cp['maxdd'],cp['regime_min'],cp['closed_hwm'],cp['closed_maxdd'],integral_ids,source_tracker=tap)
                            current=s;lasto=0;lastdt=s.replace('-','.')+' 18:03:00';early=False
                            print(f'SESSION_START mode=RUN_{phase} session={s} cells={len(cells)}',flush=True)
                        elif s!=current:
                            if not early:
                                res=eng.finish(lasto,lastdt);base._commit_session(po,current,res,cells,cp,done,row_by[current],cp_path,tp,h,runtime=runtime);runtime.committed(len(done));monitor.boundary('SESSION_COMMIT',current,len(done))
                            wanted.discard(current); row=row_by[s]
                            if s not in starts: raise ModelError('SOURCE_RESUME_BOUNDARY_MISSING '+s)
                            write_anchor_checkpoint(cp_path,cp,make_anchor(tp,s,starts[s]));bar=d1[row['expected_previous_session_date']];base._verify_d1_bar(s,row,bar,d1_extract)
                            eng=runtime.engine(s,bar,cells,int(row['cutoff_msc']),True,cp['cash'],cp['hwm'],cp['maxdd'],cp['regime_min'],cp['closed_hwm'],cp['closed_maxdd'],integral_ids,source_tracker=tap)
                            current=s;lasto=0;lastdt=s.replace('-','.')+' 18:03:00';early=False
                            print(f'SESSION_START mode=RUN_{phase} session={s} cells={len(cells)}',flush=True)
                        if early: continue
                        lasto=rec.ordinal;lastdt=rec.date_time
                        if not eng.process_record(rec):
                            res=eng.finish(lasto,lastdt);base._commit_session(po,current,res,cells,cp,done,row_by[current],cp_path,tp,h,runtime=runtime);runtime.committed(len(done));wanted.discard(current);early=True;monitor.boundary('SESSION_COMMIT',current,len(done))
                    if current is not None and current in wanted and not early:
                        res=eng.finish(lasto,lastdt);base._commit_session(po,current,res,cells,cp,done,row_by[current],cp_path,tp,h,runtime=runtime);runtime.committed(len(done));wanted.discard(current);monitor.boundary('SESSION_COMMIT',current,len(done))
                except KeyboardInterrupt:
                    runtime.safe_stop_requested=True; print(f'SAFE_STOP_REQUESTED=YES phase={phase} session={current or "NONE"}',flush=True); raise
                h.assert_all_expected_checked(); actual=h.hexdigest().upper()
                if actual!=expected_hash: raise ModelError(f'RUN_BLOCKED_TICK_DRIFT file={tp} expected={expected_hash} got={actual}')
                cp.setdefault('verified_months',{})[str(tp)]=actual; clear_anchor_checkpoint(cp_path,cp);completed_bytes+=tp.stat().st_size
                print(f'RUN_MONTH_HASH_VERIFIED phase={phase} file={tp.name} sha256={actual}',flush=True)
                if wanted: raise ModelError('RUN_MONTH_MISSING_EXPECTED_SESSIONS '+','.join(sorted(wanted)))
                monitor.boundary('MONTH_VERIFIED',None,len(done))
            if len(done)!=len(calendar): raise ModelError(f'RUN_{phase}_INCOMPLETE_SESSIONS got={len(done)} expected={len(calendar)}')
            if len(cp.get('verified_months',{}))!=len(sorted_files): raise ModelError(f'RUN_{phase}_MONTH_HASH_INCOMPLETE')
            runtime.status(f'RUN_{phase}_PASS',COMMITTED=len(done),TOTAL=len(calendar),ACTIVE=0,READY_WAITING=0,RATE='UNKNOWN',ETA='DONE',FINISH='NOW',CHECKPOINT=max(done),SAFE_STOP='NO')
            print(f'RUN_{phase}=PASS sessions={len(done)}',flush=True)
        finally:
            runtime.close()


def _r3_final_disclosure(out: Path,cells):
    sidecars=[]; calendars=[]
    all_sessions=[]
    for phase in PHASE_ORDER:
        po=out/f'PHASE_{phase}'
        with (po/f'R3_CUTOFF_SIDECARS_PHASE_{phase}.jsonl').open('r',encoding='utf-8') as f:
            for line in f:
                if line.strip(): sidecars.append(json.loads(line))
        with (po/f'SESSION_CALENDAR_PHASE_{phase}.csv').open('r',encoding='utf-8-sig',newline='') as f:
            calendars.extend(list(csv.DictReader(f,delimiter=';')))
        cp=json.loads((po/'CHECKPOINT.json').read_text(encoding='utf-8'))
        all_sessions.extend(sorted(cp.get('completed',[])))
    levels={'L0':0,'L1':0,'BLOCKED':0};l1_sessions=set(); side_rows=[]
    for sc in sidecars:
        for side in ('LONG','SHORT'):
            ev=sc[side];kind=str(ev['x_kind']);levels[kind]=levels.get(kind,0)+1
            if kind=='L1':l1_sessions.add(sc['session'])
            side_rows.append({'session':sc['session'],'side':side,'level':kind,'availability_phase':'POST_RECORD',
                              'x_ordinal':int(ev['x_ordinal']),'x_time_msc':int(ev['x_time_msc']),
                              'x_price_micro':int(ev['x_price_micro']),'e1_latency_ms':int(ev['x_time_msc'])-int(sc['cutoff_msc']) if kind=='L1' else None})
    anchor={r['session_date']:{'bid_micro':r.get('r3_pre_latch_anchor_bid_micro'),'ask_micro':r.get('r3_pre_latch_anchor_ask_micro'),
                               'anchor_msc':r.get('r3_pre_latch_anchor_msc'),'spread_ticks':r.get('r3_pre_latch_anchor_spread_ticks')}
            for r in calendars if r['session_date'] in l1_sessions}
    metrics={c.cell_id:{'with_l1':{'trades':0,'net':0,'pos':0,'neg':0},'without_l1':{'trades':0,'net':0,'pos':0,'neg':0},
                        'l1_sensitivity_0t_net_units':0,'l1_sensitivity_2t_net_units':0,'l1_trade_count':0} for c in cells}
    for phase in PHASE_ORDER:
        po=out/f'PHASE_{phase}';cp=json.loads((po/'CHECKPOINT.json').read_text(encoding='utf-8'));sessions=sorted(cp.get('completed',[]))
        for tr in iter_committed_trades(po,sessions):
            cid=tr['cell_id'];net=int(tr.get('net_pnl_units',0));m=metrics[cid]
            w=m['with_l1'];w['trades']+=1;w['net']+=net;w['pos']+=max(net,0);w['neg']+=max(-net,0)
            is_l1=tr.get('cutoff_level')=='L1'
            if not is_l1:
                x=m['without_l1'];x['trades']+=1;x['net']+=net;x['pos']+=max(net,0);x['neg']+=max(-net,0)
            else:
                m['l1_trade_count']+=1
                direction=1 if tr['direction']=='BUY' else -1
                last=int(tr['cutoff_business_last_micro']);entry=int(tr['entry_price_micro'])
                exit0=last;exit2=last-(10*1_000_000) if direction>0 else last+(10*1_000_000)
                m['l1_sensitivity_0t_net_units'] += pnl_units(entry,exit0,direction)-ENTRY_COST_UNITS-EXIT_COST_UNITS
                m['l1_sensitivity_2t_net_units'] += pnl_units(entry,exit2,direction)-ENTRY_COST_UNITS-EXIT_COST_UNITS
    for m in metrics.values():
        for k in ('with_l1','without_l1'):
            den=m[k]['neg'];m[k]['pf_num']=m[k]['pos'];m[k]['pf_den']=den
    disclosure={'schema':'MINOTAURO_R3_CUTOFF_FINAL_DISCLOSURE_V001','status':'PASS','sessions':len(set(all_sessions)),
                'sides':len(side_rows),'level_counts':levels,'l1_sessions':sorted(l1_sessions),'blocked_sessions':[],
                'side_events':side_rows,'pre_latch_anchor_spread_l1_sessions':anchor,'metrics_by_cell':metrics,
                'sensitivity_note':'0T and 2T are disclosure-only alternatives around observed BUSINESS last; they do not amend the approved L1 model.',
                'l1_price_nature':'MODELED_NOT_OBSERVED_EXECUTION'}
    _atomic(out/'GATES'/'R3_CUTOFF_FINAL_DISCLOSURE.json',disclosure)
    return disclosure


def write_combined_final(out: Path,parent,cells):
    b=json.loads((out/'PHASE_B'/'PHASE_B_FINAL_REPORT.json').read_text());c=json.loads((out/'PHASE_C'/'PHASE_C_FINAL_REPORT.json').read_text())
    r3=_r3_final_disclosure(out,cells)
    gate=json.loads((out/'PHASE_B'/'CONFIRMATION_GATE.json').read_text())
    report={'schema':'MINOTAURO_FULL_2026_BC_FINAL_REPORT_R3_V001','status':'PASS','range':'2026-01-01..2026-09-11',
            'phase_b':b,'phase_c':c,'confirmation_status':gate['status'],'frozen_cell_ids':[x.cell_id for x in cells],
            'parent_2025_freeze_sha256':parent['freeze_sha256'],'parent_2025_homologation_sha256':parent['homologation_sha256'],
            'full_run_performance_experiments':'NOT_IN_CRITICAL_PATH','r3_cutoff_disclosure_sha256':_sha(out/'GATES'/'R3_CUTOFF_FINAL_DISCLOSURE.json'),
            'r3_level_counts':r3['level_counts'],'r3_l1_sessions':r3['l1_sessions'],'r3_blocked_sessions':r3['blocked_sessions']}
    _atomic(out/'GATES'/'FULL_2026_FINAL_REPORT.json',report)
    print(f'FULL_2026_BC=PASS phase_b_sessions={b["sessions"]} phase_c_sessions={c["sessions"]} confirmation={gate["status"]}',flush=True)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('command',choices=['run','status'],nargs='?',default='run');ap.add_argument('--out',default=str(DEFAULT_OUT));ap.add_argument('--workers',type=int,default=15);ap.add_argument('--batch-rows',type=int,choices=[32,64,128,256],default=256);ap.add_argument('--preflight-source',required=True)
    ns=ap.parse_args(); out=Path(ns.out); preflight_source=Path(ns.preflight_source).resolve()
    try:
        pkg=verify_package(); parent=validate_parent_2025(); cells=parent['cells']
        wanted={'schema':'MINOTAURO_FULL_2026_CONFIGURATION_R3_V001','package_manifest_sha256':pkg,'parent_2025_freeze_sha256':parent['freeze_sha256'],
                'parent_2025_homologation_sha256':parent['homologation_sha256'],'phases':['B','C'],'phase_ranges':{'B':PHASES['B'],'C':PHASES['C']},
                'preflight_source_root':str(preflight_source),'frozen_cell_ids':[c.cell_id for c in cells],'workers':ns.workers,'batch_rows':ns.batch_rows}
        cp=out/'FULL_2026_CONFIGURATION.json'
        if cp.exists():
            if json.loads(cp.read_text())!=wanted: raise ModelError('FULL_2026_CONFIGURATION_MISMATCH_NEW_ROOT_REQUIRED')
        else:
            out.mkdir(parents=True,exist_ok=True);_atomic(cp,wanted)
        print(f'FULL_2026_PARENT=PASS freeze_status={parent["status"]} selected={parent["selected"]} cells={len(cells)}',flush=True)
        if ns.command=='status':
            for phase in PHASE_ORDER:
                p=out/f'PHASE_{phase}'/'CHECKPOINT.json';done=0
                if p.is_file(): done=len(json.loads(p.read_text()).get('completed',[]))
                print(f'PHASE_{phase}_COMMITTED={done}',flush=True)
            return
        for phase in PHASE_ORDER:
            if phase=='C' and not (out/'PHASE_B'/'PHASE_B_FINAL_REPORT.json').is_file(): raise ModelError('PHASE_C_REQUIRES_PHASE_B_FINAL_PASS')
            pf,cal,_,_=prepare_preflight(out,phase,preflight_source)
            po,binding,identity,runtime_hashes,cal,d1_path=build_binding(out,phase,pf,cells,parent)
            final_path=out/f'PHASE_{phase}'/f'PHASE_{phase}_FINAL_REPORT.json'
            if final_path.is_file():
                fr=json.loads(final_path.read_text(encoding='utf-8'))
                if fr.get('status')!='PASS': raise ModelError(f'PHASE_{phase}_FINAL_REPORT_NOT_PASS')
                print(f'PHASE_{phase}=FINAL_REPORT_REUSED_PASS',flush=True)
            else:
                run_phase(out,phase,cells,binding,identity,runtime_hashes,cal,d1_path,ns.workers,ns.batch_rows)
                finalize_phase(out,phase,cells,parent)
        write_combined_final(out,parent,cells)
    except KeyboardInterrupt:
        print('SAFE_STOP=YES PROCESS_TREE_CLEAN=PROVED_BY_RUNTIME RESUME_SAME_COMMAND=YES',flush=True);raise SystemExit(130)
    except Exception as e:
        print('MINOTAURO_FULL_2026=BLOCKED',flush=True);print(f'ERROR={type(e).__name__}:{e}',flush=True);traceback.print_exc();raise SystemExit(2)

if __name__=='__main__':
    raise SystemExit('PEGASUS_USE_GATED_ENTRYPOINT; HISTORICAL_DIRECT_MAIN_DISABLED')


def load_phase_d1_extract(out,phase,path,binding,calendar):
    if phase not in PHASE_ORDER: raise ModelError('PHASE_INVALID')
    path=Path(path).resolve();po=(Path(out)/('PHASE_'+phase)).resolve()
    if path!=po/('D1_PREDECESSOR_EXTRACT_PHASE_'+phase+'.csv'): raise ModelError('D1_PATH_BINDING')
    if _sha(path)!=binding['d1_predecessor_extract_sha256']: raise ModelError('D1_HASH_BINDING')
    rows=base.cal(path)
    if [r['session_date'] for r in rows]!=[r['session_date'] for r in calendar]: raise ModelError('D1_SESSION_ORDER')
    if len({r['session_date'] for r in rows})!=len(rows): raise ModelError('D1_DUPLICATE')
    return {r['session_date']:r for r in rows}
