```text
OPUS55_R1R11_V004R2R1_G4_AUDIT=FAIL
SOURCE_PACKAGE_INTEGRITY=PASS
V004R2R1_G1_G3_STATE=UNVERIFIED
V004R2R1_G4_STATE=FAIL
G4_FAILURE_CONTRACT_VALID=YES
G4_SPEEDUP=0.46912959401011434
G4_REQUIRED=1.5
G4_ORACLE_SECONDS=15.577073099993868
G4_CANDIDATE_SECONDS=33.20420049999666
G4_GRANTED=[4]
G4_OVERLAP=true
G4_ECONOMIC_EQUALITY_CURRENT_RUN=NOT_CHECKED
SAME_REVISION_G4_RERUN_AUTHORIZED=NO
ROOT_CAUSE_STATUS=PARTIAL
TARGET_REACHABLE_UNDER_FROZEN_CONTRACT=PLAUSIBLE_NOT_DEMONSTRATED
NEW_REVISION_REQUIRED=YES
NEW_ARCHITECTURE_REQUIRED=YES
FRESH_G1_G3_REQUIRED_BEFORE_NEW_G4=YES
FRESH_G4_REQUIRED=YES
G5_G11_AUTHORIZED_NOW=NO
REAL_DATA_AUTHORIZED_NOW=NO
PILOT_A_AUTHORIZED_NOW=NO
FULL_RUN_AUTHORIZED_NOW=NO
SECOND_EXTERNAL_AUDIT_AFTER_FUTURE_FIX=REQUIRED
MISSING_PRIMARY_EVIDENCE=1) G1.json, G2.json, G3.json, PREREGISTRATION.json, V4_PRE_G4\RESULTS.json e TEST_DISCOVERY.json da raiz D:\MinotauroRuns\MINOTAURO_R1R11_V004R2R1_OWNER_GATES_20260927_095710_684_20200; 2) G4.json (esperado com status=FAIL, gravado por OwnerGates.run() l.339-342 - contradiz o doc 04) e G4_MEASURED.json; 3) arvores G4_oracle\ e G4_candidate\ completas (SYNTHETIC_EXECUTION.json, CHECKPOINT.json, sessions\1999-12-31 e sessions\2000-03-01 com os 5 arquivos, TELEMETRY\R1R11_TRANSPORT.jsonl, TELEMETRY\memory.jsonl, R1R11_SCHEDULER_STATE.json, SESSION_SEALS) e os logs G4_oracle.log e G4_candidate.log; 4) timestamps fisicos (st_birthtime_ns e st_mtime_ns) de todos os arquivos dessas arvores; 5) comando/controlador efetivamente usado no G4 one-shot, seu log e receipt, valor de --stop-after e origem das linhas PRE_G4_*; 6) RECEIPT.json e controller.log do controlador G1-G3 (CONTROL_ROOT ...095710_684_20200); 7) synthetic_inputs\FIXTURES.json e heavy.csv da raiz V004R2R1 (esperados A424DEAF...232E e 000B347E...0381); 8) arvore owner fisica do G4 FAIL da V004R1 (o resumo V004R1_OWNER_G4_FAIL_SUMMARY.md declara nao substitui-la)
REQUIRED_CORRECTIONS=1) Nao reexecutar o G4 da V004R2R1 e nao alterar threshold, oracle, fixture, heavy_cycles, workers=4, batch_rows=32, shared_slots=1, gzjson, compresslevel ou runtime; 2) Coletar a evidencia primaria por coletor read-only com manifesto SHA-256, sem executar codigo do candidate; 3) Corrigir o doc 04: G4.json com status=FAIL e esperado pelo codigo; 4) Fechar a causa na Fase A0 sem rerun: linha do tempo forense (timestamps fisicos + BATCH_ACK), microbench preregistrado de pisos por stream sobre as saidas preservadas do G4_oracle, e diagnostico offline nao-gate de igualdade economica G4_oracle x G4_candidate; 5) Preregistrar agora a regra GO/NO-GO: orcamento medido <= 0,90 x 15,3265179000009/1,5 = 9,1959 s; 6) Se GO, emitir SPEC R1R11 V005 = V004 + secao 18 restrita ao envelope E1-E7 (fechamento em streaming concorrente ao feed, trades encerrados em streaming com recheck de finalidade, verificacao independente em streaming com binding por hash fisico, custodia sem custo por linha no caminho critico, otimizacoes locais, telemetria de fases, controlador G4 com ledger); 7) Nova revisao R1R11_V005R1 com identidade nova, preregistro operacional/causal, pins de hash e AST dos arquivos congelados e testes V5-A a V5-J; 8) Criterio interno nao-gate de prontidao antes de selar: 3/3 pares de desenvolvimento no PC owner com speedup >= 1,667 e igualdade de bytes no heavy; 9) Controlador G4 novo que recusa artefato G4* previo e manifesto ja consumido, registra timestamps e calcula igualdade economica diagnostica pos-gate sem alterar o status; 10) Corrigir menores: RUNNER_VERSION, CHANGED_FILES after:null, fins de linha mistos com .gitattributes, documento de identidade R1R10 na raiz e contrato pre-owner especifico da revisao; 11) Projetar o contrato de ativacao (main() bloqueado, controlador externo, batch_rows=32 fixo) e a adaptacao R1R11 dos criterios PP1-PP9, ambos dentro do escopo da auditoria final
NEXT_STEPS=1) Owner: coleta read-only da evidencia V004R2R1 em ZIP com SHA256SUMS; 2) Chat: integridade + linha do tempo forense (ROOT_CAUSE PARTIAL -> CLOSED ou PARTIAL justificado); 3) Owner PC: microbench A0 preregistrado e igualdade economica diagnostica, ambos nao-gate; 4) Chat: calculo mecanico GO/NO-GO; NO-GO => STOP com G4 bloqueado; 5) GO => SPEC V005 no envelope + conformidade interna item a item (fora do envelope => auditoria externa pre-implementacao); 6) Preregistro V005R1 selado antes de qualquer timing; 7) Implementacao + testes V5 + V4 adaptados + suite herdada; 8) Owner PC: benchmark de desenvolvimento nao-gate 3/3 (maximo 2 iteracoes antes de revisao causal); 9) Build selado V005R1 com ZIP de nome novo; 10) Owner: preflight + fresh G1-G3; 11) Chat: revisao mecanica G1-G3; 12) Owner: G4 one-shot com controlador de ledger (FAIL => STOP e Fase A0 da V005R1); 13) G4 PASS integral => G5-G11 e OWNER_G1_TO_G11_RECEIPT; 14) Pacote final completo; 15) Auditoria independente final pre-Pilot (unica externa obrigatoria); 16) Cadeia pre-piloto R1R11: preregistro do cap -> synthetic gates PS5.1 -> operational gates -> Rebind A leve nao economico -> PRE_RUN_A gates 1-26 -> geometria -> seal 27/27; 17) Autorizacao de Pilot A pelo owner; 18) Pilot A -> Gate28 mismatch=0 -> PRE_RUN_A 28/28; 19) Promocao mecanica pos-piloto PP1-PP9 R1R11; 20) Autorizacao RUN_A pelo owner -> FULL RUN 250 sessoes no PC local -> relatorio final -> homologacao do FULL RUN
```

**Legenda de evidência usada em todo o parecer:**
[FV] = FATO VERIFICADO por mim (hash físico, código-fonte, aritmética);
[FD] = FATO DOCUMENTADO em evidência histórica selada no pacote (medição owner registrada, não re-medida por mim);
[H] = HIPÓTESE;
[NV] = NÃO VERIFICÁVEL com o material fornecido.

**Semântica do veredito:** `OPUS55_R1R11_V004R2R1_G4_AUDIT=FAIL` segue a convenção das auditorias 26/27 — o objeto auditado (V004R2R1 perante o G4) não é homologável. O FAIL do owner está confirmado como metodologicamente válido. Nada é autorizado.

---

## 1. Integridade

| Item | Resultado |
|---|---|
| Handoff: `SHA256SUMS_HANDOFF.txt` | 22/22 OK [FV] |
| ZIP V004R2R1 | SHA `346DCB04…ABEFF` confere; 389 entradas; manifesto 388/388; zero arquivo fora do manifesto; SHA do manifesto `2350CF33…7EE1A` [FV] |
| ZIP V004R2 | manifesto 383/383; SHA do manifesto `FE8FAEB5…250FB` [FV] |
| ZIP V004R1 | manifesto 372/372; SHA do manifesto `02181274…7021D` [FV] |
| Bundle G3 V004R2 | SHA `18AA954C…C5C` confere; CRC OK; 81 entradas; os 8 fontes em `package_key` são byte-idênticos à V004R2 [FV] |
| Oracle `oracle/minotauro_v004_runner.py` | `E5E87B55…25B9`, idêntico em V004R1/R2/R2R1 [FV] |
| Core, IO, metrics, preflight, SPEC V004, SPEC econômica, SPEC V003, CERT | idênticos aos pins e entre as três revisões [FV] |
| `r1r11_fixtures.py` | `73368AEB…95F7`, idêntico nas três revisões [FV] |
| Função `g4()` | fonte (AST, LF) `D6AB1424…7605` idêntico nas três revisões e igual ao receipt [FV] |
| `gzjson` / `_PrefixHashTracker` | candidate = oracle após normalização LF (`3CA299F4…`, `FE45BA22…`) [FV] |
| Fixture heavy | `heavy.csv 000B347E…0381`, `FIXTURES.json A424DEAF…232E`, `warmup.csv 6FCA0C64…917C` idênticos nos PREREGISTRATION owner de V003R1 e V004R2 [FV]; na V004R2R1 [NV] |
| Linhagem V004R2→V004R2R1 | exatamente 10 arquivos alterados/adicionados, conforme `CHANGED_FILES_V004R2_TO_V004R2R1.json`; runner candidate inalterado (`514ED69A…`) [FV] |
| Causa do G3 FAIL da V004R2 | seal com hashes minúsculos presente no bundle (`18cc39fc…`), confirmando a causa por caixa textual [FV] |
| Transcript G1–G3 | identidades de ZIP/manifesto/entradas coerentes com o pacote [FV]; receipts G1–G3 [NV] |

**Anomalias sem efeito sobre a integridade** (detalhadas na seção 4): inventário V004R1→V004R2 marca manifestos aninhados como `after: null` embora presentes e inalterados; `RUNNER_VERSION` continua "…V004R2" na V004R2R1; fins de linha mistos; documento de identidade R1R10 na raiz descreve `r23_gates` antigo (`14B8808B…`), enquanto o arquivo da raiz é `F6CCA729…` (alteração declarada na V003R1).

**Por que G1–G3 = UNVERIFIED e G4 = FAIL:** aceitar um FAIL reportado não promove nada (é fail-closed); aceitar um PASS sem receipt seria presunção. O PASS de G1–G3 é coerente com o código, pois o `RESUME_SKIP` exige receipt PASS e hashes de evidência intactos (l.319–329), mas só consta em transcript.

---

## 2. Reconstrução causal

### 2.1 O FAIL está corretamente determinado (pergunta A)

- `g4()` (l.134–150) calcula `speed = oracle_case/candidate_case`, grava `G4_MEASURED.json` (l.147) e lança exceção se `granted!=[4]`, se não houver overlap ou se `speed<1.5` (l.148). A igualdade econômica só é testada depois (l.149) [FV].
- Aritmética do transcript: 15,577073099993868 / 33,20420049999666 = 0,469129594010114; target = 10,384715399995912 s; redução necessária = 68,7247 %; aceleração necessária = 3,19741× [FV].
- `G4_ECONOMIC_EQUALITY_CURRENT_RUN=NOT_CHECKED` [FV por código].
- **Correção ao documento 04:** o `except BaseException` de `run()` (l.339–342) grava `G4.json` com `status=FAIL`, `error` e `traceback` antes de relançar. Logo **G4.json deve existir**. Há precedente físico: `DIAGNOSTICS_V003R2/OWNER_FAILURE_V003R1/G4.json` [FV]. Consequência protetora: nova invocação na mesma raiz falha em `PREVIOUS_G4_FAIL_REQUIRES_CAUSAL_REVIEW` (l.330) [FV].

### 2.2 Indícios de falso FAIL (pergunta B): nenhum

| Vetor | Análise |
|---|---|
| Wrapper | O launcher chama o Python sem redirecionar stderr e propaga o exit 2 da `RuntimeError` do próprio gate [FV] |
| Grant | O `GRANTED_WORKERS=3` é o warmup 1999-12-31. `FIRST_WORKER_RESERVE_MIB=10708` (l.24) e o alvo 38822 MiB dão ⌊~38.7k/10708⌋=3. A sessão heavy usa o pico medido do warmup e recebe 4. O filtro `session==heavy` produz `[4]`. O mesmo padrão 3→4 aparece no log de medição V003R2 [FV] |
| Overlap | Calculado sobre os intervalos BATCH_ACK da sessão heavy; `true` [FV por código; valor NV sem telemetria] |
| Warmup | Excluído: `case_timings[heavy]` isolado [FV] |
| Fronteira | Mesma fronteira para os dois papéis (l.182–205 de `r1r11_fixtures.py`) [FV] |
| Ordem/deriva térmica | Oracle 15,577 s está dentro da faixa owner histórica 15,33–15,77 s [FD]. Nenhum artefato plausível explica um fator de 3,2× |
| Resume parcial | O transcript não mostra `CHILD_RESUME_SKIP`; os dois filhos rodaram [FV no transcript] |

### 2.3 Localização do custo: limite forense sem rerun

- `self.start` é fixado no início de `ParallelSession` (coordinator l.45). O progresso só é impresso quando `now-last_report>=5` (l.164), dentro de cada `flush()`, após os ACKs.
- O transcript mostra uma única linha: 131 lotes (4192 linhas) em 5,0 s. Uma segunda linha teria sido impressa se algum `flush()` terminasse após 10,0 s.
- **Logo, todo o feed paralelo terminou antes de 10,0 s, e ≥ 23,20 s (≥ 69,9 %) do caso ocorreram depois do último lote** [FV, condicionado à completude do transcript; confirmação no `G4_candidate.log` primário].
- Extrapolando a taxa (26,2 lotes/s) para os 20 lotes restantes (151 no total, como na V003R1 [FD]): feed ≈ 5,76 s e pós-feed ≈ 27,44 s (82,6 %) [H].
- A V004R1 mostrava 4224 linhas em 5,0 s para 45,30 s totais [FD]. O feed ficou praticamente igual, e toda a melhora da V004R2 (−12,09 s) ocorreu no fechamento [FD+FV].

### 2.4 Mecanismo (V003R2 → V004)

| Revisão | Candidate (owner 3.14.7) | Pós-feed |
|---|---:|---:|
| V003R1 | 19,60 s | — |
| V003R2 (mediana/controle) | 17,12 / 18,10 s | ≈ 14,6 s (finish 1,76 + commit 12,65 + pós 0,16) [FD] |
| V004R1 | 45,30 s | ≈ 39,5 s [H] |
| V004R2R1 | 33,20 s | ≥ 23,2 s [FV] / ≈ 27,4 s [H] |

A V004 dobrou o custo do fechamento em relação à V003R2, apesar de mover os quatro streams para processos, porque acrescentou **passes por linha** sobre ~1,68 milhão de linhas canônicas (trades 300.000; events 633.601; equity 750.000 [FD]):

1. **Worker:** cada `ScratchSink.append` agora faz, por linha, `merge_key`, codificação JSON, SHA-256 do payload, montagem e codificação JSON do sidecar e duas escritas gzip (custody l.106–116) [FV].
2. **Helper:** `checked_rows` faz, por linha, dois `json.loads` (linha e sidecar), `merge_key`, SHA-256 e 13 comparações (l.181–222), mais `verify_file` prévio de 30 arquivos (l.183). Somam-se heap/groupby, `OrderProof.add` com `json.dumps(key)` e SHA (stage l.63), `parent.is_alive()` por linha (stage l.118, uma syscall `WaitForMultipleObjects` por linha no Windows) e o `gzjson` [FV].
3. **Coordinator após a saída dos helpers:** `validate_stage` redecodifica **todas** as linhas canônicas (`json.loads`, chave, `json.dumps(key)`, SHA), em 4 *threads* sob GIL (stage l.68–90 e l.194–197) [FV]. O GIL está habilitado no runtime owner [FD, closeout §1]. Com o GIL, esse passe é efetivamente serial [H forte]. A redução V004R1→R2 de 12,1 s, obtida ao retirar um passe semântico análogo do coordinator, dá a ordem de grandeza desse passe [FD+H].

**Duas hipóteses causais da V004 foram refutadas por construção:**
- "sidecars reduzem trabalho de merge-key" (doc 04 §8): o helper precisa decodificar o JSON de qualquer forma para reemitir pelo `gzjson`, então o sidecar só **acrescenta** custo por linha [FV por código];
- "quatro processos eliminam o GIL comum": vale para os helpers, mas o passe pós-helper do coordinator reintroduz um trecho serial sob GIL sobre todos os streams [FV por código].

**Status da causa: PARTIAL.** O locus (fechamento pós-feed ≥ 70 %) é fato. A repartição entre helper crítico, revalidação do coordinator e finish dos workers é hipótese coerente (seção 3), sem telemetria de fases, porque a telemetria atual não tem timestamps de fase. A repartição pode ser fechada sem rerun (seção 8).

---

## 3. Análise de performance

### 3.1 Partição hipotética dos 33,20 s (pergunta C)

| Componente | Natureza | Estimativa | Base |
|---|---|---:|---|
| Spawn de 4 workers + READY | process-start | 0,25–0,35 s | V003R2 medido [FD] |
| Feed/compute (151 lotes, barreira por lote, sidecar no hot path) | paralelo, worker-bound | ≈ 5,4–5,8 s | transcript + extrapolação [FV/H]; V003R2 sem sidecar: 3,46 s [FD] |
| FINISH dos workers (trades/recon + sidecar + manifests) | paralelo | 1,0–1,6 s | [H] |
| `validate_sealed_fast` (120 arquivos) | coordinator; I/O/decompress, libera o GIL | 0,7–1,2 s | [H] |
| Spawn de 4 helpers | process-start | 0,3–0,5 s | [H] |
| Helper crítico (equity 750k ou events 634k) | serial por stream, Python por linha | 12–15 s | ≥ 5,64 s de CPU medidos na V003R2 para parse+merge+gzjson de equity [FD], mais sidecar, OrderProof e `is_alive` [H] |
| `validate_stage` sob GIL (1,68 M linhas) | coordinator-bound, serial | 7–10 s | [H], ordem de grandeza V004R1→R2 |
| Reverify scratch, journal, pending, fsyncs, boundaries, cleanup, EOF, CP | I/O + coordinator | 0,8–1,5 s | V003R2: 155 boundaries = 0,27 s [FD] |
| Compressão canônica nível 6 | compression-bound | ~1,2 s de CPU total, ~0,5 s no caminho crítico | oracle zlib 1,17 s [FD] |

Conclusão: o custo é dominado por **trabalho Python por linha** no fechamento. Nem I/O, nem compressão, nem spawn, nem barreiras dominam.

### 3.2 Orçamento (pergunta E)

- Target desta medição: 10,3847 s. Target conservador (menor oracle owner, V004R1): 15,3265179/1,5 = **10,2177 s**.
- **Modelo V004** (feed → helpers → revalidação do coordinator, sequencial), usando componentes medidos como limites inferiores:
  - com zero sidecar e zero verificação: 0,25 + 3,46 + 0,5 + 5,64 + 0,3 ≈ **10,15 s**, margem de ~2 % no melhor caso irrealista;
  - com a revalidação pós-saída exigida pela SPEC §17.4.3(7) (≥ 2–6 s): ≈ **12,5–16 s**, ou 0,97–1,25×.
  - **Veredito do modelo V004: 1,5× não atingível [H forte].** Robusto a erros de 2× nas estimativas por linha, porque o piso decorre de CPU medida da V003R2.
- **Modelo de fechamento em streaming** (writers por stream consumindo deltas confirmados por ACK durante o feed; verificação independente concorrente; binding por hash):
  - T1, trades escritos só no FINISH: 0,25 + 3,46 + 0,5 + 4,44 + 0,5 ≈ **9,15 s**, margem de ~10–12 %, **marginal**;
  - T2, trades encerrados também em streaming: cauda ≈ max(CPUₛ − feed) = 5,64 − 3,46 ≈ 2,2 s, total ≈ **6,4 s**, margem de ~38 %.
  - Premissas [H]: writers em processos próprios não desaceleram os workers (24 CPUs lógicas); CPU do verificador ≤ CPU do writer; custo de IPC/tailing pequeno; ausência de sidecar no caminho crítico.
- Daí `TARGET_REACHABLE_UNDER_FROZEN_CONTRACT=PLAUSIBLE_NOT_DEMONSTRATED`. Existe um caminho com orçamento plausível, mas ele exige mudança normativa de custódia (a SPEC V004 não está na lista congelada do prompt), e nenhum número foi medido para esse desenho. Isso **não é** "universalmente impossível" nem demonstrado.
- **Validade externa [H]:** a sessão 2025-01-06 do piloto tem ~23,5 M linhas de equity (auditoria 27, MAJ-4 [FD]), cerca de 31× o heavy. No modelo V004 o fechamento por linha escalaria para minutos por sessão. A arquitetura V004 é inadequada para o FULL RUN mesmo abstraindo o G4.

### 3.3 Otimizações seguras (pergunta D)

| Classe | Otimização | Admissível sem SPEC nova? | Efeito |
|---|---|---|---|
| S1 | `is_alive()` periódico (≤ 0,2 s ou N linhas) em vez de por linha (stage l.118); a SPEC §17.6 exige checagem em esperas | Sim | 1–3 s de CPU no stream crítico [H] |
| S2 | Pre-spawn dos helpers no início da sessão, contabilizados em JOB_MEM desde o spawn | Sim | 0,3–0,5 s |
| S3 | Validação por stream assim que o helper respectivo sai | Sim | pequeno |
| S4 | Codificação binária da prova de ordem (em vez de `json.dumps(key)`) nos dois lados | Sim (formato interno) | 1–3 s de CPU |
| S5 | Eliminar o sidecar ("permitido", não exigido: §17.3.4) | Exige decisão normativa: V4-B e preregistro citam o sidecar | alto |
| A1 | Fechamento em streaming concorrente ao feed | **Não** (C4/§17.3/§17.4) | decisivo |
| A2 | Trades encerrados em streaming + recheck de finalidade | **Não** (§17.3.2 exige esclarecimento) | decisivo para margem |
| A3 | Verificador independente em streaming + binding por hash físico em vez do re-parse pelo coordinator | **Não** (§17.4.3(7)) | decisivo |

**Proibidas:** mudar `gzjson`, compresslevel, `sort_keys`, separators ou mtime; concatenar bytes JSON pré-serializados; scratch autoritativo não-JSON; runtime free-threaded ou outro runtime (a identidade 3.14.7 GIL/zlib-ng está congelada); mudar workers, batch ou slot; qualquer caminho de código que consulte sessão, cenário ou `heavy_cycles`.

S1–S4, mesmo somadas, **não fecham** o modelo V004 (§3.2).

### 3.4 Profiling mínimo antes de implementar (pergunta F)

Nenhum rerun do G4 e nenhuma reexecução do pipeline V004R2R1 são necessários ou recomendados:

1. **A0.1 Forense (zero execução):** a partir dos timestamps físicos e da telemetria preservada, reconstruir:
   - o feed (primeiro→último BATCH_ACK, Σ máximo por lote);
   - a janela de cada helper (`st_birthtime` = início do `gzjson`; `st_mtime` = fim, preservados pelos renames);
   - a janela último helper → `session_receipt.json` (revalidação + journal);
   - o `st_mtime` de `SESSION_SEALS`, `CHECKPOINT.json` e `memory.jsonl` (fim do caso ≈ última boundary − ~10 ms).
   - Cuidado: no `CHECKPOINT.json`, só `mtime` é confiável (possível *tunneling* de criação no NTFS).
2. **A0.2 Microbench preregistrado, não-gate, no PC owner (3.14.7):** sobre as saídas preservadas do `G4_oracle`:
   - piso do `gzjson` por stream, com verificação de bytes idênticos ao original;
   - custo por linha de `json.loads`, `merge_key`, heap 15-vias (divisão determinística por grupo), prova de ordem (JSON versus binária), SHA por linha e `is_alive()`.
3. **A0.3 Igualdade econômica diagnóstica:** `economic(G4_oracle)` versus `economic(G4_candidate)` offline. Não altera o G4; revela eventual defeito de bytes no heavy, que nunca foi verificado, pois G5/G6 não incluem a sessão heavy (`run_chain` sem `only` exclui heavy).

**Regra GO/NO-GO preregistrada neste parecer:**
T_est = spawn + feed_ref + max_s(cauda_s) + binding + transação, com cada termo medido em A0.1/A0.2 ou herdado de medição owner [FD].
**GO se T_est ≤ 0,90 × 10,2177 = 9,1959 s.** Caso contrário, **NO-GO**: G4 permanece bloqueado, e qualquer alteração normativa do gate é decisão do owner fora deste parecer, que não a recomenda.

### 3.5 Próximo artefato (pergunta G)

Uma revisão V004R2R2 é **insuficiente**. O próximo artefato deve ser uma **nova arquitetura de fechamento**, formalizada como **SPEC R1R11 V005** com revisão de implementação **R1R11_V005R1** (atenção à colisão de nomes com a SPEC econômica "V005R1": usar sempre o prefixo R1R11).

---

## 4. Achados por severidade

### CRÍTICO

**C-1 — Fechamento pós-feed incompatível com o target.**
- Evidência: coordinator l.45 e l.164 com transcript (feed < 10 s; pós-feed ≥ 23,2 s); stage l.68–90, l.116–127, l.194–197; custody l.106–116, l.181–222.
- O caminho sequencial feed → helpers → revalidação do coordinator tem piso estimado de 12,5–16 s, acima do target 10,38 s [FV no locus; H na partição].
- Correção: nova arquitetura (E1–E3).

### MAJOR

**M-1 — Processo de orçamento falho.**
- Três one-shots consumidos: 0,796× → 0,338× → 0,469×.
- O orçamento pré-implementação V003R3 (commit = 5,0 s) não contabilizou os passes por linha, e a V004 foi autorizada com atingibilidade UNPROVEN (SPEC §17.10.2).
- Não existiu nenhum ensaio não-gate no PC owner antes de selar.
- Correção: GO/NO-GO A0 e critério interno 3/3.

**M-2 — Hipóteses causais V004 refutadas por construção.**
- Sidecar aumenta custo; revalidação sob GIL anula o ganho de processos (seção 2.4).
- O preregistro V004R2 previa "quatro threads por stream" para um passe Python-bound.

**M-3 — `parent.is_alive()` por linha emitida (stage l.118).**
- Syscall por linha no caminho crítico; a SPEC §17.6 só exige checagem em esperas.
- Correção S1.

**M-4 — Sem telemetria de fases.**
- `Runtime.log` e `JobMemory.boundary` não registram tempo, exceto os intervalos BATCH_ACK.
- Por isso a causa ficou PARTIAL e toda falha exigiu diagnóstico caro.
- Correção E6.

**M-5 — Execução do G4 sem evidência de controle.**
- O handoff traz apenas o controlador G1–G3 e o contrato pré-owner da **V004R1** (ZIP `C4598C…`, candidate `CFE728…`).
- O bloco G4 mostra o banner do launcher do pacote e linhas `PRE_G4_*` de origem não fornecida.
- Não invalida o FAIL (conservador), mas um futuro PASS exigirá controlador e receipt selados.
- Correção E7.

**M-6 — Igualdade de bytes do heavy nunca verificada.**
- G4 só a testa após o threshold; G5/G6 não rodam heavy.
- Na V004R2R1, igualdade econômica do heavy = desconhecida.
- Correção A0.3 + V5-J + controlador E7.

**M-7 — Caminho de ativação não resolvido.**
- `main()` do candidate sai 2 para rebind, pilot e run (runner l.807–808); `r23_gates` exige receipt owner.
- O "controlador externo de ativação" (POST-M1/M2 da auditoria interna) não existe.
- Bloqueia o Pilot A e deve entrar no escopo da auditoria final.

### MINOR

**m-1** — `CHANGED_FILES_V004R1_TO_V004R2.json` declara `after:null` para 5 manifestos aninhados presentes e inalterados (bug do inventariante).

**m-2** — `RUNNER_VERSION="…R1R11_V004R2"` na V004R2R1 (contract l.14).

**m-3** — Fins de linha mistos: runner candidate CRLF/LF; `r1r11_v4_transaction.py` CRLF.
- Risco em Git com `autocrlf` (política §16.3).
- Exigir `.gitattributes` (`* -text`) ou normalização com pins AST.

**m-4** — `FROZEN_FILES_IDENTITY_R1R10.json` na raiz lista `r23_gates=14B8808B…`, mas a raiz tem `F6CCA729…`.
- Documento histórico em posição de autoridade; mover para HISTORY ou rotular.

**m-5** — Bundle diagnóstico com separador `\` nas entradas ZIP; aceitável como evidência, inválido como pacote selado (§7.4).

**m-6** — O documento 04 prevê a ausência de `G4.json`, contrariando o código (seção 2.1).

---

## 5. Correction envelope

### E0 — Congelado (hash-idêntico; pins verificados nesta auditoria)

| Arquivo | SHA-256 |
|---|---|
| `minotauro_v004_core.py` | `97F8F957300D37966913C872B7F04E498D30B0CFF68180993DB80D314B900827` |
| `minotauro_v004_io.py` | `DC816C617AA6586828CEC769B21741D5BC4106FA8A72B933F1BE76D4E1BCAF4F` |
| `minotauro_v004_metrics.py` | `8CE1292F5E0580E98DCB3743350416C0C559F6C6189305250371F2E05D22970F` |
| `minotauro_v004_preflight.py` | `3A2398FD86F93C1EBD8AF5C1BD64D4BC839185AC26FABA775C8152FD29750390` |
| `oracle/` inteiro (runner `E5E87B55C142159E84E39E44A8AF3E3BA6055CCDADFDAD022599E91A3FED25B9`) | idem V004R2R1 |
| `r1r11_fixtures.py` | `73368AEBF232F20A052485A7255CE85723D2B3847414E21C485289435BA595F7` |
| `r1r11_owner_gates.py` (G1–G11, inclusive `g4`, `chain`, `economic`) | `100B26F54E81E49B1A47CD7AAA142F12AEBEB3070C8466C824B8716CA2EE8710` |
| `r1r11_coverage.py` | `EA0AECE8CD52716EFAC6826A0CEF339B8CC3CEBF39F4E8AF8205643C32DC9401` |
| `r1r11_prefix.py` | `009046BBE28C76416BAFB966975DD04C9633F8CE18AAF9E094D80F8F94273974` |
| `r1r11_signal.py` | `CE57AE9C7943415828FEFDB6C2A86EDF89951CF07CA47BFB74C5D0671057AB52` |
| `minotauro_v005r1_r23_gates.py` (versão R1R11) | `F6CCA729E84B0E1907A423F789CEFAD5B9C2ED0E10FCA4D214C24FF1DA333591` |
| `minotauro_v005r1_r23_reference.py` / `_outputs.py` / `_binding.py` / `r1r10_memory.py` | `BFCD4EB4…175D` / `4507A1D9…8124` / `641D07C6…CE27` / `020FAB45…3C50` |
| SPEC econômica / SPEC V003 / SPEC V004 / CERT | `D6D79108…2747` / `552401C0…91C6` / `8510AFD7…3B07` / `2E5F447B…3EBB` |
| EA R6 / MQ5 geometria / grid | `1A950132…9FA5` / `1B0024E6…E412` / `A91A923F…14B1` |
| Suítes herdadas (`test_minotauro_*`, `test_r1r11_guards/integration/targeted/revision`) | hashes atuais da V004R2R1 |
| Fixture heavy | `heavy.csv 000B347E…0381`; `FIXTURES.json A424DEAF…232E` |

**Pins AST** (fonte LF normalizado, `ast.get_source_segment`, SHA-256 maiúsculo; método que reproduz o receipt):

| Símbolo | SHA-256 (AST) |
|---|---|
| `gzjson` | `3CA299F4…7961` |
| `_PrefixHashTracker` | `FE45BA22…CA31` |
| `g4` | `D6AB1424…7605` |
| `merge_key` | `359EF9B7…E743` |
| `merged_stream` | `14974BC9…B71D` |
| `EVENT_STAGE` | `F293AE33…33B6` |
| `EQUITY_STAGE` | `5F49E042…3444` |
| `GLOBAL_EVENTS` | `6A0505F6…85B1` |
| `RECORD` / `HEADER` / `MAGIC` | `7DEE059B…` / `51E6D652…` / `AEFB6C5E…` |
| `encode_record` / `decode_records` / `write_slot` / `read_slot` | `F5290B0F…` / `C6D69F53…` / `10888D0A…` / `B5A2A05D…` |

**Parâmetros congelados:** heavy_cycles=1200; G4 workers=4; batch_rows=32; shared_slots=1; SLOT_BYTES=4 MiB; threshold 1,5; par único oracle→candidate; warmup excluído; runtime 3.14.7/64 bits/NumPy 2.4.6/zlib-ng 1.3.1; hard cap 48528 MiB; RAM alvo 60 %; `FIRST_WORKER_RESERVE_MIB=10708`; protocolo transacional §17.7; C1–C9; single canonical publisher.

### Podem mudar (escopo máximo)

- `r1r11_coordinator.py`, `r1r11_worker.py`;
- `r1r11_v4_stage.py`, `r1r11_v4_custody.py`, ou módulos novos `r1r11_v5_*.py`;
- `r1r11_v4_transaction.py`, somente rótulo de versão do journal e integração, preservando a sequência §17.7;
- `r1r11_transport.py`, somente **adição** de funções/mensagens; símbolos pinados intactos;
- `r1r11_resources.py`, somente contabilização de novos papéis de processo; `grant_workers`, `HARD_CAP_MIB`, `RunLock` e `JobMemory.boundary` com pins AST registrados no preregistro V005R1;
- `minotauro_v004_runner.py`, somente o despacho `runtime is not None` de `_commit_session`; restante idêntico por AST ao `514ED69A…`;
- `minotauro_v005r1_r23_contract.py`, somente `RUNNER_VERSION` e lista de manifesto; `r1r11_revision.py`;
- `run_v4_checks.py`, inclusão das suítes V5; testes novos `test_r1r11_v5_*.py`;
- SPEC V005 (arquivo novo), `OPERATIONAL_PREREGISTRATION_V005R1.json`, changelogs, receipts e manifestos gerados.

### Cláusulas normativas admissíveis na SPEC V005 (§18 aditiva; nada mais)

- **E1 — Fechamento em streaming:** um writer por stream, iniciado na sessão.
  - Consome linhas cujo `ordinal` ≤ marca-d'água derivada do ACK validado pelo coordinator (C6).
  - Chaves e fusões C1 literais.
  - Buffers limitados e contabilizados; nenhuma linha além da marca-d'água.
  - Scratch JSON continua autoritativo e selado no fim com SHA; bytes consumidos pelo writer têm hash igual ao selado.
- **E2 — Trades encerrados em streaming:** permitido persistir o trade no scratch **após** o fechamento econômico.
  - Selagem continua no fim do grupo.
  - Recheck obrigatório no FINISH: re-serializar os trades finais em memória e comparar o SHA por linha com o emitido; divergência → FAIL.
  - Enriquecimento de cutoff inalterado.
  - A variante T1 (trades no FINISH) é permitida, mas o GO de A0 deve fechar sem E2.
- **E3 — Verificação independente em streaming:** por stream, processo distinto do writer.
  - Recalcula linhas, chaves, prova de ordem e SHA dos bytes consumidos.
  - Após a saída do writer, o coordinator exige: SHA físico do stage = SHA consumido pelo verificador = SHA do writer; contagens e prova iguais; identidade física estável.
  - Substitui o re-parse por linha do §17.4.3(7). O coordinator permanece autoridade e publisher único.
- **E4 — Custódia sem custo por linha no caminho crítico:** sidecar opcional. Se mantido, fora do caminho crítico. Hashes de selo/consumo preservados.
- **E5 — Otimizações locais:** S1–S4.
- **E6 — Telemetria de fases:** timestamps monotônicos e de parede por fase, não canônicos, em todos os processos.
- **E7 — Controlador G4 com ledger one-shot:**
  - recusa qualquer `G4*` prévio;
  - recusa manifesto já consumido (ledger fora da raiz de evidência);
  - grava comando, `--stop-after`, timestamps e receipt;
  - após o gate, calcula igualdade econômica **diagnóstica**, sem alterar o status.
- **E8 (opcional, fora do orçamento):** pool persistente. Se usado, o spawn não pode ser descontado do orçamento A0 e G5/G7 precisam cobrir reuso, estado obsoleto e regrant.

### Conformidade e dispensa de auditorias (pergunta K)

- Se a SPEC V005 for **exatamente** V004 + §18 contendo apenas E1–E7 (+E8), com as invariantes acima, a conformidade pode ser checada internamente, item a item, e **dispensa auditoria externa pré-implementação**. Qualquer cláusula fora disso exige essa auditoria.
- Também são dispensáveis: auditoria externa entre G4 PASS e G5 (mecânica) e auditoria pós-piloto, se a auditoria final preregistrar PP1–PP9 R1R11.
- **Não é metodologicamente defensável dispensar a auditoria independente final pré-Pilot:**
  1. a SPEC V004 §17.11 e o status da própria SPEC a exigem;
  2. E1–E3 são protocolos de custódia novos e relevantes para TOCTOU e SAFE_STOP, cuja correção depende da implementação;
  3. o resultado de performance é empírico;
  4. G5–G11, a ativação e a cadeia de piloto ainda não existem;
  5. o builder não pode se autocertificar.
- Por isso: `SECOND_EXTERNAL_AUDIT_AFTER_FUTURE_FIX=REQUIRED`, **exatamente uma**.

---

## 6. Plano de testes (antes do novo G4)

| ID | Teste | Critério |
|---|---|---|
| V5-A | Diferencial completo: 39 cenários + heavy (não-gate) vs oracle | 5 arquivos + CP byte-idênticos |
| V5-B | Marca-d'água: linhas do mesmo ordinal em lotes/workers distintos; latch global com ≥ 2 workers; S5a/S5b multi-worker; lotes unitários pós-cutoff | bytes iguais; asserção instrumentada "nenhuma linha além da marca" |
| V5-C | Finalidade de trades: trades abertos por muitos lotes, CUTOFF, IMMEDIATE_STOP, deferred; **mutação injetada pós-emissão** | recheck detecta → exit ≠ 0, sem promoção |
| V5-D | Verificador: linha fora de ordem injetada no writer; stage alterado após saída; SHA consumido ≠ selado; morte do writer/verificador; lag acima do limite | todos FAIL fail-closed |
| V5-E | SAFE_STOP/crash com writers ativos: Ctrl+C no feed, morte do parent, morte de worker; resume com 2↔3↔4↔8↔12 workers | árvore idêntica à limpa |
| V5-F | Memória: writers e verificadores em JOB_MEM/JOB_PEAK_BOUND; cap injetado nas novas fronteiras | exit 3; `JOB_PEAK_BOUND_RUN` monotônico |
| V5-G | Estáticos: pins de hash e AST (E0); varredura AST sem referência a sessão/cenário/`heavy_cycles` fora de fixtures/testes | PASS |
| V5-H | Telemetria de fases presente, monotônica e fechando ≥ 99 % do `case_timing` | PASS |
| V5-I | Controlador G4: recusa G4* prévio e manifesto consumido; registra; diagnóstico econômico não muda o status | PASS com defeitos injetados |
| V5-J | Benchmark de desenvolvimento não-gate (PC owner, sem profiler): 3 pares, todos com speedup ≥ 1,667 e heavy byte-idêntico | GO para selar |
| Herdados | V4-A…H adaptados (V4-B substituído por V5-D se o sidecar sair), G1–G11 inalterados, suítes R1R10 | PASS |

---

## 7. Roadmap até o FULL RUN

| # | Fase / gate | Executor | Condição de avanço |
|---|---|---|---|
| 1 | Coleta read-only da evidência V004R2R1 | PC owner | ZIP + SHA256SUMS |
| 2 | Integridade + forense | Chat | causa CLOSED ou PARTIAL justificado |
| 3 | Microbench A0 + igualdade econômica diagnóstica | PC owner | receipts não-gate |
| 4 | GO/NO-GO (≤ 9,1959 s) | Chat | NO-GO ⇒ STOP |
| 5 | SPEC V005 no envelope + conformidade interna | Chat | fora do envelope ⇒ auditoria externa |
| 6 | Preregistro V005R1 selado | Chat | antes de qualquer timing |
| 7 | Implementação + V5/V4/herdados | Codex (se necessário) → Chat | todos PASS |
| 8 | Benchmark de desenvolvimento 3/3 | PC owner | ≥ 1,667 nos 3; máx. 2 iterações |
| 9 | Build selado V005R1 (ZIP novo) | Chat/PC | autoauditoria V005 |
| 10 | Preflight + fresh G1–G3 | PC owner | G1–G3 PASS com receipts |
| 11 | Revisão G1–G3 | Chat | mecânica |
| 12 | G4 one-shot (controlador E7) | PC owner | granted=[4] ∧ overlap ∧ ≥ 1,5 ∧ igualdade econômica; FAIL ⇒ STOP |
| 13 | G5–G11 (resume) | PC owner | OWNER_G1_TO_G11_RECEIPT PASS |
| 14 | Pacote final (inclui contrato de ativação e PP R1R11) | Chat | completo |
| 15 | **Auditoria independente final pré-Pilot** | Work/externa | PASS |
| 16 | Preregistro do cap → synthetic PS5.1 → operational → **Rebind A** leve → PRE_RUN_A 1–26 → geometria → seal 27/27 | PC owner | critérios mecânicos |
| 17 | Autorização de Pilot A | owner | vinculada por SHA |
| 18 | **Pilot A** (2025-01-02/03/06; 435 células; multiwork ≥ 2) → **Gate28** mismatch=0 → **PRE_RUN_A 28/28** | PC owner | PASS |
| 19 | Promoção mecânica pós-piloto (PP1–PP9 R1R11 + PP multiwork) | Chat | todos PASS |
| 20 | Autorização RUN_A → **FULL RUN** 250 sessões (protocolo §9.3) → relatório → homologação | owner / PC | PASS |

Proibições permanentes mantidas: nenhum G5–G11 antes do G4 PASS da nova revisão; nenhum dado real antes da etapa 16; nenhum FULL RUN como teste; nenhuma evidência FAIL apagada.

---

## 8. Evidência ainda necessária

1. Tudo o que consta em `MISSING_PRIMARY_EVIDENCE`, coletado por script read-only que:
   - não importa código do candidate;
   - calcula SHA-256 de cada arquivo;
   - registra `st_birthtime_ns`/`st_mtime_ns`;
   - grava em raiz nova;
   - nunca toca a raiz original.
2. Verificações mecânicas sobre essa coleta:
   - `G4_MEASURED.json` = dicionário do transcript, byte a byte na semântica JSON;
   - `G4.json.status=FAIL`;
   - `PREREGISTRATION.inputs` com os 43 hashes iguais aos da V004R2;
   - uma única entrada SCHEDULER heavy com `granted=4`;
   - 151 BATCH_ACK heavy, com Σ dos máximos por lote;
   - janelas dos helpers pelos timestamps.
3. Tipo do volume D: (latência de fsync), para o orçamento de transação — opcional.
4. Árvore owner física da V004R1 G4 FAIL, exigida para a auditoria final.
5. Receipts A0.2/A0.3 e o cálculo GO/NO-GO, antes de qualquer linha da SPEC V005.

Nada nesta auditoria foi implementado, alterado ou executado além de verificação de hashes, leitura de fontes e evidências e aritmética. Nenhum G4, nenhum dado real, nenhum Pilot A e nenhum FULL RUN estão autorizados.
