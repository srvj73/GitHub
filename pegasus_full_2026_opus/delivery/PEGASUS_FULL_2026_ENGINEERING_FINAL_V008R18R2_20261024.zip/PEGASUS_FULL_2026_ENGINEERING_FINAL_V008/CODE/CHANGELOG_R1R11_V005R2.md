# CHANGELOG R1R11 V005R2 — Windows verifier handle lifecycle correction

Date: 2026-09-27

## Trigger
Windows owner V5 suite executed 18 tests and failed 6. Five failures shared the same physical traceback:
`PermissionError: [WinError 32]` deleting `_canonical_stage\trades.jsonl.gz.verify`.

## Root cause
`_CanonicalGzip` passes an explicitly opened raw file object to `gzip.GzipFile(fileobj=...)`.
Closing the `TextIOWrapper` closes the gzip layer but does not guarantee closure of the externally supplied raw file object.
The stream child remained alive waiting for `EXIT_ACK`, and the parent attempted to unlink the verifier copy before child exit.
POSIX allows unlink of open files; Windows does not.

## V005R2 correction
1. `_CanonicalGzip.close()` explicitly closes `self.raw`, preserving a primary close error if cleanup also fails.
2. `StreamPipeline.finalize()` records verifier cleanup paths, sends `EXIT_ACK`, joins every writer/verifier process, closes parent pipe endpoints, and only then unlinks `.verify`.
3. Added a regression test proving `writer.raw.closed == True` and successful unlink after close.

## Frozen surface
No E0 economic/causal file changed. No G4 contract parameter changed.
G4, real data, Pilot A and Full Run remain unauthorized until the synthetic chain passes.
