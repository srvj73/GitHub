"""Frozen V003 authority bindings and strict G6 coverage classification."""
from pathlib import Path
import hashlib
import json
import tempfile

from minotauro_v004_core import ModelError, RR_EPS_DEN, valid_cells
from minotauro_v005r1_r23_outputs import write_grid_cells
from r1r11_transport import EVENT_STAGE, EQUITY_STAGE

SPEC_V003_SHA256='552401C071384B921FDF4358EB3CBEB71441E5C8D2500B24183204425CFD91C6'
CERT_SHA256='2E5F447BE75D238E583C72272002E34BBF1B0FA3D47478B7B299311AC5433EBB'
GRID_SHA256='A91A923FB38C9BFA85E157AF494B26B3ED5EBF1843F531259820CD345DCD14B1'
SPEC_V004_SHA256='8510AFD78833A2242288B3FFF30B0C12CCC0EB1F45CF3D4979DBB114B6583B07'
FROZEN={
 'SPEC_R1R11_MULTIWORK_AUTOCPU_V004.md':SPEC_V004_SHA256,
 'minotauro_v004_core.py':'97F8F957300D37966913C872B7F04E498D30B0CFF68180993DB80D314B900827',
 'minotauro_v004_io.py':'DC816C617AA6586828CEC769B21741D5BC4106FA8A72B933F1BE76D4E1BCAF4F',
 'minotauro_v004_metrics.py':'8CE1292F5E0580E98DCB3743350416C0C559F6C6189305250371F2E05D22970F',
 'minotauro_v004_preflight.py':'3A2398FD86F93C1EBD8AF5C1BD64D4BC839185AC26FABA775C8152FD29750390',
 'SPEC_V005R1_R2_3_APPROVED.md':'D6D791083870015BF07BF4ABF64718D37F9136FA247D49DB31B4DC8DE2E73747',
 'SPEC_R1R11_MULTIWORK_AUTOCPU_V003.md':SPEC_V003_SHA256,
 'CERT_AMBIGUOUS_V001.md':CERT_SHA256,
}


def validate_bindings(root=None):
    root=Path(root or Path(__file__).resolve().parent)
    for name,expected in FROZEN.items():
        p=root/name
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest().upper()!=expected:
            raise ModelError('R1R11_FROZEN_BINDING_MISMATCH '+name)
    cells=valid_cells()
    if len(cells)!=435 or len({(c.p_idx,c.t_idx) for c in cells})!=15 or min(c.rr_min for c in cells)!=3 or RR_EPS_DEN!=10**12:
        raise ModelError('CERTIFICATE_CELL_PREMISE_MISMATCH')
    with tempfile.TemporaryDirectory(prefix='minotauro_binding_') as tmp:
        grid=write_grid_cells(Path(tmp)/'GRID_CELLS.csv')
    if grid!=GRID_SHA256:raise ModelError('CERTIFICATE_GRID_BINDING_MISMATCH')
    # Exact core binding covers target_idx=line_idx+direction, unique sorted
    # geometry, integer RR tolerance, and per-call empty eligible dictionary.
    return {'files':dict(FROZEN),'grid_sha256':grid,'cells':435,'groups':15,'rr_min':3,
            'adjacent_target_proven_by_frozen_core':True}


def validate_coverage(manifest, root=None):
    bindings=validate_bindings(root)
    if manifest.get('bindings')!=bindings:raise ModelError('G6_MANIFEST_BINDINGS')
    rows=manifest.get('events',[])
    names=[r.get('event') for r in rows]
    if len(names)!=13 or set(names)!=set(EVENT_STAGE):
        raise ModelError('G6_MISSING_DUPLICATE_OR_UNKNOWN_EVENT')
    for row in rows:
        name=row['event']; classification=row.get('classification')
        if name=='AMBIGUOUS_MULTI_SIGNAL':
            if classification!='STRUCTURALLY_UNREACHABLE' or row.get('certificate_sha256')!=CERT_SHA256 or row.get('occurrences')!=[]:
                raise ModelError('G6_UNREACHABLE_CONTRADICTION')
        else:
            if classification!='COVERED' or not row.get('occurrences'):
                raise ModelError('G6_CAUSAL_COVERAGE_REQUIRED '+name)
            for occurrence in row['occurrences']:
                if not all(k in occurrence for k in ('fixture','ordinal','oracle_file_sha256','row_index','cell_ids')):
                    raise ModelError('G6_UNIDENTIFIABLE_OCCURRENCE')
    required_equity=set(EQUITY_STAGE)|{'OPEN_MARK'}
    if set(manifest.get('equity',{}))!=required_equity or any(not x for x in manifest['equity'].values()):
        raise ModelError('G6_EQUITY_COVERAGE')
    obligations=('S1a','S1b','S2a','S2b','S3','S4','S5a','S5b',
                 'cancel_multiworker','deferred_multiworker','S5a_S5b_multiworker',
                 'different_rg_with_quote_update','integral_435','integral_baseline',
                 'BUY','SELL','STOP','TARGET','CUTOFF','IMMEDIATE_STOP',
                 'N_N1_same_ms','stale_BBO','crossed_BBO','RR_RMAX_boundaries',
                 'sequential_sessions','five_files_byte_equal')
    if any(not manifest.get('obligations',{}).get(k) for k in obligations):
        raise ModelError('G6_ADDITIONAL_COVERAGE_MISSING '+','.join(k for k in obligations if not manifest.get('obligations',{}).get(k)))
    return bindings


def require_owner_gates(cfg):
    from r1r11_owner_gates import verify_package
    path=cfg.get('r1r11_owner_gate_receipt')
    if not isinstance(path,str) or not Path(path).is_file():
        raise ModelError('R1R11_OWNER_G1_TO_G11_RECEIPT_REQUIRED')
    path=Path(path);receipt=json.loads(path.read_text())
    package_hash=verify_package()
    if receipt.get('status')!='PASS' or receipt.get('package_sha256')!=package_hash:
        raise ModelError('R1R11_OWNER_GATE_RECEIPT_BINDING')
    for gate in range(1,12):
        child=json.loads((path.parent/f'G{gate}.json').read_text())
        if child.get('status')!='PASS' or child.get('package_sha256')!=package_hash:
            raise ModelError('R1R11_OWNER_GATE_NOT_PASS '+str(gate))
        if not isinstance(child.get('evidence_files'),dict) or not child['evidence_files']:
            raise ModelError('R1R11_OWNER_GATE_EVIDENCE_REQUIRED '+str(gate))
        for name,expected in child.get('evidence_files',{}).items():
            p=(path.parent/name).resolve()
            if not p.is_relative_to(path.parent.resolve()) or not p.is_file():
                raise ModelError('R1R11_OWNER_EVIDENCE_PATH')
            h=hashlib.sha256()
            with p.open('rb') as f:
                for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
            if h.hexdigest().upper()!=expected:raise ModelError('R1R11_OWNER_EVIDENCE_HASH')
    from r1r11_coverage import verify_manifest_evidence
    manifest=json.loads((path.parent/'R1R11_ORACLE_COVERAGE_MANIFEST.json').read_text())
    verify_manifest_evidence(manifest,path.parent)
