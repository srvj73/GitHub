# CURRENT AUTHORITY — FULL CORRECT C1 V001

Owner decision 2026-09-28: prioritize the earliest correct FULL over further performance optimization.

Blocking gates in this revision:
- package/manifest integrity;
- synthetic oracle vs multiwork byte equality;
- explicit C1 cutoff enrichment validation;
- frozen source/preflight/D1/M1 binding;
- Pilot A 3 sessions;
- independent scalar pilot reconciliation;
- C1 pilot publication check;
- transactional/session/month integrity;
- final FULL 250 correctness homologation.

Non-blocking / not executed:
- G4 speedup threshold;
- 1.5x / 1.667x performance targets;
- new external audit rounds.

The V005R4 economic core, IO, metrics and preflight remain unchanged. The C1 fix moves the already-frozen preflight cutoff metadata to the worker before canonical scratch serialization, eliminating the known late-commit divergence for CUTOFF rows.

The controller is resumable. Any failure is fail-closed; FULL starts only after the synthetic and pilot correctness chain passes.
