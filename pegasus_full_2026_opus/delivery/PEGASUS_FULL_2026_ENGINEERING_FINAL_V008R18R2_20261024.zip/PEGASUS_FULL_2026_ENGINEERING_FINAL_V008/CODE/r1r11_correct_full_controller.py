from __future__ import annotations
import argparse, csv, gzip, hashlib, json, os, subprocess, sys, time, traceback, shutil
from pathlib import Path

PACKAGE=Path(__file__).resolve().parent
DEFAULT_OUT=Path(r'D:\MinotauroRuns\MINOTAURO_R1R11_FULL_CORRECT_C1_V001_20260928')
DEFAULT_PREFLIGHT=Path(r'D:\MinotauroRuns\MINOTAURO_PARAMETER_MARKET_DISCOVERY_V005R1_R1R4')


def sha(path: Path)->str:
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest().upper()


def atomic(path: Path,obj: dict):
    from minotauro_v005r1_r23_contract import write_json_atomic_canonical
    path.parent.mkdir(parents=True,exist_ok=True);write_json_atomic_canonical(path,obj)


def verify_package()->str:
    manifest=PACKAGE/'SHA256SUMS.txt'; listed={}
    for line in manifest.read_text(encoding='ascii').splitlines():
        if not line.strip():continue
        h,n=line.split(None,1);n=n.strip().removeprefix('./');p=(PACKAGE/n).resolve()
        if not p.is_relative_to(PACKAGE) or n in listed or not p.is_file() or sha(p)!=h.upper():
            raise RuntimeError('PACKAGE_MANIFEST_FAILURE '+n)
        listed[n]=h.upper()
    actual={p.relative_to(PACKAGE).as_posix() for p in PACKAGE.rglob('*') if p.is_file() and p!=manifest}
    if set(listed)!=actual:raise RuntimeError('PACKAGE_MANIFEST_SET_MISMATCH '+repr(actual^set(listed)))
    return sha(manifest)


def config(out: Path)->dict:
    return {
      'ticks_root':r'D:\Base CSV\WIN@N',
      'm1_root':r'D:\Base CSV\WIN@N_M1',
      'ind_d1':r'D:\Base CSV\IND@N\IND@N.csv',
      'preflight_source_root':str(DEFAULT_PREFLIGHT),
      'out_root':str(out),
      'memory_cap_mib':48528,
      'r1r11_owner_gate_receipt':str(out/'GATES'/'CORRECTNESS_PREPILOT_RECEIPT.json'),
      'correctness_fast_full_v001':True,
    }


def run_child(args, log: Path, cwd=PACKAGE):
    log.parent.mkdir(parents=True,exist_ok=True)
    with log.open('a',encoding='utf-8') as f:
        f.write('COMMAND '+json.dumps([str(x) for x in args])+'\n');f.flush()
        p=subprocess.Popen([str(x) for x in args],cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                           text=True,encoding='utf-8',errors='replace',env={**os.environ,'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'})
        for line in p.stdout:
            f.write(line);f.flush()
            if any(x in line for x in ('PASS','BLOCKED','PROGRESS','SESSION_COMMIT','RUN_MONTH_HASH_VERIFIED','GRANTED_WORKERS','SAFE_STOP')):
                print(line.rstrip(),flush=True)
        code=p.wait();f.write(f'EXIT_CODE={code}\n')
    if code!=0:raise RuntimeError(f'CHILD_FAILED exit={code} log={log}')


def _economic_tree(root: Path)->dict:
    out={}
    for p in sorted((root/'sessions').rglob('*')):
        if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
    out['CHECKPOINT.json']=sha(root/'CHECKPOINT.json')
    return out


def synthetic_qualify(out: Path, workers: int):
    gates=out/'GATES'; receipt=gates/'CORRECTNESS_SYNTHETIC_RECEIPT.json'
    pkg_hash=verify_package()
    if receipt.is_file():
        r=json.loads(receipt.read_text())
        if r.get('status')=='PASS' and r.get('package_manifest_sha256')==pkg_hash:
            print('CORRECTNESS_SYNTHETIC=RESUME_PASS',flush=True);return r
    syn=out/'CORRECTNESS_SYNTHETIC';inputs=syn/'inputs';oracle=syn/'oracle';candidate=syn/'candidate'
    if syn.exists():
        import shutil;shutil.rmtree(syn)
    syn.mkdir(parents=True)
    from r1r11_fixtures import generate
    generate(inputs,heavy_cycles=1200)
    run_child([sys.executable,'-X','utf8','-B',PACKAGE/'r1r11_fixtures.py','--inputs',inputs,'--out',oracle,'--role','oracle'],syn/'oracle.log')
    run_child([sys.executable,'-X','utf8','-B',PACKAGE/'r1r11_fixtures.py','--inputs',inputs,'--out',candidate,'--role','candidate','--workers',str(workers)],syn/'candidate.log')
    if _economic_tree(oracle)!=_economic_tree(candidate):raise RuntimeError('CORRECTNESS_SYNTHETIC_BYTE_DIFFERENCE')
    # Explicit C1 inspection: every candidate CUTOFF line must equal the synthetic preflight row persisted in its receipt.
    cutoff_rows=0
    for sessdir in sorted((candidate/'sessions').iterdir()):
        if not sessdir.is_dir():continue
        sr=json.loads((sessdir/'session_receipt.json').read_text())
        cal=sr['cutoff_diagnostics_preflight']
        with gzip.open(sessdir/'trades.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                tr=json.loads(line)
                if tr.get('exit_reason')!='CUTOFF':continue
                cutoff_rows+=1
                exp=cal['cutoff_long_fill_msc'] if tr['direction']=='BUY' else cal['cutoff_short_fill_msc']
                if int(tr['cutoff_fill_msc'])!=int(exp):raise RuntimeError('C1_SYNTHETIC_FILL')
                if int(tr.get('first_cutoff_bid_msc',-1))!=int(cal['first_cutoff_bid_msc']):raise RuntimeError('C1_SYNTHETIC_BID')
                if int(tr.get('first_cutoff_ask_msc',-1))!=int(cal['first_cutoff_ask_msc']):raise RuntimeError('C1_SYNTHETIC_ASK')
    if cutoff_rows<1:raise RuntimeError('C1_SYNTHETIC_NONVACUITY_NO_CUTOFF_TRADES')
    r={'status':'PASS','package_manifest_sha256':pkg_hash,'workers':workers,'byte_equal':True,'cutoff_rows_checked':cutoff_rows,
       'oracle_execution_sha256':sha(oracle/'SYNTHETIC_EXECUTION.json'),'candidate_execution_sha256':sha(candidate/'SYNTHETIC_EXECUTION.json')}
    atomic(receipt,r);print(f'CORRECTNESS_SYNTHETIC=PASS cutoff_rows={cutoff_rows}',flush=True);return r


def rebind_and_seal(out: Path):
    cfg=config(out); phase=out/'PHASE_A'; binding_path=phase/'RUN_SOURCE_BINDING_A.json'; gates=out/'GATES'; gates.mkdir(parents=True,exist_ok=True)
    if not binding_path.is_file():
        from minotauro_v005r1_r23_binding import build_binding
        print('CORRECTNESS_REBIND=START',flush=True);build_binding(cfg,PACKAGE)
    from minotauro_v005r1_r23_contract import canonical_json_hash, write_json_atomic_canonical, runner_identity
    from minotauro_v004_io import sha256_file
    b=json.loads(binding_path.read_text())
    if b.get('status')=='PASS_REBOUND_UNSEALED':
        b['status']='PASS_SEALED_PREPILOT'
        b['correctness_fast_path']='C1_ONLY_V001'
        b['correctness_package_manifest_sha256']=verify_package()
        b['binding_content_sha256']=canonical_json_hash(b,exclude_keys={'binding_content_sha256'})
        write_json_atomic_canonical(binding_path,b)
    elif b.get('status')!='PASS_SEALED_PREPILOT':raise RuntimeError('CORRECTNESS_BINDING_STATUS '+str(b.get('status')))
    if b.get('binding_content_sha256')!=canonical_json_hash(b,exclude_keys={'binding_content_sha256'}):raise RuntimeError('CORRECTNESS_BINDING_SELF_HASH')
    if sha256_file(phase/'SESSION_CALENDAR_PHASE_A.csv')!=b.get('session_calendar_sha256'):raise RuntimeError('CORRECTNESS_CALENDAR_HASH')
    rh,_=runner_identity(PACKAGE)
    r={'status':'PASS','authority':'OWNER_EXPLICIT_FULL_CORRECT_ASAP_20260928','package_manifest_sha256':verify_package(),
       'runner_sha256':rh,'run_source_binding_sha256':sha(binding_path),'C1_CUTOFF_FIX':'PASS_REQUIRED','performance_gate_blocking':False}
    atomic(gates/'CORRECTNESS_PREPILOT_RECEIPT.json',r);print('CORRECTNESS_BINDING=PASS_SEALED',flush=True);return r


def _patch_authority(out: Path, full=False):
    import minotauro_v004_runner as runner
    import r1r11_contract as contract
    from minotauro_v004_io import sha256_file
    prep=out/'GATES'/'CORRECTNESS_PREPILOT_RECEIPT.json'; fullp=out/'GATES'/'CORRECTNESS_FULL_AUTHORIZATION.json'
    def req_owner(cfg):
        p=fullp if full else prep
        if not p.is_file():raise runner.ModelError('CORRECTNESS_AUTHORITY_REQUIRED')
        obj=json.loads(p.read_text());
        if obj.get('status')!='PASS' or obj.get('package_manifest_sha256')!=verify_package():raise runner.ModelError('CORRECTNESS_AUTHORITY_STALE')
        return obj
    def req_pre(root,package_root,identity):return sha256_file(prep)
    def req_run(root,package_root,identity):return sha256_file(fullp)
    def req_pilot(root,identity,prepilot_hash):
        if prepilot_hash!=sha256_file(prep):raise runner.ModelError('CORRECTNESS_PILOT_AUTH_HASH')
    contract.require_owner_gates=req_owner
    runner._require_prepilot_gates=req_pre
    runner._require_pilot_authorization=req_pilot
    runner._require_run_a_gates=req_run
    return runner


def run_phase(out: Path, mode: str, workers: int):
    runner=_patch_authority(out,full=(mode=='RUN_A'))
    cfg=config(out)
    print(f'CORRECTNESS_REAL_RUN_START mode={mode} workers={workers}',flush=True)
    runner.run_phase_a(cfg,mode,workers=workers,batch_rows=32)


def _trade_key(tr):
    return (tr.get('direction'),int(tr.get('n_ordinal',-1)),int(tr.get('n1_ordinal',-1)),int(tr.get('entry_ordinal',-1)),
            int(tr.get('exit_ordinal',-1)),int(tr.get('entry_price_micro',0)),int(tr.get('exit_price_micro',0)),tr.get('exit_reason'),int(tr.get('net_pnl_units',0)))


def pilot_reconcile(out: Path):
    gates=out/'GATES'; dest=gates/'CORRECTNESS_PILOT_RECONCILIATION.json'
    if dest.is_file() and json.loads(dest.read_text()).get('status')=='PASS':print('CORRECTNESS_PILOT_RECONCILIATION=RESUME_PASS');return
    from minotauro_v004_io import load_d1, iter_tick_file
    from minotauro_v004_core import valid_cells, BASELINE_CELL_ID
    from minotauro_v005r1_r23_reference import ReferencePilotEngine
    phase=out/'PHASE_A';pilot=out/'PILOT_A';cfg=config(out)
    pr=json.loads((pilot/'PILOT_RUN_RECEIPT.json').read_text());sessions=pr['sessions']
    if len(sessions)!=3:raise RuntimeError('PILOT_NOT_3')
    with (phase/'SESSION_CALENDAR_PHASE_A.csv').open('r',encoding='utf-8-sig',newline='') as f:calendar={r['session_date']:r for r in csv.DictReader(f,delimiter=';')}
    d1=load_d1(Path(cfg['ind_d1']));cells=valid_cells();refs={};by_file={}
    for s in sessions:by_file.setdefault(Path(calendar[s]['tick_file']),[]).append(s)
    for tp,ss in sorted(by_file.items(),key=lambda kv:str(kv[0])):
        engs={}
        for rec in iter_tick_file(tp,include_sessions=set(ss)):
            if rec.session not in engs:
                row=calendar[rec.session];engs[rec.session]=ReferencePilotEngine(rec.session,d1[row['expected_previous_session_date']],cells,int(row['cutoff_msc']))
            engs[rec.session].process(rec)
        for s in ss:refs[s]=engs[s].finish()
    mismatches=[];c1=0
    for s in sessions:
        rows=[]
        with gzip.open(pilot/'sessions'/s/'trades.jsonl.gz','rt',encoding='utf-8') as f:rows=[json.loads(x) for x in f if x.strip()]
        by={}
        for tr in rows:by.setdefault(tr['cell_id'],[]).append(tr)
        for c in cells:
            pv=sorted(by.get(c.cell_id,[]),key=lambda x:(int(x.get('entry_ordinal',-1)),int(x.get('exit_ordinal',-1))))
            rv=refs[s].get(c.cell_id,[])
            pa=[_trade_key(x) for x in pv] if c.cell_id==BASELINE_CELL_ID else ([_trade_key(pv[0])] if pv else [])
            ra=[_trade_key(x) for x in rv] if c.cell_id==BASELINE_CELL_ID else ([_trade_key(rv[0])] if rv else [])
            if pa!=ra:mismatches.append((s,c.cell_id,'ECONOMIC'))
        cal=calendar[s]
        for tr in rows:
            if tr.get('exit_reason')!='CUTOFF':continue
            c1+=1;exp=int(cal['cutoff_long_fill_msc'] if tr['direction']=='BUY' else cal['cutoff_short_fill_msc'])
            if int(tr['cutoff_fill_msc'])!=exp or int(tr.get('first_cutoff_bid_msc',-1))!=int(cal['first_cutoff_bid_msc']) or int(tr.get('first_cutoff_ask_msc',-1))!=int(cal['first_cutoff_ask_msc']):
                mismatches.append((s,tr['cell_id'],'C1'))
    r={'status':'PASS' if not mismatches else 'FAIL','sessions':sessions,'mismatches':len(mismatches),'c1_cutoff_rows_checked':c1}
    atomic(dest,r)
    if mismatches:raise RuntimeError('CORRECTNESS_PILOT_RECONCILIATION_FAIL '+repr(mismatches[:5]))
    print(f'CORRECTNESS_PILOT_RECONCILIATION=PASS c1_cutoff_rows={c1}',flush=True)


def disk_gate_after_pilot(out: Path):
    pilot_sessions=out/'PILOT_A'/'sessions'
    if not pilot_sessions.is_dir():raise RuntimeError('DISK_GATE_PILOT_SESSIONS_MISSING')
    sizes=[]
    for d in sorted(pilot_sessions.iterdir()):
        if d.is_dir():sizes.append(sum(p.stat().st_size for p in d.rglob('*') if p.is_file()))
    if len(sizes)!=3:raise RuntimeError('DISK_GATE_PILOT_SESSION_COUNT')
    max_session=max(sizes); projected=max_session*250
    required=int(projected*1.35 + 10*1024**3)
    usage=shutil.disk_usage(out.anchor or str(out))
    receipt={'pilot_session_bytes':sizes,'max_pilot_session_bytes':max_session,'projected_250_bytes':projected,
             'safety_factor':1.35,'fixed_reserve_bytes':10*1024**3,'required_free_bytes':required,'actual_free_bytes':usage.free,
             'status':'PASS' if usage.free>=required else 'BLOCKED'}
    atomic(out/'GATES'/'CORRECTNESS_DISK_GATE.json',receipt)
    print(f'CORRECTNESS_DISK_GATE={receipt["status"]} free_gib={usage.free/1024**3:.2f} required_gib={required/1024**3:.2f}',flush=True)
    if receipt['status']!='PASS':raise RuntimeError('FULL_DISK_CAPACITY_INSUFFICIENT')
    return receipt

def authorize_full(out: Path):
    prep=json.loads((out/'GATES'/'CORRECTNESS_PREPILOT_RECEIPT.json').read_text());pilot=json.loads((out/'GATES'/'CORRECTNESS_PILOT_RECONCILIATION.json').read_text())
    if prep.get('status')!='PASS' or pilot.get('status')!='PASS':raise RuntimeError('CORRECTNESS_FULL_AUTH_PREREQ')
    r={'status':'PASS','RUN_A_AUTHORIZED':'YES','authority':'OWNER_EXPLICIT_FULL_CORRECT_ASAP_20260928','package_manifest_sha256':verify_package(),
       'prepilot_receipt_sha256':sha(out/'GATES'/'CORRECTNESS_PREPILOT_RECEIPT.json'),'pilot_reconciliation_sha256':sha(out/'GATES'/'CORRECTNESS_PILOT_RECONCILIATION.json'),
       'performance_gate_blocking':False}
    atomic(out/'GATES'/'CORRECTNESS_FULL_AUTHORIZATION.json',r);print('CORRECTNESS_FULL_AUTHORIZATION=PASS',flush=True)


def homologate(out: Path):
    phase=out/'PHASE_A';gates=out/'GATES';cp=json.loads((phase/'CHECKPOINT.json').read_text())
    done=cp.get('completed',[]);verified=cp.get('verified_months',{})
    if len(done)!=250 or len(set(done))!=250:raise RuntimeError('FULL_COMPLETED_NOT_250')
    if len(verified)!=12:raise RuntimeError('FULL_MONTHS_NOT_12')
    sessions=phase/'sessions';actual={p.name for p in sessions.iterdir() if p.is_dir()}
    if actual!=set(done):raise RuntimeError('FULL_SESSION_SET')
    if json.loads((phase/'EQUITY_LOSSLESS_GATE.json').read_text()).get('status')!='PASS':raise RuntimeError('FULL_EQUITY_LOSSLESS')
    with (phase/'SESSION_CALENDAR_PHASE_A.csv').open('r',encoding='utf-8-sig',newline='') as f:cal={r['session_date']:r for r in csv.DictReader(f,delimiter=';')}
    c1=0
    for s in sorted(done):
        files={p.name for p in (sessions/s).iterdir() if p.is_file()}
        if files!={'trades.jsonl.gz','events.jsonl.gz','equity.jsonl.gz','equity_reconciliation.jsonl.gz','session_receipt.json'}:raise RuntimeError('FULL_SESSION_FILES '+s)
        sr=json.loads((sessions/s/'session_receipt.json').read_text()); row=cal[s]
        pre=sr['cutoff_diagnostics_preflight']
        for k in ('first_cutoff_bid_msc','first_cutoff_ask_msc','cutoff_long_fill_msc','cutoff_short_fill_msc'):
            if int(pre[k])!=int(row[k]):raise RuntimeError('FULL_RECEIPT_C1 '+s+' '+k)
        with gzip.open(sessions/s/'trades.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                tr=json.loads(line)
                if tr.get('exit_reason')!='CUTOFF':continue
                c1+=1;exp=int(row['cutoff_long_fill_msc'] if tr['direction']=='BUY' else row['cutoff_short_fill_msc'])
                if int(tr['cutoff_fill_msc'])!=exp or int(tr.get('first_cutoff_bid_msc',-1))!=int(row['first_cutoff_bid_msc']) or int(tr.get('first_cutoff_ask_msc',-1))!=int(row['first_cutoff_ask_msc']):
                    raise RuntimeError('FULL_TRADE_C1 '+s+' '+tr['cell_id'])
    # Verify master manifest exactly.
    master=phase/'SHA256SUMS.txt';listed={}
    for line in master.read_text().splitlines():
        h,rel=line.split(None,1);rel=rel.strip().removeprefix('./');p=phase/rel
        if not p.is_file() or sha(p)!=h.upper():raise RuntimeError('FULL_MASTER_HASH '+rel)
        listed[rel]=h.upper()
    actual_files={p.relative_to(phase).as_posix() for p in phase.rglob('*') if p.is_file() and p.name!='CHECKPOINT.json' and not p.name.endswith('.tmp') and p!=master}
    if set(listed)!=actual_files:raise RuntimeError('FULL_MASTER_SET')
    r={'CORRECTNESS_FULL_HOMOLOGATION':'PASS','sessions':250,'verified_months':12,'c1_cutoff_rows_checked':c1,
       'package_manifest_sha256':verify_package(),'checkpoint_sha256':sha(phase/'CHECKPOINT.json'),'master_manifest_sha256':sha(master),
       'selection_freeze_sha256':sha(phase/'SELECTION_FREEZE.json'),'run_manifest_sha256':sha(phase/'RUN_MANIFEST.json')}
    atomic(gates/'CORRECTNESS_FULL_HOMOLOGATION_RECEIPT.json',r)
    print(f'CORRECTNESS_FULL_HOMOLOGATION=PASS sessions=250 cutoff_rows={c1}',flush=True)


def all_chain(out: Path,workers:int):
    out.mkdir(parents=True,exist_ok=True)
    cfg=config(out); (out/'CORRECTNESS_CONFIG.json').write_text(json.dumps(cfg,indent=2),encoding='utf-8')
    synthetic_qualify(out,workers)
    rebind_and_seal(out)
    pilot_receipt=out/'PILOT_A'/'PILOT_RUN_RECEIPT.json'
    if not pilot_receipt.is_file():run_phase(out,'PILOT_A',workers)
    pilot_reconcile(out)
    disk_gate_after_pilot(out)
    authorize_full(out)
    cp=out/'PHASE_A'/'CHECKPOINT.json'
    complete=False
    if cp.is_file():
        try:complete=len(json.loads(cp.read_text()).get('completed',[]))==250
        except Exception:pass
    if not complete:run_phase(out,'RUN_A',workers)
    homologate(out)
    print('MINOTAURO_FULL_CORRECT_CHAIN=PASS',flush=True)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('command',choices=['all','qualify','pilot','full','homologate'],default='all',nargs='?');ap.add_argument('--out',default=str(DEFAULT_OUT));ap.add_argument('--workers',type=int,default=12)
    ns=ap.parse_args();out=Path(ns.out)
    try:
        if ns.command=='all':all_chain(out,ns.workers)
        elif ns.command=='qualify':synthetic_qualify(out,ns.workers);rebind_and_seal(out)
        elif ns.command=='pilot':rebind_and_seal(out);run_phase(out,'PILOT_A',ns.workers);pilot_reconcile(out)
        elif ns.command=='full':authorize_full(out);run_phase(out,'RUN_A',ns.workers)
        else:homologate(out)
    except KeyboardInterrupt:
        print('SAFE_STOP=YES',flush=True);raise SystemExit(130)
    except Exception as e:
        print('MINOTAURO_FULL_CORRECT_CHAIN=BLOCKED',flush=True);print(f'ERROR={type(e).__name__}:{e}',flush=True);traceback.print_exc();raise SystemExit(2)

if __name__=='__main__':main()
