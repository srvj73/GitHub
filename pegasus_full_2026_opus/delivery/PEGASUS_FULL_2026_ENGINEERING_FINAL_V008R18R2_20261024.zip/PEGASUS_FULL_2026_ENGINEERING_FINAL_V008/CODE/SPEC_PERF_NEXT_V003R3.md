# SPEC — MINOTAURO PERF NEXT V003R3 — ATOMIC STATUS + FINAL REPORT

STATUS=DEVELOPMENT_ONLY_WHILE_V003R1_FULL_ACTIVE
BASE=V003R2
ECONOMIC_DELTA=NONE
ACTIVATE_DURING_CURRENT_V003R1_FULL=FORBIDDEN

## Delta
- `TELEMETRY/R1R11_STATUS.json` becomes the atomic machine-readable live status.
- Global PCT is derived only from COMMITTED/TOTAL; in-session rows never advance it.
- The 30 s heartbeat updates PHASE/ACTIVE/READY_WAITING/RATE/ETA/FINISH/CHECKPOINT/SAFE_STOP.
- Session commit advances COMMITTED only after the durable session commit/checkpoint path.
- Runtime close records owned process-tree clean evidence.
- Homologation requires RUN_A_PASS + 250/250 + ACTIVE=0 + PROCESS_TREE_CLEAN=YES,
  no RUN.lock and no scratch residue.
- Homologation emits `GATES/FINAL_REPORT.json` with counts, hashes, cleanup and residual-tree state.

## Not changed
economics, parser, worker engine, C1, trade ordering, W15/B256, SHARED_SLOTS=1,
source seek semantics, transaction protocol, session publication bytes.
