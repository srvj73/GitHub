"""E7 external one-shot G4 controller with consumption ledger."""
from __future__ import annotations
import argparse, hashlib, json, os, subprocess, sys, time
from pathlib import Path

PACKAGE=Path(__file__).resolve().parent


def sha(path: Path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest().upper()


def atomic(path: Path,obj):
    from minotauro_v005r1_r23_contract import write_json_atomic_canonical
    write_json_atomic_canonical(path,obj)


def economic(root: Path):
    out={}
    for p in sorted((root/'sessions').rglob('*')) if (root/'sessions').is_dir() else []:
        if p.is_file(): out[p.relative_to(root).as_posix()]=sha(p)
    cp=root/'CHECKPOINT.json'
    if cp.is_file(): out['CHECKPOINT.json']=sha(cp)
    return out


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--owner-output',required=True);ap.add_argument('--ledger-root',required=True);ap.add_argument('--a0-receipt',required=True);ap.add_argument('--dev-bench-receipt',required=True)
    ns=ap.parse_args(); owner=Path(ns.owner_output).resolve(); ledger=Path(ns.ledger_root).resolve()
    if not owner.is_dir(): raise SystemExit('G4_CONTROLLER_BLOCKED OWNER_OUTPUT_MISSING')
    if ledger==owner or ledger.is_relative_to(owner) or owner.is_relative_to(ledger): raise SystemExit('G4_CONTROLLER_BLOCKED LEDGER_MUST_BE_EXTERNAL')
    ledger.mkdir(parents=True,exist_ok=True)
    from r1r11_owner_gates import verify_package
    package_hash=verify_package()
    a0_path=Path(ns.a0_receipt).resolve(); dev_path=Path(ns.dev_bench_receipt).resolve()
    if not a0_path.is_file(): raise SystemExit('G4_CONTROLLER_BLOCKED A0_GO_RECEIPT_MISSING')
    if not dev_path.is_file(): raise SystemExit('G4_CONTROLLER_BLOCKED DEV_BENCH_RECEIPT_MISSING')
    a0=json.loads(a0_path.read_text(encoding='utf-8')); dev=json.loads(dev_path.read_text(encoding='utf-8'))
    if a0.get('A0_GO_NO_GO')!='GO': raise SystemExit('G4_CONTROLLER_BLOCKED A0_NOT_GO')
    if dev.get('R1R11_V005R1_DEV_BENCH')!='PASS' or len(dev.get('pairs',[]))!=3 or not all(bool(x.get('pass')) for x in dev.get('pairs',[])):
        raise SystemExit('G4_CONTROLLER_BLOCKED DEV_BENCH_NOT_PASS_3_OF_3')
    for n in (1,2,3):
        p=owner/f'G{n}.json'
        if not p.is_file(): raise SystemExit(f'G4_CONTROLLER_BLOCKED G{n}_MISSING')
        obj=json.loads(p.read_text())
        if obj.get('status')!='PASS' or obj.get('package_sha256')!=package_hash: raise SystemExit(f'G4_CONTROLLER_BLOCKED G{n}_NOT_FRESH_PASS')
    forbidden=[]
    for p in owner.iterdir():
        if p.name.upper().startswith('G4'):
            forbidden.append(p.name)
    if forbidden: raise SystemExit('G4_CONTROLLER_BLOCKED PRIOR_G4_ARTIFACT='+','.join(sorted(forbidden)))
    ledger_path=ledger/f'G4_LEDGER_{package_hash}.json'
    if ledger_path.exists(): raise SystemExit('G4_CONTROLLER_BLOCKED MANIFEST_ALREADY_CONSUMED')
    command=[sys.executable,'-X','utf8','-B',str(PACKAGE/'r1r11_owner_gates.py'),'--owner-output',str(owner),'--stop-after','4']
    started_wall=time.time_ns(); started_mono=time.perf_counter_ns()
    initial={'status':'CONSUMED_LAUNCHED','package_sha256':package_hash,'sha256sums_sha256':sha(PACKAGE/'SHA256SUMS.txt'),
             'owner_output':str(owner),'command':command,'stop_after':4,'started_wall_time_ns':started_wall,'started_monotonic_ns':started_mono,
             'rerun_same_identity_authorized':False,'a0_receipt_sha256':sha(a0_path),'dev_bench_receipt_sha256':sha(dev_path)}
    atomic(ledger_path,initial)
    log=ledger/f'G4_CONTROLLER_{package_hash}.log'
    with log.open('x',encoding='utf-8') as f:
        f.write('COMMAND='+json.dumps(command)+'\n');f.flush()
        p=subprocess.Popen(command,cwd=PACKAGE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',env={**os.environ,'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'})
        for line in p.stdout:
            f.write(line);f.flush()
            if 'PROGRESS' in line or 'GRANTED_WORKERS' in line: print(line.rstrip(),flush=True)
        code=p.wait();f.write(f'EXIT_CODE={code}\n')
    diag={'status':'NOT_AVAILABLE'}
    o=owner/'G4_oracle';c=owner/'G4_candidate'
    if o.is_dir() and c.is_dir() and (o/'CHECKPOINT.json').is_file() and (c/'CHECKPOINT.json').is_file():
        a=economic(o);b=economic(c)
        diag={'status':'PASS_EQUAL' if a==b else 'FAIL_DIFFERENT','equal':a==b,'oracle_files':len(a),'candidate_files':len(b),
              'oracle_only':sorted(set(a)-set(b)),'candidate_only':sorted(set(b)-set(a)),
              'hash_mismatch':sorted(k for k in set(a)&set(b) if a[k]!=b[k])}
        atomic(ledger/f'G4_ECONOMIC_DIAGNOSTIC_{package_hash}.json',diag)
    g4=json.loads((owner/'G4.json').read_text()) if (owner/'G4.json').is_file() else None
    measured=json.loads((owner/'G4_MEASURED.json').read_text()) if (owner/'G4_MEASURED.json').is_file() else None
    final={**initial,'status':'CONSUMED_COMPLETE','exit_code':code,'ended_wall_time_ns':time.time_ns(),'ended_monotonic_ns':time.perf_counter_ns(),
           'controller_log_sha256':sha(log),'g4_receipt':g4,'g4_measured':measured,'economic_diagnostic':diag,
           'g4_status_unchanged_by_diagnostic':True}
    atomic(ledger_path,final)
    atomic(ledger/f'G4_CONTROLLER_RECEIPT_{package_hash}.json',final)
    print(json.dumps({'G4_CONTROLLER':'COMPLETE','exit_code':code,'package_sha256':package_hash,'economic_diagnostic':diag['status']},sort_keys=True))
    raise SystemExit(code)

if __name__=='__main__': main()
