# POST-FULL benchmark plan — PERF NEXT V002

1. Windows PowerShell 5.1 parse + Inspect only.
2. Synthetic differential: W12/B32 baseline-compatible vs W15/B32 vs W15/B256; identical canonical bytes and oracle required.
3. Short real-session benchmark in a fresh output root only after current FULL ends.
4. Record aggregate CPU, per-role CPU, rows/s, worker span/skew, ACK, stream wait, writer, verifier, FINISH, RAM and disk.
5. Success is material wall-time reduction with zero semantic/byte drift. No arbitrary speedup threshold.
6. If W15/B256 fails any correctness gate, fall back to W15/B32, then W12/B32.
