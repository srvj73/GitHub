"""R1R11 V005R1 A0: read-only forensic collection, diagnosis and non-gate budget probes.

The collector never imports or executes the preserved V004R2R1 candidate.  It may
read/copy/hash preserved owner evidence only.  Microbenchmarks operate on the
copied G4 oracle outputs and on disposable files inside the A0 output root.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import heapq
import io
import json
import multiprocessing as mp
import os
import shutil
import struct
import time
import zipfile
from pathlib import Path

# Primary V004R2R1 owner evidence called out by the Opus 5.5 audit.
REQUIRED_OWNER_TOP = [
    "G1.json", "G2.json", "G3.json", "G4.json", "G4_MEASURED.json",
    "PREREGISTRATION.json", "V4_PRE_G4/RESULTS.json",
    "G4_oracle.log", "G4_candidate.log",
    "synthetic_inputs/FIXTURES.json", "synthetic_inputs/heavy.csv",
]
# The audit calls TEST_DISCOVERY.json from the owner root.  Some historical
# builders nested it in V4_PRE_G4; accept that historical location explicitly,
# but record which physical source satisfied the requirement.
OWNER_ALTERNATIVES = {
    "TEST_DISCOVERY.json": ["TEST_DISCOVERY.json", "V4_PRE_G4/TEST_DISCOVERY.json"],
}
REQUIRED_OWNER_TREES = ["G4_oracle", "G4_candidate"]
REQUIRED_CONTROL_TOP = ["RECEIPT.json", "controller.log"]
CANONICAL_SESSION_FILES = (
    "trades.jsonl.gz", "events.jsonl.gz", "equity.jsonl.gz",
    "equity_reconciliation.jsonl.gz", "session_receipt.json",
)
STREAMS = ("trades", "events", "equity", "equity_reconciliation")


def sha256_file(path: Path, chunk: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(chunk), b""):
            h.update(b)
    return h.hexdigest().upper()


def meta(path: Path) -> dict:
    s = path.stat()
    return {
        "bytes": s.st_size,
        "st_dev": s.st_dev,
        "st_ino": s.st_ino,
        "st_mtime_ns": s.st_mtime_ns,
        "st_ctime_ns": s.st_ctime_ns,
        "st_birthtime_ns": getattr(s, "st_birthtime_ns", None),
        "sha256": sha256_file(path),
    }


def dir_meta(path: Path) -> dict:
    s = path.stat()
    return {
        "st_dev": s.st_dev, "st_ino": s.st_ino,
        "st_mtime_ns": s.st_mtime_ns, "st_ctime_ns": s.st_ctime_ns,
        "st_birthtime_ns": getattr(s, "st_birthtime_ns", None),
    }


def _prepare_measurement_out(out: Path) -> None:
    if out.exists() and any(out.iterdir()):
        raise RuntimeError("A0_MEASUREMENT_OUT_MUST_BE_NEW_OR_EMPTY " + str(out))
    out.mkdir(parents=True, exist_ok=True)


def copy_readonly(source: Path, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        raise RuntimeError("A0_DEST_EXISTS " + str(dest))
    shutil.copy2(source, dest)


def _add_tree(root: Path, requested: list[tuple[Path, str]], prefix: str) -> None:
    requested.extend((p, prefix) for p in root.rglob("*") if p.is_file())


def _discover_v004r1(source_root: Path) -> tuple[Path | None, str]:
    parent = source_root.parent
    candidates = []
    for p in parent.iterdir() if parent.is_dir() else []:
        if not p.is_dir() or "V004R1" not in p.name.upper():
            continue
        if (p / "G4.json").is_file():
            candidates.append(p.resolve())
    if len(candidates) == 1:
        return candidates[0], "AUTO_DISCOVERED_UNIQUE"
    if not candidates:
        return None, "AUTO_DISCOVERY_NONE"
    return None, "AUTO_DISCOVERY_AMBIGUOUS:" + "|".join(str(x) for x in candidates)


def _write_collection_manifest(out: Path) -> tuple[int, str]:
    manifest = out / "SHA256SUMS.txt"
    rows = []
    for p in sorted(x for x in out.rglob("*") if x.is_file() and x != manifest):
        rows.append(f"{sha256_file(p)}  {p.relative_to(out).as_posix()}")
    manifest.write_text("\n".join(rows) + "\n", encoding="utf-8", newline="\n")
    return len(rows), sha256_file(manifest)


def _zip_collection(out: Path) -> tuple[Path, str, int]:
    dest = out.parent / (out.name + ".zip")
    side = out.parent / (out.name + ".zip.sha256.txt")
    if dest.exists() or side.exists():
        raise RuntimeError("A0_COLLECTION_ZIP_OR_SIDECAR_EXISTS")
    tmp = dest.with_suffix(dest.suffix + ".tmp")
    count = 0
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as z:
        for p in sorted(x for x in out.rglob("*") if x.is_file()):
            z.write(p, (Path(out.name) / p.relative_to(out)).as_posix())
            count += 1
    os.replace(tmp, dest)
    zsha = sha256_file(dest)
    side.write_text(f"{zsha}  {dest.name}\n", encoding="ascii", newline="\n")
    return dest, zsha, count


def collect(source_root: Path, out: Path, v004r1_root: Path | None = None,
            control_root: Path | None = None) -> dict:
    source_root = source_root.resolve()
    out = out.resolve()
    if not source_root.is_dir():
        raise RuntimeError("A0_SOURCE_ROOT_MISSING")
    if out.exists():
        raise RuntimeError("A0_OUTPUT_MUST_BE_NEW")

    discovery = "EXPLICIT"
    if v004r1_root is None:
        v004r1_root, discovery = _discover_v004r1(source_root)
    else:
        v004r1_root = v004r1_root.resolve()
    control_root = (control_root.resolve() if control_root is not None else source_root)

    out.mkdir(parents=True)
    requested: list[tuple[Path, str]] = []
    missing: list[str] = []
    satisfiers: dict[str, str] = {}

    for rel in REQUIRED_OWNER_TOP:
        p = source_root / rel
        if p.is_file():
            requested.append((p, "V004R2R1_OWNER")); satisfiers[rel] = str(p)
        else:
            missing.append(rel)
    for logical, choices in OWNER_ALTERNATIVES.items():
        found = [source_root / rel for rel in choices if (source_root / rel).is_file()]
        if len(found) == 1:
            requested.append((found[0], "V004R2R1_OWNER")); satisfiers[logical] = str(found[0])
        elif not found:
            missing.append(logical)
        else:
            # Duplicate equivalent locations are ambiguous evidence unless byte-identical.
            hashes = {sha256_file(x) for x in found}
            if len(hashes) != 1:
                missing.append(logical + "_AMBIGUOUS_MULTIPLE")
            else:
                requested.append((found[0], "V004R2R1_OWNER")); satisfiers[logical] = str(found[0])

    for rel in REQUIRED_OWNER_TREES:
        p = source_root / rel
        if not p.is_dir():
            missing.append(rel + "/")
        else:
            _add_tree(p, requested, "V004R2R1_OWNER")

    for rel in REQUIRED_CONTROL_TOP:
        p = control_root / rel
        if p.is_file():
            requested.append((p, "CONTROL_ROOT")); satisfiers["CONTROL_ROOT/" + rel] = str(p)
        else:
            missing.append("CONTROL_ROOT/" + rel)

    if v004r1_root is None or not v004r1_root.is_dir():
        missing.append("V004R1_OWNER_ROOT")
    else:
        _add_tree(v004r1_root, requested, "V004R1_OWNER")

    # Deduplicate physical files while preserving the evidence namespace.
    unique: dict[tuple[str, str], Path] = {}
    for p, prefix in requested:
        unique[(str(p.resolve()), prefix)] = p.resolve()

    records = []
    for (_, prefix), p in sorted(unique.items(), key=lambda kv: (kv[0][1], kv[0][0])):
        if prefix == "V004R2R1_OWNER": base = source_root
        elif prefix == "V004R1_OWNER": base = v004r1_root
        else: base = control_root
        assert base is not None
        rel = Path(prefix) / p.relative_to(base)
        before = meta(p)
        copy_readonly(p, out / rel)
        after = meta(p)
        if before != after:
            raise RuntimeError("A0_SOURCE_CHANGED_DURING_COLLECTION " + str(p))
        copied = meta(out / rel)
        if copied["sha256"] != before["sha256"]:
            raise RuntimeError("A0_COPY_HASH_MISMATCH " + str(p))
        records.append({"source": str(p), "copy": rel.as_posix(), "namespace": prefix, **before})

    directory_records = []
    for tree_name in REQUIRED_OWNER_TREES:
        tree = source_root / tree_name
        if tree.is_dir():
            for d in sorted(x for x in tree.rglob("*") if x.is_dir()):
                before = dir_meta(d); after = dir_meta(d)
                if before != after:
                    raise RuntimeError("A0_SOURCE_DIR_CHANGED_DURING_COLLECTION " + str(d))
                directory_records.append({"source": str(d), "copy": (Path("V004R2R1_OWNER") / d.relative_to(source_root)).as_posix(), **before})

    receipt = {
        "A0_1_FORENSIC_COLLECTION": "PASS" if not missing else "PARTIAL_MISSING_PRIMARY_EVIDENCE",
        "source_root": str(source_root),
        "control_root": str(control_root),
        "v004r1_root": str(v004r1_root) if v004r1_root else None,
        "v004r1_discovery": discovery,
        "files": records,
        "directories": directory_records,
        "required_satisfiers": satisfiers,
        "missing": missing,
        "source_mutation": "NONE_BY_COLLECTOR",
        "candidate_execution": "NO",
        "candidate_import": "NO",
    }
    (out / "A0_1_COLLECTION.json").write_text(
        json.dumps(receipt, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8"
    )
    # Seal the evidence root first. Packaging facts live beside the ZIP to avoid a
    # circular dependency in which embedding the ZIP hash would change the ZIP.
    manifest_entries, manifest_sha = _write_collection_manifest(out)
    zpath, zsha, zentries = _zip_collection(out)
    external = out.parent / (out.name + ".PACKAGE_RECEIPT.json")
    package_facts = {
        "A0_COLLECTION_PACKAGE": "PASS" if not missing else "PARTIAL_MISSING_PRIMARY_EVIDENCE",
        "collection_root": str(out), "manifest_entries": manifest_entries,
        "manifest_sha256": manifest_sha, "zip": str(zpath), "zip_sha256": zsha,
        "zip_entries": zentries, "missing": missing,
    }
    external.write_text(json.dumps(package_facts, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return {**receipt, **package_facts, "external_package_receipt": str(external)}


def _collection_file(evidence: Path, rel: str) -> Path:
    p = evidence / "V004R2R1_OWNER" / rel
    if not p.is_file():
        raise RuntimeError("A0_PRIMARY_EVIDENCE_MISSING " + rel)
    return p


def _metadata_index(evidence: Path) -> dict[str, dict]:
    receipt = json.loads((evidence / "A0_1_COLLECTION.json").read_text(encoding="utf-8"))
    return {r["copy"]: r for r in receipt.get("files", [])}


def forensic(evidence: Path, prereg: Path, out: Path) -> dict:
    evidence = evidence.resolve(); out = out.resolve(); _prepare_measurement_out(out)
    collection = json.loads((evidence / "A0_1_COLLECTION.json").read_text(encoding="utf-8"))
    pre = json.loads(prereg.read_text(encoding="utf-8"))
    expected = pre["source_audit_frozen_facts"]
    g4 = json.loads(_collection_file(evidence, "G4.json").read_text(encoding="utf-8"))
    measured = json.loads(_collection_file(evidence, "G4_MEASURED.json").read_text(encoding="utf-8"))
    preg = json.loads(_collection_file(evidence, "PREREGISTRATION.json").read_text(encoding="utf-8"))
    fix = json.loads(_collection_file(evidence, "synthetic_inputs/FIXTURES.json").read_text(encoding="utf-8"))
    heavy = fix["heavy"]["session"]
    telemetry_path = _collection_file(evidence, "G4_candidate/TELEMETRY/R1R11_TRANSPORT.jsonl")
    telemetry = [json.loads(x) for x in telemetry_path.read_text(encoding="utf-8").splitlines() if x.strip()]
    sched = [r for r in telemetry if r.get("event") == "SCHEDULER" and r.get("session") == heavy]
    acks = [r for r in telemetry if r.get("event") == "BATCH_ACK" and r.get("session") == heavy]
    intervals = [tuple(int(v) for v in triplet) for row in acks for triplet in row.get("intervals", [])]
    per_batch_critical = []
    overlap = False
    for row in acks:
        ints = [tuple(int(v) for v in x) for x in row.get("intervals", [])]
        if ints:
            per_batch_critical.append(max((b - a) for _, a, b in ints) / 1e9)
            overlap = overlap or any(max(a[1], b[1]) < min(a[2], b[2]) for i, a in enumerate(ints) for b in ints[i+1:])
    feed_sum_max = sum(per_batch_critical)
    feed_span = ((max(x[2] for x in intervals) - min(x[1] for x in intervals)) / 1e9) if intervals else None

    inputs = preg.get("inputs")
    input_count = len(inputs) if isinstance(inputs, dict) else -1
    checks = {
        "collection_complete": collection.get("A0_1_FORENSIC_COLLECTION") == "PASS",
        "g4_status_fail": g4.get("status") == "FAIL",
        "g4_measured_matches_speedup": abs(float(measured.get("speedup", -1)) - float(expected["speedup"])) <= 1e-12,
        "g4_measured_matches_oracle_seconds": abs(float(measured.get("oracle_seconds", -1)) - float(expected["oracle_seconds"])) <= 1e-9,
        "g4_measured_matches_candidate_seconds": abs(float(measured.get("candidate_seconds", -1)) - float(expected["candidate_seconds"])) <= 1e-9,
        "g4_granted_exact": measured.get("granted") == expected["granted"],
        "g4_overlap_true": bool(measured.get("overlap")) is True,
        "prereg_input_count_43": input_count == int(expected["prereg_input_count"]),
        "scheduler_single_heavy_grant_4": len(sched) == 1 and int(sched[0].get("decision", {}).get("granted", -1)) == 4,
        "batch_ack_count_151": len(acks) == int(expected["batch_ack_count"]),
        "interval_overlap_recomputed": overlap,
    }

    mindex = _metadata_index(evidence)
    dindex = {r["copy"]: r for r in collection.get("directories", [])}
    session_prefix = f"V004R2R1_OWNER/G4_candidate/sessions/{heavy}/"
    physical = {}
    for name in CANONICAL_SESSION_FILES:
        rec = mindex.get(session_prefix + name)
        if rec:
            physical[name] = {k: rec.get(k) for k in ("st_birthtime_ns", "st_mtime_ns", "bytes", "sha256")}
    for rel in ("G4_candidate/CHECKPOINT.json", "G4_candidate/TELEMETRY/memory.jsonl"):
        rec = mindex.get("V004R2R1_OWNER/" + rel)
        if rec:
            physical[rel] = {k: rec.get(k) for k in ("st_birthtime_ns", "st_mtime_ns", "bytes", "sha256")}
    seal_dir = dindex.get("V004R2R1_OWNER/G4_candidate/SESSION_SEALS")
    if seal_dir:
        physical["G4_candidate/SESSION_SEALS/"] = {k: seal_dir.get(k) for k in ("st_birthtime_ns", "st_mtime_ns")}

    candidate_seconds = float(measured["candidate_seconds"])
    timeline = {
        "heavy_session": heavy,
        "batch_ack_count": len(acks),
        "worker_interval_count": len(intervals),
        "sum_batch_max_worker_seconds": feed_sum_max,
        "first_to_last_worker_interval_seconds": feed_span,
        "candidate_case_seconds": candidate_seconds,
        "candidate_minus_worker_interval_span_seconds": (candidate_seconds - feed_span) if feed_span is not None else None,
        "physical_file_windows": physical,
    }
    all_pass = all(checks.values())
    receipt = {
        "A0_1_FORENSIC_RECONSTRUCTION": "PASS_MECHANICAL" if all_pass else "FAIL_OR_INCOMPLETE",
        "checks": checks,
        "timeline": timeline,
        "root_cause_status": "PARTIAL_SUPPORTED_POST_FEED_LOCUS" if all_pass else "UNRESOLVED_EVIDENCE_FAILURE",
        "note": "Component attribution remains non-factual unless phase timestamps support it; this receipt does not promote hypotheses to facts.",
    }
    (out / "A0_1_FORENSIC_REPORT.json").write_text(
        json.dumps(receipt, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8"
    )
    return receipt


def iter_rows(path: Path):
    with gzip.open(path, "rt", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                yield json.loads(line)


def iter_raw_lines(path: Path):
    with gzip.open(path, "rb") as f:
        for line in f:
            if line.strip():
                if not line.endswith(b"\n"):
                    raise RuntimeError("A0_GZIP_FRAME_MISSING_NEWLINE")
                yield line


def write_gzjson(path: Path, rows) -> None:
    with path.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0, compresslevel=6) as gz:
            with io.TextIOWrapper(gz, encoding="utf-8", newline="\n") as t:
                for r in rows:
                    t.write(json.dumps(r, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n")


def _proof_key_bytes(key: tuple) -> bytes:
    if not all(isinstance(v, int) and not isinstance(v, bool) for v in key):
        raise RuntimeError("A0_ORDER_KEY_NON_INTEGER")
    return bytes([len(key)]) + b"".join(struct.pack(">q", int(v)) for v in key)


def _is_alive_worker(n: int, conn) -> None:
    parent = mp.parent_process()
    if parent is None:
        conn.send({"seconds": None, "count": 0}); conn.close(); return
    start = time.perf_counter()
    alive = 0
    for _ in range(n):
        alive += 1 if parent.is_alive() else 0
    conn.send({"seconds": time.perf_counter() - start, "count": alive})
    conn.close()


def _is_alive_probe(n: int) -> dict:
    ctx = mp.get_context("spawn")
    parent, child = ctx.Pipe(False)
    p = ctx.Process(target=_is_alive_worker, args=(n, child))
    p.start(); child.close()
    result = parent.recv(); p.join(120)
    if p.is_alive() or p.exitcode != 0 or int(result.get("count", -1)) != n:
        raise RuntimeError("A0_IS_ALIVE_PROBE_FAILED")
    return result


def _transaction_probe(root: Path, trials: int = 7) -> dict:
    probe = root / "transaction_probe"
    probe.mkdir(exist_ok=False)
    values = []
    payload = b"R1R11_V005R1_A0_TRANSACTION_PROBE\n" * 128
    try:
        for i in range(trials):
            t0 = time.perf_counter()
            partials = []
            for j in range(5):
                p = probe / f"{i}_{j}.partial"
                with p.open("xb") as f:
                    f.write(payload); f.flush(); os.fsync(f.fileno())
                partials.append(p)
            for p in partials:
                os.replace(p, p.with_suffix(".sealed"))
            receipt = probe / f"{i}_receipt.json.tmp"
            with receipt.open("x", encoding="utf-8") as f:
                json.dump({"trial": i, "files": 5}, f, sort_keys=True); f.write("\n"); f.flush(); os.fsync(f.fileno())
            os.replace(receipt, probe / f"{i}_receipt.json")
            values.append(time.perf_counter() - t0)
        ordered = sorted(values)
        return {"trials": trials, "seconds": values, "median_seconds": ordered[len(ordered)//2],
                "max_seconds": max(values)}
    finally:
        shutil.rmtree(probe, ignore_errors=True)


def _stream_microbench(kind: str, p: Path, out: Path) -> dict:
    from minotauro_v004_core import valid_cells
    from r1r11_transport import merge_key
    cells = valid_cells()
    index = {c.cell_id: i for i, c in enumerate(cells)}
    groups = sorted({(c.p_idx, c.t_idx) for c in cells})
    ranks = {c.cell_id: groups.index((c.p_idx, c.t_idx)) for c in cells}

    tmp = out / (kind + ".rewrite.gz")
    start = time.perf_counter(); write_gzjson(tmp, iter_rows(p)); rewrite_seconds = time.perf_counter() - start
    identical = sha256_file(tmp) == sha256_file(p)
    tmp.unlink()
    if not identical:
        raise RuntimeError("A0_GZJSON_BYTE_DIFFERENCE " + kind)

    start = time.perf_counter(); rows = 0
    for raw in iter_raw_lines(p):
        json.loads(raw); rows += 1
    loads_seconds = time.perf_counter() - start

    start = time.perf_counter(); keyed = 0
    for raw in iter_raw_lines(p):
        row = json.loads(raw); merge_key(kind, row, index, ranks); keyed += 1
    loads_merge_seconds = time.perf_counter() - start
    if keyed != rows:
        raise RuntimeError("A0_ROW_COUNT_DRIFT " + kind)

    # Setup outside timed sections for isolated heap/proof measurements.
    keys = []
    for raw in iter_raw_lines(p):
        row = json.loads(raw); keys.append(tuple(merge_key(kind, row, index, ranks)))

    buckets = [keys[i::15] for i in range(15)]
    start = time.perf_counter(); heap_count = sum(1 for _ in heapq.merge(*buckets)); heap_seconds = time.perf_counter() - start
    if heap_count != rows:
        raise RuntimeError("A0_HEAP_COUNT_DRIFT " + kind)

    start = time.perf_counter(); digest_json = hashlib.sha256()
    for key in keys:
        digest_json.update((json.dumps(key, separators=(",", ":")) + "\n").encode("ascii"))
    proof_json_seconds = time.perf_counter() - start

    start = time.perf_counter(); digest_bin = hashlib.sha256()
    for key in keys:
        digest_bin.update(_proof_key_bytes(key))
    proof_binary_seconds = time.perf_counter() - start

    start = time.perf_counter(); line_sha = hashlib.sha256()
    for raw in iter_raw_lines(p):
        line_sha.update(hashlib.sha256(raw[:-1]).digest())
    sha_per_line_seconds = time.perf_counter() - start

    is_alive = _is_alive_probe(rows)
    gzip_encode_floor = max(0.0, rewrite_seconds - loads_seconds)
    merge_increment = max(0.0, loads_merge_seconds - loads_seconds)
    estimated_v5_stream_cpu = loads_seconds + merge_increment + heap_seconds + proof_binary_seconds + gzip_encode_floor
    return {
        "rows": rows,
        "source_sha256": sha256_file(p),
        "gzjson_rewrite_seconds": rewrite_seconds,
        "gzjson_byte_identical": True,
        "json_loads_seconds": loads_seconds,
        "json_loads_plus_merge_key_seconds": loads_merge_seconds,
        "merge_key_increment_seconds": merge_increment,
        "heap_15way_seconds": heap_seconds,
        "order_proof_json_seconds": proof_json_seconds,
        "order_proof_binary_seconds": proof_binary_seconds,
        "order_proof_binary_speedup_vs_json": (proof_json_seconds / proof_binary_seconds) if proof_binary_seconds > 0 else None,
        "sha256_per_line_seconds": sha_per_line_seconds,
        "parent_is_alive_per_line_seconds": is_alive["seconds"],
        "estimated_v5_stream_cpu_seconds": estimated_v5_stream_cpu,
    }


def microbench(evidence: Path, out: Path) -> dict:
    evidence = evidence.resolve(); out = out.resolve(); _prepare_measurement_out(out)
    fix = evidence / "V004R2R1_OWNER/synthetic_inputs/FIXTURES.json"
    if not fix.is_file():
        raise RuntimeError("A0_FIXTURES_MISSING")
    heavy = json.loads(fix.read_text(encoding="utf-8"))["heavy"]["session"]
    root = evidence / "V004R2R1_OWNER/G4_oracle/sessions" / heavy
    if not root.is_dir():
        raise RuntimeError("A0_ORACLE_HEAVY_MISSING")
    streams = {k: root / (k + ".jsonl.gz") for k in STREAMS}
    results = {}
    for kind, p in streams.items():
        if not p.is_file():
            raise RuntimeError("A0_STREAM_MISSING " + kind)
        results[kind] = _stream_microbench(kind, p, out)

    start = time.perf_counter(); hashes = {k: sha256_file(p) for k, p in streams.items()}; binding_seconds = time.perf_counter() - start
    transaction = _transaction_probe(out)
    receipt = {
        "A0_2_MICROBENCH": "PASS_NON_GATE",
        "heavy_session": heavy,
        "streams": results,
        "max_stream_rewrite_seconds": max(v["gzjson_rewrite_seconds"] for v in results.values()),
        "max_estimated_v5_stream_cpu_seconds": max(v["estimated_v5_stream_cpu_seconds"] for v in results.values()),
        "binding_seconds_four_files": binding_seconds,
        "transaction_probe": transaction,
        "hashes": hashes,
        "opus_required_dimensions": {
            "gzjson_per_stream": "MEASURED",
            "json_loads": "MEASURED",
            "merge_key": "MEASURED",
            "heap_15way": "MEASURED",
            "order_proof_json_vs_binary": "MEASURED",
            "sha_per_line": "MEASURED",
            "parent_is_alive_per_line": "MEASURED",
            "physical_binding": "MEASURED",
            "transaction_proxy_same_output_volume": "MEASURED",
        },
    }
    (out / "A0_2_MICROBENCH.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return receipt


def economic_tree(root: Path) -> dict[str, str]:
    result = {}
    for p in sorted((root / "sessions").rglob("*")):
        if p.is_file():
            result[p.relative_to(root).as_posix()] = sha256_file(p)
    cp = root / "CHECKPOINT.json"
    if cp.is_file():
        result["CHECKPOINT.json"] = sha256_file(cp)
    return result


def equality(evidence: Path, out: Path) -> dict:
    evidence = evidence.resolve(); out = out.resolve(); _prepare_measurement_out(out)
    o = evidence / "V004R2R1_OWNER/G4_oracle"; c = evidence / "V004R2R1_OWNER/G4_candidate"
    if not o.is_dir() or not c.is_dir():
        raise RuntimeError("A0_G4_TREES_MISSING")
    a = economic_tree(o); b = economic_tree(c); equal = a == b
    receipt = {
        "A0_3_ECONOMIC_EQUALITY": "PASS_EQUAL" if equal else "FAIL_DIFFERENT",
        "equal": equal, "oracle_files": len(a), "candidate_files": len(b),
        "oracle_only": sorted(set(a) - set(b)), "candidate_only": sorted(set(b) - set(a)),
        "hash_mismatch": sorted(k for k in set(a) & set(b) if a[k] != b[k]),
    }
    (out / "A0_3_ECONOMIC_EQUALITY.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return receipt


def evaluate(prereg: Path, forensic_path: Path, microbench_path: Path, equality_path: Path,
             out: Path, transaction_seconds: float | None = None) -> dict:
    pre = json.loads(prereg.read_text(encoding="utf-8"))
    fr = json.loads(forensic_path.read_text(encoding="utf-8"))
    mb = json.loads(microbench_path.read_text(encoding="utf-8"))
    eq = json.loads(equality_path.read_text(encoding="utf-8"))
    feed = float(pre["inherited_owner_facts_seconds"]["feed_ref"])
    spawn = float(pre["inherited_owner_facts_seconds"]["worker_spawn_upper"])
    max_stream = float(mb["max_estimated_v5_stream_cpu_seconds"])
    tail = max(0.0, max_stream - feed)
    binding = float(mb["binding_seconds_four_files"])
    trans = float(transaction_seconds if transaction_seconds is not None else mb["transaction_probe"]["max_seconds"])
    t_est = spawn + feed + tail + binding + trans
    limit = float(pre["go_no_go"]["go_max_seconds"])
    blockers = []
    if fr.get("A0_1_FORENSIC_RECONSTRUCTION") != "PASS_MECHANICAL": blockers.append("A0_FORENSIC_NOT_PASS")
    if eq.get("A0_3_ECONOMIC_EQUALITY") != "PASS_EQUAL": blockers.append("A0_ECONOMIC_EQUALITY_NOT_PASS")
    if mb.get("A0_2_MICROBENCH") != "PASS_NON_GATE": blockers.append("A0_MICROBENCH_NOT_PASS")
    budget_go = t_est <= limit
    if not budget_go: blockers.append("A0_BUDGET_GT_LIMIT")
    status = "GO" if not blockers else "NO_GO"
    receipt = {
        "A0_GO_NO_GO": status,
        "T_est_seconds": t_est, "limit_seconds": limit,
        "terms": {"spawn": spawn, "feed_ref": feed, "max_stream_tail": tail,
                  "binding": binding, "transaction": trans},
        "transaction_source": "explicit_override" if transaction_seconds is not None else "A0_2_TRANSACTION_PROBE_MAX",
        "blockers": blockers,
        "rule": pre["go_no_go"]["go_rule"],
        "same_revision_v004r2r1_g4_rerun": "FORBIDDEN",
    }
    out.write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return receipt


def main() -> None:
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest="cmd", required=True)
    p = sp.add_parser("collect"); p.add_argument("--source-root", required=True); p.add_argument("--out", required=True); p.add_argument("--v004r1-root"); p.add_argument("--control-root")
    p = sp.add_parser("forensic"); p.add_argument("--evidence", required=True); p.add_argument("--prereg", required=True); p.add_argument("--out", required=True)
    p = sp.add_parser("microbench"); p.add_argument("--evidence", required=True); p.add_argument("--out", required=True)
    p = sp.add_parser("equality"); p.add_argument("--evidence", required=True); p.add_argument("--out", required=True)
    p = sp.add_parser("evaluate"); p.add_argument("--prereg", required=True); p.add_argument("--forensic", required=True); p.add_argument("--microbench", required=True); p.add_argument("--equality", required=True); p.add_argument("--out", required=True); p.add_argument("--transaction-seconds", type=float)
    ns = ap.parse_args()
    if ns.cmd == "collect":
        r = collect(Path(ns.source_root), Path(ns.out), Path(ns.v004r1_root) if ns.v004r1_root else None,
                    Path(ns.control_root) if ns.control_root else None)
    elif ns.cmd == "forensic":
        r = forensic(Path(ns.evidence), Path(ns.prereg), Path(ns.out))
    elif ns.cmd == "microbench":
        r = microbench(Path(ns.evidence), Path(ns.out))
    elif ns.cmd == "equality":
        r = equality(Path(ns.evidence), Path(ns.out))
    else:
        r = evaluate(Path(ns.prereg), Path(ns.forensic), Path(ns.microbench), Path(ns.equality), Path(ns.out), ns.transaction_seconds)
    print(json.dumps(r, ensure_ascii=False, sort_keys=True, indent=2))
    if ns.cmd == "collect" and r.get("A0_1_FORENSIC_COLLECTION") != "PASS":
        raise SystemExit(2)
    if ns.cmd == "forensic" and r.get("A0_1_FORENSIC_RECONSTRUCTION") != "PASS_MECHANICAL":
        raise SystemExit(2)
    if ns.cmd == "equality" and r.get("A0_3_ECONOMIC_EQUALITY") != "PASS_EQUAL":
        raise SystemExit(2)
    if ns.cmd == "evaluate" and r.get("A0_GO_NO_GO") != "GO":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
