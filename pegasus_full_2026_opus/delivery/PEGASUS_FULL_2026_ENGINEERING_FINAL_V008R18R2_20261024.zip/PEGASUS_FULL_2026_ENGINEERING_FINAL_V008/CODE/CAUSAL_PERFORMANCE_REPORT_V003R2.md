# R1R11 V003R2 — diagnóstico causal e melhoria parcial

**R1R11_IMPLEMENTATION_STATUS=BLOCKED — G4 não resolvido.**

EVIDENCE: há melhoria legítima no executor normal, com byte equivalence observada, mas o candidato continua mais lento que o oracle. Esta revisão NÃO está homologada e não deve ser promovida. O ZIP entrega código auditável e diagnóstico; não representa solução do G4.

## Evidência original preservada

`D:\MinotauroRuns\MINOTAURO_R1R11_V003R1_OWNER_GATES_20260926` foi aberta somente para leitura. Nenhum receipt ou output dessa árvore foi escrito, apagado, reexecutado ou reaproveitado como destino. Os CSVs sintéticos ali selados foram lidos como inputs idênticos nos diagnósticos; os outputs novos ficam exclusivamente em `R1R11_V003R2_BUILD_20260926`. São 81 arquivos, inventariados com SHA-256 antes e depois.

G1/G2/G3 históricos PASS; G4 histórico FAIL: oracle 15,604007 s; candidato 19,6031488 s; 4 requested/granted; overlap true; speedup 0,7959949271; required 1,5. Esses receipts continuam históricos V003R1; não são herdados como PASS da V003R2.

Recovery: Git `D:\Teste Rede Neural MQL5\Pegasus\micro_transit`, `main`, HEAD `0ff570509dae1d93e487150192cd5d2280423368`; quatro alterações rastreadas preexistentes, 288 inserções/19 remoções. Sem reset/checkout/stash/clean/stage/commit. A árvore V003R1 anterior e o diagnóstico V002R2 também são preservados por hash.

## Causa demonstrada

EVIDENCE no telemetry original: 151 batches, 4.801 registros; soma do tempo do worker mais lento em cada batch = 3,0927892 s. Portanto, a maior parte dos 19,60 s ocorre fora desse intervalo de compute. Esperar ACK inclui trabalho econômico real; não é correto chamar todo esse tempo de overhead de barreira.

EVIDENCE no perfil do coordinator: 1.383.632 decodificações JSON de scratch, cerca de 1.684.812 chamadas de `json.dumps` e 300.000 trades. O fechamento tem muito mais trabalho serial do que o número de ticks sugere. A SPEC permite listas pequenas de trades, mas esta fixture produz uma lista grande; não foi reduzida para facilitar o benchmark.

EVIDENCE no perfil dos workers: `dataclasses.asdict` faz uma cópia recursiva integral de cada `SessionResult`; o envio por Pipe em seguida já produz uma cópia serializada para o coordinator. No worker 0 foram 4,2257 s perfilados em `asdict`; worker 2, 4,2414 s. O engine já havia terminado e não mutava mais esses objetos. A duplicação não acrescentava isolamento após o transporte.

EVIDENCE no perfil do coordinator: `gzjson` envolve consumo dos geradores, serialização JSON, gzip e gravação dos quatro arquivos, sequencialmente. O merge mais a serialização/recompressão canônica dominam esse fechamento. A hipótese inicial de que 151 barreiras seriam a causa dominante não é sustentada pelos tempos medidos.

## Tempos por etapa

Os dados abaixo são diagnósticos observacionais com profiler/timers, **não tempos G4**. Profiler aumenta custo; tempos inclusivos se sobrepõem e não devem ser somados. `parent.prof` perfila o coordinator; a segunda execução perfila os filhos, separadamente.

| Etapa V003R1 | Evidência medida |
|---|---:|
| Spawn/setup, incluindo READY | 0,3510 s no perfil parent |
| Feed/compute, incluindo waits | 4,2110 s no perfil parent |
| Batches | 151 |
| Espera de ACK | 3,7834 s no perfil parent, inclusa em feed |
| Probes e telemetry de memória | 0,3075 s, 158 boundaries da sessão/fechamento |
| Telemetry de transporte | 0,0838 s |
| Espera de RESULT dos workers | 3,0298 s |
| Finish + validação no coordinator | 3,7029 s, incluindo espera de RESULT |
| `SessionEngine.finish` por worker | 0,00032–0,00042 s totais; asdict é posterior |
| Scratch append/JSON/compressão por worker | 1,6017–2,5397 s, inclusos no compute perfilado |
| Hash físico do scratch por worker | 0,0038–0,0060 s; não removido |
| Merge consumido no coordinator | 9,9225 s no perfil parent |
| Commit canônico inclusive merge | 25,9998 s no perfil parent |
| Commit menos intervalo medido de merge | 16,0774 s; residual inclui serializer, compressor, receipts e overhead dos timers |
| Hash/selagem dos arquivos canônicos | 0,0154 s |
| Encerramento dos workers | 0,2101 s |

Na execução com profiler apenas nos filhos: merge observado 4,3541 s e commit inclusive merge 15,6756 s. A diferença confirma por que não se usa profiling como speedup de aprovação. Perfis, contagens, tempos e comandos estão em DIAGNOSTICS.

## Correção legítima aplicada

DECISION registrada antes da medição em `OPTIMIZATION_PREREGISTRATION.json`:

1. Substituir somente a projeção recursiva `asdict` por projeção rasa dos campos de `SessionResult` após FINISH. O Pipe continua serializando/copiando o payload. Nenhum engine recebe novo tick ou muta resultado após FINISH; scratch, digest e verificações permanecem.
2. Reutilizar `JSONEncoder` do scratch e usar `JSONDecoder.raw_decode` para o formato interno conhecido. A leitura exige exatamente um objeto seguido por LF; lixo/trailing content falha. Não há remoção de hashes, CRC ou validações de ordem.
3. Gravar os quatro streams independentes em quatro threads do MESMO processo coordinator. Cada arquivo usa a função `gzjson` do parent intacta, mesma ordem de linhas, serialização e gzip. Todos os futures são aguardados antes do receipt, rename ou checkpoint; erro/Ctrl+C aguarda encerramento dos writers e não promove a sessão. Workers continuam sem caminhos de publicação.

Nenhuma dessas decisões consulta session/scenario, heavy_cycles ou nome da fixture. O caminho normal com Runtime recebe a mesma correção. O oracle permanece intocado. SPEC, core, IO, métricas, preflight e o texto de `gzjson`/`_PrefixHashTracker` são preservados. Geometria, grid, RR, trigger, Rmax, custos e causalidade não foram alterados.

## Comparação sintética sem profiler

Uma comparação sequencial preregistrada, sem tuning entre seus três casos, usou o mesmo input físico e `heavy_cycles=1200`, quatro workers, batch 32 e um slot. Timings incluem setup, feed, finish, merge, commit, close e hashing mensal. Aquecimento idêntico é excluído do case timing, como já fazia V003R1.

| Executor | Case time |
|---|---:|
| Oracle R1R10 congelado | 16,6175579 s |
| V003R1 sem alteração | 22,1678577 s |
| V003R2 corrigida | 18,8675672 s |

EVIDENCE: ganho V003R2/V003R1 = **1,1749187×**, redução de elapsed **14,888%**. Os dez arquivos canônicos das duas sessões (aquecimento + heavy) e o checkpoint foram idênticos entre os três executores. Speedup contra oracle = **0,88074725×**, abaixo de **1,5×**. O tempo necessário nessa medição seria ≤11,0784 s; faltam aproximadamente 7,79 s de redução. Não há PASS G4, nem inferência estatística a partir de uma única tripla.

O tempo da V003R1 difere do histórico owner; por isso o ganho é calculado usando o baseline contemporâneo, não escolhendo timings históricos favoráveis. Mudanças posteriores à medição apenas extraíram o literal 4 para constante, registraram metadados/testes/manifests; não alteraram o algoritmo medido.

## Avaliação adversarial das prioridades

- **Batch 32 / 151 barreiras:** confirmado. Não alterado nesta revisão. A medição de memória/telemetry é cerca de 0,31 s perfilados; reduzir boundaries não elimina o custo serial de fechamento. Todas as fronteiras C5 permanecem. Não foi selecionado um novo número com base em PASS.
- **Valor operacional maior:** o normal já admitia 256 (1..4096), enquanto o harness usa explicitamente 32. Essa diferença fica explícita no preregistro G1. Capacidade não define sozinha latência segura: 4 MiB precisam comportar header, UTF-8 variável e registros; bytes físicos retidos também têm limite 4 MiB, linha até 1 MiB. A duração de compute por registro depende de sinais/posições e não admite garantia apenas pelo número de rows. Uma futura política deve limitar bytes reais e estimar duração por ACK, com todos os parâmetros preregistrados; **não foi implementada nem medida aqui**.
- **Um slot / ausência de pipeline:** confirmado. Pipeline poderia sobrepor parse/probes com compute, mas não remove o commit serial; após cutoff, a barreira por registro é necessária para não alimentar além de r_global. Não foi introduzida nova complexidade de slots/ACK sem evidência de benefício dominante.
- **Spawn por sessão:** custa cerca de 0,35 s perfilados. Um pool persistente pode ser desenhado com reset explícito do estado, epoch/session token, novo scratch e regrant apenas na fronteira; isso exigiria validar stale state, órfãos, count changes e SAFE_STOP. Não foi implementado: o custo observado não justifica ampliar essa superfície nesta correção.
- **Scratch:** continua 15 grupos, dois streams comprimidos por grupo, hash físico no worker e verificação no coordinator, decompress/merge/recompress. Hash pós-escrita custou milissegundos; foi preservado. A otimização atua nas cópias e codecs Python, sem retirar integridade.
- **C1–C8:** seq/generation/CRC, digest, contadores, r_global, snapshot de prefixo, merge S1a–S5b, single writer, matriz G5, certificado/cobertura G6 e matriz G7 não foram reduzidos.

INFERENCE: há um limite prático significativo de trabalho serial Python/JSON/compressão nessa arquitetura. Os dados não provam impossibilidade matemática de alcançar 1,5× por qualquer otimização futura. Provam que esta correção e as pequenas economias medidas de scheduling não demonstraram atendimento ao G4. Não se propõe alterar o threshold ou o oracle.

## Validação pontual e conclusão

Cinco testes pontuais PASS: pending-cancel; cutoff diferido; preservação de gzjson/PrefixHashTracker; rejeição de frame scratch inválido; falhas durante merge e após publicação/antes de checkpoint, com resume de 2 para 3 workers. O último caso também confirmou somente o PID coordinator nas escritas canônicas. Outputs e checkpoint pós-resume idênticos ao oracle.

Nenhuma homologação owner G1–G11 da V003R2 foi executada. G1 agora preregistra parâmetros relevantes, inclusive threads de commit, codecs, layout/slots, batches fixture/normal, lifecycle, assignment, limites de RAM e janela de timing. O threshold permanece 1,5 e heavy_cycles permanece 1200. G5/G6/G7 conservam seus casos.

**DECISION final: FAIL-CLOSED / BLOCKED_G4.** Há melhoria parcial legítima e auditável, mas não há autorização para promoção, mercado, Pilot A ou Run-A. O próximo passo elegível é revisar este diagnóstico e a arquitetura de fechamento; repetir o mesmo G4 sem nova evidência causal não é uma correção. O runner novo foi preparado para uma futura execução explicitamente decidida pelo owner, com EvidenceRoot novo; não foi apontado à árvore falha.
