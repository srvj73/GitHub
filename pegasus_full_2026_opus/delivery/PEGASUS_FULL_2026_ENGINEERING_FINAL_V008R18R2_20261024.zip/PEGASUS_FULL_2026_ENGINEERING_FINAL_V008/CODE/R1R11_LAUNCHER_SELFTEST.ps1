#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Python)
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) {
    throw 'POWERSHELL_5_1_REQUIRED'
}
foreach ($script in Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1' -File) {
    $tokens=$null; $parseErrors=$null
    [void][Management.Automation.Language.Parser]::ParseFile($script.FullName,[ref]$tokens,[ref]$parseErrors)
    if ($parseErrors.Count -ne 0) { throw ('LAUNCHER_PARSE_FAILED ' + $script.Name) }
}
# Existing common launcher behavior: live stdout/stderr, exit codes, transcript.
$ps51=Join-Path $PSHOME 'powershell.exe'
& $ps51 -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'R1R10_LAUNCHER_SELFTEST.ps1') -Python $Python
if ($LASTEXITCODE -ne 0) { throw 'COMMON_LAUNCHER_SELFTEST_FAILED' }
Push-Location -LiteralPath $env:USERPROFILE
try {
    & $ps51 -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'RUN_R1R11_TARGETED.ps1') -Python $Python
    if ($LASTEXITCODE -ne 0) { throw 'PS51_TARGETED_LAUNCHER_FAILED' }
    $missing=Join-Path $PSScriptRoot 'INTENTIONALLY_ABSENT_PYTHON.exe'
    if (Test-Path -LiteralPath $missing) { throw 'SELFTEST_NEGATIVE_PATH_EXISTS' }
    $ErrorActionPreference='Continue'
    try {
        $negativeOutput = & $ps51 -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'RUN_R1R11_OWNER_GATES.ps1') -Python $missing -EvidenceRoot (Join-Path $env:TEMP 'MINOTAURO_NEGATIVE_NOT_CREATED') 2>&1
        $negativeCode=$LASTEXITCODE
    } finally { $ErrorActionPreference='Stop' }
    if ($negativeCode -eq 0 -or ($negativeOutput -join ' ') -notmatch 'PYTHON_EXECUTABLE_NOT_FOUND') {
        throw 'OWNER_LAUNCHER_FAIL_CLOSED_SELFTEST_FAILED'
    }
} finally { Pop-Location }
Write-Output ('POWERSHELL51_LAUNCHER_SELFTEST=PASS VERSION=' + $PSVersionTable.PSVersion)
