#requires -Version 5.1
[CmdletBinding()] param([Parameter(Mandatory=$true)][string]$EvidenceRoot)
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'POWERSHELL_5_1_REQUIRED' }
. (Join-Path $PSScriptRoot 'Minotauro_Launcher_Common.ps1'); $Python=Resolve-RealPython
$Out=[IO.Path]::GetFullPath($EvidenceRoot)
Write-Host 'AMBIENTE=PowerShell R1R11_V005R1_DEV_BENCH NON_GATE=YES REQUIRED=3_OF_3 SPEEDUP_GE_1.667 HEAVY_BYTE_EQUAL=YES'
& $Python -X utf8 -B (Join-Path $PSScriptRoot 'r1r11_dev_benchmark.py') --out $Out
exit $LASTEXITCODE
