# AUDITORIA PÓS-PILOTO FINAL OPUS 5.5 — MINOTAURO V005R1 R1R9

**Handoff:** `HANDOFF_OPUS55_MINOTAURO_R1R9_POSTPILOT_FINAL_20260926.zip`, SHA256 `2795B91F…26AB5DB`. O manifesto `05_SHA256SUMS.txt` confere 47 de 47 entradas, sem arquivo fora do manifesto.

**Regime:** independente, adversarial e fail-closed.
- Nenhum código de projeto escrito, runner criado ou artefato alterado.
- Nenhum dado de tick lido e nenhum `run-a` executado.
- Houve apenas verificação de hashes e leitura dos outputs do piloto já produzidos.
- **O pico de memória do piloto não foi medido e não é estimado neste parecer.**

```text
OPUS55_R1R9_POSTPILOT_FINAL_AUDIT=PASS
HANDOFF_MANIFEST_INTEGRITY=PASS
IMPLEMENTATION_ZIP_INTEGRITY=PASS
OWNER_PILOT_AUTHORIZATION=PASS
PILOT_A_EXECUTION=PASS
PILOT_A_SESSIONS=PASS_3_OF_3
PILOT_OUTPUT_INTEGRITY=PASS
GATE28_RECONCILIATION=PASS
GATE28_MISMATCH_COUNT=0
PRE_RUN_A_GATES=PASS_28_OF_28
FALSE_PASS_PATHS_REMAINING=0
PILOT_TOTAL_RUNTIME=00:45:33
PILOT_PEAK_MEMORY=NOT_MEASURED
M_C_LIVE_PROGRESS_DISPOSITION=REQUIRES_MITIGATION
M_D_MEMORY_DISPOSITION=BLOCKING_FOR_RUN_A
CRITICAL_FINDINGS=0
MAJOR_FINDINGS=1
MINOR_FINDINGS=2
RUN_A_AUTHORIZED=NO
OWNER_RUN_A_AUTHORIZATION_FILE_CREATION_AUTHORIZED=NO
CODE_REVISION_REQUIRED_BEFORE_RUN_A=YES
REQUIRED_CORRECTIONS=R1R10 operacional sem mudança econômica: (1) eliminar a acumulação de todos os trades em memória durante o run-a e no resume, preservando metrics.py e saídas byte-idênticas; (2) telemetria de memória por sessão e teto fail-closed com parada segura em fronteira de sessão; (3) progresso ao vivo no console e no transcript via Write-Host linha a linha (m-c); (4) corrigir o rótulo R1R8 do RUN_PHASE.ps1 (m-e)
NEXT_ACTION=Encomendar ao builder a R1R10 com os quatro itens e a prova de equivalência do §7, e submetê-la à auditoria de diff antes de refazer a cadeia 27+28 em out_root novo
```

---

## 1. Integridade e identidade

- [x] **Manifesto do handoff:** 47 de 47 entradas OK.
- [x] **ZIP de implementação:** `00D04BE1…685C2C4B`, com `SHA256SUMS` interno 44 de 44 OK. A árvore extraída é idêntica, arquivo por arquivo, à R1R9 auditada.
- [x] **Histórico:** o `SOURCE/24_…` é idêntico à minha entrega `24_…`.
- [x] **Evidência pré-piloto:** os 11 arquivos de `GATES/` e os 5 logs anteriores ao piloto são **byte-idênticos** aos do handoff pré-piloto que auditei. Nada foi reescrito depois do selo.
- [x] **Binding usado como referência:** o `RUN_SOURCE_BINDING_A.json` selado (`BBACF23A…`) não está neste handoff. Usei a cópia do handoff anterior, cujo hash foi verificado.

---

## 2. Autorização e execução do Pilot A

**`OWNER_PILOT_AUTHORIZATION.json`** (SHA `ADFC6CF6…`)
- UTF-8 sem BOM, com os cinco campos exatos.
- `spec`, `runner`, binding `BBACF23A…` e receipt pré-piloto `341A5F62…` conferem com o estado selado.

**Transcript `RUN_GATE28_PILOT` (06:22:51 → 07:08:24 = 00:45:33)**
- **Execução:** Windows PowerShell 5.1 e Python 3.14 (`pythoncore-3.14-64`).
- **Sessões:** `RUN_START sessions=3`; commits de 2025-01-02 (1.650 trades), 2025-01-03 (12.924) e 2025-01-06 (14.842), todos com `cells=435`.
- **Arquivo de ticks:** leitura até o fim — 5,220 GiB e 87.319.657 linhas — e `RUN_MONTH_HASH_VERIFIED` = `805B97F2…`, igual ao hash de janeiro vinculado no binding.
- **Fechamento:** `PILOT_A_RUN=PASS` → receipt GATE28 PASS → receipt PRE_RUN_A → `PRE_RUN_A_GATES=PASS_28_OF_28`.
- **Nenhum sinal adverso:** sem `FAIL`, `BLOCKED`, `SAFE_STOP`, `RUN_BLOCKED`, `ORPHAN` ou `Traceback`, e sem execução de `run-a`.

**Tempos por etapa**, derivados do relógio do próprio runner a partir dos campos `RATE_MIB_S` do transcript:

| Marco | Tempo decorrido (runner) |
|---|---|
| 0,25 GiB | ~136 s |
| 0,50 GiB | ~512 s |
| 0,75 GiB, já com as 3 sessões commitadas | ~925 s |
| 5,22 GiB (fim do `pilot-a`) | ~1.414 s ≈ **00:23:34** |

- **Trecho econômico:** até ~0,75 GiB, com vazão de ≈ 0,65 MiB/s.
- **Trecho só de hash até o EOF:** ≈ 9,4 MiB/s.
- **`pilot-reconcile` + `finalize`:** ≈ **00:22** restantes.

**Coerência dos artefatos do `PILOT_A`**
- **`PILOT_RUN_RECEIPT`** (`0F3B33C7…`)
  - `PASS`, 3 sessões, 435 células, captura integral `YES`.
  - Seu `run_manifest_sha256` confere com o `RUN_MANIFEST` físico.
- **`RUN_MANIFEST`** (`9CA3968C…`)
  - `runner_version` R1R9; `spec`, `runner`, `grid` e binding corretos.
  - `gate_receipt_sha256` = receipt pré-piloto.
  - Geometria e hashes de runtime iguais aos do binding.
- **`CHECKPOINT`**
  - Todas as chaves obrigatórias presentes; self-hash e hash das sessões concluídas conferem.
  - Identidades conferem com o binding.
  - `verified_months` = `805B97F2…`.
  - O estado de 435 posições é igual ao do último `session_receipt`.

**Sessões — contagens obtidas por leitura em streaming dos outputs**

| Sessão | Trades (receipt = linhas) | Baseline | Recon. 435 / integral | `OPEN_MARK` persistidos = avaliados | Prefixo (bytes) |
|---|---|---|---|---|---|
| 2025-01-02 | 1.650 = 1.650 | 0 | ✅ / ✅ | 922.218 | 268.772.801 |
| 2025-01-03 | 12.924 = 12.924 | 9 | ✅ / ✅ | 19.263.560 | 514.635.165 |
| 2025-01-06 | 14.842 = 14.842 | 9 | ✅ / ✅ | 23.562.152 | 797.766.733 |

**Demais conferências das sessões:**
- **Prefixos:** crescentes, no caminho de janeiro, e coerentes com a ordem das linhas `RUN_PROGRESS` e `SESSION_COMMIT` no transcript.
- **Diagnósticos de cutoff:** iguais ao calendário congelado.
- **Estado final:** o `max_dd_to_date` e o `end_equity` das 435 células conferem com o `CHECKPOINT`.
- **Telemetria B1:** `precutoff_crossed_state_count` de 734, 836 e 1.397, sem aborto.

---

## 3. Gate 28 e 28/28

**Receipt GATE28** (`1374856E…`)
- `PASS`, `mismatch_count 0`, 435 células, as 3 sessões corretas, independência declarada como parcial.
- As 7 identidades e hashes conferem com os arquivos físicos: spec, runner, suite, binding, pré-piloto, `PILOT_RUN_RECEIPT` e `RUN_MANIFEST`.
- O diff CSV tem **apenas o cabeçalho**.

**`PRE_RUN_A_GATE_RECEIPT`** (`72EF8DF1…`)
- `PASS`, `gates_passed 28`, `RUN_A_AUTHORIZED=NO_PENDING…`.
- Todos os hashes referenciados conferem com os arquivos físicos: pré-piloto, GATE28, `PILOT_RUN`, `RUN_MANIFEST`, grid e binding.
- Os manifests de runner e gates reproduzem as identidades e são idênticos aos do selo.

**Como o `mismatch_count=0` fica sustentado:**
1. O código R1R6+ apaga qualquer receipt GATE28 anterior antes de reconciliar, só grava o PASS depois de comparar tudo e exige identidades correntes no `finalize`.
2. O diff está vazio.
3. Reverifiquei de forma independente a parte "captura integral" do gate: `avaliados = persistidos` nas 3 × 435 linhas.
4. Apliquei checagens de invariantes aos **29.416 trades** do piloto, com **zero violações**:
   - PnL bruto e líquido, custo, SL/TP;
   - entrada entre origem e alvo e do lado executável;
   - idade do BBO ≤ 500 ms;
   - N < N+1 = entrada ≤ saída;
   - N e N+1 de negócio e dentro da sessão;
   - `TARGET` = TP; `STOP` além da origem; `IMMEDIATE_STOP` no mesmo registro;
   - fills de `CUTOFF` iguais ao calendário;
   - trigger, RR e Rmax nas fronteiras;
   - parâmetros coerentes com o `CELL_ID`;
   - nenhuma sobreposição de trades por célula.

**Limite:** não recomputei a engine de referência, porque isso exigiria reprocessar os ticks. Pela §6.3, o recomputo independente cobriu os 18 trades da baseline e o **primeiro** trade de cada célula por sessão. Os demais trades têm cobertura apenas por invariantes.

**Falso-pass:** nenhum caminho. O `PRE_PILOT_GATE_STATUS.json` (`BLOCKED`) é histórico e foi desconsiderado como autoridade.

---

## 4. Reavaliação do m-c (progresso ao vivo) para o `run-a`

**No piloto:**
- Houve dois blocos mudos — `pilot-a` com ~24 min e reconciliação + finalize com ~22 min.
- Toda a saída só apareceu ao término de cada processo. A janela fechou no fim e o owner não viu o console final; o transcript é a autoridade.

**No `run-a`:**
- Será um **único processo Python** cobrindo 55,31 GiB com processamento econômico de 250 sessões.
- **Projeção de duração** (derivada da vazão observada, não medida):
  - limite inferior ≈ 1,7 h, na vazão de leitura pura de ~9,4 MiB/s;
  - na vazão econômica do piloto (~0,65 MiB/s, com captura integral), da ordem de **um dia**.
- Durante todo esse tempo o console ficaria mudo.
- Existem sinais externos, mas eles não substituem progresso e erros visíveis em tempo real:
  - pastas em `PHASE_A\sessions`;
  - data de escrita do `CHECKPOINT.json`;
  - Gerenciador de Tarefas.

**Disposição: `REQUIRES_MITIGATION`.**
- **Correção:** streaming linha a linha via `Write-Host`, o canal cuja captura no transcript foi comprovada pelos smokes. Como a R1R10 é obrigatória por causa do m-d, a correção entra nela.
- **Operação:** executar a partir de um console já aberto, para que o estado final permaneça visível.

---

## 5. Reavaliação do m-d (memória) para o `run-a`

**Fatos**, sem nenhuma conversão para bytes:
- **Piloto — acúmulo por sessão até o commit:**
  - até **23.591.836 linhas de equity** e 37.873 de eventos em listas Python;
  - pico **não medido**;
  - a conclusão do piloto não prova margem nem segurança.
- **Run-a — termo que cresce com a execução inteira:** o runner acumula **todos os trades de todas as sessões** em uma lista em memória:
  - acúmulo: `trades.extend(res.trades)`, runner l.390;
  - no resume, `_load_existing_trades` recarrega todos os trades já commitados (l.406-413, l.567);
  - `aggregate_phase` e `finalize_phase_a` recebem a lista inteira (l.697-698).
- **Contagens observadas:** 1.650 a 14.842 trades por sessão, cada um um dict com ~40 campos, dois dicts aninhados e uma lista. O `run-a` tem 250 sessões e o piloto teve 3.
- **Limite do piloto:** o piloto **não exercitou** esse termo cumulativo.

**Consequências fail-closed:**
1. **Falha tardia e não recuperável por resume:** se o limite de memória for atingido, isso ocorre tarde — no fim do ano ou no `finalize`, depois de horas mudas (m-c). O resume recarrega os mesmos trades e reproduz a falha.
2. **Não há telemetria nem teto de memória** no código, então nenhum procedimento operacional garante a conclusão.
3. **A ausência de medição não pode ser compensada por procedimento** para esse termo estrutural.

**Disposição: `BLOCKING_FOR_RUN_A`, com revisão de código.** A revisão é operacional e não altera a economia. A `metrics.aggregate_phase` usa apenas `cell_id`, `session` e `net_pnl_units`, e o `TRADES_2025_ALL_CELLS.csv` pode ser gerado em streaming a partir dos `trades.jsonl.gz` por sessão. Assim é possível eliminar o acúmulo e manter `metrics.py` e as saídas byte-idênticas.

---

## 6. Findings

| # | Sev. | Finding | Disposição |
|---|---|---|---|
| M-1 (= m-d) | **MAJOR** | Acúmulo em memória de todos os trades do ano (e recarga integral no resume), sem telemetria nem teto; pico do piloto não medido; termo cumulativo não exercitado pelo piloto. | Bloqueia o `run-a`; correção (1) e (2) na R1R10. |
| m-c | MINOR | Saída só aparece depois que o Python termina; no `run-a` isso significa horas de console mudo. | Requer mitigação; correção (3) na R1R10. |
| m-e | MINOR | O log do piloto ainda mostra `MINOTAURO_V005R1_R1R8 COMMAND=pilot-a`. | Correção (4). |

**Observações (não contadas):**
- **O-6:** em 2025-01-02 o `first_cutoff_ask_msc` de runtime é 0. Não houve posição aberta no cutoff, a sessão foi commitada no primeiro registro pós-cutoff, antes da atualização do ask. É apenas diagnóstico: o valor canônico é o do calendário, e a validação de fills de `CUTOFF` no commit segue intacta. Nesse dia houve zero trades de `CUTOFF`.
- **O-7:** no ambiente desta auditoria, carregar como objetos Python as linhas de equity de uma única sessão do piloto esgotou a memória do contêiner, e a verificação foi refeita em streaming. Registro o fato só por transparência: **não mede nem limita** o pico do PC do owner e não foi usado na decisão.
- **O-5:** Ctrl+C sob saída redirecionada não foi exercitado (sem interrupção).

---

## 7. Decisão sobre o `RUN_A` e evidência corretiva exigida

**`RUN_A_AUTHORIZED=NO`.** Não criar `OWNER_RUN_A_AUTHORIZATION.json`.

**R1R10 — escopo exigido, somente operacional e sem mudança econômica:**
1. **Acúmulo de trades:** eliminar o acúmulo da lista `trades` durante a execução e no resume. No `finalize`, calcular as métricas com exatamente os campos usados por `aggregate_phase` e gerar o `TRADES_2025_ALL_CELLS.csv` em streaming a partir dos arquivos por sessão. **`metrics.py` fica byte-idêntico.**
2. **Telemetria de memória:** registrar, por sessão, o working set atual e o de pico (API do Windows, sem nova dependência) numa linha de progresso e num arquivo separado (por exemplo, `session_telemetry.json`). O `session_receipt.json` deve permanecer byte-idêntico.
3. **Teto de memória:** configurável e verificado ao menos a cada commit de sessão. Ao ser excedido, faz parada segura com checkpoint consistente e código de saída próprio, nunca PASS.
4. **Progresso ao vivo:** stdout e stderr transmitidos linha a linha via `Write-Host`, mantendo o código de saída como única autoridade.
5. **Rótulo:** corrigir o R1R8 no `RUN_PHASE.ps1`.

**Evidência corretiva exigida antes de autorizar o `run-a`:**
- **(a) Auditoria de diff R1R9 → R1R10.** Deve provar que `core`, `io`, `preflight`, `metrics` e as regras de gates não mudaram, e que há testes sintéticos para o teto de memória e para a igualdade entre as métricas e o CSV gerados em streaming e os do código atual.
- **(b) Refazer a cadeia completa, sem pular etapas, em `out_root` **novo**.** Todas as identidades mudam.
  - Rebind, gates 1–27, validação de geometria e selo. A saída física do MT5 pode ser reaproveitada se o `GEOMETRY_INPUT` mantiver o hash `E28EE2F1…`.
  - Nova `OWNER_PILOT_AUTHORIZATION` com as novas identidades.
  - Piloto com telemetria.
- **(c) Equivalência do piloto R1R10:** os **15 arquivos de sessão** do piloto R1R10 — `trades`, `equity`, `events` e `equity_reconciliation` (`.jsonl.gz`) e `session_receipt.json`, nas 3 sessões — devem ser **byte-idênticos** aos do piloto R1R9. A referência são os hashes deste handoff em `05_SHA256SUMS.txt`, por exemplo `trades 2025-01-06 = 8CBF2086…` e `equity 2025-01-06 = 6AA7140D…`. Também exigidos: GATE28 `mismatch_count 0` e `PASS_28_OF_28`.
- **(d) Nova auditoria pós-piloto,** com a memória medida pela telemetria e o comportamento de progresso ao vivo comprovado no transcript. Só então caberá decidir o `run-a` e o teto de memória a usar.

---

## 8. Limites

- **Tempos por etapa:** derivados dos campos `RATE_MIB_S` do transcript. A duração do `run-a` é uma **projeção**, não uma medição.
- **Memória:** nenhuma inferência de RAM foi feita. A decisão sobre o m-d se baseia na **estrutura do código** e na **ausência de medição**.
- **Fontes externas:** os arquivos de tick, M1 e `IND@N.csv` foram aceitos pelos hashes vinculados. O hash EOF de janeiro foi confirmado pelo próprio piloto.
- **Engine de referência:** não foi reexecutada, porque isso exigiria processar dados de mercado.
