# V004R1 → V004R2 — causal performance correction

## Parent result preserved

Owner V004R1 G4 failed once and is not rerun:

```text
speedup=0.3383456527336962
required=1.5
oracle_seconds=15.326517900000908
candidate_seconds=45.29840349999722
granted=[4]
overlap=true
external_heavy_workers=0
```

G5–G11 did not run. No real data, Pilot A or Run-A.

## Causal correction

V004R1 inserted durability/validation work into the transient close path that the V004 SPEC does not require to be durable or duplicated. V004R2 preserves the SPEC and economics while removing redundant physical work:

1. worker scratch/sidecar handles are closed but not fsynced; scratch is transient and reprocessed after crash;
2. coordinator pre-helper seal validation checks physical SHA/identity/rows/bytes in one pass and four threads by stream; full semantic sidecar validation remains in helper consumption;
3. stage postvalidation recalculates consumed SHA plus rows/order proof in one physical pass, with four coordinator threads;
4. post-helper scratch raw revalidation uses four coordinator threads;
5. `SESSION_SEAL` reuses hashes from the immediately preceding validated pending tree;
6. precomputed merge keys are carried into `OrderProof`;
7. transient stage directory is not durability-flushed; stage files remain fsynced before `.sealed`.

## Unchanged

SPEC V004, core, IO, metrics, preflight, economic SPEC, oracle, heavy_cycles=1200, G4 workers=4, batch_rows=32, one slot, threshold=1.5, sidecar schema, four stage helpers, canonical `gzjson`, byte identity requirement, transaction ordering, memory cap and single canonical publisher remain unchanged.

## Governance

No V004R2 G4 has been executed. No tuning based on a V004R2 performance result exists. Any owner G4 <1.5 is a hard STOP.
