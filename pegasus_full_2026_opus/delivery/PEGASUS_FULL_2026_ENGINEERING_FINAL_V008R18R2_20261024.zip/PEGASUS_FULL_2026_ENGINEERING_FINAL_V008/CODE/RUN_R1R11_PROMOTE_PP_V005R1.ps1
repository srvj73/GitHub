#requires -Version 5.1
[CmdletBinding()] param([Parameter(Mandatory=$true)][string]$Config,[Parameter(Mandatory=$true)][string]$ChainTranscript)
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'POWERSHELL_5_1_REQUIRED' }
. (Join-Path $PSScriptRoot 'Minotauro_Launcher_Common.ps1'); $Python=Resolve-RealPython
Write-Host 'AMBIENTE=PowerShell R1R11_V005R1_POSTPILOT PP1_PP9=REQUIRED'
& $Python -X utf8 -B (Join-Path $PSScriptRoot 'r1r11_postpilot_promotion.py') --config ([IO.Path]::GetFullPath($Config)) --transcript ([IO.Path]::GetFullPath($ChainTranscript))
exit $LASTEXITCODE
