#requires -Version 5.1
[CmdletBinding()] param(
 [Parameter(Mandatory=$true)][ValidateSet('rebind-a','pilot-a','run-a')][string]$Command,
 [Parameter(Mandatory=$true)][string]$Config,
 [ValidateRange(2,12)][int]$Workers=12
)
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'POWERSHELL_5_1_REQUIRED' }
. (Join-Path $PSScriptRoot 'Minotauro_Launcher_Common.ps1'); $Python=Resolve-RealPython
$ConfigPath=[IO.Path]::GetFullPath($Config)
$Owned=Start-MinotauroTranscript -Config $ConfigPath -LauncherName $MyInvocation.MyCommand.Name
$TranscriptPath=$env:MINOTAURO_TRANSCRIPT_PATH
$NeedFullHomologation=$false
try {
 Write-Host ('AMBIENTE=PowerShell R1R11_V005R1_ACTIVATION COMMAND=' + $Command + ' BATCH_ROWS=32')
 $code=Invoke-MinotauroPython -Python $Python -Arguments @('-X','utf8','-B',(Join-Path $PSScriptRoot 'r1r11_activation_controller.py'),$Command,'--config',$ConfigPath,'--workers',[string]$Workers,'--batch-rows','32')
 if ($code -ne 0) { exit $code }
 if ($Command -eq 'run-a') { $NeedFullHomologation=$true }
 Write-Host ('CHAIN_TRANSCRIPT=' + $TranscriptPath)
} finally {
 Stop-MinotauroTranscriptSafe -Owned $Owned
}
if ($NeedFullHomologation) {
 if ([string]::IsNullOrWhiteSpace($TranscriptPath) -or -not (Test-Path -LiteralPath $TranscriptPath -PathType Leaf)) { throw 'FULL_RUN_TRANSCRIPT_PATH_MISSING' }
 & $Python -X utf8 -B (Join-Path $PSScriptRoot 'r1r11_full_homologation.py') --config $ConfigPath --transcript $TranscriptPath
 if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
 Write-Host 'R1R11_FULL_RUN_AND_HOMOLOGATION=PASS'
}
