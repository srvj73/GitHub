#requires -Version 5.1
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][ValidateSet('collect','forensic','microbench','equality','evaluate','all')][string]$Phase,
  [Parameter(Mandatory=$true)][string]$EvidenceOut,
  [string]$SourceOwnerRoot,
  [string]$ControlRoot,
  [string]$V004R1OwnerRoot,
  [double]$TransactionSeconds = -1
)
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'POWERSHELL_5_1_REQUIRED' }
. (Join-Path $PSScriptRoot 'Minotauro_Launcher_Common.ps1')
$Python=Resolve-RealPython
$A0=Join-Path $PSScriptRoot 'r1r11_a0.py'
$Prereg=Join-Path $PSScriptRoot 'A0_PREREGISTRATION_V005R1.json'
$Out=[IO.Path]::GetFullPath($EvidenceOut)
Write-Host ('AMBIENTE=PowerShell PSVersion=' + $PSVersionTable.PSVersion)
Write-Host 'R1R11_V005R1_A0 NON_GATE=YES G4_RERUN=NO CANDIDATE_EXECUTION_IN_COLLECT=NO'

function Invoke-A0([string[]]$CommandArgs) {
  & $Python @CommandArgs
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
function Collect-Args {
  if ([string]::IsNullOrWhiteSpace($SourceOwnerRoot)) { throw 'SOURCE_OWNER_ROOT_REQUIRED' }
  $A=@('-X','utf8','-B',$A0,'collect','--source-root',[IO.Path]::GetFullPath($SourceOwnerRoot),'--out',$Out)
  if (-not [string]::IsNullOrWhiteSpace($ControlRoot)) { $A += @('--control-root',[IO.Path]::GetFullPath($ControlRoot)) }
  if (-not [string]::IsNullOrWhiteSpace($V004R1OwnerRoot)) { $A += @('--v004r1-root',[IO.Path]::GetFullPath($V004R1OwnerRoot)) }
  return $A
}

if ($Phase -eq 'collect') {
  Invoke-A0 -CommandArgs (Collect-Args)
} elseif ($Phase -eq 'forensic') {
  Invoke-A0 -CommandArgs @('-X','utf8','-B',$A0,'forensic','--evidence',$Out,'--prereg',$Prereg,'--out',(Join-Path $Out 'A0_1_FORENSIC'))
} elseif ($Phase -eq 'microbench') {
  Invoke-A0 -CommandArgs @('-X','utf8','-B',$A0,'microbench','--evidence',$Out,'--out',(Join-Path $Out 'A0_2'))
} elseif ($Phase -eq 'equality') {
  Invoke-A0 -CommandArgs @('-X','utf8','-B',$A0,'equality','--evidence',$Out,'--out',(Join-Path $Out 'A0_3'))
} elseif ($Phase -eq 'evaluate') {
  $Args=@('-X','utf8','-B',$A0,'evaluate','--prereg',$Prereg,
          '--forensic',(Join-Path $Out 'A0_1_FORENSIC\A0_1_FORENSIC_REPORT.json'),
          '--microbench',(Join-Path $Out 'A0_2\A0_2_MICROBENCH.json'),
          '--equality',(Join-Path $Out 'A0_3\A0_3_ECONOMIC_EQUALITY.json'),
          '--out',(Join-Path $Out 'A0_GO_NO_GO.json'))
  if ($TransactionSeconds -ge 0) {
    $Args += @('--transaction-seconds',([string]::Format([Globalization.CultureInfo]::InvariantCulture,'{0:R}',$TransactionSeconds)))
  }
  Invoke-A0 -CommandArgs $Args
} else {
  Invoke-A0 -CommandArgs (Collect-Args)
  Invoke-A0 -CommandArgs @('-X','utf8','-B',$A0,'forensic','--evidence',$Out,'--prereg',$Prereg,'--out',(Join-Path $Out 'A0_1_FORENSIC'))
  Invoke-A0 -CommandArgs @('-X','utf8','-B',$A0,'microbench','--evidence',$Out,'--out',(Join-Path $Out 'A0_2'))
  Invoke-A0 -CommandArgs @('-X','utf8','-B',$A0,'equality','--evidence',$Out,'--out',(Join-Path $Out 'A0_3'))
  $Args=@('-X','utf8','-B',$A0,'evaluate','--prereg',$Prereg,
          '--forensic',(Join-Path $Out 'A0_1_FORENSIC\A0_1_FORENSIC_REPORT.json'),
          '--microbench',(Join-Path $Out 'A0_2\A0_2_MICROBENCH.json'),
          '--equality',(Join-Path $Out 'A0_3\A0_3_ECONOMIC_EQUALITY.json'),
          '--out',(Join-Path $Out 'A0_GO_NO_GO.json'))
  if ($TransactionSeconds -ge 0) {
    $Args += @('--transaction-seconds',([string]::Format([Globalization.CultureInfo]::InvariantCulture,'{0:R}',$TransactionSeconds)))
  }
  Invoke-A0 -CommandArgs $Args
  Write-Host 'R1R11_V005R1_A0_ALL=PASS_GO'
}
