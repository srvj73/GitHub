"""PEGASUS successor entrypoint. Offline candidate; release authority is external."""
from pathlib import Path
import argparse,hashlib,json,os,platform,subprocess,sys,time
ROOT=Path(__file__).resolve().parent.parent
class Blocked(RuntimeError): pass

def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest().upper()

def verify_tree(root=ROOT):
    root=Path(root).resolve();mf=root/'MANIFEST_SHA256.json';expected=json.loads(mf.read_text(encoding='utf-8'))
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p!=mf}
    if actual!=set(expected):raise Blocked('PACKAGE_MEMBER_SET_DRIFT')
    wanted_dirs={str(parent).replace('\\','/') for name in expected for parent in Path(name).parents if str(parent)!='.'}
    actual_dirs={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_dir()}
    if actual_dirs!=wanted_dirs:raise Blocked('PACKAGE_DIRECTORY_SET_DRIFT')
    for node in root.rglob('*'):
        if node.is_symlink() or (hasattr(node,'is_junction') and node.is_junction()):raise Blocked('PACKAGE_REPARSE_FORBIDDEN')
    for name,h in expected.items():
        p=root/name
        if not p.resolve().is_relative_to(root) or p.is_symlink() or (hasattr(p,'is_junction') and p.is_junction()):raise Blocked('PACKAGE_PATH_LINK')
        if sha(p)!=h:raise Blocked('PACKAGE_HASH_DRIFT '+name)
    return sha(mf)

def release_admission(request,phase):
    """No editable owner flag can promote this producer's qualification-only build."""
    if phase not in ('B','C'):raise Blocked('PHASE_INVALID')
    release=json.loads((ROOT/'RELEASE_STATE.json').read_text())
    if release['release_stage']!='RUN_RELEASED':raise Blocked('G00_RUN_RELEASE_DISABLED; QS2/QS3/QS4/QS5_B06_AND_R01_R06_PENDING')
    # The current artifact intentionally contains no promotion capability. A reviewed
    # release must supply its separately authorized, physically bound admission module.
    raise Blocked('G00_EXTERNAL_RELEASE_ADMISSION_NOT_INSTALLED')

def orchestrate(out,preflight,workers,request):
    """Complete B/C engineering path, unreachable without external release admission."""
    release_admission(request,'B')
    if os.name!='nt' or sys.version_info[:3]!=(3,14,7):raise Blocked('TARGET_WINDOWS_PYTHON_3_14_7_REQUIRED')
    from r1r11_full_2026 import (validate_parent_2025,prepare_preflight,build_binding,run_phase,finalize_phase,write_combined_final)
    parent=validate_parent_2025();cells=parent['cells']
    if parent['status']!='NO_CANDIDATE' or parent['selected'] is not None:raise Blocked('FROZEN_BASELINE_CHANGED')
    if out.exists() and not (out/'PEGASUS_OWNED_RUN.json').exists():raise Blocked('NEW_SUCCESSOR_OWNED_ROOT_REQUIRED')
    # Real source/preflight/volume admission belongs to the reviewed release gate,
    # never to a policy snapshot or this build's offline authority receipt.
    for phase in ('B','C'):
        release_admission(request,phase)
        if phase=='C':
            report=out/'PHASE_B/PHASE_B_FINAL_REPORT.json'
            if not report.is_file() or json.loads(report.read_text()).get('status')!='PASS':raise Blocked('PHASE_C_REQUIRES_PHASE_B_PASS')
        pf,_,_,_=prepare_preflight(out,phase,preflight)
        po,binding,identity,runtime_hashes,cal,d1_path=build_binding(out,phase,pf,cells,parent)
        run_phase(out,phase,cells,binding,identity,runtime_hashes,cal,d1_path,workers,256)
        finalize_phase(out,phase,cells,parent)
    write_combined_final(out,parent,cells)

def watch(argv,evidence,timeout=1800,env=None):
    evidence=Path(evidence).resolve();evidence.mkdir(parents=True,exist_ok=False)
    started=time.monotonic()
    with (evidence/'stdout.log').open('x',encoding='utf-8') as log:
        p=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,env=env,cwd=evidence)
        while p.poll() is None:
            if time.monotonic()-started>timeout:
                (evidence/'TIMEOUT_RECONCILE.json').write_text(json.dumps({'pid':p.pid,'timeout':timeout,'kill_performed':False,'result':'BLOCKED_TREE_RECONCILIATION_REQUIRED'}))
                raise Blocked('WATCHDOG_EXCEEDED_NO_KILL; child PID='+str(p.pid))
            print('PEGASUS_HEARTBEAT child='+str(p.pid)+' elapsed_s='+str(round(time.monotonic()-started)),flush=True)
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:pass
        rc=p.wait()
    (evidence/'PROCESS_RECEIPT.json').write_text(json.dumps({'argv':argv,'exit_code':rc,'seconds':time.monotonic()-started,'platform':platform.platform()},indent=2))
    return rc

def main():
    ap=argparse.ArgumentParser();ap.add_argument('command',choices=['verify','qualify-offline','run-b','run-c','run-full'],nargs='?',default='verify');ap.add_argument('--evidence',type=Path);n=ap.parse_args()
    try:
        identity=verify_tree();print('PACKAGE_VERIFIED='+identity)
        if n.command.startswith('run'):release_admission({},'C' if n.command=='run-c' else 'B')
        if n.command=='qualify-offline':
            if n.evidence is None or not n.evidence.is_absolute() or n.evidence.resolve().is_relative_to(ROOT):raise Blocked('ABSOLUTE_EVIDENCE_OUTSIDE_PACKAGE_REQUIRED')
            if os.name=='nt' and sys.version_info[:3]!=(3,14,7):raise Blocked('PYTHON_3_14_7_REQUIRED')
            env={**os.environ,'PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
            env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
            return watch([sys.executable,'-B',str(ROOT/'tests/qualify.py'),'--out',str(n.evidence/'cases')],n.evidence,env=env)
        print('PACKAGE_INTEGRITY=PASS FULL_QUALIFIED=NO RECOVERY_QUALIFICATION=BLOCKED FULL_RUN_AUTHORIZED=NO');return 0
    except Blocked as e:print('PEGASUS=BLOCKED '+str(e),flush=True);return 2
if __name__=='__main__':sys.exit(main())
