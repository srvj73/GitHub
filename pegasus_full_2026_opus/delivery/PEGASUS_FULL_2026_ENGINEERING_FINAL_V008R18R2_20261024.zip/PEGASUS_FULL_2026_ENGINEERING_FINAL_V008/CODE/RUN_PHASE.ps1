param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('rebind-a','pilot-a','run-a')]
    [string]$Command,
    [string]$Config = "$PSScriptRoot\config.json",
    [ValidateRange(2,12)][int]$Workers = 12,
    [ValidateRange(1,4096)][int]$BatchRows = 256
)
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Minotauro_Launcher_Common.ps1"
$TranscriptOwned = Start-MinotauroTranscript -Config $Config -LauncherName $MyInvocation.MyCommand.Name
try {
    $Python=Resolve-RealPython
    Write-Host "MINOTAURO_V005R1_R1R11_V003R2 COMMAND=$Command"
    Write-Host "PYTHON=$Python"
    $ExitCode = Invoke-MinotauroPython -Python $Python -Arguments @("$PSScriptRoot\minotauro_v004_runner.py",$Command,'--config',$Config,'--workers',[string]$Workers,'--batch-rows',[string]$BatchRows)
    if ($ExitCode -eq 130) { Write-Host 'SAFE_STOP=YES'; exit 130 }
    if ($ExitCode -eq 3) { Write-Host 'MEMORY_CAP_SAFE_STOP=YES'; Write-Host 'PASS=NO'; exit 3 }
    if ($ExitCode -ne 0) { throw "COMMAND_FAIL=$ExitCode" }
}
finally {
    Stop-MinotauroTranscriptSafe -Owned $TranscriptOwned
}
