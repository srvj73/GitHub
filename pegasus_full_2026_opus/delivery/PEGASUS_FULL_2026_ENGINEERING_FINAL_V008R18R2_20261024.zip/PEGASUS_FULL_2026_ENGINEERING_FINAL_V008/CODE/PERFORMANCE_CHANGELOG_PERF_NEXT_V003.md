# MINOTAURO PERF NEXT V003 — recovery/per-session source resume delta

BASE=MINOTAURO_PERF_NEXT_V002R1
SCHEDULER_DELTA=W15_B256_PRESERVED
ECONOMICS_CHANGED=NO
C1_CUTOFF_CHANGED=NO
FROZEN_IO_PARSER_CHANGED=NO

## Delta
- dynamic post-SAFE_STOP import binding; no hard-coded committed count;
- checkpoint source anchor at session boundary;
- seek-based economic resume by session;
- hash-only prefix rehydration for canonical prefix/month SHA continuity;
- bounded rotating JSONL telemetry;
- global progress PCT from COMMITTED, SOURCE_PCT separately labeled;
- PID ownership upgraded to PID+creation_time;
- stream helper registries added for orphan reconciliation;
- first Ctrl+C path is cooperative-only; SAFE_STOP PASS requires owned tree clean;
- current original FULL may continue running during synthetic/static development only.

## Explicit non-claims
- hash-only prefix rehydration can still reread prefix bytes from disk;
- target Windows operational PASS is not claimed by sandbox tests;
- performance speedup is not claimed until target measurement.
