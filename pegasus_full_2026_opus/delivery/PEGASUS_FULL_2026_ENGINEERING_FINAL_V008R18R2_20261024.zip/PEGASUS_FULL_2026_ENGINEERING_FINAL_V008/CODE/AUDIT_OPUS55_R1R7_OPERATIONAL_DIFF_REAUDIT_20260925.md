# REAUDITORIA MECÂNICA OPUS 5.5 — DELTA R1R6 → R1R7 (HARDENING OPERACIONAL)

**Handoff:** `HANDOFF_OPUS55_REAUDITORIA_OPERACIONAL_MINOTAURO_R1R7_20260925`
- `SHA256SUMS` 10/10 OK.
- O `03_…` é byte-idêntico à minha entrega `20_…` (`6B6FE3E3…`).
- O parent R1R6 (`FAA49FC9…`) é idêntico ao que auditei.
- A candidata R1R7 é `E8E513CE…`.

**Regime:** mecânico, restrito ao delta, independente, adversarial e fail-closed.
- Nenhum código foi escrito ou alterado, nenhum teste foi executado e nenhum dado de mercado foi lido.
- A V002R2 e a economia da R1R6 não foram reabertas.

```text
OPUS55_R1R7_OPERATIONAL_DIFF_REAUDIT=PASS
R1R6_PARENT_PRESERVATION=PASS
ECONOMIC_CAUSAL_RULE_CHANGED=NO
PYTHON_3_14_ENFORCEMENT=PASS
TRANSCRIPT_PERSISTENCE=PASS
TRANSCRIPT_OUT_ROOT_INDEPENDENT_OF_CWD=PASS
NESTED_TRANSCRIPT_REUSE=PASS
COMMON_HELPER_IDENTITY_COVERAGE=PASS
RUNNER_SHA256_RECALCULATED=PASS
GATE_SUITE_SHA256_RECALCULATED=PASS
FALSE_PASS_PATHS_REMAINING=0
CRITICAL_FINDINGS=0
MAJOR_FINDINGS=0
MINOR_FINDINGS=3
OWNER_PC_NON_ECONOMIC_GATES_AUTHORIZED=YES
PILOT_A_AUTHORIZED=NO
RUN_A_AUTHORIZED=NO
DATA_PROCESSING_AUTHORIZED=NO
```

---

## 1. Integridade e delta

- [x] **ZIPs íntegros.** R1R7 com `SHA256SUMS` interno 53/53 OK. Receipt e log do builder no handoff são idênticos aos do pacote.
- [x] **Patch fiel.** O `04_DIFF_R1R6_TO_R1R7.patch`, aplicado a uma cópia de rascunho da R1R6, reproduz byte a byte os 12 arquivos textuais do delta:
  - 9 `RUN_*.ps1`;
  - `Minotauro_Launcher_Common.ps1` (novo);
  - `contract.py`;
  - `config.example.json`.
- [x] **Arquivos econômicos, causais e de teste byte-idênticos à R1R6:**
  - Python: `core`, `io`, `preflight`, `metrics`, `runner`, `gates`, `binding`, `outputs`, `reference` e os três arquivos de teste.
  - MQL5 e referências: fixture MQL5, R6 e SPECs.
- [x] **`contract.py`:** mudam apenas `RUNNER_VERSION` → R1R7 e a inclusão do helper nos dois manifests.
- [x] **`config.example.json`:** muda apenas o `out_root`, que passa a `…_R1R7`.
- [x] **Identidades recalculadas:** `runner_sha256` = `7E076001…EA3495C` e `gate_suite_sha256` = `FD5AA743…CF7B7BFC`. Conferem com o receipt e o log.
- [x] **Helper coberto pelas duas identidades.** `Minotauro_Launcher_Common.ps1` está em `RUNTIME_MANIFEST_MEMBERS` e em `GATE_MANIFEST_MEMBERS`, e nenhum `.py`, `.ps1` ou MQ5 fica fora dos manifests.

---

## 2. Verificação dos seis objetivos do prompt

| # | Objetivo | Fonte | Resultado |
|---|---|---|---|
| 1 | Python 3.14 obrigatório em toda resolução | helper l.5-46 | ✅ Cada candidato — os dois `python.exe` fixos, `py.exe` do Launcher, `py.exe` do PATH e `python.exe` do PATH fora de `WindowsApps` — só é aceito após `sys.version_info[:2]==(3,14)` com saída 0. Para `py.exe`, a verificação e todas as invocações usam `-3.14`: o padrão `*\py.exe` cobre qualquer local, inclusive `C:\Windows\py.exe`. Falha de execução cai no `catch` e resulta em falso; sem candidato válido ⇒ `PYTHON_3_14_REAL_NOT_FOUND`. Nenhum launcher mantém resolução própria. |
| 2 | Transcript em `<out_root>\LOGS`, independente do CWD | helper l.48-70 | ✅ O `out_root` vem do JSON (absoluto no exemplo); o nome do arquivo é `<stamp ms>_<launcher>_PID<pid>.log`; o config default é `$PSScriptRoot\config.json`. Falha em config, `out_root`, `New-Item` ou `Start-Transcript` interrompe o launcher antes do Python (EAP `Stop` herdado). Ver m-2. |
| 3 | Aninhados reutilizam e não encerram o transcript do pai | helper l.53, l.72-78; todos os `RUN_*` | ✅ O filho recebe `Owned=$false`, e seu `finally` não executa `Stop-Transcript`. Cadeias verificadas: `PRE_RUN_A` → `SYNTHETIC`/`OPERATIONAL`; `LIGHT_REBIND` → `PHASE`; `GATE28` → `PHASE`. O `exit 130` do `RUN_PHASE` aninhado volta ao pai com `$LASTEXITCODE=130` e é convertido em `throw`. |
| 4 | Helper em `runner_sha256` e `gate_suite_sha256` | contract l.36, l.53 | ✅ |
| 5 | Sem alteração econômica, causal ou de testes | §1 | ✅ |
| 6 | `config.example.json` só com `out_root` | patch l.498-505 | ✅ |

**Fail-closed preservado:**
- Toda chamada Python continua seguida de conferência de `$LASTEXITCODE`; os filhos aninhados propagam `throw`.
- O `StrictMode 2.0` não quebra nenhuma referência: `$LASTEXITCODE` só é lido depois de uma chamada nativa, e o hashtable dos candidatos é acessado por chaves existentes.
- As funções retornam só `$true`/`$false`, porque as saídas de `New-Item` e `Start-Transcript` vão para `Out-Null`.
- A pasta `LOGS` dentro de `out_root` não interfere com o guard de rebind, o selo ou os manifests do `PHASE_A`.

**Falso-pass:** nenhum caminho novo. O delta não toca gates, recibos ou runner; o único efeito sobre a execução é restringir o interpretador a 3.14.

---

## 3. Findings

**CRITICAL:** nenhum. **MAJOR:** nenhum.

**MINOR (3; nenhum abre falso-pass):**

| # | Finding | Fonte | Efeito |
|---|---|---|---|
| m-1 | O pacote traz 13 `__pycache__/*.cpython-313.pyc` do builder (3.13.5). Eles constam do `SHA256SUMS`, mas não do patch declarado, do receipt ou do CHANGELOG, e ficam fora das identidades. O Python 3.14 ignora caches `cpython-313`, e o 3.13 agora é recusado; os cabeçalhos conferem com o tamanho dos fontes atuais. | `__pycache__/` | Higiene: remover do pacote na próxima revisão. |
| m-2 | O helper não exige que `out_root` seja absoluto. Um `out_root` relativo tornaria transcript e outputs dependentes do diretório corrente (e do `$PWD` do PowerShell ≠ CWD do processo). O exemplo é absoluto. | helper l.57-59 | Validar `IsPathRooted` e falhar fechado. |
| m-3 | O Python é chamado como comando nativo direto (`& $Python …`), sem passar pelo pipeline do PowerShell. Pela análise estática não é possível garantir que o stdout/stderr do Python entre no transcript; isso depende do host e da versão do PowerShell. O arquivo de log é criado de qualquer forma, e a evidência de registro continua nos recibos JSON. | todos os `RUN_*` | Conferir no primeiro uso (§4). Se faltar, rotear o stdout via `\| Out-Host`, sem `2>&1` sob EAP `Stop` no Windows PowerShell 5.1. |

**Observação (não contada):**
- A detecção de aninhamento confia em `$env:MINOTAURO_TRANSCRIPT_ACTIVE`. Se essa variável ficasse residual numa sessão interativa, um launcher top-level seguiria sem transcript.
- O `finally` com `Stop-MinotauroTranscriptSafe` torna esse estado praticamente inalcançável. Endurecimento possível: exigir também que `$env:MINOTAURO_TRANSCRIPT_PATH` exista.

**Pendências R1R6:**
- m-D fechado nos dois itens substantivos (Python 3.14 e log persistente); o nome `RUN_PRE_RUN_A_GATES.ps1` continua cosmético.
- m-A, m-B, m-C, m-E e m-F seguem como registrados em `20_…` e não foram recontados.

---

## 4. O que o owner pode rodar no PC (somente não econômico)

0. **Preparação:** se o ZIP veio por download, executar `Unblock-File` nos `.ps1` extraídos (inclusive o helper, que é carregado por dot-source).
1. **Configuração:** copiar `config.example.json` para `config.json`. O `out_root` `…_R1R7` deve ser uma pasta nova e absoluta; o `preflight_source_root` aponta para a saída R1R4.
2. **Teste de fumaça do log:** rodar `RUN_SYNTHETIC_GATES.ps1` a partir de `C:\Users\silvi`. Em seguida, abrir `<out_root>\LOGS\*_RUN_SYNTHETIC_GATES_PID*.log` e procurar três linhas:
   - `Ran … tests` e `OK` (stderr do unittest);
   - o JSON `"SYNTHETIC_GATES": "PASS"` (stdout);
   - `SYNTHETIC_GATE=PASS` (PowerShell).

   **Se as linhas do Python faltarem,** m-3 fica confirmado. Decida então se pede uma R1R8 antes de seguir, porque qualquer mudança torna os recibos obsoletos.
3. `RUN_LIGHT_REBIND_A.ps1`
4. `RUN_PRE_RUN_A_GATES.ps1`
5. **MetaEditor/MT5:**
   - copiar `GATES\GEOMETRY_INPUT_R23.csv` para `MQL5\Files\MINOTAURO_GEOMETRY_INPUT_R23.csv`;
   - compilar e executar `Minotauro_Geometry_Parity_R23.mq5`.
6. `RUN_GEOMETRY_VALIDATE.ps1 -Mt5Output <…\MQL5\Files\MINOTAURO_GEOMETRY_MT5_R23.csv>`
7. `RUN_SEAL_PREPILOT_GATES.ps1` — **parar** em `PRE_PILOT_GATES=PASS_27_OF_27` e trazer `GATES\` e `LOGS\` para auditoria.

Os comportamentos fail-closed esperados, que não indicam defeito, são os mesmos do §7 de `20_…`.

**Nunca nesta etapa:**
- `RUN_GATE28_PILOT.ps1`;
- `RUN_PHASE.ps1 -Command pilot-a` ou `-Command run-a`;
- criação de `OWNER_PILOT_AUTHORIZATION.json` ou `OWNER_RUN_A_AUTHORIZATION.json`.

---

## 5. Limites

- **PowerShell:** os launchers não foram executados. Resolução do Python, transcript e códigos de saída foram verificados apenas estaticamente.
- **Testes do builder:** o log 54/54 foi obtido em Python 3.13.5 e não serve como evidência owner-PC.
- **Escopo:** restrito ao delta R1R6 → R1R7.
