from __future__ import annotations
import ast, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent

class PerfNextV002Tests(unittest.TestCase):
    def test_worker_cap_15_and_cpu_ram_group_gate_preserved(self):
        src=(ROOT/'r1r11_resources.py').read_text(encoding='utf-8')
        self.assertIn("2 <= requested <= 15",src)
        self.assertIn("grant = min(requested, 15, cpu_grant",src)
        self.assertIn("RAM_TARGET", (ROOT/'PERFORMANCE_CHANGELOG_PERF_NEXT_V002.md').read_text(encoding='utf-8'))
    def test_default_is_one_worker_per_group_candidate(self):
        src=(ROOT/'r1r11_perf_next_controller.py').read_text(encoding='utf-8')
        self.assertIn("default=15",src)
        self.assertIn("default=256",src)
        self.assertIn("MINOTAURO_R1R11_PERF_NEXT_V003R3_W15_B256_20260929",src)
    def test_assignment_still_deterministic_round_robin(self):
        src=(ROOT/'r1r11_coordinator.py').read_text(encoding='utf-8')
        self.assertIn("self.assignments = [self.groups[i::self.granted] for i in range(self.granted)]",src)
        groups=list(range(15)); granted=15
        assignments=[groups[i::granted] for i in range(granted)]
        self.assertEqual(assignments,[[i] for i in groups])
    def test_no_multi_slot_feed_ahead_introduced(self):
        src=(ROOT/'r1r11_coordinator.py').read_text(encoding='utf-8')
        self.assertIn('SHARED_SLOTS=1',src)
        self.assertIn("acks = self.receive('ACK')",src)
    def test_batch_matrix_preserved_default_256(self):
        src=(ROOT/'r1r11_coordinator.py').read_text(encoding='utf-8')
        self.assertIn('if batch_rows not in (32,64,128,256):',src)
        self.assertIn('batch_rows=256',src)

if __name__=='__main__': unittest.main(verbosity=2)
