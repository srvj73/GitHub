from __future__ import annotations

import copy
import tempfile
import time
import unittest
from pathlib import Path

from ff_cutoff_r3_runtime import event_dict, make_sidecar, validate_sidecar
from minotauro_v004_core import D1Bar, ModelError, SessionEngine, TickRecord, valid_cells, PRICE_SCALE

SESSION='2026-01-05'
CUTOFF=1767646980000


def rec(ord_, msc, bid=0, ask=0, last=0, volume=0.0):
    return TickRecord(SESSION,ord_,'2026.01.05 18:03:00',msc,bid,ask,last,volume,volume,0)


def engine(sidecar, direction):
    c=valid_cells()[0]
    d1=D1Bar('2026-01-02',10000*PRICE_SCALE,20000*PRICE_SCALE,10000*PRICE_SCALE,15000*PRICE_SCALE)
    e=SessionEngine(SESSION,d1,[c],CUTOFF,True,r3_sidecar=sidecar)
    e.pos_open[0]=True;e.pos_dir[0]=direction;e.pos_entry[0]=164400*PRICE_SCALE;e.pos_sl[0]=160000*PRICE_SCALE;e.pos_tp[0]=170000*PRICE_SCALE
    e.pos_entry_msc[0]=CUTOFF-1000;e.pos_entry_ordinal[0]=1;e.pos_trade_index[0]=0
    e.trades=[{'cell_id':c.cell_id,'session':SESSION,'direction':'BUY' if direction>0 else 'SELL',
               'entry_msc':CUTOFF-1000,'entry_ordinal':1,'entry_price_micro':164400*PRICE_SCALE}]
    return e


class ReleaseTests(unittest.TestCase):
    def test_l0_long_preserves_legacy_path(self):
        sc=make_sidecar(SESSION,CUTOFF,
            event_dict('L0',2,CUTOFF,164380*PRICE_SCALE,164385*PRICE_SCALE),
            event_dict('L0',2,CUTOFF,164390*PRICE_SCALE,164385*PRICE_SCALE))
        e=engine(sc,1)
        self.assertFalse(e.process_record(rec(2,CUTOFF,bid=164380*PRICE_SCALE,ask=164390*PRICE_SCALE,last=164385*PRICE_SCALE,volume=1)))
        self.assertEqual(e.trades[0]['exit_price_micro'],164380*PRICE_SCALE)
        self.assertEqual(e.trades[0]['exit_reason'],'CUTOFF')
        self.assertNotIn('cutoff_level',e.trades[0])

    def test_l1_long_crossed_business(self):
        sc=make_sidecar(SESSION,CUTOFF,
            event_dict('L1',2,CUTOFF+39,164380*PRICE_SCALE,164385*PRICE_SCALE),
            event_dict('L1',2,CUTOFF+39,164390*PRICE_SCALE,164385*PRICE_SCALE))
        e=engine(sc,1)
        self.assertFalse(e.process_record(rec(2,CUTOFF+39,bid=164535*PRICE_SCALE,ask=164390*PRICE_SCALE,last=164385*PRICE_SCALE,volume=1)))
        tr=e.trades[0]
        self.assertEqual(tr['exit_price_micro'],164380*PRICE_SCALE)
        self.assertEqual(tr['cutoff_level'],'L1')
        self.assertTrue(tr['cutoff_modeled_price'])
        self.assertEqual(tr['side_uncertainty_ticks'],1)

    def test_l1_short_crossed_business(self):
        sc=make_sidecar(SESSION,CUTOFF,
            event_dict('L1',2,CUTOFF+39,164380*PRICE_SCALE,164385*PRICE_SCALE),
            event_dict('L1',2,CUTOFF+39,164390*PRICE_SCALE,164385*PRICE_SCALE))
        e=engine(sc,-1)
        self.assertFalse(e.process_record(rec(2,CUTOFF+39,bid=164535*PRICE_SCALE,ask=164390*PRICE_SCALE,last=164385*PRICE_SCALE,volume=1)))
        self.assertEqual(e.trades[0]['exit_price_micro'],164390*PRICE_SCALE)
        self.assertEqual(e.trades[0]['cutoff_level'],'L1')


    def test_preflight_scan_discovers_l1_without_position(self):
        from r1r11_preflight_2026_resumable import _scan_month
        with tempfile.TemporaryDirectory() as td:
            fp=Path(td)/'WIN@N_ticks_2026_01.csv'
            fp.write_text(
                'WIN@N;2026.01.05 18:02:59;1767646979000;164500;164505;164500;1;1;0\n'
                'WIN@N;2026.01.05 18:03:00;1767646980039;164535;164390;164385;1;1;0\n',encoding='utf-8')
            rr=_scan_month('B',fp,[{'session_date':SESSION,'expected_previous_session_date':'2026-01-02'}],0,fp.stat().st_size,0,1,time.monotonic())
            self.assertEqual(rr['status'],'PASS_MONTH')
            row=rr['calendar_rows'][0]
            self.assertEqual(row['r3_long_x_kind'],'L1')
            self.assertEqual(row['r3_short_x_kind'],'L1')
            self.assertEqual(row['r3_long_x_ordinal'],2)
            self.assertEqual(row['r3_long_x_price_micro'],164380*PRICE_SCALE)
            self.assertEqual(row['r3_short_x_price_micro'],164390*PRICE_SCALE)

    def test_preflight_scan_discovers_l0_first(self):
        from r1r11_preflight_2026_resumable import _scan_month
        with tempfile.TemporaryDirectory() as td:
            fp=Path(td)/'WIN@N_ticks_2026_02.csv'
            fp.write_text(
                'WIN@N;2026.02.03 18:02:59;1770152579000;164500;164505;164500;1;1;0\n'
                'WIN@N;2026.02.03 18:03:00;1770152580000;164510;164515;164510;1;1;0\n',encoding='utf-8')
            rr=_scan_month('B',fp,[{'session_date':'2026-02-03','expected_previous_session_date':'2026-02-02'}],0,fp.stat().st_size,0,1,time.monotonic())
            self.assertEqual(rr['status'],'PASS_MONTH')
            row=rr['calendar_rows'][0]
            self.assertEqual(row['r3_long_x_kind'],'L0')
            self.assertEqual(row['r3_short_x_kind'],'L0')

    def test_sidecar_hash_tamper_rejected(self):
        sc=make_sidecar(SESSION,CUTOFF,
            event_dict('L1',2,CUTOFF+39,164380*PRICE_SCALE,164385*PRICE_SCALE),
            event_dict('L1',2,CUTOFF+39,164390*PRICE_SCALE,164385*PRICE_SCALE))
        bad=copy.deepcopy(sc);bad['LONG']['x_price_micro']-=5
        with self.assertRaises(ValueError): validate_sidecar(bad)

    def test_l1_record_identity_mismatch_rejected(self):
        sc=make_sidecar(SESSION,CUTOFF,
            event_dict('L1',2,CUTOFF+39,164380*PRICE_SCALE,164385*PRICE_SCALE),
            event_dict('L1',2,CUTOFF+39,164390*PRICE_SCALE,164385*PRICE_SCALE))
        e=engine(sc,1)
        with self.assertRaises(ModelError):
            e.process_record(rec(2,CUTOFF+39,bid=164535*PRICE_SCALE,ask=164390*PRICE_SCALE,last=164380*PRICE_SCALE,volume=1))

    def test_no_post_latch_entry_path(self):
        sc=make_sidecar(SESSION,CUTOFF,
            event_dict('L1',2,CUTOFF+39,164380*PRICE_SCALE,164385*PRICE_SCALE),
            event_dict('L1',2,CUTOFF+39,164390*PRICE_SCALE,164385*PRICE_SCALE))
        c=valid_cells()[0];d1=D1Bar('2026-01-02',10000*PRICE_SCALE,20000*PRICE_SCALE,10000*PRICE_SCALE,15000*PRICE_SCALE)
        e=SessionEngine(SESSION,d1,[c],CUTOFF,True,r3_sidecar=sc)
        e.process_record(rec(2,CUTOFF+39,bid=164535*PRICE_SCALE,ask=164390*PRICE_SCALE,last=164385*PRICE_SCALE,volume=1))
        self.assertFalse(bool(e.pos_open[0]))
        self.assertEqual(len(e.trades),0)


if __name__=='__main__':
    unittest.main(verbosity=2)
