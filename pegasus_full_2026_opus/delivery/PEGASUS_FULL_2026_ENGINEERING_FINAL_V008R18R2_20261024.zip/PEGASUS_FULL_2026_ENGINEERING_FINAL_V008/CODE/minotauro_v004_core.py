from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from bisect import bisect_left, bisect_right
from collections import defaultdict
from typing import Iterable, Optional
import math

import numpy as np

PRICE_SCALE = 1_000_000
TICK_POINTS = 5
TICK_MICRO = TICK_POINTS * PRICE_SCALE
MONEY_SCALE = 10_000_000  # 1 unit = 1e-7 BRL
ENTRY_COST_UNITS = 2_500_000  # R$0.25
EXIT_COST_UNITS = 2_500_000
BRL_PER_POINT = Fraction(1, 5)  # R$0.20
MAX_QUOTE_AGE_MS = 500
CUTOFF_SECONDS = 18 * 3600 + 3 * 60

PROJECTION_PCT_LIST = (Fraction(382, 10), Fraction(500, 10), Fraction(618, 10))
TRIGGER_T_LIST = (6, 8, 10, 12, 14)
RR_LIST = (3, 4, 5, 6, 7)
RMAX_LIST: tuple[Optional[int], ...] = (None, 12, 14, 16, 18, 20)
MICRO_PCT_LIST = (
    Fraction(56, 10), Fraction(90, 10), Fraction(146, 10), Fraction(236, 10),
    Fraction(382, 10), Fraction(500, 10), Fraction(618, 10), Fraction(764, 10),
    Fraction(854, 10), Fraction(910, 10), Fraction(944, 10),
)

EPS_EQ_MICRO_TIMES_2 = 1  # abs(a-b) <= 0.5 micro-point
RR_EPS_DEN = 1_000_000_000_000


class ModelError(RuntimeError):
    pass


@dataclass(frozen=True)
class Cell:
    p_idx: int
    t_idx: int
    rr_idx: int
    m_idx: int
    projection_pct: Fraction
    trigger_ticks: int
    rr_min: int
    rmax_ticks: Optional[int]
    cell_id: str
    valid: bool


@dataclass(frozen=True)
class Line:
    price_micro: int
    macro: bool
    label: str


@dataclass(frozen=True)
class TickRecord:
    session: str
    ordinal: int
    date_time: str
    time_msc: int
    bid_micro: int
    ask_micro: int
    last_micro: int
    volume: float
    volume_real: float
    flags: int

    @property
    def business(self) -> bool:
        return self.last_micro > 0 and self.volume > 0


@dataclass(frozen=True)
class D1Bar:
    date: str
    open_micro: int
    high_micro: int
    low_micro: int
    close_micro: int


@dataclass
class SessionResult:
    session: str
    cell_ids: list[str]
    trades: list[dict]
    events: list[dict]
    equity_events: list[dict]
    equity_reconciliation: list[dict]
    end_cash_units: list[int]
    hwm_units: list[int]
    max_dd_units: list[int]
    regime_min_units: list[int]
    closed_hwm_units: list[int]
    closed_max_dd_units: list[int]
    trade_counts: list[int]
    cutoff_diagnostics: dict
    precutoff_crossed_state_count: int
    phase_status: str = "PASS"
    phase_block_reason: str = ""



def build_all_cells() -> list[Cell]:
    out: list[Cell] = []
    for pi, p in enumerate(PROJECTION_PCT_LIST):
        for ti, t in enumerate(TRIGGER_T_LIST):
            for ri, rr in enumerate(RR_LIST):
                for mi, rm in enumerate(RMAX_LIST):
                    valid = rm is None or rm >= t
                    cid = f"P{pi:02d}_T{ti:02d}_R{ri:02d}_M{mi:02d}"
                    out.append(Cell(pi, ti, ri, mi, p, t, rr, rm, cid, valid))
    return out


def valid_cells() -> list[Cell]:
    return [c for c in build_all_cells() if c.valid]


BASELINE_CELL_ID = "P02_T02_R02_M00"


def floor_fraction(x: Fraction) -> int:
    return x.numerator // x.denominator


def round_tick_fraction(raw_micro: Fraction) -> int:
    # R6: MathFloor(x/tick_size + 0.5 + 1e-12) * tick_size
    q = raw_micro / TICK_MICRO + Fraction(1, 2) + Fraction(1, 10**12)
    return floor_fraction(q) * TICK_MICRO


def eq_price(a_micro: int, b_micro: int) -> bool:
    return 2 * abs(a_micro - b_micro) <= EPS_EQ_MICRO_TIMES_2


def build_grid(high_micro: int, low_micro: int, projection_pct: Fraction) -> list[Line]:
    if high_micro <= low_micro or low_micro <= 0:
        raise ModelError("D1_RANGE_INVALID")
    rg = high_micro - low_micro
    proj_fraction = projection_pct / 100
    anchor = Fraction(low_micro, 1) + proj_fraction * rg

    candidates: list[Line] = []
    macro_raw: list[Fraction] = []
    for k in range(-4, 5):
        raw = anchor + k * rg
        macro_raw.append(raw)
        candidates.append(Line(round_tick_fraction(raw), True, f"MACRO k={k}"))

    for b in range(8):
        for pct in MICRO_PCT_LIST:
            raw = macro_raw[b] + (pct / 100) * rg
            candidates.append(Line(round_tick_fraction(raw), False, f"MICRO b={b} {float(pct):.1f}%"))

    candidates.sort(key=lambda x: x.price_micro)
    dedup: list[Line] = []
    for line in candidates:
        if not dedup or not eq_price(dedup[-1].price_micro, line.price_micro):
            dedup.append(line)
        elif line.macro and not dedup[-1].macro:
            dedup[-1] = line
    if len(dedup) != 97:
        raise ModelError(f"GEOMETRY_97_FAILURE line_count={len(dedup)}")
    return dedup


def rr_pass(reward_micro: int, risk_micro: int, rr_min: int) -> bool:
    if risk_micro <= 0:
        return False
    # reward/risk + 1e-12 >= rr_min
    return reward_micro * RR_EPS_DEN + risk_micro >= rr_min * risk_micro * RR_EPS_DEN


def rmax_pass(risk_micro: int, rmax_ticks: Optional[int]) -> bool:
    if rmax_ticks is None:
        return True
    # risk/TICK <= rmax + 1e-9
    return risk_micro * 1_000_000_000 <= TICK_MICRO * (rmax_ticks * 1_000_000_000 + 1)


def trigger_reached(risk_micro: int, trigger_ticks: int) -> bool:
    # risk/TICK + 1e-9 >= trigger
    return risk_micro * 1_000_000_000 + TICK_MICRO >= trigger_ticks * TICK_MICRO * 1_000_000_000


def pnl_units(entry_micro: int, exit_micro: int, direction: int) -> int:
    # P&L BRL = price_micro / 1e6 * 0.2. In 1e-7 BRL units => price_micro*2.
    return (exit_micro - entry_micro) * direction * 2


def money_units_to_brl(units: int) -> str:
    sign = "-" if units < 0 else ""
    u = abs(units)
    whole, frac = divmod(u, MONEY_SCALE)
    return f"{sign}{whole}.{frac:07d}"


def micro_to_price_text(v: int) -> str:
    sign = "-" if v < 0 else ""
    v = abs(v)
    whole, frac = divmod(v, PRICE_SCALE)
    return f"{sign}{whole}.{frac:06d}"


class SessionEngine:
    """Deterministic single-session replay for a chosen subset of valid cells."""

    def __init__(
        self,
        session: str,
        d1: D1Bar,
        cells: list[Cell],
        cutoff_msc: int,
        record_events: bool = True,
        initial_cash_units: Optional[list[int]] = None,
        initial_hwm_units: Optional[list[int]] = None,
        initial_max_dd_units: Optional[list[int]] = None,
        initial_regime_min_units: Optional[list[int]] = None,
        initial_closed_hwm_units: Optional[list[int]] = None,
        initial_closed_max_dd_units: Optional[list[int]] = None,
        integral_open_mark_cell_ids: Optional[set[str]] = None,
        r3_sidecar: Optional[dict] = None,
    ) -> None:
        if not cells:
            raise ModelError("NO_CELLS")
        self.session = session
        self.cells = cells
        self.n = len(cells)
        self.cutoff_msc = cutoff_msc
        self.record_events = record_events

        self.cell_ids = [c.cell_id for c in cells]
        self.cell_index = {c.cell_id: i for i, c in enumerate(cells)}

        self.p_idx = np.array([c.p_idx for c in cells], dtype=np.int8)
        self.t_idx = np.array([c.t_idx for c in cells], dtype=np.int8)
        self.rr_min = np.array([c.rr_min for c in cells], dtype=np.int16)
        self.rmax = np.array([-1 if c.rmax_ticks is None else c.rmax_ticks for c in cells], dtype=np.int16)

        self.lines: dict[int, list[Line]] = {}
        self.line_prices: dict[int, list[int]] = {}
        for pi in sorted(set(c.p_idx for c in cells)):
            grid = build_grid(d1.high_micro, d1.low_micro, PROJECTION_PCT_LIST[pi])
            self.lines[pi] = grid
            self.line_prices[pi] = [x.price_micro for x in grid]

        self.group_cells: dict[tuple[int, int], list[int]] = defaultdict(list)
        for i, c in enumerate(cells):
            self.group_cells[(c.p_idx, c.t_idx)].append(i)

        self.active: dict[tuple[int, int], set[int]] = {
            key: set() for key in self.group_cells
        }

        self.pending_active = np.zeros(self.n, dtype=bool)
        self.pending_dir = np.zeros(self.n, dtype=np.int8)
        self.pending_origin = np.zeros(self.n, dtype=np.int64)
        self.pending_target = np.zeros(self.n, dtype=np.int64)
        self.pending_trigger = np.zeros(self.n, dtype=np.int64)
        self.pending_risk = np.zeros(self.n, dtype=np.int64)
        self.pending_reward = np.zeros(self.n, dtype=np.int64)
        self.pending_trigger_seq = np.zeros(self.n, dtype=np.int64)
        self.pending_n_ordinal = np.zeros(self.n, dtype=np.int64)
        self.pending_n_msc = np.zeros(self.n, dtype=np.int64)
        self.pending_n_last = np.zeros(self.n, dtype=np.int64)
        self.pending_n_identity: list[Optional[dict]] = [None] * self.n

        self.pos_open = np.zeros(self.n, dtype=bool)
        self.pos_dir = np.zeros(self.n, dtype=np.int8)
        self.pos_entry = np.zeros(self.n, dtype=np.int64)
        self.pos_sl = np.zeros(self.n, dtype=np.int64)
        self.pos_tp = np.zeros(self.n, dtype=np.int64)
        self.pos_entry_msc = np.zeros(self.n, dtype=np.int64)
        self.pos_entry_ordinal = np.zeros(self.n, dtype=np.int64)
        self.pos_trade_index = np.full(self.n, -1, dtype=np.int64)

        def _arr_or_zero(values: Optional[list[int]], name: str) -> np.ndarray:
            if values is None:
                return np.zeros(self.n, dtype=np.int64)
            if len(values) != self.n:
                raise ModelError(f"{name}_LENGTH_MISMATCH")
            return np.array(values, dtype=np.int64)

        self.realized = _arr_or_zero(initial_cash_units, "INITIAL_CASH")
        self.hwm = _arr_or_zero(initial_hwm_units, "INITIAL_HWM")
        self.max_dd = _arr_or_zero(initial_max_dd_units, "INITIAL_MAX_DD")
        if initial_regime_min_units is None:
            self.regime_min = self.realized.copy()
        else:
            self.regime_min = _arr_or_zero(initial_regime_min_units, "INITIAL_REGIME_MIN")
        self.closed_hwm = _arr_or_zero(initial_closed_hwm_units, "INITIAL_CLOSED_HWM")
        self.closed_max_dd = _arr_or_zero(initial_closed_max_dd_units, "INITIAL_CLOSED_MAX_DD")
        self.trade_count = np.zeros(self.n, dtype=np.int32)

        integral_ids = integral_open_mark_cell_ids or set()
        self.integral_open_mark = np.array([cid in integral_ids for cid in self.cell_ids], dtype=bool)
        self.open_marks_evaluated = np.zeros(self.n, dtype=np.int64)
        self.open_marks_persisted = np.zeros(self.n, dtype=np.int64)
        self.session_min_equity = self.realized.copy()
        self.session_max_equity = self.realized.copy()

        self.market_bid = 0
        self.market_ask = 0
        self.bid_msc = 0
        self.ask_msc = 0
        self.prev_business = 0
        self.have_prev_business = False
        self.business_seq = 0
        self.cutoff_applied = False
        self.cutoff_pending = np.zeros(self.n, dtype=bool)
        self.r3_sidecar = None
        if r3_sidecar is not None:
            from ff_cutoff_r3_runtime import validate_sidecar
            try:
                validate_sidecar(r3_sidecar)
            except Exception as e:
                raise ModelError(f"R3_SIDECAR_INVALID {type(e).__name__}:{e}") from e
            if str(r3_sidecar.get("session")) != self.session or int(r3_sidecar.get("cutoff_msc")) != int(self.cutoff_msc):
                raise ModelError("R3_SIDECAR_SESSION_OR_CUTOFF")
            self.r3_sidecar = r3_sidecar
        self.first_cutoff_bid_msc = 0
        self.first_cutoff_ask_msc = 0
        self.precutoff_crossed_state_count = 0

        self.trades: list[dict] = []
        self.events: list[dict] = []
        self.equity_events: list[dict] = []

    def _event(self, event: str, rec: TickRecord, cell_indices: Iterable[int], **extra) -> None:
        if not self.record_events:
            return
        ids = [self.cell_ids[i] for i in cell_indices]
        if not ids:
            return
        row = {
            "event": event,
            "ordinal": rec.ordinal,
            "time_msc": rec.time_msc,
            "cell_ids": ids,
        }
        row.update(extra)
        self.events.append(row)

    def _equity_event(self, event: str, rec: TickRecord, idx: int, equity: int, **extra) -> None:
        row = {
            "event": event,
            "cell_id": self.cell_ids[idx],
            "ordinal": rec.ordinal,
            "time_msc": rec.time_msc,
            "equity_units": int(equity),
        }
        row.update(extra)
        self.equity_events.append(row)

    def _update_hwm_dd(self, idx: int, equity: int, rec: TickRecord, event: str, force_record: bool = False, **extra) -> None:
        # V005R1-R2.3: the primary equity curve is always evaluated in full.
        # Persistence may be filtered, but the filter is mathematically lossless for max DD.
        old_hwm = int(self.hwm[idx])
        old_regime_min = int(self.regime_min[idx])
        old_maxdd = int(self.max_dd[idx])

        if equity < int(self.session_min_equity[idx]):
            self.session_min_equity[idx] = equity
        if equity > int(self.session_max_equity[idx]):
            self.session_max_equity[idx] = equity

        new_hwm = equity > old_hwm
        new_regime_min = False
        if new_hwm:
            self.hwm[idx] = equity
            self.regime_min[idx] = equity
        elif equity < old_regime_min:
            self.regime_min[idx] = equity
            new_regime_min = True

        dd = int(self.hwm[idx]) - equity
        if dd > old_maxdd:
            self.max_dd[idx] = dd

        is_plain_open_mark = event == "OPEN_MARK"
        if is_plain_open_mark:
            self.open_marks_evaluated[idx] += 1
            persist = bool(self.integral_open_mark[idx]) or new_hwm or new_regime_min
            if persist:
                self.open_marks_persisted[idx] += 1
        else:
            # Group A events (entry/realization) are always persisted by callers with force_record=True.
            persist = force_record or new_hwm or new_regime_min

        if persist:
            reason = "FULL_CAPTURE" if is_plain_open_mark and bool(self.integral_open_mark[idx]) else (
                "NEW_HWM" if new_hwm else ("NEW_REGIME_MIN" if new_regime_min else "NORMATIVE_EVENT")
            )
            self._equity_event(
                event, rec, idx, equity, hwm_units=int(self.hwm[idx]), dd_units=dd,
                regime_min_units=int(self.regime_min[idx]), persistence_reason=reason, **extra
            )

    def _update_closed_dd(self, idx: int) -> None:
        eq = int(self.realized[idx])
        if eq > int(self.closed_hwm[idx]):
            self.closed_hwm[idx] = eq
        dd = int(self.closed_hwm[idx]) - eq
        if dd > int(self.closed_max_dd[idx]):
            self.closed_max_dd[idx] = dd

    def _bbo_fresh(self, now_msc: int) -> tuple[bool, int, int, str]:
        if self.bid_msc <= 0 or self.ask_msc <= 0 or self.market_bid <= 0 or self.market_ask <= 0 or self.market_ask < self.market_bid:
            return False, -1, -1, "NO_VALID_CAUSAL_BBO"
        if now_msc < self.bid_msc or now_msc < self.ask_msc:
            return False, -1, -1, "CAUSAL_BBO_CLOCK_REGRESSION"
        ba = now_msc - self.bid_msc
        aa = now_msc - self.ask_msc
        if ba > MAX_QUOTE_AGE_MS or aa > MAX_QUOTE_AGE_MS:
            return False, ba, aa, "STALE_CAUSAL_BBO"
        return True, ba, aa, "OK"

    def _close_position(self, idx: int, fill_micro: int, rec: TickRecord, reason: str, equity_event_name: str, **extra) -> None:
        direction = int(self.pos_dir[idx])
        entry = int(self.pos_entry[idx])
        gross = pnl_units(entry, fill_micro, direction)
        self.realized[idx] += gross - EXIT_COST_UNITS
        self.pos_open[idx] = False
        self.trade_count[idx] += 1
        net_trade = gross - ENTRY_COST_UNITS - EXIT_COST_UNITS
        trade_idx = int(self.pos_trade_index[idx])
        if trade_idx < 0 or trade_idx >= len(self.trades):
            raise ModelError("TRADE_INDEX_STATE_INVALID")
        tr = self.trades[trade_idx]
        tr.update({
            "exit_ordinal": rec.ordinal,
            "exit_msc": rec.time_msc,
            "exit_price_micro": fill_micro,
            "exit_reason": reason,
            "gross_pnl_units": gross,
            "cost_units": ENTRY_COST_UNITS + EXIT_COST_UNITS,
            "net_pnl_units": net_trade,
            "duration_ms": rec.time_msc - tr["entry_msc"],
        })
        if extra:
            tr.update(extra)
        eq = int(self.realized[idx])
        self._update_hwm_dd(idx, eq, rec, equity_event_name, force_record=True, exit_reason=reason, **extra)
        self._update_closed_dd(idx)
        self.pos_trade_index[idx] = -1

    def _mark_open(self, idx: int, mark_micro: int, rec: TickRecord, event_name: str = "OPEN_MARK", force_record: bool = False, **extra) -> None:
        direction = int(self.pos_dir[idx])
        entry = int(self.pos_entry[idx])
        unreal = pnl_units(entry, mark_micro, direction)
        eq = int(self.realized[idx]) + unreal - EXIT_COST_UNITS
        self._update_hwm_dd(idx, eq, rec, event_name, force_record=force_record, mark_price_micro=mark_micro, **extra)

    def _process_preexisting_positions(self, rec: TickRecord, bid_updated: bool, ask_updated: bool) -> None:
        if not np.any(self.pos_open):
            return

        open_idx = np.flatnonzero(self.pos_open)
        for idx in open_idx.tolist():
            direction = int(self.pos_dir[idx])
            if direction > 0:
                if not bid_updated:
                    continue
                mark = self.market_bid
                sl = int(self.pos_sl[idx]); tp = int(self.pos_tp[idx])
                if mark <= sl:
                    self._close_position(idx, mark, rec, "STOP", "PREEXISTING_EXIT_POST_REALIZATION")
                elif mark >= tp:
                    self._close_position(idx, tp, rec, "TARGET", "PREEXISTING_EXIT_POST_REALIZATION")
                else:
                    self._mark_open(idx, mark, rec)
            else:
                if not ask_updated:
                    continue
                mark = self.market_ask
                sl = int(self.pos_sl[idx]); tp = int(self.pos_tp[idx])
                if mark >= sl:
                    self._close_position(idx, mark, rec, "STOP", "PREEXISTING_EXIT_POST_REALIZATION")
                elif mark <= tp:
                    self._close_position(idx, tp, rec, "TARGET", "PREEXISTING_EXIT_POST_REALIZATION")
                else:
                    self._mark_open(idx, mark, rec)

    def _consume_pending(self, rec: TickRecord) -> None:
        idxs = np.flatnonzero(self.pending_active & (self.pending_trigger_seq < self.business_seq))
        if len(idxs) == 0:
            return
        ok_bbo, bid_age, ask_age, bbo_reason = self._bbo_fresh(rec.time_msc)

        for idx in idxs.tolist():
            self.pending_active[idx] = False  # consumed before all N+1 validation
            direction = int(self.pending_dir[idx])
            origin = int(self.pending_origin[idx]); target = int(self.pending_target[idx])
            if not ok_bbo:
                self._event("PENDING_REJECT", rec, [idx], reason=bbo_reason, bid_age_ms=bid_age, ask_age_ms=ask_age)
                continue

            entry = self.market_ask if direction > 0 else self.market_bid
            if direction > 0 and not (origin < entry and target > entry):
                self._event("PENDING_REJECT", rec, [idx], reason="BUY_INVALID")
                continue
            if direction < 0 and not (origin > entry and target < entry):
                self._event("PENDING_REJECT", rec, [idx], reason="SELL_INVALID")
                continue
            if self.pos_open[idx]:
                raise ModelError("PENDING_WITH_OPEN_POSITION")

            self.realized[idx] -= ENTRY_COST_UNITS
            self.pos_open[idx] = True
            self.pos_dir[idx] = direction
            self.pos_entry[idx] = entry
            self.pos_sl[idx] = origin
            self.pos_tp[idx] = target
            self.pos_entry_msc[idx] = rec.time_msc
            self.pos_entry_ordinal[idx] = rec.ordinal

            trade = {
                "cell_id": self.cell_ids[idx],
                "session": self.session,
                "direction": "BUY" if direction > 0 else "SELL",
                "n_ordinal": int(self.pending_n_ordinal[idx]),
                "n_msc": int(self.pending_n_msc[idx]),
                "n_last_micro": int(self.pending_n_last[idx]),
                "n_identity": dict(self.pending_n_identity[idx] or {}),
                "n1_ordinal": rec.ordinal,
                "n1_msc": rec.time_msc,
                "entry_msc": rec.time_msc,
                "entry_ordinal": rec.ordinal,
                "entry_price_micro": int(entry),
                "origin_micro": origin,
                "target_micro": target,
                "sl_micro": origin,
                "tp_micro": target,
                "risk_n_micro": int(self.pending_risk[idx]),
                "reward_n_micro": int(self.pending_reward[idx]),
                "risk_n1_micro": abs(entry - origin),
                "bid_micro_n1": int(self.market_bid),
                "ask_micro_n1": int(self.market_ask),
                "bid_msc_n1": int(self.bid_msc),
                "ask_msc_n1": int(self.ask_msc),
                "bid_age_ms": int(bid_age),
                "ask_age_ms": int(ask_age),
                "n1_identity": {
                    "session": rec.session, "ordinal": rec.ordinal, "date_time": rec.date_time,
                    "time_msc": rec.time_msc, "bid_micro": rec.bid_micro, "ask_micro": rec.ask_micro,
                    "last_micro": rec.last_micro, "volume": rec.volume, "volume_real": rec.volume_real,
                    "flags": rec.flags,
                },
                "rr_min": int(self.cells[idx].rr_min),
                "trigger_ticks": int(self.cells[idx].trigger_ticks),
                "rmax_ticks": self.cells[idx].rmax_ticks,
                "projection_pct": str(self.cells[idx].projection_pct),
                "model_assumptions": [
                    "LEGACY_TIME_MSC_SIMULATION_HYPOTHESIS",
                    "BROKER_STOPS_LEVEL_MODEL_0_POINTS_ASSUMPTION",
                    "TARGET_LIMIT_FILL_ON_TOUCH",
                    "CONTINUOUS_WINN_RESEARCH_MODEL",
                ],
            }
            self.trades.append(trade)
            self.pos_trade_index[idx] = len(self.trades) - 1
            self._event("ENTRY", rec, [idx], entry_price_micro=int(entry), bid_age_ms=bid_age, ask_age_ms=ask_age)

            mark = self.market_bid if direction > 0 else self.market_ask
            self._mark_open(idx, mark, rec, "ENTRY_OPEN_MARK", force_record=True)

            # immediate stop is tested only after the entry open mark.
            if direction > 0 and self.market_bid <= origin:
                self._close_position(idx, self.market_bid, rec, "IMMEDIATE_STOP", "IMMEDIATE_STOP_POST_REALIZATION")
            elif direction < 0 and self.market_ask >= origin:
                self._close_position(idx, self.market_ask, rec, "IMMEDIATE_STOP", "IMMEDIATE_STOP_POST_REALIZATION")

    def _activate_crossed_lines(self, prev_micro: int, cur_micro: int) -> None:
        lo = min(prev_micro, cur_micro)
        hi = max(prev_micro, cur_micro)
        for pi, prices in self.line_prices.items():
            a = bisect_left(prices, lo)
            b = bisect_right(prices, hi)
            if a >= b:
                continue
            crossed = range(a, b)
            for ti in sorted({c.t_idx for c in self.cells if c.p_idx == pi}):
                self.active[(pi, ti)].update(crossed)

    def _process_episodes(self, rec: TickRecord) -> None:
        if not self.have_prev_business:
            return
        prev = self.prev_business
        cur = rec.last_micro
        self._activate_crossed_lines(prev, cur)

        eligible: dict[int, list[tuple[int, int, int, int, int]]] = defaultdict(list)

        for (pi, ti), active_set in self.active.items():
            if not active_set:
                continue
            trigger_ticks = TRIGGER_T_LIST[ti]
            lines = self.lines[pi]
            triggered: list[int] = []
            for line_idx in list(active_set):
                line_price = lines[line_idx].price_micro
                risk = abs(cur - line_price)
                if trigger_reached(risk, trigger_ticks):
                    triggered.append(line_idx)
            for line_idx in triggered:
                active_set.remove(line_idx)  # episode consumed before later filters
                line_price = lines[line_idx].price_micro
                risk = abs(cur - line_price)
                direction = 1 if cur > line_price else -1 if cur < line_price else 0
                if direction == 0:
                    continue
                target_idx = line_idx + direction
                if target_idx < 0 or target_idx >= len(lines):
                    continue
                target = lines[target_idx].price_micro
                reward = (target - cur) * direction
                group = self.group_cells[(pi, ti)]
                if reward <= 0:
                    self._event("TARGET_ALREADY_PASSED", rec, group, p_idx=pi, t_idx=ti, line_idx=line_idx)
                    continue

                rr_reject: list[int] = []
                rmax_reject: list[int] = []
                passed: list[int] = []
                for idx in group:
                    c = self.cells[idx]
                    if not rr_pass(reward, risk, c.rr_min):
                        rr_reject.append(idx)
                        continue
                    if not rmax_pass(risk, c.rmax_ticks):
                        rmax_reject.append(idx)
                        continue
                    eligible[idx].append((direction, line_price, target, risk, reward))
                    passed.append(idx)
                self._event("TRIGGER", rec, group, p_idx=pi, t_idx=ti, line_idx=line_idx,
                            origin_micro=line_price, target_micro=target, risk_micro=risk, reward_micro=reward)
                self._event("RR_REJECT", rec, rr_reject, p_idx=pi, t_idx=ti, line_idx=line_idx)
                self._event("RMAX_REJECT", rec, rmax_reject, p_idx=pi, t_idx=ti, line_idx=line_idx)
                self._event("ELIGIBLE", rec, passed, p_idx=pi, t_idx=ti, line_idx=line_idx)

        for idx, candidates in eligible.items():
            if self.pending_active[idx] or self.pos_open[idx]:
                self._event("ELIGIBLE_SKIPPED_BUSY", rec, [idx], eligible_count=len(candidates))
                continue
            if len(candidates) > 1:
                self._event("AMBIGUOUS_MULTI_SIGNAL", rec, [idx], eligible_count=len(candidates))
                continue
            direction, origin, target, risk, reward = candidates[0]
            self.pending_active[idx] = True
            self.pending_dir[idx] = direction
            self.pending_origin[idx] = origin
            self.pending_target[idx] = target
            self.pending_trigger[idx] = cur
            self.pending_risk[idx] = risk
            self.pending_reward[idx] = reward
            self.pending_trigger_seq[idx] = self.business_seq
            self.pending_n_ordinal[idx] = rec.ordinal
            self.pending_n_msc[idx] = rec.time_msc
            self.pending_n_last[idx] = cur
            self.pending_n_identity[idx] = {
                "session": rec.session, "ordinal": rec.ordinal, "date_time": rec.date_time,
                "time_msc": rec.time_msc, "bid_micro": rec.bid_micro, "ask_micro": rec.ask_micro,
                "last_micro": rec.last_micro, "volume": rec.volume, "volume_real": rec.volume_real,
                "flags": rec.flags,
            }
            self._event("PENDING_N", rec, [idx], direction=direction, origin_micro=origin, target_micro=target,
                        risk_micro=risk, reward_micro=reward)

    def _latch_cutoff(self, synthetic_rec: TickRecord) -> None:
        if self.cutoff_applied:
            return
        self.cutoff_applied = True
        pending = np.flatnonzero(self.pending_active).tolist()
        if pending:
            self._event("CUTOFF_PENDING_CANCELLED", synthetic_rec, pending)
            self.pending_active[:] = False
        self.cutoff_pending[:] = self.pos_open
        self._event(
            "CUTOFF_LATCH", synthetic_rec, range(self.n),
            cutoff_msc=self.cutoff_msc, open_positions=int(np.count_nonzero(self.cutoff_pending)),
        )

    def _cutoff_state_crossed(self) -> bool:
        return self.market_bid > 0 and self.market_ask > 0 and self.market_ask < self.market_bid

    def _r3_event_for_direction(self, direction: int) -> Optional[dict]:
        if self.r3_sidecar is None:
            return None
        return self.r3_sidecar["LONG" if int(direction) > 0 else "SHORT"]

    def _attempt_cutoff_close(self, rec: TickRecord) -> None:
        idxs = np.flatnonzero(self.cutoff_pending).tolist()
        if not idxs:
            return

        bid_age = rec.time_msc - self.bid_msc if self.bid_msc > 0 else -1
        ask_age = rec.time_msc - self.ask_msc if self.ask_msc > 0 else -1
        state_crossed = self._cutoff_state_crossed()
        if state_crossed:
            self._event("CUTOFF_FILL_DEFERRED", rec, idxs, reason="CROSSED_BBO")

        for idx in idxs:
            direction = int(self.pos_dir[idx])
            r3 = self._r3_event_for_direction(direction)
            if r3 is not None:
                expected_ordinal = int(r3["x_ordinal"])
                if rec.ordinal > expected_ordinal:
                    raise ModelError(f"R3_X_EVENT_MISSED direction={direction} expected_ordinal={expected_ordinal} got={rec.ordinal}")
                if str(r3["x_kind"]) == "L1":
                    continue
                if rec.ordinal < expected_ordinal:
                    continue

            if state_crossed:
                continue
            if direction > 0:
                eligible = self.market_bid > 0 and self.bid_msc >= self.cutoff_msc and self.bid_msc <= rec.time_msc
                side = "BID"
                side_msc = self.bid_msc
                fill = self.market_bid
            else:
                eligible = self.market_ask > 0 and self.ask_msc >= self.cutoff_msc and self.ask_msc <= rec.time_msc
                side = "ASK"
                side_msc = self.ask_msc
                fill = self.market_ask
            if not eligible:
                if r3 is not None and rec.ordinal == int(r3["x_ordinal"]):
                    raise ModelError("R3_L0_NOT_EXECUTABLE_AT_SEALED_X")
                continue
            if r3 is not None:
                if int(r3["x_time_msc"]) != int(rec.time_msc) or int(r3["x_price_micro"]) != int(fill):
                    raise ModelError("R3_L0_SEALED_X_MISMATCH")
            latency = rec.time_msc - self.cutoff_msc
            extra = {
                "cutoff_msc": int(self.cutoff_msc),
                "cutoff_fill_msc": int(rec.time_msc),
                "cutoff_execution_latency_ms": int(latency),
                "cutoff_side": side,
                "cutoff_side_msc": int(side_msc),
                "first_cutoff_bid_msc": int(self.first_cutoff_bid_msc),
                "first_cutoff_ask_msc": int(self.first_cutoff_ask_msc),
                "bid_age_ms": int(bid_age),
                "ask_age_ms": int(ask_age),
            }
            self._close_position(idx, fill, rec, "CUTOFF", "CUTOFF_CLOSE_POST_REALIZATION", **extra)
            self.cutoff_pending[idx] = False

    def _attempt_r3_l1_close(self, rec: TickRecord) -> None:
        if self.r3_sidecar is None:
            return
        from ff_cutoff_r3_runtime import invalid_side, modeled_l1_price
        idxs = np.flatnonzero(self.cutoff_pending).tolist()
        for idx in idxs:
            direction = int(self.pos_dir[idx])
            side_name = "LONG" if direction > 0 else "SHORT"
            r3 = self.r3_sidecar[side_name]
            if str(r3["x_kind"]) != "L1":
                continue
            expected_ordinal = int(r3["x_ordinal"])
            if rec.ordinal < expected_ordinal:
                continue
            if rec.ordinal > expected_ordinal:
                raise ModelError(f"R3_L1_EVENT_MISSED side={side_name} expected_ordinal={expected_ordinal} got={rec.ordinal}")
            if int(r3["x_time_msc"]) != int(rec.time_msc) or int(r3["x_last_micro"]) != int(rec.last_micro):
                raise ModelError("R3_L1_RECORD_IDENTITY_MISMATCH")
            if not rec.business:
                raise ModelError("R3_L1_EXPECTED_RECORD_NOT_BUSINESS")
            if not invalid_side(side_name, self.market_bid, self.market_ask):
                raise ModelError("R3_L1_EXPECTED_INVALID_SIDE_NOT_INVALID")
            fill = modeled_l1_price(side_name, rec.last_micro)
            if int(r3["x_price_micro"]) != int(fill):
                raise ModelError("R3_L1_MODELED_PRICE_MISMATCH")
            extra = {
                "cutoff_msc": int(self.cutoff_msc),
                "cutoff_fill_msc": int(rec.time_msc),
                "cutoff_execution_latency_ms": int(rec.time_msc - self.cutoff_msc),
                "cutoff_level": "L1",
                "cutoff_modeled_price": True,
                "side_uncertainty_ticks": 1,
                "cutoff_x_ordinal": int(rec.ordinal),
                "cutoff_business_last_micro": int(rec.last_micro),
            }
            self._close_position(idx, fill, rec, "CUTOFF", "CUTOFF_CLOSE_POST_REALIZATION", **extra)
            self.cutoff_pending[idx] = False

    def _mark_cutoff_pending(self, rec: TickRecord) -> None:
        idxs = np.flatnonzero(self.cutoff_pending & self.pos_open).tolist()
        if not idxs or self._cutoff_state_crossed():
            return
        for idx in idxs:
            direction = int(self.pos_dir[idx])
            mark = self.market_bid if direction > 0 else self.market_ask
            if mark <= 0:
                continue
            self._mark_open(
                idx, mark, rec, "OPEN_MARK", force_record=False, cutoff_pending=True,
                cutoff_msc=int(self.cutoff_msc),
                mark_side="BID" if direction > 0 else "ASK",
                mark_side_msc=int(self.bid_msc if direction > 0 else self.ask_msc),
            )

    def process_record(self, rec: TickRecord) -> bool:
        """Returns False when economic processing can stop after the cutoff decision is fully resolved."""
        if rec.session != self.session:
            raise ModelError(f"SESSION_BOUNDARY_CROSSING expected={self.session} got={rec.session}")

        at_or_after_cutoff = rec.time_msc >= self.cutoff_msc
        if at_or_after_cutoff and not self.cutoff_applied:
            syn = TickRecord(
                self.session, rec.ordinal, rec.date_time, self.cutoff_msc,
                self.market_bid, self.market_ask, 0, 0.0, 0.0, 0,
            )
            self._latch_cutoff(syn)

        bid_updated = rec.bid_micro > 0
        ask_updated = rec.ask_micro > 0
        if bid_updated:
            self.market_bid = rec.bid_micro
            self.bid_msc = rec.time_msc
            if self.cutoff_applied and rec.time_msc >= self.cutoff_msc and self.first_cutoff_bid_msc == 0:
                self.first_cutoff_bid_msc = rec.time_msc
        if ask_updated:
            self.market_ask = rec.ask_micro
            self.ask_msc = rec.time_msc
            if self.cutoff_applied and rec.time_msc >= self.cutoff_msc and self.first_cutoff_ask_msc == 0:
                self.first_cutoff_ask_msc = rec.time_msc

        if self.cutoff_applied:
            # R3: X is sealed market-only in preflight. L0 keeps the legacy path; L1 is consumed only at sealed E1.
            self._attempt_cutoff_close(rec)
            self._attempt_r3_l1_close(rec)
            self._mark_cutoff_pending(rec)
            return bool(np.any(self.cutoff_pending))

        # V005R1-R2.3 / owner B1: a crossed causal BBO before cutoff is telemetry only.
        # N+1 still rejects it via _bbo_fresh(); pre-existing positions use only their executable side.
        if rec.time_msc < self.cutoff_msc and self.market_bid > 0 and self.market_ask > 0 and self.market_ask < self.market_bid:
            self.precutoff_crossed_state_count += 1

        self._process_preexisting_positions(rec, bid_updated, ask_updated)

        if not rec.business:
            return True
        self.business_seq += 1
        self._consume_pending(rec)
        if self.have_prev_business:
            self._process_episodes(rec)
        self.prev_business = rec.last_micro
        self.have_prev_business = True
        return True

    def finish(self, final_ordinal: int, final_date_time: str) -> SessionResult:
        if not self.cutoff_applied:
            raise ModelError("CUTOFF_EXECUTION_OBSERVABILITY_UNAVAILABLE")
        if np.any(self.cutoff_pending) or np.any(self.pos_open):
            raise ModelError("POSITION_NOT_FLAT_AFTER_CUTOFF")
        cutoff_diag = {
            "cutoff_msc": int(self.cutoff_msc),
            "first_cutoff_bid_msc": int(self.first_cutoff_bid_msc),
            "first_cutoff_ask_msc": int(self.first_cutoff_ask_msc),
        }
        reconciliation = []
        for idx, cid in enumerate(self.cell_ids):
            reconciliation.append({
                "session": self.session,
                "cell_id": cid,
                "open_marks_evaluated": int(self.open_marks_evaluated[idx]),
                "open_marks_persisted": int(self.open_marks_persisted[idx]),
                "session_min_equity": int(self.session_min_equity[idx]),
                "session_max_equity": int(self.session_max_equity[idx]),
                "end_equity": int(self.realized[idx]),
                "max_dd_to_date": int(self.max_dd[idx]),
            })
        return SessionResult(
            session=self.session,
            cell_ids=self.cell_ids,
            trades=self.trades,
            events=self.events,
            equity_events=self.equity_events,
            equity_reconciliation=reconciliation,
            end_cash_units=[int(x) for x in self.realized.tolist()],
            hwm_units=[int(x) for x in self.hwm.tolist()],
            max_dd_units=[int(x) for x in self.max_dd.tolist()],
            regime_min_units=[int(x) for x in self.regime_min.tolist()],
            closed_hwm_units=[int(x) for x in self.closed_hwm.tolist()],
            closed_max_dd_units=[int(x) for x in self.closed_max_dd.tolist()],
            trade_counts=[int(x) for x in self.trade_count.tolist()],
            cutoff_diagnostics=cutoff_diag,
            precutoff_crossed_state_count=int(self.precutoff_crossed_state_count),
        )


def exact_fraction_cmp(a_num: int, a_den: int, b_num: int, b_den: int) -> int:
    if a_den <= 0 or b_den <= 0:
        raise ValueError("denominator must be >0")
    left = a_num * b_den
    right = b_num * a_den
    return (left > right) - (left < right)


def median_int(values: list[int]) -> Fraction:
    if not values:
        raise ValueError("empty median")
    v = sorted(values)
    n = len(v)
    if n % 2:
        return Fraction(v[n // 2], 1)
    return Fraction(v[n // 2 - 1] + v[n // 2], 2)


def cell_neighbors(cell: Cell, all_valid: dict[str, Cell]) -> list[str]:
    out: set[str] = set()
    # projections: both alternatives
    for pi in range(len(PROJECTION_PCT_LIST)):
        if pi != cell.p_idx:
            cid = f"P{pi:02d}_T{cell.t_idx:02d}_R{cell.rr_idx:02d}_M{cell.m_idx:02d}"
            if cid in all_valid:
                out.add(cid)
    # trigger predecessor/successor
    for ti in (cell.t_idx - 1, cell.t_idx + 1):
        if 0 <= ti < len(TRIGGER_T_LIST):
            cid = f"P{cell.p_idx:02d}_T{ti:02d}_R{cell.rr_idx:02d}_M{cell.m_idx:02d}"
            if cid in all_valid:
                out.add(cid)
    # rr predecessor/successor
    for ri in (cell.rr_idx - 1, cell.rr_idx + 1):
        if 0 <= ri < len(RR_LIST):
            cid = f"P{cell.p_idx:02d}_T{cell.t_idx:02d}_R{ri:02d}_M{cell.m_idx:02d}"
            if cid in all_valid:
                out.add(cid)
    # Rmax undirected: OFF connects all finite; finite connects OFF + finite predecessor/successor
    if cell.m_idx == 0:
        mis = range(1, len(RMAX_LIST))
    else:
        cand = {0}
        if cell.m_idx - 1 >= 1:
            cand.add(cell.m_idx - 1)
        if cell.m_idx + 1 < len(RMAX_LIST):
            cand.add(cell.m_idx + 1)
        mis = cand
    for mi in mis:
        cid = f"P{cell.p_idx:02d}_T{cell.t_idx:02d}_R{cell.rr_idx:02d}_M{mi:02d}"
        if cid in all_valid:
            out.add(cid)
    return sorted(out)
