# CHANGELOG V004R2 -> V004R2R1

- Parent ZIP SHA256: `9C902951442CF9422A96490B5FC51ED1E99EE212B6E88E7925EBA4162C0070CC`
- Diagnostic ZIP SHA256: `18AA954C9B2E3161368BF28D1B815D497975AF6D3C0B2C7D1680FF84B8992C5C`
- Owner state inherited only as cause evidence: G1 PASS, G2 PASS, G3 FAIL, G4 NOT RUN.
- Root cause: cached SHA-256 lowercase representation was persisted to SESSION_SEAL and later compared
  byte-for-byte against uppercase `sha256_file`.
- Production correction: normalize cached digest to uppercase and require exact 64-hex syntax before seal write.
- Regression: dedicated `test_v004r2r1_hash_case_normalization`.
- V005 cardinality correction: `run_v4_checks.py` now uses physical `suite.countTestCases()`.
- No benchmark and no G4 were executed while producing this revision.
