from __future__ import annotations
import argparse, csv, gzip, hashlib, json, os, subprocess, sys, time, traceback, shutil
from pathlib import Path

PACKAGE=Path(__file__).resolve().parent
DEFAULT_OUT=Path(r'D:\MinotauroRuns\MINOTAURO_R1R11_PERF_NEXT_V003R3_W15_B256_20260929')
CURRENT_FULL_ROOT=Path(r'D:\MinotauroRuns\MINOTAURO_R1R11_FULL_CORRECT_C1_V001_20260928')
DEFAULT_PREFLIGHT=Path(r'D:\MinotauroRuns\MINOTAURO_PARAMETER_MARKET_DISCOVERY_V005R1_R1R4')



def current_full_state():
    """Read-only status of the old/current C1 source run. Never mutates that tree."""
    lock=CURRENT_FULL_ROOT/'RUN.lock'
    if not lock.exists(): return {'state':'ABSENT','lock':str(lock)}
    try:
        obj=json.loads(lock.read_text(encoding='utf-8')); pid=int(obj.get('pid',-1))
    except Exception as exc:
        raise RuntimeError('CURRENT_FULL_LOCK_UNREADABLE_UNTOUCHED') from exc
    try:
        from r1r11_resources import process_snapshot
        rows=process_snapshot(); bypid={int(r['pid']):r for r in rows}
    except Exception as exc:
        raise RuntimeError('CURRENT_FULL_PROCESS_STATE_UNVERIFIABLE_UNTOUCHED') from exc
    active=pid in bypid or any(int(r['ppid'])==pid for r in rows)
    return {'state':'ACTIVE' if active else 'STALE_LOCK','pid':pid,'lock':str(lock)}

def require_current_full_stopped():
    st=current_full_state()
    if st['state']=='ACTIVE': raise RuntimeError('CURRENT_FULL_ACTIVE_INTERFERENCE_FORBIDDEN')
    if st['state']=='STALE_LOCK': raise RuntimeError('CURRENT_FULL_STALE_LOCK_REQUIRES_SEPARATE_RECONCILIATION_UNTOUCHED')
    return st


def sha(path: Path)->str:
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest().upper()


def atomic(path: Path,obj: dict):
    from minotauro_v005r1_r23_contract import write_json_atomic_canonical
    path.parent.mkdir(parents=True,exist_ok=True);write_json_atomic_canonical(path,obj)


def verify_package()->str:
    manifest=PACKAGE/'SHA256SUMS.txt'; listed={}
    for line in manifest.read_text(encoding='ascii').splitlines():
        if not line.strip():continue
        h,n=line.split(None,1);n=n.strip().removeprefix('./');p=(PACKAGE/n).resolve()
        if not p.is_relative_to(PACKAGE) or n in listed or not p.is_file() or sha(p)!=h.upper():
            raise RuntimeError('PACKAGE_MANIFEST_FAILURE '+n)
        listed[n]=h.upper()
    actual={p.relative_to(PACKAGE).as_posix() for p in PACKAGE.rglob('*') if p.is_file() and p!=manifest}
    if set(listed)!=actual:raise RuntimeError('PACKAGE_MANIFEST_SET_MISMATCH '+repr(actual^set(listed)))
    return sha(manifest)


def config(out: Path)->dict:
    return {
      'ticks_root':r'D:\Base CSV\WIN@N',
      'm1_root':r'D:\Base CSV\WIN@N_M1',
      'ind_d1':r'D:\Base CSV\IND@N\IND@N.csv',
      'preflight_source_root':str(DEFAULT_PREFLIGHT),
      'out_root':str(out),
      'memory_cap_mib':48528,
      'r1r11_owner_gate_receipt':str(out/'GATES'/'CORRECTNESS_PREPILOT_RECEIPT.json'),
      'correctness_fast_full_v001':True,
    }


def run_child(args, log: Path, cwd=PACKAGE):
    log.parent.mkdir(parents=True,exist_ok=True)
    with log.open('a',encoding='utf-8') as f:
        f.write('COMMAND '+json.dumps([str(x) for x in args])+'\n');f.flush()
        p=subprocess.Popen([str(x) for x in args],cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                           text=True,encoding='utf-8',errors='replace',env={**os.environ,'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'})
        for line in p.stdout:
            f.write(line);f.flush()
            if any(x in line for x in ('PASS','BLOCKED','PROGRESS','SESSION_COMMIT','RUN_MONTH_HASH_VERIFIED','GRANTED_WORKERS','SAFE_STOP')):
                print(line.rstrip(),flush=True)
        code=p.wait();f.write(f'EXIT_CODE={code}\n')
    if code!=0:raise RuntimeError(f'CHILD_FAILED exit={code} log={log}')


def _session_artifact_tree(root: Path)->dict:
    out={}
    for p in sorted((root/'sessions').rglob('*')):
        if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
    return out


def _checkpoint_economic_view(root: Path)->dict:
    obj=json.loads((root/'CHECKPOINT.json').read_text(encoding='utf-8'))
    # V003 adds source-resume infrastructure metadata. It is intentionally not
    # part of the economic state. The checkpoint self-hash necessarily changes
    # when that metadata key is present, so compare neither field here.
    obj.pop('source_resume',None)
    obj.pop('checkpoint_content_sha256',None)
    return obj


def _synthetic_equivalence(oracle: Path,candidate: Path)->dict:
    ot=_session_artifact_tree(oracle);ct=_session_artifact_tree(candidate)
    missing=sorted(set(ot)-set(ct));extra=sorted(set(ct)-set(ot))
    changed=sorted(k for k in set(ot)&set(ct) if ot[k]!=ct[k])
    if missing or extra or changed:
        raise RuntimeError('CORRECTNESS_SYNTHETIC_SESSION_BYTE_DIFFERENCE '+
                           json.dumps({'missing':missing[:10],'extra':extra[:10],'changed':changed[:10]},sort_keys=True))
    ocp=_checkpoint_economic_view(oracle);ccp=_checkpoint_economic_view(candidate)
    if ocp!=ccp:
        keys=sorted(k for k in set(ocp)|set(ccp) if ocp.get(k)!=ccp.get(k))
        raise RuntimeError('CORRECTNESS_SYNTHETIC_CHECKPOINT_ECONOMIC_DIFFERENCE '+
                           json.dumps({'keys':keys[:20]},sort_keys=True))
    return {'session_artifacts_byte_equal':True,
            'checkpoint_economic_state_equal':True,
            'checkpoint_schema_delta_allowed':['source_resume','checkpoint_content_sha256']}



def ensure_perf_configuration(out: Path, workers: int, batch_rows: int):
    cfg_path=out/'PERF_NEXT_CONFIGURATION.json'
    wanted={'schema':'MINOTAURO_PERF_NEXT_CONFIGURATION_V003','workers':int(workers),'batch_rows':int(batch_rows)}
    if cfg_path.exists():
        got=json.loads(cfg_path.read_text(encoding='utf-8'))
        if got!=wanted:
            raise RuntimeError('PERF_NEXT_CONFIGURATION_MISMATCH_NEW_ROOT_REQUIRED')
        return
    out.mkdir(parents=True,exist_ok=True)
    atomic(cfg_path,wanted)


def synthetic_qualify(out: Path, workers: int, batch_rows: int):
    gates=out/'GATES'; receipt=gates/'CORRECTNESS_SYNTHETIC_RECEIPT.json'
    pkg_hash=verify_package()
    if receipt.is_file():
        r=json.loads(receipt.read_text())
        if (r.get('status')=='PASS' and r.get('package_manifest_sha256')==pkg_hash and
                int(r.get('workers',-1))==int(workers) and int(r.get('batch_rows',-1))==int(batch_rows)):
            print('CORRECTNESS_SYNTHETIC=RESUME_PASS',flush=True);return r
        raise RuntimeError('PERF_NEXT_SYNTHETIC_RECEIPT_CONFIG_MISMATCH_NEW_ROOT_REQUIRED')
    syn=out/'CORRECTNESS_SYNTHETIC';inputs=syn/'inputs';oracle=syn/'oracle';candidate=syn/'candidate'
    if syn.exists():
        import shutil;shutil.rmtree(syn)
    syn.mkdir(parents=True)
    from r1r11_perf_fixtures import generate
    generate(inputs,heavy_cycles=1200)
    run_child([sys.executable,'-X','utf8','-B',PACKAGE/'r1r11_fixtures.py','--inputs',inputs,'--out',oracle,'--role','oracle'],syn/'oracle.log')
    run_child([sys.executable,'-X','utf8','-B',PACKAGE/'r1r11_perf_fixtures.py','--inputs',inputs,'--out',candidate,'--role','candidate','--workers',str(workers),'--batch-rows',str(batch_rows)],syn/'candidate.log')
    equivalence=_synthetic_equivalence(oracle,candidate)
    # Explicit C1 inspection: every candidate CUTOFF line must equal the synthetic preflight row persisted in its receipt.
    cutoff_rows=0
    for sessdir in sorted((candidate/'sessions').iterdir()):
        if not sessdir.is_dir():continue
        sr=json.loads((sessdir/'session_receipt.json').read_text())
        cal=sr['cutoff_diagnostics_preflight']
        with gzip.open(sessdir/'trades.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                tr=json.loads(line)
                if tr.get('exit_reason')!='CUTOFF':continue
                cutoff_rows+=1
                exp=cal['cutoff_long_fill_msc'] if tr['direction']=='BUY' else cal['cutoff_short_fill_msc']
                if int(tr['cutoff_fill_msc'])!=int(exp):raise RuntimeError('C1_SYNTHETIC_FILL')
                if int(tr.get('first_cutoff_bid_msc',-1))!=int(cal['first_cutoff_bid_msc']):raise RuntimeError('C1_SYNTHETIC_BID')
                if int(tr.get('first_cutoff_ask_msc',-1))!=int(cal['first_cutoff_ask_msc']):raise RuntimeError('C1_SYNTHETIC_ASK')
    if cutoff_rows<1:raise RuntimeError('C1_SYNTHETIC_NONVACUITY_NO_CUTOFF_TRADES')
    r={'status':'PASS','package_manifest_sha256':pkg_hash,'workers':workers,'batch_rows':batch_rows,
       **equivalence,'cutoff_rows_checked':cutoff_rows,
       'oracle_execution_sha256':sha(oracle/'SYNTHETIC_EXECUTION.json'),'candidate_execution_sha256':sha(candidate/'SYNTHETIC_EXECUTION.json')}
    atomic(receipt,r);print(f'CORRECTNESS_SYNTHETIC=PASS cutoff_rows={cutoff_rows}',flush=True);return r


def rebind_and_seal(out: Path):
    cfg=config(out); phase=out/'PHASE_A'; binding_path=phase/'RUN_SOURCE_BINDING_A.json'; gates=out/'GATES'; gates.mkdir(parents=True,exist_ok=True)
    if not binding_path.is_file():
        from minotauro_v005r1_r23_binding import build_binding
        print('CORRECTNESS_REBIND=START',flush=True);build_binding(cfg,PACKAGE)
    from minotauro_v005r1_r23_contract import canonical_json_hash, write_json_atomic_canonical, runner_identity
    from minotauro_v004_io import sha256_file
    b=json.loads(binding_path.read_text())
    if b.get('status')=='PASS_REBOUND_UNSEALED':
        b['status']='PASS_SEALED_PREPILOT'
        b['correctness_fast_path']='PERF_NEXT_V003_C1_PRESERVED'
        b['correctness_package_manifest_sha256']=verify_package()
        b['binding_content_sha256']=canonical_json_hash(b,exclude_keys={'binding_content_sha256'})
        write_json_atomic_canonical(binding_path,b)
    elif b.get('status')!='PASS_SEALED_PREPILOT':raise RuntimeError('CORRECTNESS_BINDING_STATUS '+str(b.get('status')))
    if b.get('binding_content_sha256')!=canonical_json_hash(b,exclude_keys={'binding_content_sha256'}):raise RuntimeError('CORRECTNESS_BINDING_SELF_HASH')
    if sha256_file(phase/'SESSION_CALENDAR_PHASE_A.csv')!=b.get('session_calendar_sha256'):raise RuntimeError('CORRECTNESS_CALENDAR_HASH')
    rh,_=runner_identity(PACKAGE)
    r={'status':'PASS','authority':'OWNER_PERF_NEXT_FUTURE_RUNNER_20260929','package_manifest_sha256':verify_package(),
       'runner_sha256':rh,'run_source_binding_sha256':sha(binding_path),'C1_CUTOFF_FIX':'PASS_REQUIRED','performance_gate_blocking':False}
    atomic(gates/'CORRECTNESS_PREPILOT_RECEIPT.json',r);print('CORRECTNESS_BINDING=PASS_SEALED',flush=True);return r


def _patch_authority(out: Path, full=False):
    import minotauro_v004_runner as runner
    import r1r11_contract as contract
    from minotauro_v004_io import sha256_file
    prep=out/'GATES'/'CORRECTNESS_PREPILOT_RECEIPT.json'; fullp=out/'GATES'/'CORRECTNESS_FULL_AUTHORIZATION.json'
    def req_owner(cfg):
        p=fullp if full else prep
        if not p.is_file():raise runner.ModelError('CORRECTNESS_AUTHORITY_REQUIRED')
        obj=json.loads(p.read_text());
        if obj.get('status')!='PASS' or obj.get('package_manifest_sha256')!=verify_package():raise runner.ModelError('CORRECTNESS_AUTHORITY_STALE')
        return obj
    def req_pre(root,package_root,identity):return sha256_file(prep)
    def req_run(root,package_root,identity):return sha256_file(fullp)
    def req_pilot(root,identity,prepilot_hash):
        if prepilot_hash!=sha256_file(prep):raise runner.ModelError('CORRECTNESS_PILOT_AUTH_HASH')
    contract.require_owner_gates=req_owner
    runner._require_prepilot_gates=req_pre
    runner._require_pilot_authorization=req_pilot
    runner._require_run_a_gates=req_run
    return runner


def run_phase(out: Path, mode: str, workers: int, batch_rows: int):
    runner=_patch_authority(out,full=(mode=='RUN_A'))
    cfg=config(out)
    print(f'PERF_NEXT_REAL_RUN_START mode={mode} workers={workers} batch_rows={batch_rows}',flush=True)
    runner.run_phase_a(cfg,mode,workers=workers,batch_rows=batch_rows)


def _trade_key(tr):
    return (tr.get('direction'),int(tr.get('n_ordinal',-1)),int(tr.get('n1_ordinal',-1)),int(tr.get('entry_ordinal',-1)),
            int(tr.get('exit_ordinal',-1)),int(tr.get('entry_price_micro',0)),int(tr.get('exit_price_micro',0)),tr.get('exit_reason'),int(tr.get('net_pnl_units',0)))


def pilot_reconcile(out: Path):
    gates=out/'GATES'; dest=gates/'CORRECTNESS_PILOT_RECONCILIATION.json'
    if dest.is_file() and json.loads(dest.read_text()).get('status')=='PASS':print('CORRECTNESS_PILOT_RECONCILIATION=RESUME_PASS');return
    from minotauro_v004_io import load_d1, iter_tick_file
    from minotauro_v004_core import valid_cells, BASELINE_CELL_ID
    from minotauro_v005r1_r23_reference import ReferencePilotEngine
    phase=out/'PHASE_A';pilot=out/'PILOT_A';cfg=config(out)
    pr=json.loads((pilot/'PILOT_RUN_RECEIPT.json').read_text());sessions=pr['sessions']
    if len(sessions)!=3:raise RuntimeError('PILOT_NOT_3')
    with (phase/'SESSION_CALENDAR_PHASE_A.csv').open('r',encoding='utf-8-sig',newline='') as f:calendar={r['session_date']:r for r in csv.DictReader(f,delimiter=';')}
    d1=load_d1(Path(cfg['ind_d1']));cells=valid_cells();refs={};by_file={}
    for s in sessions:by_file.setdefault(Path(calendar[s]['tick_file']),[]).append(s)
    for tp,ss in sorted(by_file.items(),key=lambda kv:str(kv[0])):
        engs={}
        for rec in iter_tick_file(tp,include_sessions=set(ss)):
            if rec.session not in engs:
                row=calendar[rec.session];engs[rec.session]=ReferencePilotEngine(rec.session,d1[row['expected_previous_session_date']],cells,int(row['cutoff_msc']))
            engs[rec.session].process(rec)
        for s in ss:refs[s]=engs[s].finish()
    mismatches=[];c1=0
    for s in sessions:
        rows=[]
        with gzip.open(pilot/'sessions'/s/'trades.jsonl.gz','rt',encoding='utf-8') as f:rows=[json.loads(x) for x in f if x.strip()]
        by={}
        for tr in rows:by.setdefault(tr['cell_id'],[]).append(tr)
        for c in cells:
            pv=sorted(by.get(c.cell_id,[]),key=lambda x:(int(x.get('entry_ordinal',-1)),int(x.get('exit_ordinal',-1))))
            rv=refs[s].get(c.cell_id,[])
            pa=[_trade_key(x) for x in pv] if c.cell_id==BASELINE_CELL_ID else ([_trade_key(pv[0])] if pv else [])
            ra=[_trade_key(x) for x in rv] if c.cell_id==BASELINE_CELL_ID else ([_trade_key(rv[0])] if rv else [])
            if pa!=ra:mismatches.append((s,c.cell_id,'ECONOMIC'))
        cal=calendar[s]
        for tr in rows:
            if tr.get('exit_reason')!='CUTOFF':continue
            c1+=1;exp=int(cal['cutoff_long_fill_msc'] if tr['direction']=='BUY' else cal['cutoff_short_fill_msc'])
            if int(tr['cutoff_fill_msc'])!=exp or int(tr.get('first_cutoff_bid_msc',-1))!=int(cal['first_cutoff_bid_msc']) or int(tr.get('first_cutoff_ask_msc',-1))!=int(cal['first_cutoff_ask_msc']):
                mismatches.append((s,tr['cell_id'],'C1'))
    r={'status':'PASS' if not mismatches else 'FAIL','sessions':sessions,'mismatches':len(mismatches),'c1_cutoff_rows_checked':c1}
    atomic(dest,r)
    if mismatches:raise RuntimeError('CORRECTNESS_PILOT_RECONCILIATION_FAIL '+repr(mismatches[:5]))
    print(f'CORRECTNESS_PILOT_RECONCILIATION=PASS c1_cutoff_rows={c1}',flush=True)


def disk_gate_after_pilot(out: Path):
    pilot_sessions=out/'PILOT_A'/'sessions'
    if not pilot_sessions.is_dir():raise RuntimeError('DISK_GATE_PILOT_SESSIONS_MISSING')
    sizes=[]
    for d in sorted(pilot_sessions.iterdir()):
        if d.is_dir():sizes.append(sum(p.stat().st_size for p in d.rglob('*') if p.is_file()))
    if len(sizes)!=3:raise RuntimeError('DISK_GATE_PILOT_SESSION_COUNT')
    max_session=max(sizes); projected=max_session*250
    required=int(projected*1.35 + 10*1024**3)
    usage=shutil.disk_usage(out.anchor or str(out))
    receipt={'pilot_session_bytes':sizes,'max_pilot_session_bytes':max_session,'projected_250_bytes':projected,
             'safety_factor':1.35,'fixed_reserve_bytes':10*1024**3,'required_free_bytes':required,'actual_free_bytes':usage.free,
             'status':'PASS' if usage.free>=required else 'BLOCKED'}
    atomic(out/'GATES'/'CORRECTNESS_DISK_GATE.json',receipt)
    print(f'CORRECTNESS_DISK_GATE={receipt["status"]} free_gib={usage.free/1024**3:.2f} required_gib={required/1024**3:.2f}',flush=True)
    if receipt['status']!='PASS':raise RuntimeError('FULL_DISK_CAPACITY_INSUFFICIENT')
    return receipt

def authorize_full(out: Path):
    prep=json.loads((out/'GATES'/'CORRECTNESS_PREPILOT_RECEIPT.json').read_text());pilot=json.loads((out/'GATES'/'CORRECTNESS_PILOT_RECONCILIATION.json').read_text())
    if prep.get('status')!='PASS' or pilot.get('status')!='PASS':raise RuntimeError('CORRECTNESS_FULL_AUTH_PREREQ')
    r={'status':'PASS','RUN_A_AUTHORIZED':'YES','authority':'OWNER_PERF_NEXT_FUTURE_RUNNER_20260929','package_manifest_sha256':verify_package(),
       'prepilot_receipt_sha256':sha(out/'GATES'/'CORRECTNESS_PREPILOT_RECEIPT.json'),'pilot_reconciliation_sha256':sha(out/'GATES'/'CORRECTNESS_PILOT_RECONCILIATION.json'),
       'performance_gate_blocking':False}
    atomic(out/'GATES'/'CORRECTNESS_FULL_AUTHORIZATION.json',r);print('CORRECTNESS_FULL_AUTHORIZATION=PASS',flush=True)


def import_final_committed(out: Path, stop_receipt: Path):
    require_current_full_stopped()
    stop_receipt=Path(stop_receipt).resolve()
    if not stop_receipt.is_file(): raise RuntimeError('SOURCE_STOP_RECEIPT_MISSING')
    args=[sys.executable,'-X','utf8','-B',PACKAGE/'r1r11_resume_import.py',
          '--source-root',CURRENT_FULL_ROOT,'--target-root',out,
          '--dynamic-final-state','--source-stop-receipt',stop_receipt]
    run_child(args,out/'TELEMETRY'/'COMMITTED_MIGRATION_V003.log')

def require_dynamic_migration(out: Path):
    p=out/'GATES'/'COMMITTED_MIGRATION_RECEIPT.json'
    if not p.is_file(): raise RuntimeError('DYNAMIC_COMMITTED_MIGRATION_REQUIRED')
    r=json.loads(p.read_text(encoding='utf-8'))
    if r.get('status')!='PASS' or r.get('binding_mode')!='DYNAMIC_FINAL_STATE':
        raise RuntimeError('DYNAMIC_COMMITTED_MIGRATION_NOT_PASS')
    if (CURRENT_FULL_ROOT/'RUN.lock').exists(): raise RuntimeError('SOURCE_LOCK_REAPPEARED_AFTER_MIGRATION')
    source_cp=CURRENT_FULL_ROOT/'PHASE_A'/'CHECKPOINT.json'
    if not source_cp.is_file() or sha(source_cp)!=str(r.get('source_checkpoint_sha256','')).upper():
        raise RuntimeError('SOURCE_STATE_CHANGED_AFTER_DYNAMIC_MIGRATION')
    return r

def homologate(out: Path):
    phase=out/'PHASE_A';gates=out/'GATES';cp=json.loads((phase/'CHECKPOINT.json').read_text())
    done=cp.get('completed',[]);verified=cp.get('verified_months',{})
    if len(done)!=250 or len(set(done))!=250:raise RuntimeError('FULL_COMPLETED_NOT_250')
    if len(verified)!=12:raise RuntimeError('FULL_MONTHS_NOT_12')
    sessions=phase/'sessions';actual={p.name for p in sessions.iterdir() if p.is_dir()}
    if actual!=set(done):raise RuntimeError('FULL_SESSION_SET')
    if json.loads((phase/'EQUITY_LOSSLESS_GATE.json').read_text()).get('status')!='PASS':raise RuntimeError('FULL_EQUITY_LOSSLESS')
    with (phase/'SESSION_CALENDAR_PHASE_A.csv').open('r',encoding='utf-8-sig',newline='') as f:cal={r['session_date']:r for r in csv.DictReader(f,delimiter=';')}
    c1=0
    for s in sorted(done):
        files={p.name for p in (sessions/s).iterdir() if p.is_file()}
        if files!={'trades.jsonl.gz','events.jsonl.gz','equity.jsonl.gz','equity_reconciliation.jsonl.gz','session_receipt.json'}:raise RuntimeError('FULL_SESSION_FILES '+s)
        sr=json.loads((sessions/s/'session_receipt.json').read_text()); row=cal[s]
        pre=sr['cutoff_diagnostics_preflight']
        for k in ('first_cutoff_bid_msc','first_cutoff_ask_msc','cutoff_long_fill_msc','cutoff_short_fill_msc'):
            if int(pre[k])!=int(row[k]):raise RuntimeError('FULL_RECEIPT_C1 '+s+' '+k)
        with gzip.open(sessions/s/'trades.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                tr=json.loads(line)
                if tr.get('exit_reason')!='CUTOFF':continue
                c1+=1;exp=int(row['cutoff_long_fill_msc'] if tr['direction']=='BUY' else row['cutoff_short_fill_msc'])
                if int(tr['cutoff_fill_msc'])!=exp or int(tr.get('first_cutoff_bid_msc',-1))!=int(row['first_cutoff_bid_msc']) or int(tr.get('first_cutoff_ask_msc',-1))!=int(row['first_cutoff_ask_msc']):
                    raise RuntimeError('FULL_TRADE_C1 '+s+' '+tr['cell_id'])
    # Verify master manifest exactly.
    master=phase/'SHA256SUMS.txt';listed={}
    for line in master.read_text().splitlines():
        h,rel=line.split(None,1);rel=rel.strip().removeprefix('./');p=phase/rel
        if not p.is_file() or sha(p)!=h.upper():raise RuntimeError('FULL_MASTER_HASH '+rel)
        listed[rel]=h.upper()
    actual_files={p.relative_to(phase).as_posix() for p in phase.rglob('*') if p.is_file() and p.name!='CHECKPOINT.json' and not p.name.endswith('.tmp') and p!=master}
    if set(listed)!=actual_files:raise RuntimeError('FULL_MASTER_SET')
    status_path=out/'TELEMETRY'/'R1R11_STATUS.json'
    if not status_path.is_file():raise RuntimeError('FULL_RUNTIME_STATUS_MISSING')
    st=json.loads(status_path.read_text(encoding='utf-8'))
    if (st.get('schema')!='MINOTAURO_R1R11_RUNTIME_STATUS_V001' or
            st.get('PHASE')!='RUN_A_PASS' or int(st.get('COMMITTED',-1))!=250 or
            int(st.get('TOTAL',-1))!=250 or st.get('PROCESS_TREE_CLEAN')!='YES' or
            int(st.get('ACTIVE',-1))!=0):
        raise RuntimeError('FULL_RUNTIME_STATUS_NOT_CLEAN_PASS')
    if (out/'RUN.lock').exists():raise RuntimeError('FULL_RUN_LOCK_RESIDUAL')
    scratch=out/'_scratch'
    scratch_entries=list(scratch.iterdir()) if scratch.is_dir() else []
    if scratch_entries:raise RuntimeError('FULL_SCRATCH_RESIDUAL')
    r={'CORRECTNESS_FULL_HOMOLOGATION':'PASS','sessions':250,'verified_months':12,'c1_cutoff_rows_checked':c1,
       'package_manifest_sha256':verify_package(),'checkpoint_sha256':sha(phase/'CHECKPOINT.json'),'master_manifest_sha256':sha(master),
       'selection_freeze_sha256':sha(phase/'SELECTION_FREEZE.json'),'run_manifest_sha256':sha(phase/'RUN_MANIFEST.json'),
       'runtime_status_sha256':sha(status_path),'process_tree_clean':'YES','run_lock_absent':'YES','scratch_cleanup':'PASS'}
    atomic(gates/'CORRECTNESS_FULL_HOMOLOGATION_RECEIPT.json',r)
    final_report={
        'schema':'MINOTAURO_PERF_NEXT_FINAL_REPORT_V001','status':'PASS',
        'COMMITTED':250,'TOTAL':250,'verified_months':12,'c1_cutoff_rows_checked':c1,
        'checkpoint_sha256':r['checkpoint_sha256'],'master_manifest_sha256':r['master_manifest_sha256'],
        'runtime_status_sha256':r['runtime_status_sha256'],'process_tree_clean':'YES',
        'run_lock_absent':'YES','scratch_cleanup':'PASS','telemetry_retained':'YES',
        'homologation_receipt_sha256':sha(gates/'CORRECTNESS_FULL_HOMOLOGATION_RECEIPT.json')}
    atomic(gates/'FINAL_REPORT.json',final_report)
    print(f'CORRECTNESS_FULL_HOMOLOGATION=PASS sessions=250 cutoff_rows={c1}',flush=True)
    print('FINAL_REPORT=PASS process_tree_clean=YES run_lock_absent=YES scratch_cleanup=PASS',flush=True)


def all_chain(out: Path,workers:int,batch_rows:int):
    out.mkdir(parents=True,exist_ok=True)
    cfg=config(out); (out/'CORRECTNESS_CONFIG.json').write_text(json.dumps(cfg,indent=2),encoding='utf-8')
    synthetic_qualify(out,workers,batch_rows)
    rebind_and_seal(out)
    pilot_receipt=out/'PILOT_A'/'PILOT_RUN_RECEIPT.json'
    if not pilot_receipt.is_file():run_phase(out,'PILOT_A',workers,batch_rows)
    pilot_reconcile(out)
    disk_gate_after_pilot(out)
    authorize_full(out)
    cp=out/'PHASE_A'/'CHECKPOINT.json'
    complete=False
    if cp.is_file():
        try:complete=len(json.loads(cp.read_text()).get('completed',[]))==250
        except Exception:pass
    if not complete:run_phase(out,'RUN_A',workers,batch_rows)
    homologate(out)
    print('MINOTAURO_PERF_NEXT_CHAIN=PASS',flush=True)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('command',choices=['qualify','pilot','prepare-full','import-final','full','homologate'],default='qualify',nargs='?')
    ap.add_argument('--out',default=str(DEFAULT_OUT))
    ap.add_argument('--workers',type=int,default=15)
    ap.add_argument('--batch-rows',type=int,choices=[32,64,128,256],default=256)
    ap.add_argument('--source-stop-receipt')
    ns=ap.parse_args();out=Path(ns.out)
    try:
        if out.resolve()==CURRENT_FULL_ROOT.resolve():raise RuntimeError('PERF_NEXT_OUT_MUST_NOT_EQUAL_CURRENT_FULL_ROOT')
        state=current_full_state()
        print(f'CURRENT_FULL_STATE={state["state"]} DEVELOPMENT_ISOLATED=YES SOURCE_MUTATION=NO',flush=True)
        ensure_perf_configuration(out,ns.workers,ns.batch_rows)
        if ns.command=='qualify':
            # Synthetic-only qualification is intentionally allowed while the old FULL runs.
            synthetic_qualify(out,ns.workers,ns.batch_rows)
            print('QUALIFY_REAL_MARKET_DATA_READ=NO SOURCE_TREE_MUTATION=NO',flush=True)
        elif ns.command=='pilot':
            require_current_full_stopped();rebind_and_seal(out);run_phase(out,'PILOT_A',ns.workers,ns.batch_rows);pilot_reconcile(out)
        elif ns.command=='prepare-full':
            require_current_full_stopped();rebind_and_seal(out);pilot_reconcile(out);disk_gate_after_pilot(out);authorize_full(out)
        elif ns.command=='import-final':
            if not ns.source_stop_receipt: raise RuntimeError('SOURCE_STOP_RECEIPT_ARGUMENT_REQUIRED')
            import_final_committed(out,Path(ns.source_stop_receipt))
        elif ns.command=='full':
            require_current_full_stopped();require_dynamic_migration(out);authorize_full(out);run_phase(out,'RUN_A',ns.workers,ns.batch_rows)
        else:
            homologate(out)
    except KeyboardInterrupt:
        print('SAFE_STOP=YES PROCESS_TREE_CLEAN=PROVED_BY_RUNTIME',flush=True);raise SystemExit(130)
    except Exception as e:
        print('MINOTAURO_PERF_NEXT_CHAIN=BLOCKED',flush=True);print(f'ERROR={type(e).__name__}:{e}',flush=True);traceback.print_exc();raise SystemExit(2)

if __name__=='__main__':main()
