from __future__ import annotations

from pathlib import Path
import argparse
import json
import shutil
import tempfile

from minotauro_v004_core import ModelError
from minotauro_v004_io import load_d1, write_csv
from minotauro_v004_preflight import build_expected, _validate_d1
from minotauro_v005r1_r23_contract import (
    EXPECTED_CORE_IMPORTED_DEFINITIONS_SHA256,
    EXPECTED_IO_SHA256,
    EXPECTED_PREFLIGHT_SHA256,
    RUNNER_VERSION,
    SPEC_SHA256,
    canonical_json_hash,
    core_imported_definitions_hash,
    hash_manifest_rows,
    parse_source_inventory,
    read_json,
    sha256_file,
    write_json_atomic_canonical,
)

REQUIRED_PREFLIGHT_ARTIFACTS = (
    "PHASE_STATUS.json",
    "PREFLIGHT_FAILURES.json",
    "SOURCE_INVENTORY.json",
    "CUTOFF_LATENCY_DIAGNOSTICS.csv",
    "SESSION_CALENDAR_PHASE_A.csv",
    "EXPECTED_SESSIONS_PHASE_A.csv",
)


def _ensure_clean_for_rebind(phase_out: Path) -> None:
    sessions = phase_out / "sessions"
    if sessions.exists() and any(sessions.iterdir()):
        raise ModelError("REBIND_BLOCKED_EXISTING_ECONOMIC_SESSIONS")
    cp = phase_out / "CHECKPOINT.json"
    if cp.exists():
        raise ModelError("REBIND_BLOCKED_EXISTING_CHECKPOINT")


def _copy_frozen(source_phase: Path, dest_phase: Path) -> None:
    dest_phase.mkdir(parents=True, exist_ok=True)
    for name in REQUIRED_PREFLIGHT_ARTIFACTS:
        src = source_phase / name
        dst = dest_phase / name
        if not src.is_file():
            raise ModelError(f"REBIND_SOURCE_ARTIFACT_MISSING {src}")
        if dst.exists() and sha256_file(dst) != sha256_file(src):
            raise ModelError(f"REBIND_DEST_ARTIFACT_CONFLICT {dst}")
        shutil.copy2(src, dst)
    # Canonical phase-qualified alias required by V005R1 §19.
    shutil.copy2(source_phase / "SOURCE_INVENTORY.json", dest_phase / "SOURCE_INVENTORY_PHASE_A.json")


def _m1_files_used(m1_root: Path) -> list[Path]:
    out = []
    for p in sorted(m1_root.glob("WIN@N_M1_*.csv")):
        ym = p.stem[-7:]
        if "2024_01" <= ym <= "2025_12":
            out.append(p)
    if not out:
        raise ModelError("REBIND_M1_FILES_UNAVAILABLE")
    return out


def _same_bytes(a: Path, b: Path) -> bool:
    return a.read_bytes() == b.read_bytes()


def build_binding(cfg: dict, package_root: Path) -> dict:
    out_root = Path(cfg["out_root"])
    phase_out = out_root / "PHASE_A"
    raw_source_root = str(cfg.get("preflight_source_root", "")).strip()
    if not raw_source_root:
        raise ModelError("CONFIG_PREFLIGHT_SOURCE_ROOT_REQUIRED")
    source_root = Path(raw_source_root)
    source_phase = source_root / "PHASE_A"
    _ensure_clean_for_rebind(phase_out)
    _copy_frozen(source_phase, phase_out)

    preflight_path = package_root / "minotauro_v004_preflight.py"
    io_path = package_root / "minotauro_v004_io.py"
    core_path = package_root / "minotauro_v004_core.py"
    if sha256_file(preflight_path) != EXPECTED_PREFLIGHT_SHA256:
        raise ModelError("PREFLIGHT_REUSE_AUTHORIZED=NO PREFLIGHT_MODULE_HASH")
    if sha256_file(io_path) != EXPECTED_IO_SHA256:
        raise ModelError("PREFLIGHT_REUSE_AUTHORIZED=NO IO_MODULE_HASH")
    core_defs_hash = core_imported_definitions_hash(core_path)
    if core_defs_hash != EXPECTED_CORE_IMPORTED_DEFINITIONS_SHA256:
        raise ModelError("PREFLIGHT_REUSE_AUTHORIZED=NO CORE_IMPORTED_DEFINITIONS_HASH")

    status = read_json(phase_out / "PHASE_STATUS.json")
    if status.get("PHASE_DATA_STATUS") != "PASS" or int(status.get("sessions", -1)) != 250:
        raise ModelError("PREFLIGHT_REUSE_AUTHORIZED=NO PHASE_STATUS_NOT_PASS_250")
    failures = read_json(phase_out / "PREFLIGHT_FAILURES.json")
    if failures not in ([], None):
        raise ModelError("PREFLIGHT_REUSE_AUTHORIZED=NO PREFLIGHT_FAILURES_NONEMPTY")

    calendar_rows = []
    import csv
    with (phase_out / "SESSION_CALENDAR_PHASE_A.csv").open("r", encoding="utf-8-sig", newline="") as f:
        calendar_rows = list(csv.DictReader(f, delimiter=";"))
    if len(calendar_rows) != 250:
        raise ModelError(f"PREFLIGHT_REUSE_AUTHORIZED=NO CALENDAR_ROWS={len(calendar_rows)}")

    inventory_map = parse_source_inventory(phase_out / "SOURCE_INVENTORY.json")
    tick_paths = sorted({str(r["tick_file"]) for r in calendar_rows})
    if len(tick_paths) != 12:
        raise ModelError(f"PREFLIGHT_REUSE_AUTHORIZED=NO TICK_FILE_COUNT={len(tick_paths)}")
    tick_rows = []
    for raw_path in tick_paths:
        p = Path(raw_path)
        if not p.is_file():
            raise ModelError(f"PREFLIGHT_REUSE_AUTHORIZED=NO TICK_PATH_MISSING {raw_path}")
        inv = inventory_map.get(raw_path)
        if inv is None:
            raise ModelError(f"PREFLIGHT_REUSE_AUTHORIZED=NO TICK_PATH_NOT_IN_INVENTORY {raw_path}")
        actual = sha256_file(p)
        expected = str(inv.get("sha256", "")).upper()
        if actual != expected:
            raise ModelError(f"PREFLIGHT_REUSE_AUTHORIZED=NO TICK_HASH_MISMATCH file={raw_path} expected={expected} got={actual}")
        tick_rows.append({"path": raw_path, "size": int(p.stat().st_size), "sha256": actual})

    m1_root = Path(cfg["m1_root"])
    ind_path = Path(cfg["ind_d1"])
    d1 = load_d1(ind_path)
    with tempfile.TemporaryDirectory(prefix="minotauro_r23_rebind_") as td:
        tmp_expected = Path(td) / "EXPECTED_SESSIONS_PHASE_A.csv"
        rederived_rows = build_expected(m1_root, "A", tmp_expected)
        if not _same_bytes(tmp_expected, phase_out / "EXPECTED_SESSIONS_PHASE_A.csv"):
            raise ModelError("PREFLIGHT_REUSE_AUTHORIZED=NO EXPECTED_SESSIONS_NOT_BYTE_IDENTICAL")
        good, d1_failures = _validate_d1(rederived_rows, d1)
        if d1_failures or len(good) != 250:
            raise ModelError(f"PREFLIGHT_REUSE_AUTHORIZED=NO D1_REVALIDATION_FAILURES={len(d1_failures)}")

    extract_rows = []
    for er in sorted(rederived_rows, key=lambda x: x["session_date"]):
        prev = er["expected_previous_session_date"]
        bar = d1[prev]
        extract_rows.append({
            "session_date": er["session_date"],
            "expected_previous_session_date": prev,
            "open_micro": int(bar.open_micro),
            "high_micro": int(bar.high_micro),
            "low_micro": int(bar.low_micro),
            "close_micro": int(bar.close_micro),
        })
    if len(extract_rows) != 250:
        raise ModelError("PREFLIGHT_REUSE_AUTHORIZED=NO D1_EXTRACT_ROWS_NOT_250")
    d1_extract = phase_out / "D1_PREDECESSOR_EXTRACT_PHASE_A.csv"
    write_csv(d1_extract, ["session_date", "expected_previous_session_date", "open_micro", "high_micro", "low_micro", "close_micro"], extract_rows)

    m1_rows = []
    for p in _m1_files_used(m1_root):
        m1_rows.append({"path": str(p), "size": int(p.stat().st_size), "sha256": sha256_file(p)})

    binding = {
        "binding_version": "V005R1_R2_3",
        "runner_version": RUNNER_VERSION,
        "spec_sha256": SPEC_SHA256,
        "preflight_py_sha256": sha256_file(preflight_path),
        "io_py_sha256": sha256_file(io_path),
        "core_imported_definitions_sha256": core_defs_hash,
        "tick_files": tick_rows,
        "tick_manifest_sha256": hash_manifest_rows(tick_rows),
        "expected_sessions_rederived_sha256": sha256_file(phase_out / "EXPECTED_SESSIONS_PHASE_A.csv"),
        "d1_predecessor_extract_sha256": sha256_file(d1_extract),
        "ind_d1_path": str(ind_path),
        "ind_d1_sha256": sha256_file(ind_path),
        "m1_files": m1_rows,
        "m1_manifest_sha256": hash_manifest_rows(m1_rows),
        "preflight_status_sha256": sha256_file(phase_out / "PHASE_STATUS.json"),
        "preflight_failures_sha256": sha256_file(phase_out / "PREFLIGHT_FAILURES.json"),
        "session_calendar_sha256": sha256_file(phase_out / "SESSION_CALENDAR_PHASE_A.csv"),
        "expected_sessions_sha256": sha256_file(phase_out / "EXPECTED_SESSIONS_PHASE_A.csv"),
        "source_inventory_sha256": sha256_file(phase_out / "SOURCE_INVENTORY.json"),
        "cutoff_latency_diagnostics_sha256": sha256_file(phase_out / "CUTOFF_LATENCY_DIAGNOSTICS.csv"),
        "status": "PASS_REBOUND_UNSEALED",
    }
    binding["binding_content_sha256"] = canonical_json_hash(binding)
    binding_path = phase_out / "RUN_SOURCE_BINDING_A.json"
    write_json_atomic_canonical(binding_path, binding)
    receipt = {
        "PREFLIGHT_REUSE_AUTHORIZED": "YES",
        "HEAVY_55_3_GIB_PREFLIGHT_RERUN_REQUIRED": "NO",
        "LIGHTWEIGHT_HASH_AND_D1_REBIND": "PASS",
        "run_source_binding_sha256": sha256_file(binding_path),
        "tick_files_verified": len(tick_rows),
        "d1_extract_rows": len(extract_rows),
        "m1_files_hashed": len(m1_rows),
    }
    write_json_atomic_canonical(phase_out / "PREFLIGHT_REUSE_RECEIPT.json", receipt)
    return receipt


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ns = ap.parse_args()
    cfg = json.loads(Path(ns.config).read_text(encoding="utf-8"))
    package_root = Path(__file__).resolve().parent
    try:
        receipt = build_binding(cfg, package_root)
    except Exception as e:
        print(f"PREFLIGHT_REUSE_AUTHORIZED=NO")
        print(f"REBIND_BLOCKED={type(e).__name__}:{e}")
        raise
    print("PREFLIGHT_REUSE_AUTHORIZED=YES")
    print("HEAVY_55_3_GIB_PREFLIGHT_RERUN_REQUIRED=NO")
    print(f"TICK_FILES_VERIFIED={receipt['tick_files_verified']}")
    print(f"D1_EXTRACT_ROWS={receipt['d1_extract_rows']}")
    print(f"RUN_SOURCE_BINDING_SHA256={receipt['run_source_binding_sha256']}")


if __name__ == "__main__":
    main()
