from pathlib import Path
import json, tempfile, unittest
ROOT=Path(__file__).resolve().parent

class Full2026DeltaTests(unittest.TestCase):
    def test_coordinator_accepts_canonical_subset_and_dynamic_group_terminal(self):
        t=(ROOT/'r1r11_coordinator.py').read_text(encoding='utf-8')
        self.assertIn('NONCANONICAL_CELL_SUBSET_OR_ORDER',t)
        self.assertIn('if len(self.rg)==len(self.groups):',t)
        self.assertIn('effective_request = min(runtime.requested, max(2, len(self.groups)))',t)
        self.assertNotIn('PARALLEL_REQUIRES_CANONICAL_435_15',t)
    def test_full_2026_is_frozen_to_b_c_and_parent_freeze(self):
        t=(ROOT/'r1r11_full_2026.py').read_text(encoding='utf-8')
        self.assertIn("PHASE_ORDER=('B','C')",t)
        self.assertIn("PARENT_2025_SELECTION_FREEZE_MISSING",t)
        self.assertIn("PHASE_C_REQUIRES_PHASE_B_FINAL_PASS",t)
        self.assertIn("EVENT_LEDGER_2026_FROZEN_ONLY",t)
        self.assertIn("CONFIRMATION_GATE.json",t)
        self.assertIn("EVENT_LEDGER_SEP2026_FROZEN_ONLY",t)
    def test_full_2026_does_not_reselect(self):
        t=(ROOT/'r1r11_full_2026.py').read_text(encoding='utf-8')
        self.assertNotIn('select_2025(',t)
        self.assertIn("selected=f.get('selected_cell_id')",t)
        self.assertIn("frozen_cell_ids",t)
    def test_full_2026_resets_each_phase_via_distinct_checkpoint(self):
        t=(ROOT/'r1r11_full_2026.py').read_text(encoding='utf-8')
        self.assertIn("po=out/f'PHASE_{phase}'",t)
        self.assertIn("cp_path=po/'CHECKPOINT.json'",t)
        self.assertIn("base._load_checkpoint(cp_path,phase,cells",t)
    def test_memory_labels_run_b_c(self):
        t=(ROOT/'r1r11_resources.py').read_text(encoding='utf-8')
        self.assertIn("name.startswith('RUN_B_')",t)
        self.assertIn("name.startswith('RUN_C_')",t)

    def test_final_report_resume_is_not_refinalized(self):
        t=(ROOT/'r1r11_full_2026.py').read_text(encoding='utf-8')
        self.assertIn("PHASE_{phase}=FINAL_REPORT_REUSED_PASS",t)
        self.assertIn("p.name!=f'PHASE_{phase}_FINAL_REPORT.json'",t)

    def test_full_2026_preflight_source_is_explicit_cli_contract(self):
        t=(ROOT/'r1r11_full_2026.py').read_text(encoding='utf-8')
        self.assertIn("ap.add_argument('--preflight-source',required=True)",t)
        self.assertIn("preflight_source=Path(ns.preflight_source).resolve()",t)
        self.assertIn("'preflight_source_root':str(preflight_source)",t)
        self.assertIn("prepare_preflight(out,phase,preflight_source)",t)

    def test_full_2026_old_r1r4_preflight_path_is_not_authority(self):
        t=(ROOT/'r1r11_full_2026.py').read_text(encoding='utf-8')
        self.assertNotIn('MINOTAURO_PARAMETER_MARKET_DISCOVERY_V005R1_R1R4',t)

if __name__=='__main__': unittest.main(verbosity=2)
