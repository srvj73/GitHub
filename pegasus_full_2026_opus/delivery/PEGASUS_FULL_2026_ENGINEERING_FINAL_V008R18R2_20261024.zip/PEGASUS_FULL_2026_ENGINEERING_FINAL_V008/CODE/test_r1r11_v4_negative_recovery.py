"""Adversarial recovery states must fail before any evidence cleanup."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import unittest


class RecoveryNegative(unittest.TestCase):
    def test_missing_journal_and_advanced_checkpoint(self):
        from minotauro_v004_core import ModelError
        from minotauro_v004_runner import _write_checkpoint
        from r1r11_v4_transaction import recover
        root=Path(os.environ['R1R11_V4_NEGATIVE_ROOT']).resolve();root.mkdir(exist_ok=False)
        source=Path(os.environ['R1R11_V4_PRIOR_EVIDENCE'])
        clean_cp=json.loads((source/'clean/CHECKPOINT.json').read_text())
        for case in ('missing_journal','advanced_checkpoint','missing_checkpoint'):
            out=root/case;out.mkdir();scratch=out/'_scratch/123_456/evidence.txt'
            scratch.parent.mkdir(parents=True);scratch.write_text('PRESERVE')
            sessions=out/'sessions';sessions.mkdir()
            cp=dict(clean_cp)
            if case=='missing_journal':
                cp['completed']=[];cp['last_committed_session_date']=None
                shutil.copytree(source/'clean/sessions/1999-12-31',sessions/'1999-12-31')
            elif case=='missing_checkpoint':(sessions/'1999-12-31').mkdir()
            if case!='missing_checkpoint':_write_checkpoint(out/'CHECKPOINT.json',cp)
            before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()}
            with self.assertRaises(ModelError):recover(out)
            after={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()}
            self.assertEqual(before,after)

    def test_final_trade_scratch_matches_oracle(self):
        from minotauro_v004_core import valid_cells
        from r1r11_v4_stage import enrich
        import gzip
        source=Path(os.environ['R1R11_V4_PRIOR_EVIDENCE'])
        scratch=source/'final_trade_scratch/_scratch'
        paths=list(scratch.glob('*/*/0_0/trades.jsonl.gz'))
        self.assertEqual(len(paths),1)
        session=paths[0].parent.parent;date=session.name
        receipt=json.loads((source/'oracle_final_trades/sessions'/date/'session_receipt.json').read_text())
        rows=[]
        for p in session.glob('*/trades.jsonl.gz'):
            with gzip.open(p,'rt') as f:rows.extend(enrich(json.loads(l),receipt['cutoff_diagnostics_preflight']) for l in f)
        index={c.cell_id:i for i,c in enumerate(valid_cells())}
        rows.sort(key=lambda r:(r['entry_ordinal'],index[r['cell_id']]))
        with gzip.open(source/'oracle_final_trades/sessions'/date/'trades.jsonl.gz','rt') as f:expected=[json.loads(l) for l in f]
        self.assertEqual(rows,expected)
        self.assertTrue(rows)
        self.assertTrue(all(r.get('exit_reason') for r in rows))

    def test_v004r2r1_hash_case_normalization(self):
        from minotauro_v004_core import ModelError
        from r1r11_coordinator import Runtime
        known_lower='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'
        known_upper=known_lower.upper()
        self.assertEqual(hashlib.sha256(b'abc').hexdigest(),known_lower)

        root=Path(os.environ['R1R11_V4_NEGATIVE_ROOT']).resolve()/'hash_case_normalization'
        out=root/'roundtrip';pending=out/'pending';pending.mkdir(parents=True)
        names=('trades.jsonl.gz','events.jsonl.gz','equity.jsonl.gz',
               'equity_reconciliation.jsonl.gz','session_receipt.json')
        verified={}
        for name in names:
            (pending/name).write_bytes(b'abc')
            verified[name]={'sha256':known_lower,'bytes':3}
        self.assertTrue(all(v['sha256']!=v['sha256'].upper() for v in verified.values()))

        runtime=Runtime.__new__(Runtime)
        runtime.telemetry=out/'TELEMETRY'/'R1R11_TRANSPORT.jsonl'
        runtime.seal_precommit(out,'2000-01-01',pending,verified)
        seal_path=next((out/'TELEMETRY'/'SESSION_SEALS').rglob('2000-01-01.json'))
        seal=json.loads(seal_path.read_text(encoding='utf-8'))
        self.assertEqual(set(seal['files']),set(names))
        self.assertTrue(all(v==known_upper for v in seal['files'].values()))

        final=out/'sessions'/'2000-01-01';final.parent.mkdir()
        pending.rename(final)
        runtime.verify_committed(out,{'completed':['2000-01-01']})

        invalid=root/'invalid';invalid_pending=invalid/'pending';invalid_pending.mkdir(parents=True)
        invalid_verified={}
        for name in names:
            (invalid_pending/name).write_bytes(b'abc')
            invalid_verified[name]={'sha256':known_lower,'bytes':3}
        invalid_verified['events.jsonl.gz']['sha256']='g'*64
        invalid_runtime=Runtime.__new__(Runtime)
        invalid_runtime.telemetry=invalid/'TELEMETRY'/'R1R11_TRANSPORT.jsonl'
        with self.assertRaisesRegex(ModelError,'SESSION_SEAL_SHA256_INVALID events.jsonl.gz'):
            invalid_runtime.seal_precommit(invalid,'2000-01-01',invalid_pending,invalid_verified)

        seal['files']['events.jsonl.gz']=known_lower
        seal_path.write_text(json.dumps(seal,sort_keys=True,separators=(',',':'))+'\n',encoding='utf-8')
        with self.assertRaisesRegex(ModelError,'COMMITTED_SESSION_HASH_DRIFT'):
            runtime.verify_committed(out,{'completed':['2000-01-01']})

    def test_disabled_real_cli_does_not_read_config(self):
        root=Path(__file__).parent
        for mode in ('rebind-a','pilot-a','run-a'):
            p=subprocess.run([sys.executable,'-B',str(root/'minotauro_v004_runner.py'),mode,
                '--config','INTENTIONALLY_ABSENT_CONFIG.json'],capture_output=True,text=True)
            self.assertEqual(p.returncode,2)
            self.assertIn('V004R2_SYNTHETIC_ONLY',p.stderr)
            self.assertNotIn('FileNotFoundError',p.stderr)


if __name__=='__main__':unittest.main(verbosity=2)
