param([string]$Config = "$PSScriptRoot\config.json")
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Minotauro_Launcher_Common.ps1"
$TranscriptOwned = Start-MinotauroTranscript -Config $Config -LauncherName $MyInvocation.MyCommand.Name
try {
    & "$PSScriptRoot\RUN_SYNTHETIC_GATES.ps1" -Config $Config
    & "$PSScriptRoot\RUN_OPERATIONAL_GATES.ps1" -Config $Config
    $Python=Resolve-RealPython
    $ExitCode = Invoke-MinotauroPython -Python $Python -Arguments @("$PSScriptRoot\minotauro_v005r1_r23_gates.py",'source','--config',$Config)
    if ($ExitCode -ne 0) { throw "SOURCE_GATES_FAIL=$ExitCode" }
    $ExitCode = Invoke-MinotauroPython -Python $Python -Arguments @("$PSScriptRoot\minotauro_v005r1_r23_gates.py",'geometry-prepare','--config',$Config)
    if ($ExitCode -ne 0) { throw "GEOMETRY_PREPARE_FAIL=$ExitCode" }
    $ExitCode = Invoke-MinotauroPython -Python $Python -Arguments @("$PSScriptRoot\minotauro_v005r1_r23_gates.py",'status','--config',$Config)
    if ($ExitCode -ne 0) { throw "GATE_STATUS_FAIL=$ExitCode" }
    Write-Host ''
    Write-Host 'PREPILOT_NON_ECONOMIC_GATES=PASS_PENDING_MT5_GEOMETRY_VALIDATION'
    Write-Host 'NEXT=RUN_GEOMETRY_VALIDATE.ps1 then RUN_SEAL_PREPILOT_GATES.ps1'
    Write-Host 'PILOT_AUTHORIZED=NO'
    Write-Host 'RUN_A_AUTHORIZED=NO'
    Write-Host 'DATA_PROCESSING_AUTHORIZED=NO'
}
finally {
    Stop-MinotauroTranscriptSafe -Owned $TranscriptOwned
}
