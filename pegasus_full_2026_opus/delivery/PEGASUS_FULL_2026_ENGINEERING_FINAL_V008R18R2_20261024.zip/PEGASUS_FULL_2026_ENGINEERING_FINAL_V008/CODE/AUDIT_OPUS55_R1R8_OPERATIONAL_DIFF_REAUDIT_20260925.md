# REAUDITORIA MECÂNICA OPUS 5.5 — DELTA R1R7 → R1R8 (TRANSCRIPT E HIGIENE)

**Pacote:** `MINOTAURO_PARAMETER_MARKET_DISCOVERY_V005R1_R1R8_IMPLEMENTACAO_20260925.zip`
- SHA256 `714F6698…BDE4E43`; ZIP íntegro e `SHA256SUMS.txt` interno 42/42 OK.
- Parent R1R7 `E8E513CE…`, idêntico ao que auditei em `21_…`; o `AUDIT_…R1R7…` embutido é idêntico à minha entrega (`6F5AC74B…`).

**Regime:** mecânico, estático, restrito ao delta, independente, adversarial e fail-closed.
- Nenhum código escrito ou alterado; nenhum launcher ou teste executado; nenhum dado de mercado lido.
- A V002R2 e a economia aprovada não foram reabertas.

> **Ressalva de handoff.** Os arquivos `00_README_START_HERE.md`, `01_PROMPT_OPUS55_R1R8_OPERATIONAL_DIFF_REAUDIT.md` e `02_REQUIRED_VERDICT_FORMAT.md` não vieram no upload; o ZIP contém só o pacote de implementação.
> - **Formato:** usei o formato obrigatório da R1R7, trocando apenas os rótulos de versão: `R1R7` → `R1R8` na primeira linha e `R1R6_PARENT…` → `R1R7_PARENT…`.
> - **Escopo:** usei o `CHANGELOG_R1R8.md`, o `README_R1R8.md` e os findings m-1, m-2 e m-3 de `21_…`.
>
> Se o `02_…` da R1R8 tiver chaves diferentes, reemito o bloco sem refazer a análise.

```text
OPUS55_R1R8_OPERATIONAL_DIFF_REAUDIT=PASS
R1R7_PARENT_PRESERVATION=PASS
ECONOMIC_CAUSAL_RULE_CHANGED=NO
PYTHON_3_14_ENFORCEMENT=PASS
TRANSCRIPT_PERSISTENCE=PASS
TRANSCRIPT_OUT_ROOT_INDEPENDENT_OF_CWD=PASS
NESTED_TRANSCRIPT_REUSE=PASS
COMMON_HELPER_IDENTITY_COVERAGE=PASS
RUNNER_SHA256_RECALCULATED=PASS
GATE_SUITE_SHA256_RECALCULATED=PASS
FALSE_PASS_PATHS_REMAINING=0
CRITICAL_FINDINGS=0
MAJOR_FINDINGS=0
MINOR_FINDINGS=2
OWNER_PC_NON_ECONOMIC_GATES_AUTHORIZED=YES
PILOT_A_AUTHORIZED=NO
RUN_A_AUTHORIZED=NO
DATA_PROCESSING_AUTHORIZED=NO
```

```text
R1R7_m1_PYCACHE_REMOVED=YES
R1R7_m2_ABSOLUTE_OUT_ROOT_ENFORCED=YES
R1R7_m3_NATIVE_OUTPUT_ROUTED_TO_HOST=YES_STATIC
OWNER_SMOKE_REQUIRED_BEFORE_OTHER_GATES=YES
```

---

## 1. Integridade e delta

- [x] O `DIFF_R1R7_TO_R1R8.patch`, aplicado a uma cópia de rascunho da R1R7, reproduz byte a byte os 11 arquivos alterados:
  - `Minotauro_Launcher_Common.ps1`
  - 8 `RUN_*.ps1`
  - `contract.py` — só `RUNNER_VERSION`
  - `config.example.json` — só o `out_root`
- [x] `RUN_LIGHT_REBIND_A.ps1` é byte-idêntico à R1R7, como declarado.
- [x] Também byte-idênticos à R1R7:
  - Python: `core`, `io`, `preflight`, `metrics`, `runner`, `gates`, `binding`, `outputs`, `reference` e os três testes.
  - MQL5 e referências: fixture MQL5, R6 e SPECs.
- [x] Os 13 `__pycache__/*.cpython-313.pyc` foram removidos; não há `__pycache__` no ZIP nem no `SHA256SUMS`.
- [x] Identidades recalculadas conferem com o receipt e o changelog:
  - `runner_sha256` = `C55356DC…053497B6`
  - `gate_suite_sha256` = `CCF1362D…C2C41D5C`
- [x] O helper continua nos dois manifests, e nenhum `.py`, `.ps1` ou MQ5 fica descoberto.

---

## 2. Fechamento dos minors da R1R7

| R1R7 | Correção | Fonte (helper) | Resultado |
|---|---|---|---|
| m-1 `.pyc` 3.13 | removidos da distribuição | — | ✅ |
| m-2 `out_root` relativo | `IsPathRooted` ou `CONFIG_OUT_ROOT_NOT_ABSOLUTE` | l.98 | ✅ (ver O-2) |
| m-3 Python fora do transcript | stdout via `\| Out-Host`; stderr enviado a arquivo temporário e reproduzido com `Write-Host` após a saída | l.48-80 | ✅ estático |
| O-1 env residual | `TRANSCRIPT_ACTIVE_STATE_INVALID` se o caminho do transcript não existir | l.87-90 | ✅ parcial (ver O-1) |

**Por que o m-3 fecha estaticamente:** o smoke R1R7 do owner provou que, no Windows PowerShell 5.1, o transcript captura a saída do host (`LOG_HAS_POWERSHELL_PASS=TRUE`). A R1R8 faz toda a saída nativa do Python passar pelos mesmos canais de host (`Out-Host` e `Write-Host`). A confirmação em runtime é o smoke do §4.

---

## 3. Verificação do `Invoke-MinotauroPython` e dos launchers

- **Único ponto de chamada.** Nenhum `RUN_*.ps1` chama Python diretamente; as 12 chamadas passam pelo helper. `-3.14` é acrescentado de forma centralizada para qualquer `*\py.exe`.
- **Código de saída como autoridade.**
  - `$ExitCode` começa `$null` e só recebe `$LASTEXITCODE` depois da chamada nativa; se ficar nulo ⇒ `PYTHON_EXIT_CODE_MISSING`.
  - Se o processo não iniciar, o erro desvia o fluxo do bloco `try`. Assim, nunca se atribui o `$LASTEXITCODE=0` residual da verificação de versão.
  - A presença de stderr não decide nada, e todos os launchers testam o valor retornado.
- **`$ErrorActionPreference`.** Fica `Continue` apenas em volta da chamada nativa, dentro da função, e é restaurado no `finally`. No PS 5.1 isso evita que o stderr redirecionado dispare `NativeCommandError` terminante.
- **Retorno limpo.** A função devolve só `[int]$ExitCode`: `Out-Host`, `Write-Host` e `Remove-Item` não emitem nada para o pipeline.
- **Launchers aninhados.**
  - `RUN_PHASE` aninhado termina com o `$LASTEXITCODE` do próprio Python (0) ou com `exit 130`, preservando a checagem de `RUN_LIGHT_REBIND_A` e `RUN_GATE28_PILOT`.
  - `PRE_RUN_A` → `SYNTHETIC`/`OPERATIONAL` continua propagando `throw`.
  - O filho valida o caminho do transcript do pai (existente) e não o encerra.
- **Python 3.14.** A resolução é inalterada, e a checagem `Test-Path -PathType Leaf` do executável falha fechada.
- **Falso-pass:** nenhum caminho novo. O delta não toca gates, recibos ou runner.

---

## 4. Findings

**CRITICAL:** nenhum. **MAJOR:** nenhum.

**MINOR (2, cosméticos, nenhum abre falso-pass):**

| # | Finding | Fonte | Efeito / sugestão opcional |
|---|---|---|---|
| m-a | No Windows PowerShell 5.1, `2> $ErrPath` transforma o stderr nativo em `ErrorRecord`. A **primeira** linha de stderr sai decorada no arquivo e, por consequência, no transcript: `python.exe : …`, `At …Minotauro_Launcher_Common.ps1:68 char:…`, `CategoryInfo … RemoteException`, `FullyQualifiedErrorId : NativeCommandError`. Isso acontece **mesmo em execução PASS**, porque o unittest escreve toda a saída em stderr. Além disso, o stderr aparece depois do stdout. | helper l.68, l.73-75 | O conteúdo fica íntegro; é só aparência. Opcional: `2>&1` sob `Continue`, convertendo `ErrorRecord` em `.Exception.Message` antes do `Out-Host`, o que também preserva a ordem. |
| m-b | Com stdout em pipe, o Python 3.14 usa a codificação de localidade (cp1252) e o PS 5.1 decodifica com `[Console]::OutputEncoding` (OEM). Hoje a saída é ASCII e não é afetada; caracteres não-ASCII sairiam trocados no log, e fora do cp1252 causariam `UnicodeEncodeError`, com saída ≠ 0 (fail-closed). | helper l.68 | Opcional: definir `PYTHONIOENCODING`/`PYTHONUTF8` e `[Console]::OutputEncoding` UTF-8 no helper. |

**Observações (não contadas):**
- **O-1:** um estado de ambiente residual que aponte para um log antigo ainda existente passaria na nova checagem. Continua praticamente inalcançável, porque o `finally` sempre limpa o estado.
- **O-2:** o `IsPathRooted` do .NET Framework aceita `D:pasta` e `\pasta` (não totalmente qualificados). O exemplo usa `D:\…`.
- **O-3:** o stderr só chega ao transcript quando o Python termina. Se o próprio PowerShell morrer no meio, o stderr fica apenas no arquivo temporário em `%TEMP%`.

As pendências R1R6 (m-A, m-B, m-C, m-E, m-F) continuam como registradas em `20_…`.

---

## 5. O que o owner pode rodar no PC (somente não econômico)

0. **Preparação**
   - Extrair a R1R8 e executar `Unblock-File` nos `.ps1`, se o ZIP veio por download.
   - Criar `config.json` a partir do exemplo, com o `out_root` `…_R1R8` novo e absoluto.
1. **Smoke obrigatório.** Rodar só `RUN_SYNTHETIC_GATES.ps1` a partir de `C:\Users\silvi`. Depois, abrir o log mais recente em `<out_root>\LOGS\` e confirmar:
   - `TRANSCRIPT=…`
   - `Ran 44 tests in …` e `OK`, que vêm do stderr e são reproduzidos após a saída do Python
   - o JSON com `"SYNTHETIC_GATES": "PASS"`
   - `SYNTHETIC_GATE=PASS`

   Um bloco `python.exe : … / At … / CategoryInfo … / NativeCommandError` antes das linhas de teste é **esperado** no PS 5.1 (m-a) e **não** indica falha; a autoridade é o código de saída 0 e o `SYNTHETIC_GATE=PASS`.

   **Se qualquer um desses quatro itens faltar: parar e trazer o log.**
2. `RUN_LIGHT_REBIND_A.ps1`
3. `RUN_PRE_RUN_A_GATES.ps1`
4. **MetaEditor/MT5**
   - Copiar `GATES\GEOMETRY_INPUT_R23.csv` para `MQL5\Files\MINOTAURO_GEOMETRY_INPUT_R23.csv`.
   - Compilar e executar `Minotauro_Geometry_Parity_R23.mq5`.
5. `RUN_GEOMETRY_VALIDATE.ps1 -Mt5Output <…\MQL5\Files\MINOTAURO_GEOMETRY_MT5_R23.csv>`
6. `RUN_SEAL_PREPILOT_GATES.ps1` — **parar** em `PRE_PILOT_GATES=PASS_27_OF_27` e trazer `GATES\` e `LOGS\` para auditoria.

Os comportamentos fail-closed esperados continuam os mesmos do §7 de `20_…`.

**Nunca nesta etapa:**
- `RUN_GATE28_PILOT.ps1`
- `RUN_PHASE.ps1 -Command pilot-a` ou `-Command run-a`
- criação de `OWNER_PILOT_AUTHORIZATION.json` ou `OWNER_RUN_A_AUTHORIZATION.json`

---

## 6. Limites

- Nenhum launcher PowerShell foi executado. O comportamento do PS 5.1 descrito em m-a, m-b e O-2 é conhecido da plataforma, mas não foi observado neste ambiente.
- O log 54/54 do builder, em Python 3.13.5, foi tratado apenas como alegação.
- O escopo é restrito ao delta R1R7 → R1R8.
