#requires -Version 5.1
[CmdletBinding()] param(
 [Parameter(Mandatory=$true)][string]$EvidenceRoot,
 [ValidateSet('G1G3','G5G11')][string]$Phase='G1G3'
)
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'POWERSHELL_5_1_REQUIRED' }
. (Join-Path $PSScriptRoot 'Minotauro_Launcher_Common.ps1'); $Python=Resolve-RealPython
$Out=[IO.Path]::GetFullPath($EvidenceRoot)
Write-Host ('AMBIENTE=PowerShell R1R11_V005R1_OWNER_GATES PHASE=' + $Phase)
if ($Phase -eq 'G1G3') {
  & $Python -X utf8 -B (Join-Path $PSScriptRoot 'r1r11_owner_gates.py') --owner-output $Out --stop-after 3
} else {
  if (-not (Test-Path -LiteralPath (Join-Path $Out 'G4.json') -PathType Leaf)) { throw 'G4_RECEIPT_MISSING' }
  $G4=Get-Content -LiteralPath (Join-Path $Out 'G4.json') -Raw | ConvertFrom-Json
  if ([string]$G4.status -ne 'PASS') { throw 'G4_PASS_REQUIRED_BEFORE_G5_G11' }
  & $Python -X utf8 -B (Join-Path $PSScriptRoot 'r1r11_owner_gates.py') --owner-output $Out --stop-after 11
}
exit $LASTEXITCODE
