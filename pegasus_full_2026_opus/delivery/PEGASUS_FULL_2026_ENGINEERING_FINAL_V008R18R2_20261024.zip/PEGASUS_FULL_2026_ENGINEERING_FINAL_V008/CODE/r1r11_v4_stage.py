"""Four subordinate stage processes; no canonical publishing capability."""
import gzip
import hashlib
import json
import multiprocessing as mp
import os
from pathlib import Path
import signal
import sys
import time
import traceback
from minotauro_v004_core import ModelError, valid_cells
from minotauro_v004_runner import gzjson
from r1r11_transport import merged_stream, merge_key
from r1r11_v4_custody import (STREAMS, HashedReader, checked_rows, verify_file, seal_file,
                             sync_file, identity)


def restrict_writes(stage):
    stage=Path(stage).resolve()
    def audit(event,args):
        paths=[]
        if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
            p=Path(os.fsdecode(args[0])).resolve()
            mode=args[1] or '';flags=args[2]
            if str(p).casefold().startswith('d:\\base csv') or p.suffix.casefold()=='.csv':
                raise ModelError('HELPER_SOURCE_READ_FORBIDDEN')
            if any(c in mode for c in 'wax+') or flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC):paths=[p]
        elif event in ('os.mkdir','os.remove','os.rmdir'):
            paths=[Path(os.fsdecode(args[0])).resolve()]
        elif event in ('os.rename','os.replace'):
            paths=[Path(os.fsdecode(p)).resolve() for p in args[:2]]
        if any(p!=stage and not p.is_relative_to(stage) for p in paths):
            raise ModelError('HELPER_WRITE_OUTSIDE_STAGE')
    sys.addaudithook(audit)


def enrich(row,metadata):
    if row.get('exit_reason')=='CUTOFF':
        direction=row.get('direction')
        if direction not in ('BUY','SELL'):
            raise ModelError('C1_CUTOFF_DIRECTION_INVALID')
        side='long' if direction=='BUY' else 'short'
        kind=str(metadata.get(f'r3_{side}_x_kind',''))
        if kind not in ('L0','L1'):
            raise ModelError('R3_CUTOFF_KIND_INVALID')
        expected=int(metadata[f'r3_{side}_x_time_msc'])
        if int(row.get('cutoff_fill_msc',-1))!=expected:
            raise ModelError('R3_CUTOFF_PREFLIGHT_REPLAY_MISMATCH')
        row['first_cutoff_bid_msc']=int(metadata.get('first_cutoff_bid_msc') or 0)
        row['first_cutoff_ask_msc']=int(metadata.get('first_cutoff_ask_msc') or 0)
    return row


class OrderProof:
    def __init__(self,kind,cells):
        self.kind=kind;self.index={c.cell_id:i for i,c in enumerate(cells)}
        groups=sorted({(c.p_idx,c.t_idx) for c in cells})
        self.ranks={c.cell_id:groups.index((c.p_idx,c.t_idx)) for c in cells}
        self.last=None;self.first=None;self.count=0;self.digest=hashlib.sha256()
    def add(self,row,key=None):
        if key is None:key=merge_key(self.kind,row,self.index,self.ranks)
        if self.last is not None and (key<self.last or self.kind in ('trades','equity_reconciliation') and key==self.last):
            raise ModelError('STAGE_ORDER_REGRESSION_OR_DUPLICATE')
        if self.kind=='events':
            ids=[self.index[c] for c in row['cell_ids']]
            if ids!=sorted(set(ids)):raise ModelError('STAGE_EVENT_CELL_ORDER')
        if self.first is None:self.first=key
        self.last=key;self.count+=1
        self.digest.update((json.dumps(key,separators=(',',':'))+'\n').encode())
    def result(self):
        return {'rows':self.count,'first':self.first,'last':self.last,'order_sha256':self.digest.hexdigest()}


def validate_stage(manifest,cells):
    """Post-helper V004 §17.4.3 proof in one physical file pass."""
    file_manifest=manifest['file'];path=Path(file_manifest['path'])
    if identity(path)!=file_manifest['identity']:
        raise ModelError('STAGE_FILE_IDENTITY_BEFORE')
    proof=OrderProof(manifest['stream'],cells);raw=HashedReader(path)
    try:
        import io
        with io.BufferedReader(raw) as b:
            with gzip.GzipFile(fileobj=b,mode='rb') as gz:
                for line in gz:
                    if not line.endswith(b'\n'):raise ModelError('STAGE_FRAME')
                    proof.add(json.loads(line))
            while b.read(1024*1024):pass
        if raw.hash.hexdigest()!=file_manifest['sha256']:
            raise ModelError('STAGE_CONSUMED_SHA256')
        if identity(path)!=file_manifest['identity']:
            raise ModelError('STAGE_FILE_IDENTITY_AFTER')
    finally:
        raw.close()
    # JSON roundtrip normalizes tuple/list for persisted and in-memory manifests.
    if json.dumps(proof.result(),sort_keys=True)!=json.dumps(manifest['proof'],sort_keys=True):
        raise ModelError('STAGE_ORDER_PROOF')


def helper_main(conn,kind,manifests,stage,metadata,binding,fault=None):
    signal.signal(signal.SIGINT,signal.SIG_IGN)
    parent=mp.parent_process()
    if parent is None or not parent.is_alive():return
    try:
        stage=Path(stage).resolve();restrict_writes(stage)
        if kind not in STREAMS:raise ModelError('HELPER_STREAM')
        if fault=='hold_for_signal':
            # Explicit lifecycle fault only; no benchmark uses this command.
            (stage/'HOLD_FOR_SIGNAL.marker').write_text(str(os.getpid()))
            while parent.is_alive():
                if conn.poll(.2):
                    if conn.recv()['type']=='STOP':return
                    raise ModelError('FAULT_HOLD_UNEXPECTED_COMMAND')
            return
        cells=valid_cells();proof=OrderProof(kind,cells)
        by_path={m['scratch']['path']:m for m in manifests}
        if len(by_path)!=15:raise ModelError('HELPER_GROUPS')
        for m in manifests:
            if any(m['binding'][k]!=binding[k] for k in ('session','run_instance')):
                raise ModelError('HELPER_BINDING')
        def read(path,stream,index,ranks):
            return checked_rows(by_path[path],stream,index,ranks)
        def rows():
            for i,(key,row) in enumerate(merged_stream(list(by_path),kind,cells,read_fn=read,yield_key=True)):
                if not parent.is_alive():raise ModelError('HELPER_PARENT_DEATH')
                if fault=='during_merge' and i==1:raise ModelError('FAULT_DURING_MERGE')
                if fault=='helper_death' and i==1:os._exit(72)
                if kind=='trades':row=enrich(row,metadata)
                proof.add(row,key);yield row
        if fault=='canonical_write':
            (stage.parent.parent.parent.parent/'sessions'/'FORBIDDEN').write_text('blocked')
        partial=stage/(kind+'.jsonl.gz.partial');sealed=stage/(kind+'.jsonl.gz.sealed')
        if partial.exists() or sealed.exists():raise ModelError('STAGE_EXISTS')
        gzjson(partial,rows());sync_file(partial);os.rename(partial,sealed)
        manifest={'stream':kind,'binding':binding,'file':seal_file(sealed),'proof':proof.result(),
                  'consumed':[{'scratch':m['scratch']['sha256'],'sidecar':m['sidecar']['sha256']} for m in manifests]}
        conn.send({'type':'STAGE_SEALED','pid':os.getpid(),'manifest':manifest})
        if fault=='helper_after_seal':os._exit(73)
        while parent.is_alive():
            if conn.poll(.2):
                command=conn.recv()
                if command['type'] in ('EXIT_ACK','STOP'):return
                raise ModelError('HELPER_SEALED_WAIT_COMMAND')
    except (EOFError,BrokenPipeError):pass
    except BaseException:
        try:conn.send({'type':'ERROR','pid':os.getpid(),'traceback':traceback.format_exc()})
        except (EOFError,OSError):pass
        raise
    finally:conn.close()


def stage_all(active,metadata):
    runtime=active.runtime;stage=active.scratch/'_canonical_stage'
    stage.mkdir(exist_ok=False);children=[];conns=[]
    try:
        context=mp.get_context('spawn')
        runtime.memory.child_role='stage_helper'
        for kind in STREAMS:
            parent,child=context.Pipe()
            fault=runtime.fault_at('stage') if kind=='events' else None
            if runtime.fault_at('during_merge') and kind=='events':fault='during_merge'
            binding={'session':active.session,'run_instance':runtime.instance,'stream':kind}
            p=context.Process(target=helper_main,args=(child,kind,[g[kind] for g in active.final_groups],
                str(stage),metadata,binding,fault))
            p.start();child.close();children.append(p);conns.append(parent)
            runtime.memory.pids=[p.pid for p in children]
            reg={'pid':p.pid,'parent':os.getpid(),'role':'stage_helper',**binding}
            (stage/(kind+'.helper.json')).write_text(json.dumps(reg),encoding='utf-8')
            runtime.log('PROCESS_REGISTER',**reg)
        runtime.memory.boundary('HELPERS_STARTED',active.session)
        deadline=time.monotonic()+runtime.timeout;waiting=set(range(4));outputs={}
        while waiting:
            for i in list(waiting):
                if conns[i].poll(.01):
                    reply=conns[i].recv()
                    if reply.get('type')!='STAGE_SEALED' or reply.get('pid')!=children[i].pid:
                        raise ModelError('HELPER_REPLY '+json.dumps(reply))
                    m=reply['manifest'];kind=STREAMS[i]
                    expected_binding={'session':active.session,'run_instance':runtime.instance,'stream':kind}
                    expected_consumed=[{'scratch':g[kind]['scratch']['sha256'],
                                        'sidecar':g[kind]['sidecar']['sha256']} for g in active.final_groups]
                    if (m['stream']!=kind or m['binding']!=expected_binding or
                        Path(m['file']['path'])!=stage/(kind+'.jsonl.gz.sealed') or
                        m['consumed']!=expected_consumed):
                        raise ModelError('STAGE_MANIFEST_BINDING')
                    outputs[kind]=m;waiting.remove(i)
                elif not children[i].is_alive():raise ModelError('HELPER_DEATH')
            if time.monotonic()>deadline:raise ModelError('HELPER_TIMEOUT')
        if runtime.fault_at('staging_sigint'):raise KeyboardInterrupt('FAULT_STAGING_SIGINT')
        if runtime.fault_at('helper_before_probe'):
            children[0].terminate();children[0].join(5)
        runtime.memory.boundary('HELPERS_SEALED_WAIT',active.session)
        for c in conns:c.send({'type':'EXIT_ACK'})
        for p in children:
            p.join(runtime.timeout)
            if p.is_alive() or p.exitcode!=0:raise ModelError('HELPER_EXIT_UNCONFIRMED')
        runtime.memory.pids=[]
        if runtime.fault_at('stage_sealed'):
            from r1r11_v4_custody import inject_file_fault
            inject_file_fault(outputs['events']['file'],runtime.fault_at('stage_sealed'))
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=4,thread_name_prefix='v004r2-stage-verify') as pool:
            futures=[pool.submit(validate_stage,outputs[k],active.cells) for k in STREAMS]
            for future in futures:future.result()
        def verify_stream(kind):
            for g in active.final_groups:
                for field in ('scratch','sidecar'):verify_file(g[kind][field])
        with ThreadPoolExecutor(max_workers=4,thread_name_prefix='v004r2-scratch-reverify') as pool:
            futures=[pool.submit(verify_stream,k) for k in STREAMS]
            for future in futures:future.result()
        runtime.log('STAGE_VALIDATED',session=active.session,manifests=outputs)
        return outputs
    finally:
        for c in conns:
            try:c.send({'type':'STOP'})
            except (EOFError,OSError):pass
        for p in children:
            p.join(2)
            if p.is_alive():p.terminate();p.join(5)
            if p.is_alive():raise ModelError('HELPER_WONT_TERMINATE')
        for c in conns:c.close()
        runtime.memory.pids=[]
        runtime.memory.child_role='economic_worker'
