from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import argparse, hashlib, json, os, tempfile, time

from minotauro_v004_core import ModelError
from minotauro_v004_io import (
    cutoff_msc_for_session, find_tick_file_for_session, iter_tick_file, load_d1,
    sha256_file, write_csv, write_json_atomic,
)
from minotauro_v004_preflight import (
    PHASES, _progress_line, _validate_d1, _write_cutoff_latency_diagnostics, build_expected,
)
from ff_cutoff_r3_runtime import (
    calendar_fields, invalid_side, make_sidecar, modeled_l1_price,
)

PACKAGE=Path(__file__).resolve().parent
SCHEMA="MINOTAURO_PREFLIGHT_2026_R3_RESUMABLE_V001"
PHASES_ALLOWED=("B","C")


def _hash_obj(obj)->str:
    raw=json.dumps(obj,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest().upper()


def _atomic_csv(path:Path, fields:list[str], rows:list[dict]):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    write_csv(tmp,fields,rows)
    os.replace(tmp,path)


def _cleanup_owned_temps(phase_out:Path):
    for p in phase_out.glob("*.tmp"):
        try:p.unlink()
        except FileNotFoundError:pass


def _source_meta(path:Path)->dict:
    st=path.stat()
    return {"path":str(path.resolve()),"size":int(st.st_size),"mtime_ns":int(st.st_mtime_ns)}


def _load_receipt(path:Path, expected_sha:str|None=None)->dict:
    if not path.is_file(): raise ModelError("PREFLIGHT_RECEIPT_MISSING "+str(path))
    if expected_sha and sha256_file(path)!=expected_sha:
        raise ModelError("PREFLIGHT_RECEIPT_SHA_MISMATCH "+str(path))
    obj=json.loads(path.read_text(encoding="utf-8"))
    if obj.get("schema")!="MINOTAURO_PREFLIGHT_MONTH_RECEIPT_R3_V001":
        raise ModelError("PREFLIGHT_RECEIPT_SCHEMA "+str(path))
    return obj


def _month_receipt_path(phase_out:Path,tick_path:Path)->Path:
    return phase_out/"MONTH_RECEIPTS"/(tick_path.stem+".json")


def _build_context(cfg:dict,phase:str,phase_out:Path):
    if phase not in PHASES_ALLOWED: raise ModelError("PREFLIGHT_PHASE_INVALID")
    phase_out.mkdir(parents=True,exist_ok=True)
    _cleanup_owned_temps(phase_out)

    expected=phase_out/f"EXPECTED_SESSIONS_PHASE_{phase}.csv"
    with tempfile.TemporaryDirectory(prefix=f"minotauro_expected_{phase}_") as td:
        temp_expected=Path(td)/expected.name
        rows=build_expected(Path(cfg["m1_root"]),phase,temp_expected)
        if expected.exists():
            if expected.read_bytes()!=temp_expected.read_bytes():
                raise ModelError(f"PHASE_{phase}_EXPECTED_SESSIONS_DRIFT")
        else:
            os.replace(temp_expected,expected)

    d1_path=Path(cfg["ind_d1"])
    d1=load_d1(d1_path)
    good_rows,d1_failures=_validate_d1(rows,d1)
    if d1_failures or len(good_rows)!=len(rows):
        write_json_atomic(phase_out/"PREFLIGHT_FAILURES.json",d1_failures)
        write_json_atomic(phase_out/"PHASE_STATUS.json",{
            "phase":phase,"PHASE_DATA_STATUS":"BLOCKED","failure_count":len(d1_failures),
            "reason":"D1_VALIDATION",
        })
        raise ModelError(f"PHASE_{phase}_D1_VALIDATION_FAILURES={len(d1_failures)}")

    by_file=defaultdict(list)
    for er in good_rows:
        tp=find_tick_file_for_session(Path(cfg["ticks_root"]),er["session_date"])
        by_file[tp].append(er)
    sorted_files=sorted(by_file.items(),key=lambda kv:str(kv[0]))
    metas=[_source_meta(tp) for tp,_ in sorted_files]
    fingerprint_body={
        "schema":SCHEMA,"phase":phase,"range":list(PHASES[phase]),
        "ticks_root":str(Path(cfg["ticks_root"]).resolve()),
        "m1_root":str(Path(cfg["m1_root"]).resolve()),
        "ind_d1":str(d1_path.resolve()),
        "ind_d1_sha256":sha256_file(d1_path),
        "expected_sessions_sha256":sha256_file(expected),
        "source_files":metas,
        "driver_sha256":sha256_file(Path(__file__).resolve()),
        "preflight_py_sha256":sha256_file(PACKAGE/"minotauro_v004_preflight.py"),
        "io_py_sha256":sha256_file(PACKAGE/"minotauro_v004_io.py"),
    }
    return rows,d1,sorted_files,fingerprint_body,_hash_obj(fingerprint_body)


def _init_or_resume_checkpoint(phase_out:Path,phase:str,fingerprint_body:dict,fingerprint:str):
    cp_path=phase_out/"PREFLIGHT_CHECKPOINT.json"
    if cp_path.is_file():
        cp=json.loads(cp_path.read_text(encoding="utf-8"))
        if cp.get("schema")!="MINOTAURO_PREFLIGHT_CHECKPOINT_R3_V001" or cp.get("phase")!=phase:
            raise ModelError("PREFLIGHT_CHECKPOINT_SCHEMA_OR_PHASE")
        if cp.get("fingerprint")!=fingerprint:
            raise ModelError("PREFLIGHT_INPUT_FINGERPRINT_CHANGED")
        if _hash_obj(cp.get("fingerprint_body"))!=fingerprint:
            raise ModelError("PREFLIGHT_CHECKPOINT_FINGERPRINT_BODY_INVALID")
        completed=list(cp.get("completed_files",[]))
        receipt_sha=dict(cp.get("receipt_sha256",{}))
        for raw in completed:
            rp=_month_receipt_path(phase_out,Path(raw))
            rec=_load_receipt(rp,receipt_sha.get(raw))
            if rec.get("status")!="PASS_MONTH" or rec.get("source")!=_source_meta(Path(raw)):
                raise ModelError("PREFLIGHT_COMMITTED_RECEIPT_DRIFT "+raw)
        return cp_path,cp
    cp={
        "schema":"MINOTAURO_PREFLIGHT_CHECKPOINT_R3_V001","phase":phase,
        "fingerprint":fingerprint,"fingerprint_body":fingerprint_body,
        "completed_files":[],"receipt_sha256":{},"status":"RUNNING",
    }
    write_json_atomic(cp_path,cp)
    return cp_path,cp


def _scan_month(phase:str,tp:Path,ers:list[dict],overall_committed_bytes:int,total_bytes:int,
                completed_sessions:int,total_sessions:int,started:float)->dict:
    sessions={er["session_date"] for er in ers}
    file_size=tp.stat().st_size
    state={s:{
        "found":False,"last_msc":None,"bid":0,"ask":0,"bid_msc":0,"ask_msc":0,
        "saw_cutoff_record":False,"first_cutoff_bid_msc":None,"first_cutoff_ask_msc":None,
        "pre_latch_anchor_bid":None,"pre_latch_anchor_ask":None,"pre_latch_anchor_msc":None,
        "e0_long":None,"e0_short":None,"e1_long":None,"e1_short":None,
    } for s in sessions}
    cutoffs={s:cutoff_msc_for_session(s) for s in sessions}
    h=hashlib.sha256()
    failures=[]
    print(f"PREFLIGHT_MONTH_START phase={phase} file={tp.name} size_gib={file_size/1024**3:.3f} sessions={len(sessions)}",flush=True)

    def progress_cb(file_bytes,raw_rows,file_size_cb,is_final):
        _progress_line("PREFLIGHT",phase,tp.name,overall_committed_bytes+file_bytes,total_bytes,
                       file_bytes,file_size_cb,raw_rows,completed_sessions,total_sessions,started)

    try:
        for rec in iter_tick_file(tp,include_sessions=sessions,hasher=h,progress_cb=progress_cb):
            st=state[rec.session];st["found"]=True
            if st["last_msc"] is not None and rec.time_msc<st["last_msc"]:
                raise ModelError(f"TIME_MSC_REGRESSION session={rec.session} ordinal={rec.ordinal}")
            st["last_msc"]=rec.time_msc
            cutoff=cutoffs[rec.session]
            if rec.time_msc>=cutoff: st["saw_cutoff_record"]=True
            if rec.bid_micro>0:
                st["bid"]=rec.bid_micro;st["bid_msc"]=rec.time_msc
                if rec.time_msc>=cutoff and st["first_cutoff_bid_msc"] is None:st["first_cutoff_bid_msc"]=rec.time_msc
            if rec.ask_micro>0:
                st["ask"]=rec.ask_micro;st["ask_msc"]=rec.time_msc
                if rec.time_msc>=cutoff and st["first_cutoff_ask_msc"] is None:st["first_cutoff_ask_msc"]=rec.time_msc
            if rec.time_msc<cutoff:
                if st["bid"]>0 and st["ask"]>0 and not (st["ask"]<st["bid"]):
                    st["pre_latch_anchor_bid"]=st["bid"];st["pre_latch_anchor_ask"]=st["ask"];st["pre_latch_anchor_msc"]=rec.time_msc
                continue

            crossed = st["bid"]>0 and st["ask"]>0 and st["ask"]<st["bid"]
            if st["e0_long"] is None and not crossed and st["bid"]>0 and st["bid_msc"]>=cutoff and st["bid_msc"]<=rec.time_msc:
                st["e0_long"]={"kind":"L0","ordinal":rec.ordinal,"time_msc":rec.time_msc,"price":st["bid"],"last":rec.last_micro}
            if st["e0_short"] is None and not crossed and st["ask"]>0 and st["ask_msc"]>=cutoff and st["ask_msc"]<=rec.time_msc:
                st["e0_short"]={"kind":"L0","ordinal":rec.ordinal,"time_msc":rec.time_msc,"price":st["ask"],"last":rec.last_micro}

            if rec.business:
                if st["e1_long"] is None and invalid_side("LONG",st["bid"],st["ask"]):
                    st["e1_long"]={"kind":"L1","ordinal":rec.ordinal,"time_msc":rec.time_msc,
                                   "price":modeled_l1_price("LONG",rec.last_micro),"last":rec.last_micro}
                if st["e1_short"] is None and invalid_side("SHORT",st["bid"],st["ask"]):
                    st["e1_short"]={"kind":"L1","ordinal":rec.ordinal,"time_msc":rec.time_msc,
                                    "price":modeled_l1_price("SHORT",rec.last_micro),"last":rec.last_micro}
    except KeyboardInterrupt:
        raise
    except Exception as e:
        for sess in sorted(sessions):
            failures.append({"session":sess,"reason":"SOURCE_OR_TIME_FAILURE","detail":str(e)})

    def choose_x(sess,side,st):
        e0=st["e0_"+side.lower()];e1=st["e1_"+side.lower()]
        if e0 is None and e1 is None:
            failures.append({"session":sess,"reason":"R3_CUTOFF_CAUSAL_EVIDENCE_UNAVAILABLE","detail":"side="+side})
            return None
        if e0 is not None and e1 is not None and int(e0["ordinal"])==int(e1["ordinal"]):
            failures.append({"session":sess,"reason":"BLOCKED_ENGINE_INVARIANT","detail":"side="+side+" same POST_RECORD ordinal"})
            return None
        if e0 is None: return e1
        if e1 is None: return e0
        return e0 if int(e0["ordinal"])<int(e1["ordinal"]) else e1

    er_by_session={er["session_date"]:er for er in ers}
    cal=[];diag={}
    if not failures:
        for sess in sorted(sessions):
            st=state[sess];prev=er_by_session[sess]["expected_previous_session_date"];cutoff=cutoffs[sess]
            if not st["found"]:
                failures.append({"session":sess,"reason":"SESSION_MISSING_PHYSICALLY","detail":str(tp)});continue
            if not st["saw_cutoff_record"]:
                failures.append({"session":sess,"reason":"CUTOFF_LATCH_UNAVAILABLE","detail":str(tp)});continue
            xl=choose_x(sess,"LONG",st); xs=choose_x(sess,"SHORT",st)
            if xl is None or xs is None:
                continue
            long_event={"x_kind":xl["kind"],"x_ordinal":xl["ordinal"],"x_time_msc":xl["time_msc"],"x_price_micro":xl["price"],
                        "x_last_micro":xl["last"] if xl["kind"]=="L1" else xl.get("last"),"modeled":xl["kind"]=="L1",
                        "side_uncertainty_ticks":1 if xl["kind"]=="L1" else 0}
            short_event={"x_kind":xs["kind"],"x_ordinal":xs["ordinal"],"x_time_msc":xs["time_msc"],"x_price_micro":xs["price"],
                         "x_last_micro":xs["last"] if xs["kind"]=="L1" else xs.get("last"),"modeled":xs["kind"]=="L1",
                         "side_uncertainty_ticks":1 if xs["kind"]=="L1" else 0}
            sc=make_sidecar(sess,cutoff,long_event,short_event)
            e0l=st["e0_long"];e0s=st["e0_short"]
            d={
                "first_cutoff_bid_msc":st["first_cutoff_bid_msc"],"first_cutoff_ask_msc":st["first_cutoff_ask_msc"],
                "cutoff_long_fill_msc":e0l["time_msc"] if e0l else None,"cutoff_short_fill_msc":e0s["time_msc"] if e0s else None,
                "cutoff_long_latency_ms":(e0l["time_msc"]-cutoff) if e0l else None,
                "cutoff_short_latency_ms":(e0s["time_msc"]-cutoff) if e0s else None,
                "r3_long_x_kind":xl["kind"],"r3_short_x_kind":xs["kind"],
                "r3_long_x_latency_ms":xl["time_msc"]-cutoff,"r3_short_x_latency_ms":xs["time_msc"]-cutoff,
            }
            diag[sess]=d
            row={
                "session_date":sess,"expected_previous_session_date":prev,"tick_file":str(tp),"cutoff_msc":cutoff,
                "first_cutoff_bid_msc":st["first_cutoff_bid_msc"],"first_cutoff_ask_msc":st["first_cutoff_ask_msc"],
                "cutoff_long_fill_msc":e0l["time_msc"] if e0l else None,"cutoff_short_fill_msc":e0s["time_msc"] if e0s else None,
                "cutoff_long_latency_ms":d["cutoff_long_latency_ms"],"cutoff_short_latency_ms":d["cutoff_short_latency_ms"],
                "status":"COMMON_ELIGIBLE_R3",
                "r3_pre_latch_anchor_bid_micro":st["pre_latch_anchor_bid"],
                "r3_pre_latch_anchor_ask_micro":st["pre_latch_anchor_ask"],
                "r3_pre_latch_anchor_msc":st["pre_latch_anchor_msc"],
                "r3_pre_latch_anchor_spread_ticks":((st["pre_latch_anchor_ask"]-st["pre_latch_anchor_bid"])//5) if st["pre_latch_anchor_bid"] is not None and st["pre_latch_anchor_ask"] is not None else None,
            }
            row.update(calendar_fields(sc));cal.append(row)
    return {
        "schema":"MINOTAURO_PREFLIGHT_MONTH_RECEIPT_R3_V001",
        "phase":phase,"status":"PASS_MONTH" if not failures else "BLOCKED_MONTH",
        "source":_source_meta(tp),"source_sha256":h.hexdigest().upper() if not failures else "UNAVAILABLE_DUE_TO_SCAN_FAILURE",
        "calendar_rows":cal,"diagnostics":diag,"failures":failures,
    }


def _aggregate_phase(phase_out:Path,phase:str,rows:list[dict],sorted_files:list[tuple[Path,list[dict]]],cp:dict):
    inventories=[];cal=[];diag={};failures=[]
    for tp,_ in sorted_files:
        raw=str(tp);rp=_month_receipt_path(phase_out,tp)
        rec=_load_receipt(rp,cp["receipt_sha256"].get(raw))
        inventories.append({"file":raw,"size":int(rec["source"]["size"]),"sha256":rec["source_sha256"]})
        cal.extend(rec.get("calendar_rows",[]));diag.update(rec.get("diagnostics",{}));failures.extend(rec.get("failures",[]))
    write_json_atomic(phase_out/"SOURCE_INVENTORY.json",{
        "phase":phase,"files":inventories,"monthly_tick_passes":len(sorted_files),
        "tick_scan_policy":"ONE_PHYSICAL_PASS_PER_MONTH_RESUMABLE",
    })
    write_json_atomic(phase_out/"PREFLIGHT_FAILURES.json",sorted(failures,key=lambda x:(x["session"],x["reason"])))
    with tempfile.TemporaryDirectory(prefix=f"minotauro_cutoff_{phase}_") as td:
        td=Path(td);_write_cutoff_latency_diagnostics(td,rows,diag,failures)
        os.replace(td/"CUTOFF_LATENCY_DIAGNOSTICS.csv",phase_out/"CUTOFF_LATENCY_DIAGNOSTICS.csv")
    if failures:
        write_json_atomic(phase_out/"PHASE_STATUS.json",{"phase":phase,"PHASE_DATA_STATUS":"BLOCKED","failure_count":len(failures)})
        raise ModelError(f"PHASE_DATA_STATUS=BLOCKED failures={len(failures)}")
    cal=sorted(cal,key=lambda x:x["session_date"])
    if len(cal)!=len(rows): raise ModelError(f"CALENDAR_CARDINALITY_MISMATCH expected={len(rows)} got={len(cal)}")
    # G6 is a qualified invariant, not a date-specific economic override.  Phase B must reproduce it byte-for-byte after native micro scaling.
    if phase=="B":
        g6=[r for r in cal if r["session_date"]=="2026-01-05"]
        if len(g6)!=1:
            raise ModelError("G6_INVARIANT_SESSION_CARDINALITY")
        r=g6[0];scale=1_000_000
        expected={
            "r3_long_x_kind":"L1","r3_short_x_kind":"L1",
            "r3_long_x_ordinal":2470960,"r3_short_x_ordinal":2470960,
            "r3_long_x_time_msc":1767646980039,"r3_short_x_time_msc":1767646980039,
            "r3_long_x_price_micro":164380*scale,"r3_short_x_price_micro":164390*scale,
            "r3_long_x_last_micro":164385*scale,"r3_short_x_last_micro":164385*scale,
        }
        for k,v in expected.items():
            if r.get(k)!=v:
                raise ModelError(f"G6_INVARIANT_MISMATCH field={k} expected={v} got={r.get(k)}")
        jan=[x for x in inventories if Path(x["file"]).name=="WIN@N_ticks_2026_01.csv"]
        if len(jan)!=1 or jan[0]["sha256"]!="E0E29159E8EA54996857A0FAC077F3308D4250A03FE8FBEFECC2A9F6B000B7A7":
            raise ModelError("G6_SOURCE_IDENTITY_MISMATCH")
    _atomic_csv(phase_out/f"SESSION_CALENDAR_PHASE_{phase}.csv",list(cal[0].keys()),cal)
    sidecar_path=phase_out/f"R3_CUTOFF_SIDECARS_PHASE_{phase}.jsonl"
    tmp=sidecar_path.with_suffix(sidecar_path.suffix+".tmp")
    from ff_cutoff_r3_runtime import sidecar_from_calendar_row
    with tmp.open("w",encoding="utf-8",newline="\n") as f:
        for row in cal:
            sc=sidecar_from_calendar_row(row)
            f.write(json.dumps(sc,ensure_ascii=False,sort_keys=True,separators=(",",":"))+"\n")
    os.replace(tmp,sidecar_path)
    write_json_atomic(phase_out/"PHASE_STATUS.json",{
        "phase":phase,"PHASE_DATA_STATUS":"PASS","sessions":len(cal),"monthly_tick_passes":len(sorted_files),
    })


def preflight_phase_resumable(cfg:dict,phase:str):
    phase_out=Path(cfg["out_root"])/f"PHASE_{phase}"
    rows,d1,sorted_files,fingerprint_body,fingerprint=_build_context(cfg,phase,phase_out)
    cp_path,cp=_init_or_resume_checkpoint(phase_out,phase,fingerprint_body,fingerprint)
    source_paths=[str(tp) for tp,_ in sorted_files]
    if any(raw not in source_paths for raw in cp.get("completed_files",[])):
        raise ModelError("PREFLIGHT_CHECKPOINT_UNKNOWN_COMPLETED_FILE")
    total_bytes=sum(tp.stat().st_size for tp,_ in sorted_files)
    completed_set=set(cp.get("completed_files",[]))
    committed_bytes=sum(tp.stat().st_size for tp,_ in sorted_files if str(tp) in completed_set)
    completed_sessions=sum(len(ers) for tp,ers in sorted_files if str(tp) in completed_set)
    started=time.monotonic()
    print(f"PREFLIGHT_RESUME phase={phase} months_committed={len(completed_set)}/{len(sorted_files)} "
          f"sessions_committed={completed_sessions}/{len(rows)} SAFE_STOP=YES",flush=True)

    for tp,ers in sorted_files:
        raw=str(tp)
        if raw in completed_set:
            print(f"PREFLIGHT_MONTH_REUSE phase={phase} file={tp.name} CHECKPOINT=COMMITTED SAFE_STOP=YES",flush=True)
            continue
        rec=_scan_month(phase,tp,ers,committed_bytes,total_bytes,completed_sessions,len(rows),started)
        rp=_month_receipt_path(phase_out,tp);write_json_atomic(rp,rec);rec_sha=sha256_file(rp)
        if rec["status"]!="PASS_MONTH":
            write_json_atomic(phase_out/"PREFLIGHT_FAILURES.json",rec["failures"])
            write_json_atomic(phase_out/"PHASE_STATUS.json",{
                "phase":phase,"PHASE_DATA_STATUS":"BLOCKED","failure_count":len(rec["failures"]),
                "blocked_file":raw,"receipt_sha256":rec_sha,
            })
            raise ModelError(f"PREFLIGHT_MONTH_BLOCKED file={tp.name} failures={len(rec['failures'])}")
        cp["completed_files"].append(raw);cp["receipt_sha256"][raw]=rec_sha;cp["status"]="RUNNING"
        write_json_atomic(cp_path,cp)
        committed_bytes+=tp.stat().st_size;completed_sessions+=len(ers);completed_set.add(raw)
        print(f"PREFLIGHT_MONTH_COMMIT phase={phase} file={tp.name} months={len(completed_set)}/{len(sorted_files)} "
              f"sessions={completed_sessions}/{len(rows)} CHECKPOINT={cp_path} SAFE_STOP=YES",flush=True)

    _aggregate_phase(phase_out,phase,rows,sorted_files,cp)
    cp["status"]="PASS"
    cp["phase_artifacts"]={n:sha256_file(phase_out/n) for n in (
        "PHASE_STATUS.json","PREFLIGHT_FAILURES.json","SOURCE_INVENTORY.json",
        "CUTOFF_LATENCY_DIAGNOSTICS.csv",f"SESSION_CALENDAR_PHASE_{phase}.csv",
        f"EXPECTED_SESSIONS_PHASE_{phase}.csv",f"R3_CUTOFF_SIDECARS_PHASE_{phase}.jsonl")}
    write_json_atomic(cp_path,cp)
    print(f"PREFLIGHT_PHASE_{phase}=PASS sessions={len(rows)} months={len(sorted_files)} CHECKPOINT={cp_path}",flush=True)
    return len(rows)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--out",required=True);ap.add_argument("--phase",choices=PHASES_ALLOWED,required=True)
    ap.add_argument("--ticks-root",default=r"D:\Base CSV\WIN@N")
    ap.add_argument("--m1-root",default=r"D:\Base CSV\WIN@N_M1")
    ap.add_argument("--ind-d1",default=r"D:\Base CSV\IND@N\IND@N.csv")
    ns=ap.parse_args()
    cfg={"out_root":ns.out,"ticks_root":ns.ticks_root,"m1_root":ns.m1_root,"ind_d1":ns.ind_d1}
    try:
        n=preflight_phase_resumable(cfg,ns.phase)
        print(f"PREFLIGHT_STATUS=PASS phase={ns.phase} sessions={n}",flush=True)
    except KeyboardInterrupt:
        print(f"PREFLIGHT_SAFE_STOP=YES phase={ns.phase} CHECKPOINT=LAST_COMMITTED_MONTH RESUME_SAME_COMMAND=YES",flush=True)
        raise SystemExit(130)
    except Exception as e:
        print(f"PREFLIGHT_STATUS=BLOCKED phase={ns.phase} error={type(e).__name__}:{e}",flush=True)
        raise

if __name__=="__main__":main()
