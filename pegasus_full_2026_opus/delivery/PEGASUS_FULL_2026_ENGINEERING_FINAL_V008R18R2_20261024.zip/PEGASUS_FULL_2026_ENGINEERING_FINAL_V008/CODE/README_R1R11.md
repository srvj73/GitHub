# R1R11 V004R2 — synthetic owner pending

V004R2 is a versioned causal correction after the single V004R1 owner G4 FAIL.

It preserves SPEC V004 and all frozen economic/causal files. It does not alter the oracle, threshold, heavy fixture, batch size or canonical output format.

## Current authorization

```text
V004R2_IMPLEMENTED=YES
V004R2_OWNER_G4=NOT_RUN
REAL_DATA=NO
PILOT_A=NO
RUN_A=NO
FINAL_OPUS_AUDIT=NO_NOT_YET
```

The next eligible work is local owner validation on a fresh evidence root. The V004R1 evidence tree is historical and must never be reused or overwritten.

See `V004R2_CAUSAL_PREREGISTRATION.md`, `OPERATIONAL_PREREGISTRATION_V004R2.json` and `CHANGELOG_V004R1_TO_V004R2.md`.
