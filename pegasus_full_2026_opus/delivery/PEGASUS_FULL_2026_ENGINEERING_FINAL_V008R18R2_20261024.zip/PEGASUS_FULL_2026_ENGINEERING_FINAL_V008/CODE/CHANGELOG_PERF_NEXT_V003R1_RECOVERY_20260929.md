# MINOTAURO PERF NEXT V003R1 — recovery gate correction

BASE_PACKAGE_SHA256=6431A5B6EF83A05E1C124D5C883CF22454FAE97E20BFA7770E9AC0C5AAA44C97

## Observed failure
The live Windows synthetic qualification completed its candidate sessions but the
controller raised `CORRECTNESS_SYNTHETIC_BYTE_DIFFERENCE`.

## Root cause
V003 intentionally adds `source_resume` to CHECKPOINT.json. The old qualification
gate hashed the full checkpoint bytes, so this infrastructure-schema addition and
its derived `checkpoint_content_sha256` caused a false inequality even if economic
state was unchanged.

## Correction
- Every file under `sessions/` remains byte-for-byte SHA-256 equal between oracle
  and candidate.
- CHECKPOINT.json is compared structurally after excluding only:
  `source_resume` and `checkpoint_content_sha256`.
- Any difference in any other checkpoint field remains blocking.
- No economic engine, parser, source-reader, worker, coordinator, transaction,
  resume-import, or output module was changed by this correction.

SOURCE_RESUME_SEMANTICS=UNCHANGED
ECONOMIC_CODE_DELTA=NONE
