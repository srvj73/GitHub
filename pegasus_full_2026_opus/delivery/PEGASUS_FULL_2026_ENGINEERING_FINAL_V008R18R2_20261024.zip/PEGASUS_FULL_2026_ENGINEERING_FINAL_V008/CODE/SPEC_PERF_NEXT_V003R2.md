# SPEC — MINOTAURO PERF NEXT V003R2 — RESUME ONE-SHOT / HELPER LIFECYCLE / HEARTBEAT

STATUS=DEVELOPMENT_ONLY_WHILE_V003R1_FULL_ACTIVE
BASE_PACKAGE=MINOTAURO_PERF_NEXT_V003R1_RECOVERY_20260929
ECONOMIC_DELTA=NONE
ACTIVATE_DURING_CURRENT_V003R1_FULL=FORBIDDEN

## Delta
1. Stream helper registries become session-owned under `_helper_registry` inside the
   current session scratch, instead of persisting at run-instance root.
2. A helper registry is retired only after exact PID+creation_time identity matches
   and the process is no longer live.
3. A later resume that proves all stale registries dead reconciles run-owned scratch
   and continues in the same invocation; the old forced
   `STALE_SCRATCH_PURGED_RESUME_REQUIRED` extra launch is removed.
4. MULTIWORK session heartbeat moves from 5 s spam to 30 s and exposes
   PHASE/ACTIVE/READY_WAITING/RATE/ETA/FINISH/CHECKPOINT/SAFE_STOP fields.

## Invariants
- core economics unchanged;
- frozen parser unchanged;
- C1/cutoff unchanged;
- W15/B256 unchanged;
- SHARED_SLOTS=1 unchanged;
- publisher/output bytes unchanged;
- checkpoint economic semantics unchanged;
- PID ownership remains PID+creation_time;
- no kill is introduced.

## Deferred performance tier
Multi-slot/feed-ahead remains intentionally unimplemented until post-FULL profiling
shows barrier wait is still material and a causal proof prevents crossing the unknown
global terminal point.
