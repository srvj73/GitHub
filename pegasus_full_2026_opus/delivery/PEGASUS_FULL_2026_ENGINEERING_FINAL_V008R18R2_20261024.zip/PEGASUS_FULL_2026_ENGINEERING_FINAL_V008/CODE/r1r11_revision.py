"""R1R11 V005R1: streaming closeout architecture under Opus E1-E7 envelope."""
import json
from pathlib import Path
REVISION='R1R11_V005R1'
CANONICAL_COMMIT_THREADS=0  # V005 uses dedicated streaming writer processes; frozen gzjson unchanged.
def operational_parameters():
    return json.loads((Path(__file__).parent/'OPERATIONAL_PREREGISTRATION_V005R1.json').read_text())
