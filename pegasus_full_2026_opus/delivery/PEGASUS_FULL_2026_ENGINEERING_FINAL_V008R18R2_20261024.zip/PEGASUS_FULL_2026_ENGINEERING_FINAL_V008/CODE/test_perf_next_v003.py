from __future__ import annotations
import hashlib, importlib.util, json, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def load(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'))
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

class PerfNextV003Tests(unittest.TestCase):
    def _ticks(self,path:Path):
        io=load('minotauro_v004_io')
        rows=[]
        for day in ('2025.04.01','2025.04.02','2025.04.03'):
            for sec in (0,1):
                dt=f'{day} 09:00:0{sec}'
                msc=io.date_time_to_epoch_ms_floor(dt)+123
                rows.append(f'WIN@N;{dt};{msc};100.000000;100.005000;100.000000;1;1;2\n'.encode())
        path.write_bytes(b''.join(rows)); return rows

    def test_session_anchor_seek_and_hash_continuity(self):
        fr=load('r1r11_fast_resume'); runner=load('minotauro_v004_runner'); io=load('minotauro_v004_io')
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'ticks.csv'; rows=self._ticks(p)
            anchor_offset=fr.find_session_start_offset(p,'2025-04-02')
            self.assertEqual(anchor_offset,len(rows[0])+len(rows[1]))
            # Simulate a prior receipt whose prefix includes first boundary row of pending day.
            future_cut=anchor_offset+len(rows[2])
            expected={future_cut:hashlib.sha256(p.read_bytes()[:future_cut]).hexdigest().upper()}
            anchor=fr.make_anchor(p,'2025-04-02',anchor_offset)
            tracker=fr.rehydrate_prefix_tracker(p,anchor,expected)
            self.assertEqual(tracker.bytes_read,anchor_offset)
            self.assertNotIn(future_cut,tracker.checked)
            resumed=list(fr.iter_tick_file_from_offset(p,start_offset=anchor_offset,
                         include_sessions={'2025-04-02','2025-04-03'},hasher=tracker))
            frozen=list(io.iter_tick_file(p,include_sessions={'2025-04-02','2025-04-03'}))
            self.assertEqual([(r.session,r.ordinal,r.time_msc) for r in resumed],
                             [(r.session,r.ordinal,r.time_msc) for r in frozen])
            self.assertIn(future_cut,tracker.checked)
            tracker.assert_all_expected_checked()
            self.assertEqual(tracker.hexdigest().upper(),hashlib.sha256(p.read_bytes()).hexdigest().upper())

    def test_zero_offset_candidate_reader_matches_frozen_reader(self):
        fr=load('r1r11_fast_resume'); io=load('minotauro_v004_io')
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'ticks.csv'; self._ticks(p)
            boundaries={}
            got=list(fr.iter_tick_file_from_offset(p,start_offset=0,include_sessions={'2025-04-01','2025-04-03'},
                                                   session_boundary_cb=lambda sess,off:boundaries.setdefault(sess,off)))
            exp=list(io.iter_tick_file(p,include_sessions={'2025-04-01','2025-04-03'}))
            self.assertEqual([(r.session,r.ordinal,r.time_msc) for r in got],[(r.session,r.ordinal,r.time_msc) for r in exp])
            self.assertEqual(boundaries['2025-04-01'],0)
            self.assertGreater(boundaries['2025-04-03'],boundaries['2025-04-01'])

    def test_anchor_fingerprint_mutation_blocks(self):
        fr=load('r1r11_fast_resume')
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'ticks.csv'; self._ticks(p)
            a=fr.anchor_for_first_pending(p,'2025-04-02')
            with p.open('ab') as f:f.write(b'X')
            with self.assertRaises(Exception): fr.validate_fingerprint(p,a['fingerprint'])

    def test_telemetry_is_bounded_and_rotates(self):
        bt=load('r1r11_bounded_telemetry')
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'t.jsonl'
            for i in range(50): bt.append_line(p,'x'*20,max_bytes=100,keep=2)
            files=sorted(Path(td).glob('t.jsonl*'))
            self.assertLessEqual(len(files),3)
            self.assertTrue(all(x.stat().st_size<=100 for x in files))

    def test_dynamic_cutover_not_hardcoded(self):
        c=(ROOT/'r1r11_perf_next_controller.py').read_text(encoding='utf-8')
        r=(ROOT/'r1r11_resume_import.py').read_text(encoding='utf-8')
        self.assertIn("'import-final'",c)
        self.assertIn('--dynamic-final-state',c)
        self.assertIn('SOURCE_STOP_RECEIPT_REQUIRED_DYNAMIC',r)
        self.assertIn("'binding_mode':'DYNAMIC_FINAL_STATE'",r)
        self.assertNotIn('$SourceCompletedExpected',r)

    def test_contract_strings_and_tree_clean(self):
        spec=(ROOT/'SPEC_PERF_NEXT_V003.md').read_text(encoding='utf-8')
        for line in (
            'CHECKPOINT_GRANULARITY=1_PREGÃO','MAX_RECOMPUTE_AFTER_FAILURE=1_PREGÃO',
            'SOURCE_RESUME_OFFSET=POR_PREGÃO','TELEMETRY=BOUNDED',
            'PID_OWNERSHIP=PID+CREATION_TIME','SAFE_STOP=PROVADO_APÓS_TREE_CLEAN'):
            self.assertIn(line,spec)
        coord=(ROOT/'r1r11_coordinator.py').read_text(encoding='utf-8')
        resources=(ROOT/'r1r11_resources.py').read_text(encoding='utf-8')
        self.assertIn('assert_owned_tree_clean',coord)
        self.assertIn('creation_time_100ns',resources)
        self.assertIn('SAFE_STOP_WORKER_COOPERATIVE_TIMEOUT',coord)

    def test_first_ctrl_c_path_does_not_terminate(self):
        coord=(ROOT/'r1r11_coordinator.py').read_text(encoding='utf-8')
        stream=(ROOT/'r1r11_v5_stream.py').read_text(encoding='utf-8')
        self.assertIn("if cooperative_only:\n                    raise ModelError(f'SAFE_STOP_WORKER_COOPERATIVE_TIMEOUT",coord)
        self.assertIn("if cooperative_only:\n                    raise ModelError(f'SAFE_STOP_STREAM_COOPERATIVE_TIMEOUT",stream)

    def test_frozen_io_parser_bytes_preserved(self):
        h=hashlib.sha256((ROOT/'minotauro_v004_io.py').read_bytes()).hexdigest().upper()
        self.assertEqual(h,'DC816C617AA6586828CEC769B21741D5BC4106FA8A72B933F1BE76D4E1BCAF4F')

    def test_progress_global_is_committed(self):
        t=(ROOT/'minotauro_v004_runner.py').read_text(encoding='utf-8')
        self.assertIn('PCT={global_pct',t)
        self.assertIn('COMMITTED={sessions_done}/{sessions_total}',t)
        self.assertIn('SOURCE_PCT={source_pct',t)

    def test_original_full_active_only_synthetic_qualify(self):
        t=(ROOT/'r1r11_perf_next_controller.py').read_text(encoding='utf-8')
        self.assertIn('QUALIFY_REAL_MARKET_DATA_READ=NO SOURCE_TREE_MUTATION=NO',t)
        for command in ('pilot','prepare-full','import-final','full'):
            self.assertIn(command,t)
        self.assertIn('require_current_full_stopped()',t)

    def test_synthetic_checkpoint_schema_delta_is_non_economic_only(self):
        ctl=load('r1r11_perf_next_controller')
        with tempfile.TemporaryDirectory() as td:
            base=Path(td)
            oracle=base/'oracle'; candidate=base/'candidate'
            for root in (oracle,candidate):
                (root/'sessions'/'2000-01-03').mkdir(parents=True)
                (root/'sessions'/'2000-01-03'/'x.bin').write_bytes(b'economic-bytes')
            common={
                'phase':'SYNTHETIC','completed':['2000-01-03'],
                'last_committed_session_date':'2000-01-03','cash':{'x':1},
                'hwm':{'x':2},'maxdd':{'x':3},'runtime_module_hashes':{}
            }
            o={**common,'checkpoint_content_sha256':'ORACLE'}
            c={**common,'source_resume':None,'checkpoint_content_sha256':'CANDIDATE'}
            (oracle/'CHECKPOINT.json').write_text(json.dumps(o),encoding='utf-8')
            (candidate/'CHECKPOINT.json').write_text(json.dumps(c),encoding='utf-8')
            got=ctl._synthetic_equivalence(oracle,candidate)
            self.assertTrue(got['session_artifacts_byte_equal'])
            self.assertTrue(got['checkpoint_economic_state_equal'])
            self.assertEqual(got['checkpoint_schema_delta_allowed'],
                             ['source_resume','checkpoint_content_sha256'])

    def test_synthetic_checkpoint_real_economic_delta_blocks(self):
        ctl=load('r1r11_perf_next_controller')
        with tempfile.TemporaryDirectory() as td:
            base=Path(td)
            oracle=base/'oracle'; candidate=base/'candidate'
            for root in (oracle,candidate):
                (root/'sessions'/'2000-01-03').mkdir(parents=True)
                (root/'sessions'/'2000-01-03'/'x.bin').write_bytes(b'economic-bytes')
            o={'cash':{'x':1},'checkpoint_content_sha256':'A'}
            c={'cash':{'x':2},'source_resume':None,'checkpoint_content_sha256':'B'}
            (oracle/'CHECKPOINT.json').write_text(json.dumps(o),encoding='utf-8')
            (candidate/'CHECKPOINT.json').write_text(json.dumps(c),encoding='utf-8')
            with self.assertRaisesRegex(RuntimeError,'CHECKPOINT_ECONOMIC_DIFFERENCE'):
                ctl._synthetic_equivalence(oracle,candidate)

    def test_stream_helper_registry_is_session_owned_and_retired(self):
        t=(ROOT/'r1r11_v5_stream.py').read_text(encoding='utf-8')
        self.assertIn("self.registry_dir = active.scratch / \"_helper_registry\"",t)
        self.assertIn("registry_path=self.registry_dir/f'stream_{proc.pid}.helper.json'",t)
        self.assertIn('STREAM_HELPER_REGISTRY_IDENTITY_CHANGED',t)
        self.assertIn('STREAM_HELPER_REGISTRY_RETIRE_WHILE_LIVE',t)
        self.assertIn('self._retire_registry(e)',t)
        self.assertNotIn("self.runtime.scratch/f'stream_{proc.pid}.helper.json'",t)

    def test_dead_stale_scratch_reconciles_same_resume_attempt(self):
        t=(ROOT/'r1r11_resources.py').read_text(encoding='utf-8')
        self.assertIn('STALE_SCRATCH_RECONCILED=PASS',t)
        self.assertIn('resume_same_attempt=YES',t)
        self.assertNotIn('STALE_SCRATCH_PURGED_RESUME_REQUIRED',t)

    def test_progress_heartbeat_cadence_and_fields(self):
        t=(ROOT/'r1r11_coordinator.py').read_text(encoding='utf-8')
        self.assertIn('now-self.last_report>=30',t)
        self.assertNotIn('now-self.last_report>=5',t)
        for token in ('PHASE=SESSION_PROCESS','ACTIVE={active_total}','READY_WAITING=0',
                      'RATE_ROWS_S=','ETA=SOURCE_PROGRESS','FINISH=UNKNOWN',
                      'CHECKPOINT=PREVIOUS_SESSION','SAFE_STOP=YES'):
            self.assertIn(token,t)

    def test_runtime_status_atomic_required_fields_and_committed_progress(self):
        mod=load('r1r11_runtime_status')
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'TELEMETRY'/'R1R11_STATUS.json'
            state=mod.new_status(run_instance='r1',out_root=Path(td),mode='RUN_A',
                                 committed=109,total=250)
            state=mod.write_status_atomic(path,state,PHASE='SESSION_PROCESS',
                                          ACTIVE=31,READY_WAITING=0,RATE=1234.5,
                                          ETA='SOURCE_PROGRESS',CHECKPOINT='2025-06-10')
            got=json.loads(path.read_text(encoding='utf-8'))
            self.assertEqual(got['COMMITTED'],109)
            self.assertEqual(got['TOTAL'],250)
            self.assertAlmostEqual(got['PCT'],43.6)
            self.assertEqual(got['PHASE'],'SESSION_PROCESS')
            for key in mod.REQUIRED:self.assertIn(key,got)
            self.assertFalse(list(path.parent.glob('*.tmp*')))

    def test_runtime_status_heartbeat_does_not_advance_global_committed(self):
        t=(ROOT/'r1r11_coordinator.py').read_text(encoding='utf-8')
        self.assertIn("self.runtime.status('SESSION_PROCESS'",t)
        heartbeat=t[t.index("self.runtime.status('SESSION_PROCESS'"):][:700]
        self.assertNotIn('COMMITTED=',heartbeat)
        self.assertIn("runtime.committed(len(done))",(ROOT/'minotauro_v004_runner.py').read_text(encoding='utf-8'))

    def test_homologation_requires_clean_status_and_writes_final_report(self):
        t=(ROOT/'r1r11_perf_next_controller.py').read_text(encoding='utf-8')
        self.assertIn('FULL_RUNTIME_STATUS_NOT_CLEAN_PASS',t)
        self.assertIn('FULL_RUN_LOCK_RESIDUAL',t)
        self.assertIn('FULL_SCRATCH_RESIDUAL',t)
        self.assertIn("atomic(gates/'FINAL_REPORT.json',final_report)",t)
        self.assertIn("'process_tree_clean':'YES'",t)
        self.assertIn("'scratch_cleanup':'PASS'",t)

if __name__=='__main__': unittest.main(verbosity=2)
