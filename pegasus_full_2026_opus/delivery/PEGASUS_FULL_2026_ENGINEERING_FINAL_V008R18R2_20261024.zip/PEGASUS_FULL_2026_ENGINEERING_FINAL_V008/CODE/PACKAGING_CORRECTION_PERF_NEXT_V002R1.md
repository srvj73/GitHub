# MINOTAURO PERF NEXT V002R1 — packaging/resume correction

INCIDENT=V002_TOP_MANIFEST_EXCLUDED_NESTED_SHA256SUMS
CAUSE=the top-manifest generator excluded every file named SHA256SUMS.txt instead of excluding only the root manifest itself.
EVIDENCE=V002 verify_package() raised PACKAGE_MANIFEST_SET_MISMATCH for exactly five nested historical/oracle SHA256SUMS.txt files.
CORRECTION=regenerate the top manifest from the complete physical file set, excluding only the root SHA256SUMS.txt; add first-class committed-session migration helper and prepare-full command.
ENFORCEMENT=final package must pass its own verify_package(), ZIP CRC, manifest member-set equality, no undeclared pycache/pyc, and resume-import tests before delivery.
IMPACT=V002 package is superseded before target qualification; no user-PC V002 execution occurred.
SOURCE_RUN_MUTATED=NO
OLD_COMMITTED_SESSIONS_PRESERVED=YES
