﻿//+------------------------------------------------------------------+
//| MINOTAURO_REAL_LIVE_V003R1_R6.mq5                               |
//| Pegasus MT5 / MINOTAURO                                         |
//| V003 CANONICAL R1 - R6 REAL-CAPABLE / STARTUP RETRY PATCH             |
//+------------------------------------------------------------------+
#property strict
#property version   "1.034"
#property description "MINOTAURO REAL LIVE V003R1 R6 - R5 strategy/telemetry + unattended startup retry"
#include <Trade/Trade.mqh>

CTrade trade;

input string InpTradeSymbol       = "";       // vazio = simbolo do grafico
input string InpReferenceSymbol   = "IND@N";
input bool   InpUseManualPrevIND  = false;
input double InpManualPrevHigh    = 0.0;
input double InpManualPrevLow     = 0.0;
input double InpProjectionPct     = 61.8;
input double InpExpectedTickSize  = 5.0;
input int    InpTriggerTicks      = 10;
input double InpMinRRTrigger      = 5.0;
input double InpLots              = 1.0;
input ulong  InpMagic             = 2026092301;
input ulong  InpDeviationPoints   = 0;
input bool   InpEnableDemoOrders  = true;
input bool   InpEnableRealOrders  = false;      // REAL: armamento explicito; default fail-closed
input long   InpAuthorizedLogin   = 0;          // REAL send: obrigatorio >0 e igual ao login atual
input string InpAuthorizedServer  = "";         // REAL send: obrigatorio e igual ao servidor atual
input int    InpManualPrevINDDate = 0;          // YYYYMMDD; obrigatorio no modo manual
input bool   InpDrawFibos         = true;

#define VERSION_NAME "MINOTAURO_REAL_LIVE_V003R1_R6"
#define COPY_BATCH 5000
#define FROZEN_MAGIC 2026092301
#define MAX_CAUSAL_QUOTE_AGE_MS 500
#define CUTOFF_SECONDS 64980
#define REAL_MONEY_ORDER_SEND_CAPABLE true
#define STATE_SCHEMA 2
#define BUILD_REVISION 6

double MICRO_PCTS[11]={0.056,0.090,0.146,0.236,0.382,0.500,0.618,0.764,0.854,0.910,0.944};

struct FiboLine
{
   double price;
   bool macro;
   string label;
   bool active;
};

struct Signal
{
   bool active;
   int dir;
   double origin;
   double target;
   double trigger_price;
   double rr_trigger;
   double risk_ticks;
   double reward_ticks;
   ulong trigger_seq;

   // Identidade fisica de N para recovery causal.
   long trigger_time;
   long trigger_msc;
   int  trigger_same_count;
   uint trigger_flags;
   ulong trigger_volume;
   double trigger_volume_real;
};

FiboLine lines[];
Signal pending;

string sym="", refsym="", refinfo="", status_text="INIT";
double tick_size=0.0, point_size=0.0, ref_high=0.0, ref_low=0.0, ref_range=0.0;
int price_digits=0, grid_day=0;
bool demo_ok=false, grid_ok=false;
bool have_prev_business=false;
double prev_business_price=0.0;
ulong business_seq=0;

long startup_login=0, startup_trade_mode=0;
string startup_server="";
bool recovery_ok=false, cutoff_latched=false, state_initialized=false;
string state_fault="", request_phase="RECONCILED";
ulong state_generation=0;
int state_session_day=0, expected_d1_date=0, effective_d1_date=0;

// Ultimo BID/ASK causal conhecido no fluxo CopyTicks.
// Business ticks podem carregar LAST/VOLUME com bid/ask zerados.
double market_bid=0.0;
double market_ask=0.0;
long   market_bid_msc=0;
long   market_ask_msc=0;
long   market_quote_msc=0; // idade do BBO = lado mais antigo do par causal

bool cursor_ok=false;
long cursor_msc=0;
int cursor_same_count=0;

int logh=INVALID_HANDLE;

// R6: startup transitorio unattended. Condicoes recuperaveis nao removem o EA.
bool startup_runtime_ready=false;
bool startup_reconciled=false;
bool startup_pending_checked=false;
bool startup_fatal=false;
string startup_wait_reason="";
datetime startup_wait_last_report=0;

int DateKey(datetime t)
{
   MqlDateTime d; TimeToStruct(t,d);
   return d.year*10000+d.mon*100+d.day;
}
string DateText(datetime t)
{
   MqlDateTime d; TimeToStruct(t,d);
   return StringFormat("%04d-%02d-%02d",d.year,d.mon,d.day);
}
double RoundTick(double x)
{
   return MathFloor(x/tick_size+0.5+1e-12)*tick_size;
}
double NPrice(double x)
{
   return NormalizeDouble(RoundTick(x),price_digits);
}
bool Eq(double a,double b)
{
   return MathAbs(a-b)<=tick_size*1e-7;
}
bool BusinessTick(const MqlTick &t)
{
   // Canonico: BUSINESS = last>0 AND volume>0. Flags e volume_real nao classificam.
   return (t.last>0.0 && t.volume>0);
}
void UpdateKnownQuote(const MqlTick &t)
{
   // Cada lado do BBO carrega sua propria idade causal. Um BID novo nao
   // rejuvenesce silenciosamente um ASK antigo (e vice-versa).
   if(t.bid>0.0){ market_bid=t.bid; market_bid_msc=t.time_msc; }
   if(t.ask>0.0){ market_ask=t.ask; market_ask_msc=t.time_msc; }

   if(market_bid_msc>0 && market_ask_msc>0)
      market_quote_msc=(market_bid_msc<market_ask_msc?market_bid_msc:market_ask_msc);
   else
      market_quote_msc=0;
}
int SecondsOfDay(datetime t)
{
   MqlDateTime d; TimeToStruct(t,d);
   return d.hour*3600+d.min*60+d.sec;
}
string SafeName(string s)
{
   StringReplace(s,"\\","_"); StringReplace(s,"/","_"); StringReplace(s,":","_");
   StringReplace(s,";","_"); StringReplace(s,"|","_"); StringReplace(s," ","_");
   return s;
}
bool IsDemoAccount()
{
   return AccountInfoInteger(ACCOUNT_TRADE_MODE)==ACCOUNT_TRADE_MODE_DEMO;
}
bool IsRealAccount()
{
   return AccountInfoInteger(ACCOUNT_TRADE_MODE)==ACCOUNT_TRADE_MODE_REAL;
}
bool RealAccountBindingOk(string &why)
{
   if(!IsRealAccount()){ why="ACCOUNT_NOT_REAL"; return false; }
   if(InpAuthorizedLogin<=0){ why="REAL_AUTHORIZED_LOGIN_REQUIRED"; return false; }
   if(StringLen(InpAuthorizedServer)<=0){ why="REAL_AUTHORIZED_SERVER_REQUIRED"; return false; }

   long login=AccountInfoInteger(ACCOUNT_LOGIN);
   string server=AccountInfoString(ACCOUNT_SERVER);
   if(login!=InpAuthorizedLogin){ why="REAL_AUTHORIZED_LOGIN_MISMATCH"; return false; }
   if(server!=InpAuthorizedServer){ why="REAL_AUTHORIZED_SERVER_MISMATCH"; return false; }

   why="OK"; return true;
}
string ExecutionModeText()
{
   if(IsDemoAccount()) return (InpEnableDemoOrders?"DEMO_AUTO":"DEMO_DISABLED");
   if(IsRealAccount())
   {
      string why;
      if(InpEnableRealOrders && REAL_MONEY_ORDER_SEND_CAPABLE && RealAccountBindingOk(why))
         return "REAL_AUTO_ARMED";
      return "REAL_SHADOW";
   }
   return "ACCOUNT_MODE_UNSUPPORTED";
}
bool TradePermitted()
{
   return TerminalInfoInteger(TERMINAL_CONNECTED)
       && TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)
       && MQLInfoInteger(MQL_TRADE_ALLOWED)
       && AccountInfoInteger(ACCOUNT_TRADE_ALLOWED)
       && AccountInfoInteger(ACCOUNT_TRADE_EXPERT);
}
bool TradeResultAccepted(bool call_ok)
{
   if(!call_ok) return false;
   uint rc=trade.ResultRetcode();
   return (rc==TRADE_RETCODE_DONE ||
           rc==TRADE_RETCODE_DONE_PARTIAL ||
           rc==TRADE_RETCODE_PLACED);
}
bool AccountIdentityOk(string &why)
{
   long login=AccountInfoInteger(ACCOUNT_LOGIN);
   long mode=AccountInfoInteger(ACCOUNT_TRADE_MODE);
   string server=AccountInfoString(ACCOUNT_SERVER);
   if(login!=startup_login || mode!=startup_trade_mode || server!=startup_server)
   {
      why="ACCOUNT_IDENTITY_CHANGED"; return false;
   }
   if(InpAuthorizedLogin>0 && login!=InpAuthorizedLogin)
   {
      why="AUTHORIZED_LOGIN_MISMATCH"; return false;
   }
   if(StringLen(InpAuthorizedServer)>0 && server!=InpAuthorizedServer)
   {
      why="AUTHORIZED_SERVER_MISMATCH"; return false;
   }
   why="OK"; return true;
}
bool SymbolOperationalOk(string &why)
{
   if(!SymbolSelect(sym,true)){ why="SYMBOL_SELECT_FAIL"; return false; }
   if(SymbolInfoInteger(sym,SYMBOL_TRADE_MODE)!=SYMBOL_TRADE_MODE_FULL)
   {
      why="SYMBOL_TRADE_MODE_NOT_FULL"; return false;
   }
   double ts=SymbolInfoDouble(sym,SYMBOL_TRADE_TICK_SIZE);
   if(ts<=0 || MathAbs(ts-InpExpectedTickSize)>1e-9)
   {
      why="SYMBOL_TICK_SIZE_MISMATCH"; return false;
   }
   double mn=SymbolInfoDouble(sym,SYMBOL_VOLUME_MIN);
   double mx=SymbolInfoDouble(sym,SYMBOL_VOLUME_MAX);
   double st=SymbolInfoDouble(sym,SYMBOL_VOLUME_STEP);
   if(mn<=0 || mx<mn || st<=0){ why="SYMBOL_VOLUME_CONTRACT_INVALID"; return false; }
   why="OK"; return true;
}
bool PositionExists()
{
   return PositionSelect(sym);
}
bool OwnPositionExists()
{
   if(!PositionSelect(sym)) return false;
   return (ulong)PositionGetInteger(POSITION_MAGIC)==InpMagic;
}
bool ForeignPositionExists()
{
   if(!PositionSelect(sym)) return false;
   return (ulong)PositionGetInteger(POSITION_MAGIC)!=InpMagic;
}
bool OwnWorkingOrderExists()
{
   for(int i=OrdersTotal()-1;i>=0;i--)
   {
      ulong ticket=OrderGetTicket(i);
      if(ticket==0) continue;
      if(OrderGetString(ORDER_SYMBOL)!=sym) continue;
      if((ulong)OrderGetInteger(ORDER_MAGIC)!=InpMagic) continue;
      return true;
   }
   return false;
}
bool ForeignWorkingOrderExists()
{
   for(int i=OrdersTotal()-1;i>=0;i--)
   {
      ulong ticket=OrderGetTicket(i);
      if(ticket==0) continue;
      if(OrderGetString(ORDER_SYMBOL)!=sym) continue;
      if((ulong)OrderGetInteger(ORDER_MAGIC)==InpMagic) continue;
      return true;
   }
   return false;
}
double NormVolume(double v)
{
   double mn=SymbolInfoDouble(sym,SYMBOL_VOLUME_MIN);
   double mx=SymbolInfoDouble(sym,SYMBOL_VOLUME_MAX);
   double st=SymbolInfoDouble(sym,SYMBOL_VOLUME_STEP);
   if(st<=0) st=1.0;
   v=MathMax(mn,MathMin(mx,v));
   v=MathFloor(v/st+1e-9)*st;
   return v;
}
void ResetPending()
{
   pending.active=false; pending.dir=0; pending.origin=0; pending.target=0;
   pending.trigger_price=0; pending.rr_trigger=0; pending.risk_ticks=0;
   pending.reward_ticks=0; pending.trigger_seq=0;
   pending.trigger_time=0; pending.trigger_msc=0; pending.trigger_same_count=0;
   pending.trigger_flags=0; pending.trigger_volume=0; pending.trigger_volume_real=0.0;
}

uint HashText(string s)
{
   uint h=2166136261;
   for(int i=0;i<StringLen(s);i++)
      h=(h^(uint)StringGetCharacter(s,i))*16777619;
   return h;
}
string StatePrefix()
{
   // STATE_SCHEMA no namespace impede leitura acidental dos checkpoints R1/S1.
   return VERSION_NAME+"_S"+(string)STATE_SCHEMA+"_"+SafeName(startup_server)+"_"+
          (string)startup_login+"_"+SafeName(sym)+"_M"+(string)InpMagic;
}
string StateFile(bool a)
{
   return StatePrefix()+(a?"_state_A.txt":"_state_B.txt");
}
string BuildStateBody(ulong gen)
{
   return StringFormat("%I64u|%s|%I64u|%I64d|%s|%s|%d|%d|%d|%I64u|%I64d|%d|%d|%d|%.10f|%.10f|%.10f|%.10f|%.10f|%.10f|%I64u|%I64d|%I64d|%d|%u|%I64u|%.10f|%d|%d|%.10f|%.10f|%s",
      gen,VERSION_NAME,InpMagic,startup_login,SafeName(startup_server),SafeName(sym),
      STATE_SCHEMA,state_session_day,(cutoff_latched?1:0),business_seq,cursor_msc,cursor_same_count,
      (pending.active?1:0),pending.dir,pending.origin,pending.target,pending.trigger_price,
      pending.rr_trigger,pending.risk_ticks,pending.reward_ticks,pending.trigger_seq,
      pending.trigger_time,pending.trigger_msc,pending.trigger_same_count,pending.trigger_flags,
      pending.trigger_volume,pending.trigger_volume_real,expected_d1_date,effective_d1_date,
      ref_high,ref_low,request_phase);
}
bool WriteState()
{
   if(!state_initialized) return true;
   state_generation++;
   string body=BuildStateBody(state_generation);
   string line=body+"|"+StringFormat("%08X",HashText(body));
   bool slotA=((state_generation&1)==1);
   string fn=StateFile(slotA);
   int h=FileOpen(fn,FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_COMMON);
   if(h==INVALID_HANDLE){ state_fault="STATE_WRITE_OPEN_FAIL"; recovery_ok=false; return false; }
   bool ok=(FileWriteString(h,line+"\r\n")>0);
   FileFlush(h); FileClose(h);
   if(!ok){ state_fault="STATE_WRITE_FAIL"; recovery_ok=false; return false; }
   return true;
}
bool ValidateStateEnvelope(string line,ulong &gen)
{
   string f[];
   int n=StringSplit(line,'|',f);
   if(n!=33) return false;

   string body="";
   for(int i=0;i<32;i++){ if(i>0) body+="|"; body+=f[i]; }
   if(StringFormat("%08X",HashText(body))!=f[32]) return false;
   if(f[1]!=VERSION_NAME) return false;
   if((ulong)StringToInteger(f[2])!=InpMagic) return false;
   if((long)StringToInteger(f[3])!=startup_login) return false;
   if(f[4]!=SafeName(startup_server) || f[5]!=SafeName(sym)) return false;
   if((int)StringToInteger(f[6])!=STATE_SCHEMA) return false;

   gen=(ulong)StringToInteger(f[0]);
   return true;
}
bool ParseStateLine(string line,ulong &gen)
{
   if(!ValidateStateEnvelope(line,gen)) return false;

   string f[];
   int n=StringSplit(line,'|',f);
   if(n!=33) return false;

   state_session_day=(int)StringToInteger(f[7]);
   cutoff_latched=(StringToInteger(f[8])!=0);
   business_seq=(ulong)StringToInteger(f[9]);
   cursor_msc=(long)StringToInteger(f[10]);
   cursor_same_count=(int)StringToInteger(f[11]);

   pending.active=(StringToInteger(f[12])!=0);
   pending.dir=(int)StringToInteger(f[13]);
   pending.origin=StringToDouble(f[14]);
   pending.target=StringToDouble(f[15]);
   pending.trigger_price=StringToDouble(f[16]);
   pending.rr_trigger=StringToDouble(f[17]);
   pending.risk_ticks=StringToDouble(f[18]);
   pending.reward_ticks=StringToDouble(f[19]);
   pending.trigger_seq=(ulong)StringToInteger(f[20]);
   pending.trigger_time=(long)StringToInteger(f[21]);
   pending.trigger_msc=(long)StringToInteger(f[22]);
   pending.trigger_same_count=(int)StringToInteger(f[23]);
   pending.trigger_flags=(uint)StringToInteger(f[24]);
   pending.trigger_volume=(ulong)StringToInteger(f[25]);
   pending.trigger_volume_real=StringToDouble(f[26]);

   expected_d1_date=(int)StringToInteger(f[27]);
   effective_d1_date=(int)StringToInteger(f[28]);
   ref_high=StringToDouble(f[29]);
   ref_low=StringToDouble(f[30]);
   request_phase=f[31];
   return true;
}
bool ReadStateSlot(bool a,ulong &gen,string &line)
{
   string fn=StateFile(a);
   if(!FileIsExist(fn,FILE_COMMON)) return false;
   int h=FileOpen(fn,FILE_READ|FILE_TXT|FILE_ANSI|FILE_COMMON);
   if(h==INVALID_HANDLE) return false;
   line=FileReadString(h); FileClose(h);
   return ValidateStateEnvelope(line,gen);
}
bool LoadState()
{
   ulong ga=0,gb=0; string la="",lb="";
   bool va=ReadStateSlot(true,ga,la), vb=ReadStateSlot(false,gb,lb);
   bool anyA=FileIsExist(StateFile(true),FILE_COMMON);
   bool anyB=FileIsExist(StateFile(false),FILE_COMMON);

   if(!va && !vb)
   {
      if(anyA || anyB)
      {
         state_fault="STATE_SCHEMA2_BOTH_INVALID"; recovery_ok=false; return false;
      }

      // Primeiro startup do schema 2. Checkpoints schema 1 usam outro namespace e
      // nao sao interpretados/migrados silenciosamente.
      state_generation=0; state_session_day=DateKey(TimeTradeServer());
      business_seq=0; cursor_msc=0; cursor_same_count=0;
      cutoff_latched=false; request_phase="RECONCILED";
      recovery_ok=true; return true;
   }

   string chosen=(va && (!vb || ga>=gb))?la:lb;
   ulong g=0;
   if(!ParseStateLine(chosen,g))
   {
      state_fault="STATE_SCHEMA2_PARSE_FAIL"; recovery_ok=false; return false;
   }
   state_generation=g; recovery_ok=true; return true;
}
bool PendingTriggerIdentityMatches(const MqlTick &t)
{
   if(t.time!=(datetime)pending.trigger_time) return false;
   if(t.time_msc!=pending.trigger_msc) return false;
   if(t.flags!=pending.trigger_flags) return false;
   if(!Eq(t.last,pending.trigger_price)) return false;
   if(t.volume!=pending.trigger_volume) return false;
   if(MathAbs(t.volume_real-pending.trigger_volume_real)>1e-9) return false;
   return true;
}
bool ValidatePendingTriggerPhysicalIdentity(string &why)
{
   if(!pending.active){ why="NO_PENDING"; return true; }
   if(pending.trigger_msc<=0 || pending.trigger_same_count<=0 ||
      pending.trigger_time<=0 || pending.trigger_seq==0)
   {
      why="PENDING_TRIGGER_IDENTITY_INCOMPLETE"; return false;
   }

   MqlTick exact[];
   ResetLastError();
   int n=CopyTicksRange(sym,exact,COPY_TICKS_ALL,
                        (ulong)pending.trigger_msc,(ulong)pending.trigger_msc);
   int err=GetLastError();
   if(n<pending.trigger_same_count || err!=0)
   {
      why=StringFormat("PENDING_TRIGGER_RANGE_INCOMPLETE n=%d need=%d err=%d",
                       n,pending.trigger_same_count,err);
      return false;
   }

   int idx=pending.trigger_same_count-1;
   if(idx<0 || idx>=n || !PendingTriggerIdentityMatches(exact[idx]))
   {
      why=StringFormat("PENDING_TRIGGER_IDENTITY_MISMATCH n=%d idx=%d",
                       n,idx);
      return false;
   }

   why="OK"; return true;
}
bool RecoverPendingN1Physical()
{
   if(!pending.active) return true;

   string why;
   LogSimple("RECOVERY_PENDING_CHECK",
      StringFormat("trigger_seq=%I64u trigger_msc=%I64d same=%d",
                   pending.trigger_seq,pending.trigger_msc,pending.trigger_same_count));

   if(state_session_day!=DateKey(TimeTradeServer()))
   {
      LogSimple("RECOVERY_PENDING_N1_MISSED",
                "session changed while EA was unavailable; pending cancelled");
      ResetPending(); request_phase="RECONCILED";
      business_seq=0; cursor_msc=0; cursor_same_count=0;
      state_session_day=DateKey(TimeTradeServer());
      cutoff_latched=false;
      return WriteState();
   }

   if(!ValidatePendingTriggerPhysicalIdentity(why))
   {
      state_fault="RECOVERY_PENDING_COVERAGE_UNKNOWN "+why;
      recovery_ok=false;
      LogSimple("RECOVERY_PENDING_COVERAGE_UNKNOWN",why);
      return false;
   }

   MqlTick current;
   if(!SymbolInfoTick(sym,current) || current.time_msc<=0)
   {
      state_fault="RECOVERY_PENDING_CURRENT_TICK_UNAVAILABLE";
      recovery_ok=false;
      LogSimple("RECOVERY_PENDING_COVERAGE_UNKNOWN",state_fault);
      return false;
   }
   if(current.time_msc<pending.trigger_msc)
   {
      state_fault="RECOVERY_PENDING_CLOCK_REGRESSION";
      recovery_ok=false;
      LogSimple("RECOVERY_PENDING_COVERAGE_UNKNOWN",state_fault);
      return false;
   }

   long local_msc=pending.trigger_msc;
   int local_same=pending.trigger_same_count;
   bool covered=false;

   // Nao executa ProcessBusiness/ProcessEpisodes durante recovery.
   // Apenas prova se o verdadeiro BUSINESS N+1 ja ocorreu fisicamente.
   for(int loop=0;loop<2000;loop++)
   {
      if(IsStopped())
      {
         state_fault="RECOVERY_INTERRUPTED_BY_STOP";
         recovery_ok=false;
         LogSimple("RECOVERY_INTERRUPTED_BY_STOP",
                   "terminal requested stop during pending recovery scan");
         return false;
      }

      MqlTick a[];
      ResetLastError();
      int n=CopyTicks(sym,a,COPY_TICKS_ALL,(ulong)local_msc,COPY_BATCH);
      int err=GetLastError();
      if(n<=0 || err!=0)
      {
         state_fault=StringFormat("RECOVERY_PENDING_COPY_FAIL n=%d err=%d",n,err);
         recovery_ok=false;
         LogSimple("RECOVERY_PENDING_COVERAGE_UNKNOWN",state_fault);
         return false;
      }

      int seen=0,newn=0;
      for(int i=0;i<n;i++)
      {
         if(IsStopped())
         {
            state_fault="RECOVERY_INTERRUPTED_BY_STOP";
            recovery_ok=false;
            LogSimple("RECOVERY_INTERRUPTED_BY_STOP",
                      "terminal requested stop inside recovery tick batch");
            return false;
         }

         long m=a[i].time_msc;
         if(m<local_msc) continue;

         if(m==local_msc)
         {
            seen++;
            if(seen<=local_same) continue;
            local_same++;
         }
         else
         {
            local_msc=m;
            local_same=1;
            seen=1;
         }
         newn++;

         // Quotes posteriores a N e anteriores ao futuro N+1 sao causais e podem
         // reconstruir o ultimo BBO conhecido. Nenhuma decisao nova e processada.
         UpdateKnownQuote(a[i]);

         if(BusinessTick(a[i]))
         {
            string detail=StringFormat(
               "true N+1 occurred while offline: msc=%I64d same=%d last=%.*f",
               a[i].time_msc,local_same,price_digits,a[i].last);
            LogSimple("RECOVERY_PENDING_N1_MISSED",detail);

            // Entrada atrasada e proibida. Descarta pending e retoma apenas
            // prospectivamente a partir do final atual do stream.
            ResetPending();
            request_phase="RECONCILED";
            cursor_ok=false;
            cursor_msc=0; cursor_same_count=0;
            if(!WriteState()) return false;
            return true;
         }
      }

      if(local_msc>=current.time_msc)
      {
         covered=true;
         break;
      }

      if(n<COPY_BATCH || newn==0)
      {
         state_fault=StringFormat(
            "RECOVERY_PENDING_COVERAGE_GAP last_msc=%I64d current_msc=%I64d n=%d new=%d",
            local_msc,current.time_msc,n,newn);
         recovery_ok=false;
         LogSimple("RECOVERY_PENDING_COVERAGE_UNKNOWN",state_fault);
         return false;
      }
   }

   if(!covered)
   {
      state_fault="RECOVERY_PENDING_SCAN_LIMIT";
      recovery_ok=false;
      LogSimple("RECOVERY_PENDING_COVERAGE_UNKNOWN",state_fault);
      return false;
   }

   // Nenhum BUSINESS fisicamente posterior a N foi encontrado.
   // Portanto o proximo BUSINESS ao vivo continua sendo o verdadeiro N+1.
   cursor_msc=local_msc;
   cursor_same_count=local_same;
   cursor_ok=true;
   business_seq=pending.trigger_seq;
   have_prev_business=true;
   prev_business_price=pending.trigger_price;
   request_phase="RECONCILED";
   if(!WriteState()) return false;

   LogSimple("RECOVERY_PENDING_STILL_VALID",
      StringFormat("trigger_msc=%I64d same=%d cursor_msc=%I64d cursor_same=%d",
                   pending.trigger_msc,pending.trigger_same_count,
                   cursor_msc,cursor_same_count));
   return true;
}
bool ReconcileStartup()
{
   int today=DateKey(TimeTradeServer());

   if(ForeignPositionExists())
   {
      state_fault="FOREIGN_POSITION_PRESENT"; recovery_ok=false; return false;
   }
   if(OwnWorkingOrderExists())
   {
      state_fault="OWN_WORKING_ORDER_PRESENT_ON_STARTUP"; recovery_ok=false; return false;
   }
   if(ForeignWorkingOrderExists())
   {
      state_fault="FOREIGN_WORKING_ORDER_PRESENT_ON_STARTUP"; recovery_ok=false; return false;
   }
   if(OwnPositionExists())
   {
      if(IsRealAccount())
      {
         string bind_why;
         if(!RealAccountBindingOk(bind_why))
         {
            state_fault="REAL_OWN_POSITION_BINDING_REQUIRED "+bind_why;
            recovery_ok=false; return false;
         }
      }
      ResetPending();
      request_phase="RECONCILED_ACTIVE_POSITION";
      recovery_ok=true;
      state_session_day=today;
      WriteState();
      LogSimple("RECOVERY_STATE_LOADED","own active position reconciled; no pending entry allowed");
      return true;
   }
   if(request_phase=="PRE_SEND" || request_phase=="SEND_ACCEPTED")
   {
      state_fault="RECOVERY_SEND_AMBIGUOUS "+request_phase; recovery_ok=false; return false;
   }

   if(state_session_day!=today)
   {
      if(pending.active)
         LogSimple("RECOVERY_PENDING_N1_MISSED",
                   "persisted pending belongs to prior session; cancelled");
      ResetPending();
      business_seq=0; cursor_msc=0; cursor_same_count=0; cursor_ok=false;
      cutoff_latched=false;
      expected_d1_date=0; effective_d1_date=0;
      ref_high=0.0; ref_low=0.0;
      state_session_day=today;
   }

   request_phase="RECONCILED"; recovery_ok=true;
   if(!WriteState()) return false;

   LogSimple("RECOVERY_STATE_LOADED",
      StringFormat("schema=%d generation=%I64u session=%d pending=%s business_seq=%I64u cursor_msc=%I64d cursor_same=%d",
                   STATE_SCHEMA,state_generation,state_session_day,
                   pending.active?"YES":"NO",business_seq,cursor_msc,cursor_same_count));
   return true;
}
void OpenLog()
{
   string fn=StringFormat("MINOTAURO_REAL_LIVE_V003R1_R6_%I64u_%s.csv",
      (ulong)AccountInfoInteger(ACCOUNT_LOGIN),DateText(TimeTradeServer()));
   logh=FileOpen(fn,FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI|FILE_SHARE_READ,';');
   if(logh==INVALID_HANDLE){ Print(VERSION_NAME," LOG FAIL ",GetLastError()); return; }
   bool empty=(FileSize(logh)==0);
   FileSeek(logh,0,SEEK_END);
   if(empty)
      FileWrite(logh,"event_time_server","tick_time","event","seq","tick_msc","dir","origin","target","trigger",
         "rr_trigger","riskT","rewardT","bid","ask","last","extra");
}
void LogEvt(string ev,const MqlTick &t,int dir,double origin,double target,
            double trig,double rr,double risk,double reward,string extra)
{
   if(logh==INVALID_HANDLE) return;
   datetime event_time_server=TimeTradeServer();
   FileWrite(logh,TimeToString(event_time_server,TIME_DATE|TIME_SECONDS),
      TimeToString((datetime)t.time,TIME_DATE|TIME_SECONDS),ev,
      (string)business_seq,(string)t.time_msc,(dir>0?"BUY":dir<0?"SELL":""),
      DoubleToString(origin,price_digits),DoubleToString(target,price_digits),
      DoubleToString(trig,price_digits),DoubleToString(rr,6),
      DoubleToString(risk,3),DoubleToString(reward,3),
      DoubleToString(t.bid,price_digits),DoubleToString(t.ask,price_digits),
      DoubleToString(t.last,price_digits),extra);
   FileFlush(logh);
}
void DeleteFiboObjects()
{
   for(int i=ObjectsTotal(0,0,-1)-1;i>=0;i--)
   {
      if(IsStopped()) return;
      string n=ObjectName(0,i,0,-1);
      if(StringFind(n,"MINO_F_")==0) ObjectDelete(0,n);
   }
}
void AddLine(double price,bool macro,string label)
{
   int n=ArraySize(lines); ArrayResize(lines,n+1);
   lines[n].price=RoundTick(price); lines[n].macro=macro;
   lines[n].label=label; lines[n].active=false;
}
void SortDedup()
{
   int n=ArraySize(lines);
   for(int i=1;i<n;i++)
   {
      FiboLine k=lines[i]; int j=i-1;
      while(j>=0 && lines[j].price>k.price){ lines[j+1]=lines[j]; j--; }
      lines[j+1]=k;
   }
   FiboLine tmp[]; ArrayResize(tmp,0);
   for(int i=0;i<n;i++)
   {
      int m=ArraySize(tmp);
      if(m==0 || !Eq(tmp[m-1].price,lines[i].price))
      {
         ArrayResize(tmp,m+1); tmp[m]=lines[i];
      }
      else if(lines[i].macro && !tmp[m-1].macro) tmp[m-1]=lines[i];
   }
   ArrayResize(lines,ArraySize(tmp));
   for(int i=0;i<ArraySize(tmp);i++) lines[i]=tmp[i];
}
void DrawGrid()
{
   if(IsStopped()) return;
   DeleteFiboObjects();
   if(IsStopped() || !InpDrawFibos) return;
   for(int i=0;i<ArraySize(lines);i++)
   {
      if(IsStopped()) return;
      string n=StringFormat("MINO_F_%03d",i);
      if(!ObjectCreate(0,n,OBJ_HLINE,0,0,lines[i].price)) continue;
      ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,n,OBJPROP_BACK,true);
      ObjectSetInteger(0,n,OBJPROP_WIDTH,lines[i].macro?2:1);
      ObjectSetInteger(0,n,OBJPROP_STYLE,lines[i].macro?STYLE_SOLID:STYLE_DOT);
      ObjectSetInteger(0,n,OBJPROP_COLOR,lines[i].macro?clrDarkGoldenrod:clrDimGray);
      ObjectSetString(0,n,OBJPROP_TOOLTIP,lines[i].label);
   }
}
bool ValidD1Bar(const MqlRates &b)
{
   if(b.high<=b.low || b.low<=0 || b.open<=0 || b.close<=0) return false;
   if(b.open>b.high || b.open<b.low || b.close>b.high || b.close<b.low) return false;
   return true;
}
bool ExpectedPreviousSession(datetime now,int &expected)
{
   if(!SymbolSelect(sym,true)) return false;
   MqlRates r[]; ArraySetAsSeries(r,true);
   int c=CopyRates(sym,PERIOD_D1,0,30,r);
   if(c<=0) return false;
   int today=DateKey(now),best=0,count=0;
   for(int i=0;i<c;i++)
   {
      int d=DateKey(r[i].time);
      if(d<today && d>best){ best=d; count=1; }
      else if(d==best && best>0) count++;
   }
   if(best<=0 || count!=1) return false;
   expected=best; return true;
}
bool PreviousIND(datetime now,double &hi,double &lo,string &info)
{
   int expected=0;
   if(!ExpectedPreviousSession(now,expected))
   {
      state_fault="EXPECTED_PREVIOUS_SESSION_UNAVAILABLE"; return false;
   }
   expected_d1_date=expected;

   if(InpUseManualPrevIND)
   {
      if(InpManualPrevINDDate!=expected || InpManualPrevHigh<=InpManualPrevLow || InpManualPrevLow<=0)
      {
         state_fault="MANUAL_D1_DATE_OR_OHLC_INVALID"; return false;
      }
      hi=InpManualPrevHigh; lo=InpManualPrevLow; effective_d1_date=expected;
      info=StringFormat("MANUAL D1 %d",expected); return true;
   }

   if(!SymbolSelect(refsym,true)){ state_fault="REFERENCE_SYMBOL_SELECT_FAIL"; return false; }
   MqlRates r[]; ArraySetAsSeries(r,true);
   int c=CopyRates(refsym,PERIOD_D1,0,40,r);
   if(c<=0){ state_fault="REFERENCE_D1_READ_FAIL"; return false; }

   int matches=0; MqlRates chosen; ZeroMemory(chosen);
   for(int i=0;i<c;i++)
   {
      if(DateKey(r[i].time)==expected){ chosen=r[i]; matches++; }
   }
   if(matches!=1){ state_fault=(matches==0?"EXPECTED_D1_MISSING":"EXPECTED_D1_DUPLICATE"); return false; }
   if(!ValidD1Bar(chosen)){ state_fault="EXPECTED_D1_OHLC_INVALID"; return false; }

   hi=chosen.high; lo=chosen.low; effective_d1_date=DateKey(chosen.time);
   if(effective_d1_date!=expected_d1_date){ state_fault="D1_REFERENCE_DATE_MISMATCH"; return false; }
   info=refsym+" D1 "+DateText(chosen.time); return true;
}
bool BuildGrid(datetime now)
{
   double hi,lo; string info;
   if(!PreviousIND(now,hi,lo,info))
   {
      grid_ok=false; status_text="GRID_BLOCKED_REFERENCE "+state_fault; return false;
   }
   double rg=hi-lo; if(rg<=0){ grid_ok=false; state_fault="D1_RANGE_INVALID"; return false; }
   ref_high=hi; ref_low=lo; ref_range=rg; refinfo=info;
   double anchor_raw=lo+rg*(InpProjectionPct/100.0);

   ArrayResize(lines,0);
   double macro_raw[9]; int z=0;
   for(int k=-4;k<=4;k++)
   {
      macro_raw[z]=anchor_raw+k*rg;
      AddLine(macro_raw[z],true,StringFormat("MACRO k=%d",k)); z++;
   }
   for(int b=0;b<8;b++)
   {
      for(int p=0;p<11;p++)
      {
         double micro_raw=macro_raw[b]+rg*MICRO_PCTS[p];
         AddLine(micro_raw,false,StringFormat("MICRO b=%d %.1f%%",b,MICRO_PCTS[p]*100.0));
      }
   }
   SortDedup();
   if(ArraySize(lines)!=97)
   {
      grid_ok=false; state_fault="GEOMETRY_LINE_COUNT_NOT_97"; return false;
   }
   // Nao limpar pending aqui: startup recovery pode ter restaurado N valido.
   grid_day=DateKey(now); state_session_day=grid_day;
   grid_ok=true; state_fault=""; status_text="GRID_READY";
   WriteState(); DrawGrid();
   Print(VERSION_NAME," GRID READY ",grid_day," ",refinfo," range=",rg,
         " lines=",ArraySize(lines)," expected_d1=",expected_d1_date,
         " effective_d1=",effective_d1_date);
   return true;
}
bool CutoffReached(datetime t)
{
   if(t<=0) return true;
   return SecondsOfDay(t)>=CUTOFF_SECONDS;
}
void LogSimple(string ev,string extra)
{
   MqlTick t; ZeroMemory(t); SymbolInfoTick(sym,t);
   LogEvt(ev,t,0,0,0,0,0,0,0,extra);
}
bool CancelOwnOrders()
{
   bool ok=true;
   for(int i=OrdersTotal()-1;i>=0;i--)
   {
      ulong ticket=OrderGetTicket(i);
      if(ticket==0) continue;
      if(OrderGetString(ORDER_SYMBOL)!=sym) continue;
      if((ulong)OrderGetInteger(ORDER_MAGIC)!=InpMagic) continue;
      bool call_ok=trade.OrderDelete(ticket);
      bool accepted=TradeResultAccepted(call_ok);
      string detail=StringFormat("ticket=%I64u ret=%u %s",
                                 ticket,trade.ResultRetcode(),trade.ResultRetcodeDescription());
      if(!accepted){ ok=false; LogSimple("CUTOFF_ORDER_DELETE_FAIL",detail); }
      else LogSimple("CUTOFF_ORDER_DELETE_OK",detail);
   }
   return ok;
}
void ApplyCutoffSafety()
{
   datetime now=TimeTradeServer();
   if(!CutoffReached(now)) return;

   if(!cutoff_latched)
   {
      cutoff_latched=true; ResetPending(); request_phase="CUTOFF";
      WriteState();
      LogSimple("LIVE_OPERATIONAL_CUTOFF_1803",
         StringFormat("pending cleared; reentry blocked; decision_server_time=%s cutoff_seconds=%d",
                      TimeToString(now,TIME_DATE|TIME_SECONDS),CUTOFF_SECONDS));
   }

   // Conta DEMO preserva o comportamento R3. Conta REAL so altera estado broker
   // quando o armamento REAL esta explicito e o binding login+servidor e exato.
   bool broker_control=false;
   string control_mode="",bind_why="";
   if(IsDemoAccount())
   {
      broker_control=true;
      control_mode="demo";
   }
   else if(IsRealAccount())
   {
      bool own_exposure=(OwnPositionExists() || OwnWorkingOrderExists());
      bool binding_ok=RealAccountBindingOk(bind_why);
      if(REAL_MONEY_ORDER_SEND_CAPABLE && binding_ok && (InpEnableRealOrders || own_exposure))
      {
         broker_control=true;
         control_mode=(InpEnableRealOrders?"real_bound":"real_bound_manage_only");
      }
      else
      {
         static bool real_cutoff_block_logged=false;
         if(!real_cutoff_block_logged)
         {
            string why=(!REAL_MONEY_ORDER_SEND_CAPABLE?"REAL_SEND_NOT_CAPABLE":
                        !binding_ok?bind_why:
                        !InpEnableRealOrders && !own_exposure?"REAL_SHADOW_NO_OWN_EXPOSURE":"REAL_BROKER_CONTROL_BLOCKED");
            LogSimple("CUTOFF_REAL_BROKER_ACTION_BLOCKED",why);
            real_cutoff_block_logged=true;
         }
         return;
      }
   }
   if(!broker_control) return;

   // Em conta NETTING, qualquer exposicao/ordem estrangeira no mesmo simbolo
   // torna ownership ambiguo. Nao tocar estado broker nesse caso.
   if(ForeignPositionExists())
   {
      state_fault="CUTOFF_FOREIGN_POSITION_PRESENT";
      recovery_ok=false; WriteState();
      LogSimple("CUTOFF_OWNERSHIP_AMBIGUOUS",state_fault);
      return;
   }
   if(ForeignWorkingOrderExists())
   {
      state_fault="CUTOFF_FOREIGN_WORKING_ORDER_PRESENT";
      recovery_ok=false; WriteState();
      LogSimple("CUTOFF_OWNERSHIP_AMBIGUOUS",state_fault);
      return;
   }

   CancelOwnOrders();
   if(OwnPositionExists())
   {
      bool call_ok=trade.PositionClose(sym);
      bool accepted=TradeResultAccepted(call_ok);
      string detail=StringFormat("%s ret=%u %s",
                                 control_mode,trade.ResultRetcode(),trade.ResultRetcodeDescription());
      if(accepted)
      {
         request_phase="CUTOFF_CLOSE_ACCEPTED"; WriteState();
         LogSimple("CUTOFF_POSITION_CLOSE_ACCEPTED",detail);
      }
      else
         LogSimple("CUTOFF_POSITION_CLOSE_FAIL",detail);
   }
}
bool OperationalGate(const MqlTick &t,string &why)
{
   if(!recovery_ok || StringLen(state_fault)>0){ why="STATE_NOT_READY "+state_fault; return false; }
   if(request_phase=="PRE_SEND" || request_phase=="SEND_ACCEPTED")
   { why="REQUEST_PHASE_UNRECONCILED "+request_phase; return false; }
   if(cutoff_latched || CutoffReached((datetime)t.time)){ why="CUTOFF_1803"; return false; }
   if(!grid_ok || expected_d1_date<=0 || effective_d1_date!=expected_d1_date){ why="D1_OR_GEOMETRY_NOT_READY"; return false; }
   if(!AccountIdentityOk(why)) return false;
   if(!SymbolOperationalOk(why)) return false;
   if(!TradePermitted()){ why="TRADE_PERMISSIONS_OFF"; return false; }
   if(PositionExists()){ why=(OwnPositionExists()?"OWN_POSITION_EXISTS":"FOREIGN_POSITION_EXISTS"); return false; }
   if(OwnWorkingOrderExists()){ why="OWN_WORKING_ORDER_EXISTS"; return false; }
   if(ForeignWorkingOrderExists()){ why="FOREIGN_WORKING_ORDER_EXISTS"; return false; }
   why="OK"; return true;
}
bool CausalQuoteFresh(const MqlTick &t,string &why,long &age)
{
   if(market_bid_msc==0 || market_ask_msc==0 ||
      market_bid<=0 || market_ask<=0 || market_ask<market_bid)
   {
      why="NO_VALID_CAUSAL_BBO"; age=-1; return false;
   }
   if(t.time_msc<market_bid_msc || t.time_msc<market_ask_msc)
   {
      why="CAUSAL_BBO_CLOCK_REGRESSION"; age=-1; return false;
   }

   long bid_age=(long)(t.time_msc-market_bid_msc);
   long ask_age=(long)(t.time_msc-market_ask_msc);
   age=(bid_age>ask_age?bid_age:ask_age);
   market_quote_msc=(market_bid_msc<market_ask_msc?market_bid_msc:market_ask_msc);

   if(bid_age>MAX_CAUSAL_QUOTE_AGE_MS || ask_age>MAX_CAUSAL_QUOTE_AGE_MS)
   {
      why=StringFormat("STALE_CAUSAL_BBO bid_age_ms=%d ask_age_ms=%d max_ms=%d",
                       (int)bid_age,(int)ask_age,MAX_CAUSAL_QUOTE_AGE_MS);
      return false;
   }
   why="OK"; return true;
}
bool StopsValid(int dir,double bid,double ask,double sl,double tp,string &why)
{
   double px=(dir>0?ask:bid);
   if(px<=0)
   {
      why=StringFormat("NO_CAUSAL_QUOTE bid=%.*f ask=%.*f qmsc=%I64d",
                       price_digits,bid,price_digits,ask,market_quote_msc);
      return false;
   }
   if(dir>0 && !(sl<px && tp>px)){ why="BUY_INVALID"; return false; }
   if(dir<0 && !(sl>px && tp<px)){ why="SELL_INVALID"; return false; }
   long level=SymbolInfoInteger(sym,SYMBOL_TRADE_STOPS_LEVEL);
   double md=level*point_size;
   if(md>0)
   {
      if(dir>0 && ((px-sl)<md || (tp-px)<md)){ why="STOPS_LEVEL"; return false; }
      if(dir<0 && ((sl-px)<md || (px-tp)<md)){ why="STOPS_LEVEL"; return false; }
   }
   why="OK"; return true;
}
void ExecutePending(const MqlTick &t)
{
   if(!pending.active || business_seq<=pending.trigger_seq) return;
   Signal p=pending; ResetPending(); WriteState();

   string gate;
   if(!OperationalGate(t,gate))
   {
      LogEvt("BLOCK_OPERATIONAL_GATE",t,p.dir,p.origin,p.target,p.trigger_price,
             p.rr_trigger,p.risk_ticks,p.reward_ticks,gate);
      status_text="BLOCK "+gate; return;
   }

   long quote_age_ms=-1; string quote_why;
   if(!CausalQuoteFresh(t,quote_why,quote_age_ms))
   {
      LogEvt("BLOCK_STALE_CAUSAL_QUOTE",t,p.dir,p.origin,p.target,p.trigger_price,
             p.rr_trigger,p.risk_ticks,p.reward_ticks,quote_why);
      status_text="BLOCK "+quote_why; return;
   }

   double sl=NPrice(p.origin), tp=NPrice(p.target);
   MqlTick exec_tick=t; exec_tick.bid=market_bid; exec_tick.ask=market_ask;

   string why;
   if(!StopsValid(p.dir,market_bid,market_ask,sl,tp,why))
   {
      LogEvt("ENTRY_INVALIDATED_N1",exec_tick,p.dir,p.origin,p.target,p.trigger_price,
             p.rr_trigger,p.risk_ticks,p.reward_ticks,why);
      status_text="ENTRY_INVALIDATED "+why; return;
   }

   double mkt=(p.dir>0?market_ask:market_bid);
   double risk=MathAbs(mkt-p.origin)/tick_size;
   double reward=((p.target-mkt)*p.dir)/tick_size;
   double rr_actual=(risk>0?reward/risk:0);
   double vol=NormVolume(InpLots);

   string common=StringFormat("mkt=%.*f rr_send=%.4f quote_msc=%I64d quote_age_ms=%d bid_msc=%I64d ask_msc=%I64d sl=%.*f tp=%.*f vol=%.2f",
      price_digits,mkt,rr_actual,market_quote_msc,(int)quote_age_ms,
      market_bid_msc,market_ask_msc,price_digits,sl,price_digits,tp,vol);

   bool demo_mode=IsDemoAccount();
   bool real_mode=IsRealAccount();
   string send_mode="";

   if(demo_mode)
   {
      if(!InpEnableDemoOrders)
      {
         LogEvt("BLOCK_INPUT",exec_tick,p.dir,p.origin,p.target,p.trigger_price,
                p.rr_trigger,p.risk_ticks,p.reward_ticks,"InpEnableDemoOrders=false");
         return;
      }
      send_mode="DEMO";
   }
   else if(real_mode)
   {
      string bind_why;
      if(!InpEnableRealOrders)
      {
         request_phase="REAL_SHADOW"; WriteState();
         LogEvt("REAL_SHADOW_WOULD_SEND",exec_tick,p.dir,p.origin,p.target,p.trigger_price,
                p.rr_trigger,p.risk_ticks,p.reward_ticks,common+" real_enable=NO");
         request_phase="RECONCILED"; WriteState();
         status_text="REAL_SHADOW_WOULD_SEND"; return;
      }
      if(!REAL_MONEY_ORDER_SEND_CAPABLE || !RealAccountBindingOk(bind_why))
      {
         string why=(!REAL_MONEY_ORDER_SEND_CAPABLE?"REAL_SEND_NOT_CAPABLE":bind_why);
         LogEvt("BLOCK_REAL_ACCOUNT_BINDING",exec_tick,p.dir,p.origin,p.target,p.trigger_price,
                p.rr_trigger,p.risk_ticks,p.reward_ticks,why);
         status_text="BLOCK "+why; return;
      }
      send_mode="REAL";
   }
   else
   {
      LogEvt("BLOCK_ACCOUNT_MODE",exec_tick,p.dir,p.origin,p.target,p.trigger_price,
             p.rr_trigger,p.risk_ticks,p.reward_ticks,"ACCOUNT_MODE_UNSUPPORTED");
      status_text="BLOCK ACCOUNT_MODE_UNSUPPORTED"; return;
   }

   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(InpDeviationPoints);
   trade.SetAsyncMode(false);
   trade.SetTypeFillingBySymbol(sym);

   common+=" mode="+send_mode;
   request_phase="PRE_SEND"; WriteState();
   LogEvt("PRE_SEND",exec_tick,p.dir,p.origin,p.target,p.trigger_price,
          p.rr_trigger,p.risk_ticks,p.reward_ticks,common);

   string order_comment=(real_mode?"MINO V003R1 R6 REAL":"MINO V003R1 R6 DEMO");
   bool call_ok=(p.dir>0 ? trade.Buy(vol,sym,0,sl,tp,order_comment) :
                           trade.Sell(vol,sym,0,sl,tp,order_comment));
   bool accepted=TradeResultAccepted(call_ok);

   request_phase=(accepted?"SEND_ACCEPTED":"SEND_REJECTED"); WriteState();
   string extra=common+StringFormat(" call_ok=%s ret=%u %s",
      call_ok?"YES":"NO",trade.ResultRetcode(),trade.ResultRetcodeDescription());
   LogEvt(accepted?"ORDER_ACCEPTED":"ORDER_FAIL",exec_tick,p.dir,p.origin,p.target,p.trigger_price,
          p.rr_trigger,p.risk_ticks,p.reward_ticks,extra);
   if(!accepted){ request_phase="RECONCILED"; WriteState(); }
   status_text=(accepted?"ORDER_ACCEPTED ":"ORDER_FAIL ")+trade.ResultRetcodeDescription();
}
void ProcessEpisodes(const MqlTick &t)
{
   if(!grid_ok || !have_prev_business) return;

   int eligible_count=0, ci=-1, cdir=0;
   double corigin=0,ctarget=0,ctrig=0,crr=0,crisk=0,creward=0;

   double prev=prev_business_price, cur=t.last;
   for(int i=0;i<ArraySize(lines);i++)
   {
      double line=lines[i].price;
      bool interaction=Eq(prev,line)||Eq(cur,line)||
         (prev<line && cur>line)||(prev>line && cur<line);
      if(interaction && !lines[i].active) lines[i].active=true;
      if(!lines[i].active) continue;

      double risk=MathAbs(cur-line)/tick_size;
      if(risk+1e-9<InpTriggerTicks) continue;

      int dir=(cur>line?1:cur<line?-1:0);
      lines[i].active=false; // evento antes do fechamento, depois fecha no mesmo tick
      if(dir==0) continue;

      int ti=i+dir;
      if(ti<0 || ti>=ArraySize(lines)) continue;
      double target=lines[ti].price;
      double reward=((target-cur)*dir)/tick_size;
      if(reward<=0)
      {
         LogEvt("TARGET_ALREADY_PASSED",t,dir,line,target,cur,0,risk,reward,lines[i].label);
         continue;
      }
      double rr=reward/risk;
      LogEvt("TRIGGER",t,dir,line,target,cur,rr,risk,reward,lines[i].label);
      if(rr+1e-12<InpMinRRTrigger) continue;

      eligible_count++;
      ci=i; cdir=dir; corigin=line; ctarget=target; ctrig=cur;
      crr=rr; crisk=risk; creward=reward;
   }

   if(eligible_count==0) return;
   if(pending.active || PositionExists())
   {
      LogEvt("ELIGIBLE_SKIPPED_BUSY",t,cdir,corigin,ctarget,ctrig,crr,crisk,creward,"");
      return;
   }
   if(eligible_count>1)
   {
      LogEvt("AMBIGUOUS_MULTI_SIGNAL",t,0,0,0,cur,0,0,0,
         "no trade: no canonical tiebreak");
      status_text="AMBIGUOUS_MULTI_SIGNAL_NO_TRADE"; return;
   }

   pending.active=true; pending.dir=cdir; pending.origin=corigin; pending.target=ctarget;
   pending.trigger_price=ctrig; pending.rr_trigger=crr; pending.risk_ticks=crisk;
   pending.reward_ticks=creward; pending.trigger_seq=business_seq;

   // Cursor fisico exato de N. cursor_same_count inclui todos os registros
   // fisicos ja consumidos neste mesmo time_msc, nao apenas BUSINESS.
   pending.trigger_time=(long)t.time;
   pending.trigger_msc=t.time_msc;
   pending.trigger_same_count=cursor_same_count;
   pending.trigger_flags=t.flags;
   pending.trigger_volume=t.volume;
   pending.trigger_volume_real=t.volume_real;
   WriteState();
   LogEvt("PENDING_N",t,cdir,corigin,ctarget,ctrig,crr,crisk,creward,
      "decision at N; entry only next business tick");
   status_text=StringFormat("PENDING %s RRtr=%.2f",cdir>0?"BUY":"SELL",crr);
}
bool RefreshGrid(const MqlTick &t)
{
   int d=DateKey((datetime)t.time);
   if(grid_ok && d==grid_day) return true;

   if(state_session_day!=0 && d!=state_session_day)
   {
      if(OwnPositionExists() || OwnWorkingOrderExists())
      {
         state_fault="BROKER_STATE_CROSSES_SESSION"; recovery_ok=false; return false;
      }
      cutoff_latched=false; request_phase="RECONCILED"; state_fault="";
   }
   have_prev_business=false; ResetPending(); WriteState();
   return BuildGrid((datetime)t.time);
}
void ProcessBusiness(const MqlTick &t)
{
   if(!RefreshGrid(t)) return;
   if(CutoffReached((datetime)t.time)){ ApplyCutoffSafety(); return; }
   business_seq++;
   ExecutePending(t);       // N+1: primeiro executa pending de N
   if(have_prev_business) ProcessEpisodes(t);
   prev_business_price=t.last; have_prev_business=true;
}
bool PrimeCursor()
{
   MqlTick cur;
   if(!SymbolInfoTick(sym,cur) || cur.time_msc==0) return false;
   UpdateKnownQuote(cur);
   ulong from=(ulong)(cur.time_msc>1000?cur.time_msc-1000:1);
   MqlTick a[];
   int n=CopyTicks(sym,a,COPY_TICKS_ALL,from,10000);
   if(n<=0)
   {
      cursor_msc=cur.time_msc; cursor_same_count=1; cursor_ok=true;
      if(BusinessTick(cur)){ prev_business_price=cur.last; have_prev_business=true; }
      return true;
   }
   cursor_msc=a[n-1].time_msc; cursor_same_count=0;
   for(int i=n-1;i>=0 && a[i].time_msc==cursor_msc;i--) cursor_same_count++;
   for(int i=n-1;i>=0;i--)
      if(BusinessTick(a[i])){ prev_business_price=a[i].last; have_prev_business=true; break; }
   cursor_ok=true;
   Print(VERSION_NAME," CURSOR ",cursor_msc," same_ms=",cursor_same_count);
   return true;
}
void PumpTicks()
{
   if(IsStopped()) return;
   if(!cursor_ok && !PrimeCursor()) return;

   for(int loop=0;loop<20;loop++)
   {
      if(IsStopped()) return;

      long start=cursor_msc; int skip=cursor_same_count;
      MqlTick a[];
      int n=CopyTicks(sym,a,COPY_TICKS_ALL,(ulong)start,COPY_BATCH);
      if(n<=0 || IsStopped()) return;

      int seen=0,newn=0;
      for(int i=0;i<n;i++)
      {
         if(IsStopped()) return;

         long m=a[i].time_msc;
         if(m<start) continue;
         if(m==start){ seen++; if(seen<=skip) continue; }

         if(m==cursor_msc) cursor_same_count++;
         else { cursor_msc=m; cursor_same_count=1; }
         newn++;

         // Atualiza BID/ASK na ordem fisica do tick stream.
         // Se este for um business tick com bid/ask=0, preserva o ultimo
         // quote causal conhecido; nao usa informacao posterior no mesmo ms.
         UpdateKnownQuote(a[i]);

         if(BusinessTick(a[i])) ProcessBusiness(a[i]);
      }
      if(n<COPY_BATCH || newn==0) break;
   }
}
void Dashboard()
{
   string g=(grid_ok?StringFormat("GRID %d %s range=%.0f",grid_day,refinfo,ref_range):"GRID NOT READY");
   string p=(pending.active?StringFormat("PENDING %s RRtr=%.2f",pending.dir>0?"BUY":"SELL",pending.rr_trigger):"PENDING NO");
   Comment(VERSION_NAME,"\nCANONICAL R1 | R6 REAL-CAPABLE FAIL-CLOSED\n",
      sym," | Ref ",refsym,"\n",
      ExecutionModeText()," | ",
      TradePermitted()?"TRADE_PERMS_OK":"TRADE_PERMS_OFF"," | ",
      recovery_ok?"RECOVERY_OK":"RECOVERY_BLOCKED"," | ",
      cutoff_latched?"CUTOFF_LATCHED":"CUTOFF_OPEN","\n",
      "D1 expected=",expected_d1_date," effective=",effective_d1_date,"\n",
      g,"\nTrigger=",InpTriggerTicks,"T | RR_trigger>=",DoubleToString(InpMinRRTrigger,2),
      " | quote_age_max=",MAX_CAUSAL_QUOTE_AGE_MS,"ms",
      " | SL=origem | TP=proxima Fibo\n",p,
      "\nQuote BID=",DoubleToString(market_bid,price_digits),
      " ASK=",DoubleToString(market_ask,price_digits),
      " bid_msc=",(string)market_bid_msc,
      " ask_msc=",(string)market_ask_msc,
      " qmsc=",(string)market_quote_msc,
      "\nState=",request_phase," fault=",state_fault,
      "\nStartup=",startup_runtime_ready?"READY":(startup_fatal?"FATAL":"WAIT"),
      " reason=",startup_wait_reason,
      "\nSeq=",business_seq,"\n",status_text);
}
bool RetryableGridStartupReason(string why)
{
   return (why=="EXPECTED_PREVIOUS_SESSION_UNAVAILABLE" ||
           why=="REFERENCE_SYMBOL_SELECT_FAIL" ||
           why=="REFERENCE_D1_READ_FAIL" ||
           why=="EXPECTED_D1_MISSING");
}
void SetStartupWait(string why)
{
   datetime now=TimeTradeServer();
   bool changed=(startup_wait_reason!=why);
   startup_wait_reason=why;
   status_text="STARTUP_WAIT "+why;

   if(changed || startup_wait_last_report==0 ||
      (now>0 && startup_wait_last_report>0 && now-startup_wait_last_report>=60))
   {
      long mode=SymbolInfoInteger(sym,SYMBOL_TRADE_MODE);
      LogSimple("STARTUP_WAIT",
         StringFormat("reason=%s retry_seconds=1 symbol_trade_mode=%I64d state_initialized=%s reconciled=%s grid_ok=%s cursor_ok=%s",
            why,mode,state_initialized?"YES":"NO",startup_reconciled?"YES":"NO",
            grid_ok?"YES":"NO",cursor_ok?"YES":"NO"));
      Print(VERSION_NAME," STARTUP WAIT ",why," | retry=1s | symbol_trade_mode=",mode);
      startup_wait_last_report=now;
   }
}
bool SetStartupFatal(string why)
{
   startup_fatal=true;
   startup_runtime_ready=false;
   state_fault=why;
   recovery_ok=false;
   status_text="STARTUP_FATAL "+why;
   LogSimple("STARTUP_FATAL",why);
   Print(VERSION_NAME," STARTUP FATAL ",why);
   return false;
}
bool TryCompleteStartup()
{
   if(startup_runtime_ready) return true;
   if(startup_fatal) return false;

   string why;
   if(!AccountIdentityOk(why))
      return SetStartupFatal(why);

   if(!SymbolOperationalOk(why))
   {
      if(why=="SYMBOL_SELECT_FAIL" || why=="SYMBOL_TRADE_MODE_NOT_FULL")
      {
         SetStartupWait(why);
         return true;
      }
      return SetStartupFatal(why);
   }

   // O contrato do simbolo so e congelado depois que o simbolo fica operacional.
   tick_size=SymbolInfoDouble(sym,SYMBOL_TRADE_TICK_SIZE);
   point_size=SymbolInfoDouble(sym,SYMBOL_POINT);
   price_digits=(int)SymbolInfoInteger(sym,SYMBOL_DIGITS);

   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(InpDeviationPoints);
   trade.SetAsyncMode(false);
   trade.SetTypeFillingBySymbol(sym);

   if(!state_initialized)
   {
      state_initialized=true;
      if(!LoadState())
         return SetStartupFatal(state_fault);
   }

   if(!startup_reconciled)
   {
      if(!ReconcileStartup())
         return SetStartupFatal("RECOVERY "+state_fault);
      startup_reconciled=true;
   }

   if(!grid_ok)
   {
      if(!BuildGrid(TimeTradeServer()))
      {
         string grid_why=state_fault;
         if(RetryableGridStartupReason(grid_why))
         {
            SetStartupWait(grid_why);
            return true;
         }
         return SetStartupFatal("GRID "+grid_why);
      }
   }

   if(!startup_pending_checked)
   {
      if(pending.active && !RecoverPendingN1Physical())
         return SetStartupFatal("PENDING RECOVERY "+state_fault);
      startup_pending_checked=true;
   }

   if(!cursor_ok)
   {
      if(!PrimeCursor())
      {
         SetStartupWait("CURSOR_PRIME_UNAVAILABLE");
         return true;
      }
   }

   ApplyCutoffSafety();

   string recovered_from=startup_wait_reason;
   startup_wait_reason="";
   startup_runtime_ready=true;
   startup_fatal=false;
   status_text="READY";

   LogSimple("STARTUP_READY",
      StringFormat("recovered_from=%s schema=%d build_revision=%d pending=%s business_seq=%I64u cursor_msc=%I64d cursor_same=%d",
         (StringLen(recovered_from)>0?recovered_from:"DIRECT"),STATE_SCHEMA,BUILD_REVISION,
         pending.active?"YES":"NO",business_seq,cursor_msc,cursor_same_count));
   LogSimple("RECOVERY_READY",
      StringFormat("schema=%d build_revision=%d pending=%s business_seq=%I64u cursor_msc=%I64d cursor_same=%d",
         STATE_SCHEMA,BUILD_REVISION,pending.active?"YES":"NO",
         business_seq,cursor_msc,cursor_same_count));

   Print(VERSION_NAME," INIT OK | MODE=",ExecutionModeText(),
      " | magic=",InpMagic,
      " | decision=N RR_trigger | entry=N+1 business tick",
      " | max_quote_age_ms=",MAX_CAUSAL_QUOTE_AGE_MS,
      " | state_schema=",STATE_SCHEMA,
      " | build_revision=",BUILD_REVISION,
      " | real_enable_input=",(InpEnableRealOrders?"YES":"NO"));
   Dashboard();
   return true;
}
int OnInit()
{
   ResetPending();
   sym=(StringLen(InpTradeSymbol)>0?InpTradeSymbol:_Symbol);
   refsym=InpReferenceSymbol;

   startup_login=AccountInfoInteger(ACCOUNT_LOGIN);
   startup_server=AccountInfoString(ACCOUNT_SERVER);
   startup_trade_mode=AccountInfoInteger(ACCOUNT_TRADE_MODE);
   demo_ok=IsDemoAccount();

   if(InpMagic!=FROZEN_MAGIC || InpTriggerTicks!=10 ||
      MathAbs(InpMinRRTrigger-5.0)>1e-12 || MathAbs(InpProjectionPct-61.8)>1e-12 ||
      MathAbs(InpExpectedTickSize-5.0)>1e-12)
   {
      Print(VERSION_NAME," INIT FAILED: FROZEN_PARAMETER_MISMATCH");
      return INIT_PARAMETERS_INCORRECT;
   }

   string why;
   if(!AccountIdentityOk(why))
   {
      Print(VERSION_NAME," INIT FAILED ",why);
      return INIT_FAILED;
   }

   if(InpEnableRealOrders)
   {
      if(!REAL_MONEY_ORDER_SEND_CAPABLE)
      {
         Print(VERSION_NAME," INIT FAILED REAL_SEND_NOT_CAPABLE");
         return INIT_PARAMETERS_INCORRECT;
      }
      if(!RealAccountBindingOk(why))
      {
         Print(VERSION_NAME," INIT FAILED ",why);
         return INIT_PARAMETERS_INCORRECT;
      }
   }

   OpenLog();
   LogSimple("INIT",StringFormat("parent_sha=04666d28c2c4e85465406fad200635e662cd0411ac5cb359504c201b7bd284b9 magic=%I64u quote_age_max=%d state_schema=%d build_revision=%d real_send_capable=%s real_enable_input=%s mode=%s authorized_login=%I64d authorized_server=%s startup_retry=YES",
      InpMagic,MAX_CAUSAL_QUOTE_AGE_MS,STATE_SCHEMA,BUILD_REVISION,
      (REAL_MONEY_ORDER_SEND_CAPABLE?"YES":"NO"),
      (InpEnableRealOrders?"YES":"NO"),ExecutionModeText(),
      InpAuthorizedLogin,SafeName(InpAuthorizedServer)));

   EventSetTimer(1);

   if(!TryCompleteStartup())
   {
      EventKillTimer();
      if(logh!=INVALID_HANDLE)
      {
         FileFlush(logh); FileClose(logh); logh=INVALID_HANDLE;
      }
      return INIT_FAILED;
   }

   // Uma condicao transitoria (ex.: simbolo ainda fora de FULL antes do leilao)
   // mantem o EA carregado. OnTimer tentara completar o startup a cada segundo.
   if(!startup_runtime_ready)
   {
      Dashboard();
      return INIT_SUCCEEDED;
   }

   return INIT_SUCCEEDED;
}
void OnDeinit(const int reason)
{
   // Lifecycle R3: stop new timer callbacks first and keep shutdown bounded.
   EventKillTimer();

   Print(VERSION_NAME," DEINIT | reason=",reason,
         " | state_schema=",STATE_SCHEMA,
         " | build_revision=",BUILD_REVISION);

   if(logh!=INVALID_HANDLE)
      LogSimple("DEINIT",StringFormat("reason=%d state_schema=%d build_revision=%d",
                                     reason,STATE_SCHEMA,BUILD_REVISION));

   // Final checkpoint is intentionally kept. No chart-object sweep here:
   // graphical cleanup during OnDeinit can prolong terminal shutdown.
   WriteState();

   if(logh!=INVALID_HANDLE)
   {
      FileFlush(logh);
      FileClose(logh);
      logh=INVALID_HANDLE;
   }

   Comment("");
}
void OnTick()
{
   if(IsStopped()) return;
   if(!startup_runtime_ready)
   {
      Dashboard();
      return;
   }
   ApplyCutoffSafety();
   if(!cutoff_latched && !IsStopped()) PumpTicks();
   if(!IsStopped()) Dashboard();
}
void OnTimer()
{
   if(IsStopped()) return;

   if(!startup_runtime_ready)
   {
      if(!startup_fatal) TryCompleteStartup();
      if(!IsStopped()) Dashboard();
      return;
   }

   string why;
   if(!AccountIdentityOk(why) && StringLen(state_fault)==0)
   {
      state_fault=why; recovery_ok=false; WriteState(); LogSimple("ACCOUNT_GATE_BLOCK",why);
   }
   ApplyCutoffSafety();
   if(!cutoff_latched && recovery_ok && !IsStopped()) PumpTicks();
   if(!IsStopped()) Dashboard();
}
void OnTradeTransaction(const MqlTradeTransaction &trans,
                        const MqlTradeRequest &request,
                        const MqlTradeResult &result)
{
   if(trans.type!=TRADE_TRANSACTION_DEAL_ADD || trans.deal==0) return;
   if(!HistoryDealSelect(trans.deal)) return;
   if((ulong)HistoryDealGetInteger(trans.deal,DEAL_MAGIC)!=InpMagic) return;
   if(HistoryDealGetString(trans.deal,DEAL_SYMBOL)!=sym) return;

   MqlTick t; ZeroMemory(t); SymbolInfoTick(sym,t);
   int entry=(int)HistoryDealGetInteger(trans.deal,DEAL_ENTRY);
   string x=StringFormat("deal=%I64u entry=%d type=%d price=%.*f vol=%.2f profit=%.2f comm=%.2f swap=%.2f",
      trans.deal,entry,(int)HistoryDealGetInteger(trans.deal,DEAL_TYPE),price_digits,
      HistoryDealGetDouble(trans.deal,DEAL_PRICE),
      HistoryDealGetDouble(trans.deal,DEAL_VOLUME),
      HistoryDealGetDouble(trans.deal,DEAL_PROFIT),
      HistoryDealGetDouble(trans.deal,DEAL_COMMISSION),
      HistoryDealGetDouble(trans.deal,DEAL_SWAP));
   LogEvt("DEAL",t,0,0,0,0,0,0,0,x);

   request_phase="DEAL_SEEN";
   if(!PositionSelect(sym)) request_phase="FLAT_CONFIRMED";
   WriteState();
   status_text="DEAL "+x;
}
//+------------------------------------------------------------------+
