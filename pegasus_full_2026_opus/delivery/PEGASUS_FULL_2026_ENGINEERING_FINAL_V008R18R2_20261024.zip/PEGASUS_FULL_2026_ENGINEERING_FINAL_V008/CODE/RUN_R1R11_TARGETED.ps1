#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Python)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { throw 'PYTHON_EXECUTABLE_NOT_FOUND' }
Push-Location -LiteralPath $PSScriptRoot
try {
    & $Python -X utf8 -B -m unittest -v test_r1r11_targeted test_r1r11_guards test_r1r11_integration test_r1r11_revision
    $code=$LASTEXITCODE
} finally { Pop-Location }
exit $code
