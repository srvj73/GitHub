param(
    [Parameter(Mandatory=$true)][string]$Mt5Output,
    [string]$Config = "$PSScriptRoot\config.json"
)
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Minotauro_Launcher_Common.ps1"
$TranscriptOwned = Start-MinotauroTranscript -Config $Config -LauncherName $MyInvocation.MyCommand.Name
try {
    if (-not (Test-Path -LiteralPath $Mt5Output -PathType Leaf)) { throw "MT5_OUTPUT_MISSING=$Mt5Output" }
    $Python=Resolve-RealPython
    $ExitCode = Invoke-MinotauroPython -Python $Python -Arguments @("$PSScriptRoot\minotauro_v005r1_r23_gates.py",'geometry-validate','--config',$Config,'--mt5-output',$Mt5Output)
    if ($ExitCode -ne 0) { throw "GEOMETRY_VALIDATE_FAIL=$ExitCode" }
    Write-Host 'GEOMETRY_PARITY_GATE=PASS'
}
finally {
    Stop-MinotauroTranscriptSafe -Owned $TranscriptOwned
}
