from __future__ import annotations

from pathlib import Path
from collections import defaultdict
import argparse
import csv
import gzip
import hashlib
import io
import json
import os
import shutil
import sys
import time
import traceback

from minotauro_v004_core import *
from minotauro_v004_io import *
from minotauro_v004_metrics import aggregate_phase
from minotauro_v005r1_r23_binding import build_binding
from minotauro_v005r1_r23_contract import (
    EXPECTED_CORE_IMPORTED_DEFINITIONS_SHA256,
    EXPECTED_IO_SHA256,
    EXPECTED_PREFLIGHT_SHA256,
    RUNNER_VERSION,
    SPEC_SHA256,
    canonical_json_hash,
    config_hash,
    core_imported_definitions_hash,
    read_json,
    runner_identity,
    gate_identity,
    sha256_file,
    write_json_atomic_canonical,
)
from minotauro_v005r1_r23_outputs import (
    finalize_phase_a,
    iter_committed_trades,
    write_grid_cells,
    write_model_assumptions,
    write_sha_manifest,
)
from minotauro_v005r1_r1r10_memory import (
    MEMORY_CAP_EXIT_CODE,
    MemoryCapSafeStop,
    MemoryMonitor,
    parse_memory_cap_mib,
    progress_suffix,
    telemetry_path,
)

PARSER_VERSION = "MINOTAURO_V004_IO_FROZEN_DC816C61"
REQUIRED_CHECKPOINT_KEYS = {
    "phase", "last_committed_session_date", "spec_sha256", "runner_sha256", "grid_sha256",
    "preflight_status_sha256", "session_calendar_sha256", "expected_sessions_sha256",
    "source_inventory_sha256", "run_source_binding_sha256", "config_sha256", "parser_version",
    "completed", "completed_sessions_sha256", "cash", "hwm", "maxdd", "regime_min",
    "closed_hwm", "closed_maxdd", "verified_months", "runtime_module_hashes",
    "checkpoint_content_sha256",
}


def _fmt_eta(seconds):
    if seconds is None or seconds < 0:
        return "UNKNOWN"
    seconds = int(seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def _run_progress(phase, file_name, overall_bytes, total_bytes, file_bytes, file_size, raw_rows, sessions_done, sessions_total, started, mem_row=None, initial_done=0):
    elapsed = max(time.monotonic() - started, 1e-9)
    source_rate_bps = max(0, overall_bytes) / elapsed
    source_pct = (100.0 * overall_bytes / total_bytes) if total_bytes else 100.0
    global_pct = (100.0 * sessions_done / sessions_total) if sessions_total else 100.0
    new_commits=max(0,int(sessions_done)-int(initial_done))
    commit_rate_per_s=(new_commits/elapsed) if new_commits>0 else 0.0
    eta=((sessions_total-sessions_done)/commit_rate_per_s) if commit_rate_per_s>0 else None
    width = 30
    filled = max(0, min(width, int(width * global_pct / 100.0)))
    bar = "#" * filled + "-" * (width - filled)
    print(
        f"PROGRESS=[{bar}] PCT={global_pct:6.2f} PHASE={phase} COMMITTED={sessions_done}/{sessions_total} "
        f"SOURCE_PCT={source_pct:6.2f} FILE={file_name} "
        f"FILE_GIB={file_bytes/1024**3:.3f}/{file_size/1024**3:.3f} "
        f"TOTAL_GIB={overall_bytes/1024**3:.3f}/{total_bytes/1024**3:.3f} "
        f"ROWS={raw_rows} RATE_SESSIONS_MIN={commit_rate_per_s*60:.3f} "
        f"SOURCE_RATE_MIB_S={source_rate_bps/1024**2:.2f} ETA={_fmt_eta(eta)}"
        f"{progress_suffix(mem_row)}",
        flush=True,
    )


def gzjson(path: Path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0, compresslevel=6) as gz:
            with io.TextIOWrapper(gz, encoding="utf-8", newline="\n") as t:
                for r in rows:
                    t.write(json.dumps(r, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n")
    os.replace(tmp, path)


def rgz(path: Path):
    with gzip.open(path, "rt", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                yield json.loads(line)


def cal(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f, delimiter=";"))


def _hash_completed(completed: list[str]) -> str:
    return hashlib.sha256(("\n".join(sorted(completed)) + "\n").encode("ascii")).hexdigest().upper()


def _checkpoint_with_hash(cp: dict) -> dict:
    out = dict(cp)
    out["checkpoint_content_sha256"] = canonical_json_hash(out, exclude_keys={"checkpoint_content_sha256"})
    return out


def _write_checkpoint(path: Path, cp: dict) -> None:
    cp["completed"] = sorted(set(cp.get("completed", [])))
    cp["completed_sessions_sha256"] = _hash_completed(cp["completed"])
    cp2 = _checkpoint_with_hash(cp)
    cp.clear(); cp.update(cp2)
    write_json_atomic_canonical(path, cp)


def _verify_checkpoint_self(cp: dict) -> None:
    missing = REQUIRED_CHECKPOINT_KEYS - set(cp)
    if missing:
        raise ModelError("RESUME_HASH_MISMATCH CHECKPOINT_MISSING_KEYS=" + ",".join(sorted(missing)))
    expected = canonical_json_hash(cp, exclude_keys={"checkpoint_content_sha256"})
    if cp.get("checkpoint_content_sha256") != expected:
        raise ModelError("RESUME_HASH_MISMATCH CHECKPOINT_CONTENT_HASH")
    if cp.get("completed_sessions_sha256") != _hash_completed(cp.get("completed", [])):
        raise ModelError("RESUME_HASH_MISMATCH COMPLETED_SESSIONS_HASH")


def _load_d1_extract(path: Path) -> dict[str, dict]:
    rows = cal(path)
    if len(rows) != 250:
        raise ModelError(f"D1_EXTRACT_CARDINALITY_MISMATCH got={len(rows)}")
    return {r["session_date"]: r for r in rows}


def _verify_d1_bar(session: str, calendar_row: dict, bar: D1Bar, extract: dict[str, dict]) -> None:
    er = extract.get(session)
    if er is None:
        raise ModelError(f"RUN_BLOCKED_D1_DRIFT session={session} reason=EXTRACT_MISSING")
    got = (
        calendar_row["expected_previous_session_date"], int(bar.open_micro), int(bar.high_micro),
        int(bar.low_micro), int(bar.close_micro),
    )
    exp = (
        er["expected_previous_session_date"], int(er["open_micro"]), int(er["high_micro"]),
        int(er["low_micro"]), int(er["close_micro"]),
    )
    if got != exp:
        raise ModelError(f"RUN_BLOCKED_D1_DRIFT session={session} expected={exp} got={got}")


def _runtime_module_hashes(package_root: Path) -> dict:
    return {
        "preflight_py_sha256": sha256_file(package_root / "minotauro_v004_preflight.py"),
        "io_py_sha256": sha256_file(package_root / "minotauro_v004_io.py"),
        "core_imported_definitions_sha256": core_imported_definitions_hash(package_root / "minotauro_v004_core.py"),
        "fast_resume_py_sha256": sha256_file(package_root / "r1r11_fast_resume.py"),
        "bounded_telemetry_py_sha256": sha256_file(package_root / "r1r11_bounded_telemetry.py"),
        "resources_py_sha256": sha256_file(package_root / "r1r11_resources.py"),
        "coordinator_py_sha256": sha256_file(package_root / "r1r11_coordinator.py"),
        "worker_py_sha256": sha256_file(package_root / "r1r11_worker.py"),
        "stream_py_sha256": sha256_file(package_root / "r1r11_v5_stream.py"),
        "runtime_status_py_sha256": sha256_file(package_root / "r1r11_runtime_status.py"),
    }


def _verify_use_time_binding(package_root: Path, phase_data_out: Path, binding: dict) -> dict:
    runtime = _runtime_module_hashes(package_root)
    expected = {
        "preflight_py_sha256": EXPECTED_PREFLIGHT_SHA256,
        "io_py_sha256": EXPECTED_IO_SHA256,
        "core_imported_definitions_sha256": EXPECTED_CORE_IMPORTED_DEFINITIONS_SHA256,
    }
    for k, v in expected.items():
        if runtime[k] != v or binding.get(k) != v:
            raise ModelError(f"RUN_BLOCKED_BINDING_MISMATCH {k}")
    artifact_checks = {
        "session_calendar_sha256": phase_data_out / "SESSION_CALENDAR_PHASE_A.csv",
        "preflight_status_sha256": phase_data_out / "PHASE_STATUS.json",
        "d1_predecessor_extract_sha256": phase_data_out / "D1_PREDECESSOR_EXTRACT_PHASE_A.csv",
    }
    for key, path in artifact_checks.items():
        got = sha256_file(path)
        if got != binding.get(key):
            raise ModelError(f"RUN_BLOCKED_BINDING_MISMATCH {key}")
    if binding.get("binding_content_sha256") != canonical_json_hash(binding, exclude_keys={"binding_content_sha256"}):
        raise ModelError("RUN_BLOCKED_BINDING_MISMATCH BINDING_CONTENT_HASH")
    return runtime


def _binding_tick_map(binding: dict) -> dict[str, str]:
    return {str(r["path"]): str(r["sha256"]).upper() for r in binding.get("tick_files", [])}


class _PrefixHashTracker:
    """SHA256 stream with commit-prefix verification for R1R6 FP-3 closure."""
    def __init__(self, expected_prefixes: dict[int, str] | None = None):
        self._h = hashlib.sha256()
        self.bytes_read = 0
        self.expected = {int(k): str(v).upper() for k, v in (expected_prefixes or {}).items()}
        self.checked: set[int] = set()

    def update(self, raw: bytes) -> None:
        self._h.update(raw)
        self.bytes_read += len(raw)
        skipped = [o for o in self.expected if o < self.bytes_read and o not in self.checked]
        if skipped:
            raise ModelError(f"TICK_PREFIX_DRIFT OFFSET_SKIPPED expected_offset={min(skipped)} got={self.bytes_read}")
        if self.bytes_read in self.expected:
            got = self._h.hexdigest().upper()
            exp = self.expected[self.bytes_read]
            if got != exp:
                raise ModelError(f"TICK_PREFIX_DRIFT offset={self.bytes_read} expected={exp} got={got}")
            self.checked.add(self.bytes_read)

    def hexdigest(self) -> str:
        return self._h.hexdigest()

    def snapshot(self) -> tuple[int, str]:
        return int(self.bytes_read), self._h.hexdigest().upper()

    def assert_all_expected_checked(self) -> None:
        missing = sorted(set(self.expected) - self.checked)
        if missing:
            raise ModelError(f"TICK_PREFIX_DRIFT EXPECTED_PREFIX_NOT_REACHED offset={missing[0]}")


def _session_prefix_expectations(out: Path, month_rows: list[dict], done: set[str], tick_path: Path) -> dict[int, str]:
    expected: dict[int, str] = {}
    month_sessions = {r["session_date"] for r in month_rows}
    for session in sorted(done & month_sessions):
        rp = out / "sessions" / session / "session_receipt.json"
        if not rp.is_file():
            raise ModelError(f"RESUME_HASH_MISMATCH SESSION_RECEIPT_MISSING {session}")
        obj = read_json(rp)
        if obj.get("tick_file_path") != str(tick_path):
            raise ModelError(f"RESUME_HASH_MISMATCH SESSION_TICK_FILE {session}")
        try:
            offset = int(obj["tick_prefix_bytes"])
            digest = str(obj["tick_prefix_sha256"]).upper()
        except Exception as e:
            raise ModelError(f"RESUME_HASH_MISMATCH SESSION_PREFIX_MISSING {session}") from e
        if offset <= 0 or len(digest) != 64:
            raise ModelError(f"RESUME_HASH_MISMATCH SESSION_PREFIX_INVALID {session}")
        previous = expected.get(offset)
        if previous is not None and previous != digest:
            raise ModelError(f"RESUME_HASH_MISMATCH SESSION_PREFIX_COLLISION offset={offset}")
        expected[offset] = digest
    return expected


def _month_requires_read(month_rows: list[dict], done: set[str], verified_months: dict, tick_path: Path, expected_hash: str) -> bool:
    """R2.3 §3.7(c): all-committed is not enough; EOF hash must be checkpointed."""
    wanted = any(r["session_date"] not in done for r in month_rows)
    verified = verified_months.get(str(tick_path)) == expected_hash
    return wanted or not verified


def _static_identity(package_root: Path, phase_data_out: Path, cfg: dict, binding: dict) -> dict:
    grid_hash = write_grid_cells(phase_data_out / "GRID_CELLS.csv")
    write_model_assumptions(phase_data_out)
    runner_hash, runner_manifest = runner_identity(package_root)
    (phase_data_out / "SPEC_HASH.txt").write_text(SPEC_SHA256 + "\n", encoding="ascii")
    (phase_data_out / "RUNNER_HASH.txt").write_text(runner_hash + "\n", encoding="ascii")
    return {
        "spec_sha256": SPEC_SHA256,
        "runner_sha256": runner_hash,
        "runner_manifest": runner_manifest,
        "grid_sha256": grid_hash,
        "preflight_status_sha256": binding["preflight_status_sha256"],
        "session_calendar_sha256": binding["session_calendar_sha256"],
        "expected_sessions_sha256": binding["expected_sessions_sha256"],
        "source_inventory_sha256": binding["source_inventory_sha256"],
        "run_source_binding_sha256": sha256_file(phase_data_out / "RUN_SOURCE_BINDING_A.json"),
        "config_sha256": config_hash(cfg),
        "parser_version": PARSER_VERSION,
    }


def _new_checkpoint(phase: str, cells, identity: dict, runtime_hashes: dict) -> dict:
    z = [0] * len(cells)
    return {
        "phase": phase,
        "last_committed_session_date": None,
        **{k: identity[k] for k in (
            "spec_sha256", "runner_sha256", "grid_sha256", "preflight_status_sha256",
            "session_calendar_sha256", "expected_sessions_sha256", "source_inventory_sha256",
            "run_source_binding_sha256", "config_sha256", "parser_version",
        )},
        "completed": [],
        "completed_sessions_sha256": _hash_completed([]),
        "cash": z.copy(), "hwm": z.copy(), "maxdd": z.copy(), "regime_min": z.copy(),
        "closed_hwm": z.copy(), "closed_maxdd": z.copy(),
        "cell_ids": [c.cell_id for c in cells],
        "verified_months": {},
        "runtime_module_hashes": runtime_hashes,
        "source_resume": None,
        "checkpoint_content_sha256": "",
    }


def _load_checkpoint(path: Path, phase: str, cells, identity: dict, runtime_hashes: dict) -> dict:
    if not path.exists():
        cp = _new_checkpoint(phase, cells, identity, runtime_hashes)
        _write_checkpoint(path, cp)
        return cp
    cp = read_json(path)
    _verify_checkpoint_self(cp)
    if cp.get("cell_ids") != [c.cell_id for c in cells]:
        raise ModelError("RESUME_HASH_MISMATCH CELL_IDS")
    for k in (
        "phase", "spec_sha256", "runner_sha256", "grid_sha256", "preflight_status_sha256",
        "session_calendar_sha256", "expected_sessions_sha256", "source_inventory_sha256",
        "run_source_binding_sha256", "config_sha256", "parser_version",
    ):
        expected = phase if k == "phase" else identity[k]
        if cp.get(k) != expected:
            raise ModelError(f"RESUME_HASH_MISMATCH {k}")
    if cp.get("runtime_module_hashes") != runtime_hashes:
        raise ModelError("RESUME_HASH_MISMATCH RUNTIME_MODULE_HASHES")
    return cp


def _orphan_reconcile(out: Path, cp: dict) -> None:
    sessions_root = out / "sessions"
    sessions_root.mkdir(parents=True, exist_ok=True)
    done = set(cp.get("completed", []))
    for p in sorted(sessions_root.iterdir()):
        if not p.is_dir() or p.name.endswith(".pending"):
            continue
        if p.name in done:
            continue
        orphan_root = out / "_orphan"
        orphan_root.mkdir(exist_ok=True)
        n = 1
        while (orphan_root / f"{p.name}__{n}").exists():
            n += 1
        os.replace(p, orphan_root / f"{p.name}__{n}")
        print(f"ORPHAN_MOVED session={p.name} n={n}", flush=True)
    for s in sorted(done):
        if not (sessions_root / s).is_dir():
            raise ModelError(f"RESUME_HASH_MISMATCH COMMITTED_SESSION_DIR_MISSING {s}")


def _commit_session(out, s, res, cells, cp, done, calendar_row, cp_path, tick_path: Path | None = None, source_hasher: _PrefixHashTracker | None = None, runtime=None):
    if runtime is not None:
        from r1r11_v4_transaction import commit
        return commit(out,s,res,cells,cp,done,calendar_row,cp_path,tick_path,source_hasher,runtime)
    # R1R10 M-1/m-d: the commit persists the five per-session artifacts exactly as
    # R1R9 and keeps no reference to res.trades after the checkpoint update.
    final = out / "sessions" / s
    tmp = final.with_name(s + ".pending")
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True)
    cutoff_preflight = {
        "first_cutoff_bid_msc": int(calendar_row["first_cutoff_bid_msc"]),
        "first_cutoff_ask_msc": int(calendar_row["first_cutoff_ask_msc"]),
        "cutoff_long_fill_msc": int(calendar_row["cutoff_long_fill_msc"]),
        "cutoff_short_fill_msc": int(calendar_row["cutoff_short_fill_msc"]),
        "cutoff_long_latency_ms": int(calendar_row["cutoff_long_latency_ms"]),
        "cutoff_short_latency_ms": int(calendar_row["cutoff_short_latency_ms"]),
    }
    for tr in res.trades:
        if tr.get("exit_reason") != "CUTOFF":
            continue
        expected = cutoff_preflight["cutoff_long_fill_msc"] if tr.get("direction") == "BUY" else cutoff_preflight["cutoff_short_fill_msc"]
        if int(tr.get("cutoff_fill_msc", -1)) != expected:
            raise ModelError(f"CUTOFF_PREFLIGHT_REPLAY_MISMATCH session={s} direction={tr.get('direction')} expected={expected} got={tr.get('cutoff_fill_msc')}")
        tr["first_cutoff_bid_msc"] = cutoff_preflight["first_cutoff_bid_msc"]
        tr["first_cutoff_ask_msc"] = cutoff_preflight["first_cutoff_ask_msc"]
    streams = (("trades.jsonl.gz", res.trades), ("events.jsonl.gz", res.events),
               ("equity.jsonl.gz", res.equity_events),
               ("equity_reconciliation.jsonl.gz", res.equity_reconciliation))
    if runtime is None:
        for name, rows in streams:
            gzjson(tmp / name, rows)
    else:
        # One coordinator process owns all publication. Each independent file
        # keeps the exact frozen gzjson encoder/compressor and row ordering.
        # Join all writers (also on error/interrupt) before any rename or CP.
        from concurrent.futures import ThreadPoolExecutor
        from r1r11_revision import CANONICAL_COMMIT_THREADS
        with ThreadPoolExecutor(max_workers=CANONICAL_COMMIT_THREADS, thread_name_prefix='canonical-gzip') as pool:
            pending = [pool.submit(gzjson, tmp / name, rows) for name, rows in streams]
            for future in pending:
                future.result()
    prefix_bytes = None
    prefix_sha256 = None
    if source_hasher is not None:
        prefix_bytes, prefix_sha256 = source_hasher.snapshot()
    write_json_atomic_canonical(tmp / "session_receipt.json", {
        "session": s,
        "trades": len(res.trades),
        "end_cash_units": res.end_cash_units,
        "hwm_units": res.hwm_units,
        "max_dd_units": res.max_dd_units,
        "regime_min_units": res.regime_min_units,
        "closed_hwm_units": res.closed_hwm_units,
        "closed_max_dd_units": res.closed_max_dd_units,
        "cutoff_diagnostics_runtime": res.cutoff_diagnostics,
        "cutoff_diagnostics_preflight": cutoff_preflight,
        "precutoff_crossed_state_count": res.precutoff_crossed_state_count,
        "tick_file_path": str(tick_path) if tick_path is not None else None,
        "tick_prefix_bytes": prefix_bytes,
        "tick_prefix_sha256": prefix_sha256,
    })
    if final.exists():
        raise ModelError(f"SESSION_ALREADY_EXISTS {s}")
    if runtime is not None:
        runtime.seal_precommit(out,s,tmp)
        runtime.inject("after_merge_before_commit")
    os.replace(tmp, final)
    if runtime is not None: runtime.inject("after_commit_before_checkpoint")
    cp.update({
        "cash": res.end_cash_units,
        "hwm": res.hwm_units,
        "maxdd": res.max_dd_units,
        "regime_min": res.regime_min_units,
        "closed_hwm": res.closed_hwm_units,
        "closed_maxdd": res.closed_max_dd_units,
    })
    done.add(s)
    cp["completed"] = sorted(done)
    cp["last_committed_session_date"] = max(done) if done else None
    _write_checkpoint(cp_path, cp)
    print(f"SESSION_COMMIT session={s} trades={len(res.trades)}", flush=True)


def _verify_committed_trades_present(out: Path, done: set[str]) -> None:
    """R1R10 M-1/m-d: resume rebuilds state only from CHECKPOINT/receipts.

    Existence is still enforced fail-closed (same error as R1R9), but committed
    trades are never materialized into an annual in-memory list. Their content is
    consumed only by the streaming finalization (metrics + TRADES CSV).
    """
    for s in sorted(done):
        p = out / "sessions" / s / "trades.jsonl.gz"
        if not p.is_file():
            raise ModelError(f"COMMITTED_TRADES_MISSING session={s}")


def _write_run_manifest(out: Path, identity: dict, binding: dict, cp: dict, mode: str, gate_receipt_sha256: str | None = None) -> None:
    obj = {
        "runner_version": RUNNER_VERSION,
        "mode": mode,
        "spec_sha256": identity["spec_sha256"],
        "runner_sha256": identity["runner_sha256"],
        "runner_manifest": identity["runner_manifest"],
        "grid_sha256": identity["grid_sha256"],
        "run_source_binding_sha256": identity["run_source_binding_sha256"],
        "binding_content_sha256": binding["binding_content_sha256"],
        "config_sha256": identity["config_sha256"],
        "parser_version": identity["parser_version"],
        "verified_months": cp.get("verified_months", {}),
        "runtime_module_hashes": cp.get("runtime_module_hashes", {}),
        "geometry_input_sha256": binding.get("geometry_input_sha256"),
        "geometry_replay_exact_sha256": binding.get("geometry_replay_exact_sha256"),
        "geometry_mt5_output_sha256": binding.get("geometry_mt5_output_sha256"),
        "geometry_parity_2025_sha256": binding.get("geometry_parity_2025_sha256"),
        "geometry_97_lines_2025_x3": binding.get("geometry_97_lines_2025_x3"),
        "gate_receipt_sha256": gate_receipt_sha256,
        "heavy_55_3_gib_preflight_rerun": "NO",
    }
    write_json_atomic_canonical(out / "RUN_MANIFEST.json", obj)


def _authorization(path: Path, key: str, expected: dict[str, str]) -> bool:
    if not path.is_file():
        return False
    try:
        obj = read_json(path)
    except Exception:
        return False
    if obj.get(key) != "YES":
        return False
    return all(obj.get(k) == v for k, v in expected.items())


def _require_prepilot_gates(root: Path, package_root: Path, identity: dict) -> str:
    p = root / "GATES" / "PRE_PILOT_GATE_RECEIPT.json"
    if not p.is_file():
        raise ModelError("PRE_PILOT_GATE_RECEIPT_REQUIRED")
    obj = read_json(p)
    gh, _ = gate_identity(package_root)
    checks = {
        "PRE_PILOT_GATES": "PASS",
        "gates_passed": 27,
        "spec_sha256": identity["spec_sha256"],
        "runner_sha256": identity["runner_sha256"],
        "grid_sha256": identity["grid_sha256"],
        "run_source_binding_sha256": identity["run_source_binding_sha256"],
        "gate_suite_sha256": gh,
    }
    for k, v in checks.items():
        if obj.get(k) != v:
            raise ModelError(f"PRE_PILOT_GATE_BINDING_MISMATCH {k}")
    return sha256_file(p)


def _require_run_a_gates(root: Path, package_root: Path, identity: dict) -> str:
    gate = root / "GATES" / "PRE_RUN_A_GATE_RECEIPT.json"
    if not gate.is_file():
        raise ModelError("RUN_A_GATE_RECEIPT_REQUIRED")
    obj = read_json(gate)
    gh, _ = gate_identity(package_root)
    checks = {
        "PRE_RUN_A_GATES": "PASS",
        "gates_passed": 28,
        "spec_sha256": identity["spec_sha256"],
        "runner_sha256": identity["runner_sha256"],
        "grid_sha256": identity["grid_sha256"],
        "run_source_binding_sha256": identity["run_source_binding_sha256"],
        "gate_suite_sha256": gh,
    }
    for k, v in checks.items():
        if obj.get(k) != v:
            raise ModelError(f"RUN_A_GATE_BINDING_MISMATCH {k}")
    gate_hash = sha256_file(gate)
    auth = root / "GATES" / "OWNER_RUN_A_AUTHORIZATION.json"
    expected = {
        "spec_sha256": identity["spec_sha256"],
        "runner_sha256": identity["runner_sha256"],
        "run_source_binding_sha256": identity["run_source_binding_sha256"],
        "pre_run_a_gate_receipt_sha256": gate_hash,
    }
    if not _authorization(auth, "RUN_A_AUTHORIZED", expected):
        raise ModelError("RUN_A_OWNER_AUTHORIZATION_REQUIRED_OR_STALE")
    return gate_hash


def _require_pilot_authorization(root: Path, identity: dict, prepilot_hash: str) -> None:
    auth = root / "GATES" / "OWNER_PILOT_AUTHORIZATION.json"
    expected = {
        "spec_sha256": identity["spec_sha256"],
        "runner_sha256": identity["runner_sha256"],
        "run_source_binding_sha256": identity["run_source_binding_sha256"],
        "pre_pilot_gate_receipt_sha256": prepilot_hash,
    }
    if not _authorization(auth, "PILOT_AUTHORIZED", expected):
        raise ModelError("PILOT_OWNER_AUTHORIZATION_REQUIRED_OR_STALE")


def _prepare_phase(cfg: dict, mode: str):
    package_root = Path(__file__).resolve().parent
    root = Path(cfg["out_root"])
    phase_data_out = root / "PHASE_A"
    binding_path = phase_data_out / "RUN_SOURCE_BINDING_A.json"
    if not binding_path.is_file():
        raise ModelError("RUN_SOURCE_BINDING_A_REQUIRED")
    if (root / "INVALID_PHASE.marker").exists():
        raise ModelError("OUT_ROOT_INVALIDATED_REBIND_CLEAN_ROOT_REQUIRED")
    binding = read_json(binding_path)
    if binding.get("status") != "PASS_SEALED_PREPILOT":
        raise ModelError("RUN_SOURCE_BINDING_A_NOT_SEALED_PREPILOT")
    runtime_hashes = _verify_use_time_binding(package_root, phase_data_out, binding)
    identity = _static_identity(package_root, phase_data_out, cfg, binding)
    rows = cal(phase_data_out / "SESSION_CALENDAR_PHASE_A.csv")
    if len(rows) != 250:
        raise ModelError("SESSION_CALENDAR_PHASE_A_NOT_250")
    d1 = load_d1(Path(cfg["ind_d1"]))
    d1_extract = _load_d1_extract(phase_data_out / "D1_PREDECESSOR_EXTRACT_PHASE_A.csv")
    cells = valid_cells()
    if len(cells) != 435:
        raise ModelError("VALID_CELL_COUNT_NOT_435")
    if mode == "RUN_A":
        out = phase_data_out
        integral_ids = {BASELINE_CELL_ID}
        selected_rows = rows
        gate_hash = _require_run_a_gates(root, package_root, identity)
    elif mode == "PILOT_A":
        prepilot_hash = _require_prepilot_gates(root, package_root, identity)
        _require_pilot_authorization(root, identity, prepilot_hash)
        out = root / "PILOT_A"
        out.mkdir(parents=True, exist_ok=True)
        integral_ids = {c.cell_id for c in cells}
        selected_rows = rows[:3]
        gate_hash = prepilot_hash
    else:
        raise ModelError("MODE_INVALID")
    return package_root, root, phase_data_out, out, binding, runtime_hashes, identity, selected_rows, d1, d1_extract, cells, integral_ids, gate_hash


def _invalidate(root: Path, reason: str) -> None:
    (root / "INVALID_PHASE.marker").write_text(reason + "\n", encoding="utf-8")


def run_phase_a(cfg: dict, mode: str, memory_probe=None, *, workers=12, batch_rows=32, fault=None) -> None:
    from r1r11_resources import RunLock, JobMemory, HARD_CAP_MIB
    from r1r11_coordinator import Runtime
    from r1r11_contract import validate_bindings, require_owner_gates
    validate_bindings()
    require_owner_gates(cfg)
    if memory_probe is not None:
        raise ModelError("R1R11_LEGACY_SINGLE_PROCESS_PROBE_FORBIDDEN")
    if parse_memory_cap_mib(cfg) != HARD_CAP_MIB:
        raise ModelError("R1R11_HARD_CAP_MUST_BE_48528")
    with RunLock(Path(cfg["out_root"])) as lock:
        monitor = JobMemory(lock.root / "TELEMETRY" / f"{mode}_R1R11_MEMORY.jsonl")
        runtime = Runtime(lock, monitor, workers, batch_rows, fault=fault, mode=mode)
        try:
            _run_phase_a_multi(cfg, mode, runtime)
        except KeyboardInterrupt:
            runtime.safe_stop_requested=True
            runtime.status('SAFE_STOP_REQUESTED',SAFE_STOP='REQUESTED',ETA='UNKNOWN',FINISH='UNKNOWN')
            print(f'SAFE_STOP_REQUESTED=YES mode={mode}',flush=True)
            raise
        except BaseException as exc:
            runtime.status('BLOCKED',error=f'{type(exc).__name__}:{exc}',ETA='UNKNOWN',FINISH='UNKNOWN')
            raise
        finally:
            runtime.close()


def _run_phase_a_multi(cfg: dict, mode: str, runtime) -> None:
    from r1r11_prefix import PhysicalPrefixTap
    memory_cap_mib = parse_memory_cap_mib(cfg)
    (package_root, root, phase_data_out, out, binding, runtime_hashes, identity, rows, d1, d1_extract, cells, integral_ids, gate_hash) = _prepare_phase(cfg, mode)
    monitor = runtime.memory
    from r1r11_v4_transaction import prepare_volume, recover
    prepare_volume(out,runtime.scratch)
    recover(out)
    cp_path = out / "CHECKPOINT.json"
    cp = _load_checkpoint(cp_path, mode, cells, identity, runtime_hashes)
    if {p.name for p in (out/"sessions").iterdir() if p.is_dir()} != set(cp["completed"]):
        raise ModelError("SESSION_CHECKPOINT_WITHOUT_JOURNAL")
    done = set(cp["completed"])
    _verify_committed_trades_present(out, done)
    runtime.verify_committed(out, cp)

    target_sessions = {r["session_date"] for r in rows}
    if not done.issubset(target_sessions):
        raise ModelError("CHECKPOINT_CONTAINS_OUT_OF_SCOPE_SESSION")

    by_file = defaultdict(list)
    for row in rows:
        by_file[Path(row["tick_file"])].append(row)
    sorted_files = sorted(by_file.items(), key=lambda kv: str(kv[0]))
    tick_hash_map = _binding_tick_map(binding)

    active_files = []
    for tp, month_rows in sorted_files:
        expected_hash = tick_hash_map.get(str(tp))
        if not expected_hash:
            raise ModelError(f"RUN_BLOCKED_BINDING_MISMATCH TICK_NOT_BOUND {tp}")
        if _month_requires_read(month_rows, done, cp.get("verified_months", {}), tp, expected_hash):
            active_files.append((tp, month_rows))
    total_bytes = sum(tp.stat().st_size for tp, _ in active_files)
    completed_bytes = 0
    started = time.monotonic()
    initial_done = len(done)
    sessions_total = len(rows)
    runtime.configure_status(total=sessions_total,committed=len(done))
    print(f"RUN_START mode={mode} sessions={sessions_total} remaining_sessions={sessions_total-len(done)} files_to_read_or_verify={len(active_files)} total_gib={total_bytes/1024**3:.3f} memory_cap_mib={memory_cap_mib} telemetry={monitor.path}", flush=True)
    monitor.boundary("RUN_START", None, len(done))

    for tp, month_rows in sorted_files:
        month_rows = sorted(month_rows, key=lambda x: x["session_date"])
        wanted = {r["session_date"] for r in month_rows if r["session_date"] not in done}
        expected_month_hash = tick_hash_map.get(str(tp))
        if not expected_month_hash:
            raise ModelError(f"RUN_BLOCKED_BINDING_MISMATCH TICK_NOT_BOUND {tp}")
        already_verified = cp.get("verified_months", {}).get(str(tp)) == expected_month_hash
        if not wanted and already_verified:
            print(f"MONTH_SKIP_ALL_COMMITTED_AND_HASH_VERIFIED file={tp.name}", flush=True)
            continue
        row_by_session = {r["session_date"]: r for r in month_rows}
        eng = None
        current = None
        lasto = 0
        lastdt = ""
        session_committed_early = False
        expected_prefixes = _session_prefix_expectations(out, month_rows, done, tp)
        from r1r11_fast_resume import rehydrate_prefix_tracker, write_anchor_checkpoint, clear_anchor_checkpoint, make_anchor, validate_fingerprint
        resume_meta = cp.get("source_resume") if isinstance(cp.get("source_resume"), dict) else None
        start_offset = 0
        if resume_meta and resume_meta.get("fingerprint",{}).get("path") == str(tp.resolve()):
            resume_session=str(resume_meta.get("session",''))
            month_sessions=[r['session_date'] for r in month_rows]
            done_in_month=sorted(set(month_sessions) & done)
            valid_stale=(resume_session in done and (not done_in_month or resume_session==done_in_month[-1]))
            if resume_session not in wanted and not valid_stale:
                raise ModelError('SOURCE_RESUME_SESSION_NOT_PENDING_OR_LAST_COMMITTED '+resume_session)
            start_offset=int(resume_meta.get("offset",-1))
            validate_fingerprint(tp,resume_meta['fingerprint'])
            h = rehydrate_prefix_tracker(tp,resume_meta,expected_prefixes)
            state='PENDING' if resume_session in wanted else 'LAST_COMMITTED_REPLAY'
            print(f"SOURCE_RESUME_REHYDRATE=PASS file={tp.name} session={resume_session} offset={start_offset} state={state}",flush=True)
        else:
            h = _PrefixHashTracker(expected_prefixes)
        prefix_tap = PhysicalPrefixTap(h)
        session_start_offsets = {}
        def boundary_cb(session, offset):
            session_start_offsets[str(session)] = int(offset)
        try:
            file_size = tp.stat().st_size
            print(f"RUN_MONTH_START mode={mode} file={tp.name} size_gib={file_size/1024**3:.3f} wanted_sessions={len(wanted)} verify_only={'YES' if not wanted else 'NO'}", flush=True)

            def progress_cb(file_bytes, raw_rows, file_size_cb, is_final):
                mem_row = monitor.progress(current, len(done), file=tp.name, file_bytes=int(file_bytes), raw_rows=int(raw_rows))
                _run_progress(mode, tp.name, completed_bytes + file_bytes, total_bytes, file_bytes, file_size_cb, raw_rows, len(done), sessions_total, started, mem_row, initial_done=initial_done)

            from r1r11_fast_resume import iter_tick_file_from_offset
            tick_iter=iter_tick_file_from_offset(tp,start_offset=start_offset,include_sessions=wanted,hasher=prefix_tap,
                                                 progress_cb=progress_cb,session_boundary_cb=boundary_cb)
            for rec in tick_iter:
                s = rec.session
                if s not in wanted:
                    continue
                if current is None:
                    if s not in session_start_offsets: raise ModelError('SOURCE_RESUME_BOUNDARY_MISSING '+s)
                    write_anchor_checkpoint(cp_path,cp,make_anchor(tp,s,session_start_offsets[s]))
                    print(f"SOURCE_RESUME_ANCHOR=PASS session={s} offset={session_start_offsets[s]}",flush=True)
                    row = row_by_session[s]
                    bar = d1[row["expected_previous_session_date"]]
                    _verify_d1_bar(s, row, bar, d1_extract)
                    eng = runtime.engine(s, bar, cells, int(row["cutoff_msc"]), True, cp["cash"], cp["hwm"], cp["maxdd"], cp["regime_min"], cp["closed_hwm"], cp["closed_maxdd"], integral_ids, source_tracker=prefix_tap)
                    current = s; lasto = 0; lastdt = s.replace("-", ".") + " 18:03:00"; session_committed_early = False
                    print(f"SESSION_START mode={mode} session={s} cells={len(cells)}", flush=True)
                elif s != current:
                    if not session_committed_early:
                        res = eng.finish(lasto, lastdt)
                        _commit_session(out, current, res, cells, cp, done, row_by_session[current], cp_path, tp, h, runtime=runtime)
                        runtime.committed(len(done))
                        res = None; eng = None  # R1R10: release per-session lists before the next engine
                        monitor.boundary("SESSION_COMMIT", current, len(done))
                    eng = None
                    wanted.discard(current)
                    if s not in session_start_offsets: raise ModelError('SOURCE_RESUME_BOUNDARY_MISSING '+s)
                    write_anchor_checkpoint(cp_path,cp,make_anchor(tp,s,session_start_offsets[s]))
                    print(f"SOURCE_RESUME_ANCHOR=PASS session={s} offset={session_start_offsets[s]}",flush=True)
                    row = row_by_session[s]
                    bar = d1[row["expected_previous_session_date"]]
                    _verify_d1_bar(s, row, bar, d1_extract)
                    eng = runtime.engine(s, bar, cells, int(row["cutoff_msc"]), True, cp["cash"], cp["hwm"], cp["maxdd"], cp["regime_min"], cp["closed_hwm"], cp["closed_maxdd"], integral_ids, source_tracker=prefix_tap)
                    current = s; lasto = 0; lastdt = s.replace("-", ".") + " 18:03:00"; session_committed_early = False
                    print(f"SESSION_START mode={mode} session={s} cells={len(cells)}", flush=True)
                if session_committed_early:
                    continue
                lasto = rec.ordinal; lastdt = rec.date_time
                if not eng.process_record(rec):
                    res = eng.finish(lasto, lastdt)
                    _commit_session(out, current, res, cells, cp, done, row_by_session[current], cp_path, tp, h, runtime=runtime)
                    runtime.committed(len(done))
                    res = None; eng = None  # R1R10: release per-session lists immediately after commit
                    wanted.discard(current)
                    session_committed_early = True
                    monitor.boundary("SESSION_COMMIT", current, len(done))
            if current is not None and current in wanted and not session_committed_early:
                res = eng.finish(lasto, lastdt)
                _commit_session(out, current, res, cells, cp, done, row_by_session[current], cp_path, tp, h, runtime=runtime)
                runtime.committed(len(done))
                res = None; eng = None  # R1R10: release per-session lists immediately after commit
                wanted.discard(current)
                monitor.boundary("SESSION_COMMIT", current, len(done))
        except KeyboardInterrupt:
            print(f"SAFE_STOP_REQUESTED=YES mode={mode} interrupted_session={current or 'NONE'} recovery=CHECKPOINT_OR_ORPHAN_ON_RESUME", flush=True)
            raise
        except ModelError as e:
            if str(e).startswith("TICK_PREFIX_DRIFT"):
                _invalidate(root, f"RUN_BLOCKED_TICK_DRIFT file={tp} detail={e}")
                raise ModelError(f"RUN_BLOCKED_TICK_DRIFT file={tp} detail={e}") from e
            raise

        try:
            h.assert_all_expected_checked()
        except ModelError as e:
            _invalidate(root, f"RUN_BLOCKED_TICK_DRIFT file={tp} detail={e}")
            raise ModelError(f"RUN_BLOCKED_TICK_DRIFT file={tp} detail={e}") from e
        actual_month_hash = h.hexdigest().upper()
        if actual_month_hash != expected_month_hash:
            _invalidate(root, f"RUN_BLOCKED_TICK_DRIFT file={tp} expected={expected_month_hash} got={actual_month_hash}")
            raise ModelError(f"RUN_BLOCKED_TICK_DRIFT file={tp} expected={expected_month_hash} got={actual_month_hash}")
        cp.setdefault("verified_months", {})[str(tp)] = actual_month_hash
        clear_anchor_checkpoint(cp_path,cp)
        completed_bytes += tp.stat().st_size
        print(f"RUN_MONTH_HASH_VERIFIED file={tp.name} sha256={actual_month_hash}", flush=True)
        if wanted:
            raise ModelError("RUN_MONTH_MISSING_EXPECTED_SESSIONS " + ",".join(sorted(wanted)))
        monitor.boundary("MONTH_VERIFIED", None, len(done))
        runtime.status('MONTH_VERIFIED',COMMITTED=len(done),ACTIVE=0,READY_WAITING=0,
                       RATE='UNKNOWN',ETA='UNKNOWN',FINISH='UNKNOWN',
                       CHECKPOINT=max(done) if done else 'NONE',verified_month=tp.name)

    _write_run_manifest(out, identity, binding, cp, mode, gate_hash)

    if mode == "PILOT_A":
        if len(done) != 3:
            raise ModelError(f"PILOT_SESSION_COUNT_NOT_3 got={len(done)}")
        monitor.boundary("PRE_PILOT_RECEIPT", None, len(done))
        write_json_atomic_canonical(out / "PILOT_RUN_RECEIPT.json", {
            "PILOT_RUN": "PASS",
            "sessions": sorted(done),
            "cells": len(cells),
            "all_open_marks_integral": "YES",
            "verified_months": cp["verified_months"],
            "run_manifest_sha256": sha256_file(out / "RUN_MANIFEST.json"),
        })
        runtime.status('PILOT_A_PASS',COMMITTED=len(done),ACTIVE=0,READY_WAITING=0,
                       RATE='UNKNOWN',ETA='UNKNOWN',FINISH='NOW',
                       CHECKPOINT=max(done) if done else 'NONE')
        print("PILOT_A_RUN=PASS sessions=3")
        return

    if len(done) != 250:
        raise ModelError(f"RUN_A_INCOMPLETE_SESSIONS got={len(done)}")
    if len(cp.get("verified_months", {})) != 12:
        raise ModelError(f"RUN_A_MONTH_HASH_VERIFICATION_INCOMPLETE got={len(cp.get('verified_months', {}))}")
    monitor.boundary("PRE_FINALIZE", None, len(done))
    maxdd = {c.cell_id: int(cp["maxdd"][i]) for i, c in enumerate(cells)}
    # R1R10 M-1/m-d: aggregate_phase (frozen) consumes a stream of the persisted
    # per-session trades; no annual list exists in the run-a path.
    metrics = aggregate_phase(cells, iter_committed_trades(out, sorted(done)), maxdd)
    freeze = finalize_phase_a(out, package_root, cfg, cells, metrics, cp, binding)
    _write_run_manifest(out, identity, binding, cp, mode, gate_hash)
    # R1R10: last safe boundary before the master manifest and the PASS line; a
    # stop here leaves no SHA256SUMS.txt, so a resume re-finalizes identically.
    monitor.boundary("POST_FINALIZE", None, len(done))
    files_for_master = [p for p in out.rglob("*") if p.is_file() and p.name not in {"CHECKPOINT.json"} and not p.name.endswith(".tmp")]
    write_sha_manifest(out / "SHA256SUMS.txt", files_for_master, out)
    runtime.status('RUN_A_PASS',COMMITTED=len(done),ACTIVE=0,READY_WAITING=0,
                   RATE='UNKNOWN',ETA='DONE',FINISH='NOW',
                   CHECKPOINT=max(done) if done else 'NONE',SAFE_STOP='NO')
    print(f"PHASE_A_RUN=PASS sessions=250 selection_status={freeze['status']} selected={freeze.get('selected_cell_id')}")


def _guard_rebind_gate_state(cfg: dict) -> None:
    gates = Path(cfg["out_root"]) / "GATES"
    if not gates.exists():
        return
    binding_sensitive = [
        "GEOMETRY_PREPARE_RECEIPT.json", "GEOMETRY_PARITY_RECEIPT.json",
        "PRE_PILOT_GATE_RECEIPT.json", "GATE28_PILOT_RECONCILIATION_RECEIPT.json",
        "PRE_RUN_A_GATE_RECEIPT.json",
    ]
    present = [name for name in binding_sensitive if (gates / name).exists()]
    if present:
        raise ModelError("REBIND_BLOCKED_STALE_GATE_RECEIPTS_REMOVE_GATES=" + ",".join(present))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["rebind-a", "pilot-a", "run-a"])
    ap.add_argument("--config", required=True)
    ap.add_argument("--workers", type=int, default=12)
    ap.add_argument("--batch-rows", type=int, default=32)
    ns = ap.parse_args()
    print('V004R2_SYNTHETIC_ONLY: rebind, Pilot A and Run-A are disabled in this revision.',file=sys.stderr)
    raise SystemExit(2)
    cfg = json.loads(Path(ns.config).read_text(encoding="utf-8"))
    try:
        if ns.command == "rebind-a":
            _guard_rebind_gate_state(cfg)
            receipt = build_binding(cfg, Path(__file__).resolve().parent)
            print("PREFLIGHT_REUSE_AUTHORIZED=YES")
            print("HEAVY_55_3_GIB_PREFLIGHT_RERUN_REQUIRED=NO")
            print(f"RUN_SOURCE_BINDING_SHA256={receipt['run_source_binding_sha256']}")
        elif ns.command == "pilot-a":
            run_phase_a(cfg, "PILOT_A", workers=ns.workers, batch_rows=ns.batch_rows)
        elif ns.command == "run-a":
            run_phase_a(cfg, "RUN_A", workers=ns.workers, batch_rows=ns.batch_rows)
    except KeyboardInterrupt:
        print("SAFE_STOP=YES")
        raise SystemExit(130)
    except MemoryCapSafeStop as e:
        # R1R10: boundary-only stop; checkpoint already atomic; never PASS.
        print(str(e), flush=True)
        raise SystemExit(MEMORY_CAP_EXIT_CODE)
    except Exception as e:
        print(f"RUN_BLOCKED={type(e).__name__}:{e}", file=sys.stderr)
        traceback.print_exc()
        raise SystemExit(2)


if __name__ == "__main__":
    main()
