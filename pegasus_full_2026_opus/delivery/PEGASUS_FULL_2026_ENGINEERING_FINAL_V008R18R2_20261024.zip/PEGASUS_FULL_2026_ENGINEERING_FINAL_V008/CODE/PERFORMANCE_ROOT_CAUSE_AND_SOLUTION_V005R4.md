# R1R11 V005R4 — Performance Root Cause and Corrective Design

Date: 2026-09-27

## Owner evidence entering V005R4

V005R3 closed the functional synthetic gate:
- Windows V5 suite: PASS 19/19.
- Development economic byte equality: PASS 3/3.
- Development speedups: 0.9925x, 0.9894x, 1.0285x.
- Required development speedup: >= 1.667x.

Therefore the remaining blocker was performance only.

## Root cause

The A0 budget measured streaming service using gzip-compressed oracle artifacts. V005R1-R3,
however, wrote authoritative worker scratch as plain JSONL and then had independent writer and
verifier processes reread that physical raw volume.

On the heavy synthetic oracle the four canonical streams contain about 760 MB of JSON before
compression. The V005R4 level-1 streaming scratch representation measured only about 18.5 MB
combined. In the old path, writer + verifier independently reread the raw scratch, multiplying
physical I/O and JSON handling and erasing the expected parallel-compute gain.

This was an architecture mismatch between the A0 model and the implemented hot path, not a
threshold problem and not an economic-model problem.

## V005R4 correction

1. Authoritative scratch is gzip level 1.
2. Z_SYNC_FLUSH occurs once per ACKed feed batch.
3. Watermark offsets are physical compressed-byte offsets.
4. Writer and verifier keep independent persistent scratch handles and independent incremental
   gzip decompressors.
5. Both independently parse JSON, recompute merge keys/order proofs, and hash every physical
   compressed scratch byte.
6. Writer may reuse the already-canonical decompressed line; verifier independently reserializes it.
7. Final level-6 gzip writer/verifier outputs still must be byte-identical.
8. Final output remains byte-identical to the frozen oracle.
9. Scratch physical identity is revalidated before finalization, preserving the V005R3 late-tamper gate.
10. No benchmark threshold, oracle, worker count, batch size, shared slots, heavy cycles, economics
    or final gzip level changed.

## Heavy builder proof

All four streams reproduced the oracle final gzip SHA-256 exactly through the new compressed
scratch reader/writer/verifier path:

- trades: PASS, ~46.89x scratch compression;
- events: PASS, ~24.15x;
- equity: PASS, ~49.42x;
- equity_reconciliation: PASS, ~44.15x.

This proves correctness of the new serialization path. Performance remains an owner-Windows
measurement and is not claimed until the development benchmark runs there.
