"""Physical prefix custody around the unchanged parent _PrefixHashTracker.

Read-ahead stops before termination: post-cutoff batches are single-record.
For each published record we retain its raw physical line, end offset, and
hash-copy before that line. The coordinator drops these only after all ACKs.
"""
from minotauro_v004_core import ModelError


class PhysicalPrefixTap:
    def __init__(self, tracker):
        self.tracker=tracker;self.last_raw=None;self.before=None;self.offset_before=0

    def update(self, raw):
        if len(raw)>1024*1024:raise ModelError('PHYSICAL_LINE_EXCEEDS_BOUNDED_FEED')
        self.before=self.tracker._h.copy()
        self.offset_before=self.tracker.bytes_read
        self.last_raw=bytes(raw)
        self.tracker.update(raw)

    def capture(self, ordinal):
        if self.last_raw is None:raise ModelError('PHYSICAL_PREFIX_WITHOUT_LINE')
        return {'ordinal':ordinal,'start_hash':self.before.copy(),'raw':self.last_raw,
                'end_offset':self.tracker.bytes_read,'offset_before':self.offset_before}

    def verify(self, snap):
        h=snap['start_hash'].copy();h.update(snap['raw'])
        expected=(snap['end_offset'],h.hexdigest().upper())
        if expected!=self.tracker.snapshot():raise ModelError('TERMINAL_PREFIX_SNAPSHOT_DIVERGENCE')
        return expected
