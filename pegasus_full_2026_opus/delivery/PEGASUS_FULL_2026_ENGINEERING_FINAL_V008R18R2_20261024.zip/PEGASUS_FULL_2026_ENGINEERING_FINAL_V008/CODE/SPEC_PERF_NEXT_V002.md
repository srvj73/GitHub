# SPEC — MINOTAURO PERF NEXT V002

STATUS=CANDIDATE_FOR_FUTURE_QUALIFICATION_ONLY
CURRENT_FULL_AUTHORITY=UNCHANGED
CURRENT_FULL_INTERRUPTION=FORBIDDEN
BASELINE_ZIP_SHA256=207531E97C9818D00E0D61B0379A8D94A13AD5CEB8FF9450EAE466A8C2DBB064
PARENT_PERF_CANDIDATE_SHA256=ABD6E4DB570DAE9CC6FA0F0A86FFD9DE306411E5192A6AC4B2434613A6F2EA28

## 1. Escopo

Esta SPEC vale somente para o candidato de performance futuro. Ela não altera o contrato nem os bytes do FULL C1 atualmente em execução.

## 2. Invariantes preservadas

- economia e parâmetros econômicos;
- causalidade e ordem física dos eventos;
- C1/cutoff;
- determinismo e oracle;
- bytes finais canônicos;
- checkpoint/resume e SAFE_STOP;
- single canonical publisher;
- RAM target 60% e hard cap 48,528 MiB;
- 15 work groups canônicos;
- shared_slots=1 nesta revisão.

## 3. Delta de scheduler autorizado somente no candidato

A limitação `MAX_WORKERS=12` da baseline corrente não é aplicada ao candidato V002. Para a qualificação futura deste candidato:

- REQUESTED_WORKERS_DEFAULT=15;
- MAX_WORKERS_CANDIDATE=15;
- worker grant continua limitado por CPU lógica, RAM agregada, processos pesados externos e número de grupos;
- com `granted=15`, cada um dos 15 grupos canônicos é atribuído exatamente a um worker pela mesma regra determinística round-robin;
- com `granted<15`, a mesma regra determinística continua valendo e a telemetria deve registrar o skew de grupos por worker.

A alteração não pode ser aplicada ao FULL corrente nem usada para resume de output produzido sob configuração diferente.

## 4. Delta de batch

- BATCH_ROWS_DEFAULT_CANDIDATE=256;
- matriz qualificada a testar: 32, 64, 128, 256;
- 256 reduz a frequência nominal de barreiras/ACK em 8x comparada a 32 para o mesmo número de registros;
- nenhuma variante pode ser promovida sem byte equality/oracle/C1 e benchmark pós-FULL;
- mudança de batch exige output root/config identity próprios; resume cruzado é proibido.

## 5. Não implementado nesta revisão

- múltiplos shared slots;
- feed-ahead especulativo;
- transferência dinâmica de engine state entre workers;
- alteração do FIRST_WORKER_RESERVE_MIB;
- alteração do parser/fonte;
- alteração do publisher canônico.

Essas mudanças permanecem fora de escopo porque poderiam atravessar o ponto terminal global ainda desconhecido ou exigir prova adicional de equivalência.

## 6. Evidência necessária antes de uso operacional

1. PowerShell 5.1 parse do wrapper no Windows alvo;
2. synthetic differential W12/B32 x W15/B32 x W15/B256;
3. byte equality dos cinco artefatos canônicos e oracle parity;
4. C1/cutoff mismatch=0;
5. benchmark real curto em nova raiz somente depois do FULL corrente terminar;
6. CPU por papel, worker span/skew, ACK, stream wait, writer, verifier, FINISH, RAM e I/O;
7. SAFE_STOP/resume/process-tree-clean.

PERFORMANCE_CLAIM_BEFORE_POST_FULL_MEASUREMENT=FORBIDDEN
