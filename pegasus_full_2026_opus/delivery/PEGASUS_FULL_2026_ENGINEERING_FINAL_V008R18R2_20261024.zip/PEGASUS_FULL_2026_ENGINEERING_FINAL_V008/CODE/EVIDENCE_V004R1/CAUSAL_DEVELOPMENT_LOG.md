# V004R1 — registro causal de desenvolvimento

EVIDENCE: targeted_01 falhou antes de criar qualquer engine. O adaptador substituiu
`_orphan_reconcile`, que criava `sessions`, por recuperação estrita, mas tentou
enumerar o diretório ainda inexistente em um output novo. O traceback integral
está em targeted_01/candidate.log; oracle exit 0, candidate exit 2. A ferramenta
PowerShell reportou exit 1 para a invocação externa; COMMANDS.json preserva o
exit 2 nativo do candidato e o script propaga esse valor via SystemExit.
Não houve comparação econômica nem medição heavy.

ROOT_CAUSE: inicialização omitida no fixture driver, não falha de merge/core/SPEC.
DECISION: criar exclusivamente o diretório estrutural vazio com mkdir(exist_ok=True)
antes de enumerá-lo. Nenhum estado ou arquivo econômico é reconstruído.
NEXT_ACTION: repetir o mesmo diferencial pontual em targeted_02, preservando targeted_01.

EVIDENCE: targeted_02 exit 0, 21 arquivos byte-idênticos. V4_TESTS_01 exit 0,
8 testes em 89,864 s, incluindo oito fronteiras transacionais e dez falhas de
custódia/lifecycle. Nenhum caso heavy foi executado; G4 permanece UNEXECUTED.

EVIDENCE: V4_NEGATIVE_01 encontrou uma precondição inválida no teste adicional de
trade finality: o cenário pending_cancel contém zero trades. A comparação de
conteúdo não divergiu, mas assertTrue(rows) bloqueou corretamente uma prova vazia.
ROOT_CAUSE: escolha de fixture sem trades; nenhuma falha econômica demonstrada.
DECISION: incluir no V4-A um diferencial de scratch final não vazio usando a
fixture causal existente deferred, interrompida antes do journal. Manter o
assert de não vazio, sem modificar core, fixture, executor ou critérios.
VALIDATION_NEXT: executar somente V4-A em evidência nova; manter o log negativo.

EVIDENCE: V4_FINALITY_02 passou com trades não vazios. V4_NEGATIVE_02 passou 3/3.

EVIDENCE: V4_NATIVE_01 falhou no harness, antes de enviar Ctrl+C: o segundo helper
criou o marker de espera quando só três registros de helper existiam; o quarto
spawn ainda estava em curso. O assert 4 permaneceu ativo. ROOT_CAUSE: prontidão
do teste observada cedo demais, conforme a ordem spawn/registro do coordinator.
DECISION: esperar cumulativamente marker e quatro registros, mantendo o deadline
e o assert. Nenhuma alteração no executor. VALIDATION_NEXT: apenas os dois casos
nativos, em v4_native_02; não repetir as dez injeções já aprovadas.

EVIDENCE: V4_NATIVE_02 chegou ao staging com quatro helpers, mas Ctrl+C não foi
observado em 15 s; harness encerrou o coordinator. Checkpoint ficou no warmup,
nenhuma sessão parcial foi promovida, nenhum helper permaneceu vivo no scan.

AUDIT: controle isolado diagnose_console_signal.py, sem importar executor:
default_int_handler nos dois braços; emissor nativo exit 0 nos dois. Sem limpar
o atributo Win32 herdado, NO_SIGNAL_OBSERVED/exit 0 após espera; com
SetConsoleCtrlHandler(NULL,FALSE), NATIVE_SIGINT_OBSERVED/exit 130.
CONSOLE_DELIVERY_DIAGNOSTIC.json preserva comandos/saídas integrais.

ROOT_CAUSE: atributo Win32 herdado de ignorar Ctrl+C, distinto do handler Python.
DECISION: coordinator_sigint() restaura o processamento Win32 e instala o handler
Python padrão no Runtime normal, antes de trabalho. Workers/helpers continuam
SIG_IGN antes de trabalhar. Nenhum caminho por fixture/scenario ou de performance.
VALIDATION_NEXT: apenas interrupções nativas e controles pequenos em v4_native_03.
