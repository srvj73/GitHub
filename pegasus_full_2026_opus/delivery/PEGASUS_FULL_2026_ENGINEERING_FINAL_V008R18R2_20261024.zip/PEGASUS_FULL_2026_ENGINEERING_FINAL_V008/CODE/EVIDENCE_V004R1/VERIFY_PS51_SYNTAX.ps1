#requires -Version 5.1
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) {throw 'PS51_REQUIRED'}
$files=Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'candidate') -Filter '*.ps1' -File
foreach ($file in $files) {
    $tokens=$null; $errors=$null
    [void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
    if ($errors.Count -gt 0) {throw ('PS_PARSE_FAILURE ' + $file.FullName + ' ' + ($errors -join '; '))}
}
Write-Output ('PS51_SYNTAX=PASS FILES=' + $files.Count + ' VERSION=' + $PSVersionTable.PSVersion)
