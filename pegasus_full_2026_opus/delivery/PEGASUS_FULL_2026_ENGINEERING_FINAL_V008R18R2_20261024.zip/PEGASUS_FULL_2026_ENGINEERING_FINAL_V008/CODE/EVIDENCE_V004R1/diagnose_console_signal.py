"""Standalone console delivery control; no executor, economics or benchmark."""
import ctypes
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

def child(mode):
    before=repr(signal.getsignal(signal.SIGINT))
    if mode=='clear_ignore':
        k=ctypes.WinDLL('kernel32',use_last_error=True)
        if not k.SetConsoleCtrlHandler(None,False):raise ctypes.WinError(ctypes.get_last_error())
    print(json.dumps({'pid':os.getpid(),'mode':mode,'sigint':before}),flush=True)
    try:
        threading.Event().wait(8)
        print('NO_SIGNAL_OBSERVED',flush=True)
    except KeyboardInterrupt:
        print('NATIVE_SIGINT_OBSERVED',flush=True)
        raise SystemExit(130)

def main():
    root=Path(__file__).resolve().parent;out=root/'CONSOLE_DELIVERY_DIAGNOSTIC.json'
    if out.exists():raise RuntimeError('DIAGNOSTIC_ALREADY_EXISTS')
    results=[]
    for mode in ('default','clear_ignore'):
        si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
        args=[sys.executable,'-X','utf8','-B',str(Path(__file__)),'--child',mode]
        p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,
            startupinfo=si,creationflags=subprocess.CREATE_NEW_CONSOLE)
        ready=p.stdout.readline()
        send=[sys.executable,'-B',str(root/'candidate/r1r11_signal.py'),'--pid',str(p.pid)]
        sent=subprocess.run(send,capture_output=True,text=True)
        tail=p.communicate(timeout=12)[0]
        results.append({'command':args,'ready':ready,'sender_command':send,
            'sender_exit':sent.returncode,'sender_stdout':sent.stdout,'sender_stderr':sent.stderr,
            'child_exit':p.returncode,'output':tail})
    out.write_text(json.dumps(results,indent=2),encoding='utf-8');print(json.dumps(results,indent=2))

if __name__=='__main__':
    if '--child' in sys.argv:child(sys.argv[-1])
    else:main()
