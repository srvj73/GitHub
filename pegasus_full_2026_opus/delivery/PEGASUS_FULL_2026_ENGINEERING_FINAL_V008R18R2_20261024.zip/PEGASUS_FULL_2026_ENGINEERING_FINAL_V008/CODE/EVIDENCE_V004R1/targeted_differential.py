"""Small development differential only. Never invokes owner G1-G11 or heavy."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
package=root/'candidate'
out=root/(sys.argv[1] if len(sys.argv)>1 else 'targeted_01')
out.mkdir(exist_ok=False)
sys.path.insert(0,str(package))
from r1r11_fixtures import generate
generate(out/'inputs')  # Original 1200-cycle heavy fixture generated, never executed here.
results=[]
for role in ('oracle','candidate'):
    args=[sys.executable,'-X','utf8','-B',str(package/'r1r11_fixtures.py'),
          '--inputs',str(out/'inputs'),'--out',str(out/role),'--role',role,
          '--workers','2','--only','pending_cancel']
    started=time.perf_counter()
    with (out/(role+'.log')).open('x',encoding='utf-8') as log:
        p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,
                         env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1'})
    results.append({'command':args,'exit_code':p.returncode,'elapsed':time.perf_counter()-started})
    (out/'COMMANDS.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    if p.returncode:
        print((out/(role+'.log')).read_text(encoding='utf-8'))
        raise SystemExit(p.returncode)
def tree(p):
    return {str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest()
            for f in (p/'sessions').rglob('*') if f.is_file()}|{
            'CHECKPOINT.json':hashlib.sha256((p/'CHECKPOINT.json').read_bytes()).hexdigest()}
a,b=tree(out/'oracle'),tree(out/'candidate')
report={'scope':'TARGETED_DEVELOPMENT_ONLY','byte_identical':a==b,'files':len(a),
        'differences':[k for k in set(a)|set(b) if a.get(k)!=b.get(k)],'oracle':a,'candidate':b}
(out/'DIFFERENTIAL.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('oracle','candidate')}))
raise SystemExit(0 if a==b else 2)
