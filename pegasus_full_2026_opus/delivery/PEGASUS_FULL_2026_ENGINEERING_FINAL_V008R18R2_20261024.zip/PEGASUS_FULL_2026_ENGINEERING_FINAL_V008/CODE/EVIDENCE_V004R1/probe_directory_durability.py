"""Bounded synthetic prerequisite probe for SPEC V004 section 17.7.

No executor import, market access, volume flush, privilege change or cleanup.
Creates one fresh test directory and one small control file; preserves both.
Exit 2 means no successful writable directory FlushFileBuffers was observed.
"""
import ctypes
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time


def main():
    started = time.perf_counter()
    root = Path(__file__).resolve().parent
    target = root / 'directory_durability_probe'
    target.mkdir(exist_ok=False)
    control = target / 'control.bin'
    with control.open('xb') as f:
        f.write(b'V004R1_SYNTHETIC_DIRECTORY_DURABILITY_CONTROL\n')
        f.flush()
        os.fsync(f.fileno())
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    k.CreateFileW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD, ctypes.c_void_p,
                              w.DWORD, w.DWORD, ctypes.c_void_p]
    k.CreateFileW.restype = ctypes.c_void_p
    k.FlushFileBuffers.argtypes = [ctypes.c_void_p]
    k.FlushFileBuffers.restype = w.BOOL
    k.CloseHandle.argtypes = [ctypes.c_void_p]
    k.CloseHandle.restype = w.BOOL
    k.GetVolumeInformationW.argtypes = [w.LPCWSTR, w.LPWSTR, w.DWORD,
        ctypes.POINTER(w.DWORD), ctypes.POINTER(w.DWORD),
        ctypes.POINTER(w.DWORD), w.LPWSTR, w.DWORD]
    k.GetVolumeInformationW.restype = w.BOOL
    serial, max_component, flags = w.DWORD(), w.DWORD(), w.DWORD()
    fs = ctypes.create_unicode_buffer(256)
    if not k.GetVolumeInformationW(target.anchor, None, 0, ctypes.byref(serial),
            ctypes.byref(max_component), ctypes.byref(flags), fs, len(fs)):
        raise ctypes.WinError(ctypes.get_last_error())
    report = {'python': sys.version, 'platform': platform.platform(),
              'target': str(target), 'filesystem': fs.value,
              'volume_serial': serial.value, 'file_os_fsync': 'PASS',
              'spec_clause': '17.7.2 steps 8,13,16', 'cases': []}
    try:
        fd = os.open(target, os.O_RDONLY)
        try:
            os.fsync(fd)
            report['directory_os_fsync'] = {'success': True}
        finally:
            os.close(fd)
    except OSError as e:
        report['directory_os_fsync'] = {'success': False, 'errno': e.errno,
            'winerror': e.winerror, 'message': str(e)}
    for kind, path in [('file_control', control), ('directory', target)]:
        for name, access in [('GENERIC_READ', 0x80000000),
                             ('GENERIC_WRITE', 0x40000000),
                             ('GENERIC_READ_WRITE', 0xC0000000)]:
            row = {'kind': kind, 'access': name, 'mask': access,
                   'share_mask': 7, 'flags': 'FILE_FLAG_BACKUP_SEMANTICS'}
            ctypes.set_last_error(0)
            handle = k.CreateFileW(str(path), access, 7, None, 3, 0x02000000, None)
            if handle in (None, ctypes.c_void_p(-1).value):
                err = ctypes.get_last_error()
                row.update(open_ok=False, open_error=err,
                           open_error_message=ctypes.FormatError(err))
            else:
                row['open_ok'] = True
                try:
                    ctypes.set_last_error(0)
                    ok = bool(k.FlushFileBuffers(handle))
                    err = 0 if ok else ctypes.get_last_error()
                    row.update(flush_ok=ok, flush_error=err,
                               flush_error_message='' if ok else ctypes.FormatError(err))
                finally:
                    k.CloseHandle(handle)
            report['cases'].append(row)
    file_ok = any(r.get('flush_ok') for r in report['cases'] if r['kind']=='file_control')
    dir_ok = any(r.get('flush_ok') for r in report['cases'] if r['kind']=='directory'
                 and r['mask'] & 0x40000000)
    report.update(positive_control=file_ok, writable_directory_flush_observed=dir_ok,
                  status='PASS_PRIMITIVE_ONLY' if file_ok and dir_ok else 'BLOCKED_PREREQUISITE',
                  control_sha256=hashlib.sha256(control.read_bytes()).hexdigest().upper(),
                  elapsed_seconds=time.perf_counter()-started)
    code = 0 if file_ok and dir_ok else 2
    report['exit_code'] = code
    with (root/'DIRECTORY_DURABILITY_PROBE.json').open('x', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
