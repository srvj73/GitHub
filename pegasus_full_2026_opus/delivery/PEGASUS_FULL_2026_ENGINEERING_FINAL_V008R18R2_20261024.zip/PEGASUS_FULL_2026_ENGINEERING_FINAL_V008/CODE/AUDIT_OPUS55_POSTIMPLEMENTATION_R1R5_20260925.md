# AUDITORIA PÓS-IMPLEMENTAÇÃO OPUS 5.5 — MINOTAURO V005R1 R1R5

**Pacote:** `HANDOFF_OPUS55_POS_IMPLEMENTACAO_MINOTAURO_R1R5_20260925`
**Autoridades:**
- SPEC governante V005R1-R2.3 (`D6D79108…2E73747`)
- Parent normativo V005R1 (`60CBE1A2…D80AAF`)
- R6 física (`1A950132…DEE059FA5`)
- Parent físico R1R4

**Regime:** estático, independente, adversarial e fail-closed.
- Nenhum código foi escrito ou alterado.
- Nenhum teste foi executado e nenhum dado de mercado foi lido.
- Foram feitas apenas a leitura integral das fontes e a verificação de hashes.
- A V002R2 não foi reaberta.

```text
OPUS55_R1R5_POSTIMPLEMENTATION_AUDIT=PASS_WITH_BLOCKERS
R2_3_IMPLEMENTATION_PARITY=BLOCKED
R1R4_PARENT_PRESERVATION=PASS
B1_IMPLEMENTATION=PASS
PREFLIGHT_REUSE_BINDING=PASS
USE_TIME_BINDING=BLOCKED
CHECKPOINT_RESUME=PASS
EXTREMA_LOSSLESS=PASS
FREEZE_A_OUTPUTS=PASS
SECTION22_GATE_SUITE=BLOCKED
GEOMETRY_MT5_FIXTURE_STATIC=PASS
POWERSHELL_LAUNCHERS=PASS
FALSE_PASS_PATHS_REMAINING=3
CRITICAL_FINDINGS=0
MAJOR_FINDINGS=2
MINOR_FINDINGS=8
OWNER_PC_NON_ECONOMIC_GATES_AUTHORIZED=NO
PILOT_A_AUTHORIZED=NO
RUN_A_AUTHORIZED=NO
DATA_PROCESSING_AUTHORIZED=NO
```

**Síntese**

- **Núcleo correto.** A parte econômica e causal está fiel à R2.3: B1, rebind leve, verificação no uso, hash até o fim do arquivo, checkpoint e órfãos, `EXTREMA_LOSSLESS_FOR_DD`, GRID/FREEZE e o fixture MT5, que é cópia byte-idêntica da R6.
- **Bloqueio na cadeia de recibos.** O selo pré-piloto e o finalize pré-run-A aceitam evidência de geometria e do piloto que não está vinculada à identidade corrente (FP-1 e FP-2).
- **Resíduo normativo.** A §3.7(c) deixa um caminho aberto (FP-3), e esse texto é o que eu próprio propus.
- **Correções pequenas.** Ficam restritas a `gates` e `runner`, sem tocar economia, `core`, `io`, `preflight` ou `metrics`.
- **Por que `NO` agora.** As correções mudam `gate_suite_sha256` e `runner_sha256`, então qualquer recibo gerado hoje com a R1R5 ficaria obsoleto.

---

## 1. Integridade e delta (A)

- [x] ZIPs R1R4 e R1R5 íntegros; `SHA256SUMS.txt` interno 35/35 OK e idêntico à cópia em `EVIDENCE`.
- [x] Hashes de referência conferem:
  - R6 = `1A950132…`
  - SPEC V005R1 = `60CBE1A2…`
  - R2.3 do pacote = R2.3 auditada (`D6D79108…`)
- [x] Byte-idênticos à R1R4: `preflight.py` `3A2398FD…`, `io.py` `DC816C61…`, `metrics.py` `8CE1292F…` e `test_minotauro_v004.py`.
- [x] `CORE_IMPORTED_DEFINITIONS_SHA256` recalculado = `5605BE87…4DB4208`.
- [x] Identidades recalculadas: `runner_sha256` = `6E3D2AE7…0D8288` e `gate_suite_sha256` = `B0E0EB16…FB61AE`. Os 23 executáveis, launchers e o MQ5 estão todos cobertos por um dos dois manifests.
- [x] O delta de `core.py` restringe-se a:
  - contador B1;
  - `_update_hwm_dd` (regime_min e persistência);
  - `force_record=False` no OPEN_MARK de cutoff pendente;
  - reconciliação sessão × célula;
  - parâmetros de estado.

  Nenhuma regra de sinal, fill, custo ou cutoff foi alterada.
- [x] O laço mensal/sessão do runner tem a mesma semântica do R1R4: mesma ordem, commit antecipado e conjunto `wanted`.
  - Acréscimos: hasher, conferência D1, regime_min e modo piloto.
  - Removidos: comandos B/C e preflight; restam apenas `rebind-a`, `pilot-a` e `run-a`.

---

## 2. Matriz contrato → fonte → resultado

| Contrato | Fonte | Resultado |
|---|---|---|
| B1 §1.1/§1.5 — contador após atualização BID/ASK, só antes do cutoff | core l.770-773 (atualizações l.751-762; latch antes) | PASS |
| B1 §1.2 — N+1 rejeita estado cruzado, sem N+2 | core `_bbo_fresh` l.404; pending consumido l.487 | PASS |
| B1 §1.3 — posição preexistente usa só o lado executável | core l.450-478 (BUY=BID, SELL=ASK, sem teste de cruzamento) | PASS |
| B1 §1.4 — cutoff inalterado | core l.687-689 (cruzado adia); l.696/701 (timestamp próprio) | PASS |
| §1.5 — telemetria e schema | runner l.321; outputs l.271-273 | PASS |
| §3.1–3.2 — módulos e definições congelados | binding l.89-95; contract l.91-118 | PASS |
| §3.3 — 12 hashes, caminho exato, sem remapeamento | binding l.112-127 | PASS |
| §3.4 — re-derivação byte-idêntica + D1 | binding l.132-139 (tempdir) | PASS |
| §3.5 — extrato 250 + conferência no uso | binding l.141-156; runner l.140-153, l.559, l.570 | PASS |
| §3.6 — binding | binding l.162-187 | PASS |
| §3.7(a) — clean/resume conferidos antes de qualquer sessão | runner `_prepare_phase` l.460-465 | PASS |
| §3.7(b) — SHA256 de todos os bytes até EOF | io l.87-91 (congelado); runner l.544-552, l.590-593 | PASS |
| §3.7(c) — mês sem EOF registrado é relido | runner l.192-196, l.534-537 | PASS literal; resíduo FP-3 |
| §3.7(d) — hashes no checkpoint e no `RUN_MANIFEST` | runner l.235-236, l.594-595, l.364-365 | PASS |
| §3.7(e) — piloto vinculado | mesmo caminho, modo `PILOT_A` | PASS |
| Drift ⇒ fase inválida | runner l.592 (`INVALID_PHASE.marker`), l.460-461 | PASS |
| §2.2 — chaves do checkpoint + self-hash | runner l.44-51, l.122-130, l.241-260 | PASS |
| §2.3 — órfão em `_orphan/<s>__<n>`; sessão commitada sem diretório bloqueia | runner l.263-281 | PASS |
| Autorizações do owner (pilot/run-a) vinculadas às identidades | runner l.377-450 | PASS |
| run-a só com recibo 28 + autorização | runner l.410-438 | PASS, mas o recibo 28 pode ser obsoleto (FP-1) |
| §5.1 — grupo A forçado; grupo B com HWM ou mínimo do regime estritos | core l.351-393; l.439, l.561, l.732 | PASS |
| §5.2 — gate lossless nas 435 células | outputs l.170-187, l.275-285 | PASS |
| §5.3 — captura integral: baseline em 2025, todas as células no piloto | runner l.477, l.485 | PASS |
| §5.4 — `MODEL_ASSUMPTIONS` | outputs l.194-204 | PASS |
| §4 — `GRID_CELLS` com 450 linhas canônicas | outputs l.54-71 | PASS |
| §4 — FREEZE com chaves exatas + self-hash | outputs l.292-310 | PASS (m5) |
| §15 — seleção | metrics `select_2025` (inalterado); outputs l.74-117 | PASS |
| §19 — outputs antes do freeze | outputs l.246-287 | PASS (m6) |
| Sem fase 2026 nem `run-b` | runner l.632 | PASS |
| §6.1 — fixture R6-double verbatim | MQ5 l.40-128 = R6 l.122, 130, 747, 753, 851 (diff mecânico: idêntico) | PASS estático |
| §6.1 — cobertura 2024 + 250×3 + meio tick | gates l.237-280 | PASS (m8) |
| §6.1 — validate exato e bloqueio de toda divergência | gates l.283-330 | PASS |
| §6.1–6.2 — hashes no binding e no manifest | gates l.368-384; runner l.366-370 | **BLOCKED (FP-2)** |
| §6.2 — 97 linhas, 750/750 | gates l.204-213 | PASS |
| §6.3 — piloto = três primeiras sessões | runner l.486 | PASS |
| §6.3 — baseline com todos os trades + 1º trade por célula | gates l.417-469; reference | PASS (m2) |
| §6.3 — recibo do gate 28 vinculado | gates l.466, l.477-478 | **BLOCKED (FP-1)** |
| Launchers fail-closed; SAFE_STOP = 130 | RUN_PHASE l.32; demais scripts com `throw` | PASS (m7) |

---

## 3. §22 — os 28 gates e a evidência de cada um

| Gate | Evidência | Avaliação |
|---|---|---|
| 1 | G01 | mede o contrato |
| 2 | G02 + fixture MT5 + validate | adequado; o selo sofre de FP-2 |
| 3 | G03 | trigger, RR e Rmax OK; **Eq sem teste de fronteira** (m3) |
| 4, 5 | source l.165-185 (parsers independentes) | mede o contrato |
| 6, 7 | G06, G07 | OK |
| 8 | G08 + G13 | OK (500 ms inclusivo, regressão, cruzado sem aborto) |
| 9, 10, 11 | G09, G10, G11 + testes de cutoff do legado | OK |
| 12 | source l.187-202 | OK (recalcula P50/P95/P99/MAX e top-10) |
| 13–17 | G13–G17 + legado | OK |
| 18 | G18 + source (250/250 PASS) | OK |
| 19 | G19 | **asserção com disjunção trivial** (m3) |
| 20 | G20 | OK (DD recalculado dos persistidos = engine) |
| 21, 22, 24 | G21, G22, G24 | OK |
| 23 | G23 | cobre só 50 das 435 células (m3) |
| 25 | G25 | apenas textual (m3) |
| 26 | G26 + testes operacionais | recuperação OK; não é injeção de falha ponta a ponta (m4) |
| 27 | G27 + clean×resume operacional | OK em nível sintético (m4) |
| 28 | piloto + engine de referência + finalize | recibo sem identidade (FP-1); independência parcial (m2) |

**Guardas de execução:**
- `pilot-a` exige três condições (runner l.463-464 e l.481-482):
  - binding `PASS_SEALED_PREPILOT`;
  - `PRE_PILOT_GATE_RECEIPT` com 27 gates, vinculado;
  - `OWNER_PILOT_AUTHORIZATION` vinculado.
- `run-a` exige `PRE_RUN_A_GATE_RECEIPT` com 28 gates, vinculado, e `OWNER_RUN_A_AUTHORIZATION` (l.479).
- Nenhum launcher cria arquivos de autorização.

---

## 4. Findings por severidade

### CRITICAL — nenhum

### MAJOR

**M1 = FP-1 — O recibo do gate 28 não tem identidade, e o finalize aceita um PASS obsoleto.**
- `GATE28_PILOT_RECONCILIATION_RECEIPT.json` (gates l.466) não grava nenhum destes campos, e é o único recibo da cadeia nessa condição:
  - `spec_sha256`, `runner_sha256`, `gate_suite_sha256`, `run_source_binding_sha256`;
  - hash do `PRE_PILOT_GATE_RECEIPT`;
  - hash do `PILOT_RUN_RECEIPT`.
- `finalize_pre_run_gates` (l.477-478) confere apenas `== "PASS"`.
- `pilot_reconcile` não confere se `PILOT_A/RUN_MANIFEST.json` foi produzido sob o selo corrente.
- Se `pilot_reconcile` falha antes da l.467, o recibo PASS anterior não é invalidado.

**M2 = FP-2 — A evidência de geometria não está vinculada ao binding selado.**
- Os recibos `GEOMETRY_PREPARE` (l.278) e `GEOMETRY_PARITY` (l.326) não gravam o hash do `D1_PREDECESSOR_EXTRACT` nem o do binding.
- `seal_prepilot_gates` (l.341-357) confere apenas status e identidade de spec, runner e suite.
- O selo grava no binding os hashes dos arquivos (l.368-381), mas não os confronta com os valores declarados nos recibos: `prepare.input_sha256`, `prepare.replay_sha256`, `parity.replay_sha256` e `parity.mt5_output_sha256`.
- Se `validate_geometry` falha antes da l.326 (pontos de falha l.286-323), o PASS anterior não é invalidado.
- `RUN_PRE_RUN_A_GATES.ps1` (l.26) regenera o prepare a cada execução. Por isso o caminho é alcançável apenas com os launchers documentados.

### MINOR

| # | Finding | Fonte |
|---|---|---|
| m1 | FP-3: resíduo normativo da §3.7(c) | runner l.192-196, l.534-595 |
| m2 | A engine de referência do gate 28 tem máquina de estados própria, mas importa `build_grid`, `trigger_reached`, `rr_pass`, `rmax_pass`, `pnl_units`, as constantes e o parser `io`. Um defeito nesses primitivos se replicaria nos dois lados. G1–G3 e a paridade MT5 mitigam o risco; o recibo deve declarar a independência como parcial | reference l.6-9; gates l.466 |
| m3 | Asserções fracas: G03 repete `eq_price(100,100)` sem testar ±0,5 micro; G19 passa pelo `ELIGIBLE_SKIPPED_BUSY` emitido pela própria célula ocupada; G23 limita-se a 50 células; G25 é apenas textual | test_gates l.51, l.172, l.203, l.216-219 |
| m4 | G26 e G27 simulam estados de disco e usam `SessionResult` sintéticos; não conduzem `run_phase_a` com arquivo de ticks sintético, interrupção e resume. O rótulo `PASS_FAULT_INJECTION` superestima o que é testado | test_operational l.81-133; gates l.100 |
| m5 | A R2.3 §3.6 manda os hashes das §§3.2–3.5 "também" ao checkpoint e ao FREEZE_A, mas eles só entram de forma transitiva, via `run_source_binding_sha256`. Não abre falso-pass | outputs l.292-308; runner l.220-238 |
| m6 | `economic_output_paths` omite em silêncio arquivo ausente do `ECONOMIC_OUTPUTS_SHA256SUMS` | outputs l.223 |
| m7 | Launchers: (1) o fallback `python.exe` do PATH não exige 3.14; (2) nenhum log ou transcript é persistido, contra a regra do owner de manter o log sempre na pasta correta, independentemente do diretório corrente; (3) `RUN_PRE_RUN_A_GATES.ps1` executa, na verdade, passos pré-piloto | `Resolve-RealPython` (fallback PATH) em todos os `.ps1` |
| m8 | Na amostra 2024, uma barra inválida no primeiro dia do mês é descartada em silêncio (`continue`), reduzindo a cobertura sem falhar | gates l.255 |

---

## 5. Falso-pass nominal

**FP-1 (MAJOR)**
1. O piloto vX é reconciliado com PASS.
2. Faz-se uma correção pós-piloto, permitida pela §6.3, gerando vY.
3. Refaz-se o rebind, que é permitido porque não há sessão nem checkpoint em `PHASE_A`.
4. Rodam os gates e esvazia-se `PILOT_A`, como o selo exige (l.338).
5. Sela-se vY e roda-se `pilot-a` vY.
6. `pilot-reconcile` vY lança exceção antes da l.467 (por exemplo, `REFERENCE_POSITION_NOT_FLAT` ou sessão ausente).
7. Roda-se `gates.py finalize`.

Resultado: `PRE_RUN_A_GATES=PASS, gates_passed=28` para vY, sustentado pelo gate 28 de vX. Pelo launcher o caminho é interrompido no passo 6; pela CLI pública `finalize`, ele se fecha.

**FP-2 (MAJOR)**
1. Executa-se a sequência completa v1: rebind → source → prepare → MT5 → validate PASS.
2. Refaz-se o rebind (v2) com um `IND@N.csv` cujo histórico mudou, por exemplo numa reexportação. `_validate_d1` só testa a sanidade OHLC e não detecta a mudança.
3. Roda-se `RUN_PRE_RUN_A_GATES.ps1`, que refaz source v2 e prepare v2.
4. Sela-se sem novo validate, ou após um validate que falhou antes de gravar o recibo.

Resultado: binding `PASS_SEALED_PREPILOT` com `geometry_replay_exact_sha256` da v2 e `geometry_mt5_output_sha256` da v1. A paridade R6-double fica declarada para grades que nunca foram comparadas. O gate de 97 linhas continua correto, porque é refeito no source v2; o que perde evidência é a §6.1.

**FP-3 (MINOR; resíduo normativo)**
1. Na execução 1, o mês M é lido com bytes divergentes do binding.
2. As sessões s1…sk são commitadas e a execução é interrompida antes do fim do arquivo.
3. O arquivo é restaurado byte a byte, por exemplo a partir de backup.
4. O resume relê M inteiro, o hash no fim do arquivo confere e M entra em `verified_months`.

Resultado: s1…sk continuam derivadas dos bytes divergentes. A implementação segue literalmente a §3.7(c); a lacuna está no texto normativo, que é o que eu propus no parecer R2.2 (`17_…`) e que a R2.3 incorporou. Declaro o erro.

---

## 6. Correções necessárias (R1R6)

Nenhuma das correções obrigatórias altera economia, `core`, `io`, `preflight` ou `metrics`.

1. **FP-1**
   - `pilot_reconcile` invalida qualquer recibo GATE28 existente antes de começar.
   - `pilot_reconcile` confere `PILOT_A/RUN_MANIFEST.json`: spec, runner, grid, binding e `gate_receipt_sha256` igual ao hash do `PRE_PILOT_GATE_RECEIPT` corrente. Confere também os hashes mensais do piloto.
   - O recibo passa a gravar spec, runner, suite, binding, `pre_pilot_gate_receipt_sha256` e `pilot_run_receipt_sha256`.
   - `finalize_pre_run_gates` exige que todos esses valores sejam iguais aos correntes.
2. **FP-2**
   - O prepare grava `d1_predecessor_extract_sha256`, `ind_d1_sha256` e `run_source_binding_sha256` (pré-selo).
   - O validate invalida o recibo anterior ao iniciar e grava `input_sha256` e `prepare_receipt_sha256`.
   - O selo confronta cada hash declarado nos recibos com o arquivo correspondente e com o binding corrente; qualquer divergência bloqueia.
   - Defesa adicional: `rebind-a` recusa um `GATES/` que contenha recibos de outro binding.
3. **FP-3** — endurecimento compatível com a R2.3 e sem tocar `io`:
   - Um hasher-proxy passado a `iter_tick_file` registra, no `session_receipt` de cada sessão commitada, o par `(bytes_lidos, sha256_prefixo)` no instante do commit.
   - No resume de um mês não verificado, a releitura obrigatória confere cada prefixo no mesmo offset. Divergência ⇒ `RUN_BLOCKED_TICK_DRIFT` e invalidação da fase.
   - Alternativa mais cara: recomputar as sessões já commitadas do mês e exigir bundles byte-idênticos.
   - Recomendo registrar o esclarecimento numa emenda editorial futura.

**Recomendadas no mesmo ciclo:**
- **m3:** testar Eq em ±0,5 micro; em G19, `assertTrue(e.pending_active[1])` isolado; G23 nas 435 células.
- **m4:** teste ponta a ponta com arquivo de ticks sintético, `KeyboardInterrupt` e resume.
- **m5:** chaves explícitas adicionais no freeze.
- **m6:** exigir a presença de todos os nomes esperados.
- **m7:** `Start-Transcript` em `<out_root>\LOGS\`, com caminho absoluto; exigir 3.14 também no fallback.
- **m8:** falhar, ou usar a primeira barra válida do mês.

Em seguida, uma reauditoria mecânica curta, restrita ao diff R1R5 → R1R6.

---

## 7. O que o owner poderá rodar no PC

**Agora, com a R1R5: nada.** Os recibos ficariam obsoletos assim que `gate_suite_sha256` e `runner_sha256` mudarem na R1R6.

**Após R1R6 e reauditoria com PASS**, nesta ordem e apenas gates não econômicos:
1. Copiar `config.example.json` para `config.json` e revisar os caminhos `D:\…`. Os scripts usam `$PSScriptRoot` e podem ser chamados a partir de `C:\Users\silvi`.
2. `RUN_LIGHT_REBIND_A.ps1` — leitura pura para hash dos 12 arquivos de ticks e re-derivação M1/D1, sem processamento econômico.
3. `RUN_PRE_RUN_A_GATES.ps1` — py_compile, sintéticos, operacionais, source (gates 4/5/12/18 e 97 linhas), geometry-prepare e status.
4. MetaEditor/MT5:
   - copiar `GATES\GEOMETRY_INPUT_R23.csv` para `MQL5\Files\MINOTAURO_GEOMETRY_INPUT_R23.csv`;
   - compilar e executar `Minotauro_Geometry_Parity_R23.mq5`.
5. `RUN_GEOMETRY_VALIDATE.ps1 -Mt5Output <…\MQL5\Files\MINOTAURO_GEOMETRY_MT5_R23.csv>`.
6. `RUN_SEAL_PREPILOT_GATES.ps1` — parar em `PRE_PILOT_GATES=PASS_27_OF_27`.

**Nunca nesta etapa:**
- `RUN_GATE28_PILOT.ps1`;
- `RUN_PHASE.ps1 -Command pilot-a` ou `-Command run-a`;
- criação de `OWNER_PILOT_AUTHORIZATION.json` ou `OWNER_RUN_A_AUTHORIZATION.json`.

---

## 8. Limites desta auditoria

- O MQL5 não foi compilado nem executado; o PASS do fixture é estático.
  - Se o MT5 interpretar mal o CSV com terminador `\n`, o validate falha fechado por divergência do conjunto de casos.
- Nenhum teste foi executado. O log 51/51 do builder foi tratado apenas como alegação e não sustenta nenhuma conclusão acima.
- O arquivo `OWNER_SUPPLIED_OPUS55_R2_3_FINAL_VERDICT.md` foi tratado como evidência textual fornecida pelo owner.
