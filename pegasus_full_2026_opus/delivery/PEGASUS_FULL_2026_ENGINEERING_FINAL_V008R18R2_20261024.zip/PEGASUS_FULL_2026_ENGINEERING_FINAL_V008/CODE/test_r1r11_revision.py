"""Targeted V003R2 ownership, interrupted merge and exact serializer checks."""
from pathlib import Path
import ast
import gzip
import hashlib
import json
import subprocess
import sys
import tempfile
import unittest

class Revision(unittest.TestCase):
    def test_frozen_serializer_and_prefix_tracker(self):
        root=Path(__file__).parent
        def code(path,name):
            text=path.read_text();tree=ast.parse(text)
            return ast.get_source_segment(text,next(n for n in tree.body if getattr(n,'name',None)==name))
        for name in ('gzjson','_PrefixHashTracker'):
            self.assertEqual(code(root/'minotauro_v004_runner.py',name),
                             code(root/'oracle/minotauro_v004_runner.py',name))

    def test_strict_scratch_frame(self):
        from minotauro_v004_core import ModelError,valid_cells
        from r1r11_transport import ScratchSink,read_scratch
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'scratch.gz';cells=valid_cells()
            sink=ScratchSink(p,'events',cells)
            row={'event':'ENTRY','ordinal':1,'cell_ids':[cells[0].cell_id]}
            sink.append(row);sink.close()
            self.assertEqual(list(read_scratch(p,'events',sink.index,sink.rank))[0][1],row)
            with gzip.open(p,'wt',encoding='utf-8') as f:f.write(json.dumps(row)+' garbage\n')
            with self.assertRaisesRegex(ModelError,'FRAME_INVALID'):
                list(read_scratch(p,'events',sink.index,sink.rank))

    def test_threaded_commit_faults_resume_with_different_worker_count(self):
        from r1r11_fixtures import generate
        root=Path(__file__).parent
        with tempfile.TemporaryDirectory() as td:
            base=Path(td);generate(base/'inputs',heavy_cycles=1)
            def run(out,role='candidate',workers=2,fault=None):
                args=[sys.executable,'-B',str(root/'r1r11_fixtures.py'),'--inputs',str(base/'inputs'),
                      '--out',str(out),'--role',role,'--workers',str(workers),'--only','pending_cancel']
                if fault:args+=['--fault',json.dumps({'point':fault,'kind':'stop'})]
                return subprocess.run(args,capture_output=True,text=True)
            def tree(out):
                return {p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in [*(out/'sessions').rglob('*'),out/'CHECKPOINT.json'] if p.is_file()}
            oracle=base/'oracle';p=run(oracle,role='oracle');self.assertEqual(p.returncode,0,p.stderr)
            for point in ('during_merge','after_commit_before_checkpoint'):
                out=base/point;p=run(out,fault=point)
                self.assertNotEqual(p.returncode,0)
                self.assertIn('FAULT_'+point.upper(),p.stderr)
                cp=json.loads((out/'CHECKPOINT.json').read_text())
                self.assertEqual(cp['completed'],['1999-12-31'])
                p=run(out,workers=3)
                self.assertNotEqual(p.returncode,0)
                self.assertIn('STALE_SCRATCH_PURGED_RESUME_REQUIRED',p.stderr)
                p=run(out,workers=3);self.assertEqual(p.returncode,0,p.stderr)
                self.assertEqual(tree(oracle),tree(out))
                report=json.loads((out/'SYNTHETIC_EXECUTION.json').read_text())
                self.assertEqual({r['pid'] for r in report['canonical_writes']},{report['coordinator_pid']})

if __name__=='__main__':unittest.main(verbosity=2)
