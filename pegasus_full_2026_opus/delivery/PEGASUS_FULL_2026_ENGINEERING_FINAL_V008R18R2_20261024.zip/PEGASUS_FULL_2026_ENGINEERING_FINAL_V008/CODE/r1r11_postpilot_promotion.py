from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from minotauro_v004_core import ModelError
from minotauro_v005r1_r23_contract import (
    SPEC_SHA256, canonical_json_hash, config_hash, gate_identity, read_json,
    runner_identity, sha256_file, write_json_atomic_canonical,
)
from r1r11_resources import HARD_CAP_MIB, REGISTERED_RAM_MIB

PILOT_SESSIONS = {"2025-01-02", "2025-01-03", "2025-01-06"}
CANONICAL_SESSION_FILES = {
    "trades.jsonl.gz", "events.jsonl.gz", "equity.jsonl.gz",
    "equity_reconciliation.jsonl.gz", "session_receipt.json",
}
ADVERSE = (
    "RUN_BLOCKED=", "Traceback", "TICK_PREFIX_DRIFT", "RESUME_HASH_MISMATCH",
    "INVALID_PHASE", "MEMORY_CAP_SAFE_STOP",
)


def _must(path: Path, label: str) -> Path:
    if not path.is_file():
        raise ModelError(f"PP_REQUIRED_FILE_MISSING {label} {path}")
    return path


def _load_json(path: Path, label: str) -> dict:
    obj = read_json(_must(path, label))
    if not isinstance(obj, dict):
        raise ModelError(f"PP_JSON_NOT_OBJECT {label}")
    return obj


def _pp1(root: Path, pkg: Path) -> dict:
    gates = root / "GATES"
    rh, _ = runner_identity(pkg); gh, _ = gate_identity(pkg)
    pre_p = gates / "PRE_PILOT_GATE_RECEIPT.json"
    g28_p = gates / "GATE28_PILOT_RECONCILIATION_RECEIPT.json"
    pre_run_p = gates / "PRE_RUN_A_GATE_RECEIPT.json"
    pre = _load_json(pre_p, "PRE_PILOT")
    g28 = _load_json(g28_p, "GATE28")
    pre_run = _load_json(pre_run_p, "PRE_RUN_A")
    bind_p = root / "PHASE_A" / "RUN_SOURCE_BINDING_A.json"
    binding = _load_json(bind_p, "BINDING")
    if binding.get("status") != "PASS_SEALED_PREPILOT":
        raise ModelError("PP1_BINDING_NOT_SEALED")
    expected = {"spec_sha256":SPEC_SHA256,"runner_sha256":rh,"gate_suite_sha256":gh}
    for label,obj in (("PRE_PILOT",pre),("GATE28",g28),("PRE_RUN_A",pre_run)):
        for k,v in expected.items():
            if obj.get(k)!=v: raise ModelError(f"PP1_IDENTITY_DRIFT {label} {k}")
    if g28.get("pre_pilot_gate_receipt_sha256") != sha256_file(pre_p):
        raise ModelError("PP1_HASH_CHAIN_27_TO_28")
    if pre_run.get("gate28_pilot_reconciliation_receipt_sha256") != sha256_file(g28_p):
        raise ModelError("PP1_HASH_CHAIN_28_TO_PRE_RUN")
    auth_p=gates/"OWNER_PILOT_AUTHORIZATION.json"; auth=_load_json(auth_p,"OWNER_PILOT_AUTH")
    checks={"PILOT_AUTHORIZED":"YES","spec_sha256":SPEC_SHA256,"runner_sha256":rh,
            "run_source_binding_sha256":sha256_file(bind_p),"pre_pilot_gate_receipt_sha256":sha256_file(pre_p)}
    for k,v in checks.items():
        if auth.get(k)!=v: raise ModelError(f"PP1_OWNER_PILOT_AUTH_STALE {k}")
    return {"status":"PASS","runner_sha256":rh,"gate_suite_sha256":gh,
            "pre_pilot_sha256":sha256_file(pre_p),"gate28_sha256":sha256_file(g28_p),
            "pre_run_sha256":sha256_file(pre_run_p),"binding_sha256":sha256_file(bind_p)}


def _pp2(root: Path) -> dict:
    pilot=root/"PILOT_A"; sessions=pilot/"sessions"; gates=root/"GATES"
    run=_load_json(pilot/"PILOT_RUN_RECEIPT.json","PILOT_RUN")
    if run.get("PILOT_RUN")!="PASS" or set(run.get("sessions",[]))!=PILOT_SESSIONS:
        raise ModelError("PP2_PILOT_RUN_NOT_CANONICAL_3")
    actual={p.name for p in sessions.iterdir() if p.is_dir()} if sessions.is_dir() else set()
    if actual!=PILOT_SESSIONS: raise ModelError(f"PP2_SESSION_SET {sorted(actual)}")
    hashes={}
    for s in sorted(PILOT_SESSIONS):
        d=sessions/s; names={p.name for p in d.iterdir() if p.is_file()}
        if names!=CANONICAL_SESSION_FILES:
            raise ModelError(f"PP2_SESSION_FILES session={s} names={sorted(names)}")
        hashes[s]={n:sha256_file(d/n) for n in sorted(names)}
    g28=_load_json(gates/"GATE28_PILOT_RECONCILIATION_RECEIPT.json","GATE28")
    if g28.get("GATE28_PILOT_RECONCILIATION")!="PASS" or int(g28.get("mismatch_count",-1))!=0:
        raise ModelError("PP2_GATE28_NOT_ZERO")
    diff=_must(gates/"GATE28_PILOT_RECONCILIATION_DIFF.csv","GATE28_DIFF")
    lines=diff.read_text(encoding="utf-8-sig").splitlines()
    if len(lines)!=1: raise ModelError(f"PP2_GATE28_DIFF_ROWS {max(0,len(lines)-1)}")
    pre=_load_json(gates/"PRE_RUN_A_GATE_RECEIPT.json","PRE_RUN")
    if pre.get("PRE_RUN_A_GATES")!="PASS" or int(pre.get("gates_passed",0))!=28:
        raise ModelError("PP2_PRE_RUN_NOT_28_OF_28")
    bad=[]
    for p in root.rglob("*"):
        n=p.name.lower()
        if n.endswith(".pending") or "_orphan" in n or n=="invalid_phase.marker": bad.append(str(p))
    if bad: raise ModelError("PP2_PENDING_OR_ORPHAN "+"|".join(bad[:10]))
    return {"status":"PASS","sessions":sorted(PILOT_SESSIONS),"session_file_hashes":hashes,
            "gate28_mismatch_count":0,"pre_run_gates":28}


def _pp3(root: Path, transcript: str) -> dict:
    op=_load_json(root/"GATES"/"OPERATIONAL_GATES_RECEIPT.json","OPERATIONAL")
    if op.get("OPERATIONAL_GATES")!="PASS": raise ModelError("PP3_OPERATIONAL_GATES_NOT_PASS")
    # R1R11 keeps launcher evidence outside the frozen gate receipt; bind it here.
    if not re.search(r"PSVersion(?:=|\s+)5\.1", transcript, re.I):
        raise ModelError("PP3_POWERSHELL_5_1_NOT_PROVED")
    if "R1R11_LAUNCHER_SELFTEST=PASS" not in transcript:
        raise ModelError("PP3_R1R11_LAUNCHER_SELFTEST_MISSING")
    return {"status":"PASS","operational_receipt_sha256":sha256_file(root/"GATES"/"OPERATIONAL_GATES_RECEIPT.json"),
            "powershell":"5.1","launcher_selftest":"PASS"}


def _telemetry(root: Path) -> tuple[Path,list[dict]]:
    p=_must(root/"TELEMETRY"/"PILOT_A_R1R11_MEMORY.jsonl","PILOT_TELEMETRY")
    rows=[]
    for i,line in enumerate(p.read_text(encoding="utf-8").splitlines(),1):
        try: row=json.loads(line)
        except Exception as e: raise ModelError(f"PP4_TELEMETRY_JSON line={i}") from e
        if row.get("schema")!="R1R11_MEMORY_V1" or row.get("mode")!="PILOT_A":
            raise ModelError(f"PP4_TELEMETRY_SCHEMA_MODE line={i}")
        if not str(row.get("probe","")).startswith("WIN32_"):
            raise ModelError(f"PP4_TELEMETRY_PROBE line={i}")
        if int(row.get("cap_mib",-1))!=HARD_CAP_MIB:
            raise ModelError(f"PP4_TELEMETRY_CAP line={i}")
        rows.append(row)
    return p,rows


def _pp4(root: Path, transcript: str) -> dict:
    p,rows=_telemetry(root)
    commits=[r for r in rows if r.get("event")=="SESSION_COMMIT"]
    sessions=[r.get("session") for r in commits]
    if set(sessions)!=PILOT_SESSIONS or len(sessions)!=3:
        raise ModelError(f"PP4_SESSION_COMMIT_SET {sessions}")
    events={r.get("event") for r in rows}
    if not {"RUN_START","PRE_PILOT_RECEIPT"}.issubset(events):
        raise ModelError("PP4_REQUIRED_BOUNDARIES_MISSING")
    for r in commits:
        s=str(r["session"]); peak=float(r["JOB_PEAK_BOUND_RUN"])/(1024**2)
        pat=rf"MEMORY_TELEMETRY event=SESSION_COMMIT mode=PILOT_A session={re.escape(s)} .*JOB_PEAK_BOUND_RUN_MIB={peak:.1f}"
        if not re.search(pat,transcript): raise ModelError(f"PP4_TRANSCRIPT_CROSSCHECK session={s}")
    return {"status":"PASS","telemetry_sha256":sha256_file(p),"lines":len(rows),"session_commits":sessions}


def _pp5(root: Path, transcript: str) -> dict:
    p,rows=_telemetry(root)
    peak=max(int(r.get("observed_peak_bytes",0)) for r in rows)
    if peak>HARD_CAP_MIB*1024**2: raise ModelError("PP5_MEMORY_CAP_EXCEEDED")
    if any(bool(r.get("cap_exceeded",False)) for r in rows): raise ModelError("PP5_CAP_EXCEEDED_FLAG")
    if "MEMORY_CAP_SAFE_STOP" in transcript: raise ModelError("PP5_MEMORY_CAP_SAFE_STOP")
    return {"status":"PASS","max_observed_peak_bytes":peak,"cap_bytes":HARD_CAP_MIB*1024**2,"telemetry_sha256":sha256_file(p)}


def _pp6(transcript: str) -> dict:
    if "RUN_START mode=PILOT_A" not in transcript: raise ModelError("PP6_PILOT_START_MISSING")
    progress=[x for x in transcript.splitlines() if "RUN_PROGRESS=" in x and "PHASE=PILOT_A" in x and "MEM_CAP_MIB=" in x]
    commits=[x for x in transcript.splitlines() if "MEMORY_TELEMETRY event=SESSION_COMMIT mode=PILOT_A" in x]
    if not progress: raise ModelError("PP6_LIVE_PROGRESS_MISSING")
    if len(commits)!=3: raise ModelError(f"PP6_COMMIT_TELEMETRY_COUNT {len(commits)}")
    return {"status":"PASS","progress_lines":len(progress),"commit_lines":len(commits)}


def _pp7(root: Path, cfg: dict) -> dict:
    cp=_load_json(root/"PILOT_A"/"CHECKPOINT.json","PILOT_CHECKPOINT")
    h=config_hash(cfg)
    if cp.get("config_sha256")!=h: raise ModelError("PP7_CONFIG_HASH_MISMATCH")
    return {"status":"PASS","config_sha256":h}


def _pp8(root: Path, transcript: str) -> dict:
    bad=[m for m in ADVERSE if m in transcript]
    if bad: raise ModelError("PP8_ADVERSE_MARKERS "+",".join(bad))
    # SAFE_STOP/ORPHAN are tolerated only because PP2 has already passed before PP8 is evaluated.
    return {"status":"PASS","adverse_markers":[],"recovered_markers":[m for m in ("SAFE_STOP=YES","ORPHAN_MOVED") if m in transcript]}


def _pp9(root: Path) -> dict:
    tpath,rows=_telemetry(root)
    # Every scheduler grant already hard-fails when physical RAM differs from REGISTERED_RAM_MIB.
    # Re-prove it from persisted transport/scheduler telemetry when available.
    sched=root/"TELEMETRY"/"R1R11_TRANSPORT.jsonl"
    if not sched.is_file(): raise ModelError("PP9_TRANSPORT_TELEMETRY_MISSING")
    rams=[]; grants=[]
    for line in sched.read_text(encoding="utf-8").splitlines():
        try:o=json.loads(line)
        except Exception: continue
        if o.get("event")!="SCHEDULER": continue
        d=o.get("decision",{}); rams.append(int(d.get("ram_mib",-1))); grants.append(int(d.get("granted",0)))
    if not rams or any(x!=REGISTERED_RAM_MIB for x in rams): raise ModelError(f"PP9_REGISTERED_RAM_MISMATCH {rams[:10]}")
    if not grants or min(grants)<2: raise ModelError(f"PP_MULTIWORK_GRANT_LT2 {grants[:10]}")
    return {"status":"PASS","registered_ram_mib":REGISTERED_RAM_MIB,"scheduler_events":len(rams),"min_grant":min(grants),
            "telemetry_sha256":sha256_file(tpath),"transport_sha256":sha256_file(sched)}


def promote(cfg: dict, package_root: Path, transcript_path: Path) -> dict:
    root=Path(cfg["out_root"]); transcript=_must(transcript_path,"CHAIN_TRANSCRIPT").read_text(encoding="utf-8",errors="replace")
    pps={}
    pps["PP1"]=_pp1(root,package_root)
    pps["PP2"]=_pp2(root)
    pps["PP3"]=_pp3(root,transcript)
    pps["PP4"]=_pp4(root,transcript)
    pps["PP5"]=_pp5(root,transcript)
    pps["PP6"]=_pp6(transcript)
    pps["PP7"]=_pp7(root,cfg)
    pps["PP8"]=_pp8(root,transcript)
    pps["PP9"]=_pp9(root)
    rh,_=runner_identity(package_root)
    receipt={
        "R1R11_POSTPILOT_PROMOTION":"PASS","PP1_PP9":"PASS_9_OF_9",
        "spec_sha256":SPEC_SHA256,"runner_sha256":rh,"config_sha256":config_hash(cfg),
        "chain_transcript_sha256":sha256_file(transcript_path),"criteria":pps,
        "RUN_A_PROMOTABLE":"YES_PENDING_OWNER_AUTHORIZATION",
    }
    out=root/"GATES"/"R1R11_POSTPILOT_PROMOTION_RECEIPT.json"
    write_json_atomic_canonical(out,receipt)
    return receipt


def main() -> None:
    ap=argparse.ArgumentParser(); ap.add_argument("--config",required=True); ap.add_argument("--transcript",required=True)
    ns=ap.parse_args(); cfg=json.loads(Path(ns.config).read_text(encoding="utf-8")); pkg=Path(__file__).resolve().parent
    print(json.dumps(promote(cfg,pkg,Path(ns.transcript)),ensure_ascii=False,sort_keys=True,indent=2))


if __name__=="__main__": main()
