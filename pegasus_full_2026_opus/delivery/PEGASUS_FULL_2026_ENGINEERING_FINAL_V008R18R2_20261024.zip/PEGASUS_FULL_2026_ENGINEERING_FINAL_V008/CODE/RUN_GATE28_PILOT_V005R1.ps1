#requires -Version 5.1
[CmdletBinding()] param([Parameter(Mandatory=$true)][string]$Config,[ValidateRange(2,12)][int]$Workers=12)
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'POWERSHELL_5_1_REQUIRED' }
. (Join-Path $PSScriptRoot 'Minotauro_Launcher_Common.ps1')
$ConfigPath=[IO.Path]::GetFullPath($Config);$Owned=Start-MinotauroTranscript -Config $ConfigPath -LauncherName $MyInvocation.MyCommand.Name
try {
 $Python=Resolve-RealPython
 $code=Invoke-MinotauroPython -Python $Python -Arguments @('-X','utf8','-B',(Join-Path $PSScriptRoot 'r1r11_activation_controller.py'),'pilot-a','--config',$ConfigPath,'--workers',[string]$Workers,'--batch-rows','32')
 if($code-ne 0){exit $code}
 $code=Invoke-MinotauroPython -Python $Python -Arguments @((Join-Path $PSScriptRoot 'minotauro_v005r1_r23_gates.py'),'pilot-reconcile','--config',$ConfigPath)
 if($code-ne 0){throw "PILOT_RECONCILE_FAIL=$code"}
 $code=Invoke-MinotauroPython -Python $Python -Arguments @((Join-Path $PSScriptRoot 'minotauro_v005r1_r23_gates.py'),'finalize','--config',$ConfigPath)
 if($code-ne 0){throw "PRE_RUN_GATE_FINALIZE_FAIL=$code"}
 Write-Host 'PRE_RUN_A_GATES=PASS_28_OF_28'
 Write-Host ('CHAIN_TRANSCRIPT=' + $env:MINOTAURO_TRANSCRIPT_PATH)
} finally {Stop-MinotauroTranscriptSafe -Owned $Owned}
