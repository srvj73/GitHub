param([string]$Config = "$PSScriptRoot\config.json")
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Minotauro_Launcher_Common.ps1"
$TranscriptOwned = Start-MinotauroTranscript -Config $Config -LauncherName $MyInvocation.MyCommand.Name
try {
    $Python=Resolve-RealPython
    $ExitCode = Invoke-MinotauroPython -Python $Python -Arguments @("$PSScriptRoot\minotauro_v005r1_r23_gates.py",'geometry-prepare','--config',$Config)
    if ($ExitCode -ne 0) { throw "GEOMETRY_PREPARE_FAIL=$ExitCode" }
    Write-Host ''
    Write-Host 'NEXT_MANUAL_MT5_STEP:'
    Write-Host '1) Copie GATES\GEOMETRY_INPUT_R23.csv para MQL5\Files como MINOTAURO_GEOMETRY_INPUT_R23.csv.'
    Write-Host '2) Compile e execute MQL5\Minotauro_Geometry_Parity_R23.mq5 no MetaTrader 5.'
    Write-Host '3) O MT5 gerara MINOTAURO_GEOMETRY_MT5_R23.csv em MQL5\Files.'
    Write-Host '4) Rode RUN_GEOMETRY_VALIDATE.ps1 -Mt5Output <caminho-do-csv>.'
}
finally {
    Stop-MinotauroTranscriptSafe -Owned $TranscriptOwned
}
