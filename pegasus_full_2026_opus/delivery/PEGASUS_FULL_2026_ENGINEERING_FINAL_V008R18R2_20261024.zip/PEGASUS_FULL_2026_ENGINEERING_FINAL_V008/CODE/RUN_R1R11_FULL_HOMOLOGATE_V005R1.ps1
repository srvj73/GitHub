#requires -Version 5.1
[CmdletBinding()] param(
 [Parameter(Mandatory=$true)][string]$Config,
 [Parameter(Mandatory=$true)][string]$FullRunTranscript
)
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'POWERSHELL_5_1_REQUIRED' }
. (Join-Path $PSScriptRoot 'Minotauro_Launcher_Common.ps1'); $Python=Resolve-RealPython
Write-Host 'AMBIENTE=PowerShell R1R11_V005R1_FULL_HOMOLOGATION SESSIONS_REQUIRED=250 MONTHS_REQUIRED=12'
& $Python -X utf8 -B (Join-Path $PSScriptRoot 'r1r11_full_homologation.py') `
  --config ([IO.Path]::GetFullPath($Config)) `
  --transcript ([IO.Path]::GetFullPath($FullRunTranscript))
exit $LASTEXITCODE
