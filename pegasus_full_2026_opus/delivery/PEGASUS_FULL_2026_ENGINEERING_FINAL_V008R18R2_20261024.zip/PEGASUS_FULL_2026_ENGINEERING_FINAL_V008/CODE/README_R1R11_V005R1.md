# MINOTAURO R1R11 V005R1 — OWNER WORKFLOW

This package is a new implementation revision. It does not claim owner-Windows
PASS. The build is sealed for owner execution only after `SHA256SUMS.txt` is
verified.

## Mandatory order

1. A0 read-only collection from preserved V004R2R1 evidence.
2. A0 non-gate microbench + offline economic equality + GO/NO-GO.
3. V005R1 development benchmark: 3/3 heavy pairs, each >=1.667 and byte-equal.
4. Fresh owner G1–G3 in a NEW owner evidence root.
5. G4 one-shot only via `RUN_R1R11_G4_V005R1.ps1` (requires A0 GO + dev 3/3).
6. If and only if G4 PASS, resume owner G5–G11.
7. Build final audit package; obtain one independent final pre-Pilot PASS.
8. Bind the independent audit report with `RUN_R1R11_BIND_FINAL_AUDIT_V005R1.ps1`.
9. Only then start real-source chain: rebind A -> synthetic PS5.1 -> operational ->
   PRE_RUN_A gates 1–26 -> geometry -> seal 27/27.
10. Owner explicitly authorizes Pilot A.
11. Pilot A (3 sessions) -> Gate28 -> PRE_RUN_A 28/28.
12. Run PP1–PP9 mechanical promotion using the complete chain transcript.
13. Owner explicitly authorizes Run A.
14. Full Run 250 sessions via the V005 activation controller, then final report/homologation.

## Permanent blocks

- Never rerun a consumed G4 identity.
- Never run G5–G11 after a G4 FAIL.
- Never use real data before the final independent pre-Pilot audit is bound.
- Never bypass `r1r11_activation_controller.py`; frozen `minotauro_v004_runner.py`
  intentionally remains disabled for rebind/pilot/run.
- Never treat unexecuted owner gates as PASS.
