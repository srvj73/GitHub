param([string]$Config = "$PSScriptRoot\config.json")
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Minotauro_Launcher_Common.ps1"
$TranscriptOwned = Start-MinotauroTranscript -Config $Config -LauncherName $MyInvocation.MyCommand.Name
try {
    & "$PSScriptRoot\RUN_PHASE.ps1" -Command 'rebind-a' -Config $Config
    if ($LASTEXITCODE -ne 0) { throw "REBIND_FAIL=$LASTEXITCODE" }
    Write-Host 'LIGHTWEIGHT_HASH_AND_D1_REBIND=PASS'
    Write-Host 'HEAVY_55_3_GIB_PREFLIGHT_RERUN_REQUIRED=NO'
    Write-Host 'ECONOMIC_DATA_PROCESSING=NO'
}
finally {
    Stop-MinotauroTranscriptSafe -Owned $TranscriptOwned
}
