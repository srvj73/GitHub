"""Small development checks. Full owner gates are a separate explicit command."""
import dataclasses
import json
from pathlib import Path
import tempfile
import subprocess
import sys
import unittest

from minotauro_v004_core import D1Bar, SessionEngine, TickRecord, valid_cells, PRICE_SCALE
from minotauro_v004_io import parse_tick_fields
from r1r11_transport import encode_record, decode_records
from r1r11_resources import RunLock, JobMemory
from r1r11_coordinator import Runtime


class Targeted(unittest.TestCase):
    def test_prefix_and_five_files_pending_cancel(self):
        self.differential('pending_cancel')

    def test_deferred_cutoff_global_termination(self):
        self.differential('deferred')

    def test_target_passed_causal_fixture(self):
        self.differential('target_passed')

    def differential(self,scenario):
        from r1r11_fixtures import generate
        from minotauro_v005r1_r23_contract import sha256_file
        with tempfile.TemporaryDirectory() as td:
            base=Path(td);generate(base/'inputs',heavy_cycles=1)
            for role in ('oracle','candidate'):
                result=subprocess.run([sys.executable,'-B',str(Path(__file__).parent/'r1r11_fixtures.py'),
                    '--inputs',str(base/'inputs'),'--out',str(base/role),'--role',role,'--workers','2',
                    '--only',scenario],capture_output=True,text=True)
                self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            def tree(role):
                return {str(p.relative_to(base/role/'sessions')):sha256_file(p)
                        for p in (base/role/'sessions').rglob('*') if p.is_file()}
            self.assertEqual(tree('oracle'),tree('candidate'))
            self.assertEqual(len(tree('candidate')),20)  # resource warmup + three adversarial sessions
            if scenario=='target_passed':
                import gzip
                events=[json.loads(line)['event'] for p in (base/'oracle/sessions').glob('*/events.jsonl.gz')
                        for line in gzip.open(p,'rt',encoding='utf-8')]
                self.assertIn('TARGET_ALREADY_PASSED',events)
            if scenario=='deferred':
                telemetry=[json.loads(x) for x in (base/'candidate/TELEMETRY/R1R11_TRANSPORT.jsonl').read_text().splitlines()]
                results=[r for r in telemetry if r['event']=='SESSION_RESULT']
                self.assertTrue(any(len(set(r['r_g'].values()))>1 for r in results))

    def test_binary_parser_roundtrip(self):
        for volume in ('0','-0.0','0.1','9007199254740993'):
            rec=parse_tick_fields(f'WIN@N;2000.01.03 10:00:00;946904400000;100;105;100;{volume};0.25;2147483647'.split(';'),1)
            raw=encode_record(rec)
            got=list(decode_records(raw,1))
            self.assertEqual(encode_record(got[0][0]),raw)

    def test_spawn_merge_small_natural_path(self):
        cells=valid_cells();states=[[0]*435 for _ in range(6)]
        d1=D1Bar('2000-01-01',10000*PRICE_SCALE,20000*PRICE_SCALE,10000*PRICE_SCALE,15000*PRICE_SCALE)
        session='2000-01-03'; cutoff=5000; integral={c.cell_id for c in cells}
        oracle=SessionEngine(session,d1,cells,cutoff,True,*states,integral)
        line=oracle.lines[2][48].price_micro//PRICE_SCALE
        rows=[(1000,line-5,line,line,1),(2000,line+45,line+50,line+50,1),
              (2000,line+50,line+55,line+55,1),(3000,line+70,line+75,line+75,1),
              (4900,line+65,line+70,0,0),(5000,line+65,line+70,0,0)]
        records=[TickRecord(session,i,session.replace('-','.')+' 10:00:00',t,b*PRICE_SCALE,a*PRICE_SCALE,l*PRICE_SCALE,v,v,0)
                 for i,(t,b,a,l,v) in enumerate(rows,1)]
        with tempfile.TemporaryDirectory() as td:
            with RunLock(td) as lock:
                memory=JobMemory(Path(td)/'telemetry.jsonl'); runtime=Runtime(lock,memory,2,32)
                try:
                    eng=runtime.engine(session,d1,cells,cutoff,True,*states,integral)
                    for rec in records:
                        expected=oracle.process_record(rec)
                        actual=eng.process_record(rec)
                        if rec.time_msc>=cutoff:self.assertEqual(actual,expected)
                    a=oracle.finish(rec.ordinal,rec.date_time);b=eng.finish(rec.ordinal,rec.date_time)
                    from r1r11_v4_custody import checked_rows
                    from r1r11_transport import merged_stream
                    groups=runtime.active.final_groups
                    def stream(kind):
                        manifests={g[kind]['scratch']['path']:g[kind] for g in groups}
                        def reader(path,kind,index,ranks):return checked_rows(manifests[path],kind,index,ranks)
                        return list(merged_stream(list(manifests),kind,cells,read_fn=reader))
                    b.events=stream('events');b.equity_events=stream('equity')
                    b.trades=stream('trades');b.equity_reconciliation=stream('equity_reconciliation')
                    self.assertEqual(dataclasses.asdict(a),dataclasses.asdict(b))
                    runtime.close()  # Direct engine test has no canonical commit.
                finally:runtime.close()


if __name__=='__main__':unittest.main(verbosity=2)
