"""Session coordinator: bounded feed, barriers, deterministic shard merge."""
from __future__ import annotations

import hashlib
import json
import multiprocessing as mp
from multiprocessing import shared_memory
import os
from pathlib import Path
import time
import csv
import threading
import signal

from minotauro_v004_core import ModelError, SessionResult
from r1r11_resources import grant_workers, scheduler_snapshot, safe_remove_scratch
from r1r11_transport import SLOT_BYTES, encode_record, write_slot, merged_stream
from r1r11_worker import worker_main
from r1r11_v4_custody import STREAMS, identity
from r1r11_v4_transaction import prepare_volume
from r1r11_v5_stream import StreamPipeline


class ParallelSession:
    def __init__(self, session, d1, cells, cutoff, record_events, *state_args,
                 runtime, source_tracker=None, calendar_row=None):
        if not record_events or len(state_args) != 7:
            raise ModelError('PARALLEL_SESSION_CONTRACT')
        self.runtime = runtime; self.session = session; self.cutoff = cutoff
        self.cells = cells; self.source_tracker = source_tracker
        if not isinstance(calendar_row, dict):
            raise ModelError('C1_SEALED_CALENDAR_ROW_REQUIRED')
        required_calendar = (
            'session_date','cutoff_msc','first_cutoff_bid_msc','first_cutoff_ask_msc','r3_sidecar_content_sha256',
            'r3_long_x_kind','r3_long_x_ordinal','r3_long_x_time_msc','r3_long_x_price_micro','r3_long_x_last_micro',
            'r3_short_x_kind','r3_short_x_ordinal','r3_short_x_time_msc','r3_short_x_price_micro','r3_short_x_last_micro',
        )
        if any(k not in calendar_row for k in required_calendar):
            raise ModelError('C1_R3_SEALED_CALENDAR_ROW_FIELDS')
        if str(calendar_row['session_date']) != session or int(calendar_row['cutoff_msc']) != int(cutoff):
            raise ModelError('C1_R3_SEALED_CALENDAR_ROW_SESSION_OR_CUTOFF')
        self.calendar_row = dict(calendar_row)
        self.calendar_row['session_date'] = str(calendar_row['session_date'])
        self.calendar_row['cutoff_msc'] = int(calendar_row['cutoff_msc'])
        for k in ('first_cutoff_bid_msc','first_cutoff_ask_msc'):
            self.calendar_row[k] = 0 if calendar_row.get(k) in (None,'','None') else int(calendar_row[k])
        for side in ('long','short'):
            for suffix in ('x_ordinal','x_time_msc','x_price_micro'):
                k=f'r3_{side}_{suffix}'; self.calendar_row[k]=int(calendar_row[k])
            k=f'r3_{side}_x_last_micro'
            self.calendar_row[k]=None if calendar_row.get(k) in (None,'','None') else int(calendar_row[k])
            self.calendar_row[f'r3_{side}_x_kind']=str(calendar_row[f'r3_{side}_x_kind'])
        self.calendar_row['r3_sidecar_content_sha256']=str(calendar_row['r3_sidecar_content_sha256']).upper()
        self.groups = sorted({(c.p_idx,c.t_idx) for c in cells})
        from minotauro_v004_core import valid_cells
        canonical = valid_cells()
        ids = [c.cell_id for c in cells]
        if not cells or len(ids) != len(set(ids)):
            raise ModelError('PARALLEL_CELL_SUBSET_EMPTY_OR_DUPLICATE')
        allowed = set(ids)
        if cells != [c for c in canonical if c.cell_id in allowed]:
            raise ModelError('NONCANONICAL_CELL_SUBSET_OR_ORDER')
        if any(len(x)!=len(cells) for x in state_args[:6]):
            raise ModelError('STATE_SLICE_LENGTH')
        self.scratch = runtime.scratch/session
        self.scratch.mkdir(parents=True,exist_ok=False)
        prepare_volume(getattr(runtime,'transaction_root',runtime.root),self.scratch)
        self.records = []; self.seq = 0; self.generation = 0
        self.digest = hashlib.sha256(); self.n_records = 0; self.business = 0
        self.stopped = False; self.finished = False; self.last = None
        self.children = []; self.conns = []; self.acks = []; self.rg = {}
        self.slot = None
        self.prefix_batch = []
        self.prefix_bytes = 0
        self.trade_safe_key = (0, -1)
        self.pipeline = None
        self.stage_outputs = None
        self.start = time.monotonic(); self.last_report = self.start
        runtime.log('SESSION_PHASE',session=session,phase='SESSION_START')
        # PHASE_B/C process only baseline + frozen selected cell.  Keep the
        # R1R11 minimum of two worker processes while never requesting workers
        # for nonexistent economic groups.
        effective_request = min(runtime.requested, len(self.groups))
        snapshot=scheduler_snapshot(SLOT_BYTES); snapshot["independent_groups"]=len(self.groups)
        snapshot["io_worker_limit"]=min(24,len(self.groups),getattr(runtime.memory,'io_worker_limit',24))
        decision = grant_workers(snapshot, effective_request,
                                 runtime.memory.previous_worker_peak)
        self.granted = decision['granted']
        self.assignments = [self.groups[i::self.granted] for i in range(self.granted)]
        assignment_hash = hashlib.sha256(json.dumps(self.assignments,separators=(',',':')).encode()).hexdigest()
        runtime.log('SCHEDULER',session=session,decision=decision,assignments=self.assignments,
                    assignment_hash=assignment_hash)
        print(f'MULTIWORK=YES AUTOCPU=YES CPU_LOGICAL={decision["cpu_logical"]} '
              f'REQUESTED_WORKERS={runtime.requested} GRANTED_WORKERS={self.granted} '
              f'EXTERNAL_HEAVY_WORKERS={decision["external_heavy_workers"]} '
              f'PROCESS_SCAN_ACTIVE_MATCHING_RUNNERS=0 WORK_GROUPS_TOTAL={len(self.groups)} '
              f'MIN_EFFECTIVE_WORKERS=1 MAX_WORKERS=24 RAM_TARGET_PERCENT=60 '
              f'HARD_CAP_MIB=48528 ASSIGNMENT={assignment_hash} '
              f'GRANT_REASON={decision["reason"]} '
              f'BATCH_ROWS={runtime.batch_rows} SHARED_SLOTS=1 SAFE_STOP=YES RESUME=YES',flush=True)
        try:
            self.slot = shared_memory.SharedMemory(create=True,size=SLOT_BYTES,
                name=f'minotauro_{runtime.instance}_{session.replace("-", "")}')
            context = mp.get_context('spawn')
            for wi, groups in enumerate(self.assignments):
                specs = []
                for group in groups:
                    indices = [i for i,c in enumerate(cells) if (c.p_idx,c.t_idx)==group]
                    specs.append((group,[cells[i] for i in indices],[[s[i] for i in indices] for s in state_args[:6]]))
                parent,child = context.Pipe(duplex=True)
                proc = context.Process(target=worker_main,args=(child,self.slot.name,
                    str(self.scratch/f'worker_{wi}'),session,d1,specs,cutoff,state_args[6],self.calendar_row))
                proc.start(); child.close()
                self.children.append(proc); self.conns.append(parent)
            runtime.memory.set_processes([p.pid for p in self.children], [])
            runtime.memory.shared_bytes = SLOT_BYTES
            ready = self.receive('READY')
            if [r['groups'] for r in ready] != self.assignments:
                raise ModelError('WORKER_ASSIGNMENT_MISMATCH')
            runtime.log('SESSION_PHASE',session=session,phase='WORKERS_READY')
            runtime.memory.boundary('WORKERS_READY',session)
            self.pipeline = StreamPipeline(self)
            runtime.memory.set_processes([p.pid for p in self.children], self.pipeline.pids)
            runtime.log('SESSION_PHASE',session=session,phase='STREAM_PIPELINE_READY')
            runtime.memory.boundary('STREAM_PIPELINE_READY',session)
        except BaseException as exc:
            if isinstance(exc, KeyboardInterrupt):
                runtime.safe_stop_requested=True
            self.close()
            raise

    def receive(self, expected):
        deadline = time.monotonic()+self.runtime.timeout
        pending = set(range(len(self.conns))); rows = [None]*len(self.conns)
        while pending:
            for i in list(pending):
                if self.conns[i].poll(0.01):
                    try:
                        row = self.conns[i].recv()
                    except EOFError as e:
                        raise ModelError('WORKER_PIPE_EOF') from e
                    if row.get('type') != expected or row.get('pid') != self.children[i].pid:
                        raise ModelError('WORKER_REPLY_INVALID '+json.dumps(row))
                    rows[i]=row; pending.remove(i)
                elif not self.children[i].is_alive():
                    raise ModelError(f'WORKER_DEATH pid={self.children[i].pid} exit={self.children[i].exitcode}')
            if time.monotonic()>deadline:
                raise ModelError('WORKER_STRUCTURAL_TIMEOUT')
        return rows

    def process_record(self, rec):
        if self.stopped or rec.session!=self.session:
            raise ModelError('FEED_AFTER_TERMINATION_OR_SESSION_CROSSING')
        if rec.ordinal != self.n_records+len(self.records)+1:
            raise ModelError('COORDINATOR_ORDINAL_SEQUENCE')
        if rec.time_msc >= self.cutoff and self.records:
            self.flush()  # Pre-cutoff records cannot cause terminal False.
        self.records.append(rec); self.last = rec
        if self.source_tracker is not None:
            snap = self.source_tracker.capture(rec.ordinal)
            self.prefix_bytes += len(snap['raw'])
            if self.prefix_bytes > SLOT_BYTES:
                raise ModelError('PHYSICAL_BATCH_EXCEEDS_BOUNDED_FEED')
            self.prefix_batch.append(snap)
        if len(self.records)>=self.runtime.batch_rows or rec.time_msc>=self.cutoff:
            self.flush()
        return not self.stopped

    def flush(self):
        if not self.records:
            return
        self.seq += 1; self.generation += 1
        encoded = write_slot(self.slot.buf,self.session,self.seq,self.generation,self.records)
        for rec,raw in zip(self.records,encoded):
            self.digest.update(raw); self.n_records += 1
            self.business += int(rec.business and rec.time_msc < self.cutoff)
        fault = self.runtime.fault_at('batch',self.seq)
        for wi,conn in enumerate(self.conns):
            seq,gen=self.seq,self.generation
            if wi==0 and fault in ('lost_batch','out_of_order_batch'):
                seq += 1 if fault=='lost_batch' else 2
            if wi==0 and fault=='duplicate_batch':
                seq -= 1
            if wi==0 and fault=='stale_generation':
                gen -= 1
            conn.send({'type':'BATCH','seq':seq,'generation':gen,'fault':fault if wi==0 else None,
                       'trade_safe_key':list(self.trade_safe_key)})
        acks = self.receive('ACK')
        for ack in acks:
            if (ack['seq'],ack['generation'],ack['digest'],ack['n_records'],ack['business_seq']) != (
                    self.seq,self.generation,self.digest.hexdigest(),self.n_records,self.business):
                raise ModelError('ACK_OR_FEED_DIGEST_MISMATCH')
        self.acks.append([(a['pid'],a['started_ns'],a['ended_ns']) for a in acks])
        limits = {}
        for a in acks:
            for group, by_stream in a.get('scratch_offsets',{}).items():
                if group in limits:
                    raise ModelError('V5_DUPLICATE_SCRATCH_GROUP_LIMIT')
                limits[group] = {k:int(v) for k,v in by_stream.items()}
        expected_groups={f'{g[0]}_{g[1]}' for g in self.groups}
        if set(limits)!=expected_groups:
            raise ModelError('V5_SCRATCH_GROUP_LIMIT_SET')
        floors=[tuple(a.get('min_open_trade_key',(self.n_records+1,-1))) for a in acks]
        self.trade_safe_key=min([(self.n_records+1,-1),*floors])
        # Keep telemetry bounded; each batch is persisted by the coordinator.
        self.runtime.log('BATCH_ACK',session=self.session,seq=self.seq,n_records=self.n_records,
                         digest=self.digest.hexdigest(),intervals=self.acks.pop(),
                         trade_safe_key=list(self.trade_safe_key),
                         worker_timing_ns=[{'pid':a['pid'], **a.get('timing_ns',{})} for a in acks])
        self.rg = {group:ordinal for a in acks for group,ordinal in a['r_g'].items()}
        if len(self.rg)==len(self.groups):
            if max(self.rg.values())!=self.n_records:
                raise ModelError('GLOBAL_TERMINATION_OVERRUN')
            self.stopped = True
            if self.source_tracker is not None:
                self.runtime.log('TERMINAL_PREFIX',session=self.session,
                    snapshot=self.source_tracker.verify(self.prefix_batch[-1]))
        self.records.clear()
        self.prefix_batch.clear()
        self.prefix_bytes = 0
        self.runtime.memory.boundary('BATCH_ACK',self.session,records=self.n_records)
        if self.pipeline is None:
            raise ModelError('V5_STREAM_PIPELINE_MISSING')
        io_started=time.monotonic()
        self.pipeline.watermark(self.n_records,limits)
        self.runtime.memory.io_wait_seconds+=time.monotonic()-io_started
        if fault=='after_batch':
            raise ModelError('FAULT_AFTER_BATCH')
        now=time.monotonic()
        if now-self.last_report>=30:
            active_helpers=len(self.pipeline.pids) if self.pipeline is not None else 0
            active_total=len(self.children)+active_helpers
            rate=self.n_records/max(now-self.start,1e-9)
            print(f'MULTIWORK_PROGRESS PHASE=SESSION_PROCESS session={self.session} groups={len(self.rg)}/{len(self.groups)} '
                  f'workers={self.granted} ACTIVE={active_total} READY_WAITING=0 '
                  f'batches={self.seq}/{self.seq} rows={self.n_records} '
                  f'elapsed={now-self.start:.1f}s RATE_ROWS_S={rate:.1f} '
                  f'ETA=SOURCE_PROGRESS FINISH=UNKNOWN CHECKPOINT=PREVIOUS_SESSION SAFE_STOP=YES',flush=True)
            self.runtime.status('SESSION_PROCESS',ACTIVE=active_total,READY_WAITING=0,
                                RATE=round(rate,3),ETA='SOURCE_PROGRESS',FINISH='UNKNOWN',
                                CHECKPOINT='PREVIOUS_SESSION',current_session=self.session,
                                granted_workers=self.granted,batches=self.seq,rows=self.n_records)
            self.last_report=now

    def finish(self, ordinal, date_time):
        self.flush()
        if not self.stopped or ordinal != self.n_records:
            raise ModelError('SESSION_END_WITHOUT_GLOBAL_TERMINATION')
        for conn in self.conns:
            conn.send({'type':'FINISH','ordinal':ordinal,'date_time':date_time})
        replies = self.receive('FINAL_SCRATCH_MANIFEST')
        if any((r['digest'],r['n_records'],r['business_seq']) !=
               (self.digest.hexdigest(),self.n_records,self.business) for r in replies):
            raise ModelError('FINAL_FEED_DIGEST_MISMATCH')
        groups = sorted((g for r in replies for g in r['groups']),key=lambda g:g['group'])
        if [tuple(g['group']) for g in groups]!=self.groups:
            raise ModelError('MISSING_OR_DUPLICATE_GROUP_RESULT')
        results=[g['result'] for g in groups]
        if any(r[k] for r in results for k in ('trades','events','equity_events','equity_reconciliation')):
            raise ModelError('V004_LARGE_RESULT_PAYLOAD_FORBIDDEN')
        diag=results[0]['cutoff_diagnostics']; crossed=results[0]['precutoff_crossed_state_count']
        if any(r['cutoff_diagnostics']!=diag or r['precutoff_crossed_state_count']!=crossed for r in results):
            raise ModelError('GLOBAL_DIAGNOSTICS_DIVERGE')
        self.runtime.log('WORKER_FINISH_TIMING',session=self.session,
                         workers=[{'pid':r['pid'], **r.get('finish_timing_ns',{})} for r in replies])
        self.runtime.log('SESSION_PHASE',session=self.session,phase='WORKERS_SEALED')
        self.runtime.memory.boundary('WORKERS_SEALED_WAIT',self.session)
        fault=self.runtime.fault_at('scratch_sealed')
        if fault:
            from r1r11_v4_custody import inject_file_fault
            inject_file_fault(groups[0]['events']['scratch'],fault)
        # Streaming consumers bind to the sealed prefix. A physical mutation that
        # occurs after the last acknowledged watermark could otherwise sit beyond
        # that prefix (for example an append) and escape the consumed-byte digest.
        # Revalidate the sealed physical identity immediately before finalization.
        # This is metadata-only and avoids a second full scratch scan.
        for group in groups:
            for stream_name in STREAMS:
                sealed=group[stream_name]['scratch']
                if identity(sealed['path']) != sealed['identity']:
                    raise ModelError('V5_SCRATCH_SEAL_CHANGED '+stream_name)
        if self.pipeline is None:
            raise ModelError('V5_STREAM_PIPELINE_MISSING')
        self.stage_outputs=self.pipeline.finalize(groups)
        stage_fault=self.runtime.fault_at('v5_stage_sealed')
        if stage_fault:
            from r1r11_v4_custody import inject_file_fault
            inject_file_fault(self.stage_outputs['events']['file'],stage_fault)
        self.runtime.log('SESSION_PHASE',session=self.session,phase='STREAM_PIPELINE_FINALIZED')
        self.runtime.memory.set_processes([p.pid for p in self.children], [])
        for conn in self.conns:conn.send({'type':'EXIT_ACK'})
        for proc in self.children:
            proc.join(self.runtime.timeout)
            if proc.is_alive() or proc.exitcode!=0:raise ModelError('SCRATCH_WRITER_EXIT_UNCONFIRMED')
        self.runtime.memory.set_processes([], [])
        for conn in self.conns:conn.close()
        self.children=[];self.conns=[]
        self.final_groups=groups
        self.cutoff_fills={}
        for g in groups:
            for direction,fill in g['cutoff_fills'].items():
                if direction in self.cutoff_fills and self.cutoff_fills[direction]!=fill:
                    raise ModelError('CUTOFF_FILL_GROUP_DIVERGENCE')
                self.cutoff_fills[direction]=fill
        self.runtime.inject('before_merge')
        combined={}
        for name in ('cell_ids','end_cash_units','hwm_units','max_dd_units','regime_min_units',
                     'closed_hwm_units','closed_max_dd_units','trade_counts'):
            combined[name]=[v for r in results for v in r[name]]
        if combined['cell_ids']!=[c.cell_id for c in self.cells]:
            raise ModelError('MERGE_CELL_ORDER')
        combined['equity_reconciliation']=[]
        self.runtime.memory.boundary('PRE_COMMIT',self.session)
        self.runtime.log('SESSION_RESULT',session=self.session,r_global=ordinal,
                         r_g={f'{g[0]}_{g[1]}':v for g,v in self.rg.items()},digest=self.digest.hexdigest(),
                         business_seq=self.business,n_records=self.n_records,cutoff_diagnostics=diag)
        self.finished=True
        return SessionResult(session=self.session,trades=[],events=[],
                             equity_events=[],cutoff_diagnostics=diag,
                             precutoff_crossed_state_count=crossed,**combined)

    def committed(self):
        if not self.finished:
            raise ModelError('COMMIT_WITHOUT_RESULT')
        self.runtime.memory.boundary('COMMIT_COMPLETE',self.session)
        elapsed=max(time.monotonic()-self.start,1e-9)
        self.runtime.memory.io_worker_limit=(max(1,self.granted//2) if self.runtime.memory.io_wait_seconds/elapsed>0.50 else 24)
        self.runtime.log('IO_BACKPRESSURE_DECISION',wait_seconds=self.runtime.memory.io_wait_seconds,elapsed_seconds=elapsed,next_worker_limit=self.runtime.memory.io_worker_limit)
        self.runtime.memory.io_wait_seconds=0
        self.runtime.memory.previous_worker_peak=self.runtime.memory.session_worker_peak
        from minotauro_v005r1_r23_contract import write_json_atomic_canonical
        write_json_atomic_canonical(self.runtime.resource_state,{
            'previous_worker_peak':self.runtime.memory.previous_worker_peak})
        self.runtime.memory.session_worker_peak=0
        self.close()
        safe_remove_scratch(self.scratch,self.runtime.scratch)

    def close(self):
        cooperative_only=True
        for conn in self.conns:
            try:conn.send({'type':'STOP'})
            except (OSError,EOFError):pass
        for proc in self.children:
            proc.join(timeout=self.runtime.timeout if cooperative_only else 2)
            if proc.is_alive():
                if cooperative_only:
                    raise ModelError(f'SAFE_STOP_WORKER_COOPERATIVE_TIMEOUT pid={proc.pid}')
                proc.terminate();proc.join(timeout=5)
            if proc.is_alive():raise ModelError('WORKER_WONT_TERMINATE')
        for conn in self.conns:
            try: conn.close()
            except OSError: pass
        if self.pipeline is not None:
            self.pipeline.close(cooperative_only=cooperative_only); self.pipeline=None
        self.runtime.memory.set_processes([], []);self.runtime.memory.shared_bytes=0
        if self.slot is not None:
            self.slot.close();self.slot.unlink();self.slot=None


class Runtime:
    def __init__(self, lock, memory, requested=15, batch_rows=256, timeout=120, fault=None, mode='UNKNOWN', transaction_root=None):
        from r1r11_resources import coordinator_sigint
        coordinator_sigint()
        if batch_rows not in (32,64,128,256):
            raise ModelError('PERF_NEXT_BATCH_ROWS_UNQUALIFIED')
        self.root=lock.root
        self.transaction_root=Path(transaction_root).resolve() if transaction_root is not None else self.root
        self.instance=lock.instance;self.scratch=lock.root/'_scratch'/lock.instance
        self.memory=memory;self.requested=requested;self.batch_rows=batch_rows;self.timeout=timeout
        self.resource_state=lock.root/'TELEMETRY'/'R1R11_SCHEDULER_STATE.json'
        if self.resource_state.exists():
            peak=json.loads(self.resource_state.read_text())['previous_worker_peak']
            if not isinstance(peak,int) or isinstance(peak,bool) or peak<=0:
                raise ModelError('INVALID_SCHEDULER_PEAK_STATE')
            self.memory.previous_worker_peak=peak
        self.fault=fault;self.active=None
        self.safe_stop_requested=False
        self._stop_count=0; self._status_lock=threading.RLock(); self._heartbeat_done=threading.Event()
        self._heartbeat_error=None; self._progress_start=time.monotonic(); self._initial_committed=0
        self._previous_sigint=signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT,self.request_stop)
        self._calendar_cache=None
        self.synthetic_calendar_rows={}
        self.telemetry=lock.root/'TELEMETRY'/'R1R11_TRANSPORT.jsonl'
        self.telemetry.parent.mkdir(parents=True,exist_ok=True)
        from r1r11_runtime_status import new_status, write_status_atomic
        self.status_path=lock.root/'TELEMETRY'/'R1R11_STATUS.json'
        self._write_status_atomic=write_status_atomic
        self.status_state=new_status(run_instance=self.instance,out_root=lock.root,mode=mode)
        self.status_state=self._write_status_atomic(self.status_path,self.status_state)
        self._heartbeat=threading.Thread(target=self._heartbeat_loop,name='PEGASUS_HEARTBEAT',daemon=True)
        self._heartbeat.start()

    def request_stop(self, *ignored):
        self._stop_count+=1; self.safe_stop_requested=True
        print('SAFE_STOP_REQUESTED=YES ADMISSION=CLOSED BOUNDARY=SESSION_COMMIT SECOND_CTRL_C=WAIT_NO_KILL',flush=True)

    def _heartbeat_loop(self):
        while not self._heartbeat_done.wait(10):
            try: self.status(None)
            except Exception as exc:
                self._heartbeat_error=repr(exc); self.safe_stop_requested=True
                return

    def check_admission(self):
        if self._heartbeat_error: raise ModelError('HEARTBEAT_FAILED '+self._heartbeat_error)
        if self.safe_stop_requested: raise KeyboardInterrupt

    def configure_status(self, *, total: int, committed: int):
        self._progress_start=time.monotonic(); self._initial_committed=int(committed)
        self.status_state=self._write_status_atomic(
            self.status_path,self.status_state,
            PHASE='RUN_START',TOTAL=int(total),COMMITTED=int(committed),
            CHECKPOINT='PREVIOUS_SESSION' if int(committed)>0 else 'NONE',
            ACTIVE=0,READY_WAITING=0,RATE='UNKNOWN',ETA='UNKNOWN',
            FINISH='UNKNOWN',SAFE_STOP='NO',PROCESS_TREE_CLEAN='NO')
        return dict(self.status_state)

    def status(self, phase=None, **data):
        from datetime import datetime, timezone, timedelta
        with self._status_lock:
            if phase is not None: data['PHASE']=str(phase)
            committed=int(data.get('COMMITTED',self.status_state['COMMITTED']))
            total=int(data.get('TOTAL',self.status_state['TOTAL']))
            elapsed=max(time.monotonic()-self._progress_start,1e-9)
            delta=committed-self._initial_committed
            rate=delta/elapsed if delta>0 else 0
            seconds=(total-committed)/rate if rate else None
            data.update(RATE=rate if rate else 'UNKNOWN',RATE_UNIT='SESSIONS_PER_SECOND',
                ETA=seconds if seconds is not None else 'UNKNOWN',
                ETA_REASON='COMMITTED_SESSION_MEAN' if rate else 'NO_NEW_SESSION_COMMITTED_THIS_ATTEMPT',
                FINISH=(datetime.now(timezone.utc)+timedelta(seconds=seconds)).isoformat() if seconds is not None else 'UNKNOWN',
                STOP_REQUESTED=self.safe_stop_requested,JOB_PEAK_BYTES=self.memory.job_peak,
                RAM_BUDGET_MIB=self.memory.cap_mib,HEARTBEAT_SECONDS=10,
                JOB_MEM_BYTES=self.memory.current_bytes,RAM_SAMPLE_AGE_S=max(0,time.monotonic()-self.memory.sample_at),
                IO_WAIT_SECONDS=self.memory.io_wait_seconds,IO_COUNTERS=self.memory.io_counters)
            self.status_state=self._write_status_atomic(self.status_path,self.status_state,**data)
            pct=self.status_state['PCT'];bar='#'*int(pct//5)+'.'*(20-int(pct//5))
            print(f'PEGASUS [{bar}] {pct:.2f}% COMMITTED={committed}/{total} ETA_SECONDS={data["ETA"]} ACTIVE={self.status_state["ACTIVE"]} SAFE_STOP_REQUESTED={self.safe_stop_requested}',flush=True)
            return dict(self.status_state)

    def log(self,event,**data):
        row={'event':event,'run_instance':self.instance,'monotonic_ns':time.perf_counter_ns(),
             'wall_time_ns':time.time_ns(),**data}
        from r1r11_bounded_telemetry import append_json
        append_json(self.telemetry,row)

    def fault_at(self, point, seq=None):
        if self.fault and self.fault['point']==point and (seq is None or seq==self.fault.get('seq',1)):
            return self.fault['kind']
        return None

    def inject(self,point):
        if self.fault_at(point):raise ModelError('FAULT_'+point.upper())

    def seal_precommit(self,out,session,pending,verified_files=None):
        from minotauro_v005r1_r23_contract import sha256_file,write_json_atomic_canonical
        out=Path(out);pending=Path(pending)
        names=('trades.jsonl.gz','events.jsonl.gz','equity.jsonl.gz','equity_reconciliation.jsonl.gz','session_receipt.json')
        key=hashlib.sha256(str(out.resolve()).encode()).hexdigest()
        seal=self.telemetry.parent/'SESSION_SEALS'/key/(session+'.json')
        if verified_files is None:
            hashes={n:sha256_file(pending/n) for n in names}
        else:
            if set(verified_files)!=set(names):raise ModelError('SESSION_SEAL_FILES_MISMATCH')
            hashes={}
            for n in names:
                value=verified_files[n].get('sha256')
                if (not isinstance(value,str) or len(value)!=64 or
                        any(c not in '0123456789abcdefABCDEF' for c in value)):
                    raise ModelError('SESSION_SEAL_SHA256_INVALID '+n)
                hashes[n]=value.upper()
        write_json_atomic_canonical(seal,{'session':session,'out':str(out.resolve()),'files':hashes})

    def verify_committed(self,out,checkpoint):
        from minotauro_v005r1_r23_contract import sha256_file
        out=Path(out);key=hashlib.sha256(str(out.resolve()).encode()).hexdigest()
        for session in checkpoint['completed']:
            path=self.telemetry.parent/'SESSION_SEALS'/key/(session+'.json')
            if not path.is_file():raise ModelError('R1R11_COMMITTED_SESSION_SEAL_MISSING')
            seal=json.loads(path.read_text())
            if seal['out']!=str(out.resolve()) or seal['session']!=session or len(seal['files'])!=5:
                raise ModelError('SESSION_SEAL_IDENTITY')
            for name,expected in seal['files'].items():
                if name not in ('trades.jsonl.gz','events.jsonl.gz','equity.jsonl.gz','equity_reconciliation.jsonl.gz','session_receipt.json'):
                    raise ModelError('SESSION_SEAL_UNEXPECTED_FILE')
                if sha256_file(out/'sessions'/session/name)!=expected:raise ModelError('COMMITTED_SESSION_HASH_DRIFT')

    def set_synthetic_calendar_row(self, session, row):
        self.synthetic_calendar_rows[str(session)] = dict(row)

    def _load_sealed_calendar(self):
        if self._calendar_cache is not None:
            return self._calendar_cache
        binding_path=self.root/'PHASE_A'/'RUN_SOURCE_BINDING_A.json'
        calendar_path=self.root/'PHASE_A'/'SESSION_CALENDAR_PHASE_A.csv'
        if not binding_path.is_file() or not calendar_path.is_file():
            raise ModelError('C1_SEALED_CALENDAR_ARTIFACTS_REQUIRED')
        from minotauro_v005r1_r23_contract import canonical_json_hash, sha256_file
        binding=json.loads(binding_path.read_text(encoding='utf-8'))
        if binding.get('status') not in ('PASS_SEALED_PREPILOT','PASS_SEALED_CORRECTNESS'):
            raise ModelError('C1_BINDING_NOT_SEALED')
        if binding.get('binding_content_sha256') != canonical_json_hash(binding, exclude_keys={'binding_content_sha256'}):
            raise ModelError('C1_BINDING_SELF_HASH_MISMATCH')
        if sha256_file(calendar_path) != binding.get('session_calendar_sha256'):
            raise ModelError('C1_CALENDAR_SHA_MISMATCH')
        rows={}
        with calendar_path.open('r',encoding='utf-8-sig',newline='') as f:
            for row in csv.DictReader(f,delimiter=';'):
                sess=str(row.get('session_date',''))
                if not sess or sess in rows:raise ModelError('C1_CALENDAR_SESSION_DUPLICATE_OR_EMPTY')
                rows[sess]=row
        if len(rows)!=250:raise ModelError('C1_CALENDAR_CARDINALITY')
        self._calendar_cache=rows
        return rows

    def _calendar_row(self, session):
        if str(session) in self.synthetic_calendar_rows:
            return dict(self.synthetic_calendar_rows[str(session)])
        rows=self._load_sealed_calendar()
        if str(session) not in rows:raise ModelError('C1_CALENDAR_SESSION_MISSING '+str(session))
        return dict(rows[str(session)])

    def engine(self,*args,source_tracker=None):
        self.check_admission()
        if self.active is not None:raise ModelError('PREVIOUS_SESSION_NOT_COMMITTED')
        if not args:raise ModelError('PARALLEL_SESSION_ARGS_MISSING')
        row=self._calendar_row(args[0])
        self.active=ParallelSession(*args,runtime=self,source_tracker=source_tracker,calendar_row=row)
        self.status('SESSION_START',ACTIVE=len(self.active.children)+(len(self.active.pipeline.pids) if self.active.pipeline else 0),
                    READY_WAITING=0,RATE='UNKNOWN',ETA='UNKNOWN',FINISH='UNKNOWN',
                    CHECKPOINT='PREVIOUS_SESSION')
        return self.active

    def committed(self, committed_count=None):
        session=self.active.session
        self.active.committed();self.active=None
        updates={'ACTIVE':0,'READY_WAITING':0,'RATE':'UNKNOWN','ETA':'UNKNOWN',
                 'FINISH':'UNKNOWN','CHECKPOINT':session}
        if committed_count is not None:
            updates['COMMITTED']=int(committed_count)
        self.status('SESSION_COMMITTED',**updates)
        self.check_admission()

    def close(self):
        self._heartbeat_done.set(); self._heartbeat.join(15)
        if self._heartbeat.is_alive(): raise ModelError('HEARTBEAT_JOIN_TIMEOUT')
        if self.active is not None:self.active.close();self.active=None
        proof=self.memory.assert_owned_tree_clean()
        signal.signal(signal.SIGINT,self._previous_sigint)
        self.log('PROCESS_TREE_CLEAN',**proof)
        self.status(None,ACTIVE=0,READY_WAITING=0,PROCESS_TREE_CLEAN='YES',
                    SAFE_STOP='YES' if self.safe_stop_requested else self.status_state.get('SAFE_STOP','NO'))
        if self.scratch.exists() and not any(self.scratch.iterdir()):
            self.scratch.rmdir()
