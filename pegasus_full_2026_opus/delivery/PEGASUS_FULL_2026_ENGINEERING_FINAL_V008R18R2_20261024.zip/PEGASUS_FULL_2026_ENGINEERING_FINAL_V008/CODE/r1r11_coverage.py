"""Construct coverage ONLY by reading persisted frozen-oracle outputs."""
from collections import defaultdict
import gzip
import hashlib
import json
from pathlib import Path

from minotauro_v004_core import valid_cells, BASELINE_CELL_ID, rr_pass, rmax_pass, TICK_MICRO
from minotauro_v004_io import iter_tick_file
from r1r11_contract import validate_bindings, CERT_SHA256, validate_coverage
from r1r11_transport import EVENT_STAGE, EQUITY_STAGE


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()


def rows(path):
    with gzip.open(path,'rt',encoding='utf-8') as f:
        for line in f:yield json.loads(line)


def construct(inputs, oracle, candidate, baseline_oracle, baseline_candidate, evidence_root):
    inputs,oracle,candidate=map(Path,(inputs,oracle,candidate));evidence_root=Path(evidence_root)
    manifest={'bindings':validate_bindings(),'events':[], 'equity':{},'obligations':{},
              'scope':'CAUSAL_SYNTHETIC_ORACLE_OUTPUTS','real_data_processed':False}
    events={k:[] for k in EVENT_STAGE};equity={k:[] for k in set(EQUITY_STAGE)|{'OPEN_MARK'}};ob=manifest['obligations']
    specs=json.loads((inputs/'FIXTURES.json').read_text());by_session={c['session']:c for c in specs['cases']}
    telemetry=[json.loads(x) for x in (candidate/'TELEMETRY/R1R11_TRANSPORT.jsonl').read_text().splitlines()]
    assignments={r['session']:r['assignments'] for r in telemetry if r['event']=='SCHEDULER'}
    index={c.cell_id:c for c in valid_cells()}
    def worker(session,cid):
        c=index[cid];return next(i for i,groups in enumerate(assignments[session]) if [c.p_idx,c.t_idx] in groups)
    matches=0;case_count=0
    for session_dir in sorted((oracle/'sessions').iterdir()):
        session=session_dir.name;case_count+=1
        for p in session_dir.iterdir():
            counterpart=candidate/'sessions'/session/p.name
            if not counterpart.is_file() or p.read_bytes()!=counterpart.read_bytes():
                raise AssertionError('ORACLE_BYTE_DIFFERENCE '+str(p))
            matches+=1
        ep=session_dir/'events.jsonl.gz';eqp=session_dir/'equity.jsonl.gz';tp=session_dir/'trades.jsonl.gz'
        file_hashes={p:digest(p) for p in (ep,eqp,tp)}
        by_ordinal=defaultdict(lambda:defaultdict(set))
        for i,row in enumerate(rows(ep)):
            name=row['event']
            ref={'fixture':session,'ordinal':row['ordinal'],'row_index':i,'cell_ids':row['cell_ids'],
                 'oracle_file':ep.relative_to(evidence_root).as_posix(),'oracle_file_sha256':file_hashes[ep],'event':name}
            if not events[name]:events[name].append(ref)
            stage={10:'S1a',11:'S1b',20:'S2a',40:'S4',50:'S5a',51:'S5b'}[EVENT_STAGE[name]]
            ob.setdefault(stage,ref)
            owners={worker(session,cid) for cid in row['cell_ids']}
            by_ordinal[row['ordinal']][stage].update(owners)
            if name=='CUTOFF_PENDING_CANCELLED' and len(owners)>=2:ob.setdefault('cancel_multiworker',ref)
            if name=='CUTOFF_FILL_DEFERRED' and len(owners)>=2:ob.setdefault('deferred_multiworker',ref)
            if name=='PENDING_REJECT' and row.get('reason')=='STALE_CAUSAL_BBO':ob.setdefault('stale_BBO',ref)
            if name=='PENDING_REJECT' and row.get('reason')=='NO_VALID_CAUSAL_BBO':ob.setdefault('crossed_BBO',ref)
        for ordinal,stages in by_ordinal.items():
            if len(stages['S5a'])>=2 and len(stages['S5b'])>=2:
                ob.setdefault('S5a_S5b_multiworker',{'fixture':session,'ordinal':ordinal})
        for i,row in enumerate(rows(eqp)):
            ref={'fixture':session,'ordinal':row['ordinal'],'row_index':i,'oracle_file':eqp.relative_to(evidence_root).as_posix(),
                 'oracle_file_sha256':file_hashes[eqp],'cell_id':row['cell_id'],'event':row['event']}
            if not equity[row['event']]:equity[row['event']].append(ref)
            if row['event']=='OPEN_MARK' and 'cutoff_pending' in row:ob.setdefault('S2b',ref)
            if row['event']=='PREEXISTING_EXIT_POST_REALIZATION' or (row['event']=='OPEN_MARK' and 'cutoff_pending' not in row):ob.setdefault('S3',ref)
        for i,row in enumerate(rows(tp)):
            ref={'fixture':session,'row_index':i,'oracle_file':tp.relative_to(evidence_root).as_posix(),'oracle_file_sha256':file_hashes[tp]}
            ob.setdefault(row['direction'],ref);ob.setdefault(row['exit_reason'],ref)
            if row['n_msc']==row['n1_msc']:ob.setdefault('N_N1_same_ms',ref)
        if session in by_session:
            observed=next(r for r in telemetry if r['event']=='SESSION_RESULT' and r['session']==session)
            values=list(observed['r_g'].values())
            if min(values)<max(values):
                for rec in iter_tick_file(inputs/by_session[session]['path']):
                    if min(values)<rec.ordinal<=max(values) and (rec.ask_micro>0 or rec.bid_micro>0):
                        ob.setdefault('different_rg_with_quote_update',{'fixture':session,'r_g':observed['r_g'],'quote_ordinal':rec.ordinal})
    # Integral settings are verified from actual oracle reconciliation counters,
    # with economic outputs independently compared in both persistence modes.
    all_equal=True;baseline_equal=True;nonbaseline_thinned=False;baseline_seen=False
    for session_dir in (oracle/'sessions').iterdir():
        for row in rows(session_dir/'equity_reconciliation.jsonl.gz'):
            all_equal &= row['open_marks_evaluated']==row['open_marks_persisted']
    for sd in (Path(baseline_oracle)/'sessions').iterdir():
        for p in sd.iterdir():
            if p.read_bytes()!=(Path(baseline_candidate)/'sessions'/sd.name/p.name).read_bytes():
                raise AssertionError('BASELINE_BYTE_DIFFERENCE')
        for row in rows(sd/'equity_reconciliation.jsonl.gz'):
            if row['cell_id']==BASELINE_CELL_ID:
                baseline_equal &= row['open_marks_evaluated']==row['open_marks_persisted'];baseline_seen |= row['open_marks_evaluated']>0
            else:nonbaseline_thinned |= row['open_marks_evaluated']>row['open_marks_persisted']
    if all_equal:ob['integral_435']={'reconciliation':'all oracle sessions: evaluated=persisted for 435 cells'}
    if baseline_equal and baseline_seen and nonbaseline_thinned:ob['integral_baseline']={'baseline_integral':True,'nonbaseline_lossless_thinning_observed':True}
    if case_count>=2:ob['sequential_sessions']={'sessions':case_count,'checkpoint_chain':True}
    if matches==case_count*5:ob['five_files_byte_equal']={'files':matches}
    # Exact boundaries are tested against frozen predicates, not inferred from an event count.
    assert rr_pass(5*TICK_MICRO,TICK_MICRO,5) and not rr_pass(5*TICK_MICRO-2,TICK_MICRO,5)
    assert rmax_pass(14*TICK_MICRO,14) and not rmax_pass(14*TICK_MICRO+2,14)
    ob['RR_RMAX_boundaries']={'frozen_integer_predicates':'equality and next-outside checked'}
    for event in EVENT_STAGE:
        manifest['events'].append({'event':event,'classification':'STRUCTURALLY_UNREACHABLE' if event=='AMBIGUOUS_MULTI_SIGNAL' else 'COVERED',
            'occurrences':events[event],**({'certificate_sha256':CERT_SHA256} if event=='AMBIGUOUS_MULTI_SIGNAL' else {})})
    manifest['equity']=equity
    # Missing causal occurrences remain empty and cause FAIL. No synthetic PASS.
    return manifest


def verify_manifest_evidence(manifest, evidence_root):
    root=Path(evidence_root).resolve()
    validate_coverage(manifest)
    references=[ref for row in manifest['events'] for ref in row['occurrences']]
    references.extend(ref for refs in manifest['equity'].values() for ref in refs)
    for ref in references:
        p=(root/ref['oracle_file']).resolve()
        if not p.is_relative_to(root) or digest(p)!=ref['oracle_file_sha256']:
            raise AssertionError('G6_EVIDENCE_FILE_BINDING')
        found=next((r for i,r in enumerate(rows(p)) if i==ref['row_index']),None)
        if found is None or found['ordinal']!=ref['ordinal']:
            raise AssertionError('G6_EVIDENCE_ROW_BINDING')
        if found['event']!=ref['event']:raise AssertionError('G6_EVIDENCE_EVENT_BINDING')
        if 'cell_ids' in ref and found['cell_ids']!=ref['cell_ids']:raise AssertionError('G6_EVIDENCE_CELL_BINDING')
    return True
