#requires -Version 5.1
[CmdletBinding()] param(
 [Parameter(Mandatory=$true)][string]$Config,
 [Parameter(Mandatory=$true)][string]$AuditReport,
 [Parameter(Mandatory=$true)][string]$AuditPack
)
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'POWERSHELL_5_1_REQUIRED' }
. (Join-Path $PSScriptRoot 'Minotauro_Launcher_Common.ps1'); $Python=Resolve-RealPython
Write-Host 'AMBIENTE=PowerShell R1R11_V005R1_BIND_FINAL_AUDIT PACK_HASH_BINDING=REQUIRED'
& $Python -X utf8 -B (Join-Path $PSScriptRoot 'r1r11_bind_final_audit.py') `
  --config ([IO.Path]::GetFullPath($Config)) `
  --audit-report ([IO.Path]::GetFullPath($AuditReport)) `
  --audit-pack ([IO.Path]::GetFullPath($AuditPack))
exit $LASTEXITCODE
