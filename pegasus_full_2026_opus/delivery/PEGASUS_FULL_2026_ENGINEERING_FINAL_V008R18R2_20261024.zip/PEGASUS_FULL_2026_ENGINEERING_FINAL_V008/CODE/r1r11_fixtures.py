"""Deterministic synthetic-only owner fixtures. Reuses frozen geometry, never data."""
from __future__ import annotations

import argparse
from datetime import date, timedelta, datetime
import hashlib
import json
import os
from pathlib import Path
import sys
import time


def generate(root, heavy_cycles=1200):
    from minotauro_v004_core import D1Bar, SessionEngine, valid_cells, PRICE_SCALE, micro_to_price_text
    from minotauro_v004_io import cutoff_msc_for_session, BRT
    root=Path(root);root.mkdir(parents=True,exist_ok=False)
    (root/'SYNTHETIC_ONLY.json').write_text(json.dumps({'schema':'R1R11_SYNTHETIC_V003','heavy_cycles':heavy_cycles}))
    d1=D1Bar('2000-01-01',10000*PRICE_SCALE,20000*PRICE_SCALE,10000*PRICE_SCALE,15000*PRICE_SCALE)
    cases=[]
    scenarios=['pending_cancel','deferred','pending_mark','buy_target','buy_stop','sell_target','sell_stop',
               'immediate_stop','stale','crossed','busy','rr_boundary','target_passed']
    for pi in range(3):
        for scenario in scenarios:
            session=(date(2000,1,3)+timedelta(days=len(cases))).isoformat()
            eng=SessionEngine(session,d1,valid_cells(),cutoff_msc_for_session(session))
            line=eng.lines[pi][48].price_micro
            upper=eng.lines[pi][49].price_micro;lower=eng.lines[pi][47].price_micro
            tick=5*PRICE_SCALE;cutoff=cutoff_msc_for_session(session)
            rows=[];clock=cutoff-60000
            def add(b,a,last,v=1,at=None):
                nonlocal clock
                if at is None:clock+=100
                else:clock=at
                rows.append((clock,b,a,last,v))
            direction=-1 if scenario.startswith('sell') else 1
            risk=70*PRICE_SCALE if scenario!='rr_boundary' else (upper-line)//4
            add(line-tick,line,line)
            last=line+direction*risk
            if scenario=='target_passed':last=upper+tick
            add(last-tick,last,last)
            if scenario=='pending_cancel':
                add(last-tick,last,0,0,cutoff)
            else:
                if scenario=='immediate_stop':add(line-tick,last+tick,last+tick,at=clock)
                elif scenario=='stale':add(0,0,last+tick,at=clock+501)
                elif scenario=='crossed':add(last+2*tick,last+tick,last+tick,at=clock)
                else:add(last-tick if direction<0 else last,last if direction<0 else last+tick,
                         last-tick if direction<0 else last+tick,at=clock)
                if scenario=='buy_target':add(upper,upper+tick,0,0)
                elif scenario=='buy_stop':add(line-tick,line,0,0)
                elif scenario=='sell_target':add(lower-tick,lower,0,0)
                elif scenario=='sell_stop':add(line,line+tick,0,0)
                elif scenario=='busy':
                    add(last,last+tick,line);add(last,last+tick,last)
                if scenario=='deferred':
                    add(last+3*tick,0,0,0,cutoff)
                    add(0,last+4*tick,0,0,cutoff+100)
                elif scenario=='pending_mark':
                    add(0,0,0,0,cutoff)
                    add(last,last+tick,0,0,cutoff+100)
                else:add(last-tick,last,0,0,cutoff)
            # A post-terminal tail exercises exact prefix versus monthly EOF.
            add(last,last+tick,0,0,cutoff+500)
            path=root/f'{session}.csv'
            with path.open('w',encoding='utf-8',newline='\n') as f:
                for m,b,a,l,v in rows:
                    dt=datetime.fromtimestamp(m/1000,BRT).strftime('%Y.%m.%d %H:%M:%S')
                    f.write(';'.join(['WIN@N',dt,str(m),micro_to_price_text(b),micro_to_price_text(a),
                                      micro_to_price_text(l),str(v),str(v),'0'])+'\n')
            cases.append({'session':session,'scenario':scenario,'projection':pi,'path':path.name,'cutoff':cutoff})
    # Preregistered heavy workload: repeated causal buy/target cycles, all 435
    # integral marks. No artificial sleep or benchmark-only work in either engine.
    session='2000-03-01'; cutoff=cutoff_msc_for_session(session)
    eng=SessionEngine(session,d1,valid_cells(),cutoff);line=eng.lines[2][48].price_micro
    upper=eng.lines[2][49].price_micro;tick=5*PRICE_SCALE
    with (root/'heavy.csv').open('w',encoding='utf-8',newline='\n') as f:
        m=cutoff-60*60*1000
        for _ in range(heavy_cycles):
            for b,a,l in [(line-tick,line,line),(line+13*tick,line+14*tick,line+14*tick),
                          (line+14*tick,line+15*tick,line+15*tick),(upper,upper+tick,0)]:
                m+=1;dt=datetime.fromtimestamp(m/1000,BRT).strftime('%Y.%m.%d %H:%M:%S')
                f.write(';'.join(['WIN@N',dt,str(m),micro_to_price_text(b),micro_to_price_text(a),micro_to_price_text(l),'1','1','0'])+'\n')
        dt=datetime.fromtimestamp(cutoff/1000,BRT).strftime('%Y.%m.%d %H:%M:%S')
        f.write(f'WIN@N;{dt};{cutoff};{micro_to_price_text(line)};{micro_to_price_text(line+tick)};0;0;0;0\n')
    obj={'cases':cases,'heavy':{'session':session,'scenario':'heavy','path':'heavy.csv','cutoff':cutoff},
         'd1':d1.__dict__,'heavy_cycles':heavy_cycles}
    warm_session='1999-12-31';warm_cutoff=cutoff_msc_for_session(warm_session)
    warm={'session':warm_session,'scenario':'warmup','path':'warmup.csv','cutoff':warm_cutoff}
    dt=datetime.fromtimestamp(warm_cutoff/1000,BRT).strftime('%Y.%m.%d %H:%M:%S')
    (root/'warmup.csv').write_text(f'WIN@N;{dt};{warm_cutoff};15000;15005;0;0;0;0\n',encoding='utf-8',newline='\n')
    obj['warmup']=warm
    for item in [warm,*cases,obj['heavy']]:
        item['sha256']=hashlib.sha256((root/item['path']).read_bytes()).hexdigest()
    (root/'FIXTURES.json').write_text(json.dumps(obj,indent=2),encoding='utf-8')
    return obj


def _fixture_preflight_calendar(path, session, cutoff, parse_tick_fields):
    from minotauro_v004_io import _split_semicolon_bytes
    st={'bid':0,'ask':0,'bid_msc':0,'ask_msc':0,'first_cutoff_bid_msc':None,'first_cutoff_ask_msc':None,
        'cutoff_long_fill_msc':None,'cutoff_short_fill_msc':None}
    ordinal=0
    with Path(path).open('rb') as f:
        for raw in f:
            if not raw.strip():continue
            fields=_split_semicolon_bytes(raw);ordinal+=1
            rec=parse_tick_fields(fields,ordinal)
            if rec.session != session:continue
            if rec.bid_micro>0:
                st['bid']=rec.bid_micro;st['bid_msc']=rec.time_msc
                if rec.time_msc>=cutoff and st['first_cutoff_bid_msc'] is None:st['first_cutoff_bid_msc']=rec.time_msc
            if rec.ask_micro>0:
                st['ask']=rec.ask_micro;st['ask_msc']=rec.time_msc
                if rec.time_msc>=cutoff and st['first_cutoff_ask_msc'] is None:st['first_cutoff_ask_msc']=rec.time_msc
            if rec.time_msc<cutoff:continue
            if st['bid']>0 and st['ask']>0 and st['ask']<st['bid']:continue
            if st['cutoff_long_fill_msc'] is None and st['bid']>0 and st['bid_msc']>=cutoff and st['bid_msc']<=rec.time_msc:
                st['cutoff_long_fill_msc']=rec.time_msc
            if st['cutoff_short_fill_msc'] is None and st['ask']>0 and st['ask_msc']>=cutoff and st['ask_msc']<=rec.time_msc:
                st['cutoff_short_fill_msc']=rec.time_msc
    if any(st[k] is None for k in ('first_cutoff_bid_msc','first_cutoff_ask_msc','cutoff_long_fill_msc','cutoff_short_fill_msc')):
        raise RuntimeError('SYNTHETIC_PREFLIGHT_CUTOFF_UNRESOLVED '+session)
    return {'session_date':session,'cutoff_msc':int(cutoff),
            'first_cutoff_bid_msc':int(st['first_cutoff_bid_msc']),'first_cutoff_ask_msc':int(st['first_cutoff_ask_msc']),
            'cutoff_long_fill_msc':int(st['cutoff_long_fill_msc']),'cutoff_short_fill_msc':int(st['cutoff_short_fill_msc']),
            'cutoff_long_latency_ms':int(st['cutoff_long_fill_msc']-cutoff),'cutoff_short_latency_ms':int(st['cutoff_short_fill_msc']-cutoff)}

def run_chain(inputs, output, role, workers=2, integral='all', only=None, fault=None):
    inputs=Path(inputs).resolve();output=Path(output).resolve()
    if not (inputs/'SYNTHETIC_ONLY.json').is_file():raise RuntimeError('SYNTHETIC_MARKER_REQUIRED')
    spec=json.loads((inputs/'FIXTURES.json').read_text());cases=spec['cases']
    if only=='heavy':cases=[spec['heavy']]
    elif only:cases=[c for c in cases if c['scenario']==only]
    cases=[spec['warmup'],*cases]
    for case in cases:
        p=(inputs/case['path']).resolve()
        if not p.is_relative_to(inputs) or hashlib.sha256(p.read_bytes()).hexdigest()!=case['sha256']:
            raise RuntimeError('SYNTHETIC_INPUT_BINDING_MISMATCH')
    if role=='oracle':
        sys.path.insert(0,str(Path(__file__).resolve().parent/'oracle'))
    from minotauro_v004_core import D1Bar, SessionEngine, valid_cells, BASELINE_CELL_ID
    from minotauro_v004_io import iter_tick_file
    import minotauro_v004_io as source_io
    import minotauro_v004_runner as runner
    from minotauro_v005r1_r23_contract import write_json_atomic_canonical
    import contextlib
    cells=valid_cells();integral_ids={c.cell_id for c in cells} if integral=='all' else {BASELINE_CELL_ID}
    identity={k:hashlib.sha256(k.encode()).hexdigest().upper() for k in (
        'spec_sha256','runner_sha256','grid_sha256','preflight_status_sha256','session_calendar_sha256',
        'expected_sessions_sha256','source_inventory_sha256','run_source_binding_sha256','config_sha256','parser_version')}
    identity['parser_version']='SYNTHETIC_R1R11_OWNER_GATES'
    cp_path=output/'CHECKPOINT.json';output.mkdir(parents=True,exist_ok=True)
    d1=D1Bar(**spec['d1']); runtime=None
    parse_count=0
    original_parse=source_io.parse_tick_fields
    def counted_parse(*args,**kwargs):
        nonlocal parse_count
        parse_count+=1;return original_parse(*args,**kwargs)
    source_io.parse_tick_fields=counted_parse
    audit_writes=[]
    def audit(event,args):
        if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
            p=Path(os.fsdecode(args[0])).resolve()
            if str(p).lower().startswith('d:\\base csv'):raise RuntimeError('REAL_DATA_FORBIDDEN_IN_GATES')
            mode=args[1] or '';flags=args[2]
            if p.is_relative_to(output/'sessions') and (any(x in mode for x in 'wax+') or flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)):
                audit_writes.append({'pid':os.getpid(),'path':str(p)})
    sys.addaudithook(audit)
    started=time.perf_counter(); source_records=0;case_timings={}
    with contextlib.ExitStack() as stack:
        if role=='candidate':
            from r1r11_resources import RunLock, JobMemory
            from r1r11_coordinator import Runtime
            from r1r11_prefix import PhysicalPrefixTap
            lock=stack.enter_context(RunLock(output))
            runtime=Runtime(lock,JobMemory(output/'TELEMETRY'/'memory.jsonl'),workers,32)
            original_boundary=runtime.memory.boundary
            def boundary_with_owner_fault(event,*args,**kwargs):
                if runtime.fault and runtime.fault.get('kind')=='memory_cap' and runtime.fault['point']==event:
                    import r1r11_resources as resources
                    from unittest.mock import patch
                    original_probe=resources.process_memory
                    def high_sample(pid):
                        sample=original_probe(pid);sample['peak']=48528*1024**2+1;return sample
                    with patch.object(resources,'process_memory',high_sample):
                        return original_boundary(event,*args,**kwargs)
                return original_boundary(event,*args,**kwargs)
            runtime.memory.boundary=boundary_with_owner_fault
            stack.callback(runtime.close)
        # Recovery can move uncommitted canonical directories; it belongs
        # strictly inside the candidate's exclusive run lock.
        cp=runner._load_checkpoint(cp_path,'SYNTHETIC',cells,identity,{})
        if runtime:
            from r1r11_v4_transaction import recover
            recover(output)
            (output/'sessions').mkdir(exist_ok=True)
            for d in (output/'sessions').iterdir():
                if d.is_dir() and d.name not in cp['completed']:raise RuntimeError('SESSION_WITHOUT_JOURNAL')
        else:runner._orphan_reconcile(output,cp)
        done=set(cp['completed'])
        if runtime:runtime.verify_committed(output,cp)
        for case in cases:
            session=case['session'];path=inputs/case['path']
            if session in done:
                if runtime and str(path) not in cp['verified_months']:
                    h=runner._PrefixHashTracker()
                    for _ in iter_tick_file(path,hasher=h):source_records+=1
                    cp['verified_months'][str(path)]=h.hexdigest().upper();runner._write_checkpoint(cp_path,cp)
                continue
            if runtime:runtime.fault=None if case['scenario']=='warmup' else fault
            session_started=time.perf_counter()
            states=[cp[k] for k in ('cash','hwm','maxdd','regime_min','closed_hwm','closed_maxdd')]
            h=runner._PrefixHashTracker()
            tap=PhysicalPrefixTap(h) if runtime else h
            cal=_fixture_preflight_calendar(path,session,case['cutoff'],original_parse)
            if runtime:runtime.set_synthetic_calendar_row(session,cal)
            eng=(runtime.engine(session,d1,cells,case['cutoff'],True,*states,integral_ids,source_tracker=tap)
                 if runtime else SessionEngine(session,d1,cells,case['cutoff'],True,*states,integral_ids))
            iterator=iter_tick_file(path,hasher=tap)
            for rec in iterator:
                source_records+=1
                if not eng.process_record(rec):break
            result=eng.finish(rec.ordinal,rec.date_time)
            diag=result.cutoff_diagnostics
            fills=(dict(runtime.active.cutoff_fills) if runtime else {t['direction']:t['cutoff_fill_msc'] for t in result.trades if t.get('exit_reason')=='CUTOFF'})
            for direction,key in (('BUY','cutoff_long_fill_msc'),('SELL','cutoff_short_fill_msc')):
                if direction in fills and int(fills[direction]) != int(cal[key]):
                    raise RuntimeError('SYNTHETIC_C1_FILL_MISMATCH '+direction)
            kwargs={'runtime':runtime} if runtime else {}
            runner._commit_session(output,session,result,cells,cp,done,cal,cp_path,path,h,**kwargs)
            if runtime:runtime.committed()
            for _ in iterator:source_records+=1
            cp['verified_months'][str(path)]=h.hexdigest().upper();runner._write_checkpoint(cp_path,cp)
            if runtime:runtime.memory.boundary('MONTH_VERIFIED',session,len(done))
            case_timings[session]=time.perf_counter()-session_started
        if runtime:
            for boundary in ('PRE_PILOT_RECEIPT','PRE_FINALIZE','POST_FINALIZE'):
                runtime.memory.boundary(boundary,None,len(done))
    source_io.parse_tick_fields=original_parse
    report={'role':role,'elapsed_seconds':time.perf_counter()-started,'parser_calls':parse_count,
            'source_records':source_records,'canonical_writes':audit_writes,'coordinator_pid':os.getpid(),
            'workers_requested':workers,'sessions':len(done),'integral_mode':integral}
    report['case_timings']=case_timings
    write_json_atomic_canonical(output/'SYNTHETIC_EXECUTION.json',report)
    return report


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--inputs',required=True);ap.add_argument('--out',required=True)
    ap.add_argument('--role',choices=['oracle','candidate'],required=True);ap.add_argument('--workers',type=int,default=2)
    ap.add_argument('--integral',choices=['all','baseline'],default='all');ap.add_argument('--only')
    ap.add_argument('--fault');ns=ap.parse_args()
    fault=json.loads(ns.fault) if ns.fault else None
    try:
        print(json.dumps(run_chain(ns.inputs,ns.out,ns.role,ns.workers,ns.integral,ns.only,fault)))
    except KeyboardInterrupt:
        print('SAFE_STOP=YES');raise SystemExit(130)
    except Exception as exc:
        from minotauro_v005r1_r1r10_memory import MemoryCapSafeStop
        import traceback;traceback.print_exc()
        raise SystemExit(3 if isinstance(exc,MemoryCapSafeStop) else 2)


if __name__=='__main__':main()
