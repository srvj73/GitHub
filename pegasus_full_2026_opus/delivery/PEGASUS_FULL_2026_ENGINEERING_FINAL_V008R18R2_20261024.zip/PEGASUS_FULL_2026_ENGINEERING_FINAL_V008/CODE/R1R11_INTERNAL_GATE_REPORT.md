# INTERNAL DEEP REVIEW — V004R2 BEFORE OWNER EXECUTION

**Scope:** static review and non-owner targeted checks. No V004R2 performance measurement.

## Parent evidence

V004R1 G4 is frozen FAIL at 0.3383456527336962x. It is not rerun.

## Causal findings

- V004R1 source progress reached 4224/4801 rows at 5.0 s while total case wall was 45.2984 s, locating the large regression after most feed work.
- Static code showed up to 120 transient scratch/sidecar `fsync` operations per session.
- Coordinator performed full semantic scratch+sidecar decompression/JSON validation serially before helpers, duplicating helper consumption work.
- Coordinator stage validation reread/hashes stage multiple times after helpers.
- Pending SESSION_SEAL duplicated a just-completed hash pass.

## V004R2 conformance

PASS static:
- no core/economic/oracle/SPEC change;
- canonical `gzjson` unchanged;
- scratch JSON remains authoritative;
- sidecar schema unchanged;
- helper full semantic sidecar bijection retained;
- coordinator still owns publication, receipt and checkpoint;
- stage files still fsync before `.sealed`;
- journal/pending/final/checkpoint durability sequence unchanged;
- no real entrypoint enabled.

Targeted non-owner checks performed in the ChatGPT container:
- Python compile PASS for package root Python files;
- fast scratch seal validation + full checked_rows compatibility PASS on synthetic local rows;
- keyed merge + one-pass stage validation compatibility PASS on 15 synthetic groups.

Windows-specific memory/lifecycle/recovery and complete byte differential remain owner-PC gates.

## Decision

```text
V004R2_INTERNAL_STATIC_REVIEW=PASS_FOR_OWNER_SYNTHETIC_TESTING_ONLY
V004R2_G4_AUTHORIZED_NOW=NO_UNTIL_OWNER_PRE_G4_SUITE_PASS
REAL_DATA=NO
PILOT_A=NO
RUN_A=NO
OPUS=DO_NOT_USE_YET
```
