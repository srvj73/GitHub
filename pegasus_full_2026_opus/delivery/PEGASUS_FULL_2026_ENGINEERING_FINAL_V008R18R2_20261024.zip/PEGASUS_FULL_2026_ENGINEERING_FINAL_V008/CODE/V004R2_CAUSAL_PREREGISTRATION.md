# V004R2 — CAUSAL PREREGISTRATION AFTER OWNER G4 FAIL

**Status:** preregistered before any V004R2 performance measurement.

## Frozen observed parent evidence

```text
V004R1_OWNER_G4=FAIL
SPEEDUP=0.3383456527336962
REQUIRED=1.5
ORACLE_SECONDS=15.326517900000908
CANDIDATE_SECONDS=45.29840349999722
GRANTED_WORKERS=4
OVERLAP=true
EXTERNAL_HEAVY_WORKERS=0
```

The terminal showed candidate source progress at 4224 rows after 5.0 s while total candidate case wall was 45.2984 s. This supports a post-feed/finish/commit regression; it does not by itself partition the remaining wall.

## Static causal findings in V004R1

1. Worker `ScratchSink.close()` issued `fsync` on scratch and sidecar for every stream/group. With 15 groups × 4 streams × 2 physical files, the design can issue up to 120 transient-file durability flushes per session. V004 §17.4 requires close/seal/identity for scratch; durable persistence is required for canonical stage/journal/pending, not transient scratch.
2. Coordinator `ParallelSession.finish()` ran full `validate_scratch()` semantics serially over all four streams and all 15 groups before any stage helper could begin. That duplicates gzip decompression, JSON decode, per-line SHA/merge-key/sidecar validation later repeated during helper consumption.
3. `validate_stage()` performed outer hash verification, full decompression/JSON/order proof, then outer hash verification again, sequentially for the four streams after helpers exited.
4. `SESSION_SEAL` telemetry rehashed all five pending files immediately after `validate_tree()` had already verified the same bytes.
5. Stage helper computed merge keys in `checked_rows`, then `OrderProof.add()` recomputed the key for each emitted row.
6. Stage helper fsynced the transient stage directory after `.partial -> .sealed`; the file is durable, while the transient directory can be discarded on crash before canonical transaction.

## V004R2 changes

- no change to SPEC V004, core, economy, oracle, G4 threshold, heavy fixture, batch size, serializer or canonical bytes;
- remove transient scratch file fsyncs;
- coordinator pre-helper seal validation becomes a one-pass physical compressed SHA + identity + decompressed row/byte count, parallelized in four coordinator threads by stream;
- full sidecar semantics remain mandatory in helpers while consuming scratch;
- stage postvalidation becomes one compressed-file pass per stream (consumed SHA + row/order proof) and four coordinator threads;
- post-helper scratch raw revalidation runs four coordinator threads;
- reuse already verified pending hashes for SESSION_SEAL telemetry;
- carry merge key into `OrderProof`;
- remove transient stage directory fsync, preserving stage-file fsync.

## Kill criteria

Any byte mismatch, custody failure, TOCTOU failure, memory accounting failure, worker/helper lifecycle failure, recovery divergence, false PASS, or owner G4 < 1.5 => STOP. No real data, Pilot A or Run-A.

## Governance

This is a versioned V004R2 implementation attempt after V004R1 owner G4 FAIL, as explicitly permitted by SPEC V004 §17.10.4. No V004R1 owner G4 result is discarded or rerun.

## Owner execution staging

The owner run is intentionally split: first G1–G3 only, return for review, then resume the same evidence root for the single G4 attempt and G5–G11 only if G4 passes. This does not change G4 timing or fixture semantics.
