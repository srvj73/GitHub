from __future__ import annotations
import json
from pathlib import Path
from minotauro_v004_core import ModelError

SCHEMA='MINOTAURO_SOURCE_RESUME_V003'

def file_fingerprint(path: Path) -> dict:
    path=Path(path).resolve(); st=path.stat()
    return {'path':str(path),'st_dev':int(st.st_dev),'st_ino':int(st.st_ino),'size':int(st.st_size),'mtime_ns':int(st.st_mtime_ns)}

def validate_fingerprint(path: Path, expected: dict) -> dict:
    got=file_fingerprint(path); keys=('path','st_dev','st_ino','size','mtime_ns')
    if any(got.get(k)!=expected.get(k) for k in keys):
        raise ModelError('SOURCE_RESUME_FINGERPRINT_MISMATCH '+json.dumps({'expected':expected,'got':got},sort_keys=True))
    return got

def _line_session(raw: bytes, path: Path) -> str | None:
    if not raw.strip(): return None
    parts=raw.split(b';',2)
    if len(parts)<2: raise ModelError(f'TICK_FIELD_COUNT_FAST_INDEX file={path}')
    if parts[0].strip().lower()==b'symbol': return None
    dt=parts[1].strip()
    if len(dt)<10: raise ModelError(f'TICK_DATE_PARSE_FAST_INDEX file={path}')
    d=dt[:10]
    if len(d)!=10 or d[4:5]!=b'.' or d[7:8]!=b'.': raise ModelError(f'TICK_DATE_PARSE_FAST_INDEX file={path} value={dt[:32]!r}')
    try: return d.decode('ascii').replace('.','-')
    except UnicodeDecodeError as exc: raise ModelError(f'TICK_DATE_PARSE_FAST_INDEX file={path}') from exc

def find_session_start_offset(path: Path, session: str) -> int:
    path=Path(path).resolve(); offset=0
    with path.open('rb') as f:
        for raw in f:
            here=offset; offset += len(raw); s=_line_session(raw,path)
            if s==session: return int(here)
            if s is not None and s>session: break
    raise ModelError(f'SOURCE_RESUME_SESSION_NOT_FOUND session={session} file={path}')

def make_anchor(path: Path, session: str, offset: int) -> dict:
    path=Path(path).resolve(); offset=int(offset)
    if offset<0 or offset>path.stat().st_size: raise ModelError('SOURCE_RESUME_OFFSET_RANGE')
    return {'schema':SCHEMA,'session':str(session),'offset':offset,'fingerprint':file_fingerprint(path)}

def anchor_for_first_pending(path: Path, session: str) -> dict:
    return make_anchor(path,session,find_session_start_offset(path,session))

def write_anchor_checkpoint(cp_path: Path, cp: dict, anchor: dict) -> None:
    validate_fingerprint(Path(anchor['fingerprint']['path']),anchor['fingerprint'])
    cp['source_resume']=dict(anchor)
    from minotauro_v004_runner import _write_checkpoint
    _write_checkpoint(Path(cp_path),cp)

def clear_anchor_checkpoint(cp_path: Path, cp: dict) -> None:
    cp.pop('source_resume',None)
    from minotauro_v004_runner import _write_checkpoint
    _write_checkpoint(Path(cp_path),cp)

def iter_tick_file_from_offset(path: Path, *, start_offset: int, include_sessions=None, hasher=None, progress_cb=None, progress_step_bytes: int=256*1024*1024, session_boundary_cb=None):
    """Canonical tick parsing from a verified session-boundary offset.

    Parsing semantics are delegated to the frozen minotauro_v004_io helpers; this
    function only changes the physical file start position. Header handling is not
    needed at nonzero session-boundary offsets.
    """
    from minotauro_v004_io import _split_semicolon_bytes, parse_tick_fields, session_from_date_time
    path=Path(path); file_size=path.stat().st_size; start_offset=int(start_offset)
    if start_offset<0 or start_offset>file_size: raise ModelError(f'TICK_START_OFFSET_RANGE file={path} offset={start_offset}')
    ordinal_by_session={}; bytes_read=start_offset; raw_rows_read=0
    next_report=start_offset+max(1,int(progress_step_bytes)); last_reported=-1; physical_session=None
    with path.open('rb') as f:
        f.seek(start_offset); first=(start_offset==0)
        for raw in f:
            line_start=bytes_read; bytes_read += len(raw); raw_rows_read += 1
            if hasher is not None: hasher.update(raw)
            if progress_cb is not None and bytes_read>=next_report:
                progress_cb(bytes_read,raw_rows_read,file_size,False); last_reported=bytes_read
                while next_report<=bytes_read: next_report += max(1,int(progress_step_bytes))
            if not raw.strip(): continue
            fields=_split_semicolon_bytes(raw)
            if first and fields and fields[0].lower()=='symbol':
                first=False; continue
            first=False
            if len(fields)!=9: raise ModelError(f'TICK_FIELD_COUNT file={path} got={len(fields)}')
            try: session=session_from_date_time(fields[1])
            except Exception as exc: raise ModelError(f'TICK_DATE_PARSE file={path} value={fields[1]!r}') from exc
            if session!=physical_session:
                physical_session=session
                if session_boundary_cb is not None: session_boundary_cb(session,int(line_start))
            if include_sessions is not None and session not in include_sessions: continue
            ordinal_by_session[session]=ordinal_by_session.get(session,0)+1
            yield parse_tick_fields(fields,ordinal_by_session[session])
    if progress_cb is not None and last_reported!=bytes_read:
        progress_cb(bytes_read,raw_rows_read,file_size,True)

def rehydrate_prefix_tracker(path: Path, anchor: dict, expected_prefixes: dict[int,str]):
    """Rebuild SHA state to a session anchor without economic parsing.

    Prefix expectations at/before the anchor are checked during rehydration. Expectations
    after the anchor remain armed and are checked when the resumed parser advances. This is
    required because a previous session receipt may legitimately include the first physical
    row of the next session (the boundary row is hashed before the prior session commits).
    """
    from minotauro_v004_runner import _PrefixHashTracker
    path=Path(path).resolve(); validate_fingerprint(path,anchor['fingerprint']); limit=int(anchor['offset'])
    all_expected={int(k):str(v).upper() for k,v in expected_prefixes.items()}
    tracker=_PrefixHashTracker(all_expected)
    cuts=sorted(k for k in all_expected if k<=limit); ci=0
    with path.open('rb') as f:
        while tracker.bytes_read < limit:
            next_cut=cuts[ci] if ci<len(cuts) else limit
            target=min(limit,next_cut)
            if target==tracker.bytes_read and ci<len(cuts):
                ci+=1; continue
            while tracker.bytes_read < target:
                raw=f.read(min(8*1024*1024,target-tracker.bytes_read))
                if not raw: raise ModelError('SOURCE_RESUME_PREFIX_EOF')
                tracker.update(raw)
            if ci<len(cuts) and tracker.bytes_read==cuts[ci]: ci+=1
    if tracker.bytes_read!=limit: raise ModelError('SOURCE_RESUME_REHYDRATE_OFFSET')
    missing_before=[k for k in cuts if k not in tracker.checked]
    if missing_before: raise ModelError(f'SOURCE_RESUME_PREFIX_NOT_CHECKED offset={missing_before[0]}')
    return tracker
