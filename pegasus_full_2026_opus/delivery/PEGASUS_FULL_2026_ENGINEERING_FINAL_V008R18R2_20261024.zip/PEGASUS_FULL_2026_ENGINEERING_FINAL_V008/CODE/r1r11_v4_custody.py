"""V004 scratch custody. JSON is authoritative; sidecars are checked 1:1."""
import ctypes
from ctypes import wintypes as w
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
from minotauro_v004_core import ModelError
from r1r11_transport import merge_key

STREAMS = ('trades', 'events', 'equity', 'equity_reconciliation')


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def sync_directory(path):
    if os.name != 'nt':
        fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY)
        try: os.fsync(fd)
        finally: os.close(fd)
        return
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    k.CreateFileW.argtypes = [w.LPCWSTR,w.DWORD,w.DWORD,ctypes.c_void_p,w.DWORD,w.DWORD,ctypes.c_void_p]
    k.CreateFileW.restype = ctypes.c_void_p
    k.FlushFileBuffers.argtypes = [ctypes.c_void_p]; k.FlushFileBuffers.restype = w.BOOL
    k.CloseHandle.argtypes = [ctypes.c_void_p]; k.CloseHandle.restype = w.BOOL
    h = k.CreateFileW(str(Path(path).resolve()),0x40000000,7,None,3,0x02000000,None)
    if h in (None,ctypes.c_void_p(-1).value):
        raise ModelError('DIRECTORY_SYNC_OPEN '+str(ctypes.get_last_error()))
    try:
        if not k.FlushFileBuffers(h):
            raise ModelError('DIRECTORY_SYNC_FAILED '+str(ctypes.get_last_error()))
    finally:
        k.CloseHandle(h)


def sync_file(path):
    with Path(path).open('r+b') as f:
        f.flush(); os.fsync(f.fileno())


def identity(path):
    path = Path(path)
    if path.is_symlink() or path.is_junction():
        raise ModelError('CUSTODY_LINK_FORBIDDEN')
    s = path.stat()
    # CPython Windows stat exposes volume serial and file index via st_dev/ino.
    if not s.st_ino:
        raise ModelError('FILE_ID_UNAVAILABLE')
    return {'volume_serial':s.st_dev,'file_id':s.st_ino,'bytes':s.st_size,
            'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}


def seal_file(path):
    before = identity(path); digest = sha(path)
    if before != identity(path): raise ModelError('FILE_CHANGED_DURING_SEAL')
    return {'path':str(Path(path).resolve()),'identity':before,'sha256':digest}


def verify_file(manifest):
    path = Path(manifest['path'])
    if identity(path)!=manifest['identity'] or sha(path)!=manifest['sha256'] or identity(path)!=manifest['identity']:
        raise ModelError('SEALED_FILE_IDENTITY_OR_HASH_MISMATCH '+str(path))


def inject_file_fault(manifest,kind):
    """Explicit synthetic fault hook; unreachable without a fault request."""
    p=Path(manifest['path'])
    if kind=='sha':manifest['sha256']='0'*64
    elif kind=='file_id':
        replacement=p.with_name(p.name+'.fault-replacement')
        with replacement.open('xb') as f:f.write(p.read_bytes())
        os.replace(replacement,p)
    elif kind=='truncate':
        with p.open('r+b') as f:f.truncate(max(0,p.stat().st_size-1))
    else:
        with p.open('ab') as f:f.write(b'FAULT')


class HashedReader(io.RawIOBase):
    def __init__(self, path):
        self.file = Path(path).open('rb'); self.hash = hashlib.sha256()
    def readable(self): return True
    def readinto(self, buf):
        n = self.file.readinto(buf)
        if n: self.hash.update(memoryview(buf)[:n])
        return n
    def close(self):
        self.file.close(); super().close()


class ScratchSink:
    def __init__(self,path,kind,cells):
        self.path=Path(path);self.kind=kind
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.side_path=self.path.with_name(self.path.name+'.sidecar.gz')
        self.stream=gzip.open(self.path,'wb',compresslevel=1)
        self.side=gzip.open(self.side_path,'wb',compresslevel=1)
        self.index={c.cell_id:i for i,c in enumerate(cells)}
        groups=sorted({(c.p_idx,c.t_idx) for c in cells})
        self.rank={c.cell_id:groups.index((c.p_idx,c.t_idx)) for c in cells}
        self.binding={'group':self.path.parent.name,'session':self.path.parent.parent.name,
            'run_instance':self.path.parent.parent.parent.name,'stream':kind,'generation':1}
        self.last=None;self.count=0;self.offset=0;self.closed=False
        self.encoder=json.JSONEncoder(ensure_ascii=False,separators=(',',':'))
    def append(self,row):
        key=merge_key(self.kind,row,self.index,self.rank)
        if self.last is not None and (key<self.last or self.kind in ('trades','equity_reconciliation') and key==self.last):
            raise ModelError('SCRATCH_TOTAL_ORDER')
        payload=self.encoder.encode(row).encode('utf-8')
        end=self.offset+len(payload)+1
        meta={**self.binding,'line_no':self.count,'local_seq':self.count,
              'uncompressed_offset_start':self.offset,'uncompressed_offset_end_exclusive':end,
              'merge_key':list(key)+[self.count],'line_sha256':hashlib.sha256(payload).hexdigest()}
        self.stream.write(payload+b'\n');self.side.write(self.encoder.encode(meta).encode()+b'\n')
        self.last=key;self.count+=1;self.offset=end
    def close(self):
        if not self.closed:
            # Scratch is transient and never authoritative across a crash. Closing
            # both gzip handles makes the bytes visible to the coordinator; the
            # V004 transaction durability contract begins at canonical stage, not
            # at worker scratch. Avoid 120 durability flushes on the hot path.
            self.stream.close();self.side.close();self.closed=True
    def manifest(self):
        if not self.closed:raise ModelError('SCRATCH_NOT_CLOSED')
        return {'binding':self.binding,'rows':self.count,'uncompressed_bytes':self.offset,
                'scratch':seal_file(self.path),'sidecar':seal_file(self.side_path)}



def _scan_sealed_gzip(manifest, expected_rows, expected_uncompressed_bytes=None):
    """One-pass physical SHA + gzip row/byte count without JSON semantics.

    This is the coordinator-side V004 §17.4.1 seal validation. Full semantic
    sidecar bijection/order is performed later by the stream helper while
    consuming the same sealed bytes.
    """
    path=Path(manifest['path'])
    before=identity(path)
    if before!=manifest['identity']:
        raise ModelError('SEALED_FILE_IDENTITY_MISMATCH '+str(path))
    raw=HashedReader(path);rows=0;total=0;last=None
    try:
        with io.BufferedReader(raw) as b:
            with gzip.GzipFile(fileobj=b,mode='rb') as gz:
                while True:
                    chunk=gz.read(1024*1024)
                    if not chunk:break
                    rows+=chunk.count(b'\n');total+=len(chunk);last=chunk[-1]
            # Consume any gzip trailer/read-ahead bytes into the physical hash.
            while b.read(1024*1024):pass
        if raw.hash.hexdigest()!=manifest['sha256']:
            raise ModelError('SEALED_FILE_SHA256_MISMATCH '+str(path))
        if identity(path)!=manifest['identity']:
            raise ModelError('SEALED_FILE_CHANGED_DURING_SCAN '+str(path))
        if rows!=expected_rows:
            raise ModelError('SEALED_FILE_ROW_COUNT_MISMATCH '+str(path))
        if expected_rows and last!=10:
            raise ModelError('SEALED_FILE_FINAL_LF_MISSING '+str(path))
        if expected_uncompressed_bytes is not None and total!=expected_uncompressed_bytes:
            raise ModelError('SEALED_FILE_UNCOMPRESSED_BYTES_MISMATCH '+str(path))
        return {'rows':rows,'uncompressed_bytes':total}
    finally:
        raw.close()


def validate_sealed_fast(manifest,cells,root):
    """Coordinator seal validation matching V004 §17.4.1 exactly."""
    binding=manifest['binding'];kind=binding['stream']
    expected_root=Path(root).resolve()/binding['group']
    if binding['session']!=Path(root).name or binding['run_instance']!=Path(root).parent.name or binding['generation']!=1:
        raise ModelError('SCRATCH_RUN_BINDING')
    for field in ('scratch','sidecar'):
        p=Path(manifest[field]['path']).resolve()
        if p.parent!=expected_root:raise ModelError('SCRATCH_PATH_BINDING')
    rows=int(manifest['rows'])
    _scan_sealed_gzip(manifest['scratch'],rows,int(manifest['uncompressed_bytes']))
    _scan_sealed_gzip(manifest['sidecar'],rows,None)


def checked_rows(manifest,kind,index,ranks):
    if manifest['binding']['stream']!=kind:raise ModelError('SCRATCH_STREAM_BINDING')
    for field in ('scratch','sidecar'):verify_file(manifest[field])
    raw=HashedReader(manifest['scratch']['path']);side_raw=HashedReader(manifest['sidecar']['path'])
    count=0;offset=0;last=None
    try:
        with io.BufferedReader(raw) as b,io.BufferedReader(side_raw) as sb:
            with gzip.GzipFile(fileobj=b,mode='rb') as gz,gzip.GzipFile(fileobj=sb,mode='rb') as sgz:
                for line in gz:
                    side_line=sgz.readline()
                    if not line.endswith(b'\n') or not side_line.endswith(b'\n'):
                        raise ModelError('SIDECAR_MISSING_OR_FRAME')
                    row=json.loads(line);meta=json.loads(side_line)
                    if not isinstance(row,dict) or not isinstance(meta,dict):raise ModelError('SCRATCH_JSON_TYPE')
                    key=merge_key(kind,row,index,ranks)
                    end=offset+len(line)
                    binding=manifest['binding']
                    if (meta.get('group')!=binding['group'] or meta.get('session')!=binding['session'] or
                        meta.get('run_instance')!=binding['run_instance'] or meta.get('stream')!=binding['stream'] or
                        meta.get('generation')!=binding['generation'] or meta.get('line_no')!=count or
                        meta.get('local_seq')!=count or meta.get('uncompressed_offset_start')!=offset or
                        meta.get('uncompressed_offset_end_exclusive')!=end or
                        meta.get('merge_key')!=list(key)+[count] or
                        meta.get('line_sha256')!=hashlib.sha256(line[:-1]).hexdigest()):
                        raise ModelError('SIDECAR_BIJECTION_MISMATCH')
                    if last is not None and (key<last or kind in ('trades','equity_reconciliation') and key==last):
                        raise ModelError('SCRATCH_ORDER_MISMATCH')
                    last=key;count+=1;offset=end
                    yield key,row
                if sgz.read(1):raise ModelError('SIDECAR_EXTRA_LINE')
            # Read all physical bytes, including any gzip trailer read-ahead.
            while b.read(1024*1024):pass
            while sb.read(1024*1024):pass
        if count!=manifest['rows'] or offset!=manifest['uncompressed_bytes']:
            raise ModelError('SCRATCH_COUNTS_MISMATCH')
        for field,reader in (('scratch',raw),('sidecar',side_raw)):
            if reader.hash.hexdigest()!=manifest[field]['sha256']:
                raise ModelError('CONSUMED_SHA256_MISMATCH')
            if identity(manifest[field]['path'])!=manifest[field]['identity']:
                raise ModelError('FILE_CHANGED_WHILE_CONSUMING')
    finally:
        raw.close();side_raw.close()


def validate_scratch(manifest,cells,root):
    binding=manifest['binding'];kind=binding['stream']
    expected_root=Path(root).resolve()/binding['group']
    if binding['session']!=Path(root).name or binding['run_instance']!=Path(root).parent.name or binding['generation']!=1:
        raise ModelError('SCRATCH_RUN_BINDING')
    for field in ('scratch','sidecar'):
        p=Path(manifest[field]['path']).resolve()
        if p.parent!=expected_root:raise ModelError('SCRATCH_PATH_BINDING')
    index={c.cell_id:i for i,c in enumerate(cells)}
    groups=sorted({(c.p_idx,c.t_idx) for c in cells})
    ranks={c.cell_id:groups.index((c.p_idx,c.t_idx)) for c in cells}
    for _ in checked_rows(manifest,kind,index,ranks):pass
