# R1R11 V003 — fechamento da Fase 1 de viabilidade G4

**DECISION: FAIL-CLOSED para implementar V003R3.** A margem necessária não
foi demonstrada por um desenho compatível com as restrições vigentes.
O escopo deste FAIL é a prova de viabilidade para autorizar implementação.
Uma impossibilidade universal de atingir 1,5x sob toda arquitetura permitida
pela SPEC **permanece UNPROVEN**. Nenhum gate ou receipt histórico foi alterado.

## 1. Evidência recebida e integridade

EVIDENCE: dois retornos owner foram conferidos por CRC, manifesto SHA256,
ausência de entradas extras/duplicadas e identidade do pacote/instrumento:

| Retorno | SHA256 | Entradas vinculadas |
|---|---|---:|
| PROFILE_RETURN.zip | BB2187FB9453E2EE0B15F342CC6272FC1D6597EB6F23393DD016FAD643606DDA | 42 |
| PROFILE_MACRO_RETURN.zip | 016F5C11FA2A9BBAE9E1E612D75069DF849A49CD5C84C467F3325A149E22BBA7 | 25 |

Os 11 arquivos canônicos por run foram novamente comparados fisicamente no
disco: oito runs no primeiro retorno e quatro no segundo, **132 verificações**.
Cada conjunto apresentou identidade byte a byte entre seus controles e perfis.
Não se compararam checkpoints/receipts de conjuntos diferentes como se fossem
o mesmo input físico: os diretórios sintéticos de origem são distintos.

Runtime dos dois conjuntos: Python owner 3.14.7, 64 bits, NumPy 2.4.6.
O perfil macro registrou **GIL habilitado** em oracle e candidato. Todos os
casos heavy mantiveram 1200 cycles, quatro workers solicitados/concedidos,
batch_rows=32, um slot, threshold=1,5 e o pacote V003R2 original.

Manifesto do pacote:
`F12A7FA0DF0DA81D2BBE5B206FF857104335E042ED11CD8C8AB08B70AFB488FB`.

## 2. Resultados end-to-end sem instrumentação

EVIDENCE: a referência principal permanece a mediana preregistrada das três
execuções iniciais. Os controles novos são apresentados separadamente; não
há agrupamento pós-hoc ou seleção do oracle mais lento para facilitar G4.

| Conjunto | Oracle (s) | Candidato (s) | Speedup | Target = oracle / 1,5 (s) |
|---|---:|---:|---:|---:|
| Medianas iniciais, referência principal | 15.4133320 | 17.1191955 | 0.9003538x | 10.2755547 |
| Controle complementar | 15.7657298 | 18.0958367 | 0.8712352x | 10.5104865 |

A referência principal exige reduzir **6.8436408 s, ou 39.9764%** do candidato.
No controle complementar, a redução requerida é **41.9177%**. Nenhum atingiu
1,5x. Os tempos complementares não são reinterpretados como resultado de uma
revisão nova: o executor continua V003R2.

## 3. Qualidade da medição e fronteira legítima

EVIDENCE: o perfil detalhado anterior teve 12.840.652 spans no candidato e
59.6755235 s end-to-end; sua decomposição por linha é intrusiva. Seus tempos
absolutos não entram no orçamento nem na tentativa de lower bound.

O complemento macro removeu os hooks por TickRecord, JSON row, key e yield:

| Medição | Controle (s) | Macro (s) | Diferença relativa | Spans heavy |
|---|---:|---:|---:|---:|
| Oracle | 15.7657298 | 15.6171007 | -0.9427% | 1.490 |
| Candidato | 18.0958367 | 18.3376825 | +1.3365% | 8.164 |

INFERENCE: a medição macro é apropriada para localizar o custo dominante e
formular estimativas de serviço. Uma amostra por modo não mede isoladamente
o overhead: inclui variação de execução. Os tempos não foram corrigidos por
escala, subtração estimada ou escolha de amostra favorável.

EVIDENCE: os hooks usaram as duas chamadas originais de `case_timings` e
confirmaram igualdade exata. A fronteira inclui setup/spawn, feed, finish,
merge, commit, cleanup, EOF físico, checkpoint e memory boundary final da
sessão. Warmup permanece fora somente por fazer parte do contrato original.
Nenhuma fase interna foi excluída ou substituída.

## 4. Decomposição temporal que fecha exatamente

EVIDENCE: esta partição disjunta cobre os **18.3376825 s** do candidato macro.
Ela usa fronteiras do mesmo run; não combina tempos de execuções diferentes.

| Intervalo disjunto | Wall (s) |
|---|---:|
| Entrada do caso até setup | 0.0000270 |
| Setup, spawn e READY | 0.2506055 |
| Feed, parse, batches e boundaries até finish | 3.4621498 |
| Finish, recebimento, integridade e transformação | 1.7614004 |
| Preparação entre finish e commit | 0.0559032 |
| Commit completo, incluindo os quatro streams | **12.6457962** |
| Pós-commit, cleanup, EOF e checkpoint final | 0.1618004 |
| Total | **18.3376825** |

O commit corresponde a **68.9607%** do caso. Ele domina a execução medida.
Memória, ACK e compressão são subcomponentes desses intervalos; não são
parcelas adicionais a somar à tabela.

EVIDENCE de subcomponentes macro: 151 esperas de ACK totalizam 3.0165117 s
inclusivos, envolvendo compute real; 155 boundaries de memória da sessão
somam 0.2673994 s; telemetry write soma 0.0601047 s. Receber RESULT leva
1.2957391 s, contendo aproximadamente 0.9993 s de decode de Pipe observado
no conjunto das recepções. O sort de resultados/trades soma 0.4360792 s.
Todos esses valores se aninham na partição acima.

## 5. CPU, wall e sobreposição do fechamento

EVIDENCE: a CPU do processo durante o commit candidato foi 14.734375 s em
12.6457962 s de wall, média de aproximadamente 1,165 CPU. Quatro threads não
equivalem a quatro núcleos continuamente úteis neste caminho.

| Stream | Oracle wall (s) | Oracle CPU da thread (s) | Candidato wall (s) | Candidato CPU da thread (s) |
|---|---:|---:|---:|---:|
| trades | 3.8684987 | 3.859375 | 8.1419803 | 4.437500 |
| events | 2.2298295 | 2.203125 | 12.5799330 | 4.578125 |
| equity | 2.7428465 | 2.750000 | 12.2933699 | 5.640625 |
| reconciliation | 0.0022285 | 0.000000 | 0.0167001 | 0.000000 |

Os streams candidatos começam quase juntos, em cerca de 5,578 s do caso.
Seus wall times **se sobrepõem**. A soma de CPU das threads do writer é
14.65625 s; a soma de wall não representa duração do commit. CPU zero em
um intervalo pequeno não prova custo zero: os agregados observados mostram
quantização de 15,625 ms, mesmo quando a API anuncia resolução mais fina.

EVIDENCE: o oracle executa o mesmo `gzjson` sequencialmente, sobre resultados
já produzidos. Seus streams somam **8.8125 s de CPU**, dos quais **1.171875 s**
foram atribuídos aos wrappers de zlib em blocos. O residual é **7.640625 s**.
Esse residual inclui JSON, traversal, wrappers de texto/I/O e efeitos da
medição; não é uma medição pura de JSON nem um piso físico certificado.

INFERENCE: há custo relevante adicional no caminho candidato que consome
scratch, constrói keys, faz merge e reemite JSON, além da concorrência entre
threads. A diferença de CPU entre writers não pode ser atribuída inteira
ao merge. Por exemplo, o wrapper de compressão também apresentou CPU distinta
entre candidato e oracle, apesar do mesmo algoritmo/bytes finais.

O GIL habilitado limita execução simultânea de trabalho Python no mesmo
processo; os dados já mostram alguma sobreposição útil. Não foi demonstrado
que adicionar threads ou encadear producer/consumer dentro do coordinator
produziria a aceleração requerida.

## 6. Três cenários e limites da prova

| Cenário pedido | Resultado defensável |
|---|---|
| CURRENT | EVIDENCE: 17.1191955 s de mediana principal; controle novo 18.0958367 s |
| REALISTIC_OPTIMIZED | UNKNOWN / UNPROVEN: não há desenho validado com orçamento <= target |
| THEORETICAL_SAFE_LOWER_BOUND | UNKNOWN / UNMEASURED: demanda irredutível e sobreposição segura não foram provadas |

### 6.1 Sensibilidade: melhorar somente o fechamento

HYPOTHESIS, explicitamente condicional: mantenha os demais intervalos do
candidato macro, elimine todo custo de preparação/merge do commit e conceda
custo zero à parcela de compressão do writer. Use o serviço não-zlib observado
do oracle apenas como proxy de reemissão pelo `gzjson` obrigatório:

```text
outside_commit = 18.3376825 - 12.6457962 = 5.6918863 s
writer_proxy = 8.8125 - 1.171875 = 7.6406250 s
closing_only_optimistic_proxy = 5.6918863 + 7.6406250 = 13.3325113 s
```

INFERENCE SOB ESSAS PREMISSAS: esse cenário ainda fica acima tanto de
10.2755547 s quanto de 10.5104865 s. Uma proposta restrita ao fechamento,
com o restante do fluxo atual mantido, não tem orçamento demonstrado para G4.

**13,3325 s não é lower bound universal.** CPU observada não é custo
irredutível: preparação, representação de objetos, locality e reorganização
compatível podem alterar o custo de uma mesma função. A compressão retirada
da conta continua obrigatória no executor; sua retirada aqui apenas torna a
simulação favorável ao candidato. Nenhuma fase foi retirada de um timing real.

### 6.2 Sensibilidade extrema que impede alegar impossibilidade universal

EVIDENCE: as quatro somas de CPU dos corpos de batch dos workers foram
2.71875, 1.890625, 2.734375 e 1.75 s, totalizando 9.09375 s. Incluem compute,
scratch e parte do tratamento do lote; não são CPU econômica pura.

HYPOTHESIS: distribuição perfeita dessa demanda entre quatro workers,
overhead zero de lifecycle, barreiras, probes, transporte, hash e merge,
compressão sem custo adicional e writer igual ao proxy acima:

```text
ideal_worker_proxy = 9.09375 / 4 = 2.2734375 s
ideal_zero_overhead_proxy = 2.2734375 + 7.640625 = 9.9140625 s
```

Esse número cai abaixo dos targets, mas omite custos obrigatórios e não
descreve uma implementação autorizável. A folga frente ao target principal
seria somente 0.3614922 s para os custos omitidos. Ele tampouco é um lower
bound certificado, pois conserva demandas observadas que podem mudar.

INFERENCE: os dados não sustentam nem uma prova universal de impossibilidade
nem um orçamento realizável com margem. Declarar `FAIL` porque o commit atual
é maior que o target confundiria custo atual com custo mínimo. Declarar
`PASS` porque a simulação idealizada é menor confundiria hipótese com prova.
O resultado correto para implementação é **NO-GO por viabilidade não demonstrada**.

## 7. As 18 categorias e classificação arquitetural

EVIDENCE: `DETAILED_COMPONENTS_18.json/.csv` preserva CPU exclusivo por
thread e wall inclusivo do primeiro perfil, com marca explícita de medição
intrusiva. `MACRO_PARTITION.*`, `WRITER_STREAMS.*` e `WORKER_COSTS.*` contêm as
medidas macro utilizáveis como orçamento observado. Não misturar as escalas.

| # | Componente | Classificação para investigação | Interpretação |
|---:|---|---|---|
| 1 | Spawn/startup | REDUCIBLE | Persistência pode reduzir custo; lifecycle não provado |
| 2 | Setup | REDUCIBLE | Custos pequenos frente ao déficit; estados isolados |
| 3 | Encode/publicação | OVERLAPPABLE | Slot/seq/generation/CRC e backpressure obrigatórios |
| 4 | Compute | OVERLAPPABLE | Core congelado; paralelismo entre grupos completos |
| 5 | ACK/barreiras | SPEC_REQUIRED_SERIAL | Dependência de validação/reuso do slot; espera contém compute |
| 6 | Probes/telemetry | SPEC_REQUIRED_SERIAL | Resultado agregado exigido em cada boundary; implementação pode ser otimizada |
| 7 | Finalização | REDUCIBLE | Separar finish do engine, envio e recepção de resultados |
| 8 | Geração scratch | REDUCIBLE | Não eliminar requisito de scratch/completude |
| 9 | Compressão scratch | REDUCIBLE | Scratch comprimido obrigatório, nível atual 1 |
| 10 | Hash scratch | OVERLAPPABLE | Preservar integridade e TOCTOU; nenhuma redundância dispensável provada |
| 11 | Read/decompress | OVERLAPPABLE | Preparação pode ocorrer fora do writer se bounded e validada |
| 12 | Merge keys | REDUCIBLE | Ordem S1a–S5b congelada; representação operacional investigável |
| 13 | Cópias/transformações | REDUCIBLE | Custódia e estado imutável após FINISH; sem listas globais events/equity |
| 14 | K-way merge | INHERENT_SERIAL | Próximo item ordenado por stream; preparação não precisa ser toda serial |
| 15 | JSON | REDUCIBLE | C1 mantém reemissão pelo mesmo gzjson; nenhum ganho demonstrado |
| 16 | Gzip canônico | SPEC_REQUIRED_SERIAL | Ordem/estado do compressor por stream; streams já se sobrepõem |
| 17 | Receipt/checkpoint/commit | SPEC_REQUIRED_SERIAL | Publicação após validações e conclusão dos streams |
| 18 | Cleanup | OVERLAPPABLE | Apenas depois do commit seguro; efeito pequeno no orçamento |

Não há item classificado REMOVABLE com prova suficiente nesta auditoria.
As classificações indicam dependências/oportunidades, não segundos de ganho
garantidos nem obrigação de serializar toda preparação dentro do coordinator.

## 8. Conclusão adversarial A–I

- **A — Minimal-copy:** o `asdict` recursivo já saiu em V003R2. O retorno de
  300.000 trades ainda demanda decode e sort. Não há prova de eliminação do
  transporte/ordenação com custódia e orçamento suficientes.
- **B — Pré-serialização:** C1 exige linhas JSON no scratch reemitidas pelo
  mesmo `gzjson` do parent. Consumir bytes finais diretamente exigiria resolver
  esse contrato; equivalência apenas semântica não autoriza bypass. Nenhuma
  interpretação permissiva foi adotada.
- **C — Merge:** 633.615 eventos parciais e 750.000 equity rows tornam o
  fechamento relevante; 14 eventos parciais são fundidos, gerando 633.601
  events. Keys mínimas/streaming são candidatos a desenho, não ganhos provados.
- **D — Compressão scratch:** já em nível 1. CPU medida dessa compressão nos
  workers é pequena frente ao déficit; não justifica alterar C4 ou gzip final.
- **E — Pipeline:** preparar decode/keys em paralelo é conceitualmente
  distinto de publicar bytes canônicos. Exige bounded buffers, custo de IPC,
  ordem final, verificação de hashes e lifecycle. O writer já possui quatro
  streams sobrepostos. Não há orçamento demonstrado para novo pipeline.
- **F — Hashing:** os passes worker/coordinator verificam custódia. Leitura
  redundante aparente não prova hash redundante; nenhuma remoção autorizada.
- **G — Pool persistente:** setup total observado é cerca de 0,2506 s.
  Persistência isolada não cobre déficit de 6,84 s. Grant por sessão,
  run_instance, scratch, parent-death, SIGINT e resume continuam vinculantes.
- **H — Batches:** os gaps internos normais são cerca de 0,45–0,51 s.
  Batch maior pode reduzir algumas barreiras, não demonstra G4. Permanece 32/1;
  nenhuma escolha pós-hoc, nenhum tuning e nenhum C5 removido.
- **I — Bytes:** identidade física comprovada dentro de ambos os conjuntos.
  Isso valida o diagnóstico, não promove G5/G6/G7 nem prova arquitetura futura.

## 9. Custódia, congelamento e escopo executado

EVIDENCE: `00A_R1R10_PARENT_IDENTITY_CLARIFICATION.md` e
`00B_R1R10_FINAL_ORACLE_CERTIFICATION.md` foram relidos. As identidades
lógica e física do parent permanecem distintas, sem conflito. O bloqueio
deste relatório é de viabilidade, não de identidade nem de AMBIGUOUS.

Bindings físicos conferidos em `FROZEN_BINDINGS_VERIFIED.json`:

```text
SPEC_V003=552401C071384B921FDF4358EB3CBEB71441E5C8D2500B24183204425CFD91C6
CORE=97F8F957300D37966913C872B7F04E498D30B0CFF68180993DB80D314B900827
SPEC_ECONOMICA=D6D791083870015BF07BF4ABF64718D37F9136FA247D49DB31B4DC8DE2E73747
CERT_AMBIGUOUS=2E5F447BE75D238E583C72272002E34BBF1B0FA3D47478B7B299311AC5433EBB
ORACLE_RUNNER=E5E87B55C142159E84E39E44A8AF3E3BA6055CCDADFDAD022599E91A3FED25B9
```

IO, metrics e preflight também coincidem com seus hashes congelados. A fonte
da função `gzjson` extraída por AST é idêntica em oracle e candidato, inclusive
compresslevel=6, mtime=0, sort_keys e separators. SHA256 do trecho com newline
normalizado: `3CA299F409F29431719C85A22E43E2E68A043DFBAAEFD4E247A93114163F7961`.

Recovery: Git root `D:\Teste Rede Neural MQL5\Pegasus\micro_transit`, branch
`main`, HEAD `0ff570509dae1d93e487150192cd5d2280423368`. As quatro alterações
rastreadas preexistentes permanecem com o mesmo diff (288 inserções/19 remoções).
Staged permanece igual. A única árvore nova desta etapa é a deste closeout.

O inventário antes/depois abrange 1.405 arquivos nas sete árvores protegidas:
V003R1, V003R2, evidência owner G4 falha, dois instrumentos anteriores e os
dois conjuntos owner de profiling. Nenhum receipt foi editado ou reutilizado.

Execução desta etapa: somente `analyze_closeout.py`, leitor offline de JSON,
ZIP, hashes e fontes, seguido de selagem documental. Exit 0. Não importou o
executor, não replayou fixture, não executou homologação ou dados de mercado.
Comando reproduzível (os outputs usam criação exclusiva e não são sobrescritos):

```powershell
& 'C:\Users\silvi\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -X utf8 -B 'D:\Teste Rede Neural MQL5\Pegasus\micro_transit\R1R11_G4_FEASIBILITY_CLOSEOUT_20260926\analyze_closeout.py'
```

## 10. Handoff e decisão

```text
G4_ARCHITECTURAL_FEASIBILITY=FAIL
FAIL_SCOPE=IMPLEMENTATION_VIABILITY_NOT_DEMONSTRATED
UNIVERSAL_ARCHITECTURAL_INCOMPATIBILITY=UNPROVEN
TARGET_SECONDS=10.2755546667
CURRENT_SECONDS=17.1191955000
REFERENCE=medianas owner inicialmente preregistradas
LATEST_CONTROL_CANDIDATE_SECONDS=18.0958367000
LATEST_PAIRED_TARGET_SECONDS=10.5104865333
SERIAL_FLOOR_SECONDS=UNMEASURED
THEORETICAL_SAFE_LOWER_BOUND=UNMEASURED
TARGET_REACHABLE_UNDER_SPEC=UNPROVEN
DOMINANT_COMPONENTS=commit,merge,reemissao_JSON,processamento_concorrente_dos_streams
SPEC_CONSTRAINTS_BINDING=C1-C7,byte_identity,single_writer,grants_per_session
SAFE_OPTIMIZATIONS=NONE_WITH_DEMONSTRATED_G4_BUDGET_FOR_V003R3
SPEC_CHANGE_REQUIRED=UNPROVEN
V003R3_IMPLEMENTATION_AUTHORIZED=NO
OWNER_PROFILE_REQUIRED=NO
REAL_DATA_PROCESSING=NO
PILOT_A=NO
RUN_A=NO
NEXT_STEP=Revisao metodologica independente deste diagnostico, mantendo as restricoes
```

DECISION: não há terceiro perfil ou nova tentativa automática. O owner recebe
o diagnóstico para revisão independente. Uma continuação que implemente
V003R3 requer um desenho compatível, orçamento defensável e autorização
explícita; este relatório não relaxa a SPEC, o oracle ou G4.
