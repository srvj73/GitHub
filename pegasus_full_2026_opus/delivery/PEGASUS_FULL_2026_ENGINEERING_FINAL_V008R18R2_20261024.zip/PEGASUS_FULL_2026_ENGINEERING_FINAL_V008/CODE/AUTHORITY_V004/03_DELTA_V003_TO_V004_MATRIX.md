# DELTA MATRIX — SPEC V003 -> V004

## Regra
V004 preserva V003 integralmente, exceto as substituições explícitas de §17.

| Finding | Fechamento V004 |
|---|---|
| B1 — C4 exige coordinator físico | §17.1, §17.2, §17.3 autorizam helpers não canônicos; coordinator segue publisher único |
| B2 — transação ambígua | §17.7 define journal -> pending -> atomic session -> checkpoint -> cleanup e recovery por fronteira |
| B3 — TOCTOU aberto | §17.4 define sealing, manifests, file identity, consumed hash, revalidação e nenhum writer vivo |
| B4 — trades/sidecars incompletos | §17.3.2–17.3.4 fecha trade finality, enrichment, ordem e bijeção scratch↔sidecar |
| B5 — recursos dos helpers | §17.5–17.6 inclui helpers em JOB_MEM/JOB_PEAK_BOUND, peak handshake, process registry, SIGINT/parent-death |
| B6 — budget postulado | §17.10 remove alegação de atingibilidade; números viram diagnóstico/objetivo, G4 continua árbitro empírico |
| m-1 — 37,5% mal interpretável | §17.10 explicita eficiência nominal; 62,5% não é overhead budget |

## Cláusulas preservadas sem mudança
- economia/core;
- C2, C3, C6, C8/G6;
- certificado AMBIGUOUS;
- G4 = 1,5x;
- heavy_cycles=1200;
- fronteira end-to-end;
- oracle;
- `gzjson` final e compresslevel 6;
- byte identity;
- G5 worker matrix;
- source single-pass;
- no silent serial fallback.

## Mudanças físicas autorizadas
- trades finais em scratch comprimido;
- sidecars não autoritativos;
- até 4 stage helpers;
- coordinator como publisher canônico único;
- commit journal control-plane;
- fault injection ampliada.
