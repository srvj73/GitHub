# SPEC MINOTAURO R1R11 MULTIWORK/AUTOCPU V004

**Data:** 2026-09-26  
**Status:** PROVISÓRIA PARA IMPLEMENTAÇÃO SINTÉTICA V004R1; APROVAÇÃO INDEPENDENTE FINAL OBRIGATÓRIA ANTES DE QUALQUER DADO REAL  
**Parent:** MINOTAURO_PARAMETER_MARKET_DISCOVERY_V005R1_R1R10  
**Parent runner identity:** `189C26D6B05F661A731E94058A0006F7AD8E956B92342854722191AFBA1AA582`  
**Parent gate-suite identity:** `4414304E2CA168218AC811EA4B81A1F88437A28784ECDE0ADF52B066CD93B0C7`  
**SPEC econômica vigente:** `D6D791083870015BF07BF4ABF64718D37F9136FA247D49DB31B4DC8DE2E73747`

## 1. Motivo da R1R11

A R1R10 foi bloqueada antes do Pilot A porque seu executor econômico permanece monowork. O owner revogou operacionalmente a autorização de piloto, preservando o arquivo original como `OWNER_PILOT_AUTHORIZATION.BLOCKED_MONOWORK.json` com SHA-256 `12E4148C1E0CB7E7892148CBD07D87B9E633CC7D8A2824C4CCE12D0B5E19EBC4`.

Estado preservado como evidência, não como autorização de execução:

- S0/S1 bootstrap + preregistro: PASS;
- S2 synthetic: PASS 44/44;
- S3 operational: PASS 34/34;
- S4 lightweight rebind: PASS;
- S5 non-economic gates: PASS;
- S6 geometry parity: PASS, `divergent_rows=0`, `summary_2025_rows=750`;
- S7 seal: PASS 27/27;
- S8: autorização criada e depois bloqueada por violação monowork;
- Pilot A R1R10: **NÃO EXECUTADO**;
- RUN_A R1R10: **NÃO AUTORIZADO**.

A R1R11 deve corrigir exclusivamente a arquitetura de execução pesada. É proibido adaptar economia, causalidade, geometria, seleção ou dados para facilitar a paralelização.

## 2. Regras canônicas vinculantes de execução

A implementação final pesada deve obedecer cumulativamente:

- `MULTIWORK=REQUIRED`;
- `AUTOCPU=REQUIRED`;
- `MONOWORK_FINAL_ACCEPTABLE=NO`;
- `SERIAL_FALLBACK_SILENT=FORBIDDEN`;
- `PARALLELISM_MUST_BE_EFFECTIVE=YES`;
- `MIN_EFFECTIVE_WORKERS=2`;
- `MAX_WORKERS=12`;
- `RAM_TARGET≈60%` da RAM física para scheduling;
- `PROCESS_SCAN_BEFORE_SUBMIT=YES`;
- banner obrigatório com `CPU_LOGICAL`, `REQUESTED_WORKERS`, `GRANTED_WORKERS`, workers externos/concorrentes detectados e razão do grant;
- se uma carga paralelizável não puder receber pelo menos 2 workers, **STOP fail-closed**; não cair silenciosamente para serial;
- checkpoint atômico;
- canonical output single-writer;
- `SAFE_STOP=YES`;
- resume determinístico, inclusive com quantidade diferente de workers após restart;
- nenhum worker pode escrever diretamente em `PHASE_A/sessions/<date>` ou `PILOT_A/sessions/<date>`;
- source read-only;
- lock contra duplicidade da mesma execução;
- progresso ao vivo e ETA no formato operacional já usado pelo projeto;
- execução bruta no PC local/PowerShell 5.1;
- package/runner versionado, hashes e manifests fail-closed.

O `memory_cap_mib=48528` preregistrado na R1R10 é um **hard emergency cap**, não o alvo de scheduling. A R1R11 deve separar explicitamente:

- `RAM_TARGET` de scheduling ≈60%;
- hard cap fail-closed, mantido imutável se reutilizado na nova cadeia.

Qualquer mudança na fórmula ou semântica do hard cap exige preregistro novo e auditoria.

## 3. Invariantes econômicas e causais congeladas

A R1R11 não pode alterar:

- 435 células válidas;
- projeções 38.2 / 50.0 / 61.8;
- trigger 6/8/10/12/14T;
- RR 3/4/5/6/7;
- Rmax OFF/12/14/16/18/20;
- baseline 61.8 / 10T / RR5 / Rmax OFF;
- BUSINESS=`last>0 AND volume>0`;
- decisão em N, execução apenas no primeiro BUSINESS N+1;
- N+1 consumido, sem retry N+2;
- ordem física e `time_msc` preservados;
- BBO causal, inclusive quote rows anteriores ao filtro BUSINESS;
- idade BBO de entrada <=500ms;
- cutoff 18:03 e fechamento causal pós-cutoff;
- sessão nunca cruza fronteira;
- stop FIBO_ORIGIN;
- target ADJACENT_FIBO;
- trailing OFF;
- custos R$0,25 entrada + R$0,25 saída por contrato;
- slippage extra 0T;
- no-lookahead;
- seleção 2025 e isolamento de 2026;
- MacroFibo e geometria já aprovadas.

**Regra preferencial:** `minotauro_v004_core.py`, `minotauro_v004_io.py`, `minotauro_v004_metrics.py` e o contrato econômico devem permanecer byte-idênticos. Se a implementação provar que tocar o core é indispensável, isso é finding material e exige justificativa explícita + reauditoria antes de qualquer piloto.

## 4. Por que a paralelização por pregão é proibida

O runner R1R10 cria cada `SessionEngine` com os arrays do checkpoint vigente:

- `cash`;
- `hwm`;
- `maxdd`;
- `regime_min`;
- `closed_hwm`;
- `closed_maxdd`.

Após cada sessão, esses arrays são substituídos pelos estados finais da sessão e persistidos no checkpoint. Logo, sessões sucessivas formam uma cadeia temporal de estado. Executar 02/01, 03/01 e 06/01 em paralelo com o mesmo estado inicial produziria semântica diferente.

**Conclusão vinculante:** `PARALLEL_UNIT=SESSION` é proibido para a implementação R1R11 enquanto a cadeia de estado permanecer a mesma.

## 5. Unidade paralela autorizável: grupos `(p_idx,t_idx)` dentro da sessão

Os 435 cells formam **15 grupos naturais** de `(projection, trigger)`:

- 3 projeções × 5 triggers = 15 grupos;
- 12 grupos com 30 células;
- 3 grupos com 25 células;
- 145 células por projeção.

O core já declara `SessionEngine` como replay de sessão para um **chosen subset of valid cells** e mantém o estado de episódio (`active`) por `(p_idx,t_idx)`.

Portanto, a unidade atômica proposta é:

`WORK_UNIT = COMPLETE_(p_idx,t_idx)_GROUP`

Regras:

1. nunca dividir um grupo `(p_idx,t_idx)` entre workers;
2. um worker pode receber um ou mais grupos completos;
3. a atribuição de grupos deve ser determinística e registrada;
4. o worker count pode variar 2..12, mas o resultado econômico deve ser independente do worker count;
5. a ordem temporal dos ticks dentro de cada grupo permanece estritamente serial.

## 6. Arquitetura proposta

### 6.1 Coordinator single-writer

Um único processo coordinator é autoridade para:

- abrir/validar config e binding;
- fazer PROCESS_SCAN;
- escolher `GRANTED_WORKERS`;
- ler cada fonte de ticks **uma única vez**;
- manter o source hasher/prefix hasher canônico;
- publicar lotes de TickRecord em shared memory bounded;
- coordenar barriers/acks de workers;
- reunir resultados dos 15 grupos ao fim da sessão;
- reconstruir o `SessionResult` global em ordem canônica;
- executar `_commit_session` uma única vez;
- atualizar checkpoint global;
- emitir telemetry/progress/ETA;
- finalizar outputs e receipts.

Nenhum worker escreve canonical output.

### 6.2 Source broadcaster

É proibido fazer 12 workers relerem o mesmo CSV mensal. Isso multiplicaria I/O/parse e poderia ser mais lento que monowork.

A fonte deve ser parseada uma vez pelo coordinator e distribuída em **shared-memory bounded batches** para todos os workers ativos.

Requisitos:

- ordem de linhas física preservada;
- nenhum sort de ticks;
- nenhuma deduplicação;
- `ordinal`, `date_time`, `time_msc`, bid, ask, last, volume, volume_real e flags preservados;
- BUSINESS deve continuar derivado pela semântica congelada;
- batch size é parâmetro operacional, não econômico;
- memória de batch deve ser bounded e contabilizada;
- slots só podem ser reutilizados depois de ACK de todos os workers relevantes;
- worker atrasado aplica backpressure; perda de batch é proibida;
- source hashing/prefix hashing permanece no coordinator sobre os bytes físicos da fonte, não sobre representação compartilhada.

### 6.3 Workers

Cada worker:

- recebe uma lista determinística de grupos completos `(p_idx,t_idx)`;
- para cada grupo, cria `SessionEngine` com exatamente as células daquele grupo;
- recebe do coordinator os slices corretos de `cash/hwm/maxdd/regime_min/closed_*` derivados do checkpoint global;
- processa todos os batches da sessão, em ordem;
- nunca lê tick futuro fora da sequência recebida;
- ao fim da sessão retorna somente resultados de seus grupos ao coordinator;
- não grava checkpoint, sessão, receipt ou output final;
- não toma decisão de commit.

### 6.4 Estado entre pregões

O estado global só avança depois de todos os 15 grupos do pregão terem sido recebidos, validados, unidos e commitados pelo coordinator.

Fluxo obrigatório:

`GLOBAL_CHECKPOINT[n-1] -> SHARD_SLICES -> PARALLEL_SESSION[n] -> MERGE -> ATOMIC_SESSION_COMMIT -> GLOBAL_CHECKPOINT[n]`

Somente então começa a sessão `n+1`.

Isso preserva causalidade temporal entre pregões e permite paralelismo intrapregão.

## 7. Merge determinístico e byte-equivalência

Este é o principal blocker metodológico da R1R11.

As saídas por sessão precisam permanecer economicamente idênticas e, onde o contrato já exige, byte-idênticas à referência R1R9/R1R10:

- `trades.jsonl.gz`;
- `events.jsonl.gz`;
- `equity.jsonl.gz`;
- `equity_reconciliation.jsonl.gz`;
- `session_receipt.json`.

### 7.1 Proibição de concatenação ingênua

É proibido concatenar “todos os eventos do worker 1, depois worker 2...”. A execução monolítica intercala ações por tick e por estágio do engine.

### 7.2 Contrato do merger

A implementação deve definir, documentar e testar uma `CANONICAL_MERGE_KEY` para cada stream que reproduza a ordem monolítica de emissão sem alterar o conteúdo persistido.

É permitido usar **metadados internos transitórios de merge** que nunca apareçam nos arquivos canônicos, desde que:

- não influenciem decisões econômicas;
- sejam derivados apenas de informações causais já disponíveis naquele ponto;
- sejam removidos antes da serialização canônica;
- sua correção seja provada contra o oracle monowork congelado em testes sintéticos adversariais.

Se não for possível provar uma merge key total e estável para todos os caminhos (STOP, TARGET, CUTOFF, IMMEDIATE_STOP, PENDING_REJECT, crossed BBO, múltiplos sinais, open marks), a arquitetura V001 deve ser reprovada e redesenhada. **Não aceitar equivalência apenas agregada.**

### 7.3 Core congelado

Preferência forte: os metadados de merge devem ser introduzidos no adaptador/executor R1R11, não no core científico. Se o core precisar ser alterado para expor estágio/ordem de emissão, isso deve ser explicitamente classificado como mudança estrutural de risco e auditado como tal.

## 8. AUTOCPU

### 8.1 Processo de decisão

Antes de SUBMIT:

1. medir CPUs lógicas;
2. executar scan de processos;
3. bloquear duplicidade da mesma versão/out_root;
4. contar carga pesada externa relevante;
5. calcular `REQUESTED_WORKERS` com teto 12 e backlog máximo 15 grupos;
6. aplicar grant de CPU e grant de RAM;
7. registrar `GRANTED_WORKERS`;
8. se `GRANTED_WORKERS < 2`, STOP fail-closed.

O algoritmo de grant deve ser determinístico a partir do snapshot registrado e não pode esconder fallback serial.

### 8.2 RAM

- `RAM_TARGET_PERCENT=60` para scheduling;
- hard cap separado;
- memória deve contabilizar coordinator + workers + shared-memory slots controlados pelo job;
- telemetria por boundary de batch e sessão;
- ultrapassar alvo de 60% não pode ser mascarado: registrar pressão e reduzir grant em boundary seguro quando possível;
- ultrapassar hard cap segue regra fail-closed de safe-stop, sem PASS;
- o worker count pode diminuir entre sessões; isso não pode mudar resultados.

## 9. SAFE_STOP, crash e resume

### 9.1 Ctrl+C

- parent/coordinator é dono do SIGINT/KeyboardInterrupt;
- workers não devem competir pelo Ctrl+C;
- ao primeiro Ctrl+C, iniciar safe stop cooperativo;
- nenhum novo batch/session é submetido;
- se a sessão corrente não estiver pronta para commit global, descartar scratch da sessão e manter checkpoint anterior intacto;
- canonical output parcial de sessão é proibido;
- segundo Ctrl+C pode ser abortivo apenas se a política do launcher o declarar explicitamente, preservando o último checkpoint válido.

### 9.2 Crash worker

Qualquer worker perdido, exception, timeout estrutural ou ACK impossível:

- cancela a sessão corrente;
- não promove sessão;
- não altera checkpoint global;
- sai nonzero;
- resume reprocessa a sessão inteira a partir do último checkpoint selado.

### 9.3 Resume

- não depende do mesmo worker count;
- reconstrói shard assignment determinístico;
- revalida todos os hashes/binding/receipts;
- continua pelo primeiro pregão não commitado;
- outputs já commitados são imutáveis;
- orphan/pending seguem recuperação fail-closed já homologada.

## 10. Telemetria/progresso

Banner mínimo obrigatório:

- `MULTIWORK=YES`;
- `AUTOCPU=YES`;
- `CPU_LOGICAL`;
- `PROCESS_SCAN_ACTIVE_MATCHING_RUNNERS`;
- `EXTERNAL_HEAVY_WORKERS`;
- `WORK_GROUPS_TOTAL=15`;
- `REQUESTED_WORKERS`;
- `GRANTED_WORKERS`;
- `MIN_EFFECTIVE_WORKERS=2`;
- `MAX_WORKERS=12`;
- `RAM_TARGET_PERCENT=60`;
- hard cap;
- scheduler/assignment hash;
- shared-memory batch rows/slots;
- SAFE_STOP e RESUME habilitados.

Durante execução:

- worker health;
- batches publicados/acked;
- session atual;
- groups 15/15;
- bytes/rows da fonte;
- memória parent/children/aggregate;
- taxa e ETA;
- `SESSION_COMMIT` somente depois de 15/15 grupos + merge validado.

## 11. Gates de implementação antes de qualquer Pilot A real

### G1 — identidade e escopo

- delta R1R10→R1R11 contém somente executor multiwork, scheduler, merge, telemetria e testes necessários;
- nenhuma mudança econômica/causal/geometria/seleção.

### G2 — core freeze

- core/IO/metrics/preflight byte-idênticos, salvo finding explicitamente aprovado pela auditoria;
- qualquer exceção bloqueia automaticamente o Pilot A até reauditoria.

### G3 — spawn Windows

- multiprocessing com método compatível com Windows (`spawn`);
- import-safe;
- nenhuma execução recursiva de main;
- smoke real em PowerShell 5.1.

### G4 — effective multiwork

Em teste sintético suficientemente pesado:

- `GRANTED_WORKERS>=2`;
- pelo menos 2 workers simultaneamente ativos;
- evidência de overlap temporal real;
- nenhum fallback serial silencioso;
- scheduler mantém backlog alimentado quando possível.

### G5 — worker-count invariance

Mesma fixture executada com workers 2, 3, 4, 8 e 12 (quando disponíveis):

- outputs canônicos byte-idênticos;
- checkpoints byte-idênticos;
- receipts econômicos idênticos;
- apenas telemetria/scheduler metadata pode variar.

### G6 — monowork oracle differential

O parent R1R10 monowork é **oracle de teste**, não executor final.

Fixtures adversariais devem cobrir:

- BUY/SELL;
- STOP/TARGET/CUTOFF/IMMEDIATE_STOP;
- N/N+1 mesmo ms;
- BBO stale/crossed;
- pending reject;
- busy-cell;
- múltiplos sinais;
- RR/Rmax boundaries;
- 435 células;
- todos os 15 `(p,t)` groups;
- vários pregões sequenciais com estado cumulativo.

R1R11 multiwork vs R1R10 oracle: byte equivalence obrigatória para outputs econômicos.

### G7 — safe-stop/resume differential

Interromper em:

- meio de batch;
- final de batch;
- antes do merge;
- durante scratch merge;
- após merge antes do atomic commit;
- após commit antes do checkpoint seguinte;
- memória target pressure;
- hard-cap boundary.

Após resume: árvore econômica idêntica à execução limpa.

### G8 — source single-pass

Provar mecanicamente que cada arquivo fonte mensal é aberto/parseado economicamente pelo coordinator, e não uma vez por worker. Hash físico final deve continuar igual ao binding.

### G9 — single-writer

Provar que workers não têm código/caminho que publique em canonical session dirs/checkpoint/receipts.

### G10 — resource policy

- process scan PASS;
- AUTOCPU PASS;
- target RAM ~60%;
- hard cap separado;
- min 2/max 12;
- workers granted e efetivos registrados.

### G11 — package/full suite

- py_compile;
- synthetic suite;
- operational suite;
- launcher selftest;
- manifest 100%;
- no unmanifested code;
- PowerShell 5.1 runtime gate.

## 12. Pilot A R1R11

Pilot A só pode ocorrer após:

1. implementação fechada;
2. todos os gates locais PASS;
3. auditoria independente pré-piloto PASS;
4. owner authorization específica R1R11.

Pilot obrigatório:

- sessões 2025-01-02, 2025-01-03, 2025-01-06;
- 435 células;
- multiwork efetivo >=2;
- AUTOCPU;
- worker assignment registrado;
- mesma geometria e binding autenticados;
- comparação contra os 15 arquivos R1R9/R1R10 previamente auditados;
- Gate28 mismatch=0;
- outputs byte-idênticos quando aplicável;
- nenhuma autorização RUN_A automática.

## 13. RUN_A

RUN_A continua proibido até pós-piloto mecânico e gate próprio.

Para RUN_A, exigir novamente:

- MULTIWORK efetivo;
- AUTOCPU;
- 250 sessões;
- ordem temporal de commits estritamente crescente;
- same config/binding/spec/runner identities;
- resume determinístico;
- finalização econômica lossless;
- sem fallback serial.

## 14. Findings que bloqueiam implementação desta SPEC

A auditoria independente deve responder explicitamente:

1. `GROUP_SHARDING_(p,t)_SEMANTICALLY_SAFE` = YES/NO;
2. `SOURCE_SINGLE_PARSE_SHARED_MEMORY_ARCHITECTURE_SOUND` = YES/NO;
3. `CANONICAL_MERGE_BYTE_EQUIVALENCE_PROVABLE` = YES/NO;
4. `CORE_CAN_REMAIN_FROZEN` = YES/NO;
5. `AUTOCPU_POLICY_COMPLIANT` = YES/NO;
6. `SAFE_STOP_RESUME_PROTOCOL_SOUND` = YES/NO;
7. `FALSE_PASS_PATHS` = count;
8. `IMPLEMENTATION_AUTHORIZED` = YES/NO.

Qualquer NO nos itens 1–6 ou qualquer caminho de falso PASS material => `IMPLEMENTATION_AUTHORIZED=NO`.

## 15. Estado ao final da SPEC V001

```text
R1R10_EXECUTION_STATUS=BLOCKED_MONOWORK
R1R10_PILOT_EXECUTED=NO
R1R10_RUN_A_AUTHORIZED=NO
R1R11_SPEC_STATUS=READY_FOR_INDEPENDENT_AUDIT
R1R11_CODE_WRITTEN=NO
R1R11_REAL_DATA_PROCESSED=NO
NEXT_GATE=INDEPENDENT_PREIMPLEMENTATION_AUDIT
```


---

## 16. CORREÇÕES ADITIVAS V002 — C1 A C9 PREREGISTRADAS PELO OPUS 5.5

**Regra de governança desta seção:** esta V002 é a V001 com as correções C1–C9 abaixo adicionadas literalmente, sem alteração semântica das seções 1–15. Em caso de aparente conflito, esta seção 16 restringe/completa a V001; não autoriza mudança econômica, causal, geométrica ou de seleção.

### 16.1 C1 — Contrato de merge canônico

Adotar literalmente a ordem de emissão monolítica e as chaves construtivas abaixo.

**Ordem de emissão monolítica dentro de um registro** (`process_record`):

| Estágio | Condição | Emissões |
|---|---|---|
| **S1a** | primeiro registro ≥ cutoff | evento `CUTOFF_PENDING_CANCELLED` (global) |
| **S1b** | idem | evento `CUTOFF_LATCH` (global, `open_positions`) |
| **S2a** | pós-cutoff | evento `CUTOFF_FILL_DEFERRED` (global) **ou**, por idx crescente, equity `CUTOFF_CLOSE_POST_REALIZATION` |
| **S2b** | pós-cutoff | equity `OPEN_MARK` **com** campo `cutoff_pending`, por idx crescente |
| **S3** | pré-cutoff | equity `PREEXISTING_EXIT_POST_REALIZATION` ou `OPEN_MARK` **sem** `cutoff_pending`, por idx crescente |
| **S4** | BUSINESS | eventos `PENDING_REJECT`/`ENTRY`; equity `ENTRY_OPEN_MARK` e depois `IMMEDIATE_STOP_POST_REALIZATION`; append de trade — tudo por idx crescente |
| **S5a** | BUSINESS | por grupo `(p,t)` crescente e, dentro do grupo, na ordem de iteração do `set` `active`: `TARGET_ALREADY_PASSED` ou `TRIGGER`, `RR_REJECT`, `RMAX_REJECT`, `ELIGIBLE` |
| **S5b** | BUSINESS | por ordem de inserção em `eligible`: `ELIGIBLE_SKIPPED_BUSY`, `AMBIGUOUS_MULTI_SIGNAL`, `PENDING_N` |

S1/S2 e S3–S5 nunca coexistem no mesmo registro, exceto S1 seguido de S2 no registro do latch, já coberto pela ordem.

**Chaves de merge determinísticas:**

| Stream | Chave de ordenação | Observação |
|---|---|---|
| `events` | `(ordinal, estágio(event), rank_grupo(cell_ids[0]))`, com **ordem local estável** do worker dentro da chave | Cada `(ordinal, S4/S5a/S5b, grupo)` provém de um único worker, cuja ordem local deve permanecer idêntica à monolítica. |
| eventos globais | **fusão** das linhas dos workers com o mesmo `(ordinal, event)` | Afirmar igualdade dos demais campos; `cell_ids` concatenados na ordem global; `open_positions` = Σ. Worker sem células no evento não emite linha. Se nenhum emitir, não há linha. |
| `equity` | `(ordinal, estágio(event, has cutoff_pending), idx_global(cell_id))`, com ordem local estável | Em S4, a mesma célula emite `ENTRY_OPEN_MARK` e depois `IMMEDIATE_STOP_*`; a ordem local preserva isso. |
| `trades` | `(entry_ordinal, idx_global)` | O conteúdo final é o dict mutado no worker. `_commit_session` aplica os campos de cutoff do preflight como hoje. |
| `equity_reconciliation` | `idx_global` | Concatenação por bloco. |
| receipt | `trades` = Σ; arrays de estado = concatenação por bloco; `cutoff_diagnostics_runtime` = valor em `r_global` (C2); `precutoff_crossed_state_count` = valor único com igualdade afirmada (C2); prefixo = C3 | `tick_file_path` inalterado. |

Regras adicionais obrigatórias:

- Um nome de evento fora da tabela provoca **FAIL fail-closed** do merge.
- A fusão dos 3 eventos globais (`CUTOFF_PENDING_CANCELLED`, `CUTOFF_LATCH`, `CUTOFF_FILL_DEFERRED`) afirma a igualdade dos campos não fundidos.
- `CUTOFF_LATCH.open_positions` é a soma dos valores parciais dos workers.
- Pós-merge, exigir cumulativamente:
  - `ordinal` não decrescente;
  - estágio não decrescente dentro do mesmo `ordinal`;
  - `cell_ids` fundidos estritamente crescentes no índice global.
- Separação S5a/S5b é vinculante; concatenação simples por grupo é proibida.
- As linhas serializadas passam por JSON no scratch e são reemitidas pelo **mesmo `gzjson`** do parent, em gerador na ordem canônica.

### 16.2 C2 — Terminação global da sessão

- Cada worker reporta `r_g`, o registro em que o seu engine retornou `False`.
- `r_global = max(r_g)`.
- **Todos** os workers consomem e fazem ACK de todos os registros até `r_global`.
- Nenhum worker é alimentado além de `r_global`.
- Nenhum slot pode ser liberado antes de todos os workers terem consumido/ACKado até `r_global`.
- O adaptador lê `first_cutoff_bid_msc`, `first_cutoff_ask_msc` e `precutoff_crossed_state_count` após o registro `r_global`.
- Esses valores devem ser **iguais em todos os workers**; divergência → FAIL. Eles **nunca** são somados.
- O receipt usa esse valor único em `r_global`.

### 16.3 C3 — Snapshot de prefixo e escopo de lote

- O coordinator registra, para cada registro publicado, o offset físico de fim de linha.
- O coordinator retém o estado do hash (`hashlib.copy()`) no início de cada lote em uso e os bytes brutos do lote.
- O prefixo de commit é o hash exato até a linha de `r_global`, calculado a partir do estado retido, mesmo se houver leitura antecipada dentro do lote.
- **Um lote nunca atravessa a fronteira de sessão.**
- Registros de uma sessão posterior só podem ser publicados após o commit da sessão anterior.
- `_PrefixHashTracker` e a checagem de `expected_prefixes` do resume permanecem inalterados.

### 16.4 C4 — Transporte dos resultados e memória

- Cada worker grava scratch **comprimido** em `<out>/_scratch/<run_instance>/<session>/<grupo>`, fora dos diretórios canônicos, preservando sua ordem local.
- O coordinator realiza merge k-way **em streaming** e alimenta `_commit_session`/`gzjson` com geradores.
- `trades` e `equity_reconciliation`, por serem pequenos, podem ser listas.
- É **proibido** materializar listas globais de `events` ou `equity` no coordinator.
- O scratch da sessão só é apagado após commit global bem-sucedido.
- Nenhum worker publica em diretório canônico.

### 16.5 C5 — Memória agregada do job e preregistro

- `JOB_MEM = Σ PrivateUsage(coordinator + workers vivos) + bytes alocados de shared memory do job`.
- `JOB_PEAK_BOUND = max(JOB_MEM, Σ PeakPagefileUsage + shared memory)`, usado como majorante conservador.
- O hard cap operacional preregistrado para esta cadeia é **48528 MiB** e passa a ser comparado a `JOB_PEAK_BOUND` em todas as fronteiras seguras: lote, commit, mês, pré-recibo e finalize.
- `RAM_TARGET_MiB = floor(0,60 × R_MiB)`, usando o mesmo `R_MiB` registrado.
- O alvo de 60% só influencia o grant **entre sessões**; o hard cap só produz parada segura (`exit 3`), nunca PASS.
- O probe de cada filho usa `OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION)` + `K32GetProcessMemoryInfo`.
- Falha do probe em fronteira segura → `exit 2`.

### 16.6 C6 — Integridade do feed compartilhado

- Cada slot de shared memory carrega `(session, batch_seq, generation, n_records, crc32_payload)`.
- O worker exige `batch_seq = anterior + 1` e confere `generation`, `n_records` e CRC.
- Cada worker mantém `FEED_DIGEST`: SHA256 incremental sobre a codificação binária de cada `TickRecord` efetivamente entregue ao engine, até `r_global`.
- O coordinator calcula o mesmo digest sobre o feed publicado.
- Antes do merge, exigir igualdade exata entre coordinator e **todos** os workers para:
  - `FEED_DIGEST`;
  - `n_records`;
  - `business_seq`.
- Qualquer divergência descarta a sessão e termina com exit não-zero; não há promoção parcial.

### 16.7 C7 — Isolamento de crash, lock e Ctrl+C

- `run_instance = PID + timestamp`, aplicado a nomes de shared memory e à raiz do scratch.
- Lock exclusivo em `<out_root>\\RUN.lock`, criado por operação exclusiva e contendo PID/identidade da execução.
- Lock obsoleto só pode ser removido após provar que o PID não existe.
- No start: purgar `_scratch` obsoleto e recusar início se houver worker vivo do mesmo `out_root`.
- O worker ignora SIGINT **antes de qualquer trabalho**; somente o coordinator trata Ctrl+C.
- O worker verifica `multiprocessing.parent_process().is_alive()` em cada espera, com timeout, e se encerra quando o parent morrer.
- Timeout estrutural no coordinator → FAIL da sessão, exit não-zero, sem promoção.
- Resume reprocessa a sessão inteira a partir do último checkpoint global selado.

### 16.8 C8 — Gates reforçados

**G6 — manifesto de cobertura extraído do oracle monowork.** Para cada um dos **13 nomes de evento** do core congelado, o manifesto deve apresentar **exatamente uma** classificação válida:

- `COVERED`: sustentada por pelo menos uma ocorrência causal identificável em fixture válida do oracle; ou
- `STRUCTURALLY_UNREACHABLE`: sustentada por certificado formal de inalcançabilidade, reproduzível, vinculado às identidades congeladas aplicáveis e aprovado independentemente.

Para esta V003, existe exatamente uma classificação `STRUCTURALLY_UNREACHABLE` autorizada:

- `AMBIGUOUS_MULTI_SIGNAL`, pelo certificado `02_CERT_R1R11_AMBIGUOUS_MULTI_SIGNAL_UNREACHABLE_V001_20260926.md`, SHA256 `2E5F447BE75D238E583C72272002E34BBF1B0FA3D47478B7B299311AC5433EBB`.

O certificado é aplicável somente se permanecerem exatos os bindings nele declarados, incluindo core SHA256 `97F8F957300D37966913C872B7F04E498D30B0CFF68180993DB80D314B900827`, SPEC econômica SHA256 `D6D791083870015BF07BF4ABF64718D37F9136FA247D49DB31B4DC8DE2E73747`, grid SHA256 `A91A923FB38C9BFA85E157AF494B26B3ED5EBF1843F531259820CD345DCD14B1`, 435 células válidas, 15 grupos e RR mínimo 3. Qualquer divergência, certificado inaplicável ou evidência contraditória força **G6=FAIL**. Uma ocorrência causal de `AMBIGUOUS_MULTI_SIGNAL` sob bindings compatíveis invalida a aplicação do certificado e força nova auditoria.

Os outros **12 nomes de evento** continuam exigindo `COVERED`; nenhuma nova classificação `STRUCTURALLY_UNREACHABLE` pode ser criada sem prova específica e aprovação independente própria.

Além da classificação dos eventos, G6 deve provar pelo menos uma ocorrência de:

- cada um dos **5 nomes de equity**;
- cada estágio S1a–S5b;
- `CUTOFF_PENDING_CANCELLED` com células pertencentes a ≥2 workers;
- `CUTOFF_FILL_DEFERRED` com células pertencentes a ≥2 workers;
- S5a e S5b, no mesmo `ordinal`, envolvendo ≥2 grupos de workers distintos;
- `r_g` distintos entre grupos com atualização de ask/bid entre `min(r_g)` e `r_global`;
- integral de 435 células no modo piloto;
- somente baseline no modo run-a.

Ausência de qualquer cobertura obrigatória, ausência de classificação de evento, classificação duplicada, ausência de certificado exigido, certificado inválido/inaplicável ou evidência contraditória implica **G6=FAIL**.

**G7 — injeção de falhas obrigatória:**

- morte de worker no meio de lote;
- lote perdido;
- lote duplicado;
- lote fora de ordem;
- slot reutilizado com geração antiga / ACK obsoleto;
- scratch obsoleto presente no start;
- worker órfão vivo;
- Ctrl+C no coordinator.

Todos os casos devem terminar em exit não-zero e sem promoção. Após resume, a árvore econômica deve ser idêntica à execução limpa.

**G5 reforçado:** executar workers 2, 3, 4, 8 e 12 e também resumes com contagem diferente de workers em cada fronteira coberta pelo protocolo.

### 16.9 C9 — Menores m-1 a m-6

#### m-1 — Governança do documento 26

- Documento 26 declarado canônico para esta SPEC: `26_AUDIT_OPUS55_R1R10_DIFF_FINAL_20260926.md`.
- SHA256 completo do documento canônico: `181CF8D919149AE032D75A114F405041189B1C72D50B0CD41326D36B63AF7FA2`.
- `R_MiB` medido no owner bootstrap da cadeia R1R10: **64704 MiB**.
- Hard cap preregistrado e preservado para a transição R1R11: **48528 MiB**.
- O documento `26_AUDIT_OPUS55_R1R10_DIFF_CONSOLIDATED_20260926.md` SHA `E55AAD44…` permanece evidência histórica, mas não é a autoridade documental desta SPEC V002.

#### m-2 — SIGINT

- No Windows, o worker ignora SIGINT antes de qualquer trabalho.
- Somente o coordinator trata Ctrl+C.

#### m-3 — Critério quantitativo de paralelismo efetivo

- Na fixture pesada preregistrada, multiwork com **4 workers** deve atingir vazão **≥ 1,5×** a vazão do oracle monowork.
- Abaixo de 1,5× → **G4=FAIL**, mesmo que exista sobreposição temporal.

#### m-4 — Momento do grant e estimativa de RAM

- `GRANTED_WORKERS` só pode mudar em **fronteira de sessão**.
- Na primeira sessão, a estimativa usa reserva preregistrada por worker derivada do snapshot registrado.
- Nas sessões seguintes, usa o pico medido da sessão anterior como entrada determinística da decisão de grant.
- O grant nunca participa de hash econômico e nunca muda outputs canônicos.

#### m-5 — Layout binário de `TickRecord` em shared memory

- `ordinal`: int64;
- `time_msc`: int64;
- preços: int64;
- `volume`: float64 bit-exato;
- `volume_real`: float64 bit-exato;
- `date_time`: UTF-8 com comprimento explícito;
- `session`: UTF-8 com comprimento explícito;
- `flags`: int.

Teste obrigatório de ida e volta bit a bit contra `parse_tick_fields`.

#### m-6 — Process scan e probe de filhos sem dependência nova

- Implementação somente com stdlib.
- Process scan Windows via `ctypes` + `CreateToolhelp32Snapshot`.
- Probe de memória de filhos via `OpenProcess` + `K32GetProcessMemoryInfo`.
- Nenhuma dependência de terceiros nova é autorizada.

### 16.10 Fechamento da V002

```text
R1R11_SPEC_V002_DELTA=V001_PLUS_C1_TO_C9_ONLY
OPUS55_V001_ARCHITECTURE_APPROVED_IN_PRINCIPLE=YES
SPEC_V002_REAUDIT_REQUIRED=NO_IF_DELTA_EXACT
CORE_IO_METRICS_PREFLIGHT_FREEZE=REQUIRED
MONOWORK_FINAL_ACCEPTABLE=NO
MULTIWORK=REQUIRED
AUTOCPU=REQUIRED
REAL_DATA_PROCESSING_AUTHORIZED=NO
PILOT_A_AUTHORIZED=NO
RUN_A_AUTHORIZED=NO
NEXT_STEP=IMPLEMENTATION_AND_INTERNAL_GATES
NEXT_EXTERNAL_AUDIT=PREPILOT_IMPLEMENTATION_ONLY
```

---

## 17. DELTA NORMATIVO V004 — STAGING DE COMMIT DELEGADO, TRANSAÇÃO E CUSTÓDIA

### 17.0 Governança e escopo do delta

Esta seção transforma a V003 em V004 e **substitui somente** os pontos
explicitamente enumerados abaixo.

Motivo: a revisão pré-implementação do desenho V003R3 confirmou que a V003
vigente exige fisicamente que o `coordinator` faça o merge k-way e alimente
`_commit_session`/`gzjson`; portanto, processos separados de staging por stream
não eram compatíveis com C4.

A V004 autoriza essa delegação física de maneira explícita, sem alterar:

- core econômico;
- causalidade;
- geometria;
- grid;
- trigger;
- RR;
- Rmax;
- C2;
- C3;
- C6;
- C8/G6;
- certificado `AMBIGUOUS_MULTI_SIGNAL`;
- `heavy_cycles=1200`;
- `G4_WORKERS=4`;
- `G4_THRESHOLD=1.5x`;
- fronteira end-to-end de G4;
- oracle;
- byte identity;
- serializer canônico final;
- compresslevel canônico final;
- SAFE_STOP/resume;
- proibição de fallback serial silencioso.

A alteração normativa é restrita a:

1. §6.1 — autoridade do coordinator versus execução física delegada;
2. §16.1 — localização física do merge, sem alterar chaves/fusões/ordem;
3. §16.4 — transporte e staging;
4. §16.5 — escopo de memória incluindo helpers;
5. §16.7 — lifecycle/crash incluindo helpers;
6. G7/G9/G10/G11 — cobertura específica da nova cadeia de staging;
7. protocolo transacional de commit/checkpoint;
8. custódia/TOCTOU;
9. persistência final de trades e sidecars operacionais.

Qualquer interpretação além desse delta é proibida e exige nova versão da SPEC.

### 17.1 §6.1 V004 — coordinator como autoridade e publisher canônico único

Substitui, para V004, as obrigações de §6.1 incompatíveis com staging delegado.

O `coordinator` continua sendo a **única autoridade do job** e o **único
publisher canônico**.

Somente o coordinator pode:

- abrir/validar config e bindings;
- fazer PROCESS_SCAN;
- escolher `GRANTED_WORKERS`;
- ler a fonte de ticks;
- manter source hash/prefix hash;
- publicar batches;
- decidir `r_global`;
- validar `FEED_DIGEST`;
- validar scratch/sidecars/stage;
- autorizar ou abortar commit;
- criar/selar o pending canônico;
- publicar atomicamente a sessão;
- atualizar checkpoint global;
- emitir receipt/control-plane final;
- limpar scratch após commit seguro.

A execução física de merge/reemissão dos quatro streams econômicos pode ser
delegada a **commit-stage helpers subordinados**, sob estas condições:

- helpers não executam `SessionEngine`;
- helpers não leem dados-fonte de mercado;
- helpers não decidem economia;
- helpers não alteram checkpoint;
- helpers não escrevem receipt canônico;
- helpers não publicam no namespace canônico;
- helpers só escrevem em `_scratch/<run_instance>/<session>/_canonical_stage/`;
- o coordinator valida integralmente o produto antes da promoção.

Assim, `single-writer` em V004 significa:

> **um único publisher/autoridade canônica: o coordinator; helpers podem produzir
> artefatos transitórios não canônicos em scratch, mas nunca publicar estado
> econômico ou control-plane.**

### 17.2 C1 V004 — semântica de merge preservada; execução física delegável

Todas as chaves, estágios S1a–S5b, fusões globais e invariantes de §16.1
permanecem literais.

A única mudança é de **local de execução física**:

- `events`, `equity`, `trades` e `equity_reconciliation` podem ter seu merge
  físico realizado pelo helper do respectivo stream;
- o helper deve usar exatamente as chaves/fusões definidas em C1;
- um nome de evento desconhecido continua FAIL;
- os três eventos globais continuam sujeitos às mesmas fusões;
- a ordem final continua byte-equivalente ao oracle;
- o coordinator valida a prova de ordem e os hashes antes da publicação.

Nenhuma semântica de C1 é relaxada.

### 17.3 C4 V004 — scratch, trades finais, sidecars e staging

#### 17.3.1 Scratch autoritativo

Cada worker grava scratch comprimido por grupo em:

`<out>/_scratch/<run_instance>/<session>/<group>/`

Para V004:

- `events`: scratch comprimido obrigatório;
- `equity`: scratch comprimido obrigatório;
- `trades`: scratch comprimido obrigatório com o **conteúdo final do trade**;
- `equity_reconciliation`: scratch comprimido obrigatório.

A V004 usa scratch para os quatro streams, de forma que cada stage helper tenha
uma única forma de custódia/entrada e não dependa de listas globais.

É proibido transportar grandes listas de trades pelo Pipe.

#### 17.3.2 Momento de persistência de trades

Um trade não pode ser persistido no scratch final no instante da entrada.

O worker só sela `trades` depois de a sessão/grupo terminar e depois de todas as
mutações econômicas do trade terem sido concluídas.

O scratch final de trades deve conter o mesmo conteúdo econômico final que o
parent entregaria a `_commit_session`.

Qualquer enriquecimento puramente de commit/cutoff que no parent seja aplicado
por `_commit_session` deve:

- ser derivado pelo coordinator a partir dos mesmos valores congelados;
- ser entregue ao helper como metadata imutável de commit;
- ser aplicado por uma função determinística do adaptador V004;
- reproduzir byte a byte o output do parent em testes diferenciais.

#### 17.3.3 Ordenação de trades

Cada scratch local de trades deve ser selado em ordem:

`(entry_ordinal, idx_global)`

O helper global realiza k-way merge pela mesma chave.

Empate inesperado da chave total => FAIL fail-closed.

#### 17.3.4 Sidecar operacional

É permitido sidecar transitório para `events`, `equity` e `trades`.

O JSON scratch continua sendo a **única fonte autoritativa de conteúdo**.

Cada entrada do sidecar deve corresponder exatamente a uma linha do scratch e
conter no mínimo:

- `line_no` começando em zero;
- `uncompressed_offset_start`: offset do primeiro byte UTF-8 do payload JSON;
- `uncompressed_offset_end_exclusive`: offset imediatamente após o `LF` que
  termina a linha no domínio **descomprimido**;
- merge key completa;
- `local_seq`;
- SHA256 dos bytes JSON da linha sem o terminador físico;
- identidade de `group`, `session`, `run_instance`, `stream` e `generation`.

Regras:

- sidecar e scratch têm a mesma contagem de registros;
- primeiro `uncompressed_offset_start = 0`;
- para linhas consecutivas, `next.start = previous.end_exclusive`;
- o último `end_exclusive` deve ser exatamente o número total de bytes
  descomprimidos do JSONL;
- `line_no` é estritamente crescente sem lacuna;
- SHA por linha é calculado sobre o payload JSON **sem o LF terminal** e deve
  conferir;
- nenhuma linha pode ser omitida ou duplicada;
- sidecar divergente => FAIL;
- sidecar nunca entra em hash econômico ou output canônico;
- sidecar é descartado após commit seguro.

#### 17.3.5 Commit-stage helpers

V004 fixa até quatro helpers, um por stream:

- `trades`;
- `events`;
- `equity`;
- `equity_reconciliation`.

Cada helper:

1. recebe somente paths/manifests já validados e metadata imutável;
2. valida identidade do scratch/sidecar;
3. executa merge streaming do seu stream;
4. reemite objetos pelo **mesmo `gzjson` canônico**;
5. usa os mesmos `sort_keys`, separators, `mtime=0` e `compresslevel=6`;
6. escreve primeiro em arquivo `.partial`;
7. fsynca/fecha;
8. promove somente dentro do namespace stage para `.sealed`;
9. emite manifest de stage com SHA256, bytes, rows, ordem e bindings;
10. entra em `SEALED_WAIT` sem handles de escrita abertos.

Nenhum helper escreve canonical session dir, checkpoint ou receipt.

### 17.4 TOCTOU e identidade física

#### 17.4.1 Scratch sealing

Ao terminar:

1. worker fecha todos os handles de scratch/sidecar;
2. worker envia `FINAL_SCRATCH_MANIFEST`;
3. worker entra em `SEALED_WAIT`;
4. coordinator coleta/prova memória enquanto o worker ainda está vivo;
5. coordinator valida SHA256/bytes/rows e identidade física;
6. coordinator envia `EXIT_ACK`;
7. worker encerra;
8. coordinator confirma que não há writer vivo para aquele scratch.

Identidade física Windows deve registrar, quando disponível por stdlib/ctypes:

- volume serial;
- file index / file ID;
- size;
- timestamps necessários ao diagnóstico;
- SHA256.

#### 17.4.2 Consumo pelos helpers

Cada helper:

- verifica SHA/rows/file identity antes de consumir;
- calcula `CONSUMED_SHA256` sobre os bytes efetivamente lidos;
- exige igualdade com o manifest selado;
- verifica novamente identidade/size ao terminar.

Coordinator revalida scratch após a saída dos helpers antes de autorizar commit.

Divergência em qualquer etapa => FAIL sem promoção.

#### 17.4.3 Stage sealing

Após produzir stage:

1. helper fecha o `.sealed`;
2. envia manifest;
3. entra em `SEALED_WAIT`;
4. coordinator coleta memória enquanto helper está vivo;
5. coordinator envia `EXIT_ACK`;
6. helper encerra;
7. coordinator recalcula SHA/bytes/rows/order proof;
8. somente então o stage pode entrar na transação canônica.

Nenhum arquivo stage pode ser promovido enquanto existir helper capaz de
escrevê-lo.

### 17.5 C5 V004 — memória agregada incluindo commit helpers

Para V004, em qualquer momento:

`JOB_PROCESS_SET = coordinator + economic_workers_alive + stage_helpers_alive`

`JOB_MEM = Σ PrivateUsage(JOB_PROCESS_SET) + shared_memory_allocated_bytes`

`JOB_PEAK_BOUND_CURRENT = max(JOB_MEM, Σ PeakPagefileUsage(JOB_PROCESS_SET) + shared_memory_allocated_bytes)`

O coordinator mantém ainda:

`JOB_PEAK_BOUND_RUN = max(JOB_PEAK_BOUND_RUN_anterior, JOB_PEAK_BOUND_CURRENT)`

`JOB_PEAK_BOUND_RUN` é monotônico e preserva picos de workers/helpers que já
encerraram. O hard cap é comparado ao `JOB_PEAK_BOUND_RUN`.

Regras adicionais:

- helper entra no agregado desde o spawn até exit confirmado;
- buffer/queue de staging deve ser bounded e contabilizado;
- nenhum helper é excluído por não ser economic worker;
- antes de permitir a saída de worker/helper, coordinator coleta seu
  `PeakPagefileUsage` e o persiste no telemetry/control-plane;
- falha de probe em boundary => exit 2;
- hard cap 48528 MiB continua bloqueante;
- target 60% continua separado do hard cap;
- stage helper não altera `GRANTED_WORKERS`;
- se os quatro helpers preregistrados não puderem ser executados com segurança,
  não há fallback serial silencioso: a sessão para fail-closed.

### 17.6 C7 V004 — lifecycle, parent-death, Ctrl+C e cleanup

Todo worker e todo stage helper:

- ignora SIGINT antes de qualquer trabalho;
- verifica `parent_process().is_alive()` em waits com timeout;
- encerra sem publicar se o parent morrer;
- pertence ao mesmo `run_instance`;
- possui PID/role/session/stream registrados pelo coordinator.

Somente o coordinator trata Ctrl+C.

Em Ctrl+C, timeout ou falha parcial:

- nenhuma sessão incompleta é publicada;
- helpers sobreviventes recebem cancelamento/terminate controlado;
- scratch/stage da sessão corrente permanece não canônico;
- checkpoint não avança;
- resume aplica o protocolo transacional de §17.7.

Process scan deve detectar também helpers órfãos do mesmo `out_root`.

### 17.7 Protocolo transacional V004 — pending, journal, atomic session e checkpoint

Esta seção substitui qualquer sequência ambígua que possa sugerir receipt ou
checkpoint avançado antes do commit atômico.

#### 17.7.1 Autoridades

- os quatro `.jsonl.gz` staged são dados econômicos candidatos;
- `session_receipt.json` canônico continua produzido pelo coordinator;
- o checkpoint global só avança **depois** da publicação atômica da sessão;
- um journal control-plane não canônico é permitido para recovery.

#### 17.7.2 Sequência obrigatória

0. `out_root`, `_scratch`, `_commit_journal`, pending e diretório final da
   sessão devem residir no **mesmo filesystem/volume**; se não, FAIL antes do
   processamento da sessão.
1. validar 15/15 grupos, feed, scratch, sidecars e stages;
2. confirmar hard-cap boundary com todos os helpers ainda observáveis;
3. encerrar helpers após `EXIT_ACK`;
4. revalidar stages após a saída;
5. construir deterministicamente **em memória**:
   - bytes exatos do `session_receipt.json` que serão gravados no pending;
   - snapshot completo do `checkpoint-next`;
   sem publicar nenhum dos dois;
6. criar exclusivamente:
   `<out_root>/_commit_journal/<session>.<run_instance>.json`;
7. journal contém:
   - hash do checkpoint anterior;
   - hash e conteúdo/snapshot do checkpoint-next;
   - hashes/bytes/rows esperados dos quatro streams staged;
   - SHA256/bytes esperados do receipt já construído em memória;
   - session/run_instance;
8. fsync journal e seu diretório;
9. criar pending canônico exclusivo da sessão;
10. mover os quatro stage files verificados para pending **por rename no mesmo
    volume**, sem reserialização; copy fallback é proibido nesta revisão;
11. gravar no pending exatamente os bytes de receipt pré-construídos;
12. validar pending completo contra journal;
13. fsync arquivos e diretório pending;
14. publicar a sessão por operação atômica de diretório/rename conforme o
    protocolo existente;
15. somente após a sessão final existir e validar, atualizar checkpoint por
    atomic replace usando o snapshot `checkpoint-next` do journal;
16. fsync checkpoint e diretório aplicável;
17. marcar/remover journal;
18. limpar scratch/stage da sessão;
19. somente então iniciar a próxima sessão.

É proibido checkpoint avançado sobre sessão ausente.

#### 17.7.3 Recovery por ponto de falha

No startup, **antes de purgar `_scratch`**, o coordinator deve primeiro
reconciliar `_commit_journal`. Isso é obrigatório para não destruir a única
evidência capaz de fechar a janela sessão-publicada/checkpoint-antigo.

- **Antes da publicação atômica da sessão:** checkpoint antigo permanece;
  pending incompleto é descartado após validação de run_instance e sessão é
  reprocessada inteira.
- **Depois da publicação da sessão e antes do checkpoint:** journal + sessão
  final são validados; se todos os hashes conferirem e checkpoint ainda for o
  anterior esperado, coordinator aplica `checkpoint-next` do journal por atomic
  replace, sem reprocessar nem reescrever a sessão.
- **Crash durante atomic checkpoint replace:** no resume, o checkpoint só pode
  ter exatamente o hash anterior ou o hash `checkpoint-next`. Se for o anterior,
  aplicar o next; se for o next, seguir para cleanup; qualquer terceiro estado
  => FAIL-CLOSED.
- **Depois do checkpoint e antes do cleanup:** validar sessão + checkpoint
  contra journal e concluir somente cleanup.
- **Sessão final existe, checkpoint antigo e journal ausente:** FAIL-CLOSED;
  não inferir nem reconstruir silenciosamente estado.
- **Checkpoint avançado com sessão final ausente:** FAIL-CLOSED.
- **Journal inconsistente, sessão divergente, checkpoint inesperado ou hashes
  incompatíveis:** FAIL-CLOSED; nenhuma correção automática.

O journal é control-plane transitório e não altera os cinco arquivos canônicos
da sessão.

### 17.8 Byte identity e `gzjson`

V004 não autoriza novo serializer.

Cada stream staged deve passar pelo mesmo `gzjson` canônico do parent, com os
mesmos parâmetros.

Proibido:

- concatenar bytes JSON finais sem passar pelo contrato V004;
- trocar gzip implementation;
- trocar compresslevel;
- alterar `sort_keys`/separators;
- alterar `mtime`;
- aceitar equivalência apenas semântica.

Antes de owner G4, fixtures sintéticas devem demonstrar byte identity completa
dos cinco arquivos canônicos contra o oracle aplicável.

### 17.9 Gates V004 adicionais

Além de G1–G11, a implementação V004R1 deve fechar:

#### V4-A — trade finality

- trade scratch contém estado final;
- nenhum payload grande de trades no Pipe;
- enrichment de commit/cutoff byte-idêntico ao parent;
- contagem e ordem exatas.

#### V4-B — sidecar bijection

- 1:1 scratch↔sidecar;
- offsets/line_no/hash válidos;
- missing/duplicate/reordered sidecar => FAIL.

#### V4-C — delegated merge semantics

- helpers reproduzem C1;
- evento global multi-grupo fundido corretamente;
- unknown event => FAIL;
- S5a/S5b preservados.

#### V4-D — stage isolation

- helper nunca escreve namespace canônico;
- coordinator é único publisher;
- qualquer write-attempt canônico por helper deve ser bloqueado em teste.

#### V4-E — transaction/recovery

Injetar falha em cada fronteira:

- antes do journal;
- depois do journal;
- durante pending;
- depois de pending completo;
- imediatamente antes da publicação atômica;
- depois da publicação antes do checkpoint;
- durante atomic checkpoint replace;
- depois do checkpoint antes do cleanup.

Após recovery, árvore econômica e checkpoint devem ser idênticos à execução
limpa.

#### V4-F — TOCTOU

Injetar:

- scratch alterado após seal;
- sidecar alterado;
- file ID trocado;
- stage truncado;
- stage substituído;
- SHA divergente;
- helper órfão;
- helper morto durante merge;
- helper morto após seal antes do probe;
- Ctrl+C em staging.

Todos => exit não-zero e nenhuma promoção parcial.

#### V4-G — aggregate resources

- workers e helpers aparecem no process registry;
- peaks coletados antes de exit;
- falha de probe => exit 2;
- hard cap => safe stop/exit 3;
- nenhuma queda silenciosa para commit serial.

#### V4-H — byte differential

Para fixtures sintéticas adversariais, os cinco arquivos canônicos devem ser
byte-idênticos ao oracle.

### 17.10 G4 V004 — fundamento, orçamento e regra de desenvolvimento

A finalidade de G4 permanece:

> provar ganho líquido end-to-end de vazão; overlap isolado não basta.

A justificativa histórica ex ante de exatamente `1,5x` permanece classificada
como **INSUFFICIENT**. Isso não muda o gate.

Justificativa prospectiva para **manter** o gate, sem reescrever a história:

- `1,5x` = redução de 33,333% do wall frente ao monowork;
- com quatro workers, `1,5/4 = 37,5%` é eficiência paralela nominal relativa ao
  ideal de quatro workers;
- os `62,5%` complementares **não** são orçamento provado de overhead nem
  fração serial admissível;
- o limiar continua suficientemente material para impedir “multiwork no papel”.

#### 17.10.1 Evidência de referência

Referência principal existente:

- oracle `15.4133320 s`;
- V003R2 `17.1191955 s`;
- target de referência `10.2755547 s`.

Perfil macro V003R2:

- total `18.3376825 s`;
- commit `12.6457962 s`;
- finish `1.7614004 s`;
- feed `3.4621498 s`.

Custos observados relacionados à mudança V004:

- Pipe RESULT `1.2957391 s`;
- decode dentro de RESULT ~`0.9993 s`;
- sort de results/trades `0.4360792 s`;
- CPU thread por stream:
  - trades `4.437500 s`;
  - events `4.578125 s`;
  - equity `5.640625 s`;
  - reconciliation ~`0`;
- CPU oracle por stream:
  - trades `3.859375 s`;
  - events `2.203125 s`;
  - equity `2.750000 s`.

Esses números são evidência de gargalos, **não prova de tempo futuro**.

#### 17.10.2 Status de atingibilidade

`G4_ATTAINABILITY_PREIMPLEMENTATION=UNPROVEN`

A V004 não declara que `1,5x` será atingido.

A implementação V004R1 é autorizada apenas como **experimento sintético
one-shot preregistrado**, porque G4 existe justamente para medir a propriedade
de performance que não pode ser provada estaticamente.

Nenhum dado real é autorizado por essa permissão.

#### 17.10.3 Objetivo de engenharia não vinculante ao PASS

Para desenvolvimento, preregistrar:

`ENGINEERING_DESIGN_OBJECTIVE = 0.95 × (oracle / 1.5)`

Usando apenas a referência principal histórica:

`ENGINEERING_REFERENCE_OBJECTIVE = 9.7617770 s`

Esse valor:

- não substitui o gate;
- não permite escolher oracle favorável;
- não permite tuning pós-hoc;
- não é alegado como tempo demonstrado.

O PASS de G4 continua exclusivamente:

`speedup = paired_oracle_wall / candidate_wall >= 1.5`

na fixture e fronteira congeladas.

#### 17.10.4 Regra one-shot

V004R1 terá uma única implementação arquitetural conforme esta SPEC.

Se owner G4 falhar:

- G5–G11 param;
- não ajustar threshold;
- não ajustar heavy_cycles;
- não escolher nova amostra favorável;
- não fazer microtuning automático;
- produzir diagnóstico causal;
- nova tentativa exige revisão versionada V004R2 ou V005 com hipótese causal
  preregistrada antes da nova medição.

### 17.11 Governança de auditoria independente

Por decisão do owner para preservar créditos:

- a aprovação independente pré-implementação é substituída nesta etapa por
  auditoria interna documentada;
- isso autoriza somente **código + testes sintéticos**;
- nenhum dado real pode ser processado;
- Pilot A permanece proibido;
- Run-A permanece proibido.

Se V004R1 fechar integralmente todos os gates sintéticos, incluindo G4, G5–G11
e V4-A..V4-H, então deve ocorrer **uma única auditoria independente final**
antes de qualquer Pilot A.

Essa auditoria final deve receber:

- SPEC V004;
- delta V003→V004;
- implementação física;
- todos os receipts G1–G11;
- V4-A..V4-H;
- owner G4;
- evidências de byte identity;
- fault injection;
- resource telemetry;
- transação/recovery;
- hashes/manifests;
- histórico V003R1/V003R2 e findings B1–B6.

### 17.12 Fechamento V004

```text
R1R11_SPEC_VERSION=V004
PARENT_SPEC_V003_SHA256=552401C071384B921FDF4358EB3CBEB71441E5C8D2500B24183204425CFD91C6
CORE_CHANGE=NO
ECONOMIC_CHANGE=NO
G4_THRESHOLD=1.5X_UNCHANGED
G4_BOUNDARY=UNCHANGED
HEAVY_CYCLES=1200_UNCHANGED
DELEGATED_STAGE_HELPERS=AUTHORIZED_NONCANONICAL_ONLY
CANONICAL_PUBLISHER=COORDINATOR_ONLY
TRADE_SCRATCH=REQUIRED
SIDECAR=AUTHORIZED_NONAUTHORITATIVE
TRANSACTION_JOURNAL=REQUIRED_CONTROL_PLANE
BYTE_IDENTITY=REQUIRED
REAL_DATA_PROCESSING_AUTHORIZED=NO
PILOT_A_AUTHORIZED=NO
RUN_A_AUTHORIZED=NO
SYNTHETIC_IMPLEMENTATION_V004R1_AUTHORIZED=YES
FINAL_INDEPENDENT_AUDIT_REQUIRED_BEFORE_PILOT_A=YES
```

