# CODEX — IMPLEMENTAR R1R11 V004R1

APLICATIVO: Codex
MODELO: GPT-6 Astra
RACIOCÍNIO: High

## Autoridade
Leia integralmente, nesta ordem:
1. 01_SPEC_MINOTAURO_R1R11_MULTIWORK_AUTOCPU_V004.md
2. 02_WORK_ASTRA_V003R3_FAIL_FINDINGS_TRANSCRIPT.md
3. 03_DELTA_V003_TO_V004_MATRIX.md
4. 04_INTERNAL_DEEP_AUDIT_V004.md
5. 05_PARECER_PREIMPLEMENTACAO_REVISADO_V004R1.md
6. parent V003 e demais fontes incluídas no pacote.

## Estado do repositório
Retome o repositório atual do owner.
NÃO reset, checkout, stash, clean destrutivo ou reversão de alterações locais.
Preserve V003R1/V003R2 e evidências anteriores.

## Escopo
Implementar UMA revisão V004R1 estritamente sintética.

NÃO:
- alterar core;
- alterar economia;
- alterar G4=1,5x;
- alterar heavy_cycles=1200;
- alterar oracle;
- alterar fronteira de timing;
- processar dados reais;
- executar Pilot A;
- executar Run-A;
- executar homologação owner completa.

Pode executar somente testes sintéticos pontuais indispensáveis ao desenvolvimento.

## Arquitetura obrigatória

### A. Trades em scratch
- persistir somente trade final;
- nenhum grande payload de trades no Pipe;
- local sort `(entry_ordinal, idx_global)`;
- cutoff/commit enrichment determinístico e diferencial.

### B. Sidecar
- 1:1 com scratch;
- line_no/offsets/key/local_seq/line_sha;
- JSON scratch continua autoritativo.

### C. Quatro stage helpers
- trades/events/equity/reconciliation;
- escrevem só em `_scratch/.../_canonical_stage`;
- mesmo gzjson;
- nunca escrevem canonical dir/receipt/checkpoint.

### D. Coordinator
- sole canonical publisher;
- valida scratch/stage;
- transaction journal;
- pending;
- atomic session publish;
- checkpoint depois;
- cleanup por último.

### E. TOCTOU
Implementar sealing/manifests/file identity/consumed hash/revalidation conforme §17.4.

### F. Resources
- workers + helpers em JOB_MEM/JOB_PEAK_BOUND;
- SEALED_WAIT até peak probe;
- probe failure exit2;
- cap exit3;
- sem fallback serial.

### G. Recovery
Implementar exatamente §17.7 e fault injection V4-E/V4-F.

## Performance
Não faça tuning pós-hoc.
Não invente atalho benchmark-only.
Não degrade oracle.

G4 continua:
paired oracle / candidate >= 1.5.

Preregistrar no novo G1:
- SPEC V004 SHA;
- heavy_cycles=1200;
- workers=4 no G4;
- batch_rows=32;
- shared_slots=1;
- stage_helpers=4;
- final gzjson unchanged;
- engineering objective factor 0.95 (diagnóstico, não gate).

## Testes
Além de G1-G11, criar V4-A..V4-H.

Os testes devem provar:
- final trade scratch;
- sidecar bijection;
- merge C1;
- helper isolation;
- transaction recovery em todas as fronteiras;
- TOCTOU fault injection;
- helper memory peaks;
- byte identity.

## Execução mecânica
Não rode G1-G11 completos no Codex.
Prepare launcher PowerShell 5.1 para owner executar localmente.

## Entrega
Entregar ZIP versionado V004R1 contendo:
- código completo;
- SPEC V004;
- changelog V003R2->V004R1;
- implementation receipt;
- testes;
- launcher owner;
- internal targeted-test report;
- SHA256SUMS;
- nenhum dado real.

Se qualquer requisito for incompatível tecnicamente, pare FAIL-CLOSED e entregue
diagnóstico. Não altere a SPEC por conta própria.
