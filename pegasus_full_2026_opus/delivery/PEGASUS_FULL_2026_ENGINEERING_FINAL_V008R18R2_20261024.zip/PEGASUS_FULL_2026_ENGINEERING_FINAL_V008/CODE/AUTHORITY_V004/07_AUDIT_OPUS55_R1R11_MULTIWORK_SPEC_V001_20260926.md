# AUDITORIA PRÉ-IMPLEMENTAÇÃO OPUS 5.5 — MINOTAURO R1R11 MULTIWORK/AUTOCPU — SPEC V001

**Objeto:** `01_SPEC_MINOTAURO_R1R11_MULTIWORK_AUTOCPU_V001.md` (SHA `1B0345FB…2CBACE9`).

**Handoff:** `HANDOFF_OPUS55_MINOTAURO_R1R11_MULTIWORK_SPEC_V001_20260926.zip`, SHA256 `B08870EE…AFEAF93`.
- CRC OK, 23 entradas, 0 duplicatas.
- `SHA256SUMS_HANDOFF.txt`: 20/20 OK, sem arquivo fora do manifesto.

**Regime:** independente, adversarial e fail-closed.
- **Não houve:** código escrito, runner, execução, leitura de dados de mercado ou autorização de owner.
- **Houve apenas:** leitura integral da SPEC, da evidência 02, dos 16 arquivos de `SOURCE_R1R10/` e do documento 26, mais verificação de hashes.
- **Método:** análise estática do core linha a linha, com enumeração de todos os 15 pontos de emissão de eventos (13 nomes) e de todos os pontos de emissão de equity.

---

```text
OPUS55_R1R11_MULTIWORK_SPEC_AUDIT=FAIL
SOURCE_PACKAGE_INTEGRITY=PASS
PARENT_MONOWORK_DIAGNOSIS=PASS
GROUP_SHARDING_PT_SEMANTICALLY_SAFE=YES
CROSS_GROUP_SHARED_ECONOMIC_STATE=NONE
SOURCE_SINGLE_PARSE_SHARED_MEMORY_ARCHITECTURE_SOUND=YES
CANONICAL_MERGE_BYTE_EQUIVALENCE_PROVABLE=YES
CORE_CAN_REMAIN_FROZEN=YES
AUTOCPU_POLICY_COMPLIANT=YES
RAM_TARGET_60_AND_HARD_CAP_SEPARATION=PASS
SINGLE_WRITER_PROTOCOL=PASS
SAFE_STOP_RESUME_PROTOCOL=FAIL
WORKER_COUNT_INVARIANCE_TESTABLE=YES
FALSE_PASS_PATHS=4
CRITICAL_FINDINGS=0
MAJOR_FINDINGS=8
MINOR_FINDINGS=6
IMPLEMENTATION_AUTHORIZED=NO
REAL_DATA_PROCESSING_AUTHORIZED=NO
PILOT_A_AUTHORIZED=NO
RUN_A_AUTHORIZED=NO
REQUIRED_CORRECTIONS=1) Contrato de merge canônico explícito: tabela de estágios por evento, 3 eventos globais com regra de fusão (CUTOFF_LATCH soma open_positions), separação 5a/5b, chaves por stream (§4); 2) Terminação global da sessão r_global=max(r_g), todos os workers alimentados até r_global, diagnósticos compartilhados tomados em r_global e nunca somados; 3) Snapshot de prefixo na linha exata de r_global sob leitura antecipada, lotes restritos a uma sessão; 4) Transporte de resultados por scratch em streaming e merge k-way alimentando o gzjson inalterado, sem SessionResult global materializado; 5) Hard cap e alvo de 60% medidos no agregado do job (Σ private commit dos processos + bytes de shared memory), com o cap 48528 preregistrado para essa métrica; 6) Invariantes de integridade de alimentação: seq/geração por slot, FEED_DIGEST por worker igual ao do coordinator, igualdade dos contadores de mercado entre workers; 7) Isolamento de crash: run_instance em scratch e shared memory, lock de execução, autoencerramento do worker na morte do pai, purga de scratch no start, SIGINT ignorado nos workers; 8) G6 com manifesto de cobertura de caminhos e G7 com injeção de falhas (morte de worker, lote perdido, duplicado ou fora de ordem, ACK obsoleto, scratch obsoleto, órfão); 9) Menores m-1 a m-6 (§3.2)
NEXT_STEP=Emitir SPEC V002 = V001 + correções 1–9 literais, sem outra alteração, conferir internamente item a item e implementar; próxima auditoria externa somente a pré-piloto da implementação (SPEC §12.3)
```

**Determinação complementar:** a arquitetura V001 está **aprovada em princípio**. O FAIL decorre de lacunas de especificação, não de impossibilidade.
- Existe um caminho concreto e testável para a equivalência byte a byte, descrito no §4.
- Uma SPEC V002 que seja **exatamente** V001 + correções 1–9, sem outra mudança, **não requer nova auditoria de SPEC**. A conformidade pode ser conferida internamente, item a item.
- Qualquer outra alteração na V002 exige nova auditoria.

---

## 1. Respostas às perguntas obrigatórias

| Pergunta | Resposta | Fundamento |
|---|---|---|
| `(p_idx,t_idx)` completo é boundary seguro? | **SIM** | Todo estado econômico é por célula (`pending_*`, `pos_*`, `realized`, `hwm`, `max_dd`, `regime_min`, `closed_*`, contadores) ou por grupo (`active[(pi,ti)]`, core l.257). As decisões de um grupo só leem o próprio `active_set` e os próprios `idx` (l.590-664). |
| Há estado compartilhado entre grupos que invalide a proposta? | **NÃO** (econômico: NONE) | O estado compartilhado é **só de mercado**: BBO, `bid/ask_msc`, `prev_business`, `business_seq`, `cutoff_applied`, `first_cutoff_*`, `precutoff_crossed_state_count` e as grades por projeção. Todos são função pura do prefixo de ticks, do D1 e do cutoff, e não dependem de decisões de células. Cada worker os reproduz identicamente **se receber todos os registros da sessão**. Três **linhas de evento** e dois **diagnósticos** são globais e exigem regra de merge (MAJ-1, MAJ-2), sem que haja estado econômico cruzado. |
| Single-reader + broadcast preserva ordem, hashing e no-lookahead? | **SIM, em princípio** | A ordem é preservada se lotes sequenciados forem consumidos em ordem. O hashing permanece no coordinator (`io` l.91). O no-lookahead é propriedade do engine, que só vê o `rec` corrente. Faltam o snapshot de prefixo sob leitura antecipada (MAJ-3) e as invariantes de integridade (MAJ-6). |
| O merger pode reproduzir byte a byte os 4 `.jsonl.gz` + o receipt? | **SIM, em princípio** | Prova construtiva no §4. A V001 **não** a contém (MAJ-1 a MAJ-4). |
| O core pode ficar byte-idêntico? | **SIM** | Tudo o que o merge precisa é derivável do conteúdo persistido (`event`, `ordinal`, `cell_ids`/`cell_id`, presença de `cutoff_pending`) ou de atributos públicos lidos pelo adaptador após cada `process_record` (`first_cutoff_*`, `precutoff_crossed_state_count`). |
| Workers 2–12, AUTOCPU, alvo 60% e hard cap separado são coerentes? | **SIM**, com MAJ-5 | Com 15 grupos para 2–12 workers, a atribuição determinística é possível. O alvo de 60% fica abaixo do cap. A métrica do cap da R1R10, porém, é **por processo** (`memory` l.89, `GetCurrentProcess`), e isso não protege um job multiprocesso. |
| Checkpoint, single-writer, safe-stop e resume bastam? | Checkpoint e single-writer: **SIM**. Safe-stop e resume: **NÃO**, até MAJ-7 | O commit atômico (`.pending` + `os.replace`) e o checkpoint único cobrem o commit parcial. Faltam isolamento de scratch e shared memory por execução, trava contra órfãos e o SIGINT no Windows. |
| Mudar o número de workers no resume muda os outputs? | **NÃO**, se C1–C4 forem cumpridas | Os outputs passam a ser função pura de (checkpoint, fluxo de registros, chave de merge), e a chave não depende da atribuição. É testável no G5. |
| Caminhos descobertos (falso PASS, deadlock etc.)? | **SIM**, 4 de falso PASS e 1 de deadlock | Ver §2 e §3. |
| A estratégia de gates diferenciais basta antes do piloto? | **NÃO**, como escrita | O G6 não exige prova de cobertura de caminhos, e o G7 não injeta falhas de transporte nem de órfãos (MAJ-8). |

---

## 2. Caminhos de falso PASS (4)

| # | Caminho | Por que escaparia aos gates da V001 | Fecha com |
|---|---|---|---|
| FP-1 | Erro de merge num caminho raro (ex.: `CUTOFF_FILL_DEFERRED` com BBO cruzado no cutoff; `CUTOFF_PENDING_CANCELLED` com pendências em vários grupos; 5a/5b de grupos distintos no mesmo registro) | O G6 lista temas, mas não prova que cada caminho ocorreu com ≥2 grupos ativos no mesmo registro. O piloto cobre só 3 sessões. O erro passaria no `run-a` sem oráculo. | C1 + C8 |
| FP-2 | `cutoff_diagnostics_runtime` (`first_cutoff_*`) tomado de um worker que parou no seu `r_g` < `r_global` | Só diverge se houver atualização de bid/ask pós-cutoff entre `r_g` e `r_global`, o que pode não ocorrer no piloto. É exatamente a classe do O-6 do audit 25. | C2 |
| FP-3 | Lote perdido, duplicado ou fora de ordem que não altere as sessões do piloto | A V001 proíbe a perda, mas não define mecanismo de detecção. No `run-a`, a economia sairia silenciosamente errada. | C6 |
| FP-4 | Scratch obsoleto ou worker órfão de uma execução anterior misturado ao merge do resume | A V001 manda "descartar scratch", mas não vincula scratch nem shared memory à instância de execução. | C7 |

**Deadlock identificado:**
- O §6.2 da SPEC libera slots após o ACK "dos workers relevantes".
- Se um worker parar de consumir no seu `r_g`, o coordinator, que ainda precisa alimentar os grupos pendentes até `r_global`, espera ACK indefinidamente, ou libera slots com semântica indefinida.
- **Fecha com C2:** todos os workers consomem até `r_global`.

---

## 3. Findings

### 3.1 MAJOR (8)

| # | Finding | Evidência | Correção |
|---|---|---|---|
| **MAJ-1** | **O contrato de merge está ausente.** A V001 só enuncia a exigência (§7.2). Três eventos são **globais**, com `cell_ids` de vários grupos numa única linha: `CUTOFF_PENDING_CANCELLED` (core l.671); `CUTOFF_LATCH` com `range(self.n)` e `open_positions` = contagem global (l.674-677); `CUTOFF_FILL_DEFERRED` (l.688). Um worker produziria linhas parciais, e a byte-identidade exige **fusão com soma**, não ordenação. Além disso, `_process_episodes` tem dois laços: 5a por grupo (l.590-635) e 5b por célula elegível (l.637). A concatenação por grupo inverteria a ordem 5a/5b entre grupos. | core l.590-677, 688 | **C1** (§4) |
| **MAJ-2** | **A terminação da sessão não está definida.** `process_record` retorna `any(cutoff_pending)` (l.768), e o runner comita no primeiro `False` (runner l.663-668). Por grupo, o `False` ocorre em `r_g`; o monólito para em `r_global = max_g r_g`, porque `cutoff_pending` é monotônico após o latch. Os diagnósticos do receipt (`first_cutoff_*`, l.757/762) dependem do ponto de parada, e `precutoff_crossed_state_count` (l.773) é replicado em cada worker: **somá-lo** multiplicaria o valor pelo número de workers. | core l.738-768, 773; runner l.660-668 | **C2** |
| **MAJ-3** | **O snapshot de prefixo sob leitura antecipada não está definido.** O `session_receipt.json` grava `tick_prefix_bytes`/`sha256` no momento do commit (runner l.382). O hasher é atualizado por linha antes do `yield` (`io` l.91/116), logo o prefixo canônico = bytes até a **linha de `r_global`**. Um coordinator que publica lotes à frente teria o hasher adiantado: o receipt divergiria e o resume (`_session_prefix_expectations`) quebraria. A V001 também não proíbe lotes que atravessem sessões. | runner l.202-232, 382; `io` l.87-116 | **C3** |
| **MAJ-4** | **O transporte de resultados é incompatível com o hardening de memória da R1R10.** O §6.1 manda "reconstruir o SessionResult global" no coordinator. Na sessão 2025-01-06 do piloto (23,5 M linhas de equity), isso somaria as listas dos workers, os buffers de pickle e a lista global: cerca de 2× o pico monowork. | SPEC §6.1, §6.3; audit 25 §5 | **C4** |
| **MAJ-5** | **O escopo do hard cap é indefinido.** O probe da R1R10 mede só o próprio processo (`memory` l.89) e o cap compara `observed_peak_bytes` de um processo (l.170). Com N workers, cada processo pode ficar abaixo de 48528 MiB e o agregado exceder a RAM. A SPEC l.60 exige preregistro para mudança de semântica do cap, e a passagem para multiprocesso **é** essa mudança. | `memory` l.86-110, 170; SPEC l.55-60, 245-253 | **C5** (preregistro feito aqui) |
| **MAJ-6** | **Não há invariante que detecte falha de transporte.** A V001 proíbe perda de lote e exige ACK, mas não define sequência, geração de slot nem checagem cruzada. Lote perdido, duplicado, fora de ordem, ACK obsoleto ou leitura rasgada do slot passam sem detecção se não alterarem as sessões do piloto (FP-3). | SPEC §6.2 | **C6** |
| **MAJ-7** | **O isolamento de crash é insuficiente.** Faltam: vínculo scratch/shared memory ↔ instância de execução; detecção de morte do pai pelo worker; trava de execução (definida só como "lock contra duplicidade", sem semântica); purga no start. No Windows, `CTRL_C_EVENT` atinge **todos** os processos do console, e os workers recebem `KeyboardInterrupt` a menos que o ignorem explicitamente. | SPEC §9 | **C7** |
| **MAJ-8** | **A suficiência dos gates diferenciais não é demonstrável.** O G6 enumera fixtures, mas não exige **manifesto de cobertura** medido no oráculo. O G7 não injeta falhas de transporte, de órfão nem de scratch obsoleto. | SPEC §11 G6/G7 | **C8** |

### 3.2 MINOR (6)

| # | Finding | Correção |
|---|---|---|
| m-1 | **Governança.** Existem dois documentos "26" distintos: `26_AUDIT…FINAL` (SHA `181CF8D9…`, fórmula 0,85, cap 48528) e `26_AUDIT…CONSOLIDATED` (SHA `E55AAD44…`, fórmula 0,75). A SPEC herda o 48528. | A V002 deve declarar o documento 26 canônico (`181CF8D9…`) e o `R_MiB` medido. |
| m-2 | **SIGINT.** No Windows, o spawn não isola o grupo de console. | O worker ignora SIGINT antes de qualquer trabalho; só o coordinator trata Ctrl+C (integrado em C7). |
| m-3 | **"Paralelismo efetivo" não tem critério quantitativo.** O G4 só pede sobreposição temporal. | Preregistrar uma razão mínima de vazão na fixture pesada: multiwork com 4 workers ≥ 1,5× a vazão monowork do oráculo. Abaixo disso → FAIL do G4. |
| m-4 | **Grant de workers.** O momento das mudanças e a estimativa de RAM da primeira sessão estão indefinidos. | O grant muda **somente em fronteira de sessão**. A estimativa de RAM é uma função determinística do snapshot registrado (reserva preregistrada por worker na primeira sessão e, depois, o pico medido da sessão anterior). O grant nunca entra em hash econômico. |
| m-5 | **Codificação dos `TickRecord` em shared memory** não especificada. | Layout binário fixo: int64 para `ordinal`, `time_msc` e preços; float64 bit-exato para `volume` e `volume_real`; bytes UTF-8 com comprimento para `date_time`/`session`; `flags` int. Teste de ida e volta bit a bit contra `parse_tick_fields`. |
| m-6 | **Process scan e probe de filhos** sem restrição de dependência. | Somente stdlib (ctypes: `CreateToolhelp32Snapshot` e `OpenProcess` + `K32GetProcessMemoryInfo` dos PIDs filhos), mantendo a regra de nenhuma dependência nova. |

---

## 4. Prova construtiva de merge byte-equivalente (base de C1–C4)

**Fatos verificados:**
- Os 15 grupos são **blocos contíguos** do índice global de células, e `valid_cells()` está ordenado por `(p,t,r,m)`: 12 grupos × 30 + 3 grupos × 25 = 435.
- Logo, "ordem crescente de índice global" ≡ "ordem de grupo, depois índice local".
- Todo laço do core que itera células usa `np.flatnonzero` crescente ou a ordem de inserção de `group_cells`, que também é crescente.

**Ordem de emissão monolítica dentro de um registro** (`process_record`, l.738-785):

| Estágio | Condição | Emissões |
|---|---|---|
| **S1a** | primeiro registro ≥ cutoff | evento `CUTOFF_PENDING_CANCELLED` (global) |
| **S1b** | idem | evento `CUTOFF_LATCH` (global, `open_positions`) |
| **S2a** | pós-cutoff | evento `CUTOFF_FILL_DEFERRED` (global) **ou**, por idx crescente, equity `CUTOFF_CLOSE_POST_REALIZATION` |
| **S2b** | pós-cutoff | equity `OPEN_MARK` **com** campo `cutoff_pending`, por idx crescente |
| **S3** | pré-cutoff | equity `PREEXISTING_EXIT_POST_REALIZATION` ou `OPEN_MARK` **sem** `cutoff_pending`, por idx crescente |
| **S4** | BUSINESS | eventos `PENDING_REJECT`/`ENTRY`; equity `ENTRY_OPEN_MARK` e depois `IMMEDIATE_STOP_POST_REALIZATION`; append de trade — tudo por idx crescente |
| **S5a** | BUSINESS | por grupo `(p,t)` crescente e, dentro do grupo, na ordem de iteração do `set` `active`: `TARGET_ALREADY_PASSED` ou `TRIGGER`, `RR_REJECT`, `RMAX_REJECT`, `ELIGIBLE` |
| **S5b** | BUSINESS | por ordem de inserção em `eligible`: `ELIGIBLE_SKIPPED_BUSY`, `AMBIGUOUS_MULTI_SIGNAL`, `PENDING_N` |

S1/S2 e S3–S5 nunca coexistem no mesmo registro, exceto S1 seguido de S2 no registro do latch, que já está coberto pela ordem.

**Chaves de merge (determinísticas e derivadas só do conteúdo persistido e da tabela estática):**

| Stream | Chave de ordenação | Observação |
|---|---|---|
| `events` | `(ordinal, estágio(event), rank_grupo(cell_ids[0]))`, com **ordem local estável** do worker dentro da chave | Cada `(ordinal, S4/S5a/S5b, grupo)` provém de um único worker, cuja ordem local é idêntica à monolítica, porque o histórico de operações do `set` de cada grupo é local ao grupo. |
| eventos globais | **fusão** das linhas dos workers com o mesmo `(ordinal, event)` | Afirmar a igualdade dos demais campos; `cell_ids` concatenados na ordem global; `open_positions` = Σ. Worker sem células no evento não emite linha. Se nenhum emitir, não há linha. |
| `equity` | `(ordinal, estágio(event, has cutoff_pending), idx_global(cell_id))`, com ordem local estável | Em S4, a mesma célula emite `ENTRY_OPEN_MARK` e depois `IMMEDIATE_STOP_*`; a ordem local preserva isso. |
| `trades` | `(entry_ordinal, idx_global)` | O conteúdo final é o dict mutado no worker. `_commit_session` aplica os campos de cutoff do preflight como hoje. |
| `equity_reconciliation` | `idx_global` | Concatenação por bloco. |
| receipt | `trades` = Σ; arrays de estado = concatenação por bloco; `cutoff_diagnostics_runtime` = valor em `r_global` (C2); `precutoff_crossed_state_count` = valor único com igualdade afirmada (C2); prefixo = C3 | `tick_file_path` inalterado. |

**Serialização:**
- As linhas serializadas passam por JSON uma vez no scratch e são reemitidas pelo **mesmo** `gzjson` (runner l.91-99), alimentado por um gerador na ordem canônica.
- O round-trip JSON é identidade para todos os tipos emitidos pelo core: int, str, bool, None, list, float via `repr` e dicts de chave str. Verifiquei cada argumento `extra` dos 15 pontos de emissão de eventos e dos pontos de emissão de equity.
- Os bytes produzidos são, portanto, os mesmos do monólito.

**Contraprova exigida (G6):** o oráculo monowork R1R10 roda sobre o **mesmo** fluxo de registros, e os 5 arquivos por sessão precisam ser iguais byte a byte, com manifesto de cobertura (C8).

---

## 5. Correções exigidas (texto preregistrado para a SPEC V002)

- **C1 — Contrato de merge.**
  - Adotar literalmente as tabelas do §4.
  - Um nome de evento fora da tabela provoca **FAIL fail-closed** do merge.
  - A fusão dos 3 eventos globais afirma a igualdade dos campos não fundidos.
  - Adicionar invariantes pós-merge:
    - `ordinal` não decrescente;
    - estágio não decrescente dentro do ordinal;
    - `cell_ids` fundidos estritamente crescentes no índice global.
- **C2 — Terminação global.**
  - Cada worker reporta `r_g`, o registro em que o seu engine retornou `False`.
  - `r_global = max r_g`.
  - **Todos** os workers consomem e fazem ACK de todos os registros até `r_global`. Nenhum é alimentado além de `r_global`, e nenhum libera slot antes disso.
  - O adaptador lê `first_cutoff_bid_msc`, `first_cutoff_ask_msc` e `precutoff_crossed_state_count` após o registro `r_global`.
  - Esses valores devem ser **iguais em todos os workers** (divergência → FAIL). Nunca são somados.
  - O receipt usa esse valor único.
- **C3 — Prefixo e escopo de lote.**
  - O coordinator registra, por registro publicado, o offset de fim de linha.
  - Ele retém o estado do hash (`hashlib` `copy()`) no início de cada lote em uso e os bytes brutos do lote.
  - O prefixo de commit = hash até a linha de `r_global`, computado a partir do estado retido.
  - **Lote nunca atravessa sessão.** Registros de uma sessão posterior só são publicados após o commit da sessão anterior.
  - O `_PrefixHashTracker` e a checagem de `expected_prefixes` do resume permanecem inalterados.
- **C4 — Transporte e memória.**
  - Os workers gravam scratch **comprimido** em `<out>/_scratch/<run_instance>/<session>/<grupo>`, fora dos diretórios canônicos, em ordem local.
  - O coordinator faz merge k-way em streaming e passa geradores ao `_commit_session`/`gzjson`.
  - Trades e reconciliação, que são pequenos, podem ser listas.
  - Proibido materializar `events` ou `equity` globais.
  - O scratch é apagado após o commit.
- **C5 — Métrica do cap (preregistro).**
  - `JOB_MEM = Σ PrivateUsage(coordinator + workers vivos) + bytes alocados de shared memory do job`.
  - `JOB_PEAK_BOUND = max(JOB_MEM, Σ PeakPagefileUsage + shared memory)`, um majorante conservador.
  - O hard cap = **48528 MiB** (valor e fórmula do 26 canônico) passa a ser comparado a `JOB_PEAK_BOUND` em todas as fronteiras seguras: lote, commit, mês, pré-recibo e finalize.
  - `RAM_TARGET_MiB = floor(0,60 × R_MiB)`, com o mesmo `R_MiB` registrado. Se `R_MiB = 57.092` (coerente com 48528 pela fórmula 0,85), o alvo ≈ 34.255 MiB.
  - O alvo só afeta o grant entre sessões. O cap só produz parada segura (exit 3), nunca PASS.
  - O probe de cada filho usa `OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION)` + `K32GetProcessMemoryInfo`. Falha do probe em fronteira → exit 2.
- **C6 — Integridade de alimentação.**
  - Cada slot carrega `(session, batch_seq, generation, n_records, crc32_payload)`.
  - O worker exige `batch_seq` = anterior + 1 e confere o CRC.
  - Cada worker mantém um `FEED_DIGEST` (SHA256 incremental sobre a codificação binária de cada `TickRecord` efetivamente passado ao engine, até `r_global`). O coordinator calcula o mesmo digest sobre o que publicou.
  - **Igualdade exata** de `FEED_DIGEST`, `n_records` e `business_seq` entre todos os workers e o coordinator é pré-condição do merge. Divergência → sessão descartada, exit ≠ 0.
- **C7 — Crash e isolamento.**
  - `run_instance` = PID + timestamp, aplicado a nomes de shared memory e à raiz do scratch.
  - Lock de execução exclusivo em `<out_root>\RUN.lock` (criação exclusiva, PID gravado). Lock obsoleto só é removido se o PID não existir.
  - No start: purgar todo `_scratch` e recusar se houver processo worker vivo do mesmo `out_root`.
  - O worker ignora SIGINT e se encerra se o pai morrer (`multiprocessing.parent_process().is_alive()` a cada espera, com timeout).
  - O coordinator trata timeout estrutural como FAIL da sessão, com exit ≠ 0.
  - O resume reprocessa a sessão inteira a partir do checkpoint.
- **C8 — Gates.**
  - **G6 — manifesto de cobertura** extraído do **oráculo**. Deve provar ≥1 ocorrência de:
    - cada um dos 13 nomes de evento e dos 5 nomes de equity;
    - cada estágio S1a–S5b;
    - `CUTOFF_PENDING_CANCELLED` e `CUTOFF_FILL_DEFERRED` com células de ≥2 workers;
    - 5a e 5b de ≥2 grupos de workers distintos no mesmo `ordinal`;
    - `r_g` distintos entre grupos, com atualização de ask/bid entre `min r_g` e `r_global`;
    - integral de 435 células (modo piloto) e só baseline (modo run-a).
  - Se faltar qualquer item → G6 FAIL.
  - **G7 — injeção de falhas:**
    - morte de worker no meio de lote;
    - lote perdido, duplicado ou trocado de ordem;
    - slot reutilizado com geração antiga;
    - scratch obsoleto presente no start;
    - worker órfão vivo;
    - Ctrl+C no coordinator.
    - Todos devem terminar em exit ≠ 0 sem promoção e, após o resume, com árvore idêntica à limpa.
  - **G5:** workers 2, 3, 4, 8 e 12, além de resume com contagem diferente em cada fronteira.
- **C9 — Menores:** adotar m-1 a m-6 conforme §3.2.

---

## 6. Itens aprovados sem ressalva

- **Diagnóstico monowork:** correto. As sessões formam uma cadeia pelos 6 arrays do checkpoint (runner l.643/657). `PARALLEL_UNIT=SESSION` está corretamente proibido.
- **Unidade `(p,t)` completa:** correta. A separação de células de um mesmo grupo seria de fato insegura, porque `active` é compartilhado dentro do grupo.
- **Single-writer, commit atômico, `.pending`/órfão, checkpoint imutável dos commits já feitos:** reaproveitáveis sem alteração.
- **Core, `io`, `metrics` e `preflight` congelados:** viáveis. Nada no §4 requer tocar o core.
- **Proibição de fallback serial, STOP se o grant < 2, banner, spawn/import-safe e smoke em PS 5.1:** adequados.
- **Critério do piloto:** 15 arquivos contra a referência R1R9/R1R10, mais GATE28 com mismatch 0. Mantido, e constitui o oráculo físico final.

---

## 7. Limites

- **Natureza da prova:** a auditoria é estática, e a prova do §4 é construtiva, não executada. A demonstração executável é obrigação do G6/G7.
- **Desempenho real:** não é estimado. A vazão efetiva depende do parse no coordinator, que é serial, e do custo por registro replicado em cada worker. O m-3 torna isso mensurável.
- **Documento 26 do handoff:** não é o parecer `E55AAD44…`. Foi tratado como fonte de contexto (cap 48528), e a sua canonicidade cabe ao owner (m-1).
