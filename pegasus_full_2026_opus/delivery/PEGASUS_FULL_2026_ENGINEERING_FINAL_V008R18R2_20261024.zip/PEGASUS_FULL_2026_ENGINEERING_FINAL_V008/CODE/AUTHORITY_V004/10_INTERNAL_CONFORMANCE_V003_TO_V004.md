# CONFORMANCE INTERNA V003 -> V004

PARENT_V003_SHA256=552401C071384B921FDF4358EB3CBEB71441E5C8D2500B24183204425CFD91C6

Método:
- parent V003 preservado integralmente;
- antes da seção 17, somente título e STATUS foram alterados;
- toda mudança normativa adicional está contida em §17;
- nenhuma linha de C2/C3/C6/C8 ou m-3 histórica foi editada in-place.

Resultado:
V003_PREFIX_PRESERVATION=PASS
V004_DELTA_LOCALIZED_TO_SECTION_17=YES
G4_1_5_TEXT_IN_PARENT_PRESERVED=YES
HEAVY_CYCLES_CHANGE=NO
CORE_CHANGE=NO
ECONOMIC_CHANGE=NO
