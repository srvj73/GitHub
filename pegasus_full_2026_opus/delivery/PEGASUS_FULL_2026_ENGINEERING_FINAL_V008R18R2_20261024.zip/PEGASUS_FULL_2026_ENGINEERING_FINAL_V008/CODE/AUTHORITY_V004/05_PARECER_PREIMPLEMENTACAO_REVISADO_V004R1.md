# PARECER PRÉ-IMPLEMENTAÇÃO REVISADO — R1R11 V004R1

## Status
INTERNAL_OWNER_REVIEW=PASS_FOR_SYNTHETIC_IMPLEMENTATION_ONLY
INDEPENDENT_FINAL_APPROVAL=DEFERRED_UNTIL_ALL_SYNTHETIC_GATES_PASS

## Problema resolvido

O desenho V003R3 anterior falhou porque delegava fisicamente o merge/gzjson sem
autoridade normativa. V004 torna essa delegação explícita e limitada a stage
não canônico.

## Desenho construtivo

### Compute
Mantém exatamente 15 grupos econômicos completos, source single-pass e workers
2..12.

### Result custody
Events/equity/trades finais são scratch comprimido por grupo.
Trades não atravessam Pipe como lista grande.

### Merge metadata
Sidecar não autoritativo, bijetivo com scratch.

### Commit stage
Quatro helpers independentes por stream produzem arquivos canônicos-em-bytes,
mas ainda não canônicos-em-localização, dentro de scratch/stage.

### Publish
Coordinator revalida e é o único que move para pending, produz receipt,
publica sessão e atualiza checkpoint.

### Recovery
Commit journal externo aos cinco outputs fecha a janela entre atomic session
publish e global checkpoint update.

## Performance

Não se afirma PASS prospectivo.

Evidência:
- current V003R2 = 0,9003538x;
- commit = 68,9607% do macro wall;
- RESULT + decode + sort são custos medidos;
- quatro writer threads atuais sofrem GIL/contenda.

Hipótese causal V004:
- retirar trades grandes do Pipe reduz finish;
- quatro processos eliminam GIL comum entre streams;
- sidecars reduzem trabalho de merge-key;
- coordinator deixa de executar os quatro writers.

O objetivo de engenharia é 95% do limite do G4, mas o único PASS é o owner G4
pareado >=1,5x.

## Kill criteria
- qualquer byte mismatch;
- qualquer write canônico por helper;
- qualquer falha de TOCTOU;
- qualquer pico não coletado;
- qualquer recovery divergente;
- qualquer fallback serial;
- G4 <1,5x.

Qualquer kill criterion => STOP, sem dados reais.
