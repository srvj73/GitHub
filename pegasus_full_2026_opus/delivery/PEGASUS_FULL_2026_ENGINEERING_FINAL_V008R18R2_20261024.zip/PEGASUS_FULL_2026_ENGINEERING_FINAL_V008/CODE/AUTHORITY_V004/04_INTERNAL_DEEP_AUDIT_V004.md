# AUDITORIA INTERNA PROFUNDA — SPEC V004 / AUTORIZAÇÃO SINTÉTICA

## Veredito

R1R11_V004_INTERNAL_DEEP_AUDIT=PASS_FOR_SYNTHETIC_IMPLEMENTATION_ONLY
SOURCE_BASIS=PASS
B1_NORMATIVE_CONFLICT=CLOSED_BY_EXPLICIT_V004_DELTA
B2_TRANSACTION_PROTOCOL=PASS_ON_SPEC
B3_TOCTOU_PROTOCOL=PASS_ON_SPEC
B4_TRADE_AND_SIDECAR_CONTRACT=PASS_ON_SPEC
B5_HELPER_RESOURCE_CONTRACT=PASS_ON_SPEC
B6_PERFORMANCE_ATTAINABILITY=UNPROVEN_BY_DESIGN
G4_THRESHOLD=1.5X_UNCHANGED
G4_BOUNDARY=UNCHANGED
CORE_CHANGE=NO
ECONOMIC_CHANGE=NO
REAL_DATA_PROCESSING_AUTHORIZED=NO
PILOT_A_AUTHORIZED=NO
RUN_A_AUTHORIZED=NO
SYNTHETIC_IMPLEMENTATION_AUTHORIZED=YES
FINAL_INDEPENDENT_AUDIT_REQUIRED_BEFORE_PILOT_A=YES

## 1. Finding principal

A V003 não podia acomodar o desenho anterior porque C4 vinculava a execução
física do merge/gzjson ao coordinator. Portanto, tentar “reinterpretar
single-writer” teria sido erro. A V004 corrige isso explicitamente.

## 2. Single-writer versus delegated staging

A V004 separa:
- autoridade/publicação canônica — exclusivamente coordinator;
- preparação/merge/serialização de stage não canônico — helpers subordinados.

Nenhum helper pode publicar sessão, receipt ou checkpoint. Assim a mudança é
normativa, explícita e auditável, em vez de interpretação implícita.

## 3. Transação

O protocolo V004 elimina checkpoint antecipado:
journal -> pending completo -> publicação atômica da sessão -> checkpoint atomic
replace -> cleanup.

A janela session-publicada/checkpoint-antigo é recuperável pelo journal,
sem alterar os cinco arquivos canônicos.

## 4. TOCTOU

O contrato exige:
- writers fechados;
- manifests;
- file identity;
- SHA before/consumed/after;
- helper SEALED_WAIT;
- peak probe antes do exit;
- revalidação após exit;
- zero promoção com writer vivo.

Isso fecha a classe de mutação acidental/concorrente dentro do próprio job.
O threat model não inclui processo hostil externo com privilégios equivalentes.

## 5. Trades

O V003R2 ainda devolvia grande payload de trades. V004 exige que o worker só
persista o trade após seu estado final econômico. Cutoff/commit enrichment
continua determinístico e diferencialmente byte-testado.

## 6. Sidecars

O sidecar não substitui JSON scratch. A bijeção por line_no, offsets e SHA da
linha impede omissão/duplicação silenciosa. Sidecar divergente é FAIL.

## 7. Memória

A métrica passa a cobrir economic workers e stage helpers. O handshake de
SEALED_WAIT impede perder o PeakPagefileUsage do helper antes da coleta.

## 8. Performance — correção metodológica

A evidência existente NÃO demonstra que V004 atingirá G4.

Isso não é convertido artificialmente em PASS.

A autorização aqui é somente para UMA implementação sintética preregistrada,
porque o próprio G4 é a medição empírica vinculante.

A arquitetura tem mecanismo causal plausível:
- remover grande trade payload/decode/sort do coordinator;
- separar os quatro serializers/mergers em processos com GIL independente;
- sidecars reduzem trabalho de descoberta de merge key;
- publicação continua serial/atômica apenas no coordinator.

Mas `G4_ATTAINABILITY_PREIMPLEMENTATION=UNPROVEN`.

## 9. Regra contra tuning pós-hoc

Uma falha de G4 em V004R1 encerra a tentativa.
Nenhum ajuste automático ou busca de parâmetro é autorizado após observar o
resultado. Nova tentativa exige versão nova e hipótese causal preregistrada.

## 10. Conclusão

A V004 está suficientemente especificada para implementação sintética.
Não está aprovada para mercado real.

O próximo uso de auditoria independente deve ocorrer somente se toda a cadeia
sintética fechar, imediatamente antes do Pilot A.
