# MINOTAURO PERF NEXT V002 — scheduler utilization delta

BASE=MINOTAURO_PERF_NEXT_V001
PURPOSE=reduce observed worker starvation without changing economics, C1/cutoff, event order, canonical bytes, SAFE_STOP, resume or oracle.

## New evidence
Task Manager snapshot on 2026-09-28 showed 24 logical CPUs, Python process group with 21 processes using about 7% CPU while system CPU was about 13%, memory 28% and disk 5%. This is a point-in-time observation, not a throughput benchmark.

## Structural finding
The current scheduler has 15 fixed work groups but caps workers at 12. The deterministic round-robin assignment therefore gives 2 groups to three workers and 1 group to nine workers. Every 32-row feed batch waits for ACK from every worker before the next batch, so the 2:1 assignment skew is on the barrier critical path. The stream path also retains one outstanding watermark.

## V002 delta
- candidate max/requested workers: 15, still gated by logical CPU, aggregate RAM budget, external heavy workers and the 15-group ceiling;
- default batch_rows: 256, reducing coordinator/pipe/barrier frequency 8x relative to 32; 32/64/128 remain available for differential qualification;
- with grant=15, deterministic assignment becomes exactly one of the 15 groups per economic worker;
- SHARED_SLOTS remains 1; no speculative feed-ahead is introduced because it could cross an unknown global terminal point;
- hot-path incremental order/open-floor/FINISH and verifier digest-only changes from V001 are retained.

## RAM_TARGET
Unchanged: 60% soft productive target, 48,528 MiB hard cap, job-aggregate memory telemetry. FIRST_WORKER_RESERVE_MIB remains unchanged; V002 does not fabricate a lower first-session reserve without target evidence.

## Status
IMPLEMENTED_FOR_FUTURE_QUALIFICATION_ONLY. No user-PC execution or benchmark was performed while the current FULL is active.
