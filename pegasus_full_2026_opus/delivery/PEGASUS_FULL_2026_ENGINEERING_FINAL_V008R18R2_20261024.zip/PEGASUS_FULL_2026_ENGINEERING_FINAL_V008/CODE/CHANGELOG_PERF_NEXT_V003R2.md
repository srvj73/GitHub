# MINOTAURO PERF NEXT V003R2

BASE=V003R1
PURPOSE=recovery-lifecycle and observability hardening without economic changes.

CHANGES:
- session-owned stream helper registry;
- exact registry retirement after child death;
- stale scratch reconciliation in same resume attempt;
- 30-second operational heartbeat with required status fields;
- isolated successor target root.

NOT_CHANGED:
economics, C1, parser, source order, W15/B256, shared_slots=1, final canonical publisher.
