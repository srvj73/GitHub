from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

PACKAGE=Path(__file__).resolve().parent
REQUIRED_SPEEDUP=1.667
PAIRS=3


def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest().upper()


def tree(root: Path) -> dict[str,str]:
    return {p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file()}


def economic(root: Path) -> dict[str,str]:
    x=tree(root/'sessions'); x['CHECKPOINT.json']=sha(root/'CHECKPOINT.json'); return x


def run_case(inputs: Path, out: Path, role: str, workers: int, log: Path) -> dict:
    args=[sys.executable,'-X','utf8','-B',str(PACKAGE/'r1r11_fixtures.py'),
          '--inputs',str(inputs),'--out',str(out),'--role',role,'--workers',str(workers),
          '--integral','all','--only','heavy']
    with log.open('w',encoding='utf-8') as f:
        f.write('COMMAND '+json.dumps(args)+'\n'); f.flush()
        t=time.perf_counter(); p=subprocess.run(args,cwd=PACKAGE,stdout=f,stderr=subprocess.STDOUT,
            env={**os.environ,'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'})
        elapsed=time.perf_counter()-t; f.write(f'EXIT_CODE={p.returncode}\nWALL_SECONDS={elapsed}\n')
    if p.returncode!=0: raise RuntimeError(f'DEV_BENCH_CHILD_FAIL role={role} log={log}')
    return json.loads((out/'SYNTHETIC_EXECUTION.json').read_text(encoding='utf-8'))


def main() -> None:
    ap=argparse.ArgumentParser(); ap.add_argument('--out',required=True); ns=ap.parse_args()
    out=Path(ns.out).resolve(); out.mkdir(parents=True,exist_ok=True)
    if any(out.iterdir()): raise RuntimeError('DEV_BENCH_OUT_MUST_BE_EMPTY')
    inputs=out/'synthetic_inputs'
    from r1r11_fixtures import generate
    generate(inputs)
    heavy=json.loads((inputs/'FIXTURES.json').read_text(encoding='utf-8'))['heavy']['session']
    results=[]
    for i in range(1,PAIRS+1):
        oracle=out/f'pair_{i}_oracle'; candidate=out/f'pair_{i}_candidate'
        a=run_case(inputs,oracle,'oracle',4,out/f'pair_{i}_oracle.log')
        b=run_case(inputs,candidate,'candidate',4,out/f'pair_{i}_candidate.log')
        oa=float(a['case_timings'][heavy]); cb=float(b['case_timings'][heavy]); speed=oa/cb
        equal=economic(oracle)==economic(candidate)
        row={'pair':i,'oracle_seconds':oa,'candidate_seconds':cb,'speedup':speed,
             'required_speedup':REQUIRED_SPEEDUP,'heavy_byte_equal':equal,
             'pass':bool(speed>=REQUIRED_SPEEDUP and equal)}
        results.append(row); print('DEV_BENCH_PAIR '+json.dumps(row,sort_keys=True),flush=True)
    ok=all(r['pass'] for r in results)
    receipt={'R1R11_V005R1_DEV_BENCH':'PASS' if ok else 'FAIL','pairs':results,
             'required_pairs':3,'required_speedup':REQUIRED_SPEEDUP,'heavy_byte_equal_required':True,
             'NOTE':'NON_GATE_DEVELOPMENT_BENCHMARK; DOES_NOT_CONSUME_OWNER_G4'}
    tmp=out/'DEVELOPMENT_BENCHMARK_RECEIPT.json.tmp'; final=out/'DEVELOPMENT_BENCHMARK_RECEIPT.json'
    tmp.write_text(json.dumps(receipt,sort_keys=True,separators=(',',':'))+'\n',encoding='utf-8'); os.replace(tmp,final)
    if not ok: raise SystemExit(2)

if __name__=='__main__': main()
