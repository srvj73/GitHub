"""Windows stdlib process inventory, aggregate memory, session grants and lock."""
from __future__ import annotations

import ctypes
from ctypes import wintypes
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import time

from minotauro_v004_core import ModelError
from minotauro_v005r1_r1r10_memory import (
    MemoryCapSafeStop, MemoryProbeError, windows_counters_struct,
)

MIB = 1024**2
HARD_CAP_MIB = 48528
REGISTERED_RAM_MIB = 64704
# Conservative entire observed R1R10 pilot peak reserved per worker initially.
# Source: 00B, observed peak 10707.2 MiB; rounded up BEFORE any R1R11 timings.
FIRST_WORKER_RESERVE_MIB = 10708


def coordinator_sigint():
    """Undo the inherited Win32 ignore attribute; children explicitly ignore SIGINT."""
    import signal
    if os.name != 'nt':
        signal.signal(signal.SIGINT, signal.default_int_handler)
        return
    k=kernel()
    k.SetConsoleCtrlHandler.argtypes=[ctypes.c_void_p,wintypes.BOOL]
    k.SetConsoleCtrlHandler.restype=wintypes.BOOL
    if not k.SetConsoleCtrlHandler(None,False):
        raise ModelError('COORDINATOR_CTRL_C_ENABLE_FAILED '+str(ctypes.get_last_error()))
    signal.signal(signal.SIGINT,signal.default_int_handler)


def kernel():
    if os.name != 'nt':
        raise MemoryProbeError('WINDOWS_REQUIRED')
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    k.CloseHandle.argtypes = [ctypes.c_void_p]
    k.CloseHandle.restype = wintypes.BOOL
    k.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    k.OpenProcess.restype = ctypes.c_void_p
    return k


def linux_processes():
    """Map current PID namespace to the proc mount namespace; never assume equality."""
    namespace=os.readlink('/proc/self/ns/pid'); rows=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit(): continue
        try:
            if os.readlink(p/'ns/pid')!=namespace: continue
            st=(p/'status').read_text(); ids=[x for x in st.splitlines() if x.startswith('NSpid:')]
            if len(ids)!=1: raise ModelError('LINUX_NAMESPACE_PID_UNAVAILABLE')
            local=int(ids[0].split()[-1]);raw=(p/'stat').read_text(); fields=raw[raw.rfind(')')+2:].split()
            rows.append({'pid':local,'host_pid':int(p.name),'host_ppid':int(fields[1]),'exe':(p/'comm').read_text().strip(),'threads':int(fields[17]),'proc_path':str(p),'start_ticks':int(fields[19])})
        except (FileNotFoundError,ProcessLookupError): continue
        except PermissionError: continue  # other namespaces are not owned; self must still resolve
    mapping={r['host_pid']:r['pid'] for r in rows}
    if len({r['pid'] for r in rows})!=len(rows): raise ModelError('LINUX_NAMESPACE_PID_AMBIGUOUS')
    for r in rows:r['ppid']=mapping.get(r['host_ppid'],0)
    return rows


def linux_proc(pid):
    rows=[r for r in linux_processes() if r['pid']==int(pid)]
    if len(rows)!=1: raise ProcessLookupError('OWNED_PID_NOT_VISIBLE '+str(pid))
    return Path(rows[0]['proc_path'])


def process_snapshot():
    if os.name != 'nt': return linux_processes()
    class Entry(ctypes.Structure):
        _fields_ = [('dwSize', wintypes.DWORD), ('cntUsage', wintypes.DWORD),
                    ('th32ProcessID', wintypes.DWORD), ('th32DefaultHeapID', ctypes.c_size_t),
                    ('th32ModuleID', wintypes.DWORD), ('cntThreads', wintypes.DWORD),
                    ('th32ParentProcessID', wintypes.DWORD), ('pcPriClassBase', wintypes.LONG),
                    ('dwFlags', wintypes.DWORD), ('szExeFile', wintypes.WCHAR*260)]
    k = kernel()
    k.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    k.CreateToolhelp32Snapshot.restype = ctypes.c_void_p
    for name in ('Process32FirstW', 'Process32NextW'):
        fn = getattr(k, name); fn.argtypes = [ctypes.c_void_p, ctypes.POINTER(Entry)]; fn.restype = wintypes.BOOL
    handle = k.CreateToolhelp32Snapshot(2, 0)
    if handle in (None, ctypes.c_void_p(-1).value):
        raise MemoryProbeError('PROCESS_SCAN_FAILED')
    rows = []
    try:
        entry = Entry(); entry.dwSize = ctypes.sizeof(entry)
        if not k.Process32FirstW(handle, ctypes.byref(entry)):
            raise MemoryProbeError('PROCESS_SCAN_FIRST_FAILED')
        while True:
            rows.append({'pid':int(entry.th32ProcessID), 'ppid':int(entry.th32ParentProcessID),
                         'exe':entry.szExeFile, 'threads':int(entry.cntThreads)})
            if not k.Process32NextW(handle, ctypes.byref(entry)):
                if ctypes.get_last_error() != 18:
                    raise MemoryProbeError('PROCESS_SCAN_NEXT_FAILED')
                break
    finally:
        k.CloseHandle(handle)
    return sorted(rows, key=lambda r:r['pid'])


def process_creation_time_100ns(pid):
    if os.name != 'nt':
        proc=linux_proc(pid)
        raw=(proc/'stat').read_text(); fields=raw[raw.rfind(')')+2:].split()
        return int(fields[19])  # kernel start ticks, paired with PID; never fabricate dead identity
    class FT(ctypes.Structure):
        _fields_=[('low',wintypes.DWORD),('high',wintypes.DWORD)]
    k=kernel(); handle=k.OpenProcess(0x1000,False,int(pid))
    if not handle: raise MemoryProbeError(f'OPEN_PROCESS_IDENTITY_FAILED pid={pid} error={ctypes.get_last_error()}')
    k.GetProcessTimes.argtypes=[ctypes.c_void_p,ctypes.POINTER(FT),ctypes.POINTER(FT),ctypes.POINTER(FT),ctypes.POINTER(FT)]
    k.GetProcessTimes.restype=wintypes.BOOL
    try:
        c=FT();e=FT();kr=FT();u=FT()
        if not k.GetProcessTimes(handle,ctypes.byref(c),ctypes.byref(e),ctypes.byref(kr),ctypes.byref(u)):
            raise MemoryProbeError(f'PROCESS_CREATION_TIME_FAILED pid={pid} error={ctypes.get_last_error()}')
        return (int(c.high)<<32)|int(c.low)
    finally:
        k.CloseHandle(handle)

def process_identity(pid):
    return {'pid':int(pid),'creation_time_100ns':int(process_creation_time_100ns(int(pid)))}

def _pid_present(pid):
    pid=int(pid)
    if os.name!='nt': return any(r['pid']==pid for r in linux_processes())
    return any(int(r['pid'])==pid for r in process_snapshot())

def process_identity_live(identity):
    """Exact PID+creation-time liveness, fail-closed on an unprobeable live PID."""
    pid=int(identity['pid']); expected=int(identity['creation_time_100ns'])
    if not _pid_present(pid): return False
    try:
        return int(process_creation_time_100ns(pid))==expected
    except (MemoryProbeError,FileNotFoundError,ProcessLookupError):
        # A process may disappear between the inventory and GetProcessTimes. Only
        # classify it dead after a second physical inventory says the PID is gone.
        if not _pid_present(pid): return False
        raise ModelError(f'PROCESS_IDENTITY_UNPROBEABLE_WHILE_PID_LIVE pid={pid}')

def physical_ram_mib():
    if os.name != 'nt':
        total=os.sysconf('SC_PAGE_SIZE')*os.sysconf('SC_PHYS_PAGES')
        cap=Path('/sys/fs/cgroup/memory.max')
        if cap.is_file() and cap.read_text().strip()!='max': total=min(total,int(cap.read_text()))
        return total//MIB
    class Status(ctypes.Structure):
        _fields_ = [('length',wintypes.DWORD),('load',wintypes.DWORD)] + [
            (n,ctypes.c_uint64) for n in ('total','available','total_page','available_page','total_virtual','available_virtual','extended')]
    k = kernel(); st = Status(); st.length = ctypes.sizeof(st)
    k.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(Status)]
    k.GlobalMemoryStatusEx.restype = wintypes.BOOL
    if not k.GlobalMemoryStatusEx(ctypes.byref(st)):
        raise MemoryProbeError('PHYSICAL_RAM_PROBE_FAILED')
    return int(st.total//MIB)


def process_memory(pid):
    if os.name != 'nt':
        p=linux_proc(pid)
        st={a:int(b.split()[0])*1024 for line in (p/'status').read_text().splitlines() if ':' in line for a,b in [line.split(':',1)] if a in ('VmRSS','VmHWM')}
        private=st['VmRSS']  # conservative aggregate RSS; shared pages may be counted twice
        return {'pid':pid,'private':private,'peak':max(private,st.get('VmHWM',0)),'working_set':st.get('VmRSS',0)}
    k = kernel(); handle = k.OpenProcess(0x1000, False, pid)
    if not handle:
        raise MemoryProbeError(f'OPEN_PROCESS_FAILED pid={pid} error={ctypes.get_last_error()}')
    cls = windows_counters_struct(); counters = cls(); counters.cb = ctypes.sizeof(cls)
    fn = k.K32GetProcessMemoryInfo
    fn.argtypes = [ctypes.c_void_p, ctypes.POINTER(cls), wintypes.DWORD]
    fn.restype = wintypes.BOOL
    try:
        if not fn(handle, ctypes.byref(counters), counters.cb):
            raise MemoryProbeError(f'CHILD_MEMORY_PROBE_FAILED pid={pid} error={ctypes.get_last_error()}')
        return {'pid':pid, 'private':int(counters.PrivateUsage),
                'peak':int(counters.PeakPagefileUsage), 'working_set':int(counters.WorkingSetSize)}
    finally:
        k.CloseHandle(handle)


def grant_workers(snapshot, requested, previous_worker_peak=None):
    if type(requested) is not int or not 1 <= requested <= 24:
        raise ModelError('REQUESTED_WORKERS_MUST_BE_1_TO_24')
    ram=int(snapshot['ram_mib'])
    if ram <= 0: raise ModelError('RAM_UNAVAILABLE')
    reserve=FIRST_WORKER_RESERVE_MIB if previous_worker_peak is None else max(256,math.ceil(previous_worker_peak/MIB*1.25))
    target=min(ram*60//100,HARD_CAP_MIB)
    available=min(target-math.ceil(snapshot['coordinator_private']/MIB)-math.ceil(snapshot['shared_bytes']/MIB)-int(snapshot.get('aux_reserve_mib',2048)),int(snapshot.get('available_mib',target)))
    cpu=max(0,int(snapshot['cpu_logical'])-1-int(snapshot['external_heavy_workers']))
    groups=int(snapshot.get('independent_groups',requested))
    io=int(snapshot.get('io_worker_limit',24))
    grant=min(requested,24,cpu,max(0,available//reserve),groups,io)
    decision={**snapshot,'requested':requested,'granted':grant,'ram_target_mib':target,'worker_reserve_mib':reserve,'cpu_grant':cpu,'hard_cap_mib':HARD_CAP_MIB,'reason':'MIN_REQUEST_CPU_RAM_CAUSAL_GROUPS_IO'}
    if grant<1: raise ModelError('AUTOCPU_INSUFFICIENT_GRANT '+json.dumps(decision,sort_keys=True))
    return decision


def scheduler_snapshot(shared_bytes):
    rows = process_snapshot()
    by = {r['pid']:r for r in rows}; ancestors = {os.getpid()}; pid = os.getpid()
    while pid in by and by[pid]['ppid'] not in ancestors:
        pid = by[pid]['ppid']; ancestors.add(pid)
    heavy = [r for r in rows if r['pid'] not in ancestors and
             (r['exe'].lower().startswith(('python','pypy')) or r['exe'].lower() == 'terminal64.exe')]
    logical=len(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else (os.cpu_count() or 1)
    if os.name != 'nt':
        cpu=Path('/sys/fs/cgroup/cpu.max')
        if cpu.exists():
            quota,period=cpu.read_text().split()
            if quota!='max': logical=min(logical,max(1,int(quota)//int(period)))
    return {'cpu_logical':logical, 'ram_mib':physical_ram_mib(),
            'coordinator_private':process_memory(os.getpid())['private'],
            'shared_bytes':shared_bytes, 'external_heavy_workers':len(heavy),
            'external_processes':heavy, 'process_scan_count':len(rows)}


class JobMemory:
    def __init__(self, path):
        self.path = Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.pids = []; self.worker_pids = []; self.aux_pids = []; self.shared_bytes = 0; self.previous_worker_peak = None
        self.session_worker_peak = 0; self.job_peak = 0
        self.child_role = 'economic_worker'; self.owned_identities = {}
        self.cap_mib=min(HARD_CAP_MIB,physical_ram_mib()*60//100)
        self.current_bytes=0; self.sample_at=time.monotonic(); self.io_wait_seconds=0; self.io_worker_limit=24; self.io_counters={}
        name = self.path.name.upper()
        if name.startswith('PILOT_A_'):
            self.run_mode = 'PILOT_A'
        elif name.startswith('RUN_A_'):
            self.run_mode = 'RUN_A'
        elif name.startswith('RUN_B_'):
            self.run_mode = 'RUN_B'
        elif name.startswith('RUN_C_'):
            self.run_mode = 'RUN_C'
        else:
            self.run_mode = 'SYNTHETIC'

    def set_processes(self, worker_pids=(), aux_pids=()):
        self.worker_pids = [int(x) for x in worker_pids]
        self.aux_pids = [int(x) for x in aux_pids]
        self.pids = self.worker_pids + self.aux_pids
        previous = self.owned_identities
        current = dict(previous)
        for pid in self.pids:
            current[pid] = previous[pid] if pid in previous else process_identity(pid)
        self.owned_identities = current
        self.child_role = 'mixed' if self.aux_pids else 'economic_worker'

    def assert_owned_tree_clean(self):
        live=[v for v in self.owned_identities.values() if process_identity_live(v)]
        if live: raise ModelError('OWNED_PROCESS_TREE_NOT_CLEAN '+json.dumps(live,sort_keys=True))
        return {'status':'PASS','tracked':len(self.owned_identities)}

    def boundary(self, event, session=None, completed=0, **extra):
        samples = [process_memory(pid) for pid in [os.getpid(), *self.pids]]
        current = sum(x['private'] for x in samples) + self.shared_bytes
        bound = max(current, sum(x['peak'] for x in samples)+self.shared_bytes)
        self.job_peak = max(self.job_peak, bound)
        self.current_bytes=current; self.sample_at=time.monotonic()
        self.io_counters={'status':'UNKNOWN_PLATFORM_PROBE_UNAVAILABLE'}
        if os.name!='nt':
            try:
                values=[{k:int(v) for line in (linux_proc(pid)/'io').read_text().splitlines() for k,v in [line.split(':',1)]} for pid in [os.getpid(),*self.pids]]
                self.io_counters={k:sum(v[k] for v in values) for k in ('read_bytes','write_bytes')}
                self.io_counters['status']='OBSERVED_LINUX_PROC_IO'
            except (PermissionError,FileNotFoundError,ProcessLookupError): pass
        by_pid = {x['pid']:x for x in samples}
        self.session_worker_peak = max(self.session_worker_peak, max((by_pid[p]['peak'] for p in self.worker_pids if p in by_pid), default=0))
        roles = {str(p):('economic_worker' if p in self.worker_pids else 'stream_closeout') for p in self.pids}
        row = {'schema':'R1R11_MEMORY_V1','event':event,'session':session,'completed':completed,'pids':samples,'child_role':self.child_role,'pid_roles':roles,
               'shared_memory_bytes':self.shared_bytes,'JOB_MEM':current,'JOB_PEAK_BOUND':bound,'JOB_PEAK_BOUND_RUN':self.job_peak,
               'hard_cap_mib':HARD_CAP_MIB,'ram_target_mib':REGISTERED_RAM_MIB*60//100,
               'target_pressure':current > (REGISTERED_RAM_MIB*60//100)*MIB,
               'current_private_bytes':current,'peak_private_bytes':bound,
               'current_working_set_bytes':sum(x['working_set'] for x in samples),
               'peak_working_set_bytes':None,'probe':'WIN32_PRIVATE_AGGREGATE' if os.name=='nt' else 'LINUX_RSS_CONSERVATIVE_AGGREGATE','cap_mib':HARD_CAP_MIB,
               'observed_peak_bytes':bound,'cap_bytes':HARD_CAP_MIB*MIB,
               'boundary_event':event,'sessions_done':completed,'mode':self.run_mode,'architecture':'R1R11_V005R1',
               **extra}
        from r1r11_bounded_telemetry import append_json
        append_json(self.path,row,durable=True)
        if event in {'RUN_START','SESSION_COMMIT','MONTH_VERIFIED','PRE_PILOT_RECEIPT','PRE_FINALIZE','POST_FINALIZE'}:
            print(f"MEMORY_TELEMETRY event={event} mode={self.run_mode} session={session or 'NONE'} "
                  f"JOB_MEM_MIB={current/MIB:.1f} JOB_PEAK_BOUND_MIB={bound/MIB:.1f} "
                  f"JOB_PEAK_BOUND_RUN_MIB={self.job_peak/MIB:.1f} CAP_MIB={HARD_CAP_MIB}", flush=True)
        if current > self.cap_mib*MIB:
            raise MemoryCapSafeStop(row)
        return row

    def progress(self, session=None, completed=0, **extra):
        return self.boundary('PROGRESS',session,completed,**extra)


def safe_remove_scratch(path, root):
    path, root = Path(path), Path(root).resolve()
    if not path.resolve().is_relative_to(root) or path.resolve() == root:
        raise ModelError('SCRATCH_PATH_ESCAPE')
    for node in (path, *path.rglob('*')):
        if node.is_symlink() or (hasattr(node,'is_junction') and node.is_junction()):
            raise ModelError('SCRATCH_LINK_FORBIDDEN')
    shutil.rmtree(path)


class RunLock:
    def __init__(self, root):
        self.root = Path(root).resolve(); self.path = self.root/'RUN.lock'
        self.instance = f'{os.getpid()}_{time.time_ns()}'; self.creation_time_100ns = process_creation_time_100ns(os.getpid())
        self.owned = False
        self.mutex = None

    def __enter__(self):
        # Serialize stale-lock recovery itself, including the read/unlink/create
        # sequence. Exclusive file creation alone cannot protect that sequence.
        if os.name != 'nt':
            import fcntl
            self.root.mkdir(parents=True,exist_ok=True)
            self._linux_lock=(self.root/'MINOTAURO_RUN_MUTEX').open('a+b')
            try: fcntl.flock(self._linux_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except OSError:
                self._linux_lock.close(); raise ModelError('RUN_MUTEX_ACTIVE_OR_UNAVAILABLE')
            try: return self._enter_serialized()
            except BaseException as primary:
                self._abort_enter(primary)
                raise
        k = kernel()
        k.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
        k.CreateMutexW.restype = ctypes.c_void_p
        k.WaitForSingleObject.argtypes = [ctypes.c_void_p, wintypes.DWORD]
        k.WaitForSingleObject.restype = wintypes.DWORD
        name = 'Global\\MinotauroR1R11_' + hashlib.sha256(str(self.root).casefold().encode()).hexdigest()
        handle = k.CreateMutexW(None, False, name)
        if not handle:
            raise ModelError('RUN_MUTEX_CREATE_FAILED')
        result = k.WaitForSingleObject(handle, 0)
        if result not in (0, 0x80):  # WAIT_OBJECT_0 or abandoned owner.
            k.CloseHandle(handle)
            raise ModelError('RUN_MUTEX_ACTIVE_OR_UNAVAILABLE')
        self.mutex = handle
        try:
            return self._enter_serialized()
        except BaseException as primary:
            self._abort_enter(primary)
            raise

    def _abort_enter(self, primary):
        # Python does not call __exit__ when __enter__ raises. Release only
        # our identity-checked lock, while the writer mutex is still held.
        try:
            self.__exit__(type(primary), primary, primary.__traceback__)
        except BaseException as cleanup_error:
            # Cleanup must not replace the startup cause, including SIGINT.
            primary.add_note('RUN_LOCK_ENTER_CLEANUP_FAILED: ' + repr(cleanup_error))

    def _release_mutex(self):
        if getattr(self,'_linux_lock',None) is not None:
            import fcntl
            fcntl.flock(self._linux_lock,fcntl.LOCK_UN); self._linux_lock.close(); self._linux_lock=None
        if self.mutex is not None:
            k = kernel()
            k.ReleaseMutex.argtypes = [ctypes.c_void_p]
            k.ReleaseMutex.restype = wintypes.BOOL
            try:
                if not k.ReleaseMutex(self.mutex):
                    raise ModelError('RUN_MUTEX_RELEASE_FAILED')
            finally:
                k.CloseHandle(self.mutex)
                self.mutex = None

    def _enter_serialized(self):
        self.root.mkdir(parents=True,exist_ok=True)
        rows = process_snapshot(); live = {r['pid'] for r in rows}
        if self.path.exists():
            previous = json.loads(self.path.read_text(encoding='utf-8'))
            if 'creation_time_100ns' not in previous:
                raise ModelError('LEGACY_RUN_LOCK_REQUIRES_SEPARATE_RECONCILIATION')
            if process_identity_live({'pid':previous['pid'],'creation_time_100ns':previous['creation_time_100ns']}) or any(r['ppid']==previous['pid'] for r in rows):
                raise ModelError('RUN_LOCK_OR_ORPHAN_ACTIVE')
            self.path.unlink()
        scratch = self.root/'_scratch'
        if scratch.exists():
            for reg in list(scratch.rglob('worker.json'))+list(scratch.rglob('*.helper.json')):
                robj=json.loads(reg.read_text())
                if 'creation_time_100ns' not in robj:
                    raise ModelError('LEGACY_ORPHAN_REGISTRY_REQUIRES_SEPARATE_RECONCILIATION')
                if process_identity_live({'pid':robj['pid'],'creation_time_100ns':robj['creation_time_100ns']}):
                    raise ModelError('ORPHAN_WORKER_ACTIVE')
        with self.path.open('x',encoding='utf-8') as f:
            json.dump({'pid':os.getpid(),'creation_time_100ns':self.creation_time_100ns,'run_instance':self.instance,'out_root':str(self.root)},f)
        self.owned = True
        from r1r11_v4_transaction import recover
        recover(self.root)
        if scratch.exists() and any(scratch.iterdir()):
            # Every registry above was checked with PID+creation_time and no owned
            # process is live. Reconcile dead run-owned scratch in this same resume
            # attempt, then continue from the sealed checkpoint.
            removed = 0
            for child in list(scratch.iterdir()):
                if not child.is_dir():
                    raise ModelError('UNKNOWN_SCRATCH_ENTRY')
                safe_remove_scratch(child,scratch)
                removed += 1
            print(f'STALE_SCRATCH_RECONCILED=PASS removed_run_instances={removed} resume_same_attempt=YES',flush=True)
        return self

    def __exit__(self, *args):
        try:
            if self.owned:
                obj = json.loads(self.path.read_text())
                if obj.get('run_instance') != self.instance:
                    raise ModelError('RUN_LOCK_IDENTITY_CHANGED')
                self.path.unlink(); self.owned = False
        finally:
            self._release_mutex()
