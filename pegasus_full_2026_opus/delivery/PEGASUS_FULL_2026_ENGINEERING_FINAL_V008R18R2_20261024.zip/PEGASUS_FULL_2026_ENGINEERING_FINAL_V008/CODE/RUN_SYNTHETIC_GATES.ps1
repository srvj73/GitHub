param([string]$Config = "$PSScriptRoot\config.json")
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Minotauro_Launcher_Common.ps1"
$TranscriptOwned = Start-MinotauroTranscript -Config $Config -LauncherName $MyInvocation.MyCommand.Name
try {
    $Python=Resolve-RealPython
    $PyFiles = Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.py' -File | ForEach-Object { $_.FullName }
    $ExitCode = Invoke-MinotauroPython -Python $Python -Arguments (@('-m','py_compile') + @($PyFiles))
    if ($ExitCode -ne 0) { throw "PY_COMPILE_FAIL=$ExitCode" }
    # R1R10 (m-c): launcher self-test in a child Windows PowerShell of the same
    # host executable (live stdout/stderr, transcript capture, native exit
    # authority, nested transcript rule). Fail-closed before the synthetic gate.
    $HostExe = (Get-Process -Id $PID).Path
    $ExitCode = Invoke-MinotauroNative -FilePath $HostExe -Arguments @('-NoProfile','-ExecutionPolicy','Bypass','-File',"$PSScriptRoot\R1R10_LAUNCHER_SELFTEST.ps1",'-Python',$Python)
    if ($ExitCode -ne 0) { throw "R1R10_LAUNCHER_SELFTEST_FAIL=$ExitCode" }
    Write-Host 'R1R10_LAUNCHER_SELFTEST_GATE=PASS'
    $ExitCode = Invoke-MinotauroPython -Python $Python -Arguments @("$PSScriptRoot\minotauro_v005r1_r23_gates.py",'synthetic','--config',$Config)
    if ($ExitCode -ne 0) { throw "SYNTHETIC_GATE_FAIL=$ExitCode" }
    Write-Host 'SYNTHETIC_GATE=PASS'
    Write-Host 'DATA_PROCESSING=NO'
}
finally {
    Stop-MinotauroTranscriptSafe -Owned $TranscriptOwned
}
