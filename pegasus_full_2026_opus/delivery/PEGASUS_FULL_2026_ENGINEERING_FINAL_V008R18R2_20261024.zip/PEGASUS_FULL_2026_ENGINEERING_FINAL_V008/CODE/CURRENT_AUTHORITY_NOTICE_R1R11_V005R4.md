# CURRENT AUTHORITY — R1R11 V005R4

V005R4 supersedes V005R3 for further synthetic/performance qualification. Prior revisions remain historical evidence and MUST NOT be rerun.

Authorization: Windows V5 suite -> dev benchmark 3/3 -> fresh G1-G3. G4 remains forbidden until all three pass and are audited. Real data/Pilot/Full remain forbidden.
