$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'PS51_REQUIRED' }
$checked=@()
foreach ($name in @('RUN_PHASE.ps1','RUN_R1R11_OWNER_GATES.ps1','RUN_R1R11_TARGETED.ps1','R1R11_LAUNCHER_SELFTEST.ps1')) {
    $file=Join-Path (Join-Path $PSScriptRoot '..\package') $name
    $tokens=$null; $errorsFound=$null
    [void][Management.Automation.Language.Parser]::ParseFile($file,[ref]$tokens,[ref]$errorsFound)
    if ($errorsFound.Count -ne 0) { throw ($errorsFound | Out-String) }
    $checked+=$name
}
@{status='PASS_SYNTAX_ONLY';version=$PSVersionTable.PSVersion.ToString();files=$checked;full_launcher_selftest='NOT_EXECUTED'} | ConvertTo-Json
