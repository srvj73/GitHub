# MINOTAURO R1R11 V004R2R1 — Corrective Revision

Status: synthetic owner pending.

Parent: V004R2.
Reason: owner G3 failed before G4 because SESSION_SEAL persisted cached SHA-256 in lowercase while
verify_committed compares against the canonical uppercase sha256_file representation.

This revision is intentionally narrow:
- normalize cached SHA-256 to uppercase when writing SESSION_SEAL;
- validate exact 64-hex form fail-closed;
- add regression coverage for lowercase cached hash, SHA256("abc"), invalid hex, and lowercase persisted seal;
- derive V4 test cardinality from physical unittest discovery;
- preserve the original V004R2 operational preregistration unchanged.

Forbidden in this package-build step:
- G4;
- benchmark/timing measurement;
- real market data;
- Pilot A;
- Run A.

Next authorized owner stage, only after user approval: fresh G1-G3 synthetic owner evidence.
