from pathlib import Path
import ast, hashlib, json, tempfile, unittest
ROOT=Path(__file__).resolve().parent
class ResumeV002R1Tests(unittest.TestCase):
    def test_controller_has_prepare_full(self):
        t=(ROOT/'r1r11_perf_next_controller.py').read_text()
        self.assertIn("'prepare-full'",t)
        self.assertIn("disk_gate_after_pilot(out);authorize_full(out)",t)
    def test_new_default_root_is_separate(self):
        t=(ROOT/'r1r11_perf_next_controller.py').read_text()
        self.assertIn('PERF_NEXT_V003R3_W15_B256_20260929',t)
        self.assertNotIn("DEFAULT_OUT=Path(r'D:\\\\MinotauroRuns\\\\MINOTAURO_R1R11_FULL_CORRECT",t)
    def test_resume_helper_never_imports_source_scratch(self):
        t=(ROOT/'r1r11_resume_import.py').read_text()
        self.assertIn("'uncommitted_source_scratch_imported':'NO'",t)
        self.assertNotIn("copytree(source/'_scratch'",t)
    def test_resume_helper_rebuilds_target_seals(self):
        t=(ROOT/'r1r11_resume_import.py').read_text()
        self.assertIn('SESSION_SEALS',t)
        self.assertIn('Runtime.verify_committed',t)
    def test_resume_helper_atomic_session_tree_publish(self):
        t=(ROOT/'r1r11_resume_import.py').read_text()
        self.assertIn("os.replace(staging,final)",t)
    def test_source_binding_semantics_are_explicit(self):
        import importlib.util
        spec=importlib.util.spec_from_file_location('ri',ROOT/'r1r11_resume_import.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        self.assertIn('tick_files',m.SOURCE_BINDING_KEYS)
        self.assertIn('session_calendar_sha256',m.SOURCE_BINDING_KEYS)
        self.assertIn('source_inventory_sha256',m.SOURCE_BINDING_KEYS)
    def test_no_kill_primitive_in_resume_helper(self):
        t=(ROOT/'r1r11_resume_import.py').read_text().lower()
        for bad in ('terminateprocess','taskkill','stop-process'):
            self.assertNotIn(bad,t)

    def test_copy_sessions_atomic_and_manifest(self):
        import importlib.util, tempfile
        spec=importlib.util.spec_from_file_location('ri_copy',ROOT/'r1r11_resume_import.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); source=base/'source'; target=base/'target'
            completed=['2025-01-02','2025-01-03']
            for s in completed:
                d=source/'PHASE_A'/'sessions'/s; d.mkdir(parents=True)
                for i,n in enumerate(m.SESSION_FILES):
                    (d/n).write_bytes((s+'|'+n+'|'+str(i)).encode())
            (target/'PHASE_A').mkdir(parents=True)
            final=m.copy_sessions_atomic(source,target,completed)
            self.assertEqual({p.name for p in final.iterdir()},set(completed))
            mp,count=m.build_import_manifest(source,target,completed)
            self.assertEqual(count,len(completed)*len(m.SESSION_FILES))
            self.assertTrue(mp.is_file())
            for s in completed:
                for n in m.SESSION_FILES:
                    self.assertEqual((source/'PHASE_A'/'sessions'/s/n).read_bytes(),(target/'PHASE_A'/'sessions'/s/n).read_bytes())
    def test_copy_sessions_refuses_partial_target(self):
        import importlib.util, tempfile
        spec=importlib.util.spec_from_file_location('ri_partial',ROOT/'r1r11_resume_import.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); source=base/'source'; target=base/'target'; completed=['2025-01-02','2025-01-03']
            for s in completed:
                d=source/'PHASE_A'/'sessions'/s; d.mkdir(parents=True)
                for n in m.SESSION_FILES:(d/n).write_bytes(b'x')
            (target/'PHASE_A'/'sessions'/'2025-01-02').mkdir(parents=True)
            with self.assertRaises(RuntimeError):m.copy_sessions_atomic(source,target,completed)
    def test_verified_months_must_match_target_binding(self):
        import importlib.util
        spec=importlib.util.spec_from_file_location('ri_vm',ROOT/'r1r11_resume_import.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        cp={'verified_months':{'D:/ticks.csv':'A'*64}}
        binding={'tick_files':[{'path':'D:/ticks.csv','sha256':'A'*64}]}
        self.assertEqual(m.validate_verified_months(cp,binding),cp['verified_months'])
        with self.assertRaises(RuntimeError):m.validate_verified_months(cp,{'tick_files':[{'path':'D:/ticks.csv','sha256':'B'*64}]})

    def test_python_files_parse(self):
        for n in ('r1r11_perf_next_controller.py','r1r11_resume_import.py'):
            ast.parse((ROOT/n).read_text())
if __name__=='__main__': unittest.main(verbosity=2)
