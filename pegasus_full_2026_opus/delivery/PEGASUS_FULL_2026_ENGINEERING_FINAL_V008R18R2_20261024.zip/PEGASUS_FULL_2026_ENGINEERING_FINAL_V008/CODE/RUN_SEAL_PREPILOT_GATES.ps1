param([string]$Config = "$PSScriptRoot\config.json")
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Minotauro_Launcher_Common.ps1"
$TranscriptOwned = Start-MinotauroTranscript -Config $Config -LauncherName $MyInvocation.MyCommand.Name
try {
    $Python=Resolve-RealPython
    $ExitCode = Invoke-MinotauroPython -Python $Python -Arguments @("$PSScriptRoot\minotauro_v005r1_r23_gates.py",'seal-prepilot','--config',$Config)
    if ($ExitCode -ne 0) { throw "PREPILOT_SEAL_FAIL=$ExitCode" }
    Write-Host 'PRE_PILOT_GATES=PASS_27_OF_27'
    Write-Host 'PILOT_AUTHORIZED=NO_PENDING_OWNER_AND_POSTIMPLEMENTATION_AUDIT'
    Write-Host 'DATA_PROCESSING_AUTHORIZED=NO'
}
finally {
    Stop-MinotauroTranscriptSafe -Owned $TranscriptOwned
}
