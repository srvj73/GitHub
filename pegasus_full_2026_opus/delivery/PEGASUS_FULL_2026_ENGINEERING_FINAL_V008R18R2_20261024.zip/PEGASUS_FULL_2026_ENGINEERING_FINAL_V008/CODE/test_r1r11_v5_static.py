from __future__ import annotations

import unittest
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent


class V005Static(unittest.TestCase):
    def test_e1_e7_present_no_e8(self):
        text = (PACKAGE / "SPEC_R1R11_MULTIWORK_AUTOCPU_V005.md").read_text(encoding="utf-8")
        for x in ("E1", "E2", "E3", "E4", "E5", "E6", "E7"):
            self.assertIn(x, text)
        self.assertNotIn("E8 —", text)

    def test_no_v4_sidecar_hot_path(self):
        w = (PACKAGE / "r1r11_worker.py").read_text(encoding="utf-8")
        v = (PACKAGE / "r1r11_v5_stream.py").read_text(encoding="utf-8")
        self.assertNotIn("checked_rows(", w)
        self.assertNotIn(".sidecar", w)
        self.assertNotIn("checked_rows(", v)
        self.assertNotIn("side_path", v)

    def test_activation_fixed_batch_final_audit_and_owner_auth(self):
        s = (PACKAGE / "r1r11_activation_controller.py").read_text(encoding="utf-8")
        for needle in (
            "batch_rows != 32", "R1R11_FINAL_PREPILOT_AUDIT_REQUIRED",
            "R1R11_FINAL_AUDIT_PACK_REQUIRED", "R1R11_POSTPILOT_PROMOTION_REQUIRED",
            "R1R11_OWNER_PILOT_AUTHORIZATION_REQUIRED", "R1R11_OWNER_RUN_A_AUTHORIZATION_REQUIRED",
        ):
            self.assertIn(needle, s)

    def test_pp1_pp9_implemented(self):
        s = (PACKAGE / "r1r11_postpilot_promotion.py").read_text(encoding="utf-8")
        for n in range(1, 10):
            self.assertIn(f"_pp{n}", s)
        self.assertIn("PP1_PP9", s)
        self.assertIn("PASS_9_OF_9", s)

    def test_a0_runner_cli_matches_python_and_full_diagnostics(self):
        ps = (PACKAGE / "RUN_R1R11_A0_V005R1.ps1").read_text(encoding="utf-8")
        py = (PACKAGE / "r1r11_a0.py").read_text(encoding="utf-8")
        for token in ("--source-root", "--evidence", "--prereg", "--forensic", "--microbench", "--equality"):
            self.assertIn(token, ps)
            self.assertIn(token, py)
        self.assertNotIn("--source-owner-root", ps)
        self.assertNotIn("--collection", ps)
        for dimension in ("heap_15way", "order_proof_json_vs_binary", "parent_is_alive_per_line", "transaction_proxy"):
            self.assertIn(dimension, py)
        self.assertIn("G4_oracle.log", py)
        self.assertIn("G4_candidate.log", py)

    def test_final_audit_pack_is_complete_and_hash_bound(self):
        pack = (PACKAGE / "r1r11_final_audit_pack.py").read_text(encoding="utf-8")
        bind = (PACKAGE / "r1r11_bind_final_audit.py").read_text(encoding="utf-8")
        for label in ("A0_EVIDENCE", "DEVELOPMENT_BENCHMARK", "G4_EXTERNAL_LEDGER", "OWNER_EVIDENCE_V005R1", "PACKAGE"):
            self.assertIn(label, pack)
        self.assertIn("V004R1_PRIMARY_TREE_MISSING", pack)
        self.assertIn("R1R11_FINAL_AUDIT_PACK_SHA256", bind)
        self.assertIn("audit_pack_sha256", bind)

    def test_owner_authorization_is_bound_to_final_audit(self):
        s = (PACKAGE / "r1r11_owner_authorize.py").read_text(encoding="utf-8")
        self.assertIn("I_APPROVE_PILOT_A", s)
        self.assertIn("I_APPROVE_RUN_A", s)
        self.assertIn("final_audit_receipt_sha256", s)

    def test_full_run_homologation_closes_roadmap(self):
        py = (PACKAGE / "r1r11_full_homologation.py").read_text(encoding="utf-8")
        ps = (PACKAGE / "RUN_R1R11_ACTIVATION_V005R1.ps1").read_text(encoding="utf-8")
        for needle in ("FULL_RUN_HOMOLOGATION", "\"sessions\": 250", "\"verified_months\": 12", "EQUITY_LOSSLESS_GATE", "SELECTION_FREEZE"):
            self.assertIn(needle, py)
        self.assertIn("r1r11_full_homologation.py", ps)
        self.assertIn("R1R11_FULL_RUN_AND_HOMOLOGATION=PASS", ps)


if __name__ == "__main__":
    unittest.main(verbosity=2)
