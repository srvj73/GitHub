# CHANGELOG — R1R11 V005R1

Source: Opus 5.5 audit `AUDIT_OPUS55_R1R11_V004R2R1_G4_FAIL_TO_FULL_V001_20260927.md`.

Implemented within E1–E7 only:

- E1: four canonical stream writers operate during feed under ACK-derived watermarks.
- E2: finalized trades are emitted as a globally safe prefix and rechecked at FINISH.
- E3: an independent verifier process per stream produces an independent canonical gzip and proof; physical stage identity/hash is reverified before transaction publication.
- E4: no per-row sidecar exists on the V005 hot path; JSONL scratch remains authoritative.
- E5: parent liveness is no longer checked per emitted line; stream roles are pre-spawned and included in memory accounting; order proof is binary.
- E6: transport telemetry records monotonic and wall timestamps; memory telemetry is versioned and phase-qualified.
- E7: G4 has an external one-shot ledger controller and post-gate economic diagnostic.
- A0 collector/microbench/economic diagnostic/GO-NO-GO machinery added.
- Development benchmark requires 3/3 heavy pairs at speedup >= 1.667 and byte equality before G4.
- Fresh G1–G3 are required; G4 remains one-shot; G5–G11 only after G4 PASS.
- External activation controller added; frozen runner main remains disabled.
- Final independent pre-Pilot audit is bound by report hash + package + G1–G11 receipt.
- Post-Pilot PP1–PP9 mechanical promotion implemented for R1R11/multiwork.
- Owner authorizations remain explicit and cannot be minted without approval tokens.
- Final Full Run remains a PC-owner execution after all gates; it is not executed by this build.

No oracle, economic core, frozen serializer, fixture, G4 threshold, heavy cycles,
workers=4 G4 boundary, batch_rows=32, shared slot count, runtime identity, or
publisher authority was intentionally changed.
