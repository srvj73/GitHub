# MINOTAURO V005R1 — R1R10

A R1R10 é uma revisão **exclusivamente operacional** da R1R9. Ela existe para fechar os findings da auditoria pós-piloto Opus 5.5 (`AUDIT_OPUS55_R1R9_POSTPILOT_FINAL_20260926.md`, §7): M-1/m-d (memória), m-c (progresso ao vivo) e m-e (rótulo).

## Escopo

- **Especificação governante:** V005R1-R2.3 (SHA `D6D79108…2E73747`), inalterada.
- **Parent físico:** R1R9 (ZIP `00D04BE1…685C2C4B`).
- **Delta econômico, causal, geométrico, de seleção ou de gates:** **NENHUM**.
- **Arquivos congelados byte-idênticos:** `core`, `io`, `preflight`, `metrics`, `gates`, `reference`, MQ5 de paridade, SPEC R2.3 e R6 (ver `FROZEN_FILES_IDENTITY_R1R10.json`).

## O que mudou

1. **Trades sem acúmulo anual (M-1/m-d).**
   - O commit de sessão grava os mesmos cinco arquivos por sessão e não mantém `res.trades` após o checkpoint.
   - O resume não recarrega trades; apenas verifica a existência dos arquivos já commitados.
   - No `finalize`, `aggregate_phase` (congelado) consome um stream dos `trades.jsonl.gz`.
   - `TRADES_2025_ALL_CELLS.csv` é escrito em duas passagens, com no máximo uma sessão em memória.
   - O algoritmo R1R9 em lista foi mantido apenas como oráculo de equivalência nos testes.
2. **Telemetria de memória e teto fail-closed.**
   - Novo módulo `minotauro_v005r1_r1r10_memory.py`, somente stdlib: `ctypes` + `K32GetProcessMemoryInfo` no Windows, `/proc/self/status` no Linux.
   - Telemetria por sessão, gravada com flush + fsync por linha, em `<out_root>\TELEMETRY\<MODE>_SESSION_TELEMETRY.jsonl`.
   - O arquivo fica fora de `PHASE_A`/`PILOT_A`, e `session_receipt.json` permanece inalterado.
   - `config.json` exige `memory_cap_mib` (inteiro) para `pilot-a`/`run-a`.
   - O teto é verificado somente em fronteiras seguras: `RUN_START`, cada `SESSION_COMMIT`, `MONTH_VERIFIED`, `PRE_PILOT_RECEIPT`, `PRE_FINALIZE` e `POST_FINALIZE`.
   - Se o teto for excedido: marcador `MEMORY_CAP_SAFE_STOP=YES … pass=NO`, **exit code 3**, nenhum PASS, checkpoint consistente e resume normal.
3. **Progresso ao vivo (m-c).**
   - `Invoke-MinotauroNative` transmite stdout e stderr linha a linha, enquanto o processo roda, via `2>&1 | ForEach-Object { Write-Host … }`.
   - As linhas de stderr recebem o prefixo `[stderr] `.
   - O Python roda com `-u`.
   - O exit code nativo continua sendo a única autoridade.
   - Os arquivos temporários de spool/replay da R1R9 foram removidos.
4. **Rótulo (m-e).** `RUN_PHASE.ps1` imprime `MINOTAURO_V005R1_R1R10 COMMAND=…` e mapeia o exit 3 para `MEMORY_CAP_SAFE_STOP=YES` / `PASS=NO`.
5. **Autoteste do launcher.**
   - O `RUN_SYNTHETIC_GATES.ps1` executa `R1R10_LAUNCHER_SELFTEST.ps1` em um processo filho do mesmo host PowerShell, antes do gate sintético.
   - O autoteste faz 16 verificações: stdout/stderr ao vivo, captura no transcript, autoridade do exit code e regra de transcript aninhado.
   - Se qualquer verificação falhar, o gate sintético é bloqueado (fail-closed).

## Identidades R1R10

- `RUNNER_VERSION = MINOTAURO_PARAMETER_MARKET_DISCOVERY_V005R1_R1R10`
- `runner_sha256` e `gate_suite_sha256`: ver `IMPLEMENTATION_RECEIPT_R1R10.json`.
- Todas as identidades de cadeia mudam. **Nenhum receipt R1R9 pode ser promovido a R1R10.**

## Estado de autorização

- `READY_FOR_INDEPENDENT_DIFF_AUDIT=YES` é a única promoção deste pacote.
- `PILOT_A_AUTHORIZED=NO` e `RUN_A_AUTHORIZED=NO`.
- Nenhum `OWNER_*_AUTHORIZATION.json` foi criado, e nenhum dado de mercado foi processado.

## Próxima etapa

A próxima etapa é a **auditoria independente do diff R1R9→R1R10** (`DIFF_R1R9_TO_R1R10.patch`). Nada deve ser executado no PC do owner antes dela.

Se a auditoria autorizar, a cadeia será refeita em **`out_root` novo**, conforme a auditoria 25, §7(b):

1. Copiar `config.example.json` para `config.json`, ajustar os caminhos e definir `memory_cap_mib`.
   - Esse valor é decisão do owner.
   - Ele fica vinculado ao checkpoint da fase via `config_sha256`, portanto não deve ser alterado durante um `pilot-a`/`run-a` em andamento.
2. Executar `RUN_LIGHT_REBIND_A.ps1`, depois `RUN_PRE_RUN_A_GATES.ps1`, depois `RUN_GEOMETRY_VALIDATE.ps1` e por fim `RUN_SEAL_PREPILOT_GATES.ps1`.
   - A saída física do MT5 só pode ser reaproveitada se o novo `GATES\GEOMETRY_INPUT_R23.csv` tiver SHA256 `E28EE2F1BB052CE2A1FF8242FDC02702D644E8DB165706D09D2B2DBCDC3FB9D2`.
3. Seguir com as etapas de autorização e piloto definidas pela auditoria.

### O que o transcript sintético R1R10 deve conter

- `R1R10_SELFTEST_CHECK=… PASS`, 16 linhas.
- `R1R10_LAUNCHER_SELFTEST=PASS` e `R1R10_LAUNCHER_SELFTEST_GATE=PASS`.
- `[stderr] Ran 44 tests` e `[stderr] OK`.
  - O unittest escreve em stderr; na R1R10 essas linhas chegam ao vivo e com o prefixo `[stderr] `.
- O JSON `"SYNTHETIC_GATES": "PASS"` e a linha `SYNTHETIC_GATE=PASS`.
- A linha `TRANSCRIPT=` do autoteste aponta para um transcript temporário do processo filho, que é removido ao final. Isso é esperado.
- O gate operacional passa a executar **34 testes** (10 R1R9 + 24 R1R10).

## Limitações declaradas

- **Runtime Windows PowerShell 5.1.** Não está disponível no ambiente do builder.
  - O helper e o autoteste foram validados em PowerShell 7.4.6 (Linux) apenas como evidência secundária.
  - Um controle negativo com a semântica de spool da R1R9 falhou no autoteste, como esperado.
  - A prova primária é o autoteste no PC do owner.
- **Probe Windows (`K32GetProcessMemoryInfo`).**
  - O layout da estrutura foi verificado (80 bytes em x64).
  - A chamada real só é exercida no PC do owner, pelos testes operacionais `test_r1r10_live_process_probe_on_this_platform` e `test_r1r10_main_exit_code_3_marker_no_pass_with_real_probe`.
- **O teto não é um limite rígido.**
  - Ele é avaliado em fronteiras seguras e não interrompe uma sessão em curso: não há kill assíncrono, por exigência da especificação.
  - O pico dentro de uma sessão é determinado pelo engine congelado, e a telemetria de `PROGRESS` o registra.
- **O-5 (Ctrl+C sob saída redirecionada)** continua não exercitado. Qualquer interrupção segue as regras de checkpoint/orphan já auditadas.
