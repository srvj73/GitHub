from pathlib import Path
import tempfile, unittest, json, os, time
import r1r11_preflight_2026_resumable as p
from minotauro_v004_io import cutoff_msc_for_session

class ResumePreflight(unittest.TestCase):
    def _m1row(self,date):
        return f"WIN@N;M1;{date.replace('-','.')};09:00:00;100;110;90;105;1;1;1;0;0\n"
    def _fixture(self,root):
        ticks=root/"ticks";m1=root/"m1";ticks.mkdir();m1.mkdir()
        (m1/"WIN@N_M1_2025_12.csv").write_text(self._m1row("2025-12-30"),encoding="utf-8")
        (m1/"WIN@N_M1_2026_01.csv").write_text(self._m1row("2026-01-02"),encoding="utf-8")
        d1=root/"IND@N.csv";d1.write_text("data,abertura,maxima,minima,fechamento,financeiro,contratos\n2025-12-30,100,110,90,105,0,0\n",encoding="utf-8")
        cutoff=cutoff_msc_for_session("2026-01-02")
        tick=ticks/"WIN@N_ticks_2026_01.csv"
        tick.write_text(f"WIN@N;2026.01.02 18:03:00;{cutoff};100;101;100;1;1;0\nWIN@N;2026.01.02 18:03:01;{cutoff+1000};100;101;100;1;1;0\n",encoding="utf-8")
        out=root/"out";cfg={"out_root":str(out),"ticks_root":str(ticks),"m1_root":str(m1),"ind_d1":str(d1)}
        return cfg,tick,out

    def test_single_month_pass_and_resume_without_rescan(self):
        with tempfile.TemporaryDirectory() as td:
            cfg,tick,out=self._fixture(Path(td))
            self.assertEqual(p.preflight_phase_resumable(cfg,"B"),1)
            phase=out/"PHASE_B"
            self.assertEqual(json.loads((phase/"PHASE_STATUS.json").read_text())["PHASE_DATA_STATUS"],"PASS")
            cp=json.loads((phase/"PREFLIGHT_CHECKPOINT.json").read_text());self.assertEqual(cp["status"],"PASS")
            original=p.iter_tick_file
            try:
                def forbidden(*a,**k): raise AssertionError("completed month rescanned")
                p.iter_tick_file=forbidden
                self.assertEqual(p.preflight_phase_resumable(cfg,"B"),1)
            finally:p.iter_tick_file=original

    def test_checkpoint_binds_source_stat(self):
        with tempfile.TemporaryDirectory() as td:
            cfg,tick,out=self._fixture(Path(td))
            self.assertEqual(p.preflight_phase_resumable(cfg,"B"),1)
            now=time.time_ns()+2_000_000_000;os.utime(tick,ns=(now,now))
            with self.assertRaises(Exception):p.preflight_phase_resumable(cfg,"B")

if __name__=="__main__":unittest.main(verbosity=2)
