"""Bounded lifecycle tests. Recovery is replaced by a sentinel, never executed."""
from pathlib import Path
import argparse,hashlib,importlib,json,os,sys,time
from unittest.mock import patch

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--code',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--expect',choices=['parent','delta'],required=True);a=ap.parse_args()
    code=a.code.resolve();out=a.out.resolve();assert not out.exists() and not out.is_relative_to(code)
    out.mkdir(parents=True);sys.path.insert(0,str(code))
    import r1r11_resources as r
    import r1r11_v4_transaction as t
    result={'schema':'PEGASUS_LOCK_LIFECYCLE_DELTA','mode':a.expect,'source_sha256':hashlib.sha256((code/'r1r11_resources.py').read_bytes()).hexdigest().upper(),'python':sys.version,'native_platform':sys.platform,'recovery_executed':False,'economic_code_executed':False,'cases':[]}
    def record(name,**facts):result['cases'].append({'name':name,'result':'PASS_EXPECTED_OBSERVATION',**facts})
    def failure_case(name,kind='recover',exc_type=RuntimeError):
        root=out/name;root.mkdir();lock=r.RunLock(root);primary=exc_type('INJECTED_STARTUP_PRIMARY')
        marker=root/'PROTECTED_DATA';marker.write_bytes(b'keep-exact')
        if kind=='scratch':(root/'_scratch/old').mkdir(parents=True)
        def stub(_):
            if kind=='foreign':
                lock.path.write_text(json.dumps({'run_instance':'FOREIGN'}));raise primary
            if kind!='scratch':raise primary
        with patch.object(t,'recover',side_effect=stub),patch.object(r,'safe_remove_scratch',side_effect=primary):
            try:
                with lock:raise AssertionError('WITH_BODY_MUST_NOT_ENTER')
            except BaseException as got:assert got is primary
            else:raise AssertionError('EXCEPTION_NOT_PROPAGATED')
        exists=lock.path.exists();notes=getattr(primary,'__notes__',[])
        expected=(a.expect=='parent' or kind=='foreign')
        assert exists==expected,(name,exists,expected)
        assert getattr(lock,'_linux_lock',None) is None
        assert marker.read_bytes()==b'keep-exact'
        if kind=='foreign':
            assert json.loads(lock.path.read_text())=={'run_instance':'FOREIGN'}
            if a.expect=='delta':assert any('RUN_LOCK_ENTER_CLEANUP_FAILED' in s for s in notes)
        record(name,lock_remaining=exists,primary_preserved=True,cleanup_notes=notes,protected_unchanged=True)
    try:
        for name,kind,typ in [('recover_exception','recover',RuntimeError),('scratch_exception','scratch',RuntimeError),('keyboard_interrupt','recover',KeyboardInterrupt),('foreign_lock_preserved','foreign',RuntimeError)]:failure_case(name,kind,typ)
        root=out/'normal_exit';root.mkdir()
        with patch.object(t,'recover',return_value=None):
            with r.RunLock(root) as lock:
                assert lock.path.exists()
                try:
                    with r.RunLock(root):raise AssertionError('SECOND_WRITER_ADMITTED')
                except r.ModelError as e:assert 'RUN_MUTEX_ACTIVE_OR_UNAVAILABLE' in str(e)
                assert lock.path.exists()
        assert not lock.path.exists();record('normal_exit_and_mutex_exclusion',lock_remaining=False)
        root=out/'preowned_lock';root.mkdir();before=json.dumps({'pid':os.getpid(),'creation_time_100ns':r.process_creation_time_100ns(os.getpid()),'run_instance':'existing'})
        (root/'RUN.lock').write_text(before)
        with patch.object(t,'recover',side_effect=AssertionError('RECOVERY_MUST_NOT_BE_CALLED')):
            try:
                with r.RunLock(root):raise AssertionError('ACTIVE_LOCK_ADMITTED')
            except r.ModelError as e:assert 'RUN_LOCK_OR_ORPHAN_ACTIVE' in str(e)
        assert (root/'RUN.lock').read_text()==before;record('preexisting_live_lock_preserved')
        if a.expect=='delta':
            for label in ['unlink_failure','mutex_release_failure']:
                root=out/label;root.mkdir();lock=r.RunLock(root);primary=RuntimeError('PRIMARY');real_unlink=Path.unlink;release=lock._release_mutex
                def unlink(p,*args,**kw):
                    if p==lock.path:raise PermissionError('INJECTED_UNLINK_DENIED')
                    return real_unlink(p,*args,**kw)
                def release_bad():release();raise RuntimeError('INJECTED_RELEASE_REPORT_FAILURE')
                with patch.object(t,'recover',side_effect=primary),patch.object(Path,'unlink',new=unlink if label=='unlink_failure' else real_unlink),patch.object(lock,'_release_mutex',side_effect=release_bad if label=='mutex_release_failure' else release):
                    try:
                        with lock:raise AssertionError('BODY_ENTERED')
                    except BaseException as got:assert got is primary
                assert any('RUN_LOCK_ENTER_CLEANUP_FAILED' in s for s in primary.__notes__)
                assert getattr(lock,'_linux_lock',None) is None
                record(label,primary_preserved=True,lock_remaining=lock.path.exists(),notes=primary.__notes__)
        result['result']='PASS_BOUNDED_LIFECYCLE_ONLY'
    except BaseException as e:result['result']='FAIL_STOP_CHAIN';result['error']=repr(e);raise
    finally:(out/'RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'result':result['result'],'cases':len(result['cases']),'receipt':str(out/'RECEIPT.json')}))
if __name__=='__main__':main()
