"""Reintroduce mutex-only cleanup in memory; must observe the owned-lock leak."""
from pathlib import Path
import argparse,sys,json,hashlib
from unittest.mock import patch

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--code',required=True,type=Path);ap.add_argument('--out',required=True,type=Path);n=ap.parse_args()
    code=n.code.resolve();root=n.out.resolve();assert not root.exists() and not root.is_relative_to(code)
    root.mkdir(parents=True);sys.path.insert(0,str(code))
    import r1r11_resources as r
    import r1r11_v4_transaction as t
    lock=r.RunLock(root);primary=RuntimeError('MUTANT_SENTINEL')
    with patch.object(t,'recover',side_effect=primary),patch.object(lock,'_abort_enter',side_effect=lambda exc:lock._release_mutex()):
        try:
            with lock:raise AssertionError('BODY_ENTERED')
        except RuntimeError as e:assert e is primary
    assert lock.path.exists() and getattr(lock,'_linux_lock',None) is None
    record={'result':'PASS_NEGATIVE_CONTROL_DETECTS_REINTRODUCED_LEAK','mutation':'in-memory replacement of _abort_enter by mutex-only release','source_file_modified':False,'run_lock_remaining':True,'recovery_executed':False,'source_sha256':hashlib.sha256((code/'r1r11_resources.py').read_bytes()).hexdigest().upper()}
    (root/'RECEIPT.json').write_text(json.dumps(record,indent=2)+'\n')
if __name__=='__main__':main()
