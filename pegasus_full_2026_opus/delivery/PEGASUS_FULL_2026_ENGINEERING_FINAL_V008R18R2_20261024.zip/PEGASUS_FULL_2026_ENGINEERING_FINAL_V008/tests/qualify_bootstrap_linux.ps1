param([string]$ScriptPath,[string]$EvidenceRoot,[Parameter(Mandatory=$true)][string]$PythonExecutable)
$ErrorActionPreference='Stop'
$TokenSet=$null;$ParserErrors=$null
$Ast=[System.Management.Automation.Language.Parser]::ParseFile($ScriptPath,[ref]$TokenSet,[ref]$ParserErrors)
if($ParserErrors.Count -ne 0) { throw ($ParserErrors | Out-String) }
$Denied=@('pid','args','home','host','error','input','matches','pshome','psversiontable','lastexitcode','null','true','false')
$Bad=@($Ast.FindAll({param($Node) $Node -is [System.Management.Automation.Language.ParameterAst]},$true) | Where-Object { $Denied -contains $_.Name.VariablePath.UserPath.ToLowerInvariant() })
$Assignments=@($Ast.FindAll({param($Node) $Node -is [System.Management.Automation.Language.AssignmentStatementAst]},$true) | Where-Object { $_.Left -is [System.Management.Automation.Language.VariableExpressionAst] -and $Denied -contains ($_.Left.VariablePath.UserPath.ToLowerInvariant()) })
if($Bad.Count -gt 0 -or $Assignments.Count -gt 0) { throw 'RESERVED_FORMAL_PARAMETER' }
foreach($Name in @('ConvertTo-PegasusNativeArgument','Invoke-PegasusNative')) {
    $Definition=@($Ast.FindAll({param($Node) $Node -is [System.Management.Automation.Language.FunctionDefinitionAst]},$true) | Where-Object { $_.Name -eq $Name })
    if($Definition.Count -ne 1) { throw 'FUNCTION_CARDINALITY' }
    Invoke-Expression $Definition[0].Extent.Text
}
$Python=$PythonExecutable
$Probe=Join-Path $PSScriptRoot 'argv_probe.py'
$ProbeOut=Join-Path $EvidenceRoot 'ARGV_PWSH7.json'
$Exit=Invoke-PegasusNative $Python @('-I','-B',$Probe,$ProbeOut,'space value','literal"quote','tail\') $EvidenceRoot 30
if($Exit -ne 37) { throw "NATIVE_EXIT_WRONG=$Exit" }
$Data=Get-Content -LiteralPath $ProbeOut -Raw | ConvertFrom-Json
if(-not $Data.pass) { throw 'ARGV_WRONG' }
[Int64]$Large=[Int64]2147483648+[Int64]1900518140
if($Large -le [Int64]2147483647) { throw 'INT64_FAILURE' }
$Report=@{schema='PEGASUS_PS7_BOOTSTRAP_QUALIFICATION';parse='PASS';argv_and_exit='PASS';int64='PASS';formal_reserved_names='PASS';ps51_native='NOT_EXECUTED';platform=$PSVersionTable.Platform;ps_version=$PSVersionTable.PSVersion.ToString()}
$Report | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $EvidenceRoot 'BOOTSTRAP_PS7_RECEIPT.json') -Encoding UTF8
'BOOTSTRAP_PS7_PARSE_ARGV_EXIT_INT64=PASS; WINDOWS_PS51_PENDING'
