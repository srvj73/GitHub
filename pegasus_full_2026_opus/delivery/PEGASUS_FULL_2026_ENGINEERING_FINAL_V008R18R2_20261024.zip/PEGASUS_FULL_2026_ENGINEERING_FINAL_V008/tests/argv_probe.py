import sys,json,pathlib
values=sys.argv[2:]
passed=values==["space value",'literal"quote',"tail\\"]
pathlib.Path(sys.argv[1]).write_text(json.dumps({"pass":passed,"argv":values}),encoding="utf-8")
raise SystemExit(37 if passed else 38)
