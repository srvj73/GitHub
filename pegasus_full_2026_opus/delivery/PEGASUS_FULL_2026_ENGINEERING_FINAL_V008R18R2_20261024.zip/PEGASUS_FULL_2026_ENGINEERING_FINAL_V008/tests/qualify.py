"""Delta qualification: fail-fast, exact output bytes, faults and negative controls."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,time,unittest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'CODE'))

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def economic(out):
    return {p.relative_to(out).as_posix():sha(p) for p in sorted((out/'sessions').rglob('*')) if p.is_file()}|{'CHECKPOINT.json':sha(out/'CHECKPOINT.json')}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True,type=Path);n=ap.parse_args();out=n.out.resolve()
    if out.is_relative_to(ROOT):raise RuntimeError('SEALED_PACKAGE_OUTPUT_FORBIDDEN')
    out.mkdir(parents=True,exist_ok=False)
    report={'schema':'PEGASUS_OFFLINE_DELTA_V002','role':'CANDIDATE_PRODUCER','started':time.time(),'cases':[],'economic_full_executed':False,'windows_target':os.name=='nt','python':sys.version,'code_sha256':{p.name:sha(p) for p in (ROOT/'CODE').glob('*.py')}}
    def passed(name,**extra):report['cases'].append({'name':name,'result':'PASS',**extra});print(name+'=PASS',flush=True)
    def invoke(name,workers=1,fault=None,stop=False,baseline=False,reference=False,existing=None,expected=0):
        dest=existing or out/name;argv=[sys.executable,'-B',str(ROOT/'tests/synthetic_chain.py'),'--inputs',str(out/'inputs'),'--out',str(dest),'--workers',str(workers)]
        if fault:argv+=['--fault',fault]
        for flag,yes in [('--stop',stop),('--baseline',baseline),('--reference',reference)]:
            if yes:argv.append(flag)
        with (out/(name+'.log')).open('x') as log:
            p=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'})
            limit=time.monotonic()+180
            while p.poll() is None:
                if time.monotonic()>limit:raise RuntimeError('TIMEOUT_NO_KILL_RECONCILE_PID '+str(p.pid))
                try:p.wait(timeout=10)
                except subprocess.TimeoutExpired:print('TEST_HEARTBEAT='+name,flush=True)
            rc=p.wait()
        if (expected is None and rc==0) or (expected is not None and rc!=expected):raise AssertionError(name+' rc='+str(rc)+' see '+str(out/(name+'.log')))
        return dest,rc
    try:
        from r1r11_resources import grant_workers,process_identity,process_identity_live,process_memory
        from minotauro_v004_core import ModelError
        snap={'ram_mib':262144,'coordinator_private':1024**3,'shared_bytes':0,'cpu_logical':64,'external_heavy_workers':0,'independent_groups':40,'io_worker_limit':24}
        assert grant_workers(snap,24,1024**3)['granted']==24
        assert grant_workers({**snap,'independent_groups':1},24,1024**3)['granted']==1
        assert grant_workers({**snap,'io_worker_limit':2},24,1024**3)['granted']==2
        for invalid in (0,25,True,'24'):
            try:grant_workers(snap,invalid)
            except ModelError:pass
            else:raise AssertionError('bad request accepted')
        try:grant_workers({**snap,'ram_mib':1},24)
        except ModelError:pass
        else:raise AssertionError('zero memory admitted')
        passed('AUTOCPU_BOUNDS_CPU_RAM_IO_CAUSAL',hardware_24_workers_executed=False)
        ident=process_identity(os.getpid());assert process_identity_live(ident);assert not process_identity_live({**ident,'creation_time_100ns':ident['creation_time_100ns']-1});assert process_memory(os.getpid())['private']>0
        passed('PID_CREATION_TIME_REUSE_AND_MEMORY')
        from r1r11_fixtures import generate
        generate(out/'inputs',heavy_cycles=2)
        clean,_=invoke('reference_w1',reference=True);passed('FROZEN_MONO_CORE_VS_PRODUCTION_STREAM_BYTES')
        multi,_=invoke('multi_w3',workers=3)
        assert economic(clean)==economic(multi)
        sched=[json.loads(x) for x in (multi/'TELEMETRY/R1R11_TRANSPORT.jsonl').read_text().splitlines() if '"SCHEDULER"' in x]
        assert max(r['decision']['granted'] for r in sched)>1
        passed('WORKER_1_VS_MULTI_FULL_BYTE_EQUALITY',grants=[r['decision']['granted'] for r in sched])
        baseline,_=invoke('baseline_w24',workers=24,baseline=True,reference=True)
        sched=[json.loads(x) for x in (baseline/'TELEMETRY/R1R11_TRANSPORT.jsonl').read_text().splitlines() if '"SCHEDULER"' in x]
        assert all(r['decision']['granted']==1 for r in sched)
        passed('FROZEN_BASELINE_ONE_CAUSAL_GROUP')
        from r1r11_v4_transaction import FAULTS
        for point in FAULTS:
            dest,rc=invoke('fault_'+point,workers=2,fault=point,expected=None)
            before={p:sha(p) for p in (dest/'sessions').rglob('*') if p.is_file() and '.pending' not in str(p)}
            dest,_=invoke('resume_'+point,workers=3,existing=dest)
            assert economic(dest)==economic(clean),point
            assert all(sha(p)==h for p,h in before.items()),point
            passed('RECOVERY_'+point,first_rc=rc,committed_unchanged=True)
        crashed,rc=invoke('hard_crash',workers=2,fault='crash:after_commit_before_checkpoint',expected=87)
        crashed,_=invoke('hard_crash_resume',workers=3,existing=crashed);assert economic(crashed)==economic(clean)
        passed('PROCESS_EXIT_COMMIT_CHECKPOINT_GAP_RECOVERY',exit_code=87)
        stopped,rc=invoke('safe_stop',workers=2,stop=True,expected=130)
        cp=json.loads((stopped/'CHECKPOINT.json').read_text());assert len(cp['completed'])==2
        st=json.loads((stopped/'TELEMETRY/R1R11_STATUS.json').read_text());assert st['SAFE_STOP']=='YES' and st['PROCESS_TREE_CLEAN']=='YES'
        stopped,_=invoke('safe_stop_resume',workers=3,existing=stopped);assert economic(stopped)==economic(clean)
        passed('DOUBLE_SIGINT_COOPERATIVE_130_AND_RESUME_EXACTLY_ONCE')
        bad=out/'tampered';shutil.copytree(clean,bad)
        target=next((bad/'sessions').rglob('events.jsonl.gz'));target.write_bytes(target.read_bytes()+b'x')
        _,rc=invoke('tamper_blocked',existing=bad,expected=None);passed('COMMITTED_TAMPER_REJECTED',returncode=rc)
        changed=out/'identity_drift';shutil.copytree(clean,changed)
        cp=json.loads((changed/'CHECKPOINT.json').read_text());cp['config_sha256']='0'*64
        import minotauro_v004_runner as base
        base._write_checkpoint(changed/'CHECKPOINT.json',cp)
        _,rc=invoke('identity_blocked',existing=changed,expected=None);passed('CONFIG_FINGERPRINT_DRIFT_REJECTED',returncode=rc)
        from pegasus_entry import release_admission,Blocked
        for phase in ('B','C'):
            try:release_admission({'owner_authorized':True,'RUN_RELEASED':True},phase)
            except Blocked:pass
            else:raise AssertionError('effectful release admitted')
        passed('PHASE_B_C_RELEASE_FAIL_CLOSED')
        st=json.loads((multi/'TELEMETRY/R1R11_STATUS.json').read_text());assert st['PCT']==100 and st['PROCESS_TREE_CLEAN']=='YES' and isinstance(st['ETA'],(int,float))
        passed('PROGRESS_ETA_FINAL_TREE_RECONCILIATION')
        report['result']='PASS_OFFLINE_DELTAS';report['full_qualified']=False
    except BaseException as exc:
        report['result']='FAIL_STOP_CHAIN';report['error']=repr(exc)
        raise
    finally:
        report['seconds']=time.time()-report['started'];(out/'QUALIFICATION_RECEIPT.json').write_text(json.dumps(report,indent=2,sort_keys=True))
    return 0
if __name__=='__main__':sys.exit(main())
