import sys,site,json,pathlib,numpy,hashlib
prefix=pathlib.Path(sys.prefix).resolve(); module=pathlib.Path(numpy.__file__).resolve()
assert sys.prefix!=sys.base_prefix and site.ENABLE_USER_SITE is False
assert module.is_relative_to(prefix) and numpy.__version__=='2.4.6'
assert sys.version_info[:3]==(3,14,7)
pathlib.Path(sys.argv[1]).write_text(json.dumps({'executable':sys.executable,'version':sys.version,'numpy_version':numpy.__version__,'numpy_path':str(module),'numpy_init_sha256':hashlib.sha256(module.read_bytes()).hexdigest(),'prefix':str(prefix),'site_user':site.ENABLE_USER_SITE,'isolated':sys.flags.isolated},indent=2),encoding='utf-8')
