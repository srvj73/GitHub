"""Bounded synthetic qualification only. Uses production worker/commit path."""
from pathlib import Path
import argparse,hashlib,json,os,sys,time,signal
PACKAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKAGE/'CODE'))
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'

def run(inputs,out,workers=1,fault=None,stop=False,baseline=False,reference=False):
    from minotauro_v004_core import D1Bar,SessionEngine,valid_cells,BASELINE_CELL_ID
    from minotauro_v004_io import iter_tick_file
    import minotauro_v004_runner as base
    from r1r11_resources import RunLock,JobMemory
    from r1r11_coordinator import Runtime
    from r1r11_prefix import PhysicalPrefixTap
    from r1r11_v4_transaction import recover
    from r1r11_preflight_2026_resumable import _scan_month
    from ff_cutoff_r3_runtime import sidecar_from_calendar_row
    if not (inputs/'SYNTHETIC_ONLY.json').is_file(): raise RuntimeError('SYNTHETIC_MARKER_REQUIRED')
    if out.resolve().is_relative_to(PACKAGE): raise RuntimeError('OUTPUT_INSIDE_SEALED_PACKAGE')
    spec=json.loads((inputs/'FIXTURES.json').read_text());cases=[spec['warmup'],spec['cases'][3],spec['cases'][8]]
    cells=valid_cells();cells=[c for c in cells if c.cell_id==BASELINE_CELL_ID] if baseline else cells
    d1=D1Bar(**spec['d1']);out.mkdir(exist_ok=True,parents=True)
    keys=('spec_sha256','runner_sha256','grid_sha256','preflight_status_sha256','session_calendar_sha256','expected_sessions_sha256','source_inventory_sha256','run_source_binding_sha256','config_sha256','parser_version')
    fingerprint=hashlib.sha256((inputs/'FIXTURES.json').read_bytes()).hexdigest()
    code_hash=hashlib.sha256(b''.join(p.read_bytes() for p in sorted((PACKAGE/'CODE').glob('*.py')))).hexdigest()
    identity={k:hashlib.sha256((k+fingerprint+code_hash).encode()).hexdigest().upper() for k in keys}
    cp_path=out/'CHECKPOINT.json'
    with RunLock(out) as lock:
        memory=JobMemory(out/'TELEMETRY/memory.jsonl')
        # Small bounded synthetic workload reservation only; never exported to real B/C.
        memory.previous_worker_peak=256*1024**2
        rt=Runtime(lock,memory,workers,32,timeout=30,mode='SYNTHETIC')
        try:
            recover(out);cp=base._load_checkpoint(cp_path,'SYNTHETIC',cells,identity,{})
            done=set(cp['completed']);rt.verify_committed(out,cp);rt.configure_status(total=len(cases),committed=len(done))
            for ix,case in enumerate(cases):
                s=case['session'];p=(inputs/case['path']).resolve()
                if not p.is_relative_to(inputs.resolve()) or hashlib.sha256(p.read_bytes()).hexdigest()!=case['sha256']: raise RuntimeError('SYNTHETIC_INPUT_DRIFT')
                if s in done: continue
                row=_scan_month('B',p,[{'session_date':s,'expected_previous_session_date':d1.date}],0,p.stat().st_size,0,1,time.monotonic())
                if row['failures']: raise RuntimeError('SYNTHETIC_PREFLIGHT_FAILURE '+str(row['failures']))
                row=row['calendar_rows'][0];rt.set_synthetic_calendar_row(s,row)
                states=[cp[k] for k in ('cash','hwm','maxdd','regime_min','closed_hwm','closed_maxdd')]
                h=base._PrefixHashTracker();tap=PhysicalPrefixTap(h)
                eng=rt.engine(s,d1,cells,case['cutoff'],True,*states,{c.cell_id for c in cells},source_tracker=tap)
                oracle=SessionEngine(s,d1,cells,case['cutoff'],True,*states,{c.cell_id for c in cells},r3_sidecar=sidecar_from_calendar_row(row)) if reference else None
                rt.fault={'point':fault,'kind':'injected'} if fault and ix==1 and not fault.startswith('crash:') else None
                if fault and fault.startswith('crash:') and ix==1:
                    original_inject=rt.inject
                    def crash_inject(point):
                        if point==fault.split(':',1)[1]: os._exit(87)
                        original_inject(point)
                    rt.inject=crash_inject
                for rec in iter_tick_file(p,hasher=tap):
                    if stop and ix==1: signal.raise_signal(signal.SIGINT);signal.raise_signal(signal.SIGINT);stop=False
                    continuing=eng.process_record(rec)
                    if oracle is not None:
                        assert oracle.process_record(rec)==continuing
                    if not continuing: break
                result=eng.finish(rec.ordinal,rec.date_time)
                if oracle is not None:
                    ref=oracle.finish(rec.ordinal,rec.date_time)
                    from r1r11_worker import _enrich_cutoff_trade
                    for tr in ref.trades: _enrich_cutoff_trade(tr,row)
                    mapping={'trades':ref.trades,'events':ref.events,'equity':ref.equity_events,'equity_reconciliation':ref.equity_reconciliation}
                    refroot=out/'reference'/s;refroot.mkdir(parents=True)
                    for name,rows in mapping.items():
                        base.gzjson(refroot/(name+'.jsonl.gz'),rows)
                        assert (refroot/(name+'.jsonl.gz')).read_bytes()==Path(eng.stage_outputs[name]['file']['path']).read_bytes(),name
                    for k in ('end_cash_units','hwm_units','max_dd_units','regime_min_units','closed_hwm_units','closed_max_dd_units','trade_counts'):
                        assert getattr(ref,k)==getattr(result,k),k
                base._commit_session(out,s,result,cells,cp,done,row,cp_path,p,h,runtime=rt)
                rt.committed(len(done))
            rt.status('SYNTHETIC_COMMITTED',COMMITTED=len(done),TOTAL=len(cases))
        finally: rt.close()
    return 0

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--inputs',required=True,type=Path);ap.add_argument('--out',required=True,type=Path);ap.add_argument('--workers',type=int,default=1);ap.add_argument('--fault');ap.add_argument('--stop',action='store_true');ap.add_argument('--baseline',action='store_true');ap.add_argument('--reference',action='store_true');n=ap.parse_args()
    try:return run(n.inputs,n.out,n.workers,n.fault,n.stop,n.baseline,n.reference)
    except KeyboardInterrupt:
        st=json.loads((n.out/'TELEMETRY/R1R11_STATUS.json').read_text())
        if st.get('PROCESS_TREE_CLEAN')!='YES' or st.get('SAFE_STOP')!='YES': return 3
        print('SAFE_STOP=YES PROCESS_TREE_CLEAN=YES');return 130
if __name__=='__main__':sys.exit(main())
