# 00_SOURCE_MAP_AND_GATE_LEDGER — Evidência física e autoridade por categoria

## 1. Estado canônico no transporte (2026-10-08; não substituir política viva)

MASTER ativo no envio: v30, SHA `011CFB0CDD39E3B2ECC104A7B967330D2B29D84EA2A506E74A3ABB2B8D231FA2`, HEAD SHA `8DDDF99F206848471A6A27A9E37637CC51CAD8378C482C3CA3F7C3322A68A1C5`. Só `/POLITICA_CANONICA_ATIVA` vivo autoriza novos atos. Role `CANDIDATE_PRODUCER`; alterações canônicas em `/POLITICA_CANONICA_CANDIDATES` somente quando cabível; não tocar MASTER.

## 2. Fontes físicas

| Papel | Nome no pacote | SHA-256 esperado | Semântica |
|---|---|---|---|
| E01 original | EVIDENCE/E01_ORIGINAL_20261002.zip | `21189621F22C9E134E5E7F3887D5F9D012E290884FF42663933D94EE0CC1310A` | 559 membros, 558 manifest, CODE 474/474, captura sequencial NÃO atômica |
| Pós-PID_REUSE | EVIDENCE/E01_POST_PID_REUSE_20261008_RECONSTRUCTED.zip | `3757373881C20D8329E5D4C41B39D04BD25403BAA0453AEA51494CA9B64B8EC0` | 529 membros, 528 arquivos reconstruídos; é fixture de regressão, NÃO E01 original |
| C2 G4 | EVIDENCE/G4_C2_ADAPTER_CANDIDATE.zip | `1948D6F1EC6BBC75392264D12B1CFBC74D445E9EB96A520220BC9CB02165E19D` | identity `EC96FE9A020963EC8164F1C31B1AEBCEC148A68CB494F46CD634449D174B0C41`; 31 membros |
| QS0 G4 | EVIDENCE/G4_QS0_WINDOWS_PASS_RESULT.zip | `691DC60C41318AE0BD9C561443D8E7B7E7C499AD05375FC7FCF69ACEE0E06384` | QS0 nativo 46/46 |
| QS1 WSL V001 | EVIDENCE/WSL_V001_BLOCKED_RESULT.zip | `EBE11197A845BBF30E95F4B3AA05808863C1B184CD08735C5D5DBAA0BC049152` | RC=2, Bash CRLF pipefail, QS1 não iniciado |
| QS1 WSL V001R1 | TOOLS/RUN_PEGASUS_QS1_G4_WSL_ISOLATED_V001R1.pyz | `B85A9D5098D6D69BBB6ABD942848D6D6E8976520740D0876457576CDFFA3BFE9` | 29/29 controles offline; QS1 G4 terminal ainda pendente |

## 3. Resultados e limites

- G4 QS0 `PASS_NATIVE_46_OF_46` Windows PS5.1, preservado. NÃO repetir.
- QS1 G2 Linux: 47 métodos rápidos + T14F 1 + classificação adversarial 5 = **53 métodos PASS** em execuções segmentadas; 19 mutantes rejeitados em grupos. Não é recibo terminal `MINOTAURO_PHASE_B_ADAPTER_QS1_RECEIPT_V002`.
- H1–H16 no Windows PS5.1: 16/16 PASS na identidade G2 histórica, com recibos de processos conciliados. Não equivale ao método Linux do harness no QS1 G4.
- QS1 G4 Q07 executado 2/2 PASS, e paridade 10/10 de superfícies de produção G2→G4. QS1 G4 `NOT_QUALIFIED` até receipt oficial V002 para 55 métodos.
- Histórico QS4 Shadow: 24/24 casos e 45/45 steps no attempt original reconciliado. Esse QS4 não autoriza QS4 desta nova identidade nem prova `AUTOCPU_24`.
- Dados/contrato: `last>0 AND volume>0` business, não usar quotes OTHER como execução business; pregões 2026-01-05 permanece sessão esperada; R3 economic rules FROZEN, `RESELECTION_2026=FORBIDDEN`.
- C2 G4 code atual `workers=15`, `release_stage=QUALIFICATION_ONLY_RUN_DISABLED`, `RUN_RELEASED=NO`, `run_growth_bytes=1900518140`, 8 arquivos tick em G16; espaço mínimo estimado no preflight de 166 sessões `6,775,296,244` bytes, sujeito à revalidação de volume e fontes.
- QS2 read-only alvo e QS3 dry substantive não executados; não inferir PASS de QS0/QS1. QS4 novo e QS5 R01–R06 pendentes. `AUTOCPU24=NOT_QUALIFIED`, `SAFE_STOP=NOT_PROVEN`, `FULL=NOT_AUTHORIZED`.

## 4. Caminhos Windows históricos, nunca substituir por aproximações

- Downloads operacional: `C:\Users\silvi\OneDrive\Downloads` (arquivo E01 original também foi localizado historicamente sob `C:\Users\silvi\Downloads\MB_1dc320af7276\WORK`, mas não mudar o padrão de novos downloads).
- Python: `C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe`, versão 3.14.7; Windows PowerShell 5.1 Desktop.
- R3 release: `D:\MinotauroRuns\MINOTAURO_R1R11_FULL_2026_R3_FIXABC_V001` e `D:\MinotauroRuns\MINOTAURO_R1R11_FULL_2026_R3_RELEASE_20261001`; **read-only/admission**, não sobrescrever.
- Parent 2025: `D:\MinotauroRuns\MINOTAURO_R1R11_PERF_NEXT_V003R1_W15_B256_20260929`.
- IND: `D:\Base CSV\IND@N\IND@N.csv`, SHA `36D97467E7CBD37197E5071E67F4E7CB669C53863E1683FA7E350D46D6CB7A39`.
- Phase A extract: `D:\MinotauroRuns\MINOTAURO_R1R11_PERF_NEXT_V003R1_W15_B256_20260929\PHASE_A\D1_PREDECESSOR_EXTRACT_PHASE_A.csv`, SHA `3D7220067E25E8F113A3C213DD4D774CDDD88DD934CDC944F861B895DFC645D3`.
- Dados WIN ticks: `D:\Base CSV\WIN@N`; não varrer/apagar/mover massas desnecessariamente.

## 5. Critérios de admitir pacote

Verificar SHA e CRC dos ZIPs, 558/558 E01, 528/528 da captura reconstruída, candidato 29/29, recebimento do RESULT QS0 Windows e política ao vivo. Checar a cadeia de custódia FIXB/PID_REUSE por registros e módulos, não usar a captura reconstruída como E01 original. Se evidência incompleta: BLOCKED preciso, não inferir.
