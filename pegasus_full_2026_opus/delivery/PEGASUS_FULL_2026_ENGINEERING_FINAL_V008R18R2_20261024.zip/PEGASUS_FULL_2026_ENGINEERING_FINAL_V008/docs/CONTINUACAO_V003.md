# Continuidade V002 → V003: causas, correção e fronteira de qualificação

Data: 09/10/2026. Superfície: Work; papel CANDIDATE_PRODUCER. Modelo/esforço não verificáveis independentemente da interface. Sem troca de superfície/modelo deliberada; sem subagentes, auditor externo ou autorização de créditos pagos.

## 1. Fontes e continuidade

O parent operacional é o ZIP V002 SHA-256 `4A0C775DC94AC46510BD37AC6792CE611474254C6CD1CDD7867AF035CF74EF56`. Uma cópia temporária foi encontrada incompleta (162.749.440 bytes; ZIP inválido); foi preservada e não utilizada como fonte. Recuperou-se da identidade já conhecida o ZIP original de 172.826.090 bytes com o SHA esperado. Essa ocorrência não prova defeito no candidato original nem explica o PENDING histórico.

A árvore desta revisão foi materializada diretamente do payload V002 já autenticado, SHA `2659FAD60696A065BBBCEB380BA46AAE982A592D03163EE6163AADFB18C84F22`, em diretório novo. Nenhuma reconstrução do V002 a partir de resumos e nenhum rerun de suas suítes ocorreu. O manifesto e documentos de identidade antigos estão em `receipts/V002_PARENT`; os recibos históricos de execução não foram reescritos. Documentos antigos continuam como histórico, e este documento com o GATE_LEDGER define o estado desta revisão.

A instrução atual do usuário autoriza a continuidade da engenharia dentro dos limites existentes. O handoff anterior de leitura continua válido como registro da investigação já concluída; não é interpretado como autorização de recovery. O novo trabalho é exclusivamente a correção independente demonstrada de lifecycle e consolidação para revisão.

## 2. Reconciliação do entrypoint

A suíte final registrou SHA `1E260BD3B5F0168C7806D848CB6B096ACF651D92461E7777A30DBAF1BB8542A5`; o empacotado é `F77B52669FF5D98BD9D8AC7AFBFB1483BF8CAE3AA7CB61F5242830BF3E43A7FB`. A diferença era conhecida pelo FINAL_SOURCE_RECONCILIATION e não permite herdar PASS integral.

O achado complementar, porém, não incluía todo o fechamento externo: FINAL_ENTRYPOINT_RECEIPT.json vincula o segundo SHA e registra verify, negativas run-b/run-c/run-full e negativas de owner flags B/C. Esse recibo foi recuperado dos bytes do ZIP original e incorporado sem alteração em `receipts/V003_DELTA/parent_outer`. Não repetimos esses seis controles. O entrypoint continua byte-idêntico; a nova verificação de transporte usa somente verify sobre o novo conjunto selado, sem repetir a auditoria funcional.

Assim, fecha-se a lacuna de localização/binding da evidência específica do entrypoint. Não se fecha o gate de qualificação integrada. O veredito da suíte final permanece 7 PASS + FAIL_STOP_CHAIN; os 18 PASS da identidade anterior mantêm seu escopo anterior.

## 3. Defeito independente comprovado em entrada de lock

Precondições: módulo parent pinado, root novo fora do pacote, dependências locais completas, sem processo econômico, sem chamadas reais de recover, sem alteração de roots históricos. Um stub substituiu recover e lançou exceção após a criação do RUN.lock. Outro caso lançou durante a limpeza de scratch; outro simulou KeyboardInterrupt.

Em todos, o corpo with não foi executado; o handler de __enter__ liberou o mutex, mas deixou RUN.lock e owned=True. A linguagem Python só garante __exit__ após retorno bem-sucedido de __enter__. Referência primária consultada: https://docs.python.org/3/reference/compound_stmts.html#the-with-statement. Essa semântica, junto ao probe físico, explica o defeito específico. Nenhum erro de filesystem foi necessário para reproduzi-lo.

A correção adiciona `_abort_enter(primary)` nos dois ramos de plataforma. O helper chama o cleanup já existente de __exit__ enquanto o mutex ainda é owned. Esse cleanup verifica run_instance antes de excluir o lock; se a identidade mudou, preserva o arquivo. Se a limpeza também falha, o erro secundário é registrado em uma nota da exceção primária; a exceção primária continua sendo propagada. Não se modifica recover, commit, assinatura, layout econômico, checkpoint, stale-lock admission nem exclusão de scratch.

SHA parent de r1r11_resources.py: `C7F6278306875BC442C741176937304BC5507713D6A504F864A40C7B7331733F`.
SHA corrigido: `719988E114ACC60236E7D9FFC23F7C59BC1C48B13822E8DDDA79200A21E1801E`.
O patch legível está em `receipts/V003_DELTA/RUNLOCK_DELTA.patch`.

## 4. Evidência nova e limites

| Grupo | Resultado | Escopo |
|---|---|---|
| Caracterização parent | 6 observações esperadas | Três tipos de falha na entrada; identidade estrangeira; saída normal/exclusão mútua; lock vivo preexistente |
| Delta corrigido | 8 controles PASS | Mesmos caminhos relevantes, mais falha de unlink e falha reportada ao liberar mutex; causa primária preservada |
| Controle negativo | PASS: vazamento detectado | Substituição em memória do helper por liberação apenas do mutex; arquivo-fonte intacto |
| Compilação dos bytes novos | Ver recibo de build | Sintaxe, sem importação econômica ou execução de suíte |
| Bootstrap derivado | Ver recibo externo | Payload/pins regenerados; funções de lançamento comparadas ao parent; parse PS7 somente |

Os testes de lifecycle importam as dependências do módulo, mas substituem recover antes da entrada; nenhuma lógica econômica ou recuperação transacional é executada. A qualificação física é Linux/Python 3.12.14. A mudança atinge o ramo Windows pelo helper comum, mas isso não constitui teste do mutex Win32 nem homologação Python 3.14.7. A falha durante escrita parcial do JSON antes de owned=True permanece fail-closed para reconciliação; não é coberta como limpeza bem-sucedida pelo patch. Falha de cleanup deixa nota e pode preservar resíduo: não declarar filesystem limpo nesses casos.

O script de controle negativo incluído é a forma parametrizada do comando aplicado nesta investigação; sua inclusão não representa uma nova execução. O script de lifecycle é o executado nos probes. Receipts e fontes dos testes são vinculados pelo manifesto de qualificação delta. Os oito controles não contam como oito testes da suíte FULL.

## 5. Por que os resíduos históricos continuam abertos

Os logs de suite_final mostram processamento e status final; não registram uma exceção de __enter__ responsável pelos resíduos capturados. Portanto, encontrar um defeito capaz de deixar lock em outro cenário não prova a causa desses RUN.lock concluídos e muito menos a duplicidade pending/journal.

A investigação anterior já comparou 167 arquivos em três superfícies, validou as assinaturas e identificou dois arquivos de conteúdo igual com identidades runtime distintas. A igualdade de hash não distingue sobrevivência de um inode antigo de cópia/recriação. O status PROCESS_TREE_CLEAN precede a saída do contexto e não comprova unlink nem captura atômica.

Continuam ausentes: operações originais rename/unlink/rmtree com PID+criação+boot/namespace e retornos; inventários no instante da asserção; identidade da fonte e fronteira de congelamento/cópia. Não houve nova fonte histórica que preenchesse esses campos. Não se repetiu o probe PENDING, não se apagaram arquivos, não se alterou recover nem se declarou causa race/overlay/filesystem. ROOT_CAUSE_NOT_PROVEN permanece.

## 6. Launcher e uso posterior

O bootstrap derivado continua autocontido, autoextrai em root novo e mantém as funções de argv, watchdog e propagação de exit do parent. A única redução funcional é a allowlist de modos para Verify; o ramo que iniciava a suíte foi retirado do launcher. Essa restrição implementa a suspensão já documentada, sem conceder autorização nova. Fontes e wheels da qualificação futura permanecem presentes para revisão.

A instrução local executável não é emitida nesta entrega porque a finalidade atual é revisão técnica e a qualificação PS5.1 nativa permanece pendente. O auditor pode ler todos os bytes e o bootstrap sem executá-lo. Nenhum launcher deve ser interpretado como autorização FULL.

## 7. Estado e próxima decisão

Engenharia incremental implementada e delta Linux qualificado. O restante do código, os testes anteriores, o núcleo G4, os históricos e evidências são preservados; os manifests/identidades derivadas são regenerados e vinculados. A política permanece FROZEN; a correção foi registrada como candidate não autoritativo no inbox canônico, sem mudar o MASTER.

O ChatGPT de origem deve revisar a correspondência causa→patch→probes e a suficiência dos limites; não tratar esta autorrevisão como B06. Os bloqueios não demonstrados permanecem no ledger. O despacho a auditor externo como READY continua bloqueado por gates técnicos e de recursos não satisfeitos; não foi realizado. A disponibilização ao usuário para revisão do trabalho parcial não promove release nem implica gasto externo.
