# PARECER V002 — FECHAMENTO DO DESENHO PHASE B COM O E01 · MINOTAURO 2026

```text
OPUS55_PHASE_B_REAUDIT=PASS
WORK_VERDICT_CONFIRMED=YES
LIVE_POLICY_RECHECK=UNAVAILABLE_EXTERNAL_TRANSFER
PACKAGE_INTEGRITY=PASS
ROOT_CAUSE_CHAIN=FULLY_CLOSED
SOLUTION_DESIGN_AUDIT=PASS
IMPLEMENTATION_AUTHORIZED=YES
NEW_EFFECTFUL_RUNNER=NO
PHASE_B_READY_FOR_FULL=NO
PHASE_C_EXECUTION=NO
RESELECTION_2026=FORBIDDEN
```

```text
QUALIFICADORES OBRIGATÓRIOS DO BLOCO ACIMA
OPUS55_PHASE_B_REAUDIT=PASS        ⇒ reauditoria e gate de desenho fechados; NÃO é prontidão de execução
ROOT_CAUSE_CHAIN=FULLY_CLOSED      ⇒ cadeia causal estática/de desenho fechada com 27/27 módulos lidos
DYNAMIC_COVERAGE=NOT_YET_PROVEN    ⇒ S11–S20 jamais executadas em B; QS3 e QS4 são obrigatórios
IMPLEMENTATION_AUTHORIZED=YES      ⇒ gate técnico liberado SOMENTE para o envelope V001; exige ordem explícita do owner;
                                     execução effectful NÃO autorizada; auditoria pré-entrega obrigatória
CHANGE_ENVELOPE=CHANGE_ENVELOPE_PHASE_B_ADAPTER_V001.json (SHA-256 no MANIFEST do pacote de retorno)
DD-1..DD-6=CLOSED_BY_BYTES | DD-7..DD-9=OWNER_DECIDED | DD-10=ACCEPTED_WITH_CONDITIONS
```

```text
PROJECT=Pegasus Original | THREAD=Implementação Runner Paralelo 4
AUDITOR=Opus 5.5 (claude-opus-5-5) | MODO=READ_ONLY | DATA=2026-10-02
PREDECESSOR=AUDIT_OPUS55_MINOTAURO_PHASE_B_REAUDITORIA_END_TO_END_V001_20261002.md (SHA 9AAFA075…)
E01=MINOTAURO_PHASE_B_READONLY_RESULT_RUN_20261002_134312_993_15644.zip
E01_SHA256=21189621F22C9E134E5E7F3887D5F9D012E290884FF42663933D94EE0CC1310A
SNAPSHOT_MASTER_SHA256=D5EBEA05ABF0D8AE822BC7381EE67A0112FB25CC8BBC8652770ED67DB41F1C35 (transferência; não live)
EXECUTADO=verificação integral do E01; leitura de 21 módulos antes ausentes; closure + grafo de chamadas; 9 grupos de probes em sandbox (Anexo B)
NÃO_EXECUTADO=qualquer runner, wrapper, bootstrap, Phase B/C | PC_TOCADO=NO | CODE/PREFLIGHT_ALTERADOS=NO
```

**Rótulos:** `FATO` (bytes do E01 ou do handoff) · `CÁLCULO` (recalculado por mim) · `INFERÊNCIA` · `HIPÓTESE` · `NÃO_VERIFICÁVEL`.

**Notação de linhas** (todas em arquivos do CODE do E01, SHA conferido contra `SHA256SUMS.txt`): `full` = `r1r11_full_2026.py`; `runner` = `minotauro_v004_runner.py`; `tx` = `r1r11_v4_transaction.py`; `res` = `r1r11_resources.py`; `coord` = `r1r11_coordinator.py`; `fr` = `r1r11_fast_resume.py`; `out` = `minotauro_v005r1_r23_outputs.py`; `io` = `minotauro_v004_io.py`; `pre` = `minotauro_v004_preflight.py`.

---

## 0. Decisões recebidas do owner (registradas sem alteração)

```text
DD-7=SAFE_STOP_SHADOW_REAL_DATA_QUARANTINED_HASH_ONLY
DD-8=TICK_FULL_REHASH_BEFORE_EACH_DRY_RUN_AND_RUN=AUTHORIZED
DD-9=ANTIVIRUS_BROAD_EXCLUSION_NOT_AUTHORIZED; FAIL_CLOSED; narrow temporary owned-directory exclusion may be proposed later only if physically demonstrated necessary
```

---

## 1. Integridade do E01 — `CÁLCULO`

| Verificação | Resultado |
|---|---|
| SHA-256 do ZIP | `21189621…10A` = valor esperado |
| CRC e caminhos | PASS. 559 entradas, separador `\` normalizado, sem escape de raiz, sem colisão case-insensitive |
| Manifesto | 558/558 hashes conferidos; conjunto exato |
| Inventário do coletor | 549/549 `CAPTURED`, com `sha256 = post_sha256` = bytes do payload |
| CODE | 474/474 + `SHA256SUMS.txt` = `FA4E2BE1…`, sem extras; manifesto byte-idêntico ao `G8_CODE_SHA256SUMS.txt` do V003 |
| Fontes do handoff anterior | Os 8 fontes presentes no handoff são idênticos aos do E01 |
| CONTROL | 23 arquivos e 4 diretórios (27 entradas no snapshot de árvore); os 21 artefatos são iguais à tabela do Work |
| PREFLIGHT | 16 arquivos em `PHASE_B` (7 obrigatórios + `PREFLIGHT_CHECKPOINT.json` + 8 `MONTH_RECEIPTS`) e **`_TMP_SAME_VOLUME_PHASE_B/_avast_`** (dois diretórios vazios — ver N-17) |
| Identidades cruzadas | G8 local receipt `1A28413B…`, G8 evidence `1F5732B0…`, homologação do pai `A0BD69C2…`, freeze `B56315F5…`, IND `36D97467…` = `binding.ind_d1_sha256` |

```text
PACKAGE_INTEGRITY=PASS
```

---

## 2. Fechamento de DD-1 a DD-6 por leitura física

| DD | Questão | Evidência física (linhas) | Probe | Resolução e consequência para o desenho |
|---|---|---|---|---|
| **DD-1** | Contrato de retorno de `_load_d1_extract` e consumo | runner:147-151: `rows=cal(path)`; `len(rows)!=250` ⇒ erro; retorna `{r["session_date"]: r}`. `cal` (runner:113-115) usa `csv.DictReader(utf-8-sig, ';')`. `_verify_d1_bar` (runner:154-167) lê `er["expected_previous_session_date"]` e `int(er[open/high/low/close_micro])` | PX1 | **FECHADO.** Tipo `dict[str, dict[str,str]]`. A substituta B reutiliza `base.cal(path)` e a mesma compreensão, logo a forma é idêntica por construção. Unicidade/ordem (W02): ausentes no legado, **confirmado byte a byte** (duplicata aceita e colapsada em 249) |
| **DD-2** | RunLock purga scratch antes do recovery B? O recovery depende do scratch? | res:317-318: `recover(self.root)` (raiz CONTROL); res:319-329: purga **todo** `CONTROL/_scratch`. `tx:123-124`: a raiz só recursa em `PILOT_A`/`PHASE_A`, portanto o journal B **não** é tratado ali. O recovery B ocorre depois, em full:306. Protocolo tx:53-115: journal → pending → seal → `rename(pending, final)` → checkpoint → apaga journal. O journal referencia apenas `po/sessions/<s>(.pending)` e o checkpoint, nunca o scratch | PX5, PX5b | **FECHADO.** A ordem do W07 está **confirmada**, mas o **risco é refutado**: roll-back (remove pending) e roll-forward (`validate_tree(final)` + checkpoint next) independem do scratch nos três estágios testados. Mesmo assim, para satisfazer literalmente o critério "recovery B antes de qualquer purga", o desenho adota **PRE_RECOVER_B** sob o mutex nominal R1R11 (§5.3, G21); a 2ª chamada em full:306 é no-op (PX5b) |
| **DD-3** | Escritas de checkpoint e anchor; ordem do commit | runner:320-339: checkpoint ausente ⇒ cria e grava; presente ⇒ **somente leitura**. fr:47-56: `write_anchor_checkpoint`/`clear_anchor_checkpoint` gravam o checkpoint. fr:8-16: fingerprint = path, st_dev, **st_ino**, size, mtime_ns. tx:93→114: ordem durável, com checkpoint depois do commit | PX4 | **FECHADO.** Um dry-run sobre CONTROL é impossível sem mutação, o que exige shadow. Resume após SAFE_STOP exige o mesmo arquivo de tick físico (mesmo inode/mtime): mover ou copiar ticks bloqueia (fail-closed) |
| **DD-4** | Formato do manifesto mestre | out:318-326: linhas `SHA  rel` ordenadas por caminho com `/`, SHA maiúsculo, `newline="\n"`; exclusões em full:280 (CHECKPOINT, `*.tmp`, o próprio manifesto, FINAL) | — | **FECHADO.** O validador de FINAL recomputa exatamente esse conjunto e formato |
| **DD-5** | Semântica de Ctrl+C | res:27-35: o coordenador **reabilita** Ctrl+C e instala `default_int_handler` (KeyboardInterrupt em qualquer ponto). Workers e helpers ignoram SIGINT (worker:123; stream:368) e terminam por morte do pai (worker:26-28, 168, 228). Em `close()` cooperativo, se um worker não para em 120 s ⇒ `SAFE_STOP_WORKER_COOPERATIVE_TIMEOUT`, sem terminate (coord:334-337) | — | **FECHADO.** Uma interrupção no meio do commit deixa journal, resolvido pelo recovery. SAFE_STOP=YES exige prova do próprio runtime (§5.6) |
| **DD-6** | `build_expected`, `_validate_d1`, `write_csv` | pre:40-60: predecessor = sessão M1 anterior (histórico desde 2024-01-01). pre:63-74: `_validate_d1` verifica presença e sanidade OHLC, **não** a identidade com o calendário. io:214-220: `write_csv` com `newline=""` e terminador `\n` (LF, sem BOM). `SPEC_HASH`/`RUNNER_HASH` usam `write_text` sem `newline` (CRLF no Windows) | PX3 | **FECHADO.** Extract D1 é reproduzível e independente de plataforma (`610841D8…`); SPEC e RUNNER dependem da plataforma (N-15 confirmado). A cadeia de autoridade D1 é M1 → EXPECTED → calendário → extract → IND; o contrato D1-B cobre cada elo |

| DD | Resolução |
|---|---|
| DD-7, DD-8, DD-9 | Decididos pelo owner (§0) e incorporados |
| **DD-10** | **ACEITO COM CONDIÇÕES.** Para IN_PROGRESS, o dry-run executa em CONTROL apenas validadores congelados somente leitura (`_load_checkpoint` com checkpoint presente, `_verify_committed_trades_present`, `Runtime.verify_committed` como função não vinculada com objeto mínimo que expõe só o caminho de TELEMETRY, `_session_prefix_expectations`, `validate_fingerprint` e `rehydrate_prefix_tracker`), mais G00–G18. Condições: QS4 (T16–T18) PASS no mesmo código; o RUN repete todo o caminho e permanece fail-closed |

---

## 3. Closure estática completa — `CÁLCULO`

| Medida | Valor |
|---|---|
| Arquivos `.py` na raiz do CODE | 64 |
| Closure a partir de `r1r11_full_2026` (imports em qualquer escopo) | **27** (= Work; 27/27 agora lidos) |
| Imports dinâmicos | 1 (`__import__('math')`, out:111), benigno |
| Funções alcançáveis a partir das entradas B + alvos de spawn (`worker_main`, `stream_main`), por grafo sobre-aproximado | **271** |
| Ocorrências no código alcançável com regex ampliada (inclui `12`, `249/251/252`, `'A'`, `phase==`, `range(1,13)`) | **25** |

| Classificação das 25 ocorrências | Qtde | Exemplo | Efeito em B |
|---|---:|---|---|
| **Defeito ativo** | 1 | runner:149 `len(rows) != 250` | Coberto por SEAM-D1 |
| Fallback A fail-closed | 3 | coord:445-463 | Inalcançável com sucesso sem `CONTROL/PHASE_A`; gate G12 |
| Identidade intencional do pai 2025 | 2 | full:71, 75 | Preservar |
| Ramos B-cientes | 4 | full:235-286 (8 meses, `2026-01..08`) | Corretos para B |
| Rótulo de modo | 4 | res:187-190 (`RUN_B` em res:191) | Correto |
| Recursão A em `recover(raiz)` | 1 | tx:123 | Inócua para B; G21 cobre a ordem |
| Faixas de fase / janela histórica de predecessor | 2 | pre:8, 45 | Corretas |
| Nomes de artefato A em mapas não usados em B | 5 | contract:19-23, 99; binding:32-33 | Nenhum uso alcançável |
| Literais de grade e numéricos | 3 | core:23, 25 (`12` ticks), core:135 (ε) | Não são cardinalidade |

**Conclusão:** o único pressuposto Phase A **ativo** no caminho B é o loader D1. Não há outro.

**Correção C-1 ao V001.** O V001 afirmou que os workers não importam `minotauro_v004_runner` "pela closure". A closure transitiva do worker, com imports em escopo de função, **inclui** o runner. A justificativa correta é o local de chamada: `_load_d1_extract` só é chamado em full:297 (B) e runner:580 (A); nenhum processo filho executa esses pontos. A conclusão (o seam não precisa sobreviver ao spawn) permanece válida.

---

## 4. Atualização dos achados

| ID | Estado V001 | Estado V002 | Base |
|---|---|---|---|
| W02 (unicidade/ordem do loader) | NOT_VERIFIABLE | **CONFIRMED** byte a byte | runner:147-151; PX2 T01 |
| W07 (recovery/purge) | PARTIAL | **CONFIRMED (ordem) / RISCO REFUTADO** | res:317-329; PX5 |
| N-03 (D1 in-run tautológico) | CONFIRMED (estático) | **DEMONSTRADO** | PX2 T09b: calendário adulterado ⇒ `_verify_d1_bar` congelado passa; o contrato D1-B bloqueia |
| N-04 (identidade ligada ao caminho) | ALTA | **AMPLIADO** | Inclui também o mutex nominal (res:269), `journal.out_root`/`checkpoint_path` (tx:87-89, 135-138), `RUN.lock` e `STATUS.out_root` |
| N-11 (bytecode nos filhos) | INFERÊNCIA | **REFINADO** | Spawn via contexto `spawn` (coord:100). O audit hook do worker (worker:133-148) converte escrita de `.pyc` **após** o hook em exceção (falha ruidosa), mas imports **antes** do hook podem escrever `.pyc` em silêncio ⇒ T27 permanece |
| N-12 (antivírus) | HIPÓTESE | **FATO** ⇒ ver N-17 | |
| N-01, N-02, N-05–N-10, N-13–N-16 | — | Confirmados pelos bytes; tratados no desenho | |

### Achados novos do E01

| ID | Sev. | Achado | Evidência | Tratamento |
|---|---|---|---|---|
| **N-17** | MÉDIA | O antivírus criou fisicamente `PREFLIGHT\_TMP_SAME_VOLUME_PHASE_B\_avast_` (diretório vazio dentro de um temporário próprio do run). Se ocorrer dentro de `po/sessions/<s>.pending`, `po/sessions` ou `_scratch`, os gates congelados falham fechados: `TRANSACTION_FILES_MISMATCH` (tx:35), `SESSION_CHECKPOINT_WITHOUT_JOURNAL` (full:309; tx:159), `UNKNOWN_SCRATCH_ENTRY` só para arquivo (res:325-326). O risco é **BLOCKED no meio do run**, não corrupção silenciosa | `TREE_SNAPSHOTS.json` do E01 | DD-9: fail-closed; o par vazio é fixado como extrínseco imutável (nunca apagado); T30 monitora em QS3/QS4; exclusão estreita só com demonstração física |
| **N-18** | BAIXA | `grant_workers` exige `ram_mib == 64704` (res:152-153); qualquer mudança de RAM bloqueia na criação do engine | `FATO` | Exercido pelo DRY até BND |
| **N-19** | INFO | `r1r11_v4_custody.sha` devolve hexa **minúsculo** (custody:16-18); `sha256_file` do contract devolve **maiúsculo** (contract:115-123). O protocolo é internamente coerente | `FATO` | O validador do adapter nunca mistura as duas grafias |
| **N-20** | INFO | Os testes históricos `test_full_2026_v001.py` apenas inspecionam strings do fonte | `FATO` | Não contam como prova (confirma o Work) |

---

## 5. Desenho final V002

Deltas sobre o §5 do V001.

### 5.1 Componentes

```text
CODE congelado (474, FA4E2BE1, runner 0ACDD45F) ← 0 bytes alterados; verificado antes/depois; sem __pycache__
PHASE_B_ADAPTER_V001 (identidade própria, fora do CODE)
  phase_b_entry     CLI: classify-b | dry-run-b | run-b | status-b ; imports de topo só stdlib; main guard
  phase_b_state     classificador (5 estados), somente leitura
  phase_b_contract  D1-B, config, PREPARED, FINAL, entradas, rehash de ticks
  phase_b_shared    executor de gates G00–G24, shadow, seams, mutexes, tee de stdout para trace
  phase_b_effects   inventário por conteúdo (BEFORE persistido), diff, receipts, mapa de exit
  phase_b_constants.json  todas as identidades do envelope (hash-bound)
```

**Requisito de import-safety.** No spawn, os filhos reimportam o módulo principal como `__mp_main__`. Por isso:

- nenhum módulo do adapter pode ter efeito em import;
- `phase_b_entry` não importa o CODE no topo;
- todo o trabalho fica sob `if __name__ == "__main__"`.

### 5.2 Seams (lista fechada)

| Seam | Modo | Alvo | Contrato |
|---|---|---|---|
| **SEAM-D1** | DRY + RUN | `minotauro_v004_runner._load_d1_extract` (chamado por atributo em full:297) | Recusa qualquer path ≠ `<root>/PHASE_B/D1_PREDECESSOR_EXTRACT_PHASE_B.csv`. Lê `rows=base.cal(path)`, executa o contrato D1-B (§5.4) no momento do uso e devolve `{r["session_date"]: r for r in rows}`. Instalado imediatamente antes de `run_phase` e restaurado em `finally`. Afirma a identidade do objeto original antes e depois |
| **SEAM-PPR** | DRY + RUN | `r1r11_coordinator.ParallelSession.process_record` (chamado em full:372) | **DRY:** a 1ª chamada levanta `PreProcessRecordBoundary(BaseException)` = **BND**. **RUN:** a 1ª chamada verifica o trace normalizado contra o template do DRY e as invariantes de estado, restaura o objeto original e delega; divergência ⇒ `TraceGuardMismatch(BaseException)` antes de qualquer `process_record` |
| SEAM-INTERRUPT-AFTER | **só qualificação** | Funções congeladas listadas em QS4 | Chama a original e depois levanta KeyboardInterrupt |
| SEAM-FAULT | **só qualificação** | `Runtime.fault_at` | Ativa os pontos de falha congelados (`tx:12-14`) |
| Qualquer outro patch | — | — | **FORBIDDEN**; o conjunto de atributos alterados é afirmado em tempo de execução |

### 5.3 Ordem de gates V002 (caminho compartilhado)

| Gate | Conteúdo | Efeito |
|---|---|---|
| G00 | argv exato; fase literal `B`; nenhum entrypoint genérico | R |
| G01 | Mutex do adapter `Global\MinotauroPhaseBAdapter_<sha256(release_root casefold)>`, sem espera | R |
| G02 | `sys.flags.dont_write_bytecode==1` e `PYTHONDONTWRITEBYTECODE=1` (lançado com `-B`, de modo que os filhos herdam a flag) | R |
| G03 | Runtime pin (`4942B86A…`, 3.14.7, numpy 2.4.6 e origem) | R |
| G04 | Autoridade: pacote vinculado ao MASTER live na entrega; RUN exige receipt de recheck live | R |
| G05 | Pacote do adapter: payload exato e identidade | R |
| G06 | CODE exato (474, sem extras), `full.verify_package()`, `runner_identity` = `0ACDD45F…`, `EXPECTED_*` | R |
| G07 | Receipts G8 (`1A28413B…`, `1F5732B0…`) | R |
| G08 | `PHASE_B_OWNER_AUTHORIZATION.json` (`5553C064…`), somente leitura; RUN exige autorização nova vinculada ao pacote | R |
| G09 | `validate_parent_2025()` = freeze `B56315F5…`, `NO_CANDIDATE`, células `[P02_T02_R02_M00]` | R |
| G10 | Config: bytes `08BF21D6…` + conjunto de 10 chaves + domínio JSON; ausente ≠ `null` | R |
| G11 | BEFORE: inventário por conteúdo de CONTROL (inclusive diretórios), PREFLIGHT, CODE, adapter e metadados de entrada, persistido em `<evidence_root>` | W (evidência própria) |
| G12 | Classificação de estado + invariantes (sem `CONTROL/PHASE_A`; PHASE_C vazio; sem `RUN.lock` vivo; nenhuma entrada desconhecida, inclusive `_avast_`, dentro de CONTROL; regras do *adapter run binding*) | R |
| G13 | PREFLIGHT exato: 16 arquivos fixados, `MONTH_RECEIPTS`, par vazio extrínseco fixado (N-17); `PHASE_STATUS` PASS/166; `PREFLIGHT_CHECKPOINT` PASS com 8 arquivos | R |
| G14 | Entradas: SHA do IND = `36D97467…` (obrigatório em PREPARED/IN_PROGRESS); inventário M1 2024-01..2026-08 (caminho, tamanho, SHA); metadados dos 8 ticks (inclusive file ID) | R |
| G15 | Contrato D1-B sobre PREFLIGHT, IND corrente e extract derivado em memória (e, em PREPARED, o extract de CONTROL) | R |
| G16 | Espaço livre: DRY ≥ tamanho do shadow + 1 GiB; RUN ≥ 3 × crescimento medido em QS4 + margem | R |
| G17 | **Rehash integral dos 8 ticks** (34.317.940.389 B) = SHAs fixados (DD-8) | R |
| G18 | SHADOW: raiz nova em D:, sem junction; cópia das 23 entradas (ou config + autorização em EMPTY); `prepare_preflight` e `build_binding` congelados no shadow. Os 21 arquivos devem igualar CONTROL ou o Anexo A, byte a byte; identidade igual módulo `config_sha256`; calcula também a identidade esperada para CONTROL | W (shadow) |
| G19 | **Só RUN:** grava `CONTROL/GATES/PHASE_B_ADAPTER_RUN_BINDING.json` se ausente (frontier F1) ou compara em IN_PROGRESS; `prepare_preflight` e `build_binding` congelados em CONTROL; pós-verifica os 21 SHAs = shadow = fixados | W (CONTROL) |
| G20 | Instala SEAM-D1 e SEAM-PPR; afirma a lista fechada de patches; afirma FINAL ausente (full:295 inalcançável) | R |
| G21 | **PRE_RECOVER_B:** adquire o mutex nominal R1R11 da raiz (`res:269`, mesma fórmula), executa `recover(<root>/PHASE_B)` e mantém o mutex até o retorno de `run_phase`. O RunLock interno o reobtém recursivamente na mesma thread (comportamento Win32 documentado; `INFERÊNCIA` até T31a no alvo) | W (root) |
| G22 | `run_phase(root,'B',…)` congelado: RunLock → `recover(raiz)` → purga de scratch → JobMemory → Runtime → injeção → `prepare_volume` → `recover(po)` (no-op) → checkpoint → journal/seals → plano de meses → 1º registro/anchor → `_verify_d1_bar` → engine/spawn | W (root) |
| **BND** | `BND_PRE_PROCESS_RECORD` — fim do DRY | — |
| G23 | **Só DRY:** AFTER = BEFORE em CONTROL, PREFLIGHT, CODE e entradas; CODE sem `.pyc`; trace normalizado gravado como template; prova de árvore limpa | R |
| G24 | **Só RUN:** laço econômico congelado → `finalize_phase` → validador FINAL → completion receipt + evidence ZIP → CODE exato → PHASE_C intocada → AFTER | W (CONTROL) |

**Template de trace** (normalizado, sem campos voláteis):

```text
PREFLIGHT_PHASE_B_REUSE=PASS sessions=166
RUN_START mode=RUN_B sessions=166 remaining_sessions=166 files_to_read_or_verify=8 total_gib=31.961 frozen_cells=1
RUN_MONTH_START mode=RUN_B file=WIN@N_ticks_2026_01.csv … wanted_sessions=21 verify_only=NO
MULTIWORK=YES AUTOCPU=YES …
SESSION_START mode=RUN_B session=2026-01-02 cells=1
```

Ficam excluídos memória, PIDs, tempos e workers concedidos. Em PREPARED não pode aparecer `STALE_SCRATCH_RECONCILED`.

**Campos dependentes de caminho (lista fechada):**

- `identity.config_sha256`;
- chave e `out` de `SESSION_SEALS`;
- `journal.out_root` e `journal.checkpoint_path`;
- nome do mutex R1R11;
- `RUN.lock.out_root`;
- `R1R11_STATUS.json.out_root`;
- `checkpoint_content_sha256`, como consequência.

Qualquer outra divergência entre shadow e CONTROL ⇒ FAIL.

### 5.4 Contrato D1-B (G15 antes de qualquer escrita; SEAM-D1 no uso)

1. **Bytes:** sem BOM, sem CR. Cabeçalho exatamente `session_date;expected_previous_session_date;open_micro;high_micro;low_micro;close_micro`. OHLC em dígitos.
2. **Cardinalidade em dupla fonte:** N = `len(EXPECTED)`, N = 166, N = `len(calendário)` = `len(extract)`.
3. **Sequência:** sem duplicata; dentro de `2026-01-01..2026-08-31`; `set(extract) == EXPECTED`; mesma ordem nos três arquivos.
4. **Predecessor:** igual nos três arquivos (extract, calendário, EXPECTED); `prev < session_date`; `prev` presente no IND.
5. **OHLC:** extract = barra corrente do IND nos 4 campos; SHA do IND = binding.
6. **Identidade:** SHA do extract = `binding.d1_predecessor_extract_sha256` = `610841D8…`; self-hash do binding.
7. **Códigos:** `D1B_SCHEMA`, `D1B_CARDINALITY`, `D1B_DUPLICATE`, `D1B_RANGE`, `D1B_SEQUENCE`, `D1B_ORDER`, `D1B_PREDECESSOR_3WAY`, `D1B_PREDECESSOR_INVALID`, `D1B_OHLC`, `D1B_EXTRACT_SHA`, `D1B_BINDING_SELF_HASH`.

Eficácia demonstrada em PX2 sobre os bytes reais: os 9 casos de violação construídos foram todos detectados com o código esperado, e o caso físico passa nos 166.

### 5.5 Máquina de estados (predicados exatos)

| Estado | Predicado |
|---|---|
| **EMPTY** | `PHASE_B` e `PREFLIGHT/PHASE_B` ausentes ou vazios; nenhuma entrada além de config e autorização exatas e dos diretórios `GATES`/`PREFLIGHT` |
| **PREPARED** | As 23 entradas do Anexo A, exatas; nenhuma outra (com ou sem `PHASE_B_ADAPTER_RUN_BINDING.json` igual à identidade corrente); G18 byte-idêntico |
| **IN_PROGRESS** | PREPARED-set exato + `CHECKPOINT.json` com self-hash e identidade igual à calculada para CONTROL; `completed` ⊂ calendário; `sessions/*` = `completed`; seals OK; `_commit_journal` com no máximo 1 journal válido; *adapter run binding* igual; `TELEMETRY`/`_scratch` sem dono vivo |
| **FINAL_VALID** | IN_PROGRESS com `completed` = EXPECTED; FINAL validado (V001 §5.8 com o formato do DD-4) |
| **BLOCKED_AMBIGUOUS** | Qualquer outra configuração |

- **PREPARED_REBIND** (por exemplo, IND@N estendido além de 2026-09-18): não é automático. Exige decisão do owner, cópia arquivada dos 21, prova de calendário/EXPECTED/extract idênticos e novos SHAs.
- **DRY:** nunca altera CONTROL.

### 5.6 SAFE_STOP, efeitos e códigos de saída

| Situação | Resultado |
|---|---|
| KeyboardInterrupt **e** `R1R11_STATUS.json` deste `run_instance` com `PROCESS_TREE_CLEAN=YES` **e** evento `PROCESS_TREE_CLEAN` no transporte **e** reclassificação ∈ {PREPARED, IN_PROGRESS} | 130 `SAFE_STOP=YES` |
| Interrupção antes de F1 | 130 `SAFE_STOP=YES EFFECT=NONE PROCESS_TREE=NOT_APPLICABLE` |
| Interrupção ou falha após F1 sem prova de runtime, ou `SAFE_STOP_WORKER_COOPERATIVE_TIMEOUT` | 3 `PARTIAL_EFFECT` com todos os alvos por conteúdo + checagem de órfãos (res:303) |
| Falha de gate antes de F1 | 2 |
| DRY com AFTER ≠ BEFORE em CONTROL | 3 + incidente |

### 5.7 Antivírus (DD-9)

- Sem exclusão ampla.
- Qualquer `_avast_` ou entrada desconhecida dentro de CONTROL, shadow ou CODE ⇒ BLOCKED, com o caminho no receipt.
- O par vazio do PREFLIGHT fica fixado e é fiscalizado como imutável.
- Uma exclusão estreita, temporária e restrita a diretório owned só pode ser **proposta** com o receipt de QS3/QS4 demonstrando a interferência.

---

## 6. Auditoria do desenho contra os requisitos

| # | Requisito (prompt §D / critérios 03) | Atendido por | Evidência | Estado |
|---|---|---|---|---|
| 1 | CODE econômico congelado e identificado | G06, G24; 0 bytes alterados | `verify_package` (full:49-60) + `runner_identity` | PASS |
| 2 | Adapter B explícito e fail-closed; A legado exato; C recusado | SEAM-D1 com escopo e restauração; G00 | PX1 (forma), T01, T21 | PASS |
| 3 | Estados EMPTY/PREPARED/IN_PROGRESS/FINAL_VALID/BLOCKED_AMBIGUOUS | §5.5 | Predicados sobre artefatos reais | PASS |
| 4 | PREPARED atual só por hashes/identidades exatas | G12 + G18 + Anexo A | 23 SHAs + reprodução em shadow | PASS |
| 5 | Ausente ≠ `null` | G10 | PX7: config atual tem exatamente 10 chaves, nenhuma `null` | PASS |
| 6 | D1 B completo antes do runtime/efeito | G15 (pré-escrita) + SEAM-D1 (uso) | PX2 (9 negativos + tautologia demonstrada) | PASS |
| 7 | Recovery B da fase correta antes de qualquer purga | G21 PRE_RECOVER_B + independência provada | PX5, PX5b; tx:118-161 | PASS |
| 8 | FINAL validado antes de reuso | §5.5 / V001 §5.8 + DD-4; full:295 inalcançável (G20) | out:318-326; full:280 | PASS |
| 9 | Preparação compartilhada dry/run até a fronteira anterior ao 1º `process_record` | G00–G22 idênticos; BND via SEAM-PPR | coord:147; full:372 | PASS |
| 10 | Dry-run não muta CONTROL nem fonte econômica | Shadow + G11/G23 | N-04/N-05 resolvidos por raiz owned | PASS |
| 11 | SAFE_STOP/resume real em B | §5.6 + QS4 (T16–T18) | DD-3/DD-5 | PASS (prova dinâmica em QS4) |
| 12 | Phase C impossível | G00; wrappers `phase=='B'`; `full.main` proibido | full:477-479 | PASS |
| 13 | Runtime, argv e exit nativo qualificados no alvo antes do executor final | QS2 (T26, Q08) | Política 10.0A; N-10 | PASS (condição de qualificação) |
| 14 | Auditoria pré-entrega depois da qualificação e antes do effectful | QS5 (R02) | — | PASS |
| 15 | Nenhuma alteração econômica ou reselection | Envelope `forbidden` | Células congeladas `NO_CANDIDATE` | PASS |

```text
SOLUTION_DESIGN_AUDIT=PASS
```

---

## 7. Change envelope congelado (resumo; autoridade = JSON)

| Item | Conteúdo |
|---|---|
| Identidade | `MINOTAURO_PHASE_B_ADAPTER_CHANGE_ENVELOPE_V001` (`CHANGE_ENVELOPE_PHASE_B_ADAPTER_V001.json`) |
| Base imutável | CODE `FA4E2BE1…` (474); runner `0ACDD45F…`; G8 `4DD1CFD0…`/`1A28413B…`/`1F5732B0…`; pai `A0BD69C2…`/`B56315F5…`; CONTROL PREPARED (23); PREFLIGHT (16 + par vazio); IND `36D97467…`; 8 ticks (SHA e tamanho); runtime `4942B86A…`/numpy 2.4.6 |
| Arquivos novos permitidos | `PHASE_B_ADAPTER_V001/{phase_b_entry,phase_b_state,phase_b_contract,phase_b_shared,phase_b_effects}.py`, `phase_b_constants.json`, `tests/**`, `qualification/**`, `MANIFEST_SHA256.txt`, `ADAPTER_IDENTITY.json`, `BOOTSTRAP_PHASE_B_ADAPTER.ps1` (executável só após auditoria pré-entrega) |
| Escritas em CONTROL (só RUN) | Via funções congeladas com `phase=B`; `GATES/PHASE_B_ADAPTER_RUN_BINDING.json`; após FINAL_VALID: `GATES/PHASE_B_COMPLETION_RECEIPT.json` e `RELEASE_ROOT/PHASE_B_2026_FF_CUTOFF_R3_20261001_EVIDENCE.zip` |
| Raízes owned | `D:\MinotauroRuns\MINOTAURO_PHASE_B_SHADOW\<ATTEMPT_ID>\CONTROL` · `D:\MinotauroRuns\MINOTAURO_PHASE_B_ADAPTER_EVIDENCE\<ATTEMPT_ID>` |
| Seams | SEAM-D1, SEAM-PPR (produção); SEAM-INTERRUPT-AFTER e SEAM-FAULT (só qualificação); nenhum outro |
| Gates | G00–G24 + BND (§5.3) |
| Proibido | Bytes de CODE/PREFLIGHT; apagar ou mover os 21; regra econômica; `full.main`; fase ≠ B; Phase C; FULL 2025; repetir V001–V003; instalação global; exclusão ampla de AV; re-chavear seals ou reescrever journal; promover ou ler métricas do shadow em quarentena |

---

## 8. Especificação da implementação (contratos, sem código executável)

| Módulo | Responsabilidade | Contratos obrigatórios |
|---|---|---|
| `phase_b_entry` | CLI e mapa de exit | Subcomandos fechados; `-B` verificado; nenhum import do CODE antes de G06; saída `key=value` estável; erro primário prevalece sobre cleanup |
| `phase_b_state` | `classify(control, preflight, constants) → (state, findings)` | Somente leitura; enumera **todas** as entradas (arquivos e diretórios); usa validadores congelados apenas após G06; nunca chama `recover` |
| `phase_b_contract` | `d1b_validate`, `config_validate`, `prepared_validate`, `final_validate`, `inputs_validate`, `tick_rehash` | Códigos rotulados (§5.4); SHA em maiúsculas, salvo onde o protocolo congelado usa minúsculas (N-19); leitura de arquivos grandes em blocos de 8 MiB |
| `phase_b_effects` | BEFORE/AFTER, diff, receipts | BEFORE persistido **antes** de F1, com fsync; inventário por conteúdo (sem top-N); receipts canônicos atômicos em `<evidence_root>` |
| `phase_b_shared` | G00–G24, shadow, seams, mutexes, trace | Seams instalados em `try/finally` com afirmação de identidade; mutex R1R11 obtido e liberado na mesma thread; tee de stdout apenas observacional; shadow nunca dentro de RELEASE_ROOT |
| `BOOTSTRAP_PHASE_B_ADAPTER.ps1` | Lançador PS 5.1 (especificação) | Caminho absoluto do exe; `-B` + env; script-alvo explícito com SHA vinculado antes do lançamento; exit via `System.Diagnostics.Process` (`WaitForExit()` + `Refresh()` + `ExitCode`) ou `$global:LASTEXITCODE`; probes RC 0 e 7 antes do comando real; heartbeat e watchdog sem auto-kill; CRC/manifesto/payload exato antes de extrair; fronteira de extração marcada; **log em caminho absoluto fixo** (`<evidence_root>\BOOTSTRAP.log`), independente do diretório corrente (`C:\Users\silvi`); cabeçalho e rodapé `RESULT_CONTEXT`/`RESULT_RETURN_TO` |

**Receipt do DRY (campos mínimos):** `attempt_id`, identidade do adapter, manifesto do CODE, estado, `gates[{id, status, input_sha256}]`, trace normalizado + SHA, BEFORE/AFTER + igualdade, raiz do shadow, `BND_REACHED`, prova de árvore limpa, rehash de ticks, resumo D1-B, config, exit.

---

## 9. Especificação da qualificação

| Estágio | Onde | Conteúdo | Pré-condição |
|---|---|---|---|
| **QS0** | Estático | Payload exato; import-safety; scan da lista fechada de seams; ausência de `full.main`; parse PowerShell + scan de variáveis automáticas | Implementação entregue |
| **QS1** | Fixtures (sandbox ou alvo) | T01–T13, T15, T17, T20, T21, T24, T25, T28, T32 | QS0 PASS |
| **QS2** | Alvo, somente leitura | Q01–Q08, T26 (exit 0/2/3/7/130 + padrão `-999`), T31a (mutex reentrante em raiz owned) | Autorização do owner |
| **QS3** | Alvo, DRY substantivo sobre o PREPARED atual | T02, T11c, T14, T19 (template), T23, T27, T30 | QS2 PASS |
| **QS4** | Alvo, shadow com dados reais em quarentena (DD-7) | T16, T17, T18, T22, T29, T30, T31b, T33; mede crescimento por sessão para G16 | QS3 PASS + autorização do owner |
| **QS5** | Pré-RUN | R01–R06; auditoria pré-entrega do pacote RUN | QS4 PASS |

### Matriz V002 (deltas sobre o V001 §7)

| ID | Ajuste ou novidade |
|---|---|
| T09 | Inclui o caso (b) tautológico: calendário adulterado com extract rederivado. Esperado: `D1B_PREDECESSOR_3WAY`; o `_verify_d1_bar` congelado passaria (PX2) |
| T11 | (c) passa a ser prova lógica: chegar a BND com `CONTROL/PHASE_A` ausente implica fallback não usado |
| T16 | k ∈ {1, 2, 21 (fim de janeiro), 22 (1ª de fevereiro)}; referência = shadow ininterrupto; comparação de `sessions/*` byte a byte e do checkpoint módulo `config_sha256` |
| T18 | P1–P7 por SEAM-INTERRUPT-AFTER/SEAM-FAULT em: RunLock, `prepare_volume`, `recover`, `_load_checkpoint`, `write_anchor_checkpoint`, `commit` (8 FAULTS), `clear_anchor_checkpoint`. P5 com **CTRL_C_EVENT real** (deve aparecer `SAFE_STOP_REQUESTED=YES`). P10 = TerminateProcess do coordenador (órfãos devem morrer por morte do pai, worker:168/228; caso contrário, `RUN_LOCK_OR_ORPHAN_ACTIVE` fail-closed) |
| T30 | **Novo:** monitoramento de `_avast_` ou entradas desconhecidas em CONTROL, shadow e CODE durante QS3/QS4 ⇒ BLOCKED + relatório (base para eventual pedido estreito, DD-9) |
| T31 | **Novo:** PRE_RECOVER_B: (a) mutex obtido pelo adapter ⇒ o RunLock na mesma thread entra; um 2º processo recebe `RUN_MUTEX_ACTIVE_OR_UNAVAILABLE`; (b) journal pendente resolvido antes da purga (`STALE_SCRATCH_RECONCILED` só depois) |
| T32 | **Novo:** P8/P9 (finalize e evidence) em fixture sintética com forma de B (166 sessões fictícias coerentes). Interrupção no meio do finalize ⇒ refinalização determinística byte a byte; FINAL só após validação |
| T33 | **Novo:** guarda de trace do RUN: template divergente (injetado no shadow) ⇒ parada antes do 1º `process_record` |

**Quarentena (DD-7):**

- As saídas econômicas do QS4 são comparadas apenas por SHA.
- Nenhuma métrica é aberta; só tamanhos em bytes são lidos, para G16.
- O shadow nunca é promovido.
- O descarte segue o ciclo de vida, após a auditoria do receipt.

**Rehash de ticks (DD-8):** obrigatório em cada `dry-run-b` e `run-b`. No QS4, executado uma vez por sessão de qualificação; as retomadas seguintes dependem do fingerprint e do hash em streaming congelados.

---

## 10. Falsos-PASS adicionais bloqueados

| FP | Falso-PASS | Bloqueio |
|---|---|---|
| FP-23 | Marcador de AV removido ou ignorado para "destravar" | DD-9; G12/G13; T30 |
| FP-24 | Identidade do shadow confundida com a de CONTROL | Lista fechada de campos de caminho; G18 calcula a identidade esperada de CONTROL |
| FP-25 | Template de trace do DRY reaproveitado com entradas diferentes | `input_sha256` por gate no template; T33 |
| FP-26 | PASS de QS4 em subconjunto tratado como cobertura de finalize | T32 separado; FINAL validado no RUN |
| FP-27 | Seam de qualificação presente em `run-b` | Afirmação da lista fechada em G20; QS0 |

Os falsos-PASS FP-01 a FP-22 do V001 continuam vigentes.

---

## 11. Evidência remanescente

| Classe | Itens |
|---|---|
| `REQUIRED_BEFORE_IMPLEMENTATION` | **Nenhum.** E01 e decisões do owner recebidos |
| `REQUIRED_BEFORE_QUALIFICATION` | Q01–Q08 (V001 §8.2), capturados pelo pré-estágio somente leitura do QS2; recheck live da política |
| `REQUIRED_ONLY_BEFORE_EFFECTFUL_RUN` | R01–R06 (V001 §8.3); limiar de G16 medido no QS4 |

---

## 12. Próxima ação única

**Ordem explícita do owner para iniciar a implementação restrita ao `CHANGE_ENVELOPE_PHASE_B_ADAPTER_V001`.** A entrega deve conter o pacote `PHASE_B_ADAPTER_V001` (código, testes, harness de qualificação e bootstrap especificado) e vai para auditoria pré-entrega do Opus (QS0 + revisão estática), **sem nenhuma execução no PC** nesta etapa.

---

## 13. Veredito final

```text
OPUS55_PHASE_B_REAUDIT=PASS
WORK_VERDICT_CONFIRMED=YES
LIVE_POLICY_RECHECK=UNAVAILABLE_EXTERNAL_TRANSFER
PACKAGE_INTEGRITY=PASS
ROOT_CAUSE_CHAIN=FULLY_CLOSED
SOLUTION_DESIGN_AUDIT=PASS
IMPLEMENTATION_AUTHORIZED=YES
NEW_EFFECTFUL_RUNNER=NO
PHASE_B_READY_FOR_FULL=NO
PHASE_C_EXECUTION=NO
RESELECTION_2026=FORBIDDEN
```

- **DD-1 a DD-6** fechados pelos bytes. O único pressuposto A ativo é o loader D1.
- **Recovery:** a ordem recovery/purga do frozen era segura (PX5), mas o desenho garante a ordem literal via PRE_RECOVER_B.
- **D1:** a tautologia da verificação in-run foi demonstrada fisicamente; o contrato D1-B a fecha em três vias.
- **Antivírus:** a presença de `_avast_` é fato físico (N-17) e é tratada fail-closed, conforme DD-9.
- **O que falta é prova dinâmica, não desenho:** QS2 → QS3 → QS4 → QS5, cada estágio com autorização própria.

---

## Anexo A — Identidades fixadas

A autoridade é o JSON do envelope. Resumo:

| Conjunto | Quantidade | Referência |
|---|---:|---|
| CONTROL PREPARED (arquivos) | 23 | 21 artefatos do V001 Anexo A + config `08BF21D6…` + autorização `5553C064…` |
| PREFLIGHT/PHASE_B (arquivos) | 16 | Inclui `PREFLIGHT_CHECKPOINT.json` `65B824CE8542A74109BA5C15C9287F9C086D9523CA78691B38007A572F3A44D3` e 8 `MONTH_RECEIPTS` |
| PREFLIGHT extrínseco vazio | 2 diretórios | `_TMP_SAME_VOLUME_PHASE_B`, `_TMP_SAME_VOLUME_PHASE_B/_avast_` |
| Ticks | 8 | 34.317.940.389 B; SHAs do binding (= inventário = month receipts) |
| Sessões por mês | 166 | 21/18/22/20/20/21/23/21 (CÁLCULO, PX8) |

## Anexo B — Probes V002 (sandbox Python 3.13; o alvo é Windows/3.14)

| Probe | Resultado |
|---|---|
| PX1 | Legado: A=250 OK, B=166 rejeitado. Tipo `dict[str,dict]`. A compreensão idêntica reproduz o legado em A. Contrato B + `_verify_d1_bar` passam em 166. SHA do IND = binding. Última data do IND: 2026-09-18 |
| PX2 | T03–T10: todos detectados com o código esperado. T09b: o `_verify_d1_bar` congelado passa (tautologia) e o contrato bloqueia. T01: o legado aceita duplicata (249) |
| PX3 | Extract reproduzido = `610841D8…` (LF). `SPEC_HASH` gerado no Linux ≠ CONTROL (CRLF) ⇒ dependência de plataforma |
| PX4 | `_load_checkpoint`: ausente ⇒ cria; presente ⇒ bytes e mtime inalterados; drift de identidade ⇒ `RESUME_HASH_MISMATCH config_sha256` |
| PX5 | `recover(raiz)` não toca o journal B; purga do scratch; `recover(po)`: pending ⇒ OLD, published ⇒ NEXT, checkpointed ⇒ NEXT. Negativos: `CHECKPOINT_THIRD_STATE`, `BOTH_FINAL_AND_PENDING`, `MULTIPLE_UNRESOLVED_JOURNALS` |
| PX5b | PRE_RECOVER_B com scratch intacto; 2ª chamada no-op nos 3 estágios |
| PX6 | `ParallelSession.process_record` substituível e restaurável por identidade |
| PX7 | Config `08BF21D6…`: 10 chaves, nenhuma `null` |
| PX8 | 0 linhas sem campos R3; ticks do calendário = binding; 166 = 21+18+22+20+20+21+23+21; níveis L0/L1 |
| Closure | 64 / 27 / 271 / 25 (§3) |

Payload do E01 inalterado antes e depois dos probes (`payload_unchanged=true`). Único stub usado: `sync_directory` (syscall Win32 de durabilidade) como no-op, apenas em PX5/PX5b.

```text
RESULT_RETURN_TO=ChatGPT | PROJECT=Pegasus Original | THREAD=Implementação Runner Paralelo 4
```
