# Engenharia e limites físicos

A árvore `CODE` deriva integralmente dos 474 membros manifestados da captura pós-PID_REUSE; `receipts/DELTA_INVENTORY.json` lista as sete superfícies de engenharia modificadas e o entrypoint novo. `HISTORICAL_G4` permanece 31/31 byte idêntico. O handoff original inteiro e o adendo estão em evidence. Os fontes históricos dentro dos ZIPs não foram editados, renomeados ou reinterpretados como sucessor.

## Causalidade e recursos

As sessões permanecem sequenciais porque cash/HWM/drawdown e estado transitam entre pregões. O particionamento econômico usa somente grupos `(p_idx,t_idx)` independentes, feed único, um slot compartilhado e barreiras de ACK; commit ordenado e escritor canônico único. A baseline NO_CANDIDATE mantém P02_T02_R02_M00: um grupo, portanto um worker econômico. O pipeline pode ter oito auxiliares de compressão/verificação; eles não são denominados workers econômicos e entram na memória agregada. A grade sintética ampla usada nos testes possui 15 grupos; nenhum teste demonstrou 24 processos econômicos simultâneos.

AUTOCPU aceita 1..24, toma mínimo de CPU efetiva menos reserva/carga externa, memória, grupos e limite I/O. Primeira reserva produtiva permanece conservadora 10.708 MiB por worker; estimativas seguintes usam pico observado +25%, mínimo 256 MiB, além de 2 GiB para auxiliares. Linux respeita quota CPU e cgroup de RAM; Windows mede PrivateUsage. O orçamento é min(60% RAM física, 48.528 MiB), não uma meta de consumo. Pressão medida bloqueia; nenhum aumento é feito para ocupar CPUs artificialmente. I/O usa a espera real da barreira de streaming; espera superior a 50% limita workers na sessão seguinte. Essa heurística é candidata, não homologação de performance no PC.

Linux do Work tem namespaces PID: o mapeamento lê NSpid e o namespace do processo, preservando PID+start ticks. Esse detalhe não altera PID+GetProcessTimes Windows. smaps_rollup foi negado; a medição Linux usa soma conservadora RSS, com possível dupla contagem de páginas compartilhadas, não alegação de memória privada exata.

## Persistência

O protocolo histórico journal → PENDING → rename sessão → checkpoint fsync/replace foi reutilizado. A recuperação do root agora também percorre PHASE_B/C antes de qualquer purge de scratch. Journals resolvidos são arquivados em `_journal_history` com bytes originais, sem overwrite; COMMITTED não é renomeado nem truncado. `CHECKPOINT.json` continua vinculado a identidades de core/config/fontes; alteração de workers é engenharia e só pode ser admitida onde a equivalência está qualificada. Não há migração automática de checkpoint histórico para a identidade nova.

Incidente aberto: resíduo PENDING em uma execução da qualificação final. Não há prova final de exatamente-uma-vez para esta revisão e nenhum PASS herdado da anterior. Veja 00_START_HERE.md e recibos. O protocolo não foi alterado especulativamente após esse incidente.

## Interrupção e observabilidade

SIGINT registra pedido, fecha admissão e aguarda commit da sessão corrente; segundo SIGINT reitera espera e não autoriza kill. Checkpoint precede confirmação 130. Cleanup solicita STOP aos filhos e espera prazo finito; timeout preserva evidência e falha. Prova de árvore limpa conserva identidades de todos os filhos, inclusive os já retirados da lista ativa. Não se mata processo do usuário.

Heartbeat de thread a cada 10 s mantém STATUS atômico mesmo durante bloqueio do feed. A taxa é sessões committed/segundo da tentativa, ETA a média observada; antes do primeiro commit a justificativa UNKNOWN é explícita. Barra global fica em 99,99% até limpeza final. Memória inclui idade da amostra e pico; contadores de I/O só são declarados quando observados. Campos ausentes não são fabricados. Status de sessão não é autorização de Phase C.

## B/C, freeze e admissão futura

O controller preserva fases B 2026-01-01..08-31 e C 2026-09-01..09-11, predecessor D1, bindings MINOTAURO e finalização econômica. A ponte D1 da nova árvore valida path de fase, hash e ordem sem alterar o loader congelado. Phase C exige final B PASS. 2026-01-05 continua na autoridade original. RESELECTION_2026 permanece FORBIDDEN.

A entrada de produção e o main legado direto ficam bloqueados. Não existe chave booleana de owner que libere esse build. R01–R06, receipt atual da política viva, revisão independente B06/QS5, admissão de fontes por hash (oito ticks de B e fontes/preflight de C), serial/volume, Python 3.14.7/PS5.1, locks, crescimento 1.900.518.140 bytes e reserva atual, QS2/QS3 conforme autorizações são obrigações da liberação futura. O pacote não inventa definições ausentes nem transforma snapshots em autoridade.

## Codificação e build

Python/JSON/Markdown UTF-8 sem BOM; PS1 gerado ASCII sem BOM; newlines LF; SHA vincula bytes físicos. Testes usam `-B`, área externa, sem pycache no payload. O ZIP interno e externo têm conjuntos exatos e manifests; extração é somente root novo. O bootstrap incorpora o ZIP interno completo e um SHA fixo; o espelho TXT é byte idêntico. A assinatura humana de retorno identifica o mesmo projeto/frente nas duas bordas.
