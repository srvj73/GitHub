# 01_IMPLEMENTATION_CONTRACT_FULL_READY — Requisitos objetivos e condições de aceite

## Papel
Work/Astra High = implementador end-to-end, NÃO auditor independente. Entregar FULL candidato pronto para qualificação e operação **após gates/autorizações**. Não executar full econômico nesta transferência; implementação e suíte offline estão autorizadas.

## Congelamentos e autoridades
1. Proibir `RESELECTION_2026`; Phase B 2026-01-01..2026-08-31, Phase C 2026-09-01..2026-09-11. `2026-01-05` não pode ser removido por conveniência. Não modificar pré-registro econômico ou regra de negócio para destravar execução.
2. Código legado `EVIDENCE/.../CODE` traz módulos econômicos e docs de autoridade; o estado pós-PID_REUSE está na captura reconstruída. Qualquer modificação necessária a orquestração deve preservar outputs econômicos verificáveis ou parar para aprovação se contrato congelado exigir byte identity.
3. Manter bindings, nomes `MINOTAURO` internos, mutex/locks e contratos históricos quando exigidos. Dar nome `PEGASUS` aos novos artefatos de transporte e entrega; não renomear retrospectivamente código congelado.
4. Não usar snapshots de política como autoridade. Revalidar o par live antes de etapa coberta e à entrega.

## Implementação obrigatória — paralelismo real
- AUTOCPU deve escolher trabalhadores dinamicamente: alvo máximo 24 lógicos quando recursos permitirem, considerando CPU, RAM agregada (~60% como orçamento, não meta obrigatória), disco, I/O, tamanho de partições; justificar se menos de 24.
- Sessão/pregão/chunk só pode ser paralelizado se o contrato causal permitir. Ordenação/commit de outputs deve ser determinístico e canonicamente indexado, independente de worker completion. Nenhuma dependência temporal cruzada pode ser perdida.
- Backpressure, filas limitadas, sem avalanche de filhos ou consumo ilimitado de memória. Child lineage PID+start_time contra PID reuse; ownership/lock reentrante verificado.
- Deve haver comparação A/B multiwork vs monowork/parent determinística por sessão/hash/saída; seed histórico, negative controls, crash injection; não comparar somente contagens ou sumarizações.

## Persistência e recovery
- Commit atômico/durável e checkpoint só **depois** de commit; estado `PENDING` separado de `COMMITTED` e reconciliado após crash entre commit e checkpoint; nunca truncar output protegido ao retomar.
- Resume por unidade inequívoca (p. ex. `date_key`, quando autorizado), fingerprints de código/config/dados, journal append-only validado, checkpoint fsync+replace atômico, status persistente.
- SAFE_STOP 1º Ctrl+C: parar admissão, concluir fronteira segura, flush/close, checkpoint, esperar limpeza cooperativa, exit 130 se foi realmente safe; interrupção 2º Ctrl+C documentada, nunca PASS parcial.
- Cleanup de subprocessos com prazos finitos e recibos físicos; não matar processos fora do owned root nem processos vivos do usuário.
- Testar kill/fault após PENDING, após journal, após commit antes de checkpoint, durante replace, durante cleanup; confirmar exactly-once e anti-duplicação.

## Telemetria
- Consola e `STATUS.json` atômico com phase, expected, committed, active, done, worker count, RAM, I/O se observável, ETA, heartbeat e watchdog.
- Percentual deriva de unidades committed, não tentativas ou bytes lidos. `ETA=UNKNOWN` apenas quando não estimável, não indefinidamente para workload conhecido sem justificativa. Tempo e taxa em unidades documentadas.

## Gates / segurança
- `RUN_RELEASED` não pode ser promovido de modo documental. G00 exige autorização específica antes de qualquer efeito. Se código estiver pronto mas não autorizado, launcher deve bloquear com explicação exata, não contornar gate.
- QS0 estático/PS5.1 no alvo; QS1 integral G4 tem pendência oficial V002, executor WSL V001R1 corrigido no pacote. NÃO executar QS1 diretamente no Windows real (T14F cria paths D:).
- QS2 READONLY Windows com autorização separada; QS3 DRY e QS4 conforme envelope/harness e autorização; B06 revisão independente por ator distinto, QS5 e R01–R06 antes de FULL econômico.
- Validar runtime Python 3.14.7, PS 5.1, paths absolutos, fonte congelada, 8 ticks físicos G16 por hash na invocação, free-space: crescimento estimado 1,900,518,140 bytes para 166 sessões; exigir reserva calculada atual, locks, processos, serial de volume; fail-closed se divergência.
- Não alterar `ExecutionPolicy` permanente, não desativar antivírus, não fazer source delete, não executar Phase C/C2/FULL por suposta implicação da palavra READY.

## Entrega do pacote FULL candidato
`PEGASUS_FULL_2026_CANDIDATE_READY_<REV>.zip` deve conter:
- `00_START_HERE...md`, fontes/patches completos, `.ps1`/`.cmd` autodescompactável e parser-safe, `MANIFEST_SHA256`, `ADAPTER_IDENTITY`, ambiente e upgrade de política, qualificação/scripts offline, resultados/logs, fixtures sintéticas, pacotes de review e recibos hash-bound.
- Artefato local no PC deve autoextrair a partir de Downloads, não exigir copiar os 474 fontes manualmente nem adivinhar paths; autoCPU, ETA, status, safe-stop, resume testados com fault injection em sandbox.
- Documento de risco com `full_candidate_built/qualified/authorized/executed` distintos; nenhum veredito de auditor independente fabricado.
- Pelo menos uma qualificação A/B de determinismo (pequena amostra física com autorização e isolated owned root) e provas de recovery; caso só seja possível offline, marcar bloqueio de hardware/gate específico sem afirmar ready-to-run real.

## Critérios de parada
Incompatibilidade de source, política live inacessível, requisito econômico ambíguo, drift hash, missing parent, falha no gate, erro de runner, processo ativo não reconciliado => BLOCKED com causa-raiz, sem successor cego nem efeitos. Pode continuar doc/código offline de partes independentes somente quando a autoridade permitir.
