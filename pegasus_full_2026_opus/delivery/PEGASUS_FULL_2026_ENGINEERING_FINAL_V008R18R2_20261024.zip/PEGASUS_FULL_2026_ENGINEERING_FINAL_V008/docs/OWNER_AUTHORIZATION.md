# Autorização do owner — evidência de conversa, não autorização econômica

Em 2026-10-08 o owner autorizou expressamente PROPOSED_SUCCESSOR_ENVELOPE.json do pacote pai SHA-256 62A1447C2CA6E58F893532D9BBAF1DBDA812C7D3B9EBE09198D0FA6F948526E6, com escopo de IMPLEMENTAÇÃO E QUALIFICAÇÃO OFFLINE DE UM NOVO FULL CANDIDATO.

A autorização abrange árvore separada do G4: AUTOCPU/escalonamento/recursos; orquestração e controladores B/C; SAFE_STOP, checkpoints e resume; journal/recuperação/anti-duplicidade; heartbeat/progresso/ETA; bootstrap/launcher PS5.1/transporte/testes. Exige preservar bytes econômicos, parser, preflight, cutoff, pré-registro, histórico, identidades MINOTAURO, baseline e RESELECTION_2026=FORBIDDEN. Exige revalidar política viva e qualificar deltas; não herdar PASS de código alterado.

Não autoriza FULL econômico, replay effectful B/C, QS2/QS3 protegidos, exclusão de fontes, RUN_RELEASED nem mudança de históricos. A auditoria final será por contexto independente. Em falha deve-se parar a cadeia afetada, reproduzir causa, corrigir minimamente e retestar; nova autoridade material bloqueia somente frente afetada. Este registro não é assinatura/receipt de release e não amplia a autorização.
