"""PHASE_B_QS4_HARNESS_V001 — seams de qualificação do QS4 (somente harness; nunca produção).

Regra de ordem (envelope QS4 §invocation_flow): este módulo só pode ser carregado/instalado DEPOIS de
SeamSet.__enter__ do R3 (a guarda de produção do R3 verifica que `phase_b_qualification_seams` está ausente)
e precisa ser restaurado ANTES de SeamSet.__exit__ (o R3 verifica delta de namespace zero).

Alvos: somente a lista fechada do R3 (INTERRUPT_TARGETS / FAULT_POINTS de phase_b_qualification_seams, carregada pelo
SHA do MANIFEST do R3) e um controlador do harness sobre função da mesma lista (WRITE_ANCHOR do r1r11_fast_resume):
  * AnchorController: ação por DATA da sessão do anchor recém-gravado: interrupt | notify | block
Mensagens: KeyboardInterrupt('QS4_SEAM ...') distingue parada por seam de Ctrl+C real (sem argumentos).
"""
from __future__ import annotations

import functools
import hashlib
import sys
import time
import types
from pathlib import Path

R3_SEAM_MODULE = "phase_b_qualification_seams"
ANCHOR_SPEC = ("r1r11_fast_resume", "write_anchor_checkpoint")


def r3_seams(adapter_dir):
    """Carrega o módulo de seams do R3 (lista fechada) a partir de <adapter>/qualification, executando
    exatamente os bytes cujo SHA-256 consta do MANIFEST do pacote verificado (G05). Só deve ser chamado após
    SeamSet.__enter__ (a guarda de produção do R3 exige o módulo ausente nesse instante)."""
    if R3_SEAM_MODULE in sys.modules:
        return sys.modules[R3_SEAM_MODULE]
    rel = "qualification/" + R3_SEAM_MODULE + ".py"
    root = Path(adapter_dir)
    pin = None
    for line in (root / "MANIFEST_SHA256.txt").read_text(encoding="ascii").splitlines():
        if line.strip():
            h, n = line.split("  ", 1)
            if n == rel:
                pin = h.upper()
    data = (root / rel).read_bytes()
    if pin is None or hashlib.sha256(data).hexdigest().upper() != pin:
        raise RuntimeError("QS4_R3_SEAM_MODULE_PIN")
    mod = types.ModuleType(R3_SEAM_MODULE)
    mod.__file__ = str(root / rel)
    sys.modules[R3_SEAM_MODULE] = mod
    try:
        exec(compile(data, str(root / rel), "exec"), mod.__dict__)
    except BaseException:
        sys.modules.pop(R3_SEAM_MODULE, None)
        raise
    return mod


class _ModuleWrap:
    def __init__(self, sys_modules, spec):
        self.mods, self.spec, self.orig = sys_modules, spec, None

    def _install(self, wrapper_factory):
        owner = self.mods[self.spec[0]]
        self.orig = getattr(owner, self.spec[1])
        setattr(owner, self.spec[1], wrapper_factory(self.orig))

    def __exit__(self, *exc):
        setattr(self.mods[self.spec[0]], self.spec[1], self.orig)
        return False


class AnchorController(_ModuleWrap):
    """Envolve write_anchor_checkpoint. actions: {session_date: 'interrupt'|'notify'|'block'}.
    A ação ocorre DEPOIS da função original (o anchor foi persistido)."""

    def __init__(self, sys_modules, actions: dict, marker_dir, block_max_s: float = 900.0, poll_s: float = 0.5):
        super().__init__(sys_modules, ANCHOR_SPEC)
        bad = {v for v in actions.values()} - {"interrupt", "notify", "block"}
        if bad:
            raise ValueError("ANCHOR_ACTION_NOT_IN_CLOSED_LIST " + ",".join(sorted(bad)))
        self.actions = dict(actions)
        self.marker_dir = Path(marker_dir)
        self.block_max_s, self.poll_s = float(block_max_s), float(poll_s)
        self.events: list = []

    def _marker(self, kind: str, session: str) -> Path:
        self.marker_dir.mkdir(parents=True, exist_ok=True)
        p = self.marker_dir / f"QS4_MARKER_{kind}.txt"
        tmp = p.with_name(p.name + ".tmp")
        tmp.write_text(f"{kind} session={session}\n", encoding="ascii")
        tmp.replace(p)
        return p

    def __enter__(self):
        ctl = self

        def factory(orig):
            @functools.wraps(orig)
            def wrapper(cp_path, cp, anchor, *a, **k):
                r = orig(cp_path, cp, anchor, *a, **k)
                session = str(anchor.get("session")) if isinstance(anchor, dict) else ""
                act = ctl.actions.get(session)
                ctl.events.append({"session": session, "action": act})
                if act == "interrupt":
                    raise KeyboardInterrupt("QS4_SEAM QS4_STOP_ANCHOR session=" + session)
                if act == "notify":
                    ctl._marker("NOTIFY", session)
                elif act == "block":
                    ctl._marker("BLOCK", session)
                    t0 = time.monotonic()
                    while time.monotonic() - t0 < ctl.block_max_s:  # aguarda TerminateProcess do orquestrador (P10)
                        time.sleep(ctl.poll_s)
                    raise KeyboardInterrupt("QS4_SEAM QS4_BLOCK_TIMEOUT session=" + session)
                return r
            return wrapper
        self._install(factory)
        return self


class SeamStack:
    """Instala, em ordem, os seams de uma invocação e restaura na ordem inversa, verificando identidade."""

    def __init__(self, sys_modules, step: dict, ordinal_to_date: dict, marker_dir, block_max_s: float = 900.0,
                 adapter_dir=None):
        self.mods, self.step, self.o2d = sys_modules, step, ordinal_to_date
        self.adapter_dir = adapter_dir
        self.marker_dir, self.block_max_s = marker_dir, block_max_s
        self.stack: list = []
        self.anchor: AnchorController | None = None
        self.spec_record: dict = {}

    def _originals(self):
        return {ANCHOR_SPEC: getattr(self.mods[ANCHOR_SPEC[0]], ANCHOR_SPEC[1])}

    def __enter__(self):
        self._orig0 = self._originals()
        try:
            self._install_all()
        except BaseException:
            self._restore_all()
            raise
        return self

    def _install_all(self):
        stop, step = self.step["stop"], self.step
        safety = int(step["safety_ordinal"])
        actions = {self.o2d[safety]: "interrupt"}
        r3 = None
        if "interrupt_target" in stop or "fault" in stop:
            r3 = r3_seams(self.adapter_dir)
        if "interrupt_target" in stop:
            cm = r3.InterruptAfter(self.mods, stop["interrupt_target"])
            self.stack.append(cm.__enter__())
            self.spec_record["r3_interrupt_after"] = stop["interrupt_target"]
        if "fault" in stop:
            cm = r3.FaultAt(self.mods, stop["fault"])
            self.stack.append(cm.__enter__())
            self.spec_record["r3_fault_at"] = stop["fault"]
        if "anchor_ordinal" in stop:
            actions[self.o2d[int(stop["anchor_ordinal"])]] = "interrupt"
        if "notify_anchor_ordinal" in step:
            actions[self.o2d[int(step["notify_anchor_ordinal"])]] = "notify"
        if "block_anchor_ordinal" in step:
            actions[self.o2d[int(step["block_anchor_ordinal"])]] = "block"
        self.anchor = AnchorController(self.mods, actions, self.marker_dir, self.block_max_s)
        self.stack.append(self.anchor.__enter__())
        self.spec_record.update(anchor_actions=actions, safety_ordinal=safety)

    def _restore_all(self) -> list:
        errors = []
        while self.stack:
            try:
                self.stack.pop().__exit__(None, None, None)
            except BaseException as e:  # noqa: BLE001 - restaura todos antes de falhar
                errors.append(type(e).__name__)
        return errors

    def __exit__(self, *exc):
        errors = self._restore_all()
        if errors or self._originals() != self._orig0:
            raise RuntimeError("QS4_SEAM_RESTORE_IDENTITY " + ",".join(errors))
        return False
