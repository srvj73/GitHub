"""PHASE_B_QS4_HARNESS_V001 — biblioteca do orquestrador (somente stdlib + módulos NÃO-CODE do R3 passados
explicitamente). Nunca importa o CODE congelado. Nenhum efeito em import.

DD-7: nada aqui abre conteúdo econômico. Sessões são comparadas por SHA-256 de bytes; o checkpoint por digest
canônico excluindo a lista fechada de chaves voláteis (o diff devolve só caminhos de chave); crescimento só por
tamanho em bytes.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

ATTEMPT_RE = re.compile(r"^\d{8}T\d{6}Z_[0-9a-f]{8}$")
HEX64 = re.compile(r"^[0-9A-F]{64}$")
STEP_RECEIPT_SCHEMA = "MINOTAURO_PHASE_B_QS4_STEP_RECEIPT_V001"
HARNESS_RECEIPT_SCHEMA = "MINOTAURO_PHASE_B_QS4_HARNESS_RECEIPT_V001"
VERIFIED_SCHEMA = "MINOTAURO_PHASE_B_QS4_RECEIPT_VERIFIED_V001"
COMPANION_KEYS = frozenset({"schema", "receipt_sha256", "attempt_id", "exit_code", "readback"})
QS4_ITEMS = ("T16", "T17", "T18", "T22", "T29", "T30", "T31b", "T33", "GROWTH_G16")


class HarnessBlocked(Exception):
    def __init__(self, code: str, detail: str = ""):
        self.code, self.detail = str(code), str(detail)
        super().__init__((self.code + " " + self.detail).strip())


# --------------------------------------------------------------------------- hashing / json
def sha_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest().upper()


def sha_file(p) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for blk in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(blk)
    return h.hexdigest().upper()


def canon(obj) -> bytes:
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def write_json_exclusive(path, obj, exclusive: bool = True) -> str:
    """Escritor durável só-stdlib (criação exclusiva + fsync) para quando o R3 ainda não foi verificado/importado
    (bloqueio em H00/H02). Mesma serialização canônica; nunca sobrescreve."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = canon(obj)
    with open(path, "xb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    return sha_bytes(data)


def load_json_bytes(raw: bytes):
    def hook(pairs):
        out = {}
        for k, v in pairs:
            if k in out:
                raise HarnessBlocked("JSON_DUPLICATE_KEY", k)
            out[k] = v
        return out
    try:
        return json.loads(raw.decode("utf-8-sig"), object_pairs_hook=hook)
    except HarnessBlocked:
        raise
    except Exception as e:  # noqa: BLE001
        raise HarnessBlocked("JSON_INVALID", type(e).__name__) from e


def load_constants(path) -> dict:
    raw = Path(path).read_bytes()
    c = load_json_bytes(raw)
    if c.get("schema") != "MINOTAURO_PHASE_B_QS4_HARNESS_CONSTANTS_V001":
        raise HarnessBlocked("QS4_CONSTANTS_SCHEMA")
    ids = [x["id"] for x in c["cases"]]
    if len(ids) != len(set(ids)):
        raise HarnessBlocked("QS4_CASE_ID_DUPLICATE")
    c["_sha256"] = sha_bytes(raw)
    return c


def new_attempt_id() -> str:
    return time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()) + "_" + os.urandom(4).hex()


# --------------------------------------------------------------------------- packages
def verify_manifest_dir(root: Path, manifest: str, identity_name: str) -> dict:
    """Payload exato + hashes; identidade = SHA do manifesto (mesma regra de G05 do R3)."""
    root = Path(root)
    man, ident_p = root / manifest, root / identity_name
    if not man.is_file() or not ident_p.is_file():
        raise HarnessBlocked("PACKAGE_MANIFEST_MISSING", str(root))
    listed = {}
    for line in man.read_text(encoding="ascii").splitlines():
        if not line.strip():
            continue
        h, n = line.split("  ", 1)
        if n in listed or Path(n).is_absolute() or ".." in Path(n).parts:
            raise HarnessBlocked("PACKAGE_MANIFEST_ENTRY", n)
        listed[n] = h.upper()
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()} - {manifest, identity_name}
    if actual != set(listed):
        raise HarnessBlocked("PACKAGE_EXACT_PAYLOAD", repr(sorted(actual ^ set(listed))[:20]))
    bad = [n for n in listed if sha_file(root / n) != listed[n]]
    if bad:
        raise HarnessBlocked("PACKAGE_MEMBER_HASH", ",".join(bad[:10]))
    if any(d.name == "__pycache__" for d in root.rglob("*") if d.is_dir()):
        raise HarnessBlocked("PACKAGE_PYCACHE_PRESENT", str(root))
    ident = load_json_bytes(ident_p.read_bytes())
    return {"manifest_sha256": sha_file(man), "identity": ident}


def verify_r3_package(r3_dir: Path, c: dict) -> dict:
    a = c["adapter"]
    v = verify_manifest_dir(r3_dir, "MANIFEST_SHA256.txt", "ADAPTER_IDENTITY.json")
    ident = v["identity"]
    if (v["manifest_sha256"] != a["identity_sha256"] or ident.get("adapter_identity_sha256") != a["identity_sha256"]
            or ident.get("constants_sha256") != a["constants_sha256"] or ident.get("envelope_sha256") != a["envelope_sha256"]
            or ident.get("release_stage") != a["release_stage"]
            or sha_file(Path(r3_dir) / "phase_b_constants.json") != a["constants_sha256"]):
        raise HarnessBlocked("R3_IDENTITY_MISMATCH", v["manifest_sha256"])
    return v


def verify_harness_package(h_dir: Path) -> dict:
    v = verify_manifest_dir(h_dir, "MANIFEST_SHA256.txt", "HARNESS_IDENTITY.json")
    ident = v["identity"]
    if ident.get("harness_identity_sha256") != v["manifest_sha256"]:
        raise HarnessBlocked("HARNESS_IDENTITY_MISMATCH")
    return v


# --------------------------------------------------------------------------- calendar
def ordinal_map(preflight_root) -> dict:
    """{ordinal(1-based): session_date} do calendário PREFLIGHT real (somente leitura)."""
    p = Path(preflight_root) / "PHASE_B" / "SESSION_CALENDAR_PHASE_B.csv"
    rows = list(csv.DictReader(io.StringIO(p.read_bytes().decode("utf-8-sig")), delimiter=";"))
    dates = [r["session_date"] for r in rows]
    if dates != sorted(dates) or len(set(dates)) != len(dates):
        raise HarnessBlocked("QS4_CALENDAR_ORDER")
    return {i + 1: d for i, d in enumerate(dates)}


def check_calendar(o2d: dict, c: dict) -> None:
    e = c["calendar_expectations"]
    jl, ff = int(e["january_last_ordinal"]), int(e["february_first_ordinal"])
    if not (o2d.get(jl, "").startswith("2026-01") and o2d.get(ff, "").startswith("2026-02") and ff == jl + 1):
        raise HarnessBlocked("QS4_CALENDAR_EXPECTATION", f"{jl}={o2d.get(jl)} {ff}={o2d.get(ff)}")
    top = max(int(v) for v in c["endpoints"].values())
    if top not in o2d:
        raise HarnessBlocked("QS4_ENDPOINT_OUT_OF_CALENDAR", str(top))


# --------------------------------------------------------------------------- prior QS3 (H01)
def _log_lines(p: Path) -> list:
    return [ln for ln in p.read_bytes().decode("utf-8-sig").splitlines() if ln != ""]


def validate_prior_qs3(qs3_path: str, qs3_sha_pin: str, c: dict, evidence_base: str, canonical_hash) -> dict:
    """H01: QS3 PASS anterior físico, da identidade R3, com DRY_RECEIPT e QS2 vinculados. Devolve o template."""
    pq = c["prior_qs3"]
    if not qs3_path or '"' in qs3_path or not os.path.isabs(qs3_path):
        raise HarnessBlocked("H01_QS3_RECEIPT_PATH_NOT_ABSOLUTE")
    p = Path(qs3_path)
    if not p.is_file():
        raise HarnessBlocked("H01_QS3_RECEIPT_MISSING")
    if not HEX64.match(str(qs3_sha_pin or "").upper()):
        raise HarnessBlocked("H01_QS3_SHA_PARAM_INVALID")
    raw = p.read_bytes()
    sha = sha_bytes(raw)
    if sha != qs3_sha_pin.upper():
        raise HarnessBlocked("H01_QS3_RECEIPT_SHA_MISMATCH")
    d = load_json_bytes(raw)
    if d.get("schema") != pq["schema"] or d.get("stage") != "QS3_DRY":
        raise HarnessBlocked("H01_QS3_SCHEMA_OR_STAGE")
    if d.get("final_exit") != 0:
        raise HarnessBlocked("H01_QS3_FINAL_EXIT_NOT_ZERO")
    if (d.get("interrupted") is not False or d.get("unproven_effect") is not False or d.get("blocked_reason") is not None
            or d.get("final_status_written") is not True or d.get("status_write_failures") != 0):
        raise HarnessBlocked("H01_QS3_NOT_CLEAN")
    att = str(d.get("attempt_id", ""))
    if not ATTEMPT_RE.match(att):
        raise HarnessBlocked("H01_QS3_ATTEMPT_ID")
    qdir = Path(evidence_base) / att
    want = qdir / "QS3_RECEIPT.json"
    if os.path.normcase(os.path.abspath(str(p))) != os.path.normcase(os.path.abspath(str(want))):
        raise HarnessBlocked("H01_QS3_RECEIPT_LOCATION")
    facts = d.get("facts") or {}
    if facts.get("adapter_identity_sha256") != pq["adapter_identity_sha256"]:
        raise HarnessBlocked("H01_QS3_OTHER_ADAPTER")
    if facts.get("package_zip_sha256") != pq["package_zip_sha256"]:
        raise HarnessBlocked("H01_QS3_OTHER_ZIP")
    items = d.get("items") or {}
    declared = d.get("required_items") or []
    for q in pq["required_items"]:
        if q not in declared:
            raise HarnessBlocked("H01_QS3_REQUIRED_SET", q)
        it = items.get(q)
        if not isinstance(it, dict):
            raise HarnessBlocked("H01_QS3_ITEM_MISSING", q)
        if it.get("result") != "PASS":
            raise HarnessBlocked("H01_QS3_ITEM_NOT_PASS", q)
    # companion + log + status final do bootstrap QS3
    comp_p = qdir / "QS3_RECEIPT.VERIFIED.json"
    if not comp_p.is_file():
        raise HarnessBlocked("H01_QS3_COMPANION_MISSING")
    comp = load_json_bytes(comp_p.read_bytes())
    if (not isinstance(comp, dict) or comp.get("schema") != "MINOTAURO_PHASE_B_ADAPTER_BOOTSTRAP_RECEIPT_VERIFIED_V001"
            or comp.get("receipt_sha256") != sha or comp.get("attempt_id") != att or comp.get("attempt_id") != d.get("attempt_id")
            or comp.get("stage") != d.get("stage") or comp.get("final_exit") != 0 or d.get("final_exit") != 0
            or comp.get("readback") != "PASS"):
        raise HarnessBlocked("H01_QS3_COMPANION_MISMATCH")
    logp = qdir / "BOOTSTRAP.log"
    if not logp.is_file():
        raise HarnessBlocked("H01_QS3_LOG_BINDING")
    lines = _log_lines(logp)
    st = [ln for ln in lines if ln.startswith("STAGE_RECEIPT=")]
    if len(st) != 1 or st[0] != "STAGE_RECEIPT=" + str(want) + " sha256=" + sha:
        raise HarnessBlocked("H01_QS3_LOG_BINDING")
    fe = [ln for ln in lines if ln.startswith("FINAL_EXIT=")]
    if fe != ["FINAL_EXIT=0"]:
        raise HarnessBlocked("H01_QS3_LOG_FINAL_EXIT")
    bsp = qdir / "BOOTSTRAP_STATUS.json"
    if not bsp.is_file() or sha_file(bsp) != d.get("final_status_sha256"):
        raise HarnessBlocked("H01_QS3_FINAL_STATUS")
    bsd = load_json_bytes(bsp.read_bytes())
    if (bsd.get("fields") or {}).get("ACTIVE") != "NO" or (bsd.get("extra") or {}).get("final_exit") != 0:
        raise HarnessBlocked("H01_QS3_FINAL_STATUS")
    # DRY_RECEIPT físico (fonte do template T19/T33)
    adir = qdir / "ADAPTER"
    dr_p = adir / "DRY_RECEIPT.json"
    drc = (items.get("DRY_RUN_B") or {}).get("receipt") or {}
    if not dr_p.is_file() or drc.get("valid") is not True or sha_file(dr_p) != drc.get("sha256"):
        raise HarnessBlocked("H01_QS3_DRY_RECEIPT_BINDING")
    dr_raw = dr_p.read_bytes()
    dr = load_json_bytes(dr_raw)
    if (dr.get("schema") != "MINOTAURO_PHASE_B_ADAPTER_DRY_RECEIPT_V001" or dr.get("attempt_id") != att
            or dr.get("exit_code") != 0 or dr.get("result") != "PASS" or dr.get("mode") != "DRY"
            or dr.get("adapter_identity_sha256") != pq["adapter_identity_sha256"] or dr.get("state") != "PREPARED"
            or dr.get("dry_scope") != "SUBSTANTIVE_TO_BND" or dr.get("bnd_reached") is not True
            or dr.get("status_write_failures") != 0 or dr.get("status_final_persisted") is not True):
        raise HarnessBlocked("H01_QS3_DRY_RECEIPT_CONTENT")
    dcomp_p = adir / "DRY_RECEIPT.VERIFIED.json"
    dcomp = load_json_bytes(dcomp_p.read_bytes()) if dcomp_p.is_file() else {}
    if (not isinstance(dcomp, dict) or dcomp.get("schema") != "MINOTAURO_PHASE_B_ADAPTER_RECEIPT_VERIFIED_V001"
            or dcomp.get("receipt_sha256") != sha_bytes(dr_raw) or dcomp.get("attempt_id") != dr.get("attempt_id")
            or dcomp.get("exit_code") != 0 or dcomp.get("exit_code") != dr.get("exit_code")
            or dcomp.get("mode") != "DRY" or dcomp.get("mode") != dr.get("mode") or dcomp.get("readback") != "PASS"):
        raise HarnessBlocked("H01_QS3_DRY_RECEIPT_NOT_VERIFIED")
    ast_p = adir / "ADAPTER_STATUS.json"
    if not ast_p.is_file() or sha_file(ast_p) != dr.get("status_final_sha256"):
        raise HarnessBlocked("H01_QS3_DRY_STATUS_BINDING")
    ast = load_json_bytes(ast_p.read_bytes())
    if (ast.get("fields") or {}).get("ACTIVE") != "NO" or (ast.get("extra") or {}).get("exit_code") != 0:
        raise HarnessBlocked("H01_QS3_DRY_STATUS_BINDING")
    template = dr.get("runtime_trace")
    if not isinstance(template, list) or not template or dr.get("runtime_trace_sha256") != canonical_hash(template):
        raise HarnessBlocked("H01_QS3_TEMPLATE")
    # QS2 PASS citado pelo QS3 (preservado fisicamente)
    q2p, q2s = facts.get("prior_qs2_receipt_path"), facts.get("prior_qs2_receipt_sha256")
    if not q2p or not HEX64.match(str(q2s or "")) or not Path(q2p).is_file() or sha_file(q2p) != q2s:
        raise HarnessBlocked("H01_QS2_RECEIPT_BINDING")
    q2 = load_json_bytes(Path(q2p).read_bytes())
    if (q2.get("schema") != pq["qs2_schema"] or q2.get("stage") != "QS2_READONLY" or q2.get("final_exit") != 0
            or (q2.get("facts") or {}).get("adapter_identity_sha256") != pq["adapter_identity_sha256"]):
        raise HarnessBlocked("H01_QS2_RECEIPT_CONTENT")
    return {"qs3_receipt_sha256": sha, "qs3_attempt_id": att, "dry_receipt_sha256": sha_bytes(dr_raw),
            "qs2_receipt_sha256": q2s, "template": template, "template_sha256": dr.get("runtime_trace_sha256")}


# --------------------------------------------------------------------------- paths / guards
def is_inside(child, parent) -> bool:
    c, p = os.path.normcase(os.path.abspath(str(child))), os.path.normcase(os.path.abspath(str(parent)))
    return c == p or c.startswith(p.rstrip("\\/") + os.sep)


def _is_link_like(node: Path) -> bool:
    """symlink, junction (Python >= 3.12) ou qualquer ponto de reparse do Windows."""
    if node.is_symlink() or getattr(node, "is_junction", lambda: False)():
        return True
    attrs = getattr(os.lstat(node), "st_file_attributes", 0)
    return bool(attrs & 0x400)  # FILE_ATTRIBUTE_REPARSE_POINT


def guard_case_root(root: Path, attempt_shadow: Path, real_control: Path) -> None:
    root, attempt_shadow, real_control = Path(root), Path(attempt_shadow), Path(real_control)
    if not is_inside(root, attempt_shadow) or is_inside(root, real_control) or is_inside(real_control, root):
        raise HarnessBlocked("QS4_ROOT_OUTSIDE_OWNED_SHADOW", str(root))
    for node in (root, *root.parents):
        if node.exists() and _is_link_like(node):
            raise HarnessBlocked("QS4_ROOT_LINK", str(node))
    rr, rs, rc = (os.path.realpath(str(x)) for x in (root, attempt_shadow, real_control))
    if not is_inside(rr, rs) or is_inside(rr, rc) or is_inside(rc, rr):
        raise HarnessBlocked("QS4_ROOT_OUTSIDE_OWNED_SHADOW_REALPATH", rr)
    if root.exists() and real_control.exists():
        try:
            if os.path.samefile(root, real_control):
                raise HarnessBlocked("QS4_ROOT_IS_REAL_CONTROL", str(root))
        except OSError:
            pass


def seed_case_root(real_control: Path, dst: Path, pinned_entries: list, dirs: list) -> dict:
    """Copia SOMENTE os 23 PREPARED pinados do CONTROL real (leitura) para a raiz do caso; verifica SHA."""
    if dst.exists():
        raise HarnessBlocked("QS4_CASE_ROOT_EXISTS", str(dst))
    dst.mkdir(parents=True)
    for d in sorted(dirs):
        (dst / d).mkdir(parents=True, exist_ok=True)
    for e in pinned_entries:
        src, out = Path(real_control) / e["path"], dst / e["path"]
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, out)
        if sha_file(out) != str(e["sha256"]).upper() or out.stat().st_size != int(e["bytes"]):
            raise HarnessBlocked("QS4_SEED_HASH", e["path"])
    return {"files": len(pinned_entries), "dirs": len(dirs)}


# --------------------------------------------------------------------------- shadow state (DD-7)
def sessions_map(root: Path) -> dict:
    sd = Path(root) / "PHASE_B" / "sessions"
    out = {}
    if sd.is_dir():
        for d in sorted(p for p in sd.iterdir() if p.is_dir()):
            out[d.name] = {f.name: sha_file(f) for f in sorted(d.iterdir()) if f.is_file()}
    return out


def _flatten(obj, prefix=""):
    if isinstance(obj, dict):
        for k in sorted(obj):
            yield from _flatten(obj[k], f"{prefix}.{k}" if prefix else str(k))
    else:
        yield prefix, sha_bytes(canon(obj))


def checkpoint_digest(root: Path, volatile: list) -> dict:
    """Digest canônico do CHECKPOINT excluindo chaves voláteis de 1º nível; devolve também um mapa
    caminho->hash por folha (nunca valores) para diff."""
    p = Path(root) / "PHASE_B" / "CHECKPOINT.json"
    if not p.is_file():
        return {"present": False, "digest": None, "leaves": {}}
    cp = load_json_bytes(p.read_bytes())
    kept = {k: v for k, v in cp.items() if k not in set(volatile)}
    return {"present": True, "digest": sha_bytes(canon(kept)), "leaves": dict(_flatten(kept)),
            "completed_count": len(cp.get("completed") or [])}


def phase_b_files(root: Path) -> list:
    """Nomes (nunca conteúdo) dos arquivos sob PHASE_B fora de sessions/ — detecta journal, .v004-next etc."""
    po = Path(root) / "PHASE_B"
    if not po.is_dir():
        return []
    return sorted(p.relative_to(po).as_posix() for p in po.rglob("*")
                  if p.is_file() and p.relative_to(po).parts[0] != "sessions")


def state_digest(root: Path, volatile: list) -> dict:
    sm = sessions_map(root)
    cp = checkpoint_digest(root, volatile)
    return {"sessions": sm, "sessions_digest": sha_bytes(canon(sm)), "checkpoint": cp, "phase_b_files": phase_b_files(root)}


def compare_states(ref: dict, got: dict) -> dict:
    diffs = []
    if set(ref["sessions"]) != set(got["sessions"]):
        diffs.append("SESSIONS_SET:" + ",".join(sorted(set(ref["sessions"]) ^ set(got["sessions"]))[:10]))
    for s in sorted(set(ref["sessions"]) & set(got["sessions"])):
        if ref["sessions"][s] != got["sessions"][s]:
            names = set(ref["sessions"][s]) | set(got["sessions"][s])
            diffs += [f"SESSION_FILE:{s}/{n}" for n in sorted(names) if ref["sessions"][s].get(n) != got["sessions"][s].get(n)]
    if ref.get("phase_b_files") != got.get("phase_b_files"):
        diffs += ["PHASE_B_FILE_SET:" + n for n in sorted(set(ref.get("phase_b_files") or []) ^ set(got.get("phase_b_files") or []))][:20]
    rc, gc = ref["checkpoint"], got["checkpoint"]
    if rc["present"] != gc["present"]:
        diffs.append("CHECKPOINT_PRESENCE")
    elif rc["digest"] != gc["digest"]:
        keys = set(rc["leaves"]) | set(gc["leaves"])
        diffs += ["CHECKPOINT_KEY:" + k for k in sorted(keys) if rc["leaves"].get(k) != gc["leaves"].get(k)][:50]
    return {"equal": not diffs, "diffs": diffs[:80]}


def growth(root: Path, sessions_total: int) -> dict:
    """Somente tamanhos (stat)."""
    sd = Path(root) / "PHASE_B" / "sessions"
    per = []
    if sd.is_dir():
        for d in sorted(p for p in sd.iterdir() if p.is_dir()):
            per.append({"session": d.name, "bytes": sum(f.stat().st_size for f in d.rglob("*") if f.is_file())})
    tel = Path(root) / "TELEMETRY"
    tel_b = sum(f.stat().st_size for f in tel.rglob("*") if f.is_file()) if tel.is_dir() else 0
    root_b = sum(f.stat().st_size for f in Path(root).rglob("*") if f.is_file())
    vals = sorted(x["bytes"] for x in per)
    mx = vals[-1] if vals else None
    proj = (mx * int(sessions_total) + 2 * tel_b) if mx is not None else None
    return {"sessions_measured": len(per), "per_session": per, "max_session_bytes": mx,
            "mean_session_bytes": (sum(vals) // len(vals)) if vals else None, "telemetry_bytes": tel_b,
            "root_bytes": root_b, "projected_run_growth_bytes_166": proj,
            "note": "medição para re-release futuro de free_space.run_growth_bytes; NÃO aplicada às constantes do R3"}


# --------------------------------------------------------------------------- expectations
def evaluate_step(expect: dict, rec: dict) -> dict:
    """Compara o resultado de uma invocação com a expectativa EFETIVA (fechada) do passo. Sem alternativas."""
    reasons = []
    out = rec.get("outcome") or {}
    if out.get("class") != expect.get("outcome"):
        reasons.append(f"OUTCOME got={out.get('class')}:{out.get('code')}:{out.get('seam')} want={expect.get('outcome')}")
    for k in ("code", "seam"):
        if k in expect and out.get(k) != expect[k]:
            reasons.append(f"OUTCOME_{k.upper()} got={out.get(k)} want={expect[k]}")
    if "detail_contains" in expect and expect["detail_contains"] not in str(out.get("detail", "")):
        reasons.append("OUTCOME_DETAIL_MISSING:" + expect["detail_contains"])
    if expect.get("signal_no_args") and out.get("detail_len") != 0:
        reasons.append("SIGNAL_KEYBOARDINTERRUPT_HAS_ARGS")
    if "blocked_gate" in expect and rec.get("blocked_gate") != expect["blocked_gate"]:
        reasons.append(f"BLOCKED_GATE got={rec.get('blocked_gate')} want={expect['blocked_gate']}")
    if expect.get("safe_stop_line") is True and not rec.get("safe_stop_requested_line"):
        reasons.append("SAFE_STOP_REQUESTED_LINE_MISSING")
    if expect.get("safe_stop_line") is False and rec.get("safe_stop_requested_line"):
        reasons.append("SAFE_STOP_REQUESTED_LINE_UNEXPECTED")
    if "committed" in expect and rec.get("committed_count") != expect["committed"]:
        reasons.append(f"COMMITTED got={rec.get('committed_count')} want={expect['committed']}")
    if expect.get("guard") == "PASS_COMPARED" and rec.get("trace_guard") != "PASS_COMPARED":
        reasons.append("TRACE_GUARD_NOT_COMPARED:" + str(rec.get("trace_guard")))
    if expect.get("root_unchanged") and rec.get("root_digest_before") != rec.get("root_digest_after"):
        reasons.append("ROOT_CHANGED_ON_BLOCKED_STEP")
    if "state_after" in expect and rec.get("state_after") != expect["state_after"]:
        reasons.append(f"STATE_AFTER got={rec.get('state_after')} want={expect['state_after']}")
    if "state_finding" in expect and not any(str(f).startswith(expect["state_finding"]) for f in rec.get("state_after_findings") or []):
        reasons.append("STATE_FINDING_MISSING:" + expect["state_finding"])
    if expect.get("clean_state"):
        d = rec.get("state_after_detail") or {}
        if d.get("journal") or d.get("pending") or rec.get("state_after_findings"):
            reasons.append("STATE_NOT_CLEAN")
    if expect.get("t31b"):
        t = rec.get("t31b") or {}
        if t.get("journal_after_g21") != 0 or (t.get("journal_before_g21") or 0) < int(expect.get("journal_min", 0)):
            reasons.append("T31B_JOURNAL")
    want_before = {"RUN": "PREPARED", "RESUME": "IN_PROGRESS"}.get(rec.get("kind"))
    if rec.get("state_before") is not None and want_before and rec.get("state_before") != want_before:
        reasons.append(f"STATE_BEFORE got={rec.get('state_before')} want={want_before}")
    if expect.get("outcome") == "TERMINATED" and rec.get("orphans_alive"):
        reasons.append("ORPHANS_ALIVE")
    ev = rec.get("runtime_evidence") or {}
    if ev.get("started") and not ev.get("clean") and out.get("class") != "TERMINATED":
        reasons.append("PROCESS_TREE_NOT_CLEAN")
    if (rec.get("t30") or {}).get("foreign"):
        reasons.append("T30_FOREIGN_ENTRY")
    return {"pass": not reasons, "reasons": reasons}


# --------------------------------------------------------------------------- receipts
def write_receipt_with_companion(path: Path, obj: dict, write_json_durable) -> str:
    """Grava (exclusivo), relê e grava o companion positivo. Retorna o SHA do receipt."""
    sha = write_json_durable(path, obj, exclusive=True)
    raw = Path(path).read_bytes()
    if sha_bytes(raw) != sha or load_json_bytes(raw).get("attempt_id") != obj.get("attempt_id"):
        raise HarnessBlocked("RECEIPT_READBACK")
    write_json_durable(companion_path(path),
                       {"schema": VERIFIED_SCHEMA, "receipt_sha256": sha, "attempt_id": obj.get("attempt_id"),
                        "exit_code": obj.get("exit_code"), "readback": "PASS"}, exclusive=True)
    return sha


def companion_path(path) -> Path:
    return Path(str(path)[:-5] + ".VERIFIED.json")


def verify_receipt_with_companion(path: Path, schema: str, attempt_id: str, exit_code=None) -> dict:
    """R1-03: o companion só valida um receipt NÃO contraditório. Exige: schema do companion; receipt_sha256 = SHA
    físico; attempt_id igual ao do receipt (e ao esperado); companion.exit_code == receipt.exit_code (inteiros);
    se exit_code esperado for dado, ambos iguais a ele; readback == PASS; chaves do companion exatamente as do
    contrato (nada de 'mode' ou outro campo não contratual neste esquema). Qualquer divergência => inválido."""
    p = Path(path)
    if not p.is_file():
        return {"valid": False, "reason": "RECEIPT_MISSING"}
    raw = p.read_bytes()
    sha = sha_bytes(raw)
    try:
        d = load_json_bytes(raw)
    except HarnessBlocked:
        return {"valid": False, "reason": "RECEIPT_JSON_INVALID", "sha256": sha}
    if not isinstance(d, dict) or d.get("schema") != schema or d.get("attempt_id") != attempt_id:
        return {"valid": False, "reason": "RECEIPT_SCHEMA_OR_ATTEMPT", "sha256": sha}
    rx = d.get("exit_code")
    if type(rx) is not int:
        return {"valid": False, "reason": "RECEIPT_EXIT_NOT_INT", "sha256": sha}
    if exit_code is not None and rx != exit_code:
        return {"valid": False, "reason": "RECEIPT_EXIT_NE_NATIVE", "sha256": sha}
    cp = companion_path(p)
    if not cp.is_file():
        return {"valid": False, "reason": "COMPANION_MISSING", "sha256": sha}
    craw = cp.read_bytes()
    try:
        comp = load_json_bytes(craw)
    except HarnessBlocked:
        return {"valid": False, "reason": "COMPANION_JSON_INVALID", "sha256": sha}
    if not isinstance(comp, dict) or comp.get("schema") != VERIFIED_SCHEMA:
        return {"valid": False, "reason": "COMPANION_SCHEMA", "sha256": sha}
    if set(comp) != COMPANION_KEYS:
        return {"valid": False, "reason": "COMPANION_KEYS", "sha256": sha}
    if comp.get("receipt_sha256") != sha:
        return {"valid": False, "reason": "COMPANION_SHA_NE_RECEIPT", "sha256": sha}
    if comp.get("attempt_id") != d.get("attempt_id"):
        return {"valid": False, "reason": "COMPANION_ATTEMPT_NE_RECEIPT", "sha256": sha}
    cx = comp.get("exit_code")
    if type(cx) is not int or cx != rx:
        return {"valid": False, "reason": "COMPANION_EXIT_NE_RECEIPT", "sha256": sha}
    if exit_code is not None and cx != exit_code:
        return {"valid": False, "reason": "COMPANION_EXIT_NE_EXPECTED", "sha256": sha}
    if comp.get("readback") != "PASS":
        return {"valid": False, "reason": "COMPANION_READBACK_NOT_PASS", "sha256": sha}
    return {"valid": True, "reason": "OK", "sha256": sha, "doc": d, "companion_sha256": sha_bytes(craw)}


# --------------------------------------------------------------------------- processes
WIN = os.name == "nt"
CREATE_NO_WINDOW = 0x08000000


def _k32():
    """kernel32 com assinaturas declaradas (handles de 64 bits; erros checados)."""
    import ctypes
    from ctypes import wintypes
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    H, D, B = wintypes.HANDLE, wintypes.DWORD, wintypes.BOOL
    k.CreateToolhelp32Snapshot.argtypes, k.CreateToolhelp32Snapshot.restype = [D, D], H
    k.OpenProcess.argtypes, k.OpenProcess.restype = [D, B, D], H
    k.CloseHandle.argtypes, k.CloseHandle.restype = [H], B
    k.GetProcessTimes.argtypes = [H] + [ctypes.POINTER(wintypes.FILETIME)] * 4
    k.GetProcessTimes.restype = B
    k.GetExitCodeProcess.argtypes, k.GetExitCodeProcess.restype = [H, ctypes.POINTER(D)], B
    k.TerminateProcess.argtypes, k.TerminateProcess.restype = [H, wintypes.UINT], B
    k.AttachConsole.argtypes, k.AttachConsole.restype = [D], B
    k.FreeConsole.argtypes, k.FreeConsole.restype = [], B
    k.SetConsoleCtrlHandler.argtypes, k.SetConsoleCtrlHandler.restype = [ctypes.c_void_p, B], B
    k.GenerateConsoleCtrlEvent.argtypes, k.GenerateConsoleCtrlEvent.restype = [D, D], B
    return k


def _win_snapshot():
    import ctypes
    from ctypes import wintypes

    class PE(ctypes.Structure):
        _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD), ("th32ProcessID", wintypes.DWORD),
                    ("th32DefaultHeapID", ctypes.c_size_t), ("th32ModuleID", wintypes.DWORD),
                    ("cntThreads", wintypes.DWORD), ("th32ParentProcessID", wintypes.DWORD),
                    ("pcPriClassBase", wintypes.LONG), ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260)]
    k = _k32()
    k.Process32FirstW.argtypes = k.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PE)]
    k.Process32FirstW.restype = k.Process32NextW.restype = wintypes.BOOL
    snap = k.CreateToolhelp32Snapshot(0x2, 0)
    if snap is None or snap == wintypes.HANDLE(-1).value:
        raise HarnessBlocked("PROCESS_SNAPSHOT_FAILED", str(ctypes.get_last_error()))
    rows = []
    e = PE()
    e.dwSize = ctypes.sizeof(PE)
    try:
        ctypes.set_last_error(0)
        ok = k.Process32FirstW(snap, ctypes.byref(e))
        while ok:
            rows.append((int(e.th32ProcessID), int(e.th32ParentProcessID), str(e.szExeFile)))
            ctypes.set_last_error(0)
            ok = k.Process32NextW(snap, ctypes.byref(e))
        error = ctypes.get_last_error()
        if error != 18:  # ERROR_NO_MORE_FILES is the only complete enumeration.
            raise HarnessBlocked("PROCESS_SNAPSHOT_INCOMPLETE", str(error))
    finally:
        k.CloseHandle(snap)
    return rows


def _win_process_observation(pid: int) -> dict:
    """One handle, checked API returns. Visibility failures remain UNKNOWN."""
    import ctypes
    from ctypes import wintypes
    k = _k32()
    obs = dict(present=True, open_succeeded=False, exit_query_succeeded=False,
               exit_code=None, creation_time=None, api_error=None)
    h = k.OpenProcess(0x1000, False, pid)
    if not h:
        obs["api_error"] = ctypes.get_last_error()
        return obs
    try:
        obs["open_succeeded"] = True
        code = wintypes.DWORD()
        if not k.GetExitCodeProcess(h, ctypes.byref(code)):
            obs["api_error"] = ctypes.get_last_error()
            return obs
        obs["exit_query_succeeded"] = True
        obs["exit_code"] = int(code.value)
        c, e, kk, u = (wintypes.FILETIME() for _ in range(4))
        if k.GetProcessTimes(h, ctypes.byref(c), ctypes.byref(e), ctypes.byref(kk), ctypes.byref(u)):
            obs["creation_time"] = (c.dwHighDateTime << 32) | c.dwLowDateTime
        else:
            obs["api_error"] = ctypes.get_last_error()
        return obs
    finally:
        k.CloseHandle(h)


def _win_ctime(pid: int):
    obs = _win_process_observation(pid)
    if obs["exit_query_succeeded"] and obs["exit_code"] == 259:
        return obs["creation_time"]
    return None


def _posix_rows():
    rows = []
    for d in Path("/proc").iterdir():
        if d.name.isdigit():
            try:
                st = (d / "stat").read_text()
                rest = st[st.rindex(")") + 2:].split()
                rows.append((int(d.name), int(rest[1]), int(rest[2]), int(rest[19]), rest[0]))
            except FileNotFoundError:  # raced a kernel process removal, no object remains
                continue
            except (OSError, ValueError, IndexError) as exc:
                raise HarnessBlocked("PROCESS_CENSUS_UNKNOWN", d.name) from exc
    return rows



def process_liveness(pid: int, expected_ctime=None) -> str:
    """Tri-state-plus-reuse liveness for an owned identity.

    Visibility failure is UNKNOWN and therefore must block admission. PID_REUSED means
    the numeric PID is occupied, but not by the expected owned process identity.
    """
    import qs4_attempt_lifecycle_v002 as LV2
    if WIN:
        rows = _win_snapshot()
        present = any(int(p) == int(pid) for p, _pp, _name in rows)
        if not present:
            return LV2.TERMINATED
        obs = _win_process_observation(pid)
        obs.pop("api_error", None)
        return LV2.classify_process_observation(**obs, expected_creation_time=expected_ctime)
    current = None
    for r in _posix_rows():
        if r[0] == pid and r[4] != "Z":
            current = r[3]
            break
    if current is None:
        return LV2.TERMINATED
    if expected_ctime is None:
        return LV2.UNKNOWN
    return LV2.PID_REUSED if current != expected_ctime else LV2.ALIVE


def durable_failed_cases(ledger):
    import qs4_attempt_lifecycle_v002 as LV2
    return LV2.durable_failed_cases(ledger)


def attempt_lifecycle_state(ledger):
    import qs4_attempt_lifecycle_v002 as LV2
    return LV2.attempt_lifecycle_state(ledger)


def assert_resume_allowed(ledger):
    import qs4_attempt_lifecycle_v002 as LV2
    try:
        return LV2.assert_resume_allowed(ledger)
    except LV2.LifecycleBlocked as e:
        raise HarnessBlocked(e.code, e.detail) from e


def process_ctime(pid: int):
    """Identidade temporal de um processo vivo (Windows: creation time; POSIX: starttime em ticks)."""
    if WIN:
        return _win_ctime(pid)
    for r in _posix_rows():
        if r[0] == pid and r[4] != "Z":
            return r[3]
    return None


CONSOLE_HOSTS = ("conhost.exe", "openconsole.exe")


def session_processes(session: str, exclude_pid: int | None = None) -> list:
    """Processos vivos marcados com QS4_HARNESS_SESSION=<sessão> (POSIX: /proc/<pid>/environ). No Windows a mesma
    prova é feita por descendants(owner_pid, owner_ctime): o PPID do Toolhelp persiste após a morte do pai."""
    if WIN:
        return []
    want = ("QS4_HARNESS_SESSION=" + session).encode()
    out = []
    for r in _posix_rows():
        if r[4] == "Z" or r[0] == exclude_pid:
            continue
        try:
            env = Path(f"/proc/{r[0]}/environ").read_bytes().split(b"\0")
        except FileNotFoundError:
            continue
        except OSError as exc:
            raise HarnessBlocked("SESSION_PROCESS_CENSUS_UNKNOWN", str(r[0])) from exc
        if want in env:
            out.append((r[0], r[3]))
    return out


def descendants(pid: int, root_ctime=None) -> list:
    """[(pid, ctime)] dos descendentes vivos de pid. Seguro contra reuso de PID: em cada aresta o filho precisa ter
    creation time >= o do pai; se o pid raiz estiver hoje ocupado por OUTRO processo (reuso), filhos criados depois do
    reusador são dele e ficam fora. POSIX inclui o mesmo grupo de processo (filhos reparentados)."""
    if WIN:
        rows = _win_snapshot()
        names = {p: n.casefold() for p, _pp, n in rows}
        kids_of: dict = {}
        for p, pp, _n in rows:
            kids_of.setdefault(pp, []).append(p)
        cache: dict = {}

        def ct(x):
            if x not in cache:
                cache[x] = _win_ctime(x)
            return cache[x]
        now_root = ct(pid)
        if kids_of.get(pid) and (root_ctime is None or (pid in names and now_root is None)):
            raise HarnessBlocked("DESCENDANT_ROOT_IDENTITY_UNKNOWN", str(pid))
        reuse = now_root if (root_ctime is not None and now_root is not None and now_root != root_ctime) else None
        out, frontier, seen = [], [(pid, root_ctime)], {pid}
        while frontier:
            node, nct = frontier.pop()
            for k in kids_of.get(node, []):
                if k in seen:
                    continue
                kc = ct(k)
                if kc is None:
                    raise HarnessBlocked("DESCENDANT_IDENTITY_UNKNOWN", str(k))
                if nct is not None and kc < nct:
                    continue
                if node == pid and reuse is not None and kc >= reuse:
                    continue
                seen.add(k)
                frontier.append((k, kc))
                if names.get(k) not in CONSOLE_HOSTS:  # host de console do alvo não é trabalho do harness/CODE
                    out.append((k, kc))
        return sorted(out)
    rows = _posix_rows()
    by = {r[0]: r for r in rows if r[4] != "Z"}
    kids_of: dict = {}
    for r in by.values():
        kids_of.setdefault(r[1], []).append(r[0])
    now = by.get(pid)
    reuse = now[3] if (root_ctime is not None and now is not None and now[3] != root_ctime) else None
    out, frontier, seen = {}, [(pid, root_ctime)], {pid}
    while frontier:
        node, nct = frontier.pop()
        for k in kids_of.get(node, []):
            kc = by[k][3]
            if k in seen or (nct is not None and kc < nct) or (node == pid and reuse is not None and kc >= reuse):
                continue
            seen.add(k)
            frontier.append((k, kc))
            out[k] = kc
    for r in by.values():  # mesmo grupo de processo (filhos reparentados após a morte do pai)
        if r[2] == pid and r[0] != pid and (root_ctime is None or r[3] >= root_ctime) and (reuse is None or r[3] < reuse):
            out[r[0]] = r[3]
    return sorted(out.items())


def alive(pid: int, ctime) -> bool:
    import qs4_attempt_lifecycle_v002 as LV2
    state = process_liveness(pid, ctime)
    if state == LV2.UNKNOWN:
        raise HarnessBlocked("PROCESS_LIVENESS_UNKNOWN", str(pid))
    return state == LV2.ALIVE


def terminate_p10(pid: int) -> None:
    """ÚNICO kill do harness (T18 P10): TerminateProcess do filho do próprio caso (handle mantido pelo Popen)."""
    if WIN:
        import ctypes
        k = _k32()
        h = k.OpenProcess(0x0001, False, pid)  # PROCESS_TERMINATE
        if not h:
            raise HarnessBlocked("P10_OPEN_PROCESS_FAILED", str(ctypes.get_last_error()))
        try:
            if not k.TerminateProcess(h, 1):
                raise HarnessBlocked("P10_TERMINATE_FAILED", str(ctypes.get_last_error()))
        finally:
            k.CloseHandle(h)
    else:
        import signal
        os.kill(pid, signal.SIGKILL)


def ctrl_c_attached(pid: int) -> int:
    """Executado no processo AUXILIAR (Windows): entrega CTRL_C_EVENT ao console oculto do filho."""
    k = _k32()
    k.FreeConsole()
    if not k.AttachConsole(int(pid)):
        return 2
    k.SetConsoleCtrlHandler(None, True)
    ok = k.GenerateConsoleCtrlEvent(0, 0)
    time.sleep(1.0)
    k.FreeConsole()
    return 0 if ok else 2


CREATE_NEW_CONSOLE = 0x00000010


def popen_kwargs(console: bool = False) -> dict:
    """Filhos comuns: CREATE_NO_WINDOW (sem console). console=True SOMENTE para o filho P5 e o alvo do microprobe P5:
    CREATE_NEW_CONSOLE com janela oculta (SW_HIDE) => console PRÓPRIO real, ao qual o auxiliar consegue se anexar
    (AttachConsole falha para processos sem console). Nunca CREATE_NEW_PROCESS_GROUP (desabilitaria o CTRL_C)."""
    if WIN:
        if console:
            si = subprocess.STARTUPINFO()
            si.dwFlags |= 0x00000001  # STARTF_USESHOWWINDOW
            si.wShowWindow = 0  # SW_HIDE: console real, janela oculta (o owner não fecha a janela por engano)
            return {"creationflags": CREATE_NEW_CONSOLE, "startupinfo": si}
        return {"creationflags": CREATE_NO_WINDOW}
    return {"start_new_session": True}


def enable_ctrl_c() -> dict:
    """No processo-alvo do CTRL_C (filho P5 / alvo do microprobe): garante o processamento de CTRL+C mesmo que o
    atributo 'ignorar CTRL+C' tenha sido herdado (SetConsoleCtrlHandler(NULL, FALSE)). POSIX: nada a fazer."""
    if not WIN:
        return {"platform": "POSIX", "enabled": True}
    import ctypes
    k = _k32()
    ok = bool(k.SetConsoleCtrlHandler(None, False))
    return {"platform": "WIN32", "enabled": ok, "last_error": ctypes.get_last_error()}


def progress_view(done: int, total: int, reconciled: bool = False, width: int = 30) -> dict:
    """Progresso canônico SOMENTE pelo trabalho durável (unidades no ledger). PCT=100 só com receipt final reconciliado."""
    total = max(int(total), 1)
    pct = 100.0 * int(done) / total
    if not reconciled:
        pct = min(pct, 99.9)
    filled = int(round(width * pct / 100.0))
    bar = "[" + "#" * filled + "-" * (width - filled) + f"] {pct:5.1f}% {int(done)}/{total}"
    return {"PCT": f"{pct:.1f}", "BAR": bar, "DURABLE_UNITS": int(done), "TOTAL_UNITS": total, "RECONCILED": bool(reconciled)}


# --------------------------------------------------------------------------- ledger (checkpoint/resume do harness)
LEDGER_SCHEMA = "MINOTAURO_PHASE_B_QS4_LEDGER_V001"


def ledger_seal(doc: dict) -> dict:
    body = {k: v for k, v in doc.items() if k != "ledger_sha256"}
    out = dict(body)
    out["ledger_sha256"] = sha_bytes(canon(body))
    return out


def _journal_entries(raw: str):
    """(entradas válidas, SHAs de linhas inválidas pendentes, fragmento final não terminado). Linhas inválidas só são
    toleradas se forem seguidas de um JOURNAL_REPAIR que liste exatamente os seus SHAs (restos de quedas no append)."""
    parts = raw.split("\n")
    complete, fragment = parts[:-1], parts[-1]
    entries, pending = [], []
    for ln in complete:
        if not ln.strip():
            continue
        try:
            e = load_json_bytes(ln.encode("utf-8"))
        except HarnessBlocked:
            pending.append(sha_bytes(ln.encode("utf-8")))
            continue
        if pending:
            if e.get("event") != "JOURNAL_REPAIR" or e.get("skipped_fragment_sha256s") != pending:
                raise HarnessBlocked("RESUME_LEDGER_INTEGRITY", "journal_garbage")
            pending = []
        entries.append(e)
    return entries, pending, fragment


def ledger_verify(path: Path, journal: Path) -> dict:
    """Integridade: schema, auto-hash do ledger e cadeia completa do diário append-only. Tolera EXATAMENTE as quedas
    entre o replace do ledger e o append do diário (ledger.seq = cauda+1 e prev = SHA da cauda), inclusive linha
    truncada, linha completa sem '\\n' e queda durante um reparo anterior: devolve '_journal_repair' para a retomada
    completar o diário por APPEND (nada é apagado). Qualquer outra divergência => RESUME_LEDGER_INTEGRITY."""
    p, j = Path(path), Path(journal)
    if not p.is_file() or not j.is_file():
        raise HarnessBlocked("RESUME_LEDGER_MISSING", str(p))
    doc = load_json_bytes(p.read_bytes())
    if doc.get("schema") != LEDGER_SCHEMA:
        raise HarnessBlocked("RESUME_LEDGER_SCHEMA")
    if ledger_seal(doc)["ledger_sha256"] != doc.get("ledger_sha256"):
        raise HarnessBlocked("RESUME_LEDGER_INTEGRITY", "self_hash")
    entries, pending, fragment = _journal_entries(j.read_bytes().decode("utf-8", "replace"))
    if not entries:
        raise HarnessBlocked("RESUME_LEDGER_INTEGRITY", "journal_empty")
    prev = None
    for i, e in enumerate(entries):
        if e.get("seq") != i + 1 or e.get("prev_ledger_sha256") != prev:
            raise HarnessBlocked("RESUME_LEDGER_INTEGRITY", f"journal_chain@{i + 1}")
        prev = e.get("ledger_sha256")
    tail = entries[-1]
    if tail.get("ledger_sha256") == doc["ledger_sha256"] and tail.get("seq") == doc.get("seq") and not pending and not fragment:
        return doc
    if doc.get("seq") == tail.get("seq") + 1 and doc.get("prev_ledger_sha256") == tail.get("ledger_sha256"):
        expected = {"seq": doc["seq"], "ledger_sha256": doc["ledger_sha256"], "prev_ledger_sha256": doc["prev_ledger_sha256"]}
        try:
            fdoc = load_json_bytes(fragment.encode("utf-8")) if fragment.strip() else None
        except HarnessBlocked:
            fdoc = None
        out = dict(doc)
        if (isinstance(fdoc, dict) and all(fdoc.get(k) == v for k, v in expected.items())
                and (fdoc.get("skipped_fragment_sha256s") or []) == pending):
            out["_journal_repair"] = {"mode": "TERMINATE_LINE", "missing_seq": doc["seq"]}  # linha inteira, falta só o '\\n'
        else:
            skipped = pending + ([sha_bytes(fragment.encode("utf-8"))] if fragment else [])
            out["_journal_repair"] = {"mode": "APPEND", "missing_seq": doc["seq"], "skipped": skipped,
                                      "needs_newline": bool(fragment)}
        return out
    raise HarnessBlocked("RESUME_LEDGER_INTEGRITY", "journal_tail")


def ledger_repair_journal(journal: Path, doc: dict) -> dict:
    """Completa o diário (queda entre ledger e diário). Append-only; restos preservados e listados por SHA."""
    rep = doc["_journal_repair"]
    line = {"seq": doc["seq"], "ledger_sha256": doc["ledger_sha256"], "prev_ledger_sha256": doc["prev_ledger_sha256"],
            "event": "JOURNAL_REPAIR", "mode": rep["mode"], "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    if rep["mode"] == "TERMINATE_LINE":
        data = "\n"
    else:
        if rep.get("skipped"):
            line["skipped_fragment_sha256s"] = list(rep["skipped"])
        data = ("\n" if rep.get("needs_newline") else "") + json.dumps(line, sort_keys=True, separators=(",", ":")) + "\n"
    with open(journal, "a", encoding="utf-8", newline="\n") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    return line


def ledger_write(path: Path, journal: Path, doc: dict, write_atomic, event: str) -> dict:
    """Grava o ledger (tmp+fsync+replace via R3) e encadeia no diário append-only (fsync). Relê e confere."""
    doc = dict(doc)
    doc["prev_ledger_sha256"] = doc.get("ledger_sha256")
    doc["seq"] = int(doc.get("seq") or 0) + 1
    doc["updated_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    sealed = ledger_seal(doc)
    write_atomic(path, sealed)
    back = load_json_bytes(Path(path).read_bytes())
    if back.get("ledger_sha256") != sealed["ledger_sha256"] or ledger_seal(back)["ledger_sha256"] != sealed["ledger_sha256"]:
        raise HarnessBlocked("LEDGER_READBACK")
    line = json.dumps({"seq": sealed["seq"], "ledger_sha256": sealed["ledger_sha256"],
                       "prev_ledger_sha256": sealed["prev_ledger_sha256"], "event": event,
                       "utc": sealed["updated_utc"]}, sort_keys=True, separators=(",", ":"))
    with open(journal, "a", encoding="utf-8", newline="\n") as f:
        f.write(line + "\n")
        f.flush()
        os.fsync(f.fileno())
    return sealed


class AttemptLock:
    """Exclusão de sessões do MESMO attempt lógico. Windows: mutex nomeado Global (liberado pelo SO na morte do
    processo; mesma primitiva do R3). POSIX (sandbox): flock num arquivo de lock (nunca removido)."""

    def __init__(self, logical: str, lock_dir: Path, platform_factory=None):
        self.name = "Global\\MinotauroQS4Harness_" + hashlib.sha256(logical.casefold().encode()).hexdigest()
        self.path = Path(lock_dir) / "QS4_ATTEMPT.lock"
        self.platform_factory = platform_factory
        self.h = None
        self.fd = None

    def acquire(self) -> None:
        if WIN:
            plat = self.platform_factory()
            try:
                self.h = plat.acquire_named_mutex(self.name)
            except Exception as e:  # noqa: BLE001
                raise HarnessBlocked("RESUME_ATTEMPT_LOCKED", getattr(e, "code", type(e).__name__)) from e
            self.plat = plat
            return
        import fcntl
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.fd = os.open(self.path, os.O_RDWR | os.O_CREAT, 0o644)
        try:
            fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as e:
            os.close(self.fd)
            self.fd = None
            raise HarnessBlocked("RESUME_ATTEMPT_LOCKED", str(self.path)) from e




def python_cmd() -> list:
    return [sys.executable, "-B"]
