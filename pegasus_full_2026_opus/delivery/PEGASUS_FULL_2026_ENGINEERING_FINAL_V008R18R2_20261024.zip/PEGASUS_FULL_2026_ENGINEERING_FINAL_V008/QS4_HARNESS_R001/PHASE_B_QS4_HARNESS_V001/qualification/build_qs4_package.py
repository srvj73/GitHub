"""PHASE_B_QS4_HARNESS_V001 — gera MANIFEST_SHA256.txt e HARNESS_IDENTITY.json (sandbox de auditoria).
Também fixa em qs4_constants.json o SHA do envelope do harness (qualification/CHANGE_ENVELOPE_QS4_HARNESS_V001.json).
Uso: python -B qualification/build_qs4_package.py <PHASE_B_QS4_HARNESS_V001_dir>"""
import hashlib
import json
import sys
from pathlib import Path


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()


def main(root):
    root = Path(root).resolve()
    if any(d.name == "__pycache__" for d in root.rglob("*") if d.is_dir()):
        raise SystemExit("PYCACHE_PRESENT")
    cpath = root / "qs4_constants.json"
    c = json.loads(cpath.read_text(encoding="utf-8"))
    env = root / "qualification" / c["harness_envelope"]["file"]
    if c["harness_envelope"]["sha256"] != sha(env):
        c["harness_envelope"]["sha256"] = sha(env)
        cpath.write_text(json.dumps(c, indent=1, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    skip = {"MANIFEST_SHA256.txt", "HARNESS_IDENTITY.json"}
    rels = sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and p.relative_to(root).as_posix() not in skip)
    (root / "MANIFEST_SHA256.txt").write_bytes("".join(f"{sha(root / r)}  {r}\n" for r in rels).encode("ascii"))
    man = sha(root / "MANIFEST_SHA256.txt")
    ident = {"schema": "MINOTAURO_PHASE_B_QS4_HARNESS_IDENTITY_V001", "harness_version": c["harness_version"],
             "harness_identity_sha256": man, "manifest_sha256": man, "constants_sha256": sha(cpath),
             "harness_envelope_sha256": c["harness_envelope"]["sha256"],
             "adapter_identity_sha256": c["adapter"]["identity_sha256"], "files": len(rels)}
    (root / "HARNESS_IDENTITY.json").write_bytes((json.dumps(ident, indent=1, sort_keys=True) + "\n").encode("utf-8"))
    print("HARNESS_IDENTITY_SHA256=" + man)
    print("FILES=" + str(len(rels)))


if __name__ == "__main__":
    main(sys.argv[1])
