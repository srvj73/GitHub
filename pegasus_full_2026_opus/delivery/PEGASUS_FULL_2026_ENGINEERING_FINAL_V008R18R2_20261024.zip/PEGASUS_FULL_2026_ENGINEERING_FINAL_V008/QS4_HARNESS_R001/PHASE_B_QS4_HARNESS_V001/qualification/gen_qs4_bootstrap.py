"""PHASE_B_QS4_HARNESS_V001 — gerador do BOOTSTRAP_QS4_HARNESS.ps1 (sandbox de auditoria).
Uso: python -B qualification/gen_qs4_bootstrap.py <BOOTSTRAP_PHASE_B_ADAPTER.ps1 do R3> <saida.ps1>
As funções de infraestrutura listadas em REUSE são extraídas VERBATIM do bootstrap R3; o restante é próprio do QS4."""
import re
import sys
from pathlib import Path
R3 = Path(sys.argv[1]).read_bytes()[3:].decode("utf-8").replace("\r\n", "\n")
REUSE = ["Write-Line", "Get-Sha256", "Read-SharedText", "Get-BytesSha256", "Read-SharedBytes", "Write-AtomicText",
         "Get-JsonProp", "Format-Eta", "New-StatusFields", "Set-BootstrapStatus", "Read-AdapterStatus", "Write-Heartbeat",
         "Invoke-Child", "Resolve-ChildOutcome", "Get-TextSha256", "Invoke-T26Probes", "Expand-AdapterPackage",
         "Write-StageReceipt", "Resolve-FinalExit", "Get-StageExit"]
def body(name):
    m = re.search(r"^function " + re.escape(name) + r"\b.*?(?=^function |^# =+ execução)", R3, re.S | re.M)
    assert m, name
    return m.group(0).rstrip("\n") + "\n"
reused = "\n".join(body(n) for n in REUSE)
head = r'''<#
PHASE_B_QS4_HARNESS_V001 — BOOTSTRAP QS4 (Windows PowerShell 5.1)
ESTADO: especificação executável SOMENTE após auditoria externa do harness e autorização explícita do owner
        com o texto exato 'AUTORIZO QS4 PHASE_B_ADAPTER_V001 R3'. Não aceita QS2, QS3, RUN nem Phase C.
Uso (a partir de C:\Users\silvi):
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File <caminho>\BOOTSTRAP_QS4_HARNESS.ps1 `
      -Stage QS4_SHADOW -HarnessZip <zip harness> -HarnessZipSha256 <sha> `
      -R3PackageZip <zip R3> -R3PackageZipSha256 F14E7B149BDFB5184D09116122C7A6264F7A4798E08799DEBD852B45E959A775 `
      -Qs3Receipt <caminho ABSOLUTO do QS3_RECEIPT.json PASS> -Qs3ReceiptSha256 <sha completo> `
      -AuthorizationText "AUTORIZO QS4 PHASE_B_ADAPTER_V001 R3" [-ResumeQs4AttemptId <ATTEMPT_ID lógico a retomar>]
Retomada (Q4-02): -ResumeQs4AttemptId continua o attempt lógico a partir da fronteira durável do ledger do harness
     (QS4_LEDGER.json), depois de revalidar bytes, identidades e entradas; nada é apagado nem refeito em duplicidade.
     Processo vivo da sessão anterior (orquestrador ou filho) => BLOCKED até a reconciliação humana.
Progresso: PROGRESS/TOTAL = unidades DURÁVEIS (45 passos); PCT=100 somente com o receipt final reconciliado.
MULTIWORK=NOT_APPLICABLE (R3_GLOBAL_NAMED_MUTEX + REFERENCE_CAUSAL_ORDER + TEST_ISOLATION).
T18: PASS NÃO significa auto-resume em P1–P3 (fail-closed; exigem reconciliação humana).
P5 (Windows 11): antes do QS4, definir o terminal padrão como "Host do Console do Windows" (com o Windows Terminal como
     padrão o console oculto do filho P5 pode aparecer); NUNCA fechar janelas de console abertas durante o QS4.
Log: caminho absoluto fixo D:\MinotauroRuns\MINOTAURO_PHASE_B_ADAPTER_EVIDENCE\<ATTEMPT_ID>\BOOTSTRAP.log, independente do
     diretório corrente. Status: <mesma pasta>\BOOTSTRAP_STATUS.json. Receipt do estágio: <mesma pasta>\QS4_RECEIPT.json.
Funções de infraestrutura copiadas VERBATIM do BOOTSTRAP R3 (identidade 2184D8F9…); QS0-H verifica a igualdade byte a byte.
Regras: exit nativo via System.Diagnostics.Process; sem Start-Process; sem sentinela de $LASTEXITCODE; identidade por
SHA-256 completo; watchdog finito SEM auto-kill; heartbeat <= 30 s com os 11 campos; receipt e status obrigatórios (B02/B08).
#>
param(
    [Parameter(Mandatory = $true)][ValidateSet('QS4_SHADOW')][string]$Stage,
    [Parameter(Mandatory = $true)][string]$HarnessZip,
    [Parameter(Mandatory = $true)][ValidatePattern('^[0-9A-Fa-f]{64}$')][string]$HarnessZipSha256,
    [Parameter(Mandatory = $true)][string]$R3PackageZip,
    [Parameter(Mandatory = $true)][ValidatePattern('^[0-9A-Fa-f]{64}$')][string]$R3PackageZipSha256,
    [Parameter(Mandatory = $true)][string]$Qs3Receipt,
    [Parameter(Mandatory = $true)][ValidatePattern('^[0-9A-Fa-f]{64}$')][string]$Qs3ReceiptSha256,
    [Parameter(Mandatory = $true)][string]$AuthorizationText,
    [Parameter(Mandatory = $false)][string]$ResumeQs4AttemptId = ''
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$ProjectLine     = 'PROJECT=Pegasus Original | THREAD=Implementacao Runner Paralelo 7'
$PythonExe       = 'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe'
$PythonSha256    = '4942B86A6597E5AEE0128DAA00050ED79BC21F6E709A78EB19CBFEB0C2F39AC9'
$PackageBase     = 'D:\MinotauroRuns\MINOTAURO_PHASE_B_ADAPTER_PKG'
$EvidenceBase    = 'D:\MinotauroRuns\MINOTAURO_PHASE_B_ADAPTER_EVIDENCE'
$ReleaseRoot     = 'D:\MinotauroRuns\MINOTAURO_R1R11_FULL_2026_R3_RELEASE_20261001'
$StageText       = 'AUTORIZO QS4 PHASE_B_ADAPTER_V001 R3'
$R3ZipPinned     = 'F14E7B149BDFB5184D09116122C7A6264F7A4798E08799DEBD852B45E959A775'
$R3IdentityPinned = '05A0CF3D807A63BA7FD5BB36374D93E56E3D727183CFD3C62D3C0D637F1DDD0A'
$Utf8NoBom       = New-Object System.Text.UTF8Encoding($false)
$StatusFields    = @('PHASE', 'PROGRESS', 'COMMITTED', 'TOTAL', 'RATE', 'ETA', 'FINISH', 'ACTIVE', 'READY_WAITING', 'CHECKPOINT', 'SAFE_STOP')
$HeartbeatMs     = 30000
$WatchdogSeconds = @{ 'PROBE' = 120; 'QS4_HARNESS' = 259200 }
$StderrDrainMs   = 60000
$ContractExits   = @(0, 2, 3, 130)
$Qs4Items        = @('T16', 'T17', 'T18', 'T22', 'T29', 'T30', 'T31b', 'T33', 'GROWTH_G16')
$RequiredItems   = @{ 'QS4_SHADOW' = @('T26', 'QS4_HARNESS', 'T16', 'T17', 'T18', 'T22', 'T29', 'T30', 'T31b', 'T33', 'GROWTH_G16') }

$NonceBytes = New-Object byte[] 4
$Rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
$Rng.GetBytes($NonceBytes)
$Rng.Dispose()
$Nonce = -join ($NonceBytes | ForEach-Object { $_.ToString('x2') })
$AttemptId  = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ') + '_' + $Nonce
$AttemptDir = Join-Path $EvidenceBase $AttemptId
$LogPath    = Join-Path $AttemptDir 'BOOTSTRAP.log'
$BootstrapStatusPath = Join-Path $AttemptDir 'BOOTSTRAP_STATUS.json'
$StageReceiptPath = Join-Path $AttemptDir 'QS4_RECEIPT.json'
$FinalCode  = 2
$Frontier   = 'NONE'
$BlockedReason = $null
$Items = [ordered]@{}
$Facts = [ordered]@{}
$script:StatusSeq = 0
$script:StatusWriteFailures = 0
$script:FinalStatusWritten = $false
$script:Checkpoint = 'NONE'
$script:AdapterChildStarted = $false
$script:Unproven = $false
$script:MainCompleted = $false
$script:LastReceiptDoc = $null
$script:LastStatusSha256 = $null
$script:HarnessIdentity = $null
$script:Qs4Logical = $null
$script:Qs4Pct = '0.0'

# ============================================================================ funções (verbatim do R3)
'''
own = r'''
# ============================================================================ funções próprias do QS4
function Test-HarnessReceipt([string]$Path, $NativeExit) {
    # B02/B08: receipt do orquestrador QS4 só é aceito com companion, exit igual ao nativo e status final vinculado.
    $r = [ordered]@{ path = $Path; present = $false; valid = $false; reason = 'RECEIPT_MISSING'; sha256 = $null; result = $null }
    $script:LastReceiptDoc = $null
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $r }
    $r.present = $true
    $raw = Read-SharedBytes $Path
    $r.sha256 = Get-BytesSha256 $raw
    try { $doc = $Utf8NoBom.GetString($raw).TrimStart([char]0xFEFF) | ConvertFrom-Json } catch { $r.reason = 'RECEIPT_JSON_INVALID'; return $r }
    $r.result = Get-JsonProp $doc 'result'
    if ((Get-JsonProp $doc 'schema') -ne 'MINOTAURO_PHASE_B_QS4_HARNESS_RECEIPT_V001') { $r.reason = 'RECEIPT_SCHEMA'; return $r }
    if ((Get-JsonProp $doc 'attempt_id') -ne $AttemptId) { $r.reason = 'RECEIPT_ATTEMPT_ID'; return $r }
    if ($null -eq $NativeExit -or (Get-JsonProp $doc 'exit_code') -ne $NativeExit) { $r.reason = 'RECEIPT_EXIT_CODE_NE_NATIVE'; return $r }
    $want = 'NOT_PASS'
    if ($NativeExit -eq 0) { $want = 'PASS' }
    if ($r.result -ne $want) { $r.reason = 'RECEIPT_RESULT_NE_NATIVE'; return $r }
    if ((Get-JsonProp $doc 'r3_identity_sha256') -ne $R3IdentityPinned) { $r.reason = 'RECEIPT_R3_IDENTITY'; return $r }
    if ($null -eq $script:HarnessIdentity -or (Get-JsonProp $doc 'harness_identity_sha256') -ne $script:HarnessIdentity) { $r.reason = 'RECEIPT_HARNESS_IDENTITY'; return $r }
    if ($null -eq $script:Qs4Logical -or (Get-JsonProp $doc 'logical_attempt') -cne $script:Qs4Logical) { $r.reason = 'RECEIPT_LOGICAL_ATTEMPT'; return $r }
    if ((Get-JsonProp (Get-JsonProp $doc 'multiwork') 'value') -cne 'NOT_APPLICABLE') { $r.reason = 'RECEIPT_MULTIWORK'; return $r }
    $cp = $Path.Substring(0, $Path.Length - 5) + '.VERIFIED.json'
    if (-not (Test-Path -LiteralPath $cp -PathType Leaf)) { $r.reason = 'RECEIPT_NOT_VERIFIED_BY_HARNESS'; return $r }
    try { $comp = (Read-SharedText $cp) | ConvertFrom-Json } catch { $r.reason = 'RECEIPT_COMPANION_INVALID'; return $r }
    if ((Get-JsonProp $comp 'schema') -ne 'MINOTAURO_PHASE_B_QS4_RECEIPT_VERIFIED_V001' -or (Get-JsonProp $comp 'receipt_sha256') -ne $r.sha256 -or
        (Get-JsonProp $comp 'attempt_id') -ne $AttemptId -or (Get-JsonProp $comp 'attempt_id') -ne (Get-JsonProp $doc 'attempt_id') -or
        ((Get-JsonProp $comp 'exit_code') -isnot [int] -and (Get-JsonProp $comp 'exit_code') -isnot [long]) -or
        (Get-JsonProp $comp 'exit_code') -ne $NativeExit -or (Get-JsonProp $comp 'exit_code') -ne (Get-JsonProp $doc 'exit_code') -or
        (Get-JsonProp $comp 'readback') -cne 'PASS') { $r.reason = 'RECEIPT_COMPANION_MISMATCH'; return $r }
    if ((Get-JsonProp $doc 'terminal') -isnot [bool]) { $r.reason = 'RECEIPT_TERMINAL_FLAG'; return $r }
    if ($NativeExit -eq 0 -and (Get-JsonProp $doc 'terminal') -ne $true) { $r.reason = 'RECEIPT_TERMINAL_FLAG'; return $r }
    if ($NativeExit -eq 0) {
        if ((Get-JsonProp $doc 'status_write_failures') -ne 0 -or (Get-JsonProp $doc 'status_final_persisted') -ne $true) { $r.reason = 'RECEIPT_STATUS_NOT_PERSISTED'; return $r }
        $sp = Join-Path (Split-Path -Parent $Path) 'HARNESS_STATUS.json'
        if (-not (Test-Path -LiteralPath $sp -PathType Leaf)) { $r.reason = 'RECEIPT_STATUS_FILE_MISSING'; return $r }
        $sb = Read-SharedBytes $sp
        if ((Get-BytesSha256 $sb) -ne (Get-JsonProp $doc 'status_final_sha256')) { $r.reason = 'RECEIPT_STATUS_FINAL_MISMATCH'; return $r }
        try { $sd = $Utf8NoBom.GetString($sb) | ConvertFrom-Json } catch { $r.reason = 'RECEIPT_STATUS_FINAL_MISMATCH'; return $r }
        if ((Get-JsonProp (Get-JsonProp $sd 'fields') 'ACTIVE') -ne 'NO' -or (Get-JsonProp (Get-JsonProp $sd 'extra') 'exit_code') -ne $NativeExit) { $r.reason = 'RECEIPT_STATUS_FINAL_MISMATCH'; return $r }
    }
    $r.valid = $true
    $r.reason = 'OK'
    $script:LastReceiptDoc = $doc
    return $r
}

function Confirm-PackageIdentity([string]$Dir, [string]$IdentityFile, [string]$IdentityKey) {
    # manifesto: cada membro com o SHA listado, nenhum extra; identidade = SHA-256 completo do manifesto
    $manifest = Join-Path $Dir 'MANIFEST_SHA256.txt'
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw ('PACKAGE_MANIFEST_MISSING ' + $Dir) }
    $listed = @{}
    foreach ($line in [System.IO.File]::ReadAllLines($manifest)) {
        if ($line.Trim().Length -eq 0) { continue }
        $parts = $line.Split(@('  '), 2, [System.StringSplitOptions]::None)
        if ($parts.Count -ne 2 -or $parts[0] -notmatch '^[0-9A-Fa-f]{64}$' -or $parts[1].Contains('..') -or
            [System.IO.Path]::IsPathRooted($parts[1]) -or $listed.ContainsKey($parts[1])) { throw ('PACKAGE_MANIFEST_ENTRY ' + $line) }
        $listed[$parts[1]] = $parts[0].ToUpperInvariant()
    }
    foreach ($rel in $listed.Keys) {
        $p = Join-Path $Dir ($rel.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
        if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { throw ('PACKAGE_MEMBER_MISSING ' + $rel) }
        if ((Get-Sha256 $p) -ne $listed[$rel]) { throw ('PACKAGE_MEMBER_HASH ' + $rel) }
    }
    $actual = @(Get-ChildItem -LiteralPath $Dir -Recurse -File -Force | ForEach-Object { $_.FullName.Substring($Dir.Length + 1).Replace([System.IO.Path]::DirectorySeparatorChar, '/') })
    foreach ($rel in $actual) {
        if (($rel -ne 'MANIFEST_SHA256.txt') -and ($rel -ne $IdentityFile) -and (-not $listed.ContainsKey($rel))) { throw ('PACKAGE_EXTRA_FILE ' + $rel) }
    }
    $manifestSha = Get-Sha256 $manifest
    $identityDoc = (Read-SharedText (Join-Path $Dir $IdentityFile)) | ConvertFrom-Json
    if ([string](Get-JsonProp $identityDoc $IdentityKey) -ne $manifestSha) { throw ('PACKAGE_IDENTITY_NE_MANIFEST ' + $Dir) }
    return $manifestSha
}

# ============================================================================ execução
Write-Host ('RESULT_CONTEXT=ChatGPT | ' + $ProjectLine)
try {
    if ($StageText -cne $AuthorizationText) { throw 'STAGE_AUTHORIZATION_TEXT_MISMATCH' }
    if ($R3PackageZipSha256.ToUpperInvariant() -ne $R3ZipPinned) { throw 'R3_PACKAGE_ZIP_SHA_NOT_PINNED_R3' }
    if ($Qs3Receipt.Contains('"') -or $Qs3Receipt.EndsWith('\') -or -not [System.IO.Path]::IsPathRooted($Qs3Receipt) -or
        -not (Test-Path -LiteralPath $Qs3Receipt -PathType Leaf)) { throw 'QS3_RECEIPT_PATH_INVALID_ABSOLUTE_FILE_REQUIRED' }
    if ((Get-Sha256 $Qs3Receipt) -ne $Qs3ReceiptSha256.ToUpperInvariant()) { throw 'QS3_RECEIPT_SHA_MISMATCH' }
    if ($ResumeQs4AttemptId -ne '') {
        if ($ResumeQs4AttemptId -cnotmatch '^\d{8}T\d{6}Z_[0-9a-f]{8}$') { throw 'RESUME_QS4_ATTEMPT_ID_INVALID' }
        if (-not (Test-Path -LiteralPath (Join-Path (Join-Path (Join-Path $EvidenceBase $ResumeQs4AttemptId) 'HARNESS') 'QS4_LEDGER.json') -PathType Leaf)) { throw 'RESUME_QS4_ATTEMPT_UNKNOWN' }
        $script:Qs4Logical = $ResumeQs4AttemptId
    }
    else { $script:Qs4Logical = $AttemptId }
    $Facts['qs4_logical_attempt'] = $script:Qs4Logical
    $Facts['qs4_resume'] = ($ResumeQs4AttemptId -ne '')
    $Facts['multiwork'] = 'NOT_APPLICABLE'
    $Facts['multiwork_reason'] = 'R3_GLOBAL_NAMED_MUTEX + REFERENCE_CAUSAL_ORDER + TEST_ISOLATION'
    $Facts['t18_p1_p3'] = 'FAIL_CLOSED_HUMAN_RECONCILIATION_REQUIRED (T18 PASS != AUTO_RESUME EM P1-P3)'
    if (-not (Test-Path -LiteralPath $EvidenceBase)) { [void](New-Item -ItemType Directory -Path $EvidenceBase) }
    if (Test-Path -LiteralPath $AttemptDir) { throw 'ATTEMPT_DIR_EXISTS' }
    [void](New-Item -ItemType Directory -Path $AttemptDir)
    Write-Line ('ATTEMPT_ID=' + $AttemptId)
    Write-Line ('STAGE=' + $Stage)
    Write-Line ('LOG=' + $LogPath)
    Write-Line ('STATUS=' + $BootstrapStatusPath)
    Write-Line ('PS_VERSION=' + $PSVersionTable.PSVersion.ToString())
    [void](Set-BootstrapStatus (New-StatusFields 'PREPARE') $null)
    if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'WINDOWS_POWERSHELL_5_1_REQUIRED' }
    if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) { throw 'PYTHON_EXE_MISSING' }
    $pySha = Get-Sha256 $PythonExe
    if ($pySha -ne $PythonSha256) { throw ('PYTHON_EXE_SHA_MISMATCH got=' + $pySha) }
    $Facts['python_exe_sha256'] = $pySha
    $Facts['qs3_receipt_path'] = $Qs3Receipt
    $Facts['qs3_receipt_sha256'] = $Qs3ReceiptSha256.ToUpperInvariant()

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    foreach ($z in @(@($R3PackageZip, $R3PackageZipSha256, 'R3'), @($HarnessZip, $HarnessZipSha256, 'HARNESS'))) {
        if (-not (Test-Path -LiteralPath $z[0] -PathType Leaf)) { throw ('PACKAGE_ZIP_MISSING ' + $z[2]) }
        $zs = Get-Sha256 $z[0]
        if ($zs -ne $z[1].ToUpperInvariant()) { throw ('PACKAGE_ZIP_SHA_MISMATCH ' + $z[2] + ' got=' + $zs) }
        $Facts[$z[2].ToLowerInvariant() + '_zip_sha256'] = $zs
    }
    # identidade de diretório = SHA-256 COMPLETO do ZIP (nunca prefixo)
    $R3Dir0 = Join-Path $PackageBase $R3ZipPinned
    $HarnessDir0 = Join-Path $PackageBase $HarnessZipSha256.ToUpperInvariant()
    foreach ($d in @($R3Dir0, $HarnessDir0)) {
        if ($d.ToUpperInvariant().StartsWith($ReleaseRoot.ToUpperInvariant())) { throw 'PACKAGE_DIR_INSIDE_RELEASE_ROOT' }
    }
    [void](Expand-AdapterPackage $R3PackageZip $R3Dir0)
    [void](Expand-AdapterPackage $HarnessZip $HarnessDir0)
    $R3Dir = Join-Path $R3Dir0 'PHASE_B_ADAPTER_V001'
    $HarnessDir = Join-Path $HarnessDir0 'PHASE_B_QS4_HARNESS_V001'
    $r3Id = Confirm-PackageIdentity $R3Dir 'ADAPTER_IDENTITY.json' 'adapter_identity_sha256'
    if ($r3Id -ne $R3IdentityPinned) { throw ('R3_IDENTITY_NOT_PINNED got=' + $r3Id) }
    $hId = Confirm-PackageIdentity $HarnessDir 'HARNESS_IDENTITY.json' 'harness_identity_sha256'
    $script:HarnessIdentity = $hId
    $Facts['r3_identity_sha256'] = $r3Id
    $Facts['harness_identity_sha256'] = $hId
    Write-Line ('R3_IDENTITY_SHA256=' + $r3Id)
    Write-Line ('HARNESS_IDENTITY_SHA256=' + $hId)
    $script:Checkpoint = 'PACKAGES'

    $t26 = Invoke-T26Probes (Join-Path $R3Dir 'qualification\probe_exit.py') $R3Dir
    $Items['T26'] = $t26
    Write-Line ('T26=' + $t26['result'])
    if ($t26['result'] -ne 'PASS') { throw 'T26_NATIVE_EXIT_OR_STDERR_CAPTURE_NOT_QUALIFIED' }
    $script:Checkpoint = 'T26'

    $script:AdapterChildStarted = $true
    $hstatus = Join-Path (Join-Path $AttemptDir 'HARNESS') 'HARNESS_STATUS.json'
    $args0 = '-B "' + (Join-Path $HarnessDir 'qs4_harness.py') + '" orchestrate --attempt-id ' + $AttemptId + ' --r3-dir "' + $R3Dir +
             '" --qs3-receipt "' + $Qs3Receipt + '" --qs3-receipt-sha256 ' + $Qs3ReceiptSha256.ToUpperInvariant()
    if ($ResumeQs4AttemptId -ne '') { $args0 = $args0 + ' --resume-from ' + $ResumeQs4AttemptId }
    Write-Line ('QS4_LOGICAL_ATTEMPT=' + $script:Qs4Logical + ' RESUME=' + $(if ($ResumeQs4AttemptId -ne '') { 'YES' } else { 'NO' }))
    $ch = Invoke-Child $PythonExe $args0 $HarnessDir 'QS4_HARNESS' $WatchdogSeconds['QS4_HARNESS'] $hstatus
    $rh = Test-HarnessReceipt (Join-Path (Join-Path $AttemptDir 'HARNESS') 'QS4_HARNESS_RECEIPT.json') $ch.ExitCode
    $oh = Resolve-ChildOutcome $ch $rh 'QS4_HARNESS'
    $oh['result'] = $(if ($oh.final_exit -eq 0) { 'PASS' } else { 'FAIL' })
    $Items['QS4_HARNESS'] = $oh
    if ($rh.valid) {
        $du = [double](Get-JsonProp $script:LastReceiptDoc 'durable_units')
        $tu = [double](Get-JsonProp $script:LastReceiptDoc 'total_units')
        if ($tu -gt 0) { $script:Qs4Pct = ([math]::Round([math]::Min(100.0 * $du / $tu, 99.9), 1)).ToString('0.0', [System.Globalization.CultureInfo]::InvariantCulture) }
        $Facts['qs4_durable_units'] = $du
        $Facts['qs4_total_units'] = $tu
        $Facts['t18_semantics'] = Get-JsonProp (Get-JsonProp $script:LastReceiptDoc 't18_semantics') 'statement'
        $hitems = Get-JsonProp $script:LastReceiptDoc 'items'
        foreach ($q in $Qs4Items) {
            $v = Get-JsonProp $hitems $q
            $Items[$q] = [ordered]@{ result = $(if ($v -eq 'PASS') { 'PASS' } else { 'FAIL' }); source = 'QS4_HARNESS_RECEIPT.items.' + $q; receipt_sha256 = $rh.sha256 }
            Write-Line ($q + '=' + $Items[$q]['result'])
        }
    }
    Write-Line ('QS4_HARNESS=' + $oh['result'])
    $script:Checkpoint = 'QS4_HARNESS'
    $FinalCode = Get-StageExit $Items $RequiredItems[$Stage]
    $script:MainCompleted = $true
}
catch {
    $script:MainCompleted = $true
    $BlockedReason = $_.Exception.Message
    Write-Line ('BOOTSTRAP_BLOCKED=' + $BlockedReason)
    Write-Line ('BOOTSTRAP_FRONTIER=' + $Frontier)
    if ($script:AdapterChildStarted -or $script:Unproven) { $FinalCode = 3 } else { $FinalCode = 2 }
}
finally {
    if (-not $script:MainCompleted) {
        $BlockedReason = 'BOOTSTRAP_INTERRUPTED'
        if ($script:AdapterChildStarted -or $script:Unproven) { $FinalCode = 3 } else { $FinalCode = 2 }
        Write-Line ('BOOTSTRAP_INTERRUPTED=YES auto_kill=NO final_exit=' + $FinalCode + ' RECONCILIATION_REQUIRED=' + $(if ($FinalCode -eq 3) { 'YES' } else { 'NO' }))
    }
    if (Test-Path -LiteralPath $AttemptDir) {
        $ff = New-StatusFields 'FINISHED'
        $ff['ACTIVE'] = 'NO'
        $ff['ETA'] = Format-Eta 0
        $ff['FINISH'] = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
        $pre = $FinalCode
        $FinalCode = Resolve-FinalExit $FinalCode $script:StatusWriteFailures $true
        # PCT=100 somente com o receipt final do harness verificado e o estágio em 0 (reconciliado)
        $pct = $(if ($FinalCode -eq 0 -and [string]$script:Qs4Pct -eq '99.9') { '100.0' } else { $script:Qs4Pct })
        $script:FinalStatusWritten = Set-BootstrapStatus $ff ([ordered]@{ final_exit = $FinalCode; stage_receipt = $StageReceiptPath; qs4_pct = $pct; qs4_logical_attempt = $script:Qs4Logical })
        $FinalCode = Resolve-FinalExit $FinalCode $script:StatusWriteFailures $script:FinalStatusWritten
        if ($FinalCode -ne $pre) { Write-Line ('STATUS_PERSISTENCE_FAILED failures=' + $script:StatusWriteFailures + ' final_status_written=' + $script:FinalStatusWritten + ' exit=' + $pre + '->' + $FinalCode + ' PASS_REFUSED') }
        try {
            $rec = [ordered]@{}
            $rec['schema'] = 'MINOTAURO_PHASE_B_ADAPTER_BOOTSTRAP_QS4_SHADOW_RECEIPT_V001'
            $rec['attempt_id'] = $AttemptId
            $rec['stage'] = $Stage
            $rec['facts'] = $Facts
            $rec['items'] = $Items
            $rec['required_items'] = $RequiredItems[$Stage]
            $rec['blocked_reason'] = $BlockedReason
            $rec['frontier'] = $Frontier
            $rec['unproven_effect'] = $script:Unproven
            $rec['interrupted'] = (-not $script:MainCompleted)
            $rec['status_write_failures'] = $script:StatusWriteFailures
            $rec['final_status_written'] = $script:FinalStatusWritten
            $rec['final_status_sha256'] = $(if ($script:FinalStatusWritten) { $script:LastStatusSha256 } else { $null })
            $rec['final_exit'] = $FinalCode
            $rec['auto_kill'] = 'NO'
            $rec['run_released'] = 'NO'
            $rec['phase_c_execution'] = 'NO'
            $stageSha = Write-StageReceipt $StageReceiptPath $rec
            Write-Line ('STAGE_RECEIPT=' + $StageReceiptPath + ' sha256=' + $stageSha)
        }
        catch {
            Write-Line ('STAGE_RECEIPT_WRITE=FAILED ' + $_.Exception.GetType().Name)
            if ([System.IO.File]::Exists($StageReceiptPath)) {
                try { [System.IO.File]::Move($StageReceiptPath, $StageReceiptPath + '.INVALIDATED.' + $Nonce) } catch { Write-Line 'STAGE_RECEIPT_RESIDUAL_NOT_INVALIDATED' }
            }
            if ($FinalCode -eq 0 -or $FinalCode -eq 130) {
                if ($script:Unproven) { $FinalCode = 3 } else { $FinalCode = 2 }
                [void](Set-BootstrapStatus $ff ([ordered]@{ final_exit = $FinalCode; stage_receipt = 'NOT_WRITTEN' }))
            }
        }
    }
    Write-Line ('FINAL_EXIT=' + $FinalCode)
    Write-Line 'BLIND_RETRY=FORBIDDEN'
    Write-Host ('RESULT_RETURN_TO=ChatGPT | ' + $ProjectLine)
    if (-not $script:MainCompleted) { [Environment]::Exit($FinalCode) }
}
exit $FinalCode
'''
text = head + reused + own
out = Path(sys.argv[2])
out.write_bytes(b"\xef\xbb\xbf" + text.replace("\n", "\r\n").encode("utf-8"))
print("written", len(text))
