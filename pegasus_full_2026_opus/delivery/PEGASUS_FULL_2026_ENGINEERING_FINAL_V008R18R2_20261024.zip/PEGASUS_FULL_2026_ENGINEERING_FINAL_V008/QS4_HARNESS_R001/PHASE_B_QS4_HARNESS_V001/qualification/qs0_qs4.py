"""PHASE_B_QS4_HARNESS_V001 — QS0-H (estático + import-safety). Não importa o CODE congelado; não toca D:\\.
Uso: python -B qualification/qs0_qs4.py <receipt_out.json> --r3 <R3 extraído> [--pwsh <pwsh>]
Também importável: check_all(root, r3_dir, pwsh=None) -> lista de checks (usado pelos mutantes do QS1-H).
"""
from __future__ import annotations

import ast
import fnmatch
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULES = ["qs4_harness.py", "qs4_lib.py", "qs4_flow.py", "qs4_seams.py"]
REUSE = ["Write-Line", "Get-Sha256", "Read-SharedText", "Get-BytesSha256", "Read-SharedBytes", "Write-AtomicText",
         "Get-JsonProp", "Format-Eta", "New-StatusFields", "Set-BootstrapStatus", "Read-AdapterStatus", "Write-Heartbeat",
         "Invoke-Child", "Resolve-ChildOutcome", "Get-TextSha256", "Invoke-T26Probes", "Expand-AdapterPackage",
         "Write-StageReceipt", "Resolve-FinalExit", "Get-StageExit"]
CODE_MODULES = {"r1r11_full_2026", "minotauro_v004_runner", "r1r11_coordinator", "r1r11_resources", "r1r11_v4_transaction",
                "r1r11_fast_resume", "minotauro_v005r1_r23_contract", "minotauro_v004_io", "minotauro_v004_core"}
R3_MODULES = {"phase_b_shared", "phase_b_effects", "phase_b_contract", "phase_b_state", "phase_b_entry",
              "phase_b_qualification_seams"}


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()


def check(res, cid, ok, detail=""):
    res.append({"check": cid, "result": "PASS" if ok else "FAIL", "detail": str(detail)[:600]})


def attr_chain(node):
    parts = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
        return ".".join(reversed(parts))
    return None


def ps_text(p: Path) -> str:
    raw = p.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        raw = raw[3:]
    return raw.decode("utf-8").replace("\r\n", "\n")


def ps_function(text: str, name: str):
    m = re.search(r"^function " + re.escape(name) + r"\b.*?(?=^function |^# =+ )", text, re.S | re.M)
    return m.group(0).rstrip("\n") if m else None


def ps_code(text: str) -> str:
    """Texto sem comentários de bloco e sem linhas só de comentário (conservador: comentário ao fim da linha permanece)."""
    t = re.sub(r"<#.*?#>", "", text, flags=re.S)
    return "\n".join(ln for ln in t.split("\n") if not ln.lstrip().startswith("#"))


def enclosing_functions(tree):
    """{id(node): nome da função mais interna que o contém}"""
    out = {}

    def walk(n, fn):
        for c in ast.iter_child_nodes(n):
            f = c.name if isinstance(c, (ast.FunctionDef, ast.AsyncFunctionDef)) else fn
            out[id(c)] = f
            walk(c, f)
    walk(tree, None)
    return out


def check_all(root: Path, r3: Path, pwsh=None) -> list:
    root, r3 = Path(root), Path(r3)
    res: list = []
    c = json.loads((root / "qs4_constants.json").read_text(encoding="utf-8"))
    env_p = root / "qualification" / c["harness_envelope"]["file"]
    env = json.loads(env_p.read_text(encoding="utf-8"))
    # S01 pacote: manifesto exato, identidade, envelope fixado, arquivos permitidos, sem __pycache__
    listed = {}
    for line in (root / "MANIFEST_SHA256.txt").read_text(encoding="ascii").splitlines():
        if line.strip():
            h, n = line.split("  ", 1)
            listed[n] = h
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()} - {"MANIFEST_SHA256.txt", "HARNESS_IDENTITY.json"}
    bad = [n for n in listed if not (root / n).is_file() or sha(root / n) != listed[n]]
    check(res, "S01_MANIFEST_EXACT", actual == set(listed) and not bad, f"delta={sorted(actual ^ set(listed))[:5]} bad={bad[:5]}")
    ident = json.loads((root / "HARNESS_IDENTITY.json").read_text(encoding="utf-8"))
    msha = sha(root / "MANIFEST_SHA256.txt")
    check(res, "S01_IDENTITY_EQ_MANIFEST", ident.get("harness_identity_sha256") == msha == ident.get("manifest_sha256"))
    check(res, "S01_ENVELOPE_PIN", sha(env_p) == c["harness_envelope"]["sha256"] == ident.get("harness_envelope_sha256"))
    allowed = env["harness_package"]["allowed_files"]
    outside = [n for n in actual if not any(fnmatch.fnmatch(n, pat) or (pat.endswith("/**") and n.startswith(pat[:-2])) for pat in allowed)]
    check(res, "S01_ALLOWED_FILES_ONLY", not outside, outside[:5])
    check(res, "S01_NO_PYCACHE", not any(d.name == "__pycache__" or d.suffix == ".pyc" for d in root.rglob("*")))
    # S02 pinos R3 (constantes, envelope, bootstrap) = identidade R3 do pacote extraído
    r3_ident = json.loads((r3 / "ADAPTER_IDENTITY.json").read_text(encoding="utf-8"))
    a = c["adapter"]
    check(res, "S02_R3_IDENTITY_PINS", a["identity_sha256"] == r3_ident["adapter_identity_sha256"] == sha(r3 / "MANIFEST_SHA256.txt")
          == env["adapter_under_test"]["identity_sha256"] == ident.get("adapter_identity_sha256"))
    check(res, "S02_R3_CONSTANTS_PIN", a["constants_sha256"] == sha(r3 / "phase_b_constants.json") == env["adapter_under_test"]["constants_sha256"])
    check(res, "S02_R3_ZIP_PIN", a["package_zip_sha256"] == env["adapter_under_test"]["package_zip_sha256"])
    pq = c["prior_qs3"]
    h01 = env.get("h01_prior_qs3_compatibility", {})
    src_lib = (root / "qs4_lib.py").read_text(encoding="utf-8")
    prior_pins_ok = (pq.get("adapter_identity_sha256") == h01.get("prior_adapter_identity_sha256")
                     and pq.get("package_zip_sha256") == h01.get("prior_adapter_package_zip_sha256")
                     and pq.get("adapter_identity_sha256") != a["identity_sha256"]
                     and pq.get("package_zip_sha256") != a["package_zip_sha256"]
                     and 'pq["adapter_identity_sha256"]' in src_lib
                     and 'pq["package_zip_sha256"]' in src_lib)
    check(res, "S02_PRIOR_QS3_EXPLICIT_PINS", prior_pins_ok)
    boot = ps_text(root / "BOOTSTRAP_QS4_HARNESS.ps1")
    check(res, "S02_BOOTSTRAP_PINS", f"$R3ZipPinned     = '{a['package_zip_sha256']}'" in boot
          and f"$R3IdentityPinned = '{a['identity_sha256']}'" in boot
          and f"$StageText       = '{c['authorization_text']}'" in boot)
    # S03 funções de infraestrutura VERBATIM do bootstrap R3
    r3b = ps_text(r3 / "BOOTSTRAP_PHASE_B_ADAPTER.ps1")
    diff = [n for n in REUSE if ps_function(boot, n) is None or ps_function(boot, n) != ps_function(r3b, n)]
    check(res, "S03_PS_FUNCTIONS_VERBATIM_R3", not diff, diff)
    check(res, "S03_BOOTSTRAP_BOM_CRLF", (root / "BOOTSTRAP_QS4_HARNESS.ps1").read_bytes().startswith(b"\xef\xbb\xbf")
          and b"\n" not in (root / "BOOTSTRAP_QS4_HARNESS.ps1").read_bytes().replace(b"\r\n", b""))
    # S04 PowerShell proibido
    code = ps_code(boot)
    forb = [w for w in ("Start-Process", "Stop-Process", ".Kill(", "Remove-Item", "taskkill", "Invoke-Expression",
                        "Set-MpPreference", "Add-MpPreference", "-ExclusionPath") if w in code]
    check(res, "S04_PS_FORBIDDEN_CONSTRUCTS", not forb, forb)
    check(res, "S04_PS_NO_LASTEXITCODE_SENTINEL", "$LASTEXITCODE" not in code)
    check(res, "S04_PS_STAGE_CLOSED", "[ValidateSet('QS4_SHADOW')]" in boot and "'RUN_B'" not in boot and "run-b" not in boot)
    # S05 Python: remoções, kills, shell, finalize, fase C, caminhos literais
    trees = {m: ast.parse((root / m).read_text(encoding="utf-8")) for m in MODULES}
    hits_rm, hits_kill, hits_shell, hits_fin, hits_phase, hits_lit, hits_popen_kill = [], [], [], [], [], [], []
    for m, t in trees.items():
        enc = enclosing_functions(t)
        for n in ast.walk(t):
            if isinstance(n, ast.Call):
                ch = attr_chain(n.func) or ""
                last = ch.split(".")[-1]
                if ch in ("os.remove", "os.unlink", "os.rmdir", "os.removedirs", "shutil.rmtree", "shutil.move") or last in ("unlink", "rmdir", "rmtree"):
                    hits_rm.append(f"{m}:{n.lineno}:{ch}")
                if ch in ("os.kill", "os.killpg") or last in ("TerminateProcess", "GenerateConsoleCtrlEvent"):
                    hits_kill.append((m, enc.get(id(n)), ch.split(".")[-1]))
                if last in ("kill", "terminate", "send_signal") and ch not in ("os.kill",):
                    hits_popen_kill.append(f"{m}:{n.lineno}:{ch}")
                if any(k.arg == "shell" and getattr(k.value, "value", False) is True for k in n.keywords):
                    hits_shell.append(f"{m}:{n.lineno}")
                if last == "finalize_phase" or "finalize_phase" in ch:
                    hits_fin.append(f"{m}:{n.lineno}")
                if ch.endswith("phase_b_only") is False and last == "run_phase":
                    hits_phase.append(f"{m}:{n.lineno}:unguarded_run_phase")
            if isinstance(n, ast.Attribute) and n.attr == "finalize_phase":
                hits_fin.append(f"{m}:{n.lineno}")
            if isinstance(n, ast.Constant) and isinstance(n.value, str) and re.match(r"^[A-Za-z]:\\", n.value):
                hits_lit.append(f"{m}:{n.lineno}")
        # todo uso de fz.full.<fn> passa por ps.phase_b_only(...)(root, "B", ...)
        for n in ast.walk(t):
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Call) and (attr_chain(n.func.func) or "").endswith("phase_b_only"):
                if not (len(n.args) >= 2 and isinstance(n.args[1], ast.Constant) and n.args[1].value == "B"):
                    hits_phase.append(f"{m}:{n.lineno}:phase_not_literal_B")
    full_uses = []
    for m, t in trees.items():
        parents = {}
        for p in ast.walk(t):
            for ch_ in ast.iter_child_nodes(p):
                parents[id(ch_)] = p
        for n in ast.walk(t):
            if isinstance(n, ast.Attribute) and (attr_chain(n) or "").startswith("fz.full."):
                par = parents.get(id(n))
                ok = isinstance(par, ast.Call) and (attr_chain(par.func) or "").endswith("phase_b_only") and par.args and par.args[0] is n
                if not ok:
                    full_uses.append(f"{m}:{n.lineno}:{attr_chain(n)}")
    check(res, "S05_NO_FILE_REMOVAL", not hits_rm, hits_rm)
    allowed_kill = {("qs4_lib.py", "terminate_p10", "kill"), ("qs4_lib.py", "terminate_p10", "TerminateProcess"),
                    ("qs4_lib.py", "ctrl_c_attached", "GenerateConsoleCtrlEvent"), ("qs4_harness.py", "send_ctrl_c", "killpg")}
    check(res, "S05_KILL_ONLY_P10_AND_P5", set(hits_kill) <= allowed_kill and not hits_popen_kill, (hits_kill, hits_popen_kill))
    check(res, "S05_NO_SHELL_TRUE", not hits_shell, hits_shell)
    check(res, "S05_NEVER_FINALIZE", not hits_fin, hits_fin)
    check(res, "S05_PHASE_B_ONLY", not hits_phase and not full_uses, (hits_phase, full_uses))
    check(res, "S05_NO_LITERAL_DRIVE_PATHS", not hits_lit, hits_lit)
    # S06 terminate_p10 é chamado só no ramo TERMINATE do run_step; killpg/ctrl-c só em send_ctrl_c (ramo CTRL_C)
    callers = []
    t = trees["qs4_harness.py"]
    enc = enclosing_functions(t)
    for n in ast.walk(t):
        if isinstance(n, ast.Call) and (attr_chain(n.func) or "").split(".")[-1] in ("terminate_p10", "send_ctrl_c"):
            callers.append((enc.get(id(n)), (attr_chain(n.func) or "").split(".")[-1]))
    check(res, "S06_KILL_CALL_SITES", sorted(callers) == [("p5_microprobe", "send_ctrl_c"), ("run_step", "send_ctrl_c"),
                                                          ("run_step", "terminate_p10")], callers)
    src_h = (root / "qs4_harness.py").read_text(encoding="utf-8")
    check(res, "S06_TERMINATE_GUARDED_BY_MARKER", 'if action == "TERMINATE" and not acted and (sdir / "QS4_MARKER_BLOCK.txt").is_file():' in src_h
          and 'if action == "CTRL_C" and not acted and (sdir / "QS4_MARKER_NOTIFY.txt").is_file():' in src_h)
    # S07 ordem dos seams: qs4_seams só é importado DENTRO do corpo do `with ps.SeamSet(...)` em qs4_flow
    flow = trees["qs4_flow.py"]
    imports_top = [n for n in flow.body if isinstance(n, (ast.Import, ast.ImportFrom)) and any(
        (getattr(a_, "name", "") or "").startswith("qs4_seams") for a_ in n.names) or (isinstance(n, ast.ImportFrom) and n.module == "qs4_seams")]
    inside = False
    for n in ast.walk(flow):
        if isinstance(n, ast.With) and any((attr_chain(i.context_expr.func) or "").endswith("SeamSet") for i in n.items
                                           if isinstance(i.context_expr, ast.Call)):
            if n.body and isinstance(n.body[0], ast.Import) and n.body[0].names[0].name == "qs4_seams":
                inside = isinstance(n.body[1], ast.With) and "SeamStack" in (attr_chain(n.body[1].items[0].context_expr.func) or "")
    other_imports = [m for m in MODULES if m != "qs4_flow.py" and re.search(r"^\s*(import|from)\s+qs4_seams\b", (root / m).read_text(encoding="utf-8"), re.M)]
    check(res, "S07_SEAMS_AFTER_SEAMSET_ENTER", inside and not imports_top and not other_imports, (inside, other_imports))
    seams_src = (root / "qs4_seams.py").read_text(encoding="utf-8")
    check(res, "S07_R3_SEAM_MODULE_PINNED_LOAD", "QS4_R3_SEAM_MODULE_PIN" in seams_src and "importlib" not in seams_src)
    # S08 import-safety: importar os módulos não carrega R3/CODE/seams nem cria arquivos
    with tempfile.TemporaryDirectory() as td:
        code = ("import sys,json; sys.path.insert(0, sys.argv[1]); import qs4_lib, qs4_seams, qs4_flow, qs4_harness;"
                " print(json.dumps(sorted(m for m in sys.modules if m.split('.')[0] in %r)))" % (sorted(CODE_MODULES | R3_MODULES),))
        r = subprocess.run([sys.executable, "-B", "-c", code, str(root)], capture_output=True, text=True, cwd=td,
                           env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        loaded = json.loads(r.stdout or "null")
        check(res, "S08_IMPORT_SAFETY", r.returncode == 0 and loaded == [] and not os.listdir(td), (r.returncode, loaded, r.stderr[-300:]))
    # S09 plano: listas fechadas de R3, endpoints, P7 completo
    seams_r3 = (r3 / "qualification" / "phase_b_qualification_seams.py").read_text(encoding="utf-8")
    ns: dict = {}
    exec(compile(ast.parse(seams_r3), "r3seams", "exec"), ns)  # somente definições (lista fechada); nenhum efeito
    targets = {s["stop"]["interrupt_target"] for x in c["cases"] for s in x["steps"] if "interrupt_target" in s["stop"]}
    faults = {s["stop"]["fault"] for x in c["cases"] for s in x["steps"] if "fault" in s["stop"]}
    check(res, "S09_CLOSED_LISTS", targets <= set(ns["INTERRUPT_TARGETS"]) and faults == set(ns["FAULT_POINTS"]))
    codes_ok = all(s["expect"].get("code") == "/".join(ns["INTERRUPT_TARGETS"][s["stop"]["interrupt_target"]])
                   for x in c["cases"] for s in x["steps"] if "interrupt_target" in s["stop"])
    check(res, "S09_INTERRUPT_EXPECTED_CODES", codes_ok)
    check(res, "S09_PLAN_SHAPE", len(c["cases"]) == 24 and sum(len(x["steps"]) for x in c["cases"]) == 45
          and len({x["id"] for x in c["cases"]}) == 24)
    st_src = (r3 / "phase_b_state.py").read_text(encoding="utf-8")
    m = re.search(r"EMPTY, PREPARED, IN_PROGRESS, FINAL_VALID, BLOCKED = \(\s*([^)]*)\)", st_src)
    r3_states = set(re.findall(r'"([A-Z_]+)"', m.group(1))) if m else set()
    used_states = {s["expect"]["state_after"] for x in c["cases"] for s in x["steps"] if "state_after" in s["expect"]}
    check(res, "S09_STATE_LITERALS_FROM_R3", bool(r3_states) and used_states <= r3_states, sorted(used_states - r3_states))
    check(res, "S09_RESUME_HAS_NO_TEMPLATE", all("template" not in s for x in c["cases"] for s in x["steps"] if s["kind"] == "RESUME"))
    # S10 bootstrap pwsh parse (quando disponível)
    if pwsh and Path(pwsh).is_file():
        bp = str(root / "BOOTSTRAP_QS4_HARNESS.ps1").replace("'", "''")
        cmd = ("$e=$null;$t=$null;[void][System.Management.Automation.Language.Parser]::ParseFile('" + bp + "',[ref]$t,[ref]$e);"
               "'PARSE_ERRORS=' + $e.Count")
        r = subprocess.run([pwsh, "-NoProfile", "-NonInteractive", "-Command", cmd], capture_output=True, text=True)
        check(res, "S10_BOOTSTRAP_PARSE_PWSH", "PARSE_ERRORS=0" in r.stdout, r.stdout[-200:] + r.stderr[-200:])
    else:
        check(res, "S10_BOOTSTRAP_PARSE_PWSH", False, "PWSH_NOT_PROVIDED")
    # S11 ninguém do R3 importa o harness (R3 inalterado; nenhum gancho de produção)
    r3_src = "\n".join(p.read_text(encoding="utf-8") for p in r3.glob("*.py"))
    check(res, "S11_R3_DOES_NOT_REFERENCE_HARNESS", "qs4_" not in r3_src)

    def fn_src(tree, src, name):
        for n in ast.walk(tree):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name:
                return ast.get_source_segment(src, n) or ""
        return ""
    lib_src = (root / "qs4_lib.py").read_text(encoding="utf-8")
    # S12 Q4-01: console próprio real SOMENTE no alvo do CTRL_C (filho P5 e alvo do microprobe); helper na ordem exigida
    pk = fn_src(trees["qs4_lib.py"], lib_src, "popen_kwargs")
    cc = fn_src(trees["qs4_lib.py"], lib_src, "ctrl_c_attached")
    order = [cc.find(x) for x in ("k.FreeConsole()", "k.AttachConsole(", "k.SetConsoleCtrlHandler(None, True)", "k.GenerateConsoleCtrlEvent(0, 0)")]
    console_calls = []
    for n in ast.walk(trees["qs4_harness.py"]):
        if isinstance(n, ast.Call) and (attr_chain(n.func) or "").endswith("popen_kwargs"):
            kw = {k.arg: ast.unparse(k.value) for k in n.keywords}
            console_calls.append((enclosing_functions(trees["qs4_harness.py"]).get(id(n)), kw.get("console")))
    no_group = not any((isinstance(n, ast.Name) and n.id == "CREATE_NEW_PROCESS_GROUP")
                       or (isinstance(n, ast.Attribute) and n.attr == "CREATE_NEW_PROCESS_GROUP")
                       or (isinstance(n, ast.Constant) and type(n.value) is int and n.value == 0x200)
                       for t in trees.values() for n in ast.walk(t))
    check(res, "S12_P5_OWN_REAL_CONSOLE",
          "CREATE_NEW_CONSOLE" in pk and "if console:" in pk and "CREATE_NO_WINDOW" in pk and no_group
          and all(i >= 0 for i in order) and order == sorted(order)
          and sorted(console_calls, key=str) == sorted([("p5_microprobe", "True"), ("run_step", "action == 'CTRL_C'"),
                                                        ("run_simple", None)], key=str), console_calls)
    flow_src = (root / "qs4_flow.py").read_text(encoding="utf-8")
    check(res, "S12_P5_TARGET_REENABLES_CTRL_C", 'if st.get("orchestrator_action") == "CTRL_C":' in flow_src
          and "enable_ctrl_c()" in flow_src and "SetConsoleCtrlHandler(None, False)" in fn_src(trees["qs4_lib.py"], lib_src, "enable_ctrl_c"))
    # S13 microprobe P5 nas pré-condições (antes da fronteira do shadow); falha => BLOCKED
    pre = fn_src(trees["qs4_harness.py"], src_h, "preconditions")
    run_src = fn_src(trees["qs4_harness.py"], src_h, "run")
    mp = fn_src(trees["qs4_harness.py"], src_h, "p5_microprobe")
    check(res, "S13_P5_MICROPROBE_BEFORE_MATRIX", "self.p5_microprobe()" in pre and pre.find("self.p5_microprobe()") < pre.find("K.tick_rehash(")
          and run_src.find("self.preconditions()") < run_src.find("self.shadow.mkdir(") and 'raise L.HarnessBlocked("H07_P5_MICROPROBE_FAILED"' in mp
          and "popen_kwargs(console=True)" in mp)
    # S14 Q4-02: intenção durável no ledger ANTES de cada efeito; registro durável DEPOIS
    rs = fn_src(trees["qs4_harness.py"], src_h, "run_step")
    rc_ = fn_src(trees["qs4_harness.py"], src_h, "run_case")
    ev_ = fn_src(trees["qs4_harness.py"], src_h, "ensure_variant")
    cs = fn_src(trees["qs4_harness.py"], src_h, "commit_step")
    lw = fn_src(trees["qs4_lib.py"], lib_src, "ledger_write")
    ok14 = (0 <= rs.find('self.save("STEP_INTENT")') < rs.find("subprocess.Popen(") < rs.find('self.save("STEP_CHILD")')
            and 0 <= rc_.find('self.save("CASE_SEEDING")') < rc_.find("L.seed_case_root(")
            and 0 <= rc_.find('self.save("RELOCATE_INTENT")') < rc_.find("shutil.copytree(")
            and 0 <= ev_.find('self.save("VARIANT_BUILDING")') < ev_.find("shutil.copytree(")
            and 'self.save("STEP_DONE")' in cs and "os.fsync" in lw and "write_atomic(path, sealed)" in lw
            and "ledger_verify" in fn_src(trees["qs4_harness.py"], src_h, "reconcile_resume"))
    check(res, "S14_LEDGER_INTENT_BEFORE_EFFECT", ok14)
    rr = fn_src(trees["qs4_harness.py"], src_h, "reconcile_resume")
    rr14 = rr + (fn_src(trees["qs4_harness.py"], src_h, "revalidate_durable_steps").replace('f"{where}_', '"RESUME_')
                 if 'self.revalidate_durable_steps(led, "RESUME")' in rr else "")
    check(res, "S14_RESUME_GUARDS", all(x in rr14 for x in ("RESUME_BINDING_MISMATCH", "RESUME_ATTEMPT_ALREADY_FINAL",
                                                            "RESUME_PREVIOUS_ORCHESTRATOR_ALIVE",
                                                            "RESUME_PARTIAL_CHILD_ALIVE_RECONCILIATION_REQUIRED",
                                                            "RESUME_DURABLE_RECEIPT_CHANGED", "RESUME_DURABLE_BYTES_CHANGED",
                                                            "RESUME_REFERENCE_CHANGED", "RESUME_ROOT_DRIFT"))
          and "AttemptLock(" in pre)
    # S15 Q4-04: MULTIWORK=NOT_APPLICABLE provado
    mw = c.get("multiwork") or {}
    reason = "R3_GLOBAL_NAMED_MUTEX + REFERENCE_CAUSAL_ORDER + TEST_ISOLATION"
    check(res, "S15_MULTIWORK_DECLARED", mw.get("value") == "NOT_APPLICABLE" and mw.get("reason") == reason
          and (env.get("multiwork") or {}).get("value") == "NOT_APPLICABLE" and (env.get("multiwork") or {}).get("reason") == reason)
    sh_src = (r3 / "phase_b_shared.py").read_text(encoding="utf-8")
    replace_kw = set()
    for n in ast.walk(trees["qs4_flow.py"]):
        if isinstance(n, ast.Call) and attr_chain(n.func) == "replace":
            replace_kw |= {k.arg for k in n.keywords}
    check(res, "S15_PROOF_R3_GLOBAL_NAMED_MUTEX",
          'acquire_named_mutex(adapter_mutex_name(lay.release_root))' in sh_src
          and 'return "Global\\\\MinotauroPhaseBAdapter_"' in sh_src
          and bool(replace_kw) and "release_root" not in replace_kw, sorted(replace_kw))
    ids = [x["id"] for x in c["cases"]]
    causal = all(ids.index(x["reference"]) < ids.index(x["id"]) for x in c["cases"] if x.get("reference"))
    check(res, "S15_PROOF_REFERENCE_CAUSAL_ORDER", causal)
    conc = [m for m in MODULES if re.search(r"^\s*(import|from)\s+(multiprocessing|concurrent|asyncio)\b", (root / m).read_text(encoding="utf-8"), re.M)]
    threads = [ast.unparse(n) for n in ast.walk(trees["qs4_harness.py"]) if isinstance(n, ast.Call) and attr_chain(n.func) == "threading.Thread"]
    popen_fns = sorted({enclosing_functions(trees["qs4_harness.py"]).get(id(n)) for n in ast.walk(trees["qs4_harness.py"])
                        if isinstance(n, ast.Call) and attr_chain(n.func) == "subprocess.Popen"})
    sync = all("while p.poll() is None" in fn_src(trees["qs4_harness.py"], src_h, f) for f in popen_fns)
    check(res, "S15_PROOF_TEST_ISOLATION", not conc and len(threads) == 1 and "target=loop" in threads[0]
          and popen_fns == ["p5_microprobe", "run_simple", "run_step"] and sync
          and 'f"R{gen}"' in fn_src(trees["qs4_harness.py"], src_h, "case_root"), (conc, threads, popen_fns))
    # S16 R1-03: companion contraditório nunca valida (contrato completo do companion)
    vc = fn_src(trees["qs4_lib.py"], lib_src, "verify_receipt_with_companion")
    check(res, "S16_COMPANION_CONTRACT", all(x in vc for x in (
        'comp.get("schema") != VERIFIED_SCHEMA', "set(comp) != COMPANION_KEYS", 'comp.get("receipt_sha256") != sha',
        'comp.get("attempt_id") != d.get("attempt_id")', "cx != rx", "cx != exit_code", 'comp.get("readback") != "PASS"',
        "type(rx) is not int", "type(cx) is not int")))
    # S17 R1-02: adoção persiste o exit NATIVO observado pelo pai e a origem; revalidação exige a prova
    rv = fn_src(trees["qs4_harness.py"], src_h, "revalidate_durable_steps")
    check(res, "S17_ADOPT_NATIVE_EXIT_PERSISTED",
          '"native_exit": part["exited"]["native_exit"]' in rr and '"native_exit": None' not in rr
          and all(x in rr for x in ('"source_partial_seq": src_seq', '"source_partial_ledger_sha256": src_sha', '"source_child"'))
          and 'self.revalidate_durable_steps(led, "RESUME")' in rr and 'self.revalidate_durable_steps(self.led, "FINAL")' in run_src
          and 's_.get("native_exit") != 0' in rv and "exit_code=0)" in rv and 'a.get("source_native_exit") != 0' in rv)
    # S18 R1-01: histórico da sessão anterior persistido ANTES de limpar o final; PASS binda o histórico
    fin = fn_src(trees["qs4_harness.py"], src_h, "finish")
    shc = fn_src(trees["qs4_harness.py"], src_h, "session_history_check")
    check(res, "S18_SESSION_STATE_TRANSFER",
          0 <= rr.find("self.session_history_check(") < rr.find('self.save("SESSION_HISTORY")') < rr.find('self.led["final"] = None')
          and 0 <= rr.find("L.ledger_repair_journal(") < rr.find('self.save("SESSION_HISTORY")')
          and "self.session_history_verify(self.led)" in run_src
          and 'self.rec["session_history"] = hist' in fin and 'self.rec["terminal"] = terminal' in fin
          and all(x in shc for x in ("RESUME_PREVIOUS_RECEIPT_INVALID", "RESUME_PREVIOUS_RECEIPT_MISSING",
                                     "RESUME_PREVIOUS_STATUS_MISMATCH", "RESUME_TERMINAL_RECEIPT_EXISTS",
                                     "SESSION_HISTORY_INCOMPLETE")))
    return res


def main(argv):
    out = Path(argv[0])
    r3 = Path(argv[argv.index("--r3") + 1])
    pwsh = argv[argv.index("--pwsh") + 1] if "--pwsh" in argv else None
    res = check_all(ROOT, r3, pwsh)
    ok = all(x["result"] == "PASS" for x in res)
    ident = json.loads((ROOT / "HARNESS_IDENTITY.json").read_text(encoding="utf-8"))
    rec = {"schema": "MINOTAURO_PHASE_B_QS4_HARNESS_QS0_RECEIPT_V001", "harness_identity_sha256": ident["harness_identity_sha256"],
           "r3_identity_sha256": json.loads((r3 / "ADAPTER_IDENTITY.json").read_text(encoding="utf-8"))["adapter_identity_sha256"],
           "checks": res, "checks_total": len(res), "checks_pass": sum(1 for x in res if x["result"] == "PASS"),
           "result": "PASS" if ok else "FAIL", "qs4_executed": "NO"}
    out.write_text(json.dumps(rec, indent=1, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    for x in res:
        print(f"{x['check']}={x['result']}" + ("" if x["result"] == "PASS" else " " + x["detail"]))
    print("QS0_H_RESULT=" + rec["result"])
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
