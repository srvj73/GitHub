"""QS4 convergence controller V002 — guarded planning and caller-owned binding/collection. No import-time effects."""
from __future__ import annotations
from typing import Any, Mapping, Iterable
import qs4_attempt_lifecycle_v002 as L

class ConvergenceControllerV002:
    def plan_new_attempt(self, *, retirement_receipt: Mapping[str, Any], expected_attempt_id: str,
                         historical_residue_paths: Iterable[str], actual_control_files: Mapping[str,str],
                         actual_control_dirs: Iterable[str], pre_control_files: Mapping[str,str],
                         post_control_files: Mapping[str,str], expected_control_dirs: Iterable[str],
                         current_owned_lineage_states: Iterable[str], retirement_evidence_root=None,
                         expected_retirement_receipt_sha256=None, process_api=None) -> dict[str,Any]:
        L.lineage_admission(current_owned_lineage_states)
        import qs4_failure_collection_v002 as F
        if process_api is None:
            import qs4_lib as process_api
        retirement=L.admit_new_attempt(retirement_receipt=retirement_receipt,
                                       historical_residue_paths=historical_residue_paths,
                                       expected_attempt_id=expected_attempt_id,
                                       evidence_root=retirement_evidence_root,
                                       expected_receipt_sha256=expected_retirement_receipt_sha256)
        census = F.bounded_census(retirement_receipt.get("owned_process_identities", []), process_api)
        if not census["complete"] or census["state"] != "PASS_CLEAN":
            raise L.LifecycleBlocked("CURRENT_OWNED_CENSUS_NOT_CLEAN")
        state=L.classify_control_binding(actual_files=actual_control_files, actual_dirs=actual_control_dirs,
                                         pre_files=pre_control_files, post_files=post_control_files,
                                         expected_dirs=expected_control_dirs)
        plan=L.control_binding_plan(state)
        return {"current_census":census, "retirement_admission":retirement,"control_binding":plan,
                "historical_residue_action":"PRESERVE_NOT_LIVENESS_AUTHORITY",
                "new_attempt":"AUTHORIZED_BY_CALLER_SCOPE_ONLY"}

    def failure_close(self, **kwargs):
        import qs4_failure_collection_v002 as F
        return F.collect_failure_bundle(**kwargs)

    def prepare_qs5(self, **kwargs):
        return L.qs5_prepared(**kwargs)

    def full_admission(self, **kwargs):
        return L.full_admission(**kwargs)


def bind_control_exact(*, control_root, pre_files, post_files, expected_dirs, replacements, evidence_dir):
    """Caller-owned binding transaction. POST performs no writes, including receipts.

    The two durable replaces are individually atomic. A partial commit is MIXED and
    blocks the next invocation; the evidence records commits and never silently rolls back.
    This function is never invoked by the target qualifier.
    """
    import os
    from pathlib import Path
    import qs4_failure_collection_v002 as F
    root = Path(control_root)
    def measure():
        files, dirs = {}, []
        for p in root.rglob('*'):
            if p.is_symlink() or (hasattr(p,'is_junction') and p.is_junction()):
                raise L.LifecycleBlocked('CONTROL_REPARSE_OR_SYMLINK')
            rel = p.relative_to(root).as_posix()
            if p.is_dir(): dirs.append(rel)
            else: files[rel] = L.sha256_bytes(p.read_bytes())
        return files, dirs
    if not root.is_dir() or root.is_symlink() or (hasattr(root,'is_junction') and root.is_junction()):
        raise L.LifecycleBlocked('CONTROL_ROOT_INVALID')
    actual, dirs = measure()
    state = L.classify_control_binding(actual_files=actual, actual_dirs=dirs, pre_files=pre_files,
                                       post_files=post_files, expected_dirs=expected_dirs)
    plan = L.control_binding_plan(state)
    if state == L.POST_BIND_EXACT:
        return dict(plan,committed=[])
    changed = sorted(k for k in pre_files if pre_files[k].upper() != post_files[k].upper())
    if set(replacements) != set(changed) or any(L.sha256_bytes(replacements[k]) != post_files[k].upper() for k in changed):
        raise L.LifecycleBlocked('CONTROL_REPLACEMENTS_NOT_EXACT')
    out = Path(evidence_dir)
    if out.resolve().is_relative_to(root.resolve()) or root.resolve().is_relative_to(out.resolve()):
        raise L.LifecycleBlocked('CONTROL_EVIDENCE_ROOT_OVERLAP')
    out.mkdir(parents=True,exist_ok=False)
    committed=[]
    try:
        for k in changed:
            path = root/L.safe_relative_path(k)
            F.durable_write(out/('BACKUP_'+str(len(committed))+'.bin'),path.read_bytes())
            now,_ = measure()
            expected = dict(pre_files)
            for done in committed: expected[done]=post_files[done]
            if now != {k:v.upper() for k,v in expected.items()}:
                raise L.LifecycleBlocked('CONTROL_CHANGED_DURING_BIND')
            tmp = path.with_name(path.name+'.V002_BIND.tmp')
            F.durable_write(tmp,replacements[k])
            os.replace(tmp,path)
            committed.append(k)
            F.durable_write(out/('COMMIT_'+str(len(committed))+'.json'),L.canonical_json_bytes({'path':k,'sha256':L.sha256_bytes(path.read_bytes())}))
            if L.sha256_bytes(path.read_bytes()) != post_files[k].upper():
                raise L.LifecycleBlocked('CONTROL_COMMIT_READBACK')
        final,fd = measure()
        if L.classify_control_binding(actual_files=final,actual_dirs=fd,pre_files=pre_files,post_files=post_files,expected_dirs=expected_dirs)!=L.POST_BIND_EXACT:
            raise L.LifecycleBlocked('CONTROL_POST_READBACK')
        F.durable_write(out/'BIND_RECEIPT.json',L.canonical_json_bytes({'state':'POST_BIND_EXACT','committed':committed,'writes':2}))
        return dict(plan,committed=committed)
    except Exception as exc:
        try:
            F.durable_write(out/'BIND_FAILURE.json',L.canonical_json_bytes({'primary_error':str(exc),'committed':committed,'next_admission':'BLOCKED_UNLESS_POST_BIND_EXACT'}))
        except Exception:
            pass  # Preserve the primary exception even when the evidence volume is unavailable.
        try:
            # Binding spawns no processes; its owned identity set is empty by construction.
            F.collect_failure_bundle(output_dir=out.with_name(out.name+'_FAILURE'),primary_error=str(exc),
                stage='CONTROL_BIND',native_exit=3,protected_effects_committed=committed,identities=[],
                source_roots={'BIND_EVIDENCE':out},process_api=None)
        except Exception as collection_exc:
            try:
                F.durable_write(out/'BIND_COLLECTION_ERROR.json',L.canonical_json_bytes({'primary_error':str(exc),'collection_error':str(collection_exc)}))
            except Exception:
                pass
        raise
