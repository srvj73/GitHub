"""PHASE_B_QS4_HARNESS_V001 (R1) — orquestrador QS4 (shadow com dados reais em quarentena, DD-7) do PHASE_B_ADAPTER_V001 R3.

CLI fechada (somente via BOOTSTRAP_QS4_HARNESS.ps1; python -B; PYTHONDONTWRITEBYTECODE=1):
  qs4_harness.py plan
  qs4_harness.py orchestrate --attempt-id <SESSÃO> --r3-dir <R3 extraído> --qs3-receipt <abs> --qs3-receipt-sha256 <sha>
                             [--resume-from <ATTEMPT LÓGICO>]
  qs4_harness.py invoke --step-json <abs>                        (interno: um processo por invocação)
  qs4_harness.py ctrlc --pid <pid>                               (interno, Windows: CTRL_C_EVENT no console do alvo)
  qs4_harness.py p5probe-target --marker-dir <abs> --timeout-s <n> (interno: alvo do microprobe P5)

Attempt LÓGICO (shadow, ledger, CASES) x SESSÃO (log, status, receipt, progresso desta execução do bootstrap). Na 1ª
sessão os dois coincidem; numa retomada a sessão nova continua o attempt lógico a partir da fronteira durável do
ledger (QS4_LEDGER.json + diário encadeado QS4_LEDGER.jsonl), depois de revalidar todos os bytes já concluídos.

O orquestrador nunca importa o CODE congelado; usa apenas módulos não-CODE do R3 após verificar a identidade R3.
Escreve somente sob <qs4_shadow_base>\\<lógico>, <evidence_base>\\<lógico>\\HARNESS e <evidence_base>\\<sessão>\\HARNESS.
Nenhum arquivo é removido. Único kill: TerminateProcess do filho do próprio caso T18_P10. Watchdog finito sem auto-kill.
MULTIWORK=NOT_APPLICABLE (mutex global do R3 + ordem causal das referências + isolamento dos testes): um filho por vez.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path

HARNESS_DIR = Path(__file__).resolve().parent
if str(HARNESS_DIR) not in sys.path:
    sys.path.insert(0, str(HARNESS_DIR))

EXIT_PASS, EXIT_BLOCKED, EXIT_UNPROVEN = 0, 2, 3


def _print(k, v):
    sys.stdout.write(f"{k}={v}\n")
    sys.stdout.flush()


def _args(argv, required, optional=()):
    allowed = set(required) | set(optional)
    out, i = {}, 0
    while i < len(argv):
        if argv[i] not in allowed or argv[i] in out or i + 1 >= len(argv):
            return None
        out[argv[i]] = argv[i + 1]
        i += 2
    return out if set(required) <= set(out) else None


class Unproven(Exception):
    def __init__(self, code: str, detail: str = ""):
        self.code, self.detail = code, detail
        super().__init__(code + " " + detail)


class Orchestrator:
    def __init__(self, session_id: str, r3_dir: Path, qs3_receipt: str, qs3_sha: str, resume_from=None, retirement_context=None):
        import qs4_lib as L
        self.L = L
        self.session = session_id
        self.logical = resume_from or session_id
        self.resume = resume_from is not None
        self.retirement_context = retirement_context
        self.r3_dir = Path(r3_dir)
        self.qs3_receipt, self.qs3_sha = qs3_receipt, qs3_sha
        self.c = L.load_constants(HARNESS_DIR / "qs4_constants.json")
        ev = Path(self.c["paths"]["evidence_base"])
        self.sess_dir = ev / session_id / "HARNESS"
        self.evidence = ev / self.logical / "HARNESS"
        self.shadow = Path(self.c["paths"]["qs4_shadow_base"]) / self.logical
        self.ledger_p, self.journal_p = self.evidence / "QS4_LEDGER.json", self.evidence / "QS4_LEDGER.jsonl"
        self.led = None
        self.lock = None
        self.status_failures = 0
        self.status_seq = 0
        self.steps_total = sum(len(x["steps"]) for x in self.c["cases"])
        self.session_units = 0
        self.session_t0 = time.monotonic()
        self.phase = "INIT"
        self.checkpoint = "NONE"
        self.unproven = False
        self.blocked_reason = None
        self.active_child = None
        self.owned_children = []
        self.rec: dict = {"schema": L.HARNESS_RECEIPT_SCHEMA, "attempt_id": session_id, "logical_attempt": self.logical,
                          "resumed": self.resume, "cases": [], "items": {}, "multiwork": self.c["multiwork"],
                          "t18_semantics": self.c["t18_semantics"]}
        self.variant_dir = None
        self.shadow_frontier = False
        self.status_lock = threading.RLock()
        self.last_status_mono = 0.0
        self.last_status_kw: dict = {}
        self.hb_stop = threading.Event()
        self.hb_thread = None

    # ------------------------------------------------------------------ log / status / progresso
    def log(self, text: str) -> None:
        line = text.rstrip("\n")
        sys.stdout.write(line + "\n")
        sys.stdout.flush()
        with (self.sess_dir / "HARNESS.log").open("a", encoding="utf-8", newline="\n") as f:
            f.write(line + "\n")
            f.flush()
            os.fsync(f.fileno())

    def units_done(self) -> int:
        """Unidades DURÁVEIS: passos registrados no ledger das gerações vigentes dos casos (nunca abandonadas)."""
        if not self.led:
            return 0
        return sum(len(cl.get("steps") or []) for cl in list(self.led["cases"].values()))  # cópia atômica (heartbeat)

    def start_heartbeat(self) -> None:
        """Liveness: garante HARNESS_STATUS <= heartbeat_seconds mesmo durante hashing longo no thread principal."""
        hb = float(self.c["heartbeat_seconds"])

        def loop():
            while not self.hb_stop.wait(1.0):
                try:
                    if time.monotonic() - self.last_status_mono >= hb:
                        self.status(**dict(self.last_status_kw, _liveness=True))
                except Exception:  # noqa: BLE001 - nunca morre em silêncio: conta como falha de status (B08)
                    with self.status_lock:
                        self.status_failures += 1
        self.hb_thread = threading.Thread(target=loop, name="QS4_HARNESS_HEARTBEAT", daemon=True)
        self.hb_thread.start()

    def stop_heartbeat(self) -> None:
        self.hb_stop.set()
        if self.hb_thread is not None:
            self.hb_thread.join(timeout=10)

    def status(self, active="YES", committed="0", extra=None, _liveness=False) -> bool:
        if not hasattr(self, "E"):
            return False
        with self.status_lock:
            if not _liveness:
                self.last_status_kw = {"active": active, "committed": committed, "extra": extra}
            try:
                return self._status_write(active, committed, extra)
            except Exception:  # noqa: BLE001 - montagem dos campos também conta como falha de status
                self.status_failures += 1
                return False

    def _status_write(self, active, committed, extra) -> bool:
        E = self.E
        done = self.units_done()
        el = time.monotonic() - self.session_t0
        rate = (self.session_units / el) if (self.session_units and el > 0) else None  # unidades duráveis/s nesta sessão
        eta = ((self.steps_total - done) / rate) if (rate and active == "YES") else (0 if active == "NO" else None)
        fields = {"PHASE": self.phase, "PROGRESS": str(done), "COMMITTED": str(committed), "TOTAL": str(self.steps_total),
                  "RATE": (f"{3600.0 * rate:.2f}steps/h" if rate else "UNKNOWN"), "ETA": E.fmt_eta(eta),
                  "FINISH": (time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() + eta)) if eta is not None else "UNKNOWN"),
                  "ACTIVE": active, "READY_WAITING": "0", "CHECKPOINT": self.checkpoint, "SAFE_STOP": "NO"}
        doc = {"schema": "MINOTAURO_PHASE_B_QS4_HARNESS_STATUS_V001", "field_order": list(E.STATUS_FIELDS),
               "attempt_id": self.session, "logical_attempt": self.logical, "seq": self.status_seq + 1,
               "updated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "fields": fields,
               "progress": self.L.progress_view(done, self.steps_total, reconciled=False),
               "status_write_failures": self.status_failures}
        if extra:
            doc["extra"] = extra
        try:
            sha = E.write_status_atomic(self.sess_dir / "HARNESS_STATUS.json", doc)
            if self.L.sha_file(self.sess_dir / "HARNESS_STATUS.json") != sha:
                raise RuntimeError("STATUS_READBACK")
            self.status_seq = doc["seq"]
            self.last_status_sha = sha
            self.last_status_mono = time.monotonic()
            return True
        except Exception:  # noqa: BLE001
            self.status_failures += 1
            return False

    # ------------------------------------------------------------------ ledger
    def save(self, event: str) -> None:
        """Fronteira durável: ledger atômico + diário encadeado (fsync). Falha => estado não provado."""
        try:
            self.led = self.L.ledger_write(self.ledger_p, self.journal_p, self.led, self.E.write_status_atomic, event)
        except Exception as e:  # noqa: BLE001
            raise Unproven("LEDGER_WRITE_FAILED", f"{event} {type(e).__name__}") from e

    def digest(self, root) -> str:
        return self.E.inventory_digest(self.E.inventory(root))

    def bindings(self) -> dict:
        E = self.E
        return {"harness_identity_sha256": self.rec["harness_identity_sha256"],
                "harness_constants_sha256": self.c["_sha256"],
                "r3_identity_sha256": self.rec["r3_identity_sha256"],
                "r3_package_zip_sha256": self.c["adapter"]["package_zip_sha256"],
                "r3_constants_sha256": self.c["adapter"]["constants_sha256"],
                "qs3_receipt_sha256": self.rec["prior_qs3"]["qs3_receipt_sha256"],
                "qs3_attempt_id": self.rec["prior_qs3"]["qs3_attempt_id"],
                "template_sha256": self.rec["prior_qs3"]["template_sha256"],
                "calendar_sha256": E.canonical_hash({str(k): v for k, v in self.o2d.items()}),
                "tick_rehash_sha256": E.canonical_hash(self.rec["tick_rehash"]),
                "protected_before": self.protected_before,
                "multiwork": self.c["multiwork"]["value"]}

    def owner(self) -> dict:
        return {"pid": os.getpid(), "ctime": self.L.process_ctime(os.getpid())}

    # ------------------------------------------------------------------ preconditions
    def preconditions(self) -> None:
        L = self.L
        self.phase = "H00_HARNESS_IDENTITY"
        hv = L.verify_harness_package(HARNESS_DIR)
        env_p = HARNESS_DIR / "qualification" / self.c["harness_envelope"]["file"]
        if not env_p.is_file() or L.sha_file(env_p) != self.c["harness_envelope"]["sha256"]:
            raise L.HarnessBlocked("H00_HARNESS_ENVELOPE_PIN")
        self.rec["harness_identity_sha256"] = hv["manifest_sha256"]
        self.rec["harness_constants_sha256"] = self.c["_sha256"]
        self.phase = "H02_R3_IDENTITY"
        rv = L.verify_r3_package(self.r3_dir, self.c)
        self.rec["r3_identity_sha256"] = rv["manifest_sha256"]
        sys.path.insert(0, str(self.r3_dir))
        import phase_b_effects as E
        import phase_b_contract as K
        import phase_b_shared as S
        import phase_b_state as ST
        frozen_loaded = [m for m in ("r1r11_full_2026", "minotauro_v004_runner", "r1r11_coordinator") if m in sys.modules]
        if frozen_loaded:
            raise L.HarnessBlocked("ORCHESTRATOR_CODE_IMPORTED", ",".join(frozen_loaded))
        self.E, self.K, self.S, self.ST = E, K, S, ST
        self.r3c = K.load_constants(self.r3_dir / "phase_b_constants.json")
        self.lay = S.Layout.production(self.r3c, self.r3_dir)
        self.status()
        self.start_heartbeat()
        # exclusão de sessões do mesmo attempt lógico (antes de tocar ledger/shadow)
        self.phase = "H08_ATTEMPT_LOCK"
        self.lock = L.AttemptLock(self.logical, self.evidence, S.WindowsPlatform)
        self.lock.acquire()
        self.phase = "H01_PRIOR_QS3"
        self.status()
        q = L.validate_prior_qs3(self.qs3_receipt, self.qs3_sha, self.c, self.c["paths"]["evidence_base"], E.canonical_hash)
        self.template = q.pop("template")
        self.rec["prior_qs3"] = q
        tpath = self.evidence / "QS3_TEMPLATE.json"
        if self.resume:
            if not tpath.is_file() or E.canonical_hash(L.load_json_bytes(tpath.read_bytes())) != q["template_sha256"]:
                raise L.HarnessBlocked("RESUME_TEMPLATE_MISMATCH")
        else:
            E.write_json_durable(tpath, self.template, exclusive=True)
        self.template_path = tpath
        self.o2d = L.ordinal_map(self.lay.preflight_root)
        L.check_calendar(self.o2d, self.c)
        self.phase = "H03_REAL_CONTROL_PREPARED"
        self.status()
        struct = ST.classify_structure(E.inventory(self.lay.control_root), self.r3c, self.lay.control_root)
        if struct["state"] != ST.PREPARED or struct["findings"]:
            raise L.HarnessBlocked("H03_REAL_CONTROL_NOT_PREPARED", f"{struct['state']} {struct['findings'][:5]}")
        self.phase = "H04_FREE_SPACE"
        self.check_free(int(self.c["free_space"]["min_free_bytes_at_start"]), "H04_FREE_SPACE")
        self.phase = "H05_PROTECTED_BEFORE"
        self.status()
        self.protected_before = self.protected()
        self.rec["protected_before"] = self.protected_before
        self.phase = "H07_P5_CONSOLE_MICROPROBE"
        self.status()
        self.p5_microprobe()
        self.phase = "H06_TICK_REHASH_ONCE"
        self.status()
        t0 = time.monotonic()

        def progress(done, total, _last=[0.0]):
            if time.monotonic() - _last[0] >= 30 or done == total:
                _last[0] = time.monotonic()
                rate = done / max(time.monotonic() - t0, 1e-6)
                self.status(extra={"tick_rehash_bytes": done, "tick_rehash_total": total,
                                   "tick_rehash_eta": E.fmt_eta((total - done) / rate if rate else None)})
        self.rec["tick_rehash"] = K.tick_rehash(self.lay, self.r3c, progress)

    def check_free(self, need: int, code: str) -> None:
        probe = self.shadow
        while not probe.exists() and probe != probe.parent:
            probe = probe.parent
        free = shutil.disk_usage(str(probe)).free
        if free < need:
            raise self.L.HarnessBlocked(code, f"free={free} need={need}")

    def protected(self) -> dict:
        E, lay = self.E, self.lay
        top = {}
        rel = Path(lay.release_root)
        if rel.is_dir():
            for p in sorted(rel.iterdir()):
                top[p.name] = self.L.sha_file(p) if p.is_file() else "DIR"
        return {"control": E.inventory_digest(E.inventory(lay.control_root)),
                "preflight": E.inventory_digest(E.inventory(lay.preflight_root)),
                "code": E.inventory_digest(E.inventory(lay.code_root)),
                "r3_package": E.inventory_digest(E.inventory(self.r3_dir)),
                "harness_package": E.inventory_digest(E.inventory(HARNESS_DIR)),
                "release_top": E.canonical_hash(top)}

    def check_protected(self, where: str) -> None:
        now = self.protected()
        delta = [k for k in now if now[k] != self.protected_before[k]]
        if delta:
            raise Unproven("PROTECTED_DELTA", where + ":" + ",".join(delta))

    # ------------------------------------------------------------------ P5: microprobe físico pré-matriz
    def p5_microprobe(self) -> None:
        """Prova física, ANTES da matriz longa, de que o CTRL_C_EVENT chega a um filho criado exatamente como o P5
        (console próprio real): READY -> helper (FreeConsole/AttachConsole/SetConsoleCtrlHandler/Generate...) ->
        KeyboardInterrupt sem argumentos no alvo -> CAUGHT, exit 0. O alvo se encerra sozinho após o timeout
        (nunca é morto). Falha => BLOCKED sem iniciar os 45 passos."""
        L = self.L
        mp = self.c["p5"]["microprobe"]
        d = self.sess_dir / "P5_MICROPROBE"
        d.mkdir(parents=True, exist_ok=False)
        cmd = L.python_cmd() + [str(HARNESS_DIR / "qs4_harness.py"), "p5probe-target", "--marker-dir", str(d),
                                "--timeout-s", str(int(mp["target_timeout_s"]))]
        out = {"ready": False, "ctrl_c": None}
        with (d / "target.out.txt").open("wb") as fo:
            p = subprocess.Popen(cmd, stdout=fo, stderr=subprocess.STDOUT, env=self.child_env(), **L.popen_kwargs(console=True))
            ctime = L.process_ctime(p.pid)
            self.owned_children.append({"pid": p.pid, "ctime": ctime})
            t0 = time.monotonic()
            while p.poll() is None and not (d / "READY.json").is_file() and time.monotonic() - t0 < float(mp["ready_timeout_s"]):
                time.sleep(0.1)
            out["ready"] = (d / "READY.json").is_file()
            if out["ready"] and p.poll() is None:
                out["ctrl_c"] = self.send_ctrl_c(p.pid)
            limit = float(mp["target_timeout_s"]) + float(mp["exit_wait_s"])
            while p.poll() is None:
                if time.monotonic() - t0 > limit:
                    self.unproven = True
                    raise Unproven("H07_P5_MICROPROBE_TARGET_STILL_ALIVE", f"pid={p.pid} auto_kill=NO")
                time.sleep(0.1)
        out["target_exit"] = p.returncode
        late = self.late_descendants(p.pid, ctime)
        if late:
            self.unproven = True
            raise Unproven("H07_P5_MICROPROBE_ORPHAN", repr([x[0] for x in late]))
        caught = L.load_json_bytes((d / "CAUGHT.json").read_bytes()) if (d / "CAUGHT.json").is_file() else None
        ready = L.load_json_bytes((d / "READY.json").read_bytes()) if out["ready"] else {}
        out["caught"] = caught
        out["target_ctrl_c_enable"] = ready.get("ctrl_c_enable")
        reasons = []
        if not out["ready"]:
            reasons.append("NOT_READY")
        if (out["ctrl_c"] or {}).get("helper_exit") != 0:
            reasons.append("HELPER_EXIT")
        if out["target_exit"] != 0:
            reasons.append(f"TARGET_EXIT_{out['target_exit']}")
        if not caught or caught.get("args_len") != 0:
            reasons.append("NO_KEYBOARDINTERRUPT_WITHOUT_ARGS")
        if out["ready"] and (out["target_ctrl_c_enable"] or {}).get("enabled") is not True:
            reasons.append("CTRL_C_NOT_ENABLED_IN_TARGET")
        out["result"] = "PASS" if not reasons else "FAIL"
        out["reasons"] = reasons
        self.rec["p5_microprobe"] = out
        self.log(f"P5_MICROPROBE={out['result']} reasons={','.join(reasons) or 'NONE'} method={(out['ctrl_c'] or {}).get('method')}")
        if reasons:
            raise L.HarnessBlocked("H07_P5_MICROPROBE_FAILED", ",".join(reasons))

    # ------------------------------------------------------------------ variant adapter (T22)
    def ensure_variant(self) -> Path:
        if self.variant_dir is not None:
            return self.variant_dir
        L = self.L
        v0 = self.led.get("variant")
        if v0 and v0.get("status") == "DONE":
            self.variant_dir = Path(v0["dir"])
            return self.variant_dir
        gen = int(self.led.get("variant_gen") or 0) + 1
        dst = self.shadow / "VARIANT_ADAPTER" / f"V{gen}" / "PHASE_B_ADAPTER_V001"
        L.guard_case_root(dst, self.shadow, Path(self.lay.control_root))
        self.led["variant_gen"] = gen
        self.led["variant"] = {"status": "BUILDING", "dir": str(dst), "gen": gen}
        self.save("VARIANT_BUILDING")
        shutil.copytree(self.r3_dir, dst)
        with (dst / "qualification" / "QUALIFICATION_PLAN.md").open("a", encoding="utf-8", newline="\n") as f:
            f.write(f"\n<!-- QS4 T22 VARIANT {self.logical}: identidade diferente do R3, mesmo código e constantes -->\n")
        cmd = L.python_cmd() + [str(dst / "qualification" / "build_package.py"), str(dst)]
        rc, _out = self.run_simple(cmd, int(self.c["watchdog_seconds"]["variant_build"]), f"VARIANT_BUILD_V{gen}")
        if rc != 0:
            raise L.HarnessBlocked("T22_VARIANT_BUILD", str(rc))
        v = L.verify_manifest_dir(dst, "MANIFEST_SHA256.txt", "ADAPTER_IDENTITY.json")
        if v["manifest_sha256"] == self.c["adapter"]["identity_sha256"] or L.sha_file(dst / "phase_b_constants.json") != self.c["adapter"]["constants_sha256"]:
            raise L.HarnessBlocked("T22_VARIANT_NOT_DISTINCT")
        # identidade coerente (G05 da variante PASSA): o bloqueio esperado é o G12 (RUN binding de outra identidade)
        if v["identity"].get("adapter_identity_sha256") != v["manifest_sha256"] or v["identity"].get("manifest_sha256") != v["manifest_sha256"]:
            raise L.HarnessBlocked("T22_VARIANT_IDENTITY_INCOHERENT")
        self.led["variant"] = {"status": "DONE", "dir": str(dst), "gen": gen, "identity_sha256": v["manifest_sha256"]}
        self.save("VARIANT_DONE")
        self.variant_dir = dst
        return dst

    def run_simple(self, cmd, watchdog_s: int, label: str):
        """Filho simples com watchdog SEM kill (expiração => Unproven)."""
        out_p = self.sess_dir / f"{label}.out.txt"
        with out_p.open("wb") as fo:
            p = subprocess.Popen(cmd, stdout=fo, stderr=subprocess.STDOUT, env=self.child_env(), **self.L.popen_kwargs())
            self.owned_children.append({"pid": p.pid, "ctime": self.L.process_ctime(p.pid)})
            t0 = time.monotonic()
            while p.poll() is None:
                if time.monotonic() - t0 > watchdog_s:
                    self.unproven = True
                    raise Unproven("WATCHDOG_EXPIRED", f"{label} pid={p.pid} auto_kill=NO")
                time.sleep(0.5)
        return p.returncode, out_p

    def child_env(self) -> dict:
        env = dict(os.environ)
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["QS4_HARNESS_SESSION"] = self.session  # marca de sessão (prova de "nenhum processo vivo" na retomada)
        return env

    def send_ctrl_c(self, pid: int) -> dict:
        L = self.L
        if L.WIN:
            cmd = L.python_cmd() + [str(HARNESS_DIR / "qs4_harness.py"), "ctrlc", "--pid", str(pid)]
            rc, _ = self.run_simple(cmd, int(self.c["watchdog_seconds"]["ctrl_c_helper"]), f"CTRL_C_{pid}")
            return {"method": "FreeConsole+AttachConsole+SetConsoleCtrlHandler(NULL,TRUE)+GenerateConsoleCtrlEvent(CTRL_C_EVENT,0)",
                    "helper_exit": rc}
        import signal
        os.killpg(pid, signal.SIGINT)
        return {"method": "killpg(SIGINT) [POSIX analog]", "helper_exit": 0}

    # ------------------------------------------------------------------ expectativa efetiva
    # sessões commitadas no instante exato de cada parada por SEAM_INTERRUPT_AFTER (estrutura do run_phase congelado)
    COMMITTED_AT_TARGET = {"RUNLOCK_ENTER": 0, "PREPARE_VOLUME": 0, "RECOVER": 0, "LOAD_CHECKPOINT": 0, "WRITE_ANCHOR": 0}

    def effective_expect(self, step: dict) -> dict:
        """Expectativa fechada + defaults determinísticos derivados da parada pedida:
        * QS4_STOP_ANCHOR no ordinal N => code 'session=<data N>' e committed = N-1 (o anchor de N só é gravado
          depois do commit de N-1); estado IN_PROGRESS limpo (sem journal/pending/constatações);
        * SEAM_INTERRUPT_AFTER => committed fixo por alvo; CLEAR_ANCHOR => fim de janeiro verificado (21);
        * INTERRUPT_SIGNAL/FAULT/TRACE_GUARD/TERMINATED => estado IN_PROGRESS (FAULT pode deixar journal).
        Valores explícitos do passo prevalecem."""
        e = dict(step["expect"])
        stop = step["stop"]
        out = e.get("outcome")
        if out == "INTERRUPT_SEAM" and e.get("seam") == "QS4_STOP_ANCHOR" and "anchor_ordinal" in stop:
            n = int(stop["anchor_ordinal"])
            e.setdefault("code", "session=" + self.o2d[n])
            e.setdefault("committed", n - 1)
            e.setdefault("clean_state", True)
        if out == "INTERRUPT_SEAM" and e.get("seam") == "SEAM_INTERRUPT_AFTER" and "interrupt_target" in stop:
            t = stop["interrupt_target"]
            if t == "CLEAR_ANCHOR":
                e.setdefault("committed", int(self.c["calendar_expectations"]["january_last_ordinal"]))
                e.setdefault("clean_state", True)
            elif t in self.COMMITTED_AT_TARGET:
                e.setdefault("committed", self.COMMITTED_AT_TARGET[t])
        if out in ("INTERRUPT_SEAM", "INTERRUPT_SIGNAL", "FAULT", "TRACE_GUARD", "TERMINATED"):
            e.setdefault("state_after", "IN_PROGRESS")
        if out == "TERMINATED":  # P10 bloqueia DEPOIS de gravar o anchor: nenhuma transação aberta
            e.setdefault("clean_state", True)
        # INTERRUPT_SIGNAL (Ctrl+C real) pode cair no meio do commit: journal legítimo; a prova é a retomada
        return e

    def invoke_cmd(self, step_json: Path) -> list:
        return self.L.python_cmd() + [str(HARNESS_DIR / "qs4_harness.py"), "invoke", "--step-json", str(step_json)]

    # ------------------------------------------------------------------ passo
    def step_doc(self, case, i, step, gen, sdir, inv, root, adapter_dir) -> dict:
        st = {"case": case["id"], "case_gen": gen, "step_index": i, "kind": step["kind"], "stop": step["stop"],
              "safety_ordinal": int(self.c["endpoints"][case["family"]]), "invocation_attempt_id": inv,
              "step_dir": str(sdir), "root": str(root), "adapter_dir": str(adapter_dir),
              "adapter_constants_sha256": self.c["adapter"]["constants_sha256"],
              "attempt_shadow": str(self.shadow), "g18_base": str(self.shadow / "G18"),
              "invocations_evidence_base": str(self.evidence / "INVOCATIONS"),
              "ordinal_to_date": {str(k): v for k, v in self.o2d.items()},
              "template": step.get("template", "NONE"), "template_path": str(self.template_path),
              "template_sha256": self.rec["prior_qs3"]["template_sha256"],
              "block_max_s": float(self.c["p10"]["block_max_s"])}
        for k in ("notify_anchor_ordinal", "block_anchor_ordinal", "orchestrator_action"):
            if k in step:
                st[k] = step[k]
        return st

    def run_step(self, case: dict, i: int, step: dict, root: Path, adapter_dir: Path) -> dict:
        L = self.L
        cl = self.led["cases"][case["id"]]
        inv = L.new_attempt_id()
        sdir = self.evidence / "CASES" / case["id"] / f"R{cl['gen']}" / f"{i}_{inv}"
        sdir.mkdir(parents=True, exist_ok=False)
        fam = case["family"]
        self.E.write_json_durable(sdir / "STEP.json", self.step_doc(case, i, step, cl["gen"], sdir, inv, root, adapter_dir),
                                  exclusive=True)
        self.check_free(int(self.c["free_space"]["min_free_bytes_per_invocation"]), "FREE_SPACE_PER_INVOCATION")
        cmd = self.invoke_cmd(sdir / "STEP.json")
        action = step.get("orchestrator_action")
        watchdog = int(self.c["watchdog_seconds"].get(f"invoke_{fam}", self.c["watchdog_seconds"]["invoke_other"]))
        hb = int(self.c["heartbeat_seconds"])
        res = {"case": case["id"], "case_gen": cl["gen"], "step": i, "invocation_attempt_id": inv, "action": action,
               "step_dir": str(sdir), "run_root": str(root)}
        root_before = self.digest(root)
        # intenção durável ANTES do efeito (base da reconciliação na retomada)
        self.led["partial"] = {"stage": "STEP", "case": case["id"], "gen": cl["gen"], "step": i, "invocation_attempt_id": inv,
                               "step_dir": str(sdir), "run_root": str(root), "root_digest_before": root_before,
                               "action": action, "child": None, "session": self.session,
                               "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        self.save("STEP_INTENT")
        self.phase = f"{case['id']}#{i}"
        t0 = time.monotonic()
        with (sdir / "stdout.txt").open("wb") as fo, (sdir / "stderr.txt").open("wb") as fe:
            # console próprio real SOMENTE para o filho P5 (alvo do CTRL_C_EVENT); demais: CREATE_NO_WINDOW
            p = subprocess.Popen(cmd, stdout=fo, stderr=fe, env=self.child_env(),
                                 **L.popen_kwargs(console=(action == "CTRL_C")))  # cwd herdado
            self.active_child = p
            child_ctime = L.process_ctime(p.pid)
            self.owned_children.append({"pid": p.pid, "ctime": child_ctime})
            self.led["partial"]["child"] = {"pid": p.pid, "ctime": child_ctime}
            res["child"] = {"pid": p.pid, "ctime": child_ctime}
            self.save("STEP_CHILD")
            self.log(f"STEP_START case={case['id']} gen={cl['gen']} step={i} pid={p.pid} watchdog_s={watchdog} auto_kill=NO action={action}")
            last_hb, acted, desc = 0.0, False, []
            while p.poll() is None:
                el = time.monotonic() - t0
                if el - last_hb >= hb:
                    last_hb = el
                    committed = len([d for d in (root / "PHASE_B" / "sessions").iterdir() if d.is_dir()]) \
                        if (root / "PHASE_B" / "sessions").is_dir() else 0
                    self.status(committed=str(committed), extra={"child_pid": p.pid, "elapsed_s": int(el), "watchdog_s": watchdog})
                    self.log(f"HEARTBEAT case={case['id']} step={i} pid={p.pid} elapsed_s={int(el)} committed={committed} auto_kill=NO")
                if action == "CTRL_C" and not acted and (sdir / "QS4_MARKER_NOTIFY.txt").is_file():
                    acted = True
                    res["ctrl_c"] = self.send_ctrl_c(p.pid)
                    self.log(f"P5_CTRL_C_SENT pid={p.pid} {res['ctrl_c']}")
                if action == "TERMINATE" and not acted and (sdir / "QS4_MARKER_BLOCK.txt").is_file():
                    acted = True
                    desc = L.descendants(p.pid, child_ctime)
                    res["p10_descendants_before"] = [d[0] for d in desc]
                    L.terminate_p10(p.pid)
                    self.log(f"P10_TERMINATE pid={p.pid} descendants={res['p10_descendants_before']}")
                if action and not acted and el > float(self.c["p5" if action == "CTRL_C" else "p10"]["marker_timeout_s"]):
                    acted = True
                    res["marker_timeout"] = True
                if el > watchdog:
                    self.unproven = True
                    self.log(f"WATCHDOG_EXPIRED case={case['id']} step={i} pid={p.pid} auto_kill=NO child_killed=NO RECONCILIATION_REQUIRED=YES")
                    self.observe(watchdog_expired=True, child_alive=True)
                    raise Unproven("WATCHDOG_EXPIRED", f"{case['id']}#{i} pid={p.pid}")
                time.sleep(0.5)
            self.active_child = None
        native = p.returncode
        # saída observada DURÁVEL logo após o poll: a adoção na retomada exige exit nativo 0 registrado
        self.led["partial"]["exited"] = {"native_exit": native}
        self.save("STEP_EXITED")
        res["native_exit"], res["seconds"] = native, round(time.monotonic() - t0, 1)
        res["stderr_sha256"] = L.sha_file(sdir / "stderr.txt")
        res["stdout_sha256"] = L.sha_file(sdir / "stdout.txt")
        # órfãos: descendentes registrados (P10) e descendentes vivos após a saída do filho
        grace = float(self.c["p10"]["orphan_grace_s"])
        tg = time.monotonic()
        alive = [d for d in desc if L.alive(d[0], d[1])]
        while alive and time.monotonic() - tg < grace:
            time.sleep(1.0)
            alive = [d for d in desc if L.alive(d[0], d[1])]
        late = self.late_descendants(p.pid, child_ctime)
        orphans = sorted({d[0] for d in alive} | {d[0] for d in late})
        if orphans:
            self.unproven = True
            self.log(f"ORPHAN_ACTIVE case={case['id']} step={i} pids={orphans} auto_kill=NO RECONCILIATION_REQUIRED=YES")
            self.observe(native_exit=native, orphans=orphans)
            raise Unproven("ORPHAN_ACTIVE", f"{case['id']}#{i} {orphans}")
        if action == "TERMINATE" and res.get("p10_descendants_before") is not None:
            # sem receipt do filho (morto pelo P10): o orquestrador classifica a raiz com o classificador do R3
            struct = self.ST.classify_structure(self.E.inventory(root), self.r3c, root)
            rec = {"outcome": {"class": "TERMINATED", "seam": None, "code": None}, "orphans_alive": [],
                   "root_digest_before": root_before, "root_digest_after": self.digest(root),
                   "runtime_evidence": {"started": False, "clean": False, "note": "processo terminado pelo P10"},
                   "state_after": struct["state"], "state_after_findings": struct["findings"][:20],
                   "state_after_detail": {"journal": bool(struct.get("journal")), "pending": len(struct.get("pending") or [])},
                   "committed_count": len(struct.get("sessions") or [])}
            res["receipt"] = {"valid": True, "reason": "TERMINATED_BY_P10_NO_CHILD_RECEIPT"}
        else:
            v = L.verify_receipt_with_companion(sdir / "STEP_RECEIPT.json", L.STEP_RECEIPT_SCHEMA, inv,
                                                exit_code=0 if native == 0 else None)
            res["receipt"] = {k: v.get(k) for k in ("valid", "reason", "sha256")}
            if native != 0 or not v["valid"]:
                self.unproven = True
                self.observe(native_exit=native, receipt=v["reason"])
                self.log(f"MISSING_DOWNSTREAM_RESULT case={case['id']} step={i} native_exit={native} stderr_sha256={res['stderr_sha256']} receipt={v['reason']}")
                raise Unproven("STEP_RESULT_NOT_PROVEN", f"{case['id']}#{i} native={native} {v['reason']}")
            rec = v["doc"]
        return self.commit_step(case, i, step, res, rec, root, action)

    def observe(self, **obs) -> None:
        """Registra no ledger, ANTES de parar com 'não provado', o que foi observado do filho (nunca adotável)."""
        try:
            if self.led and self.led.get("partial"):
                self.led["partial"]["observed"] = obs
                self.save("STEP_OBSERVED")
        except Unproven as e:
            self.log(f"STEP_OBSERVED_NOT_DURABLE {e.code}")

    def late_descendants(self, pid: int, ctime) -> list:
        """Descendentes vivos após a saída do filho, com a mesma carência do P10 (host de console encerrando etc.)."""
        L = self.L
        grace = float(self.c["p10"]["orphan_grace_s"])
        tg = time.monotonic()
        late = L.descendants(pid, ctime)
        while late and time.monotonic() - tg < grace:
            time.sleep(1.0)
            late = L.descendants(pid, ctime)
        return late

    def commit_step(self, case, i, step, res, rec, root, action, adopted=False) -> dict:
        """Avaliação + registro DURÁVEL do passo (fronteira de retomada). Usado também na adoção de um passo
        cujo filho terminou com receipt válido antes da queda do orquestrador."""
        L = self.L
        res["outcome"] = rec.get("outcome")
        for k in ("safe_stop_requested_line", "committed_count", "trace_guard", "t31b", "t17", "state_before", "state_after",
                  "state_after_findings", "state_after_detail", "blocked_gate", "runtime_evidence", "root_digest_before",
                  "root_digest_after", "quarantine"):
            if k in rec:
                res[k] = rec[k]
        res["t30_foreign"] = (rec.get("t30") or {}).get("foreign", [])
        res["expect_effective"] = self.effective_expect(step)
        rec.setdefault("kind", step["kind"])
        res["evaluation"] = L.evaluate_step(res["expect_effective"], rec)
        # ações do orquestrador comprovadas (P5: helper entregou o CTRL_C_EVENT; P10: TerminateProcess executado)
        extra = []
        if action and res.get("marker_timeout"):
            extra.append("ORCHESTRATOR_ACTION_MARKER_TIMEOUT")
        if action == "CTRL_C" and (res.get("ctrl_c") or {}).get("helper_exit") != 0:
            extra.append("P5_CTRL_C_NOT_DELIVERED")
        if action == "TERMINATE" and res.get("p10_descendants_before") is None:
            extra.append("P10_TERMINATE_NOT_EXECUTED")
        if extra:
            res["evaluation"] = {"pass": False, "reasons": res["evaluation"]["reasons"] + extra}
        res["adopted_on_resume"] = adopted
        res["root_digest_after_orch"] = self.digest(root)
        cl = self.led["cases"][case["id"]]
        cl["steps"].append(res)
        self.led["partial"] = None
        self.save("STEP_DONE")
        self.session_units += 1
        self.checkpoint = f"{case['id']}#{i}"
        pv = L.progress_view(self.units_done(), self.steps_total)
        self.log(f"STEP_END case={case['id']} step={i} native_exit={res.get('native_exit')} outcome={json.dumps(res['outcome'], sort_keys=True)} "
                 f"pass={res['evaluation']['pass']} reasons={';'.join(res['evaluation']['reasons'])} adopted={adopted}")
        self.log("PROGRESS_BAR=" + pv["BAR"])
        self.status()
        return res

    # ------------------------------------------------------------------ caso
    def case_root(self, cid: str, gen: int) -> Path:
        return self.shadow / "CASES" / cid / f"R{gen}" / "CONTROL"

    def reloc_root(self, cid: str, gen: int, n: int = 0) -> Path:
        return self.shadow / "RELOCATED" / cid / (f"R{gen}" if not n else f"R{gen}_{n}") / "CONTROL"

    def run_case(self, case: dict) -> dict:
        L = self.L
        cid = case["id"]
        ref = case.get("reference")
        if ref and ref not in self.led.get("refs", {}):
            raise L.HarnessBlocked("REFERENCE_PREREQUISITE_NOT_PASS", f"{cid}:{ref}")
        cl = self.led["cases"].get(cid)
        if cl is not None and cl["status"] == "DONE":
            self.log(f"CASE_SKIP_DURABLE {cid}={cl['out']['result']} gen={cl['gen']}")
            return cl["out"]
        if cl is None:
            gen = int(self.led["case_gen"].get(cid, 1))
            root = self.case_root(cid, gen)
            L.guard_case_root(root, self.shadow, Path(self.lay.control_root))
            cl = {"gen": gen, "status": "SEEDING", "root": str(root), "steps": [], "covers": case["covers"],
                  "reference": case.get("reference")}
            self.led["cases"][cid] = cl
            self.save("CASE_SEEDING")
            cl["seed"] = L.seed_case_root(Path(self.lay.control_root), root, self.r3c["control_prepared"]["files"],
                                          self.r3c["control_prepared"]["dirs"])
            cl["seed_digest"] = self.digest(root)
            cl["status"] = "IN_PROGRESS"
            self.save("CASE_SEEDED")
        root = Path(cl["root"])
        ok = all(s["evaluation"]["pass"] for s in cl["steps"])
        i = len(cl["steps"])
        while ok and i < len(case["steps"]):
            step = case["steps"][i]
            run_root, adapter_dir = root, self.r3_dir
            if step.get("root") == "RELOCATED":
                if not cl.get("relocated_root"):
                    rr = self.reloc_root(cid, cl["gen"], int(cl.get("relocation_n") or 0))
                    L.guard_case_root(rr, self.shadow, Path(self.lay.control_root))
                    self.led["partial"] = {"stage": "RELOCATE", "case": cid, "gen": cl["gen"], "step": i, "run_root": str(rr),
                                           "child": None}
                    self.save("RELOCATE_INTENT")
                    shutil.copytree(root, rr)
                    cl["relocated_root"] = str(rr)
                    cl["relocated_digest"] = self.digest(rr)
                    self.led["partial"] = None
                    self.save("RELOCATED")
                run_root = Path(cl["relocated_root"])
            if step.get("adapter") == "VARIANT":
                adapter_dir = self.ensure_variant()
            r = self.run_step(case, i, step, run_root, adapter_dir)
            ok = r["evaluation"]["pass"]
            i += 1
        out = {"id": cid, "covers": case["covers"], "reference": case.get("reference"), "steps": cl["steps"],
               "gen": cl["gen"], "seed": cl.get("seed"), "relocated_root": cl.get("relocated_root")}
        ref = case.get("reference")
        if ok and ref:
            if ref not in self.led["refs"]:
                ok = False
                out["comparison"] = {"equal": False, "diffs": ["REFERENCE_UNAVAILABLE"]}
            else:
                out["comparison"] = L.compare_states(self.led["refs"][ref], L.state_digest(root, self.c["checkpoint_volatile_keys"]))
                ok = ok and out["comparison"]["equal"]
        if ok and cid in ("REF_E3", "REF_E23"):
            sd = L.state_digest(root, self.c["checkpoint_volatile_keys"])
            self.led["refs"][cid] = sd
            out["reference_digest"] = {"sessions_digest": sd["sessions_digest"], "checkpoint_digest": sd["checkpoint"]["digest"],
                                       "sessions": len(sd["sessions"])}
        if ok and cid == "REF_E23":
            self.led["growth"] = L.growth(root, len(self.o2d))
        out["result"] = "PASS" if ok else "FAIL"
        cl["roots_final"] = {str(root): self.digest(root)}
        if cl.get("relocated_root"):
            cl["roots_final"][cl["relocated_root"]] = self.digest(cl["relocated_root"])
        cl["out"] = out
        cl["status"] = "DONE"
        self.save("CASE_DONE")
        return out

    # ------------------------------------------------------------------ ledger: criação e reconciliação na retomada
    def ledger_init(self, b: dict) -> None:
        self.led = {"schema": self.L.LEDGER_SCHEMA, "logical_attempt": self.logical, "harness_version": self.c["harness_version"],
                    "harness_revision": self.c["harness_revision"], "bindings": b,
                    "sessions": [{"session": self.session, "owner": self.owner(),
                                  "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "kind": "INITIAL"}],
                    "cases": {}, "case_gen": {}, "abandoned": [], "refs": {}, "growth": None, "variant": None,
                    "variant_gen": 0, "partial": None, "final": None, "seq": 0, "ledger_sha256": None}
        self.save("LEDGER_INIT")

    def abandon(self, cid: str, reason: str) -> None:
        cl = self.led["cases"].pop(cid)
        self.led["abandoned"].append({"case": cid, "gen": cl["gen"], "root": cl.get("root"), "relocated_root": cl.get("relocated_root"),
                                      "steps_durable": len(cl.get("steps") or []), "reason": reason,
                                      "note": "raiz preservada (nada é removido); o caso recomeça numa geração nova"})
        self.led["case_gen"][cid] = int(cl["gen"]) + 1
        self.log(f"RESUME_CASE_ABANDONED case={cid} gen={cl['gen']} reason={reason} next_gen={cl['gen'] + 1}")

    def reconcile_resume(self, b: dict) -> None:
        L = self.L
        self.phase = "RESUME_RECONCILE"
        self.status()
        led = L.ledger_verify(self.ledger_p, self.journal_p)
        if led.get("logical_attempt") != self.logical:
            raise L.HarnessBlocked("RESUME_LOGICAL_ATTEMPT_MISMATCH")
        for k, v in b.items():
            if led["bindings"].get(k) != v:
                raise L.HarnessBlocked("RESUME_BINDING_MISMATCH", k)
        if (led.get("final") or {}).get("complete"):
            raise L.HarnessBlocked("RESUME_ATTEMPT_ALREADY_FINAL", str(led["final"].get("exit_code")))
        resume_state = L.attempt_lifecycle_state(led)
        if resume_state != "CONTINUABLE_INTERRUPTED":
            failed = L.durable_failed_cases(led)
            raise L.HarnessBlocked("RESUME_STATE_NOT_CONTINUABLE", resume_state + ((" failed=" + ",".join(failed)) if failed else ""))
        # nenhum processo de sessão anterior vivo: dono, descendentes (Windows: PPID persiste), marca de sessão (POSIX)
        for sess in led["sessions"]:
            o = sess.get("owner") or {}
            if o.get("pid") and L.alive(int(o["pid"]), o.get("ctime")):
                raise L.HarnessBlocked("RESUME_PREVIOUS_ORCHESTRATOR_ALIVE", str(o["pid"]))
            live = (L.descendants(int(o["pid"]), o.get("ctime")) if o.get("pid") and o.get("ctime") is not None else []) \
                + L.session_processes(sess["session"], exclude_pid=os.getpid())
            if live:
                raise L.HarnessBlocked("RESUME_PREVIOUS_SESSION_PROCESS_ALIVE", repr(sorted({x[0] for x in live})))
        part = led.get("partial")
        ch = (part or {}).get("child")
        if ch and (L.alive(int(ch["pid"]), ch.get("ctime")) or L.descendants(int(ch["pid"]), ch.get("ctime"))):
            raise L.HarnessBlocked("RESUME_PARTIAL_CHILD_ALIVE_RECONCILIATION_REQUIRED", str(ch["pid"]))
        if L.WIN:  # nenhuma invocação viva segura o mutex global do adaptador (G01 do R3)
            plat = self.S.WindowsPlatform()
            try:
                h = plat.acquire_named_mutex(self.S.adapter_mutex_name(self.lay.release_root))
            except Exception as e:  # noqa: BLE001
                raise L.HarnessBlocked("RESUME_R3_ADAPTER_MUTEX_HELD", getattr(e, "code", type(e).__name__)) from e
            plat.release_named_mutex(h)
        src_seq, src_sha = led.get("seq"), led.get("ledger_sha256")
        src_session = led["sessions"][-1]["session"] if led.get("sessions") else None
        # R1-01: histórico imutável das sessões anteriores revalidado; a última sessão anterior recebe sua entrada
        hist_entry = self.session_history_check(led, src_seq, src_sha)
        # revalidação física de TODO o trabalho durável (R1-02: exit nativo 0 + receipt 0 + companion 0 + hashes)
        self.revalidate_durable_steps(led, "RESUME")
        for cid, cl in led["cases"].items():
            if cl["status"] == "DONE":
                for path, dg in (cl.get("roots_final") or {}).items():
                    if self.digest(path) != dg:
                        raise L.HarnessBlocked("RESUME_DURABLE_BYTES_CHANGED", cid)
        for rid, rd in led["refs"].items():
            if L.state_digest(led["cases"][rid]["root"], self.c["checkpoint_volatile_keys"]) != rd:
                raise L.HarnessBlocked("RESUME_REFERENCE_CHANGED", rid)
        var = led.get("variant")
        if var and var.get("status") == "DONE":
            v = L.verify_manifest_dir(Path(var["dir"]), "MANIFEST_SHA256.txt", "ADAPTER_IDENTITY.json")
            if v["manifest_sha256"] != var["identity_sha256"]:
                raise L.HarnessBlocked("RESUME_VARIANT_CHANGED")
        open_cases = [cid for cid, cl in led["cases"].items() if cl["status"] != "DONE"]
        if len(open_cases) > 1:
            raise L.HarnessBlocked("RESUME_MULTIPLE_OPEN_CASES", ",".join(open_cases))
        if part:
            cl = led["cases"].get(part.get("case"))
            exp_roots = set()
            if cl is not None:
                exp_roots = {cl.get("root")} | ({cl["relocated_root"]} if cl.get("relocated_root") else set())
            if (cl is None or cl["status"] == "DONE" or part.get("gen") != cl.get("gen")
                    or part.get("step") != len(cl.get("steps") or [])
                    or (part.get("stage") == "STEP" and part.get("run_root") not in exp_roots)):
                raise L.HarnessBlocked("RESUME_PARTIAL_INCONSISTENT", str(part.get("case")))
        # a partir daqui a retomada MUTA a evidência/ledger: fronteira efetiva (falhas => não provado + recheck)
        repair = led.pop("_journal_repair", None)
        self.led = led
        self.shadow_frontier = True
        actions = []
        if repair:  # B-1: o diário é completado (append-only) ANTES de qualquer nova gravação do ledger
            line = L.ledger_repair_journal(self.journal_p, dict(led, _journal_repair=repair))
            actions.append(f"JOURNAL_REPAIR:seq={line['seq']}")
            self.log(f"RESUME_JOURNAL_REPAIRED seq={line['seq']} fragment={'YES' if repair.get('fragment_sha256') else 'NO'}")
        # R1-01: ANTES de qualquer mutação (final, parcial, casos): histórico da sessão anterior + esta sessão
        # registrados num único write atômico do ledger (a identidade transacional lógica é reutilizada)
        if hist_entry is not None:
            self.led.setdefault("session_history", []).append(hist_entry)
        self.led["sessions"].append({"session": self.session, "owner": self.owner(), "kind": "RESUME",
                                     "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "reconcile": None})
        self.save("SESSION_HISTORY")
        if var and var.get("status") != "DONE":
            self.led["variant"] = None  # construção interrompida: a próxima usa a geração seguinte (diretório preservado)
            actions.append(f"VARIANT_V{var.get('gen')}:REBUILD_NEXT_GEN")
        for cid in open_cases:
            cl = led["cases"][cid]
            if cl["status"] == "SEEDING":
                self.abandon(cid, "SEEDING_INTERRUPTED")
                actions.append(f"{cid}:ABANDON_SEEDING")
                continue
            last = cl["steps"][-1] if cl["steps"] else None
            if part and part.get("stage") == "RELOCATE":
                # cópia só LÊ a raiz do caso: se ela está na fronteira durável, a relocação é refeita num caminho novo
                if self.digest(cl["root"]) != (last["root_digest_after_orch"] if last else cl["seed_digest"]):
                    raise L.HarnessBlocked("RESUME_ROOT_DRIFT", cid)
                cl["relocation_n"] = int(cl.get("relocation_n") or 0) + 1
                actions.append(f"{cid}:RELOCATE_RETRY_N{cl['relocation_n']}")
                continue
            if part and part.get("stage") == "STEP":
                cur = self.digest(part["run_root"])
                sdir = Path(part["step_dir"])
                v = L.verify_receipt_with_companion(sdir / "STEP_RECEIPT.json", L.STEP_RECEIPT_SCHEMA,
                                                    part["invocation_attempt_id"], exit_code=0)
                case = next(x for x in self.c["cases"] if x["id"] == cid)
                adoptable = (v["valid"] and not part.get("action") and part.get("child") and not part.get("observed")
                             and (part.get("exited") or {}).get("native_exit") == 0
                             and v["doc"].get("root_digest_after") == cur)
                if adoptable:
                    # R1-02: o exit NATIVO observado pelo pai (STEP_EXITED durável) é a autoridade; nunca inferido do receipt
                    res = {"case": cid, "case_gen": cl["gen"], "step": part["step"], "invocation_attempt_id": part["invocation_attempt_id"],
                           "action": None, "step_dir": part["step_dir"], "run_root": part["run_root"],
                           "native_exit": part["exited"]["native_exit"], "child": dict(part["child"]),
                           "receipt": {k: v.get(k) for k in ("valid", "reason", "sha256")},
                           "adoption": {"source_session": part.get("session") or src_session, "source_partial_seq": src_seq,
                                        "source_partial_ledger_sha256": src_sha, "source_child": dict(part["child"]),
                                        "source_native_exit": part["exited"]["native_exit"],
                                        "receipt_sha256": v["sha256"], "companion_sha256": v["companion_sha256"],
                                        "receipt_exit_code": v["doc"].get("exit_code")}}
                    self.led.setdefault("adopted", []).append({"case": cid, "gen": cl["gen"], "step": part["step"],
                                                               "invocation_attempt_id": part["invocation_attempt_id"],
                                                               "session": self.session})
                    self.commit_step(case, part["step"], case["steps"][part["step"]], res, v["doc"], Path(part["run_root"]),
                                     None, adopted=True)
                    actions.append(f"{cid}#{part['step']}:ADOPT")
                elif cur == part["root_digest_before"]:
                    self.led["partial"] = None
                    actions.append(f"{cid}#{part['step']}:RETRY_NO_EFFECT")
                else:
                    self.abandon(cid, "PARTIAL_STEP_WITH_UNPROVEN_EFFECT" + (":OBSERVED" if part.get("observed") else ""))
                    actions.append(f"{cid}:ABANDON_PARTIAL_STEP")
                continue
            # caso aberto sem parcial: a raiz (e a cópia relocada ainda não usada) precisa estar na fronteira durável
            path = last["run_root"] if last else cl["root"]
            want = last["root_digest_after_orch"] if last else cl["seed_digest"]
            if self.digest(path) != want:
                raise L.HarnessBlocked("RESUME_ROOT_DRIFT", cid)
            rr = cl.get("relocated_root")
            if rr and not any(s_.get("run_root") == rr for s_ in cl["steps"]) and self.digest(rr) != cl.get("relocated_digest"):
                raise L.HarnessBlocked("RESUME_ROOT_DRIFT", cid + ":RELOCATED")
            actions.append(f"{cid}:CONTINUE_AT_STEP_{len(cl['steps'])}")
        self.led["partial"] = None
        self.led["final"] = None
        self.led["sessions"][-1]["reconcile"] = actions
        self.led.setdefault("resume_history", []).append({"session": self.session, "actions": actions})
        self.save("RESUME_RECONCILED")
        self.rec["resume_reconcile"] = actions
        self.log(f"RESUME_RECONCILED logical={self.logical} durable_units={self.units_done()} actions={';'.join(actions) or 'NONE'}")

    # ------------------------------------------------------------------ R1-01: histórico de sessões (state-transfer)
    def _session_dir(self, sid: str) -> Path:
        return self.sess_dir.parent.parent / sid / "HARNESS"

    def _entry_sha(self, e: dict) -> str:
        return self.L.sha_bytes(json.dumps({k: v for k, v in e.items() if k != "entry_sha256"}, sort_keys=True,
                                           ensure_ascii=True, separators=(",", ":")).encode("ascii"))

    def session_entry_verify(self, h: dict, prev_sha) -> None:
        """Revalida fisicamente uma entrada do histórico: auto-hash, encadeamento, receipt+companion+status."""
        L = self.L
        sid = h.get("session")
        if h.get("entry_sha256") != self._entry_sha(h) or h.get("prev_entry_sha256") != prev_sha:
            raise L.HarnessBlocked("SESSION_HISTORY_TAMPERED", f"{sid}:ENTRY_HASH")
        if h.get("closure") == "RECEIPT":
            v = L.verify_receipt_with_companion(Path(h["receipt_path"]), L.HARNESS_RECEIPT_SCHEMA, sid, exit_code=h.get("exit_code"))
            if not v["valid"] or v["sha256"] != h.get("receipt_sha256") or v["companion_sha256"] != h.get("companion_sha256"):
                raise L.HarnessBlocked("SESSION_HISTORY_TAMPERED", f"{sid}:RECEIPT:{v['reason']}")
        elif h.get("closure") != "NO_RECEIPT_CRASH_GAP":
            raise L.HarnessBlocked("SESSION_HISTORY_TAMPERED", f"{sid}:CLOSURE")
        sp = Path(h["status_file_path"])
        got = L.sha_file(sp) if sp.is_file() else None
        if got != h.get("status_file_sha256"):
            raise L.HarnessBlocked("SESSION_HISTORY_TAMPERED", f"{sid}:STATUS")

    def session_history_verify(self, led: dict) -> list:
        prev = None
        hist = led.get("session_history") or []
        for h in hist:
            self.session_entry_verify(h, prev)
            prev = h["entry_sha256"]
        return hist

    def session_history_check(self, led: dict, src_seq, src_sha):
        """R1-01 (na retomada, antes da fronteira): histórico existente íntegro e completo; constrói a entrada da
        última sessão anterior a partir dos bytes físicos (receipt+companion+status) — ou registra a lacuna de
        queda sem receipt. Receipt terminal anterior => certificado alternativo proibido (BLOCKED)."""
        L = self.L
        hist = self.session_history_verify(led)
        prior = [x["session"] for x in led["sessions"]]
        recorded = [h["session"] for h in hist]
        if recorded != prior[:-1]:
            raise L.HarnessBlocked("SESSION_HISTORY_INCOMPLETE", f"recorded={len(recorded)} sessions={len(prior)}")
        sid = prior[-1]
        sdir = self._session_dir(sid)
        rp, sp = sdir / "QS4_HARNESS_RECEIPT.json", sdir / "HARNESS_STATUS.json"
        fin = led.get("final") or {}
        fin_here = fin.get("session") == sid
        e = {"session": sid, "receipt_path": str(rp), "companion_path": str(L.companion_path(rp)),
             "status_file_path": str(sp), "ledger_seq": src_seq, "ledger_sha256": src_sha,
             "final_state": {k: fin.get(k) for k in ("complete", "receipt_pending", "matrix_complete", "provisional_exit_code",
                                                     "exit_code", "resumable")} if fin_here else None}
        if rp.is_file() or L.companion_path(rp).is_file():
            v = L.verify_receipt_with_companion(rp, L.HARNESS_RECEIPT_SCHEMA, sid)
            if not v["valid"]:
                raise L.HarnessBlocked("RESUME_PREVIOUS_RECEIPT_INVALID", f"{sid}:{v['reason']}")
            d = v["doc"]
            if d.get("logical_attempt") != self.logical:
                raise L.HarnessBlocked("RESUME_PREVIOUS_RECEIPT_INVALID", f"{sid}:LOGICAL_ATTEMPT")
            if d.get("terminal") is not False:
                raise L.HarnessBlocked("RESUME_TERMINAL_RECEIPT_EXISTS", f"{sid} exit={d.get('exit_code')}")
            if fin_here and fin.get("receipt_sha256") not in (None, v["sha256"]):
                raise L.HarnessBlocked("RESUME_PREVIOUS_RECEIPT_INVALID", f"{sid}:LEDGER_RECEIPT_SHA")
            st_final = d.get("status_final_sha256")
            st_phys = L.sha_file(sp) if sp.is_file() else None
            if st_final is not None and st_phys != st_final:
                raise L.HarnessBlocked("RESUME_PREVIOUS_STATUS_MISMATCH", sid)
            if fin_here and fin.get("status_file_sha256_at_close", st_phys) != st_phys:
                raise L.HarnessBlocked("RESUME_PREVIOUS_STATUS_MISMATCH", f"{sid}:AT_CLOSE")
            e.update(closure="RECEIPT", exit_code=d.get("exit_code"), result=d.get("result"),
                     blocked_reason=d.get("blocked_reason"), receipt_sha256=v["sha256"], companion_sha256=v["companion_sha256"],
                     status_final_sha256=st_final, status_file_sha256=st_phys,
                     status_write_failures=d.get("status_write_failures"),
                     reason_for_resume=f"PREVIOUS_SESSION_NOT_PASS exit={d.get('exit_code')} reason={d.get('blocked_reason')}")
        else:
            lp = sdir / "HARNESS.log"
            logged = lp.is_file() and any(ln.startswith("QS4_HARNESS_RECEIPT=") for ln in
                                          lp.read_text(encoding="utf-8", errors="replace").splitlines())
            if (fin_here and fin.get("receipt_sha256")) or logged or (sdir / "HARNESS_PROGRESS.json").is_file():
                raise L.HarnessBlocked("RESUME_PREVIOUS_RECEIPT_MISSING", sid)
            e.update(closure="NO_RECEIPT_CRASH_GAP", exit_code=None, result=None, blocked_reason=None,
                     receipt_sha256=None, companion_sha256=None, status_final_sha256=None,
                     status_file_sha256=L.sha_file(sp) if sp.is_file() else None, status_write_failures=None,
                     reason_for_resume="PREVIOUS_SESSION_ENDED_WITHOUT_RECEIPT_CRASH_GAP")
        e["prev_entry_sha256"] = hist[-1]["entry_sha256"] if hist else None
        e["entry_sha256"] = self._entry_sha(e)
        self.log(f"SESSION_HISTORY_ENTRY session={sid} closure={e['closure']} exit={e['exit_code']} "
                 f"receipt_sha256={e['receipt_sha256']} entry_sha256={e['entry_sha256']}")
        return e

    def revalidate_durable_steps(self, led: dict, where: str) -> None:
        """R1-02: todo passo durável com receipt exige exit nativo 0 (inteiro) + receipt exit 0 + companion exit 0 +
        hashes iguais; passo adotado exige a prova pai-observada completa. P10: sem receipt, exit nativo registrado."""
        L = self.L
        for cid, cl in led["cases"].items():
            for s_ in cl.get("steps") or []:
                tag = f"{cid}#{s_.get('step')}"
                rc = s_.get("receipt") or {}
                if rc.get("reason") == "TERMINATED_BY_P10_NO_CHILD_RECEIPT":
                    if s_.get("action") != "TERMINATE" or type(s_.get("native_exit")) is not int:
                        raise L.HarnessBlocked(f"{where}_DURABLE_STEP_PROOF", tag + ":P10")
                    continue
                if s_.get("native_exit") != 0 or type(s_.get("native_exit")) is not int:
                    raise L.HarnessBlocked(f"{where}_DURABLE_STEP_PROOF", tag + ":NATIVE_EXIT")
                v = L.verify_receipt_with_companion(Path(s_["step_dir"]) / "STEP_RECEIPT.json", L.STEP_RECEIPT_SCHEMA,
                                                    s_["invocation_attempt_id"], exit_code=0)
                if not v["valid"] or v["sha256"] != rc.get("sha256"):
                    raise L.HarnessBlocked(f"{where}_DURABLE_RECEIPT_CHANGED", tag + ":" + v["reason"])
                ch = s_.get("child") or {}
                if type(ch.get("pid")) is not int:
                    raise L.HarnessBlocked(f"{where}_DURABLE_STEP_PROOF", tag + ":CHILD")
                if s_.get("adopted_on_resume"):
                    a = s_.get("adoption") or {}
                    if (a.get("source_native_exit") != 0 or a.get("receipt_sha256") != v["sha256"]
                            or a.get("companion_sha256") != v["companion_sha256"] or a.get("receipt_exit_code") != 0
                            or type(a.get("source_partial_seq")) is not int or not a.get("source_partial_ledger_sha256")
                            or a.get("source_child") != ch):
                        raise L.HarnessBlocked(f"{where}_DURABLE_STEP_PROOF", tag + ":ADOPTION")

    # ------------------------------------------------------------------ itens
    def items(self) -> dict:
        cases = {c["id"]: c for c in self.rec["cases"]}

        def passed(*ids):
            return all(cases.get(i, {}).get("result") == "PASS" for i in ids)
        steps = [s for c in self.rec["cases"] for s in c["steps"]]
        # T17: validadores congelados somente leitura sobre a raiz IN_PROGRESS, em todo passo dos casos que cobrem T17
        t17 = [s for c in self.rec["cases"] if "T17" in c["covers"] for s in c["steps"] if s.get("state_after") == "IN_PROGRESS"]
        p7 = [c for i, c in cases.items() if i.startswith("T18_P7_")]
        t31b_seen = sum(1 for c in p7 for s in c["steps"] if ((s.get("t31b") or {}).get("journal_before_g21") or 0) > 0) >= 7
        ref_e3 = cases.get("REF_E3", {}).get("steps", [{}])
        t18 = [c["id"] for c in self.rec["cases"] if "T18" in c["covers"]]
        it = {
            "T16": passed("T16_K1", "T16_K2", "T16_K21", "T16_K22"),
            "T17": len(t17) >= 10 and all((s.get("t17") or {}).get("validate_in_progress") == "PASS" for s in t17)
                   and passed(*[c["id"] for c in self.rec["cases"] if "T17" in c["covers"]]),
            "T18": passed(*t18) and len(t18) == 16,
            "T22": passed("T22_ADAPTER_IDENTITY"),
            "T29": passed("T29_RELOCATION"),
            "T30": bool(steps) and all(not s.get("t30_foreign") for s in steps),
            "T31b": passed(*[c["id"] for c in p7]) and len(p7) == 8 and t31b_seen,
            "T33": passed("REF_E3", "T33_TRACE_GUARD_NEG") and bool(ref_e3) and ref_e3[0].get("trace_guard") == "PASS_COMPARED",
            "GROWTH_G16": passed("REF_E23") and bool((self.led or {}).get("growth", {}) and self.led["growth"].get("max_session_bytes")),
        }
        return {k: ("PASS" if v else "FAIL") for k, v in it.items()}

    # ------------------------------------------------------------------ main
    def admit_prior_retirement(self) -> None:
        """New attempts require a physical retirement context; direct calls cannot bypass it."""
        if self.resume:
            return
        import qs4_attempt_lifecycle_v002 as LV
        import qs4_failure_collection_v002 as F
        ctx = self.retirement_context
        required = {"receipt_path", "receipt_sha256", "evidence_root", "attempt_id"}
        if not ctx or set(ctx) != required:
            raise self.L.HarnessBlocked("NEW_ATTEMPT_RETIREMENT_CONTEXT_REQUIRED")
        path = Path(ctx["receipt_path"])
        if not path.is_absolute() or not Path(ctx["evidence_root"]).is_absolute():
            raise self.L.HarnessBlocked("RETIREMENT_PATH_NOT_ABSOLUTE")
        if path.is_symlink() or (hasattr(path, "is_junction") and path.is_junction()):
            raise self.L.HarnessBlocked("RETIREMENT_RECEIPT_REPARSE")
        raw = path.read_bytes()
        if LV.sha256_bytes(raw) != ctx["receipt_sha256"]:
            raise self.L.HarnessBlocked("RETIREMENT_FILE_SHA_MISMATCH")
        receipt = LV.strict_json(raw)
        try:
            LV.admit_new_attempt(retirement_receipt=receipt, expected_attempt_id=ctx["attempt_id"],
                evidence_root=ctx["evidence_root"], expected_receipt_sha256=ctx["receipt_sha256"])
            census = F.bounded_census(receipt["owned_process_identities"], self.L)
            if census["state"] != "PASS_CLEAN" or not census["complete"]:
                raise LV.LifecycleBlocked("CURRENT_OWNED_CENSUS_NOT_CLEAN")
        except LV.LifecycleBlocked as exc:
            raise self.L.HarnessBlocked(exc.code, exc.detail) from exc
        self.rec["prior_retirement"] = {"attempt_id":ctx["attempt_id"], "receipt_sha256":ctx["receipt_sha256"],
                                        "historical_residue_role":"PRESERVED_EVIDENCE", "current_census":census}

    def run(self) -> int:
        L = self.L
        self.sess_dir.mkdir(parents=True, exist_ok=False)
        code = EXIT_BLOCKED
        try:
            self.log(f"QS4_HARNESS=PHASE_B_QS4_HARNESS_V001 revision={self.c['harness_revision']} session={self.session} "
                     f"logical={self.logical} resume={'YES' if self.resume else 'NO'}")
            self.log("PHASE_C_EXECUTION=NO RESELECTION_2026=FORBIDDEN RUN_RELEASED=NO DD7=QUARANTINE_SHA_SIZE_ONLY")
            self.log(f"MULTIWORK={self.c['multiwork']['value']} REASON={self.c['multiwork']['reason']}")
            self.log("T18_SEMANTICS=" + self.c["t18_semantics"]["statement"])
            if self.resume and not self.ledger_p.is_file():
                raise L.HarnessBlocked("RESUME_LEDGER_MISSING", str(self.ledger_p))
            if not self.resume and (self.shadow.exists() or self.ledger_p.exists()):
                raise L.HarnessBlocked("ATTEMPT_ALREADY_EXISTS", self.logical)
            if self.resume:  # somente exibição de progresso durante as pré-condições; a reconciliação reverifica tudo
                try:
                    self.led = L.ledger_verify(self.ledger_p, self.journal_p)
                except L.HarnessBlocked:
                    self.led = None
            self.admit_prior_retirement()
            self.preconditions()
            self.led = None if self.resume else self.led
            b = self.bindings()
            if self.resume:
                self.reconcile_resume(b)
                self.shadow_frontier = True
            else:
                self.phase = "SHADOW_FRONTIER"
                self.shadow.mkdir(parents=True, exist_ok=False)
                self.shadow_frontier = True
                self.ledger_init(b)
            self.session_t0 = time.monotonic()  # RATE/ETA só pelas unidades da matriz (sem as pré-condições)
            self.log(f"EFFECTFUL_FRONTIER=QS4_SHADOW_OWNED root={self.shadow} durable_units={self.units_done()}")
            self.log("PROGRESS_BAR=" + L.progress_view(self.units_done(), self.steps_total)["BAR"])
            for case in self.c["cases"]:
                r = self.run_case(case)
                self.log(f"CASE {case['id']}={r['result']}")
                self.check_protected("after_case_" + case["id"])
                if case["id"] in ("REF_E3", "REF_E23") and r["result"] != "PASS":
                    raise L.HarnessBlocked("REFERENCE_CASE_FAILED", case["id"])
            self.rec["cases"] = [self.led["cases"][x["id"]]["out"] for x in self.c["cases"]]
            self.rec["growth"] = self.led.get("growth")
            self.rec["items"] = self.items()
            self.session_history_verify(self.led)          # R1-01: PASS só com state-transfer íntegro
            self.revalidate_durable_steps(self.led, "FINAL")  # R1-02: prova nativa de todo passo durável
            self.check_protected("final")
            self.rec["protected_after"] = self.protected()
            self.led["final"] = {"complete": True, "session": self.session}
            code = EXIT_PASS if all(v == "PASS" for v in self.rec["items"].values()) else EXIT_BLOCKED
        except Unproven as e:
            self.unproven = True
            self.blocked_reason = f"{e.code} {e.detail}"
            code = EXIT_UNPROVEN
        except L.HarnessBlocked as e:
            self.blocked_reason = f"{e.code} {e.detail}"
            code = EXIT_BLOCKED
        except KeyboardInterrupt:
            self.blocked_reason = "ORCHESTRATOR_INTERRUPTED"
            code = EXIT_UNPROVEN if (self.active_child is not None or self.shadow_frontier) else EXIT_BLOCKED
            self.unproven = self.unproven or code == EXIT_UNPROVEN
        except Exception as e:  # noqa: BLE001
            self.blocked_reason = f"{type(e).__name__} {str(e)[:500]}"
            self.rec["traceback_tail"] = traceback.format_exc()[-4000:]
            code = EXIT_UNPROVEN if self.shadow_frontier else EXIT_BLOCKED
        return self.finish(code)

    def finish(self, code: int) -> int:
        # Preserve the first error through finalization and same-run best-effort collection.
        import qs4_failure_collection_v002 as F
        initial_error = self.blocked_reason
        try:
            code = self._finish(code)
        except Exception as exc:
            self.blocked_reason = self.blocked_reason or (type(exc).__name__ + " " + str(exc))
            code = EXIT_UNPROVEN
        if code != EXIT_PASS:
            primary = initial_error or self.blocked_reason or "QS4_DURABLE_VERDICT_NOT_PASS"
            identities = list(self.owned_children)
            for sess in (self.led or {}).get("sessions", []):
                ident = sess.get("owner") or {}
                if ident.get("pid") != os.getpid():
                    identities.append(ident)
            ch = ((self.led or {}).get("partial") or {}).get("child")
            if ch and ch not in identities:
                identities.append(ch)
            roots = {"SESSION": self.sess_dir}
            if self.evidence != self.sess_dir:
                roots["LOGICAL_ATTEMPT"] = self.evidence
            try:
                result = F.collect_failure_bundle(output_dir=self.sess_dir.parent / "SAME_RUN_FAILURE_V002",
                    primary_error=primary, stage=self.phase, native_exit=code,
                    protected_effects_committed=["QS4_SHADOW_OWNED"] if self.shadow_frontier else [],
                    identities=identities, source_roots=roots, process_api=self.L)
                self.log("SAME_RUN_FAILURE_ZIP=" + result["zip_path"] + " SHA256=" + result["zip_sha256"])
            except Exception as exc:
                # An unavailable evidence filesystem is never concealed as a complete bundle.
                message = "SAME_RUN_FAILURE_COLLECTION=BLOCKED primary=" + primary + " collection=" + str(exc)
                try:
                    self.log(message)
                except Exception:
                    sys.stderr.write(message + "\n")
        return code

    def _finish(self, code: int) -> int:
        L = self.L
        # filho ainda vivo (ex.: TerminateProcess falhou) => estado não provado
        if self.active_child is not None and self.active_child.poll() is None:
            self.unproven = True
            self.log(f"CHILD_STILL_ACTIVE pid={self.active_child.pid} auto_kill=NO RECONCILIATION_REQUIRED=YES")
        # depois da fronteira do shadow, os protegidos são SEMPRE recalculados no fim (qualquer caminho de saída)
        if self.shadow_frontier and hasattr(self, "protected_before"):
            try:
                self.check_protected("finish")
            except Unproven as e:
                self.unproven = True
                self.blocked_reason = (self.blocked_reason + " | " if self.blocked_reason else "") + f"{e.code} {e.detail}"
            except Exception as e:  # noqa: BLE001
                self.unproven = True
                self.blocked_reason = (self.blocked_reason + " | " if self.blocked_reason else "") + "PROTECTED_RECHECK_FAILED " + type(e).__name__
        if self.unproven and code != EXIT_UNPROVEN:
            code = EXIT_UNPROVEN
        if not self.rec["cases"] and self.led is not None:  # saída antecipada: casos duráveis já concluídos
            self.rec["cases"] = [cl["out"] for cl in self.led["cases"].values() if cl.get("status") == "DONE"]
        if self.status_failures and code == EXIT_PASS:
            code = EXIT_BLOCKED
        # ledger: FINAL_PENDING (retomável) ANTES do receipt; selado como completo só DEPOIS do receipt relido (M-4)
        all_done = bool((self.led or {}).get("final") or {}) and bool(self.led["final"].get("complete"))
        ledger_ok = self.led is not None and self.shadow_frontier
        if ledger_ok:
            self.led["final"] = {"complete": False, "receipt_pending": True, "matrix_complete": all_done,
                                 "session": self.session, "provisional_exit_code": code, "reason": self.blocked_reason}
            try:
                self.save("FINAL_PENDING")
            except Unproven as e:
                ledger_ok = False
                self.unproven = True
                code = EXIT_UNPROVEN
                self.blocked_reason = (self.blocked_reason + " | " if self.blocked_reason else "") + f"{e.code} {e.detail}"
        self.stop_heartbeat()
        # B08: status obrigatório — falhas anteriores e status final ACTIVE=NO persistido ANTES do receipt
        self.phase = "FINISHED"
        final_ok = self.status(active="NO", extra={"exit_code": code})
        if not final_ok and code == EXIT_PASS:
            code = EXIT_BLOCKED
        units = self.units_done()
        self.rec.update(exit_code=code, blocked_reason=self.blocked_reason, unproven=self.unproven,
                        status_write_failures=self.status_failures, status_final_persisted=final_ok,
                        status_final_sha256=getattr(self, "last_status_sha", None) if final_ok else None,
                        result="PASS" if code == EXIT_PASS else "NOT_PASS", auto_kill="NO",
                        phase_c_execution="NO", run_released="NO", shadow_root=str(self.shadow),
                        durable_units=units, total_units=self.steps_total,
                        ledger_sha256=(self.led or {}).get("ledger_sha256"),
                        ledger_seq=(self.led or {}).get("seq"),
                        sessions=[s["session"] for s in (self.led or {}).get("sessions", [])],
                        abandoned=(self.led or {}).get("abandoned", []), adopted=(self.led or {}).get("adopted", []),
                        resume_history=(self.led or {}).get("resume_history", []))
        var = (self.led or {}).get("variant") or {}
        self.rec["t22_variant_identity_sha256"] = var.get("identity_sha256") if var.get("status") == "DONE" else None
        # R1-01: o receipt binda o histórico de sessões; STOP closure: exatamente um certificado TERMINAL por attempt
        hist = (self.led or {}).get("session_history") or []
        self.rec["session_history"] = hist
        self.rec["session_history_head_sha256"] = hist[-1]["entry_sha256"] if hist else None
        verdict_only = (code == EXIT_BLOCKED and self.blocked_reason is None and not self.unproven
                        and self.status_failures == 0 and final_ok)
        terminal = bool(ledger_ok and all_done and (code == EXIT_PASS or verdict_only))
        durable_failed = L.durable_failed_cases(self.led) if self.led is not None else []
        if terminal:
            attempt_state = "TERMINAL_PASS" if code == EXIT_PASS else "TERMINAL_VERDICT"
        elif durable_failed:
            attempt_state = "FAILED_DURABLE_NONRESUMABLE"
        elif ledger_ok:
            attempt_state = "CONTINUABLE_INTERRUPTED"
        else:
            attempt_state = "ACTIVE"
        self.rec["terminal"] = terminal
        self.rec["attempt_lifecycle_state"] = attempt_state
        self.rec["durable_failed_cases"] = durable_failed
        self.rec["resumable"] = attempt_state == "CONTINUABLE_INTERRUPTED"
        if self.blocked_reason:
            self.log(f"QS4_HARNESS_BLOCKED={self.blocked_reason}")
        receipt_ok = False
        try:
            # R3 verificado => escritor durável do R3; bloqueio antes disso (H00/H02) => escritor só-stdlib do harness
            writer = self.E.write_json_durable if hasattr(self, "E") else L.write_json_exclusive
            self.rec["receipt_writer"] = "R3_write_json_durable" if hasattr(self, "E") else "HARNESS_STDLIB_EXCLUSIVE"
            sha = L.write_receipt_with_companion(self.sess_dir / "QS4_HARNESS_RECEIPT.json", self.rec, writer)
            receipt_ok = True
            self.log(f"QS4_HARNESS_RECEIPT={self.sess_dir / 'QS4_HARNESS_RECEIPT.json'} sha256={sha}")
        except Exception as e:  # noqa: BLE001
            sha = None
            self.log(f"QS4_HARNESS_RECEIPT_WRITE=FAILED {type(e).__name__}")
            if code == EXIT_PASS:
                code = EXIT_BLOCKED
        sealed = False
        if ledger_ok and receipt_ok:
            # attempt COMPLETO (não retomável) só com PASS ou com o veredito dos itens; falha de status (B08) ou não
            # provado após a matriz recusa o PASS desta SESSÃO mas mantém o attempt retomável (nova sessão só reavalia)
            complete = terminal and code in (EXIT_PASS, EXIT_BLOCKED)
            stp = self.sess_dir / "HARNESS_STATUS.json"
            self.led["final"] = {"complete": complete, "matrix_complete": all_done, "receipt_pending": False,
                                 "session": self.session, "exit_code": code, "result": self.rec.get("result"),
                                 "reason": self.blocked_reason, "receipt_path": str(self.sess_dir / "QS4_HARNESS_RECEIPT.json"),
                                 "receipt_sha256": sha, "status_final_sha256": self.rec.get("status_final_sha256"),
                                 "status_file_sha256_at_close": L.sha_file(stp) if stp.is_file() else None,
                                 "status_write_failures": self.status_failures, "terminal": complete,
                                 "session_history_head_sha256": self.rec["session_history_head_sha256"],
                                 "attempt_lifecycle_state": self.rec.get("attempt_lifecycle_state"),
                                 "durable_failed_cases": self.rec.get("durable_failed_cases", []),
                                 "resumable": self.rec.get("attempt_lifecycle_state") == "CONTINUABLE_INTERRUPTED"}
            all_done = complete
            try:
                self.save("FINAL_SEALED")
                sealed = True
            except Unproven as e:
                self.log(f"FINAL_SEALED_NOT_DURABLE {e.code} (ledger permanece FINAL_PENDING)")
                if terminal:
                    # resultado terminal exige STATE persistido e relido: sem selo, o exit nativo diverge do receipt
                    # (o bootstrap o recusa) e a retomada bloqueia (certificado terminal alternativo proibido)
                    code = EXIT_UNPROVEN
                    self.log("TERMINAL_RECEIPT_WITHOUT_SEALED_STATE RECONCILIATION_REQUIRED=YES")
        # progresso final: PCT=100 SOMENTE com receipt final gravado/relido + ledger selado completo + exit 0 + 45/45
        reconciled = receipt_ok and sealed and all_done and code == EXIT_PASS and units == self.steps_total
        pv = L.progress_view(units, self.steps_total, reconciled=reconciled)
        try:
            if receipt_ok:
                p = self.sess_dir / "HARNESS_PROGRESS.json"
                L.write_json_exclusive(p, {"schema": "MINOTAURO_PHASE_B_QS4_HARNESS_PROGRESS_V001", "attempt_id": self.session,
                                           "logical_attempt": self.logical, "progress": pv, "receipt_sha256": sha,
                                           "exit_code": code, "ledger_sha256": (self.led or {}).get("ledger_sha256")})
        except Exception as e:  # noqa: BLE001
            self.log(f"QS4_HARNESS_PROGRESS_WRITE=FAILED {type(e).__name__}")
        self.log("PROGRESS_BAR=" + pv["BAR"] + (" RECONCILED" if reconciled else ""))
        self.log(f"QS4_HARNESS_EXIT={code}")
        return code


def p5probe_target(marker_dir: Path, timeout_s: int) -> int:
    """Alvo do microprobe P5: mesmo modo de criação do filho P5 (console próprio). Encerra-se sozinho (exit 3)."""
    import qs4_lib as L
    info = L.enable_ctrl_c()

    def mark(name, obj):
        tmp = marker_dir / (name + ".tmp")
        tmp.write_text(json.dumps(obj, sort_keys=True), encoding="utf-8")
        tmp.replace(marker_dir / name)
    try:
        mark("READY.json", {"pid": os.getpid(), "ctrl_c_enable": info})
        t0 = time.monotonic()
        while time.monotonic() - t0 < timeout_s:
            time.sleep(0.1)
    except KeyboardInterrupt as e:
        mark("CAUGHT.json", {"args_len": len(e.args), "pid": os.getpid()})
        return 0
    return 3


def main(argv) -> int:
    # antes de QUALQUER import do harness/R3: sem -B e PYTHONDONTWRITEBYTECODE=1 nenhum __pycache__ pode surgir
    if sys.flags.dont_write_bytecode != 1 or os.environ.get("PYTHONDONTWRITEBYTECODE") != "1":
        _print("QS4_HARNESS_BYTECODE", "BLOCKED")
        return EXIT_BLOCKED
    if not argv:
        _print("QS4_HARNESS_ARGV", "BLOCKED")
        return EXIT_BLOCKED
    cmd, rest = argv[0], argv[1:]
    if cmd == "plan" and not rest:
        import qs4_lib as L
        c = L.load_constants(HARNESS_DIR / "qs4_constants.json")
        for case in c["cases"]:
            _print("CASE", f"{case['id']} family={case['family']} steps={len(case['steps'])} covers={','.join(case['covers'])}")
        _print("STEPS_TOTAL", sum(len(x["steps"]) for x in c["cases"]))
        _print("MULTIWORK", c["multiwork"]["value"])
        return EXIT_PASS
    if cmd == "orchestrate":
        a = _args(rest, {"--attempt-id", "--r3-dir", "--qs3-receipt", "--qs3-receipt-sha256"}, {"--resume-from", "--retirement-receipt", "--retirement-receipt-sha256", "--retirement-evidence-root", "--retired-attempt-id"})
        if a is None:
            _print("QS4_HARNESS_ARGV", "BLOCKED")
            return EXIT_BLOCKED
        import qs4_lib as L
        rf = a.get("--resume-from")
        if not L.ATTEMPT_RE.match(a["--attempt-id"]) or (rf is not None and (not L.ATTEMPT_RE.match(rf) or rf == a["--attempt-id"])):
            _print("QS4_HARNESS_ATTEMPT_ID", "BLOCKED")
            return EXIT_BLOCKED
        retirement_keys = {"--retirement-receipt", "--retirement-receipt-sha256", "--retirement-evidence-root", "--retired-attempt-id"}
        if (rf is None and not retirement_keys <= set(a)) or (rf is not None and retirement_keys & set(a)):
            _print("QS4_NEW_ATTEMPT_RETIREMENT", "BLOCKED_CONTEXT_MISSING_OR_RESUME_CONFLICT")
            return EXIT_BLOCKED
        ctx = None if rf is not None else {"receipt_path":a["--retirement-receipt"],
            "receipt_sha256":a["--retirement-receipt-sha256"].upper(), "evidence_root":a["--retirement-evidence-root"],
            "attempt_id":a["--retired-attempt-id"]}
        return Orchestrator(a["--attempt-id"], Path(a["--r3-dir"]), a["--qs3-receipt"], a["--qs3-receipt-sha256"],
                            resume_from=rf, retirement_context=ctx).run()
    if cmd == "invoke":
        a = _args(rest, {"--step-json"})
        if a is None:
            return EXIT_BLOCKED
        import qs4_flow
        return qs4_flow.invoke(Path(a["--step-json"]))
    if cmd == "ctrlc":
        a = _args(rest, {"--pid"})
        if a is None or not a["--pid"].isdigit():
            return EXIT_BLOCKED
        import qs4_lib as L
        if not L.WIN:
            return EXIT_BLOCKED
        return L.ctrl_c_attached(int(a["--pid"]))
    if cmd == "p5probe-target":
        a = _args(rest, {"--marker-dir", "--timeout-s"})
        if a is None or not a["--timeout-s"].isdigit() or not Path(a["--marker-dir"]).is_dir():
            return EXIT_BLOCKED
        return p5probe_target(Path(a["--marker-dir"]), int(a["--timeout-s"]))
    _print("QS4_HARNESS_ARGV", "BLOCKED")
    return EXIT_BLOCKED


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
