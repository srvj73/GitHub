"""PHASE_B_QS4_HARNESS_V001 — uma invocação QS4 (processo-filho próprio; o CODE congelado é importado uma vez).

Fluxo (envelope QS4 §invocation_flow): Session(mode=DRY) do R3 com Layout QS4 → G01–G16 (R3) → G18 (R3) →
G19-QS4 (run binding + prepare_preflight/build_binding congelados NA RAIZ DO CASO) → G20 → SeamSet(RUN) do R3 →
seams QS4 (somente depois do SeamSet) → G21 PRE_RECOVER_B (R3) → run_phase congelado (phase='B') até o seam de
parada → pós-análise (árvore limpa, estado, T17, T30, T31b, digests DD-7). Nunca finalize_phase; nunca CONTROL real.
"""
from __future__ import annotations

import json
import os
import sys
import time
import traceback
from dataclasses import replace
from pathlib import Path

from qs4_lib import (STEP_RECEIPT_SCHEMA, HarnessBlocked, enable_ctrl_c, guard_case_root, load_json_bytes, sha_bytes,
                     write_receipt_with_companion)


def _journal_count(root: Path) -> int:
    j = Path(root) / "PHASE_B" / "_commit_journal"
    return len([p for p in j.iterdir()]) if j.is_dir() else 0


def _committed(root: Path) -> int:
    sd = Path(root) / "PHASE_B" / "sessions"
    return len([p for p in sd.iterdir() if p.is_dir()]) if sd.is_dir() else 0


def _classify_exception(e: BaseException) -> dict:
    """Classe/código/seam. DD-7: o texto livre só é mantido para mensagens geradas pelo harness/R3 (seams, BLOCKED,
    TRACE_GUARD); para exceções do CODE congelado fica só tamanho+SHA (o texto bruto vai para a quarentena)."""
    name = type(e).__name__
    msg = str(e)
    meta = {"detail_len": len(msg), "detail_sha256": sha_bytes(msg.encode("utf-8", "replace"))}
    if isinstance(e, KeyboardInterrupt):
        if msg.startswith("QS4_SEAM "):
            parts = msg.split()
            return {"class": "INTERRUPT_SEAM", "seam": parts[1], "code": parts[2] if len(parts) > 2 else None,
                    "detail": msg[:300], **meta}
        if msg.startswith("SEAM_INTERRUPT_AFTER "):
            return {"class": "INTERRUPT_SEAM", "seam": "SEAM_INTERRUPT_AFTER", "code": msg.split()[1], "detail": msg[:300], **meta}
        return {"class": "INTERRUPT_SIGNAL", "seam": None, "code": None, **meta}
    if name == "TraceGuardMismatch":
        return {"class": "TRACE_GUARD", "seam": None, "code": "TRACE_GUARD_MISMATCH", "detail": msg[:300], **meta}
    if name in ("AdapterBlocked", "HarnessBlocked"):
        return {"class": "BLOCKED", "seam": None, "code": getattr(e, "code", msg.split()[0] if msg else ""), "detail": msg[:600], **meta}
    if name == "ModelError":
        code = msg.split()[0] if msg else ""
        return {"class": "FAULT" if code.startswith("FAULT_") else "FROZEN_ERROR", "seam": None, "code": code, **meta}
    return {"class": "ERROR", "seam": None, "code": name, **meta}


def _quarantine(step_dir: Path, rec: dict, text: str) -> None:
    """DD-7: traceback/mensagem bruta ficam num arquivo de quarentena; o receipt leva só SHA e tamanho."""
    data = text.encode("utf-8", "replace")
    p = step_dir / "STEP_QUARANTINE.txt"
    with open(p, "xb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    rec["quarantine"] = {"file": p.name, "sha256": sha_bytes(data), "bytes": len(data)}


def invoke(step_json: Path) -> int:
    st = load_json_bytes(Path(step_json).read_bytes())
    step_dir = Path(st["step_dir"])
    adapter_dir = Path(st["adapter_dir"])
    root = Path(st["root"])
    inv = st["invocation_attempt_id"]
    sys.path.insert(0, str(adapter_dir))
    import phase_b_shared as ps
    from phase_b_contract import load_constants, run_binding_compare, run_binding_document
    from phase_b_effects import (AdapterBlocked, TraceTee, inventory, inventory_digest, normalize_trace,
                                 canonical_hash, write_json_durable)
    from phase_b_state import IN_PROGRESS, PREPARED, classify_structure, validate_in_progress

    c = load_constants(adapter_dir / "phase_b_constants.json")
    rec = {"schema": STEP_RECEIPT_SCHEMA, "attempt_id": inv, "case": st["case"], "step": st["step_index"],
           "kind": st["kind"], "root": str(root), "adapter_dir": str(adapter_dir), "pid": os.getpid(),
           "dd7": "SHA/tamanho apenas; nenhuma métrica econômica lida", "outcome": None}
    if st.get("orchestrator_action") == "CTRL_C":
        rec["ctrl_c_enable"] = enable_ctrl_c()  # alvo do CTRL_C_EVENT real (P5): processamento de CTRL+C garantido
    try:  # bloqueio sem efeito (antes de qualquer gate): receipt BLOCKED, nunca exit não provado
        if c["_sha256"] != st["adapter_constants_sha256"]:
            raise HarnessBlocked("QS4_ADAPTER_CONSTANTS_PIN", c["_sha256"])
        guard_case_root(root, Path(st["attempt_shadow"]), Path(c["paths"]["control_root"]))
    except HarnessBlocked as e:
        rec["outcome"] = _classify_exception(e)
        rec["blocked_gate"] = "QS4_PRE"
        rec["exit_code"] = 0
        write_receipt_with_companion(step_dir / "STEP_RECEIPT.json", rec, write_json_durable)
        return 0
    lay = replace(ps.Layout.production(c, adapter_dir), control_root=str(root), shadow_base=st["g18_base"],
                  evidence_base=st["invocations_evidence_base"],
                  phase_b_evidence_zip=str(Path(st["attempt_shadow"]) / "NEVER_WRITTEN_PHASE_B_EVIDENCE.zip"))
    o2d = {int(k): v for k, v in st["ordinal_to_date"].items()}
    root_inv0 = inventory(root)
    rec["root_digest_before"] = inventory_digest(root_inv0)
    s = ps.Session(mode="DRY", layout=lay, constants=c, platform=ps.WindowsPlatform(), attempt_id=inv)
    s.started_ns = time.time_ns()
    real_stdout = sys.stdout
    h = None
    g21_index = None
    seam_record: dict = {}
    template_mode = None
    seamset = None
    try:
        s.open_evidence()
        rec["adapter_evidence_dir"] = str(s.evidence_dir)
        ctx = ps._common_pre_shadow(s, with_tick_rehash=False)
        state = ctx["struct"]["state"]
        rec["state_before"] = state
        if state not in (PREPARED, IN_PROGRESS):
            raise AdapterBlocked("QS4_STATE_NOT_RUNNABLE", state)
        s.record["parent_cells"] = ctx["parent"]["cells"]
        s.tee = TraceTee(sys.stdout)
        sys.stdout = s.tee
        s.gate("G18", lambda: ps.gate_g18_shadow(s, state, ctx["parent"]),
               input_of=lambda r: {"repro": r["reproduction"]["files"], "identity": r["identity_stable"]})
        s.tee.lines.clear()  # janela comparável = G19 + run_phase (mesma regra de run_flow do R3)
        fz = s.frozen

        def g19():
            rb_path = root / c["run_owned_names"]["run_binding"]
            existing = rb_path.exists()
            if existing:
                run_binding_compare(load_json_bytes(rb_path.read_bytes()), s.adapter_identity, c)
            s.f1_marked = True
            s.emit("EFFECTFUL_FRONTIER", "F1_QS4_SHADOW_ONLY", root=str(root))
            if not existing:
                write_json_durable(rb_path, run_binding_document(s.adapter_identity, c, s.attempt_id), exclusive=True)
            pf, _a, _b, _d = ps.phase_b_only(fz.full.prepare_preflight)(root, "B", Path(lay.preflight_root))
            _po, binding, identity, rhash, cal, d1_path = ps.phase_b_only(fz.full.build_binding)(
                root, "B", pf, ctx["parent"]["cells"], ctx["parent"])
            inv_now = inventory(root)
            pins = {e["path"]: {"bytes": int(e["bytes"]), "sha256": str(e["sha256"]).upper()} for e in c["control_prepared"]["files"]}
            bad = [k for k, v in pins.items() if inv_now["files"].get(k) != v]
            if bad:
                raise AdapterBlocked("QS4_PREP_POSTVERIFY", ",".join(bad))
            if identity != s.record["identity_control"]:
                raise AdapterBlocked("QS4_IDENTITY_NE_SHADOW_EXPECTED")
            return {"binding": binding, "identity": identity, "rhash": rhash, "cal": cal, "d1_path": str(d1_path)}
        g19r = s.gate("G19", g19)
        s.gate("G20", lambda: ps._assert_final_absent(root / "PHASE_B"))
        template = None
        if st["template"] in ("QS3", "ALTERED") and state == PREPARED:
            template = load_json_bytes(Path(st["template_path"]).read_bytes())
            if canonical_hash(template) != st["template_sha256"]:
                raise AdapterBlocked("QS4_TEMPLATE_PIN")
            if st["template"] == "ALTERED":
                template = list(template) + ["QS4_ALTERED_TEMPLATE_LINE"]
            template_mode = st["template"]
        else:
            template_mode = "NONE_RESUME" if state == IN_PROGRESS else "NONE"
        with ps.SeamSet(s, "RUN", root, template_runtime_trace=template) as seamset:
            import qs4_seams  # somente após a guarda de produção do R3 (SeamSet.__enter__)
            with qs4_seams.SeamStack(sys.modules, st, o2d, step_dir, float(st["block_max_s"]),
                                       adapter_dir=adapter_dir) as stack:
                seam_record = stack.spec_record
                jb = _journal_count(root)
                h = s.gate("G21", lambda: ps._pre_recover(s, root))
                ja = _journal_count(root)
                g21_index = len(s.tee.lines)
                rec["t31b"] = {"journal_before_g21": jb, "journal_after_g21": ja}
                try:
                    ps.phase_b_only(fz.full.run_phase)(root, "B", ctx["parent"]["cells"], g19r["binding"], g19r["identity"],
                                                       g19r["rhash"], g19r["cal"], Path(g19r["d1_path"]),
                                                       c["config"]["workers"], c["config"]["batch_rows"])
                    rec["outcome"] = {"class": "COMPLETED_UNEXPECTED", "seam": None, "code": None}
                finally:
                    seam_record["anchor_events"] = list(stack.anchor.events) if stack.anchor else []
    except BaseException as e:  # noqa: BLE001 - classificação explícita, sem engolir sinais de saída do processo
        if isinstance(e, (SystemExit, GeneratorExit)):
            raise
        rec["outcome"] = _classify_exception(e)
        _quarantine(step_dir, rec, f"{type(e).__name__}: {e}\n" + traceback.format_exc())
    finally:
        sys.stdout = real_stdout
        if h is not None:
            try:
                s.platform.release_named_mutex(h)
            except Exception:  # noqa: BLE001
                rec["g21_mutex_release"] = "FAILED"
        ps._release_mutexes(s)
    # ------------------------------------------------------------------ pós-análise (somente leitura)
    lines = s.tee.lines if s.tee else []
    rec["template_mode"] = template_mode
    rec["trace_guard"] = ("PASS_COMPARED" if (seamset is not None and seamset.ppr_restored and template_mode in ("QS3", "ALTERED"))
                          else "PASS_NOT_APPLICABLE" if (seamset is not None and seamset.ppr_restored) else "NOT_REACHED")
    rec["normalized_trace_sha256"] = canonical_hash(normalize_trace(lines, c["trace"]))
    rec["raw_trace_lines"] = len(lines)
    rec["raw_trace_sha256"] = sha_bytes(("\n".join(lines)).encode("utf-8"))
    rec["safe_stop_requested_line"] = any(ln.startswith("SAFE_STOP_REQUESTED=YES") for ln in lines)
    stale = [i for i, ln in enumerate(lines) if ln.startswith("STALE_SCRATCH_RECONCILED")]
    if "t31b" in rec:
        rec["t31b"]["stale_line_before_g21"] = any(i < (g21_index or 0) for i in stale)
        rec["t31b"]["stale_lines"] = len(stale)
    rec["seams"] = seam_record
    rec["gates"] = [{k: g.get(k) for k in ("id", "status", "code")} for g in s.gates]
    blocked = [g.get("id") for g in s.gates if g.get("status") == "BLOCKED"]
    rec["blocked_gate"] = blocked[-1] if blocked else None
    rec["runtime_evidence"] = ps.runtime_evidence(root, os.getpid(), s.started_ns)
    rec["committed_count"] = _committed(root)
    try:
        struct = classify_structure(inventory(root), c, root)
        rec["state_after"] = struct["state"]
        rec["state_after_findings"] = struct["findings"][:20]
        rec["state_after_detail"] = {"journal": bool(struct.get("journal")), "pending": len(struct.get("pending") or []),
                                     "sessions": len(struct.get("sessions") or []), "seals": len(struct.get("seals") or []),
                                     "completed": len(struct.get("completed") or []),
                                     "runlock_present": bool(struct.get("runlock_present")),
                                     "scratch_files": int(struct.get("scratch_files") or 0)}
        if struct["state"] == IN_PROGRESS and "identity_control" in s.record and "calendar" in s.record:
            try:
                validate_in_progress(root, c, struct, s.frozen, s.record["identity_control"], s.record["runtime_hashes"],
                                     s.record["parent_cells"], s.record["calendar"], lay)
                rec["t17"] = {"validate_in_progress": "PASS"}
            except Exception as e:  # noqa: BLE001
                rec["t17"] = {"validate_in_progress": "FAIL", "code": getattr(e, "code", type(e).__name__)}
    except Exception as e:  # noqa: BLE001
        rec["state_after"] = "UNCLASSIFIABLE"
        rec["state_after_error"] = type(e).__name__
    try:
        rec["t30"] = ps.t30_foreign_entries(s)
    except Exception as e:  # noqa: BLE001
        rec["t30"] = {"foreign": ["T30_SCAN_ERROR:" + type(e).__name__]}
    rec["root_digest_after"] = inventory_digest(inventory(root))
    rec["status_write_failures"] = s.status_failures
    s.stop_heartbeat()
    rec["exit_code"] = 0
    try:
        write_receipt_with_companion(step_dir / "STEP_RECEIPT.json", rec, write_json_durable)
    except Exception as e:  # noqa: BLE001
        sys.stderr.write("STEP_RECEIPT_WRITE_FAILED " + type(e).__name__ + "\n")
        return 3
    sys.stdout.write("QS4_STEP=" + json.dumps(rec["outcome"], sort_keys=True) + "\n")
    sys.stdout.flush()
    return 0
