"""PHASE_B_QS4_HARNESS_V001 — mundo literal de teste (sandbox Linux). NUNCA usado no alvo.

Constrói, num cwd temporário, os caminhos de produção literais ('D:\\...' como nomes relativos POSIX):
  * RELEASE (CODE 474 do E01, CONTROL PREPARED do E01, PREFLIGHT do E01, recibos G8), IND/M1 do E01,
    ticks ESPARSOS com o tamanho exato (conteúdo NÃO real), pai 2025 (homologação + freeze do E01);
  * ADAPTADOR DE TESTE = cópia do R3 com constantes ajustadas ao mundo (rotulado): preflight_source_root da
    configuração resolvida no cwd e SHA dos ticks esparsos — mesma técnica do T14F do R3;
  * HARNESS DE TESTE = cópia do harness com os pinos do adaptador de teste;
  * QS3 sintético (rotulado) com DRY_RECEIPT/companions/status/log/QS2 coerentes, para H01.
Dados SINTÉTICOS são rotulados; nenhum resultado econômico é produzido (o runtime para em RunLock: Win32).
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
HARNESS = HERE.parent


def env_paths():
    payload = Path(os.environ["MINOTAURO_E01_PAYLOAD"])
    r3 = Path(os.environ["MINOTAURO_R3_DIR"])
    return payload, r3


def sha(p) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()


def zero_sha(size: int) -> str:
    h = hashlib.sha256()
    blk = b"\0" * (8 * 1024 * 1024)
    left = size
    while left:
        n = min(left, len(blk))
        h.update(blk[:n])
        left -= n
    return h.hexdigest().upper()


def canon(obj) -> bytes:
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def run_build_package(adapter_copy: Path):
    subprocess.run([sys.executable, "-B", str(adapter_copy / "qualification" / "build_package.py"), str(adapter_copy)],
                   check=True, capture_output=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))


def build_world(work: Path) -> dict:
    """cwd DEVE ser `work` durante o uso do mundo."""
    payload, r3 = env_paths()
    c = json.loads((r3 / "phase_b_constants.json").read_text(encoding="utf-8"))
    P, lit = c["paths"], c["frozen_literals"]
    rel = Path(P["release_root"])
    rel.mkdir(parents=True)  # em POSIX, 'D:\\...\\CODE' é nome irmão (não filho) da raiz literal do release
    shutil.copytree(payload / "CODE", Path(P["code_root"]))
    shutil.copytree(payload / "CONTROL", Path(P["control_root"]))
    shutil.copytree(payload / "PREFLIGHT", Path(P["preflight_root"]))
    (Path(P["preflight_root"]) / "_TMP_SAME_VOLUME_PHASE_B" / "_avast_").mkdir(parents=True, exist_ok=True)
    for key, f in (("g8_local_receipt", "G8_RELEASE_RECEIPT.json"),
                   ("g8_evidence_zip", "G8_DRY_RUN_RELEASE_FF_CUTOFF_R3_20261001_EVIDENCE.zip")):
        shutil.copyfile(payload / "RELEASE" / f, Path(P[key]))  # nome literal (irmão em POSIX)
    ind = Path(lit["ind_d1"]); ind.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(payload / "DATA" / "IND_D1.csv", ind)
    m1 = Path(lit["m1_root"]); m1.mkdir(parents=True)
    for f in sorted((payload / "M1_2026").glob("*.csv")):
        shutil.copyfile(f, m1 / f.name)
    (m1 / "WIN@N_M1_2025_12.csv").write_text(  # SINTÉTICO: só fornece a sessão predecessora 2025-12-30
        "WIN@N;M1;2025.12.30;09:00:00;1.00;1.00;1.00;1.00;1;1;1.00;0;0\n", encoding="utf-8")
    tick_shas = {}
    for t in c["inputs"]["ticks"]:
        p = Path(t["path"]); p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("wb") as f:
            f.truncate(int(t["bytes"]))
        tick_shas[t["path"]] = zero_sha(int(t["bytes"]))
    parent = Path(lit["parent_2025"])
    (parent / "GATES").mkdir(parents=True); (parent / "PHASE_A").mkdir(parents=True)
    shutil.copyfile(payload / "PARENT_2025" / "GATES" / "CORRECTNESS_FULL_HOMOLOGATION_RECEIPT.json",
                    parent / "GATES" / "CORRECTNESS_FULL_HOMOLOGATION_RECEIPT.json")
    shutil.copyfile(payload / "PARENT_2025" / "PHASE_A" / "SELECTION_FREEZE.json", parent / "PHASE_A" / "SELECTION_FREEZE.json")
    # configuração: preflight_source_root resolvido no cwd (mesma técnica do T14F)
    control = Path(P["control_root"])
    cfg = json.loads((control / "FULL_2026_CONFIGURATION.json").read_text(encoding="utf-8"))
    cfg["preflight_source_root"] = str(Path(P["preflight_root"]).resolve())
    raw = json.dumps(cfg, ensure_ascii=False, indent=2).encode()
    (control / "FULL_2026_CONFIGURATION.json").write_bytes(raw)
    # adaptador de TESTE (rotulado)
    adapter = work / "TEST_ADAPTER" / "PHASE_B_ADAPTER_V001"
    shutil.copytree(r3, adapter)
    tc = json.loads((adapter / "phase_b_constants.json").read_text(encoding="utf-8"))
    tc["config"]["sha256"] = sha(control / "FULL_2026_CONFIGURATION.json")
    for e in tc["control_prepared"]["files"]:
        if e["path"] == "FULL_2026_CONFIGURATION.json":
            e["sha256"], e["bytes"] = tc["config"]["sha256"], len(raw)
    for t in tc["inputs"]["ticks"]:
        t["sha256"] = tick_shas[t["path"]]
    (adapter / "phase_b_constants.json").write_text(json.dumps(tc, indent=1, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    run_build_package(adapter)
    a_ident = json.loads((adapter / "ADAPTER_IDENTITY.json").read_text())
    # harness de TESTE com os pinos do adaptador de teste
    harness, hc = make_test_harness(work, "PHASE_B_QS4_HARNESS_V001", a_ident, {})
    fake_zip = hc["adapter"]["package_zip_sha256"]
    return {"adapter": adapter, "harness": harness, "adapter_identity": a_ident["adapter_identity_sha256"],
            "adapter_constants": a_ident["constants_sha256"], "fake_zip": fake_zip, "hc": hc, "tc": tc,
            "a_ident": a_ident}


TEST_FREE_SPACE = {"min_free_bytes_at_start": 1 << 20, "min_free_bytes_per_invocation": 1 << 20}


def make_test_harness(work: Path, name: str, a_ident: dict, overrides: dict) -> tuple:
    """Cópia ROTULADA do harness com os pinos do adaptador de teste e limites de sandbox (espaço livre em
    1 MiB: o disco da sandbox não tem 100 GiB). `overrides` = {chave_de_1º_nível: dict a mesclar}."""
    harness = work / "TEST_HARNESS" / name / "PHASE_B_QS4_HARNESS_V001"
    shutil.copytree(HARNESS, harness, ignore=shutil.ignore_patterns("__pycache__"))
    hc = json.loads((harness / "qs4_constants.json").read_text(encoding="utf-8"))
    hc["adapter"].update(identity_sha256=a_ident["adapter_identity_sha256"], constants_sha256=a_ident["constants_sha256"],
                         package_zip_sha256="F" * 64)
    hc["free_space"] = dict(TEST_FREE_SPACE)
    for k, v in overrides.items():
        if isinstance(v, dict) and isinstance(hc.get(k), dict):
            hc[k].update(v)
        else:
            hc[k] = v
    (harness / "qs4_constants.json").write_text(json.dumps(hc, indent=1, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    subprocess.run([sys.executable, "-B", str(harness / "qualification" / "build_qs4_package.py"), str(harness)],
                   check=True, capture_output=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
    return harness, hc


# --------------------------------------------------------------------------- QS3 sintético (H01)
QS3_ITEMS = ["PRIOR_QS2", "T26", "DRY_RUN_B", "T02", "T11c", "T14", "T19_template", "T23", "T27", "T30"]
TEMPLATE = ["PREFLIGHT_PHASE_B_REUSE sessions=166", "RUN_START mode=RUN_B sessions=166 remaining_sessions=166"]


def build_qs3(evidence_base: Path, identity: str, zip_sha: str, mut: dict | None = None,
              qs3_attempt: str = "20261003T100000Z_0000abcd", qs2_attempt: str = "20261003T090000Z_0000abce") -> dict:
    """QS3 PASS sintético (rotulado) com todos os vínculos físicos que H01 exige. `mut` aplica falhas pontuais."""
    mut = mut or {}
    sys.path.insert(0, str(env_paths()[1]))
    from phase_b_effects import canonical_hash  # mesma função do R3
    qd = Path(evidence_base) / qs3_attempt
    ad = qd / "ADAPTER"
    ad.mkdir(parents=True)
    q2d = Path(evidence_base) / qs2_attempt
    q2d.mkdir(parents=True)
    q2 = {"schema": "MINOTAURO_PHASE_B_ADAPTER_BOOTSTRAP_QS2_READONLY_RECEIPT_V001", "attempt_id": qs2_attempt,
          "stage": "QS2_READONLY", "final_exit": 0 if not mut.get("qs2_fail") else 2,
          "facts": {"adapter_identity_sha256": identity, "package_zip_sha256": zip_sha}}
    q2p = q2d / "QS2_RECEIPT.json"
    q2p.write_bytes(canon(q2))
    status = canon({"fields": {"ACTIVE": "NO", "PHASE": "FINISHED"}, "extra": {"exit_code": 0}})
    (ad / "ADAPTER_STATUS.json").write_bytes(status)
    template = list(TEMPLATE)
    dr = {"schema": "MINOTAURO_PHASE_B_ADAPTER_DRY_RECEIPT_V001", "attempt_id": qs3_attempt, "exit_code": 0, "result": "PASS",
          "mode": "DRY", "adapter_identity_sha256": identity, "state": "PREPARED", "dry_scope": "SUBSTANTIVE_TO_BND",
          "bnd_reached": True, "status_write_failures": 0, "status_final_persisted": True,
          "status_final_sha256": hashlib.sha256(status).hexdigest().upper(),
          "runtime_trace": template, "runtime_trace_sha256": canonical_hash(template)}
    if mut.get("dry_scope"):
        dr["dry_scope"] = mut["dry_scope"]
    if mut.get("template_sha_wrong"):
        dr["runtime_trace_sha256"] = "0" * 64
    drb = canon(dr)
    (ad / "DRY_RECEIPT.json").write_bytes(drb)
    dsha = hashlib.sha256(drb).hexdigest().upper()
    (ad / "DRY_RECEIPT.VERIFIED.json").write_bytes(canon({"schema": "MINOTAURO_PHASE_B_ADAPTER_RECEIPT_VERIFIED_V001",
                                                         "receipt_sha256": dsha, "attempt_id": qs3_attempt,
                                                         "exit_code": 0, "mode": "DRY", "readback": "PASS"}))
    bstatus = canon({"fields": {"ACTIVE": "NO", "PHASE": "FINISHED"}, "extra": {"final_exit": 0 if not mut.get("bstatus_fail") else 2}})
    (qd / "BOOTSTRAP_STATUS.json").write_bytes(bstatus)
    items = {q: {"result": "PASS"} for q in QS3_ITEMS}
    items["DRY_RUN_B"]["receipt"] = {"valid": True, "sha256": dsha if not mut.get("dry_binding") else "0" * 64}
    if mut.get("item_fail"):
        items[mut["item_fail"]]["result"] = "FAIL"
    if mut.get("item_missing"):
        items.pop(mut["item_missing"])
    rec = {"schema": "MINOTAURO_PHASE_B_ADAPTER_BOOTSTRAP_QS3_DRY_RECEIPT_V001", "attempt_id": qs3_attempt, "stage": "QS3_DRY",
           "facts": {"adapter_identity_sha256": mut.get("identity", identity), "package_zip_sha256": mut.get("zip", zip_sha),
                     "prior_qs2_receipt_path": str(q2p.resolve()), "prior_qs2_receipt_sha256": sha(q2p)},
           "items": items, "required_items": QS3_ITEMS, "blocked_reason": None, "unproven_effect": False,
           "interrupted": False, "status_write_failures": 0, "final_status_written": True,
           "final_status_sha256": hashlib.sha256(bstatus).hexdigest().upper(), "final_exit": mut.get("final_exit", 0)}
    if mut.get("not_clean"):
        rec["interrupted"] = True
    rp = qd / "QS3_RECEIPT.json"
    rb = canon(rec)
    rp.write_bytes(rb)
    rsha = hashlib.sha256(rb).hexdigest().upper()
    if not mut.get("companion_missing"):
        (qd / "QS3_RECEIPT.VERIFIED.json").write_bytes(canon({"schema": "MINOTAURO_PHASE_B_ADAPTER_BOOTSTRAP_RECEIPT_VERIFIED_V001",
                                                             "receipt_sha256": rsha, "attempt_id": qs3_attempt,
                                                             "stage": "QS3_DRY", "final_exit": rec["final_exit"], "readback": "PASS"}))
    log = [f"ATTEMPT_ID={qs3_attempt}", f"STAGE_RECEIPT={rp} sha256={rsha}", "FINAL_EXIT=0"]
    if mut.get("log_dup"):
        log.append("STAGE_RECEIPT=x sha256=y")
    if mut.get("log_final_2"):
        log[-1] = "FINAL_EXIT=2"
    (qd / "BOOTSTRAP.log").write_bytes(("\r\n".join(log) + "\r\n").encode("utf-8"))
    if mut.get("tamper_after"):
        rp.write_bytes(rb + b" ")
    return {"path": str(rp.resolve()), "sha": rsha, "dir": qd, "template": template, "qs2": q2p}
