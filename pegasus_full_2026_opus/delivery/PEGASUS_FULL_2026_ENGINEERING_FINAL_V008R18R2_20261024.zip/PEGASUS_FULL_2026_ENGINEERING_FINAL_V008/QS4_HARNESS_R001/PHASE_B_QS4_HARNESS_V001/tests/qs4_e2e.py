"""PHASE_B_QS4_HARNESS_V001 — cenários ponta a ponta no mundo literal (sandbox Linux). NUNCA usado no alvo.

Uso: python -B tests/qs4_e2e.py <fake-matrix|real-orchestrator|real-direct> <out.json>
Cada cenário roda em diretório temporário próprio (cwd = mundo literal). Imprime/grava um JSON com as observações.
Tudo que é SINTÉTICO é rotulado (ticks esparsos, QS3 sintético, efeitos simulados do fake-invoke).
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))
import qs4_world as W  # noqa: E402

ATT = "20261003T12{:04d}Z_0000{:04x}"


def tree(root) -> dict:
    root = Path(root)
    out = {}
    if root.is_dir():
        for p in sorted(root.rglob("*")):
            if p.is_file():
                out[p.relative_to(root).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest().upper()
    return out


def protected_digest(tc: dict) -> dict:
    P = tc["paths"]
    return {k: hashlib.sha256(json.dumps(tree(P[k]), sort_keys=True).encode()).hexdigest().upper()
            for k in ("control_root", "preflight_root", "code_root")}


def run_orch(harness: Path, adapter: Path, mode: str, att: str, qs3: dict, env_extra=None, sha_override=None,
             bytecode=True, resume_from=None, background=False):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    env.update(env_extra or {})
    py = [sys.executable, "-B"]
    if not bytecode:  # -B mantido no wrapper (não gerar __pycache__ no harness de teste); falta só a variável
        env.pop("PYTHONDONTWRITEBYTECODE", None)
    t0 = time.time()
    cmd = py + [str(HERE / "qs4_orch_wrapper.py"), str(harness), mode, "orchestrate", "--attempt-id", att,
                "--r3-dir", str(adapter), "--qs3-receipt", os.path.abspath(qs3["path"]),
                "--qs3-receipt-sha256", sha_override or qs3["sha"]] + (["--resume-from", resume_from] if resume_from else [])
    if background:
        return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env)
    r = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=3600)
    hc = json.loads((harness / "qs4_constants.json").read_text(encoding="utf-8"))
    ev = Path(hc["paths"]["evidence_base"]) / att / "HARNESS"
    sh = Path(hc["paths"]["qs4_shadow_base"]) / att
    out = {"exit": r.returncode, "seconds": round(time.time() - t0, 1), "stderr_tail": r.stderr[-1500:],
           "evidence_exists": ev.is_dir(), "shadow_exists": sh.is_dir()}
    rp = ev / "QS4_HARNESS_RECEIPT.json"
    if rp.is_file():
        sys.path.insert(0, str(harness))
        import qs4_lib as L
        v = L.verify_receipt_with_companion(rp, L.HARNESS_RECEIPT_SCHEMA, att, exit_code=r.returncode)
        rec = json.loads(rp.read_text(encoding="utf-8"))
        out.update(receipt_valid=v["valid"], receipt_reason=v["reason"], items=rec.get("items"),
                   blocked_reason=rec.get("blocked_reason"), unproven=rec.get("unproven"),
                   status_write_failures=rec.get("status_write_failures"),
                   status_final_persisted=rec.get("status_final_persisted"), result=rec.get("result"),
                   cases={c["id"]: c["result"] for c in rec.get("cases", [])},
                   comparisons={c["id"]: c.get("comparison") for c in rec.get("cases", []) if c.get("comparison")},
                   growth=(rec.get("growth") or {}).get("projected_run_growth_bytes_166"),
                   protected_equal=(rec.get("protected_before") == rec.get("protected_after")) if rec.get("protected_after") else None,
                   t22_variant=rec.get("t22_variant_identity_sha256"),
                   durable_units=rec.get("durable_units"), sessions=rec.get("sessions"), abandoned=rec.get("abandoned"),
                   resume_reconcile=rec.get("resume_reconcile"), p5_microprobe=rec.get("p5_microprobe"),
                   multiwork=(rec.get("multiwork") or {}).get("value"), t18_semantics=(rec.get("t18_semantics") or {}).get("statement"),
                   gens={c["id"]: c.get("gen") for c in rec.get("cases", [])},
                   step_counts={c["id"]: len(c["steps"]) for c in rec.get("cases", [])},
                   adopted=[f"{c['id']}#{s['step']}" for c in rec.get("cases", []) for s in c["steps"] if s.get("adopted_on_resume")],
                   adopted_ledger=rec.get("adopted"), resume_history=rec.get("resume_history"),
                   terminal=rec.get("terminal"), resumable=rec.get("resumable"), exit_code=rec.get("exit_code"),
                   session_history=rec.get("session_history"), session_history_head=rec.get("session_history_head_sha256"),
                   adopted_steps=[{k: s.get(k) for k in ("case", "step", "native_exit", "child", "adoption", "receipt")}
                                  for c in rec.get("cases", []) for s in c["steps"] if s.get("adopted_on_resume")],
                   steps_without_native=[f"{c['id']}#{s['step']}" for c in rec.get("cases", []) for s in c["steps"]
                                         if type(s.get("native_exit")) is not int],
                   steps=[{"case": s["case"], "step": s["step"], "outcome": s.get("outcome"), "pass": s["evaluation"]["pass"],
                           "reasons": s["evaluation"]["reasons"], "action": s.get("action"), "ctrl_c": s.get("ctrl_c"),
                           "p10": s.get("p10_descendants_before"), "expect": s.get("expect_effective"),
                           "state_after": s.get("state_after"), "committed": s.get("committed_count")}
                          for c in rec.get("cases", []) for s in c["steps"]])
        st = ev / "HARNESS_STATUS.json"
        if st.is_file():
            sd = json.loads(st.read_text(encoding="utf-8"))
            out["status_final"] = {"ACTIVE": sd["fields"]["ACTIVE"], "exit": (sd.get("extra") or {}).get("exit_code"),
                                   "sha_matches_receipt": hashlib.sha256(st.read_bytes()).hexdigest().upper() == rec.get("status_final_sha256")}
    pp = ev / "HARNESS_PROGRESS.json"
    if pp.is_file():
        out["progress_final"] = json.loads(pp.read_text(encoding="utf-8"))["progress"]
    stp = ev / "HARNESS_STATUS.json"
    if stp.is_file():
        sdoc = json.loads(stp.read_text(encoding="utf-8"))
        out["status_progress"] = {"PROGRESS": sdoc["fields"]["PROGRESS"], "TOTAL": sdoc["fields"]["TOTAL"],
                                  "PCT": (sdoc.get("progress") or {}).get("PCT")}
    lp = ev / "HARNESS.log"
    if lp.is_file():
        out["log_tail"] = [ln for ln in lp.read_text(encoding="utf-8").splitlines() if not ln.startswith("HEARTBEAT")][-6:]
        out["log_watchdog"] = [ln for ln in lp.read_text(encoding="utf-8").splitlines() if ln.startswith(("WATCHDOG_EXPIRED", "ORPHAN_ACTIVE"))]
    return out


def pids_from(lines, key="pid="):
    out = []
    for ln in lines:
        for tok in ln.split():
            if tok.startswith(key):
                v = tok[len(key):].strip("[],")
                for x in v.split(","):
                    if x.strip().isdigit():
                        out.append(int(x.strip()))
    return out


def alive(pid) -> bool:
    try:
        os.kill(pid, 0)
        st = Path(f"/proc/{pid}/stat").read_text()
        return st[st.rindex(")") + 2] != "Z"
    except (OSError, ValueError):
        return False


BASE_OVER = {"heartbeat_seconds": 2, "p10": {"orphan_grace_s": 3},
             "p5": {"microprobe": {"ready_timeout_s": 10, "target_timeout_s": 4, "exit_wait_s": 10}}}


def ledger(hc: dict, logical: str) -> dict:
    p = Path(hc["paths"]["evidence_base"]) / logical / "HARNESS" / "QS4_LEDGER.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else {}


def resume_matrix(work: Path) -> dict:
    """Q4-02: queda do orquestrador em pontos distintos + retomada; negativos de retomada."""
    w = W.build_world(work)
    h, hc = W.make_test_harness(work, "RES", w["a_ident"], dict(BASE_OVER))
    ev = Path(hc["paths"]["evidence_base"])
    qs3 = W.build_qs3(ev, hc["prior_qs3"]["adapter_identity_sha256"], hc["prior_qs3"]["package_zip_sha256"])
    qs3b = W.build_qs3(ev, hc["prior_qs3"]["adapter_identity_sha256"], hc["prior_qs3"]["package_zip_sha256"],
                       qs3_attempt="20261003T110000Z_0000beef", qs2_attempt="20261003T105000Z_0000beee")
    sh = Path(hc["paths"]["qs4_shadow_base"])
    res = {}
    n = [100]

    def att():
        n[0] += 1
        return ATT.format(n[0], n[0])

    def crash_then_resume(name, crash, fake=None):
        a = att()
        env = {"QS4_TEST_CRASH": crash}
        if fake:
            env["QS4_FAKE"] = fake
        r1 = run_orch(h, w["adapter"], "fake", a, qs3, env)
        led1 = ledger(hc, a)
        r1["ledger_partial"] = led1.get("partial")
        r1["ledger_final"] = led1.get("final")
        r1["units_at_crash"] = sum(len(c.get("steps") or []) for c in led1.get("cases", {}).values())
        b = att()
        r2 = run_orch(h, w["adapter"], "fake", b, qs3, resume_from=a)
        r2["case_dirs"] = {cid: sorted(p.name for p in (sh / a / "CASES" / cid).iterdir()) for cid in ("T16_K1", "T16_K2", "REF_E3")
                           if (sh / a / "CASES" / cid).is_dir()}
        r2["reloc_dirs"] = sorted(p.name for p in (sh / a / "RELOCATED" / "T29_RELOCATION").iterdir()) \
            if (sh / a / "RELOCATED" / "T29_RELOCATION").is_dir() else []
        r2["variant_dirs"] = sorted(p.name for p in (sh / a / "VARIANT_ADAPTER").iterdir()) if (sh / a / "VARIANT_ADAPTER").is_dir() else []
        r2["ledger_final"] = ledger(hc, a).get("final")
        res[name] = {"first": r1, "resume": r2, "logical": a}
        return a
    crash_then_resume("RETRY", "T16_K1#1:STEP_INTENT")
    crash_then_resume("ADOPT", "REF_E3#0:BEFORE_COMMIT")
    crash_then_resume("ABANDON", "", fake="noreceipt:T16_K2#1")
    crash_then_resume("SEEDING", "T16_K2#:CASE_SEEDING")
    crash_then_resume("RELOCATE", "T29_RELOCATION#1:RELOCATE_INTENT")
    crash_then_resume("VARIANT", "*#:VARIANT_BUILDING")
    crash_then_resume("EXITNONZERO", "", fake="exitnonzero:T16_K1#1")
    crash_then_resume("FINAL_PENDING", "*#:FINAL_PENDING")

    def wait_dead(pid, limit=240):
        t0 = time.time()
        while alive(pid) and time.time() - t0 < limit:
            time.sleep(0.5)

    # queda ENTRE o Popen e o registro do pid (filho vivo, desconhecido do ledger) => bloqueia; depois ABANDONA (nunca adota)
    a = att()
    g1 = run_orch(h, w["adapter"], "fake", a, qs3, {"QS4_TEST_CRASH": "REF_E3#0:STEP_CHILD_GAP", "QS4_FAKE": "slow:REF_E3#0",
                                                            "QS4_FAKE_SLOW_S": "150"})
    gap = {"first": g1, "ledger_partial": ledger(hc, a).get("partial")}
    gap["blocked"] = run_orch(h, w["adapter"], "fake", att(), qs3, resume_from=a)
    for pid in [int(x) for x in os.listdir("/proc") if x.isdigit()]:
        try:
            if ("QS4_HARNESS_SESSION=" + a).encode() in Path(f"/proc/{pid}/environ").read_bytes().split(b"\0"):
                wait_dead(pid)
        except OSError:
            pass
    gap["resume"] = run_orch(h, w["adapter"], "fake", att(), qs3, resume_from=a)
    res["GAP"] = gap
    # P5 (ação do orquestrador) caído com o filho vivo: espera o filho terminar; ação => nunca adotado
    a = att()
    p1 = run_orch(h, w["adapter"], "fake", a, qs3, {"QS4_TEST_CRASH": "T18_P5_CTRL_C#0:STEP_CHILD"})
    ch = (ledger(hc, a).get("partial") or {}).get("child") or {}
    if ch.get("pid"):
        wait_dead(int(ch["pid"]))
    res["P5_CRASH"] = {"first": p1, "resume": run_orch(h, w["adapter"], "fake", att(), qs3, resume_from=a)}
    # diário dessincronizado (queda entre o replace do ledger e o append do diário) + fragmento truncado
    a = att()
    run_orch(h, w["adapter"], "fake", a, qs3, {"QS4_TEST_CRASH": "T16_K1#0:STEP_INTENT"})
    jp = ev / a / "HARNESS" / "QS4_LEDGER.jsonl"
    lines = jp.read_text(encoding="utf-8").splitlines()
    jp.write_text("\n".join(lines[:-1]) + "\n" + lines[-1][:17], encoding="utf-8")  # TESTE: simula a queda
    res["JOURNAL_DESYNC"] = run_orch(h, w["adapter"], "fake", att(), qs3, resume_from=a)
    res["JOURNAL_DESYNC"]["journal_tail_event"] = json.loads(jp.read_text(encoding="utf-8").splitlines()[-1]).get("event")
    # B-1 (R2): depois da retomada o diário continua íntegro e o reparo precede a 1ª gravação da retomada
    sys.path.insert(0, str(h))
    import qs4_lib as L
    try:
        L.ledger_verify(ev / a / "HARNESS" / "QS4_LEDGER.json", jp)
        res["JOURNAL_DESYNC"]["journal_verify_after"] = "OK"
    except L.HarnessBlocked as ex:
        res["JOURNAL_DESYNC"]["journal_verify_after"] = f"{ex.code} {ex.detail}"
    evs = []
    for ln in jp.read_text(encoding="utf-8").splitlines():
        try:
            evs.append(json.loads(ln).get("event"))
        except ValueError:
            evs.append("<FRAGMENT>")
    res["JOURNAL_DESYNC"]["journal_events"] = evs
    # lock + filho vivo + retomada final
    a = att()
    bg = run_orch(h, w["adapter"], "fake", a, qs3, {"QS4_FAKE": "hang:REF_E3#0"}, background=True)
    t0 = time.time()
    child = None
    while time.time() - t0 < 120:
        part = ledger(hc, a).get("partial") or {}
        if part.get("child"):
            child = part["child"]["pid"]
            break
        time.sleep(0.5)
    lk = {"child_seen": child is not None}
    lk["locked"] = run_orch(h, w["adapter"], "fake", att(), qs3, resume_from=a)
    bg.send_signal(signal.SIGKILL)  # TESTE: queda do orquestrador (o filho "hang" continua vivo)
    bg.wait(30)
    lk["child_alive"] = run_orch(h, w["adapter"], "fake", att(), qs3, resume_from=a)
    if child:
        os.kill(child, signal.SIGKILL)  # TESTE: reconciliação manual simulada
        time.sleep(1.0)
    lk["after_reconcile"] = run_orch(h, w["adapter"], "fake", att(), qs3, resume_from=a)
    res["LOCK_ALIVE"] = lk
    final_logical = a
    # negativos de retomada (sobre attempts já existentes)
    res["FINAL_ALREADY"] = run_orch(h, w["adapter"], "fake", att(), qs3, resume_from=final_logical)
    a2 = att()
    run_orch(h, w["adapter"], "fake", a2, qs3, {"QS4_TEST_CRASH": "T16_K2#0:STEP_INTENT"})
    seq0 = ledger(hc, a2).get("ledger_sha256")
    res["BINDING"] = run_orch(h, w["adapter"], "fake", att(), qs3b, resume_from=a2)
    done_root = Path(ledger(hc, a2)["cases"]["REF_E3"]["root"])
    victim = sorted((done_root / "PHASE_B" / "sessions").rglob("*.gz"))[0]
    orig = victim.read_bytes()
    victim.write_bytes(orig + b"X")
    res["DURABLE_CHANGED"] = run_orch(h, w["adapter"], "fake", att(), qs3, resume_from=a2)
    victim.write_bytes(orig)
    lp = ev / a2 / "HARNESS" / "QS4_LEDGER.json"
    lorig = lp.read_bytes()
    lp.write_bytes(lorig.replace(b'"growth":null', b'"growth":0', 1) if b'"growth":null' in lorig else lorig + b" ")
    res["LEDGER_TAMPER"] = run_orch(h, w["adapter"], "fake", att(), qs3, resume_from=a2)
    lp.write_bytes(lorig)
    res["LEDGER_UNCHANGED_BY_NEGATIVES"] = ledger(hc, a2).get("ledger_sha256") == seq0
    res["UNKNOWN_ATTEMPT"] = run_orch(h, w["adapter"], "fake", att(), qs3, resume_from="20261003T235959Z_0000dead")
    res["RESUME_OK_AFTER_NEGATIVES"] = run_orch(h, w["adapter"], "fake", att(), qs3, resume_from=a2)
    res["NO_PYCACHE"] = not any(d.name == "__pycache__" for d in h.rglob("*") if d.is_dir())
    return res


def state_transfer(work: Path) -> dict:
    """R1-01 (state-transfer da sessão NOT_PASS) + R1-02 (adoção com exit nativo) + certificado terminal único."""
    w = W.build_world(work)
    h, hc = W.make_test_harness(work, "STX", w["a_ident"], dict(BASE_OVER))
    ev = Path(hc["paths"]["evidence_base"])
    qs3 = W.build_qs3(ev, hc["prior_qs3"]["adapter_identity_sha256"], hc["prior_qs3"]["package_zip_sha256"])
    res = {}
    n = [300]

    def att():
        n[0] += 1
        return ATT.format(n[0], n[0])

    def sha(p):
        return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()

    def resume(a, env=None):
        r = run_orch(h, w["adapter"], "fake", att(), qs3, env, resume_from=a)
        r["ledger_final"] = ledger(hc, a).get("final")
        return r
    # (1) sessão NOT_PASS só por falha de status => negativos de adulteração do receipt/companion/status anteriores
    a = att()
    s1 = run_orch(h, w["adapter"], "fake", a, qs3, {"QS4_TEST_STATUS_FAIL": "1"})
    s1["ledger_final"] = ledger(hc, a).get("final")
    sd = ev / a / "HARNESS"
    rp, cp, sp = sd / "QS4_HARNESS_RECEIPT.json", sd / "QS4_HARNESS_RECEIPT.VERIFIED.json", sd / "HARNESS_STATUS.json"
    s1["receipt_sha256"], s1["companion_sha256"], s1["status_sha256"] = sha(rp), sha(cp), sha(sp)
    led0 = ledger(hc, a).get("ledger_sha256")
    neg = {}
    rb, cb, sb = rp.read_bytes(), cp.read_bytes(), sp.read_bytes()
    rp.write_bytes(rb + b" ")  # TESTE: adulteração física
    neg["RECEIPT_TAMPER"] = resume(a)
    rp.write_bytes(rb)
    cdoc = json.loads(cb)
    cp.write_bytes(json.dumps(dict(cdoc, exit_code=3, readback="FAIL")).encode("utf-8"))
    neg["COMPANION_CONTRADICTORY"] = resume(a)
    cp.unlink()
    neg["COMPANION_MISSING"] = resume(a)
    cp.write_bytes(cb)
    rp.rename(sd / "X_RECEIPT.json")
    cp.rename(sd / "X_COMPANION.json")
    neg["RECEIPT_AND_COMPANION_MISSING"] = resume(a)
    (sd / "X_RECEIPT.json").rename(rp)
    (sd / "X_COMPANION.json").rename(cp)
    sp.write_bytes(sb + b" ")
    neg["STATUS_TAMPER"] = resume(a)
    sp.write_bytes(sb)
    neg["LEDGER_UNCHANGED"] = ledger(hc, a).get("ledger_sha256") == led0
    res["NEG"] = neg
    res["S1"] = s1
    res["S1_RESUME_PASS"] = resume(a)
    res["S1_RESUME_PASS"]["s1_session"] = a
    # (2) histórico de 2 sessões (queda sem receipt + NOT_PASS com receipt); adulteração de entrada já gravada
    b = att()
    run_orch(h, w["adapter"], "fake", b, qs3, {"QS4_TEST_CRASH": "T16_K2#0:STEP_INTENT"})
    b2 = resume(b, {"QS4_TEST_STATUS_FAIL": "1"})
    b2_sess = b2.get("sessions", [None])[-1] if b2.get("sessions") else None
    st1 = ev / b / "HARNESS" / "HARNESS_STATUS.json"
    s1b = st1.read_bytes()
    st1.write_bytes(s1b + b" ")  # TESTE: adulteração da sessão 1 (já registrada no histórico)
    hist_tamper = resume(b)
    st1.write_bytes(s1b)
    res["TWO_SESSIONS"] = {"crash_logical": b, "second": b2, "second_session": b2_sess, "history_tamper": hist_tamper,
                           "final": resume(b)}
    # (3) R1-02: adoção persistida com prova pai-observada; companion contraditório do passo adotado bloqueia
    c = att()
    run_orch(h, w["adapter"], "fake", c, qs3, {"QS4_TEST_CRASH": "REF_E3#0:BEFORE_COMMIT"})
    c2 = resume(c, {"QS4_TEST_CRASH": "T16_K1#1:STEP_INTENT"})
    lc = ledger(hc, c)
    ad = (lc.get("cases", {}).get("REF_E3", {}).get("steps") or [{}])[0]
    ad_ledger = {k: ad.get(k) for k in ("native_exit", "child", "adoption", "adopted_on_resume", "receipt")}
    scp = Path(ad["step_dir"]) / "STEP_RECEIPT.VERIFIED.json"
    scb = scp.read_bytes()
    scp.write_bytes(json.dumps(dict(json.loads(scb), exit_code=3, readback="FAIL")).encode("utf-8"))
    c3 = resume(c)
    scp.write_bytes(scb)
    res["ADOPT"] = {"first_session": c, "second": c2, "adopted_in_ledger": ad_ledger, "companion_contradictory": c3, "final": resume(c)}
    # (4) receipt TERMINAL sem STATE selado: exit 3; retomada recusa certificado alternativo
    d = att()
    d1 = run_orch(h, w["adapter"], "fake", d, qs3, {"QS4_TEST_SEAL_FAIL": "1"})
    d1["ledger_final"] = ledger(hc, d).get("final")
    rd = ev / d / "HARNESS" / "QS4_HARNESS_RECEIPT.json"
    d1["receipt_doc_exit"] = json.loads(rd.read_text(encoding="utf-8")).get("exit_code") if rd.is_file() else None
    res["SEAL_FAIL"] = {"first": d1, "resume": resume(d)}
    # receipt terminal apagado (receipt + companion): o log da sessão o registra => nunca vira lacuna de queda
    rdc = ev / d / "HARNESS" / "QS4_HARNESS_RECEIPT.VERIFIED.json"
    rd.rename(ev / d / "HARNESS" / "X_R.json")
    rdc.rename(ev / d / "HARNESS" / "X_C.json")
    res["SEAL_FAIL"]["receipt_deleted"] = resume(d)
    (ev / d / "HARNESS" / "X_R.json").rename(rd)
    (ev / d / "HARNESS" / "X_C.json").rename(rdc)
    res["NO_PYCACHE"] = not any(x.name == "__pycache__" for x in h.rglob("*") if x.is_dir())
    return res


def fake_matrix(work: Path) -> dict:
    w = W.build_world(work)
    tc = w["tc"]
    base_over = dict(BASE_OVER)
    h_ok, hc = W.make_test_harness(work, "OK", w["a_ident"], base_over)
    h_wd, _ = W.make_test_harness(work, "WD", w["a_ident"], dict(base_over, watchdog_seconds={"invoke_E3": 6}))
    ev = Path(hc["paths"]["evidence_base"])
    qs3 = W.build_qs3(ev, hc["prior_qs3"]["adapter_identity_sha256"], hc["prior_qs3"]["package_zip_sha256"])
    prot0 = protected_digest(tc)
    top0 = sorted(p.name for p in Path(".").iterdir())
    res = {}
    n = [0]

    def att():
        n[0] += 1
        return ATT.format(n[0], n[0])
    res["PASS"] = run_orch(h_ok, w["adapter"], "fake", att(), qs3)
    res["PASS"]["protected_unchanged_external"] = protected_digest(tc) == prot0
    new_top = set(p.name for p in Path(".").iterdir()) - set(top0)
    res["PASS"]["top_level_new"] = sorted(new_top)
    res["PASS"]["top_level_only_shadow_base"] = new_top <= {hc["paths"]["qs4_shadow_base"]}
    for name, spec in (("DIVERGE", "diverge:T16_K1"), ("EARLYSTOP", "earlystop:REF_E3"), ("FOREIGN", "foreign:T16_K2#1"),
                       ("NORECEIPT", "noreceipt:T16_K1#1")):
        a_ = att()
        res[name] = run_orch(h_ok, w["adapter"], "fake", a_, qs3, {"QS4_FAKE": spec})
        res[name]["logical"] = a_
    # veredito dos itens (FAIL) sela o attempt: retomada recusada
    res["DIVERGE_RESUME"] = run_orch(h_ok, w["adapter"], "fake", att(), qs3, resume_from=res["DIVERGE"]["logical"])
    r = run_orch(h_wd, w["adapter"], "fake", att(), qs3, {"QS4_FAKE": "hang:REF_E3"})
    pids = pids_from(r.get("log_watchdog", []))
    r["child_alive_after_exit"] = bool(pids) and all(alive(p) for p in pids)  # sem auto-kill
    for p in pids:  # limpeza do TESTE (sandbox)
        os.kill(p, signal.SIGKILL)
    res["HANG"] = r
    r = run_orch(h_ok, w["adapter"], "fake", att(), qs3, {"QS4_FAKE": "orphan:REF_E3"})
    orph = []
    for ln in r.get("log_watchdog", []):
        if "pids=[" in ln:
            orph += [int(x) for x in ln.split("pids=[")[1].split("]")[0].split(",") if x.strip().isdigit()]
    r["orphans_alive_after_exit"] = bool(orph) and all(alive(p) for p in orph)
    for p in orph:
        os.kill(p, signal.SIGKILL)
    res["ORPHAN"] = r
    a_sf = att()
    res["STATUS_FAIL"] = run_orch(h_ok, w["adapter"], "fake", a_sf, qs3, {"QS4_TEST_STATUS_FAIL": "1"})
    res["STATUS_FAIL"]["ledger_final"] = ledger(hc, a_sf).get("final")
    # B08 recusa o PASS da SESSÃO; o attempt continua retomável e uma sessão nova só reavalia (nada é reexecutado)
    res["STATUS_FAIL_RESUME"] = run_orch(h_ok, w["adapter"], "fake", att(), qs3, resume_from=a_sf)
    res["H01_BAD_SHA"] = run_orch(h_ok, w["adapter"], "fake", att(), qs3, sha_override="0" * 64)
    res["NO_BYTECODE_FLAG"] = run_orch(h_ok, w["adapter"], "fake", att(), qs3, bytecode=False)
    h_bad, _ = W.make_test_harness(work, "TAMPER", w["a_ident"], base_over)
    with (h_bad / "qs4_lib.py").open("a", encoding="utf-8") as f:
        f.write("\n# tamper\n")
    res["H00_TAMPER"] = run_orch(h_bad, w["adapter"], "fake", att(), qs3)
    r3_bad = work / "R3_TAMPER" / "PHASE_B_ADAPTER_V001"
    shutil.copytree(w["adapter"], r3_bad)
    with (r3_bad / "phase_b_effects.py").open("a", encoding="utf-8") as f:
        f.write("\n# tamper\n")
    res["H02_R3_TAMPER"] = run_orch(h_ok, r3_bad, "fake", att(), qs3)
    res["SIGARGS"] = run_orch(h_ok, w["adapter"], "fake", att(), qs3, {"QS4_FAKE": "sigargs:T18_P5_CTRL_C#0"})
    res["DIRTY"] = run_orch(h_ok, w["adapter"], "fake", att(), qs3, {"QS4_FAKE": "dirty:T16_K1#1"})
    res["BLOCK_AFTER_FRONTIER"] = run_orch(h_ok, w["adapter"], "fake", att(), qs3, {"QS4_TEST_BLOCK_AFTER_CASE": "REF_E3"})
    res["P5_PROBE_NOSIGNAL"] = run_orch(h_ok, w["adapter"], "fake", att(), qs3, {"QS4_TEST_P5_PROBE": "nosignal"})
    res["P5_PROBE_HELPERFAIL"] = run_orch(h_ok, w["adapter"], "fake", att(), qs3, {"QS4_TEST_P5_PROBE": "helperfail"})
    res["NO_PYCACHE_IN_TEST_HARNESSES"] = not any(d.name == "__pycache__" for h in (h_ok, h_wd) for d in h.rglob("*") if d.is_dir())
    res["PROTECTED_BEFORE_TOUCH"] = protected_digest(tc) == prot0
    cfgp = Path(tc["paths"]["control_root"]) / "FULL_2026_CONFIGURATION.json"
    cfg0 = cfgp.read_bytes()
    res["TOUCHCONTROL"] = run_orch(h_ok, w["adapter"], "fake", att(), qs3, {"QS4_FAKE": "touchcontrol:T16_K1#0"})
    cfgp.write_bytes(cfg0)  # TESTE: restaura o mundo de sandbox para o próximo cenário
    res["RESTORED_BEFORE_BLOCK_TOUCH"] = protected_digest(tc) == prot0
    # bloqueio (exit 2) DEPOIS de um efeito protegido: finish() recalcula os protegidos e eleva para 3
    res["BLOCK_AFTER_TOUCH"] = run_orch(h_ok, w["adapter"], "fake", att(), qs3,
                                        {"QS4_FAKE": "touchcontrol:REF_E3#0", "QS4_TEST_BLOCK_AFTER_CASE": "REF_E3"})
    cfgp.write_bytes(cfg0)
    return res


def real_orchestrator(work: Path) -> dict:
    w = W.build_world(work)
    tc = w["tc"]
    hc0 = json.loads((W.HARNESS / "qs4_constants.json").read_text(encoding="utf-8"))
    keep = [c["id"] for c in hc0["cases"]]  # plano COMPLETO (24 casos); cada caso para no 1º passo (RunLock/Win32)
    h, hc = W.make_test_harness(work, "REAL", w["a_ident"], {"heartbeat_seconds": 5})
    qs3 = W.build_qs3(Path(hc["paths"]["evidence_base"]), hc["prior_qs3"]["adapter_identity_sha256"], hc["prior_qs3"]["package_zip_sha256"])
    prot0 = protected_digest(tc)
    att = ATT.format(9000, 0x9000)
    r = run_orch(h, w["adapter"], "real", att, qs3, {"QS4_TEST_SEAM_PROBE": "1"})
    r["protected_unchanged_external"] = protected_digest(tc) == prot0
    ev = Path(hc["paths"]["evidence_base"]) / att / "HARNESS" / "CASES"
    det = {}
    for cid in keep:
        sd0 = sorted((ev / cid / "R1").glob("0_*")) if (ev / cid / "R1").is_dir() else []
        rp = (sd0[0] / "STEP_RECEIPT.json") if sd0 else ev / cid / "NONE"
        if rp.is_file():
            d = json.loads(rp.read_text(encoding="utf-8"))
            out_txt = (sd0[0] / "stdout.txt").read_text(encoding="utf-8", errors="replace")
            det[cid] = {"outcome": d["outcome"], "gates": [g["id"] + ":" + str(g["status"]) for g in d["gates"]],
                        "seams": d.get("seams"), "template_mode": d.get("template_mode"), "t31b": d.get("t31b"),
                        "state_after": d.get("state_after"), "t30_foreign": (d.get("t30") or {}).get("foreign"),
                        "seamset_probe": [ln for ln in out_txt.splitlines() if ln.startswith("QS4_TEST_SEAMSET_ENTER")],
                        "traceback_last": (d.get("traceback_tail") or "").strip().splitlines()[-1:]}
    r["step_details"] = det
    return r


def real_direct(work: Path) -> dict:
    """T22 (identidade do adapter) com fluxo REAL: passo 1 grava RUN binding no caso; passo 2 com adapter VARIANTE."""
    w = W.build_world(work)
    tc = w["tc"]
    sys.path.insert(0, str(W.HARNESS))
    import qs4_lib as L
    sys.path.insert(0, str(w["adapter"]))
    from phase_b_effects import canonical_hash, inventory, inventory_digest, write_json_durable
    real_control = Path(tc["paths"]["control_root"])
    shadow = Path(w["hc"]["paths"]["qs4_shadow_base"]) / ATT.format(9100, 0x9100)
    root = shadow / "CASES" / "T22_ADAPTER_IDENTITY" / "CONTROL"
    L.guard_case_root(root, shadow, real_control)
    L.seed_case_root(real_control, root, tc["control_prepared"]["files"], tc["control_prepared"]["dirs"])
    o2d = L.ordinal_map(tc["paths"]["preflight_root"])
    ev = Path(w["hc"]["paths"]["evidence_base"]) / ATT.format(9100, 0x9100) / "HARNESS"
    tmpl = ev / "QS3_TEMPLATE.json"
    write_json_durable(tmpl, W.TEMPLATE, exclusive=True)
    # adapter VARIANTE (mesmo código e constantes; identidade diferente) — mesma receita de Orchestrator.ensure_variant
    var = shadow / "VARIANT_ADAPTER" / "PHASE_B_ADAPTER_V001"
    shutil.copytree(w["adapter"], var)
    with (var / "qualification" / "QUALIFICATION_PLAN.md").open("a", encoding="utf-8", newline="\n") as f:
        f.write("\n<!-- QS4 T22 VARIANT test -->\n")
    W.run_build_package(var)
    var_ident = L.verify_manifest_dir(var, "MANIFEST_SHA256.txt", "ADAPTER_IDENTITY.json")["manifest_sha256"]
    out = {"variant_identity": var_ident, "r3_test_identity": w["adapter_identity"]}
    csha = hashlib.sha256((w["adapter"] / "phase_b_constants.json").read_bytes()).hexdigest().upper()

    def step(i, adapter_dir, stop):
        sdir = ev / "CASES" / "T22_ADAPTER_IDENTITY" / str(i)
        sdir.mkdir(parents=True)
        st = {"case": "T22_ADAPTER_IDENTITY", "step_index": i, "kind": "RUN" if i == 0 else "RESUME", "stop": stop,
              "safety_ordinal": 4, "invocation_attempt_id": ATT.format(9101 + i, 0x9101 + i), "step_dir": str(sdir),
              "root": str(root), "adapter_dir": str(adapter_dir), "adapter_constants_sha256": csha,
              "attempt_shadow": str(shadow), "g18_base": str(shadow / "G18"),
              "invocations_evidence_base": str(ev / "INVOCATIONS"),
              "ordinal_to_date": {str(k): v for k, v in o2d.items()}, "template": "QS3" if i == 0 else "NONE",
              "template_path": str(tmpl), "template_sha256": canonical_hash(W.TEMPLATE), "block_max_s": 5.0}
        write_json_durable(sdir / "STEP.json", st, exclusive=True)
        r = subprocess.run([sys.executable, "-B", str(HERE / "qs4_invoke_wrapper.py"), str(W.HARNESS), "--step-json",
                            str(sdir / "STEP.json")], capture_output=True, text=True,
                           env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1", QS4_TEST_SEAM_PROBE="1"))
        v = L.verify_receipt_with_companion(sdir / "STEP_RECEIPT.json", L.STEP_RECEIPT_SCHEMA, st["invocation_attempt_id"],
                                            exit_code=0)
        d = v.get("doc") or {}
        return {"exit": r.returncode, "receipt_valid": v["valid"], "outcome": d.get("outcome"),
                "gates": [g["id"] + ":" + str(g["status"]) for g in d.get("gates", [])],
                "root_unchanged": d.get("root_digest_before") == d.get("root_digest_after"),
                "state_after": d.get("state_after"), "seams": d.get("seams"), "blocked_gate": d.get("blocked_gate"),
                "state_after_findings": d.get("state_after_findings"), "quarantine": d.get("quarantine"),
                "seamset_probe": [ln for ln in r.stdout.splitlines() if ln.startswith("QS4_TEST_SEAMSET_ENTER")],
                "run_binding_present": (root / tc["run_owned_names"]["run_binding"]).is_file(),
                "stderr_tail": r.stderr[-800:]}
    out["step0"] = step(0, w["adapter"], {"interrupt_target": "RUNLOCK_ENTER"})
    root_before = inventory_digest(inventory(root))
    out["step1_variant"] = step(1, var, {"anchor_ordinal": 4})
    out["root_unchanged_by_variant"] = inventory_digest(inventory(root)) == root_before
    return out


def main(argv) -> int:
    scen, outp = argv[0], Path(argv[1]).resolve()
    work = Path(tempfile.mkdtemp(prefix="qs4e2e_" + scen + "_"))
    os.chdir(work)
    fn = {"fake-matrix": fake_matrix, "real-orchestrator": real_orchestrator, "real-direct": real_direct,
          "resume-matrix": resume_matrix, "state-transfer": state_transfer}[scen]
    res = fn(work)
    res["work"] = str(work)
    outp.write_text(json.dumps(res, indent=1, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    print("QS4_E2E_DONE " + scen)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
