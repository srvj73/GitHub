"""PHASE_B_QS4_HARNESS_V001 — executor QS1-H com receipt (contagem de testes derivada fisicamente).
Uso: MINOTAURO_E01_PAYLOAD=<payload> MINOTAURO_R3_DIR=<R3 extraído> MINOTAURO_PWSH=<pwsh>
     python -B tests/run_qs4_qs1.py <receipt_out.json>
O receipt prova também que o R3, o payload E01 e a própria árvore do harness ficaram byte-idênticos."""
import hashlib
import json
import os
import sys
import time
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))


def tree_digest(root):
    h = {}
    for p in sorted(Path(root).rglob("*")):
        if p.is_file():
            h[p.relative_to(root).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest().upper()
    return hashlib.sha256(json.dumps(h, sort_keys=True).encode()).hexdigest().upper(), len(h)


def sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()


def main(out):
    if sys.flags.dont_write_bytecode != 1 or os.environ.get("PYTHONDONTWRITEBYTECODE") != "1":
        print("QS1_H_BYTECODE=BLOCKED")
        return 2
    payload = Path(os.environ["MINOTAURO_E01_PAYLOAD"])
    r3 = Path(os.environ["MINOTAURO_R3_DIR"])
    harness = HERE.parent
    ident = json.loads((harness / "HARNESS_IDENTITY.json").read_text(encoding="utf-8"))
    r3_ident = json.loads((r3 / "ADAPTER_IDENTITY.json").read_text(encoding="utf-8"))
    manifest_sha = sha_file(harness / "MANIFEST_SHA256.txt")
    pwsh = os.environ.get("MINOTAURO_PWSH")
    before = {"e01": tree_digest(payload), "r3": tree_digest(r3), "harness": tree_digest(harness)}
    suite = unittest.defaultTestLoader.loadTestsFromName("test_qs4")
    results = []

    class R(unittest.TextTestResult):
        def addSuccess(self, t):
            super().addSuccess(t); results.append({"test": t.id(), "result": "PASS"})

        def addFailure(self, t, e):
            super().addFailure(t, e); results.append({"test": t.id(), "result": "FAIL", "detail": self._exc_info_to_string(e, t)[-3000:]})

        def addError(self, t, e):
            super().addError(t, e); results.append({"test": t.id(), "result": "ERROR", "detail": self._exc_info_to_string(e, t)[-3000:]})
    t0 = time.time()
    r = unittest.TextTestRunner(verbosity=2, resultclass=R).run(suite)
    after = {"e01": tree_digest(payload), "r3": tree_digest(r3), "harness": tree_digest(harness)}
    identity_ok = ident["harness_identity_sha256"] == manifest_sha == ident["manifest_sha256"]
    r3_ok = r3_ident["adapter_identity_sha256"] == sha_file(r3 / "MANIFEST_SHA256.txt") == \
        "05A0CF3D807A63BA7FD5BB36374D93E56E3D727183CFD3C62D3C0D637F1DDD0A"
    unchanged = {k: before[k] == after[k] for k in before}
    import test_qs4 as T
    rec = {"schema": "MINOTAURO_PHASE_B_QS4_HARNESS_QS1_RECEIPT_V001", "python": sys.version.split()[0], "platform": sys.platform,
           "harness_identity_sha256": ident["harness_identity_sha256"], "harness_manifest_recomputed_sha256": manifest_sha,
           "harness_identity_matches_manifest": identity_ok,
           "r3_identity_sha256": r3_ident["adapter_identity_sha256"], "r3_identity_is_pinned_r3": r3_ok,
           "tree_digests_before": {k: {"sha256": v[0], "files": v[1]} for k, v in before.items()},
           "tree_digests_after": {k: {"sha256": v[0], "files": v[1]} for k, v in after.items()},
           "unchanged": unchanged,
           "pwsh": pwsh, "pwsh_sha256": sha_file(pwsh) if pwsh and Path(pwsh).is_file() else None,
           "tests_run": r.testsRun, "passed": sum(1 for x in results if x["result"] == "PASS"),
           "failed": len(r.failures), "errors": len(r.errors), "results": results,
           "e2e_observations": T.E2E_CACHE,
           "seconds": round(time.time() - t0, 1),
           "qs4_executed": "NO", "owner_pc_touched": "NO", "run_released": "NO", "phase_c_execution": "NO",
           "result": "PASS" if r.wasSuccessful() and all(unchanged.values()) and identity_ok and r3_ok else "FAIL"}
    Path(out).write_text(json.dumps(rec, indent=1, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    print("QS1_H_RESULT=" + rec["result"], "TESTS=" + str(r.testsRun))
    return 0 if rec["result"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
