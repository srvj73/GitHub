"""PHASE_B_QS4_HARNESS_V001 — QS1-H (qualificação pré-entrega do harness na sandbox). Executar via tests/run_qs4_qs1.py.
Requer MINOTAURO_E01_PAYLOAD, MINOTAURO_R3_DIR (R3 extraído, intocado) e, opcionalmente, MINOTAURO_PWSH.
Nada aqui toca o PC do owner; tudo roda em diretórios temporários. Dados sintéticos são rotulados.
"""
from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import types
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
HARNESS = HERE.parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HARNESS))
import qs4_lib as L  # noqa: E402
import qs4_world as W  # noqa: E402

R3 = Path(os.environ["MINOTAURO_R3_DIR"])
PAYLOAD = Path(os.environ["MINOTAURO_E01_PAYLOAD"])
sys.path.insert(0, str(R3))
from phase_b_effects import canonical_hash, write_json_durable  # noqa: E402  (módulos NÃO-CODE do R3)

C = L.load_constants(HARNESS / "qs4_constants.json")
C_O2D = L.ordinal_map(PAYLOAD / "PREFLIGHT")
R3C = json.loads((R3 / "phase_b_constants.json").read_text(encoding="utf-8"))
SCRATCH = Path(tempfile.mkdtemp(prefix="qs4_qs1_"))
E2E_CACHE: dict = {}


def e2e(scen: str) -> dict:
    """Executa (uma vez) um cenário ponta a ponta em subprocesso próprio (cwd = mundo literal temporário)."""
    if scen not in E2E_CACHE:
        out = SCRATCH / f"e2e_{scen}.json"
        r = subprocess.run([sys.executable, "-B", str(HERE / "qs4_e2e.py"), scen, str(out)], capture_output=True, text=True,
                           env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"), timeout=7200)
        if r.returncode != 0:
            raise AssertionError("E2E_DRIVER_FAILED " + scen + " " + r.stderr[-3000:])
        E2E_CACHE[scen] = json.loads(out.read_text(encoding="utf-8"))
    return E2E_CACHE[scen]


def code_of(fn):
    try:
        fn()
    except L.HarnessBlocked as e:
        return e.code
    except Exception as e:  # noqa: BLE001
        return "EXC:" + type(e).__name__ + ":" + str(e)[:80]
    return "NO_ERROR"


# =========================================================================== constants / plan
class H_Constants(unittest.TestCase):
    def test_plan_shape_and_closed_lists(self):
        sys.path.insert(0, str(R3 / "qualification"))
        try:
            import phase_b_qualification_seams as q
            targets, faults = set(q.INTERRUPT_TARGETS), set(q.FAULT_POINTS)
        finally:
            sys.modules.pop("phase_b_qualification_seams", None)
            sys.path.remove(str(R3 / "qualification"))
        cases = C["cases"]
        self.assertEqual(len(cases), 24)
        self.assertEqual(sum(len(c["steps"]) for c in cases), 45)
        used_t = {s["stop"]["interrupt_target"] for c in cases for s in c["steps"] if "interrupt_target" in s["stop"]}
        used_f = {s["stop"]["fault"] for c in cases for s in c["steps"] if "fault" in s["stop"]}
        self.assertTrue(used_t <= targets)
        self.assertEqual(used_f, faults)  # T18 P7 cobre TODOS os pontos de falha congelados
        self.assertEqual(len([c for c in cases if c["id"].startswith("T18_")]), 15)
        self.assertEqual(len([c for c in cases if "T18" in c["covers"]]), 16)
        from phase_b_state import BLOCKED, EMPTY, FINAL_VALID, IN_PROGRESS, PREPARED
        states = {s["expect"]["state_after"] for c in cases for s in c["steps"] if "state_after" in s["expect"]}
        self.assertTrue(states <= {BLOCKED, EMPTY, FINAL_VALID, IN_PROGRESS, PREPARED}, states)
        self.assertEqual(C["adapter"]["identity_sha256"], "05A0CF3D807A63BA7FD5BB36374D93E56E3D727183CFD3C62D3C0D637F1DDD0A")
        self.assertEqual(C["adapter"]["package_zip_sha256"], "F14E7B149BDFB5184D09116122C7A6264F7A4798E08799DEBD852B45E959A775")
        self.assertEqual(C["adapter"]["constants_sha256"], L.sha_file(R3 / "phase_b_constants.json"))
        for c in cases:
            fam_end = C["endpoints"][c["family"]]
            for s in c["steps"]:
                if "anchor_ordinal" in s["stop"]:
                    self.assertLessEqual(s["stop"]["anchor_ordinal"], fam_end)
                if s["kind"] == "RESUME":
                    self.assertNotIn("template", s)  # retomada nunca recebe template (state IN_PROGRESS)
        # referências usam o endpoint da família
        refs = {c["id"]: c for c in cases if c["id"].startswith("REF_")}
        self.assertEqual(refs["REF_E3"]["steps"][0]["stop"]["anchor_ordinal"], C["endpoints"]["E3"])
        self.assertEqual(refs["REF_E23"]["steps"][0]["stop"]["anchor_ordinal"], C["endpoints"]["E23"])
        self.assertEqual([c["id"] for c in cases].index("REF_E3"), 0)
        self.assertLess([c["id"] for c in cases].index("REF_E23"), [c["id"] for c in cases].index("T16_K21"))

    def test_harness_envelope_pin_and_identity(self):
        v = L.verify_harness_package(HARNESS)
        self.assertEqual(L.sha_file(HARNESS / "qualification" / C["harness_envelope"]["file"]), C["harness_envelope"]["sha256"])
        ident = json.loads((HARNESS / "HARNESS_IDENTITY.json").read_text(encoding="utf-8"))
        self.assertEqual(ident["harness_identity_sha256"], v["manifest_sha256"])
        self.assertEqual(ident["adapter_identity_sha256"], C["adapter"]["identity_sha256"])

    def test_json_duplicate_key_and_schema(self):
        self.assertEqual(code_of(lambda: L.load_json_bytes(b'{"a":1,"a":2}')), "JSON_DUPLICATE_KEY")
        self.assertEqual(code_of(lambda: L.load_json_bytes(b'{"a":')), "JSON_INVALID")
        p = SCRATCH / "c.json"
        p.write_text(json.dumps({"schema": "X", "cases": []}))
        self.assertEqual(code_of(lambda: L.load_constants(p)), "QS4_CONSTANTS_SCHEMA")


# =========================================================================== packages (H00/H02)
class H_Packages(unittest.TestCase):
    def test_r3_identity_positive_and_tamper(self):
        v = L.verify_r3_package(R3, C)
        self.assertEqual(v["manifest_sha256"], C["adapter"]["identity_sha256"])
        cp = SCRATCH / "r3copy"
        shutil.copytree(R3, cp)
        with (cp / "phase_b_shared.py").open("a") as f:
            f.write("#x\n")
        self.assertEqual(code_of(lambda: L.verify_r3_package(cp, C)), "PACKAGE_MEMBER_HASH")
        (cp / "phase_b_shared.py").write_bytes((R3 / "phase_b_shared.py").read_bytes())
        (cp / "extra.py").write_text("x")
        self.assertEqual(code_of(lambda: L.verify_r3_package(cp, C)), "PACKAGE_EXACT_PAYLOAD")
        (cp / "extra.py").unlink()
        (cp / "__pycache__").mkdir()
        self.assertEqual(code_of(lambda: L.verify_r3_package(cp, C)), "PACKAGE_PYCACHE_PRESENT")
        (cp / "__pycache__").rmdir()
        c2 = json.loads(json.dumps({k: v for k, v in C.items()}))
        c2["adapter"]["identity_sha256"] = "0" * 64
        self.assertEqual(code_of(lambda: L.verify_r3_package(cp, c2)), "R3_IDENTITY_MISMATCH")

    def test_harness_tamper(self):
        cp = SCRATCH / "hcopy"
        shutil.copytree(HARNESS, cp, ignore=shutil.ignore_patterns("__pycache__"))
        L.verify_harness_package(cp)
        with (cp / "qs4_flow.py").open("a") as f:
            f.write("#x\n")
        self.assertEqual(code_of(lambda: L.verify_harness_package(cp)), "PACKAGE_MEMBER_HASH")


# =========================================================================== H01 prior QS3
class H01_PriorQS3(unittest.TestCase):
    def mk(self, **mut):
        base = Path(tempfile.mkdtemp(prefix="h01_", dir=SCRATCH)) / "EVIDENCE"
        q = W.build_qs3(base, C["prior_qs3"]["adapter_identity_sha256"], C["prior_qs3"]["package_zip_sha256"], mut)
        return base, q

    def val(self, base, q, sha=None, path=None):
        return L.validate_prior_qs3(path or q["path"], sha or q["sha"], C, str(base), canonical_hash)

    def test_positive_returns_template_and_bindings(self):
        base, q = self.mk()
        self.assertNotEqual(C["prior_qs3"]["adapter_identity_sha256"], C["adapter"]["identity_sha256"])
        self.assertNotEqual(C["prior_qs3"]["package_zip_sha256"], C["adapter"]["package_zip_sha256"])
        r = self.val(base, q)
        self.assertEqual(r["template"], W.TEMPLATE)
        self.assertEqual(r["template_sha256"], canonical_hash(W.TEMPLATE))
        self.assertEqual(r["qs3_receipt_sha256"], q["sha"])

    def test_negatives(self):
        cases = {
            "dry_scope": ({"dry_scope": "PRE_SHADOW_ONLY"}, "H01_QS3_DRY_RECEIPT_BINDING"),
            "template_sha_wrong": ({"template_sha_wrong": True}, "H01_QS3_DRY_RECEIPT_BINDING"),
            "dry_binding": ({"dry_binding": True}, "H01_QS3_DRY_RECEIPT_BINDING"),
            "item_fail": ({"item_fail": "T27"}, "H01_QS3_ITEM_NOT_PASS"),
            "item_missing": ({"item_missing": "T19_template"}, "H01_QS3_ITEM_MISSING"),
            "identity": ({"identity": "A" * 64}, "H01_QS3_OTHER_ADAPTER"),
            "zip": ({"zip": "B" * 64}, "H01_QS3_OTHER_ZIP"),
            "final_exit": ({"final_exit": 2}, "H01_QS3_FINAL_EXIT_NOT_ZERO"),
            "not_clean": ({"not_clean": True}, "H01_QS3_NOT_CLEAN"),
            "companion_missing": ({"companion_missing": True}, "H01_QS3_COMPANION_MISSING"),
            "log_dup": ({"log_dup": True}, "H01_QS3_LOG_BINDING"),
            "log_final_2": ({"log_final_2": True}, "H01_QS3_LOG_FINAL_EXIT"),
            "tamper_after": ({"tamper_after": True}, "H01_QS3_RECEIPT_SHA_MISMATCH"),
            "bstatus_fail": ({"bstatus_fail": True}, "H01_QS3_FINAL_STATUS"),
            "qs2_fail": ({"qs2_fail": True}, "H01_QS2_RECEIPT_CONTENT"),
        }
        got = {}
        for name, (mut, _want) in cases.items():
            base, q = self.mk(**mut)
            got[name] = code_of(lambda: self.val(base, q))
        # dry_scope/template_sha_wrong mudam o DRY_RECEIPT -> o SHA vinculado no QS3 (gerado antes) ainda bate;
        # a falha esperada é de CONTEÚDO/TEMPLATE, não de vínculo: verificar exatamente
        expected = {k: v[1] for k, v in cases.items()}
        expected["dry_scope"] = "H01_QS3_DRY_RECEIPT_CONTENT"
        expected["template_sha_wrong"] = "H01_QS3_TEMPLATE"
        self.assertEqual(got, expected)

    def test_path_and_param_negatives(self):
        base, q = self.mk()
        self.assertEqual(code_of(lambda: self.val(base, q, path="relative/QS3_RECEIPT.json")), "H01_QS3_RECEIPT_PATH_NOT_ABSOLUTE")
        self.assertEqual(code_of(lambda: self.val(base, q, sha="xyz")), "H01_QS3_SHA_PARAM_INVALID")
        self.assertEqual(code_of(lambda: self.val(base, q, sha="0" * 64)), "H01_QS3_RECEIPT_SHA_MISMATCH")
        moved = Path(q["path"]).parent.parent / "COPY_QS3_RECEIPT.json"
        shutil.copyfile(q["path"], moved)
        self.assertEqual(code_of(lambda: self.val(base, q, path=str(moved))), "H01_QS3_RECEIPT_LOCATION")
        self.assertEqual(code_of(lambda: L.validate_prior_qs3(q["path"], q["sha"], C, str(base) + "_OTHER", canonical_hash)),
                         "H01_QS3_RECEIPT_LOCATION")
        # status do DRY divergente do vínculo
        base2, q2 = self.mk()
        st = Path(q2["dir"]) / "ADAPTER" / "ADAPTER_STATUS.json"
        st.write_bytes(st.read_bytes() + b" ")
        self.assertEqual(code_of(lambda: self.val(base2, q2)), "H01_QS3_DRY_STATUS_BINDING")
        # companion do DRY ausente
        base3, q3 = self.mk()
        (Path(q3["dir"]) / "ADAPTER" / "DRY_RECEIPT.VERIFIED.json").rename(Path(q3["dir"]) / "ADAPTER" / "X.json")
        self.assertEqual(code_of(lambda: self.val(base3, q3)), "H01_QS3_DRY_RECEIPT_NOT_VERIFIED")
        # QS2 citado alterado depois do QS3
        base4, q4 = self.mk()
        q4["qs2"].write_bytes(q4["qs2"].read_bytes() + b" ")
        self.assertEqual(code_of(lambda: self.val(base4, q4)), "H01_QS2_RECEIPT_BINDING")

    def test_r1_03_qs3_companions_contradictory(self):
        """R1-03 aplicado ao H01: companions do bootstrap QS3 e do DRY com contrato completo."""
        def patched(rel, **chg):
            base, q = self.mk()
            cp = Path(q["dir"]) / rel
            d = json.loads(cp.read_text(encoding="utf-8-sig"))
            for k, v in chg.items():
                if v is None:
                    d.pop(k, None)
                else:
                    d[k] = v
            cp.write_text(json.dumps(d), encoding="utf-8")
            return code_of(lambda: self.val(base, q))
        for chg in ({"readback": "FAIL"}, {"readback": None}, {"schema": "X"}, {"stage": "QS2_PREFLIGHT"}, {"final_exit": 3}):
            self.assertEqual(patched("QS3_RECEIPT.VERIFIED.json", **chg), "H01_QS3_COMPANION_MISMATCH", chg)
        for chg in ({"readback": "FAIL"}, {"schema": "X"}, {"attempt_id": "20261003T000000Z_0000000f"}, {"exit_code": 3},
                    {"mode": "RUN"}):
            self.assertEqual(patched("ADAPTER/DRY_RECEIPT.VERIFIED.json", **chg), "H01_QS3_DRY_RECEIPT_NOT_VERIFIED", chg)


# =========================================================================== calendar / guards / seed
class H_CalendarGuardsSeed(unittest.TestCase):
    def test_calendar_real_preflight(self):
        o2d = L.ordinal_map(PAYLOAD / "PREFLIGHT")
        self.assertEqual(len(o2d), 166)
        self.assertEqual((o2d[1], o2d[2], o2d[4], o2d[21], o2d[22], o2d[24]),
                         ("2026-01-02", "2026-01-05", "2026-01-07", "2026-01-30", "2026-02-02", "2026-02-04"))
        L.check_calendar(o2d, C)
        c2 = json.loads(json.dumps(C))
        c2["calendar_expectations"]["january_last_ordinal"] = 20
        self.assertEqual(code_of(lambda: L.check_calendar(o2d, c2)), "QS4_CALENDAR_EXPECTATION")
        c3 = json.loads(json.dumps(C))
        c3["endpoints"]["E23"] = 999
        self.assertEqual(code_of(lambda: L.check_calendar(o2d, c3)), "QS4_ENDPOINT_OUT_OF_CALENDAR")

    def test_guard_case_root(self):
        base = Path(tempfile.mkdtemp(prefix="guard_", dir=SCRATCH))
        shadow, real = base / "SHADOW" / "att", base / "RELEASE" / "CONTROL"
        shadow.mkdir(parents=True)
        real.mkdir(parents=True)
        L.guard_case_root(shadow / "CASES" / "X" / "CONTROL", shadow, real)
        self.assertEqual(code_of(lambda: L.guard_case_root(base / "ELSEWHERE", shadow, real)), "QS4_ROOT_OUTSIDE_OWNED_SHADOW")
        self.assertEqual(code_of(lambda: L.guard_case_root(real / "x", shadow, real)), "QS4_ROOT_OUTSIDE_OWNED_SHADOW")
        self.assertEqual(code_of(lambda: L.guard_case_root(shadow, shadow / "CASES" / "X", real)), "QS4_ROOT_OUTSIDE_OWNED_SHADOW")
        (shadow / "LINK").symlink_to(base / "RELEASE")
        self.assertEqual(code_of(lambda: L.guard_case_root(shadow / "LINK" / "CONTROL", shadow, real)), "QS4_ROOT_LINK")
        # raiz real DENTRO do shadow (configuração absurda) também bloqueia
        self.assertEqual(code_of(lambda: L.guard_case_root(shadow / "R", shadow, shadow / "R" / "CONTROL")),
                         "QS4_ROOT_OUTSIDE_OWNED_SHADOW")

    def test_seed_exact_23_and_negatives(self):
        base = Path(tempfile.mkdtemp(prefix="seed_", dir=SCRATCH))
        r = L.seed_case_root(PAYLOAD / "CONTROL", base / "A", R3C["control_prepared"]["files"], R3C["control_prepared"]["dirs"])
        self.assertEqual(r, {"files": 23, "dirs": len(R3C["control_prepared"]["dirs"])})
        files = sorted(p.relative_to(base / "A").as_posix() for p in (base / "A").rglob("*") if p.is_file())
        self.assertEqual(files, sorted(e["path"] for e in R3C["control_prepared"]["files"]))
        self.assertEqual(code_of(lambda: L.seed_case_root(PAYLOAD / "CONTROL", base / "A", R3C["control_prepared"]["files"], [])),
                         "QS4_CASE_ROOT_EXISTS")
        src = base / "SRC"
        shutil.copytree(PAYLOAD / "CONTROL", src)
        p = src / R3C["control_prepared"]["files"][0]["path"]
        p.write_bytes(p.read_bytes() + b"x")
        self.assertEqual(code_of(lambda: L.seed_case_root(src, base / "B", R3C["control_prepared"]["files"], [])),
                         "QS4_SEED_HASH")


# =========================================================================== DD-7 state comparison / growth
class H_StateCompare(unittest.TestCase):
    def mkroot(self, name, sessions, cp):
        r = Path(tempfile.mkdtemp(prefix=name, dir=SCRATCH))
        for d, files in sessions.items():
            (r / "PHASE_B" / "sessions" / d).mkdir(parents=True)
            for n, b in files.items():
                (r / "PHASE_B" / "sessions" / d / n).write_bytes(b)
        (r / "PHASE_B").mkdir(exist_ok=True)
        if cp is not None:
            (r / "PHASE_B" / "CHECKPOINT.json").write_text(json.dumps(cp))
        return r

    def test_volatile_keys_ignored_and_diff_names_only(self):
        vol = C["checkpoint_volatile_keys"]
        s = {"2026-01-02": {"trades.jsonl.gz": b"SYNTH_A" * 10}, "2026-01-05": {"trades.jsonl.gz": b"SYNTH_B"}}
        cp = {"completed": ["2026-01-02", "2026-01-05"], "cash": 123.0, "config_sha256": "A" * 64,
              "checkpoint_content_sha256": "1" * 64, "nested": {"x": 1}}
        a = L.state_digest(self.mkroot("a", s, cp), vol)
        cp_b = dict(cp, config_sha256="B" * 64, checkpoint_content_sha256="2" * 64)
        b = L.state_digest(self.mkroot("b", s, cp_b), vol)
        self.assertEqual(L.compare_states(a, b), {"equal": True, "diffs": []})
        cp_c = dict(cp, cash=124.0, nested={"x": 2})
        c = L.state_digest(self.mkroot("c", s, cp_c), vol)
        d = L.compare_states(a, c)
        self.assertFalse(d["equal"])
        self.assertEqual(sorted(d["diffs"]), ["CHECKPOINT_KEY:cash", "CHECKPOINT_KEY:nested.x"])
        self.assertNotIn("124", json.dumps(d))  # DD-7: nenhum valor no diff
        s2 = {"2026-01-02": {"trades.jsonl.gz": b"SYNTH_A" * 10}, "2026-01-05": {"trades.jsonl.gz": b"SYNTH_X"}}
        e = L.compare_states(a, L.state_digest(self.mkroot("e", s2, cp), vol))
        self.assertEqual(e["diffs"], ["SESSION_FILE:2026-01-05/trades.jsonl.gz"])
        f = L.compare_states(a, L.state_digest(self.mkroot("f", {"2026-01-02": s["2026-01-02"]}, cp), vol))
        self.assertEqual(f["diffs"], ["SESSIONS_SET:2026-01-05"])
        g = L.compare_states(a, L.state_digest(self.mkroot("g", s, None), vol))
        self.assertEqual(g["diffs"], ["PHASE_B_FILE_SET:CHECKPOINT.json", "CHECKPOINT_PRESENCE"])
        r_j = self.mkroot("j", s, cp)
        (r_j / "PHASE_B" / "_commit_journal").mkdir()
        (r_j / "PHASE_B" / "_commit_journal" / "2026-01-05.1_1.json").write_text("{}")
        self.assertEqual(L.compare_states(a, L.state_digest(r_j, vol))["diffs"], ["PHASE_B_FILE_SET:_commit_journal/2026-01-05.1_1.json"])

    def test_growth_sizes_only(self):
        r = self.mkroot("gr", {"2026-01-02": {"a": b"\0" * 100}, "2026-01-05": {"a": b"\0" * 300}}, {"completed": []})
        (r / "TELEMETRY").mkdir()
        (r / "TELEMETRY" / "t.jsonl").write_bytes(b"\0" * 10)
        g = L.growth(r, 166)
        self.assertEqual((g["max_session_bytes"], g["mean_session_bytes"], g["telemetry_bytes"]), (300, 200, 10))
        self.assertEqual(g["projected_run_growth_bytes_166"], 300 * 166 + 20)
        self.assertIn("NÃO aplicada", g["note"])


# =========================================================================== expectations / receipts
class H_EvaluateAndReceipts(unittest.TestCase):
    def rec(self, **kw):
        base = {"outcome": {"class": "INTERRUPT_SEAM", "seam": "QS4_STOP_ANCHOR", "code": "session=2026-01-07"},
                "safe_stop_requested_line": True, "committed_count": 3, "trace_guard": "PASS_COMPARED",
                "runtime_evidence": {"started": True, "clean": True}, "t30": {"foreign": []},
                "root_digest_before": "A", "root_digest_after": "B", "t31b": {"journal_after_g21": 0, "stale_line_before_g21": False}}
        base.update(kw)
        return base

    def test_matrix(self):
        E = {"outcome": "INTERRUPT_SEAM", "seam": "QS4_STOP_ANCHOR", "code": "session=2026-01-07", "safe_stop_line": True,
             "guard": "PASS_COMPARED"}
        ev = L.evaluate_step
        self.assertTrue(ev(E, self.rec())["pass"])
        self.assertFalse(ev(E, self.rec(outcome={"class": "INTERRUPT_SEAM", "seam": "QS4_STOP_ANCHOR", "code": "session=2026-01-06"}))["pass"])
        self.assertFalse(ev(E, self.rec(outcome={"class": "INTERRUPT_SIGNAL", "seam": None, "code": None}))["pass"])
        self.assertEqual(ev(E, self.rec(safe_stop_requested_line=False))["reasons"], ["SAFE_STOP_REQUESTED_LINE_MISSING"])
        self.assertEqual(ev(E, self.rec(trace_guard="PASS_NOT_APPLICABLE"))["reasons"], ["TRACE_GUARD_NOT_COMPARED:PASS_NOT_APPLICABLE"])
        self.assertEqual(ev(E, self.rec(runtime_evidence={"started": True, "clean": False}))["reasons"], ["PROCESS_TREE_NOT_CLEAN"])
        self.assertEqual(ev(E, self.rec(t30={"foreign": ["control:_avast_"]}))["reasons"], ["T30_FOREIGN_ENTRY"])
        E2 = {"outcome": "INTERRUPT_SEAM", "seam": "SEAM_INTERRUPT_AFTER", "safe_stop_line": False}
        self.assertEqual(ev(E2, self.rec(outcome={"class": "INTERRUPT_SEAM", "seam": "SEAM_INTERRUPT_AFTER", "code": "x"}))["reasons"],
                         ["SAFE_STOP_REQUESTED_LINE_UNEXPECTED"])
        E3 = {"outcome": "TRACE_GUARD", "code": "TRACE_GUARD_MISMATCH", "committed": 0}
        self.assertEqual(ev(E3, self.rec(outcome={"class": "TRACE_GUARD", "code": "TRACE_GUARD_MISMATCH", "seam": None}))["reasons"],
                         ["COMMITTED got=3 want=0"])
        E4 = {"outcome": "BLOCKED", "code": "STATE_BLOCKED_AMBIGUOUS", "root_unchanged": True, "blocked_gate": "G12",
              "detail_contains": "SEAL_KEY_FOREIGN:", "state_after": "BLOCKED_AMBIGUOUS"}
        blk = {"class": "BLOCKED", "code": "STATE_BLOCKED_AMBIGUOUS", "seam": None, "detail": "STATE_BLOCKED_AMBIGUOUS SEAL_KEY_FOREIGN:x"}
        okb = dict(outcome=blk, runtime_evidence={}, root_digest_after="A", blocked_gate="G12", state_after="BLOCKED_AMBIGUOUS")
        self.assertTrue(ev(E4, self.rec(**okb))["pass"])
        self.assertEqual(ev(E4, self.rec(**dict(okb, root_digest_after="B")))["reasons"], ["ROOT_CHANGED_ON_BLOCKED_STEP"])
        self.assertEqual(ev(E4, self.rec(**dict(okb, blocked_gate="G05")))["reasons"], ["BLOCKED_GATE got=G05 want=G12"])
        self.assertEqual(ev(E4, self.rec(**dict(okb, outcome=dict(blk, detail="STATE_BLOCKED_AMBIGUOUS UNKNOWN_ENTRY:x"))))["reasons"],
                         ["OUTCOME_DETAIL_MISSING:SEAL_KEY_FOREIGN:"])
        self.assertEqual(ev(E4, self.rec(**dict(okb, outcome=dict(blk, code="OTHER"))))["reasons"],
                         ["OUTCOME_CODE got=OTHER want=STATE_BLOCKED_AMBIGUOUS"])
        E5 = dict(E, t31b=True, journal_min=1)
        self.assertEqual(ev(E5, self.rec(t31b={"journal_before_g21": 1, "journal_after_g21": 1}))["reasons"], ["T31B_JOURNAL"])
        self.assertEqual(ev(E5, self.rec(t31b={"journal_before_g21": 0, "journal_after_g21": 0}))["reasons"], ["T31B_JOURNAL"])
        self.assertTrue(ev(E5, self.rec(t31b={"journal_before_g21": 1, "journal_after_g21": 0}))["pass"])
        # sem alternativas: chave desconhecida não relaxa nada
        E6 = {"outcome": "INTERRUPT_SEAM", "seam": "QS4_STOP_ANCHOR", "alternative": {"outcome": "FROZEN_ERROR"}}
        self.assertFalse(ev(E6, self.rec(outcome={"class": "FROZEN_ERROR", "code": "RUN_LOCK_OR_ORPHAN_ACTIVE", "seam": None}))["pass"])
        # estado final
        E7 = dict(E, state_after="IN_PROGRESS", clean_state=True, committed=3)
        good = dict(state_after="IN_PROGRESS", state_after_findings=[], state_after_detail={"journal": False, "pending": 0})
        self.assertTrue(ev(E7, self.rec(**good))["pass"])
        self.assertEqual(ev(E7, self.rec(**dict(good, state_after="BLOCKED")))["reasons"], ["STATE_AFTER got=BLOCKED want=IN_PROGRESS"])
        self.assertEqual(ev(E7, self.rec(**dict(good, state_after_detail={"journal": True, "pending": 0})))["reasons"], ["STATE_NOT_CLEAN"])
        self.assertEqual(ev(E7, self.rec(**dict(good, state_after_findings=["FINALIZE_PENDING"])))["reasons"], ["STATE_NOT_CLEAN"])
        E8 = {"outcome": "INTERRUPT_SEAM", "seam": "SEAM_INTERRUPT_AFTER", "state_after": "BLOCKED_AMBIGUOUS",
              "state_finding": "RUNTIME_RESIDUE_WITHOUT_CHECKPOINT"}
        r8 = self.rec(outcome={"class": "INTERRUPT_SEAM", "seam": "SEAM_INTERRUPT_AFTER", "code": "x"}, state_after="BLOCKED_AMBIGUOUS",
                      state_after_findings=["RUNTIME_RESIDUE_WITHOUT_CHECKPOINT", "RESIDUE:RUN.lock"])
        self.assertTrue(ev(E8, r8)["pass"])
        self.assertEqual(ev(E8, dict(r8, state_after_findings=["UNKNOWN_ENTRY:x"]))["reasons"],
                         ["STATE_FINDING_MISSING:RUNTIME_RESIDUE_WITHOUT_CHECKPOINT"])
        # P5: KeyboardInterrupt real não tem argumentos
        E9 = {"outcome": "INTERRUPT_SIGNAL", "signal_no_args": True}
        sig = {"class": "INTERRUPT_SIGNAL", "seam": None, "code": None}
        self.assertTrue(ev(E9, self.rec(outcome=dict(sig, detail_len=0)))["pass"])
        self.assertEqual(ev(E9, self.rec(outcome=dict(sig, detail_len=19)))["reasons"], ["SIGNAL_KEYBOARDINTERRUPT_HAS_ARGS"])
        # kind x state_before
        self.assertEqual(ev(E, self.rec(kind="RUN", state_before="IN_PROGRESS"))["reasons"], ["STATE_BEFORE got=IN_PROGRESS want=PREPARED"])
        self.assertEqual(ev(E, self.rec(kind="RESUME", state_before="PREPARED"))["reasons"], ["STATE_BEFORE got=PREPARED want=IN_PROGRESS"])
        self.assertTrue(ev(E, self.rec(kind="RESUME", state_before="IN_PROGRESS"))["pass"])

    def test_receipt_companion(self):
        d = Path(tempfile.mkdtemp(prefix="rc_", dir=SCRATCH))
        obj = {"schema": L.STEP_RECEIPT_SCHEMA, "attempt_id": "20261003T000000Z_00000001", "exit_code": 0}
        sha = L.write_receipt_with_companion(d / "R.json", obj, write_json_durable)
        v = L.verify_receipt_with_companion(d / "R.json", L.STEP_RECEIPT_SCHEMA, obj["attempt_id"], exit_code=0)
        self.assertTrue(v["valid"])
        self.assertEqual(v["sha256"], sha)
        self.assertEqual(L.verify_receipt_with_companion(d / "R.json", L.STEP_RECEIPT_SCHEMA, obj["attempt_id"], exit_code=3)["reason"],
                         "RECEIPT_EXIT_NE_NATIVE")
        self.assertEqual(L.verify_receipt_with_companion(d / "R.json", L.STEP_RECEIPT_SCHEMA, "x")["reason"], "RECEIPT_SCHEMA_OR_ATTEMPT")
        self.assertEqual(L.verify_receipt_with_companion(d / "NONE.json", L.STEP_RECEIPT_SCHEMA, "x")["reason"], "RECEIPT_MISSING")
        (d / "R.json").write_bytes((d / "R.json").read_bytes().replace(b'"exit_code":0', b'"exit_code": 0'))
        self.assertEqual(L.verify_receipt_with_companion(d / "R.json", L.STEP_RECEIPT_SCHEMA, obj["attempt_id"])["reason"],
                         "COMPANION_SHA_NE_RECEIPT")
        # gravação exclusiva: nunca sobrescreve
        self.assertRaises(Exception, L.write_receipt_with_companion, d / "R.json", obj, write_json_durable)

    def test_r1_03_contradictory_companion_blocks(self):
        """R1-03: companion contraditório nunca valida (probe externo: receipt exit 0, companion exit 3/readback FAIL)."""
        att = "20261003T000000Z_00000003"
        good = {"schema": L.STEP_RECEIPT_SCHEMA, "attempt_id": att, "exit_code": 0}

        def mk(receipt: dict, comp_patch=None, comp_drop=None, comp_raw=None):
            d = Path(tempfile.mkdtemp(prefix="r103_", dir=SCRATCH))
            raw = json.dumps(receipt, sort_keys=True).encode("utf-8")
            (d / "R.json").write_bytes(raw)
            comp = {"schema": L.VERIFIED_SCHEMA, "receipt_sha256": L.sha_bytes(raw), "attempt_id": receipt.get("attempt_id"),
                    "exit_code": receipt.get("exit_code"), "readback": "PASS"}
            comp.update(comp_patch or {})
            for k in comp_drop or ():
                comp.pop(k)
            (d / "R.VERIFIED.json").write_bytes(comp_raw if comp_raw is not None else json.dumps(comp).encode("utf-8"))
            return d / "R.json"

        def why(path, expected=None, attempt=att):
            v = L.verify_receipt_with_companion(path, L.STEP_RECEIPT_SCHEMA, attempt, exit_code=expected)
            self.assertFalse(v["valid"]) if v["reason"] != "OK" else None
            return v["reason"]
        self.assertEqual(why(mk(good), 0), "OK")
        self.assertEqual(why(mk(good)), "OK")
        # o probe externo reproduzido no R1: receipt 0, companion 3 + readback FAIL, expected=0
        self.assertEqual(why(mk(good, {"exit_code": 3, "readback": "FAIL"}), 0), "COMPANION_EXIT_NE_RECEIPT")
        cases = {
            "COMPANION_EXIT_NE_RECEIPT": (mk(good, {"exit_code": 3}), None),
            "COMPANION_READBACK_NOT_PASS": (mk(good, {"readback": "FAIL"}), 0),
            "COMPANION_ATTEMPT_NE_RECEIPT": (mk(good, {"attempt_id": "20261003T000000Z_0000000f"}), 0),
            "COMPANION_SHA_NE_RECEIPT": (mk(good, {"receipt_sha256": "0" * 64}), 0),
            "COMPANION_SCHEMA": (mk(good, {"schema": "MINOTAURO_PHASE_B_ADAPTER_RECEIPT_VERIFIED_V001"}), 0),
            "COMPANION_KEYS": (mk(good, {"mode": "DRY"}), 0),
            "COMPANION_JSON_INVALID": (mk(good, comp_raw=b"{not json"), 0),
            "RECEIPT_EXIT_NE_NATIVE": (mk(good), 3),
        }
        for want, (path, exp) in cases.items():
            self.assertEqual(why(path, exp), want, want)
        self.assertEqual(why(mk(good, comp_drop=["readback"]), 0), "COMPANION_KEYS")
        self.assertEqual(why(mk(good, {"exit_code": "0"}), 0), "COMPANION_EXIT_NE_RECEIPT")  # tipo: "0" != 0
        self.assertEqual(why(mk(dict(good, exit_code=True)), None), "RECEIPT_EXIT_NOT_INT")
        # receipt e companion coerentes entre si (ambos 3), mas divergentes do esperado => inválido
        bad3 = dict(good, exit_code=3)
        self.assertEqual(why(mk(bad3), 0), "RECEIPT_EXIT_NE_NATIVE")
        self.assertEqual(why(mk(bad3), 3), "OK")
        p = mk(good)
        (p.parent / "R.VERIFIED.json").unlink()
        self.assertEqual(why(p, 0), "COMPANION_MISSING")

    def test_classify_exception(self):
        import qs4_flow as F

        class AdapterBlocked(Exception):
            def __init__(self, code):
                self.code = code
                super().__init__(code)

        class ModelError(Exception):
            pass

        class TraceGuardMismatch(Exception):
            pass
        k = F._classify_exception
        self.assertEqual({x: k(KeyboardInterrupt("QS4_SEAM QS4_STOP_ANCHOR session=2026-01-07"))[x] for x in ("class", "seam", "code")},
                         {"class": "INTERRUPT_SEAM", "seam": "QS4_STOP_ANCHOR", "code": "session=2026-01-07"})
        self.assertEqual(k(KeyboardInterrupt("QS4_SEAM QS4_BLOCK_TIMEOUT session=2026-01-05"))["seam"], "QS4_BLOCK_TIMEOUT")
        r = k(KeyboardInterrupt("SEAM_INTERRUPT_AFTER r1r11_resources/RunLock/__enter__"))
        self.assertEqual((r["seam"], r["code"]), ("SEAM_INTERRUPT_AFTER", "r1r11_resources/RunLock/__enter__"))
        self.assertEqual(k(KeyboardInterrupt())["class"], "INTERRUPT_SIGNAL")  # Ctrl+C real: sem argumentos
        self.assertEqual(k(TraceGuardMismatch("TRACE_GUARD_MISMATCH"))["class"], "TRACE_GUARD")
        self.assertEqual((k(AdapterBlocked("ADAPTER_IDENTITY_MISMATCH"))["class"], k(AdapterBlocked("ADAPTER_IDENTITY_MISMATCH"))["code"]),
                         ("BLOCKED", "ADAPTER_IDENTITY_MISMATCH"))
        self.assertEqual((k(ModelError("FAULT_BEFORE_JOURNAL"))["class"], k(ModelError("FAULT_BEFORE_JOURNAL"))["code"]),
                         ("FAULT", "FAULT_BEFORE_JOURNAL"))
        self.assertEqual(k(ModelError("RUN_LOCK_OR_ORPHAN_ACTIVE"))["class"], "FROZEN_ERROR")
        self.assertEqual(k(ValueError("x"))["class"], "ERROR")
        # DD-7: texto livre do CODE congelado nunca vai ao receipt (só tamanho + SHA)
        fe = k(ModelError("RUN_BLOCKED_TICK_DRIFT file=x expected=1 got=2"))
        self.assertNotIn("detail", fe)
        self.assertEqual(fe["detail_len"], len("RUN_BLOCKED_TICK_DRIFT file=x expected=1 got=2"))
        self.assertNotIn("detail", k(ValueError("valor 123.45")))
        self.assertNotIn("detail", k(KeyboardInterrupt("FAULT_STAGING_SIGINT")))
        self.assertEqual(k(KeyboardInterrupt("FAULT_STAGING_SIGINT"))["detail_len"], 20)  # sinal com args != Ctrl+C real
        self.assertEqual(k(KeyboardInterrupt())["detail_len"], 0)


# =========================================================================== seams (fake frozen namespace)
def fake_frozen():
    calls = []
    fr = types.ModuleType("r1r11_fast_resume")

    def write_anchor_checkpoint(cp_path, cp, anchor):
        calls.append(("write", anchor["session"]))

    def clear_anchor_checkpoint(cp_path, cp):
        calls.append(("clear",))
    fr.write_anchor_checkpoint, fr.clear_anchor_checkpoint = write_anchor_checkpoint, clear_anchor_checkpoint
    res = types.ModuleType("r1r11_resources")

    class RunLock:
        def __init__(self, out):
            pass

        def __enter__(self):
            calls.append(("runlock",))
            return self

        def __exit__(self, *e):
            return False
    res.RunLock = RunLock
    co = types.ModuleType("r1r11_coordinator")

    class Runtime:
        def fault_at(self, point, seq=None):
            return None

        def inject(self, point):
            if self.fault_at(point):
                raise RuntimeError("FAULT_" + point.upper())
    co.Runtime = Runtime
    full = types.ModuleType("r1r11_full_2026")
    full.prepare_volume = lambda *a: calls.append(("prepare_volume",))
    full.recover = lambda *a: calls.append(("recover",))
    full.write_trades_csv_streaming = lambda *a: None
    run = types.ModuleType("minotauro_v004_runner")
    run._load_checkpoint = lambda *a: calls.append(("load",))
    mods = {"r1r11_fast_resume": fr, "r1r11_resources": res, "r1r11_coordinator": co, "r1r11_full_2026": full,
            "minotauro_v004_runner": run}
    return mods, calls


class H_Seams(unittest.TestCase):
    O2D = {1: "2026-01-02", 2: "2026-01-05", 3: "2026-01-06", 4: "2026-01-07"}

    def setUp(self):
        import qs4_seams
        self.S = qs4_seams
        sys.modules.pop("phase_b_qualification_seams", None)

    def tearDown(self):
        sys.modules.pop("phase_b_qualification_seams", None)

    def stack(self, mods, stop, **extra):
        step = dict({"stop": stop, "safety_ordinal": 4}, **extra)
        return self.S.SeamStack(mods, step, self.O2D, Path(tempfile.mkdtemp(prefix="mk_", dir=SCRATCH)), 0.5, adapter_dir=R3)

    def test_import_does_not_load_r3_seams(self):
        r = subprocess.run([sys.executable, "-B", "-c", "import sys; sys.path.insert(0, sys.argv[1]); import qs4_seams, qs4_flow, qs4_lib;"
                            " print('phase_b_qualification_seams' in sys.modules, any(m.startswith(('r1r11', 'minotauro')) for m in sys.modules))",
                            str(HARNESS)], capture_output=True, text=True)
        self.assertEqual(r.stdout.strip(), "False False")

    def test_anchor_interrupt_restore(self):
        mods, calls = fake_frozen()
        orig_w = mods["r1r11_fast_resume"].write_anchor_checkpoint
        with self.assertRaises(KeyboardInterrupt) as cm:
            with self.stack(mods, {"anchor_ordinal": 2}) as st:
                mods["r1r11_fast_resume"].write_anchor_checkpoint("p", {}, {"session": "2026-01-02"})
                mods["r1r11_fast_resume"].write_anchor_checkpoint("p", {}, {"session": "2026-01-05"})
        self.assertEqual(str(cm.exception), "QS4_SEAM QS4_STOP_ANCHOR session=2026-01-05")
        self.assertEqual(calls, [("write", "2026-01-02"), ("write", "2026-01-05")])  # anchor persistido ANTES da parada
        self.assertIs(mods["r1r11_fast_resume"].write_anchor_checkpoint, orig_w)
        self.assertEqual(st.spec_record["anchor_actions"], {"2026-01-07": "interrupt", "2026-01-05": "interrupt"})
        self.assertNotIn("phase_b_qualification_seams", sys.modules)  # só anchor: módulo R3 nem é carregado

    def test_safety_endpoint_always_installed(self):
        mods, _ = fake_frozen()
        with self.assertRaises(KeyboardInterrupt) as cm:
            with self.stack(mods, {"interrupt_target": "LOAD_CHECKPOINT"}):
                mods["r1r11_fast_resume"].write_anchor_checkpoint("p", {}, {"session": "2026-01-07"})
        self.assertIn("session=2026-01-07", str(cm.exception))

    def test_notify_and_block_markers(self):
        mods, _ = fake_frozen()
        st = self.stack(mods, {"anchor_ordinal": 4}, notify_anchor_ordinal=2)
        with st:
            mods["r1r11_fast_resume"].write_anchor_checkpoint("p", {}, {"session": "2026-01-05"})
        self.assertTrue((st.marker_dir / "QS4_MARKER_NOTIFY.txt").is_file())
        mods, _ = fake_frozen()
        st = self.stack(mods, {"anchor_ordinal": 4}, block_anchor_ordinal=2)
        t0 = time.monotonic()
        with self.assertRaises(KeyboardInterrupt) as cm:
            with st:
                mods["r1r11_fast_resume"].write_anchor_checkpoint("p", {}, {"session": "2026-01-05"})
        self.assertGreaterEqual(time.monotonic() - t0, 0.5)
        self.assertTrue((st.marker_dir / "QS4_MARKER_BLOCK.txt").is_file())
        self.assertIn("QS4_BLOCK_TIMEOUT", str(cm.exception))

    def test_r3_clear_anchor_interrupt(self):
        mods, calls = fake_frozen()
        orig_c = mods["r1r11_fast_resume"].clear_anchor_checkpoint
        with self.assertRaises(KeyboardInterrupt) as cm:
            with self.stack(mods, {"interrupt_target": "CLEAR_ANCHOR"}):
                mods["r1r11_fast_resume"].clear_anchor_checkpoint("p", {})
        self.assertEqual(str(cm.exception), "SEAM_INTERRUPT_AFTER r1r11_fast_resume/clear_anchor_checkpoint")
        self.assertEqual(calls, [("clear",)])  # original executado ANTES da parada (fim de mês já verificado)
        self.assertIs(mods["r1r11_fast_resume"].clear_anchor_checkpoint, orig_c)
        self.assertRaises(ValueError, self.S.AnchorController, mods, {"x": "kill"}, SCRATCH)

    def test_r3_interrupt_and_fault_installed_and_restored(self):
        mods, calls = fake_frozen()
        o_enter = mods["r1r11_resources"].RunLock.__dict__["__enter__"]
        o_fault = mods["r1r11_coordinator"].Runtime.__dict__["fault_at"]
        with self.assertRaises(KeyboardInterrupt) as cm:
            with self.stack(mods, {"interrupt_target": "RUNLOCK_ENTER"}):
                self.assertIn("phase_b_qualification_seams", sys.modules)
                with mods["r1r11_resources"].RunLock("x"):
                    pass
        self.assertEqual(str(cm.exception), "SEAM_INTERRUPT_AFTER r1r11_resources/RunLock/__enter__")
        self.assertIs(mods["r1r11_resources"].RunLock.__dict__["__enter__"], o_enter)
        with self.stack(mods, {"fault": "after_journal"}):
            rt = mods["r1r11_coordinator"].Runtime()
            self.assertRaises(RuntimeError, rt.inject, "after_journal")
            rt.inject("before_journal")
        self.assertIs(mods["r1r11_coordinator"].Runtime.__dict__["fault_at"], o_fault)
        # WRITE_ANCHOR do R3 + controlador de anchor do harness empilhados: R3 interrompe primeiro, restauração exata
        orig_w = mods["r1r11_fast_resume"].write_anchor_checkpoint
        with self.assertRaises(KeyboardInterrupt) as cm:
            with self.stack(mods, {"interrupt_target": "WRITE_ANCHOR"}):
                mods["r1r11_fast_resume"].write_anchor_checkpoint("p", {}, {"session": "2026-01-02"})
        self.assertIn("SEAM_INTERRUPT_AFTER", str(cm.exception))
        self.assertIs(mods["r1r11_fast_resume"].write_anchor_checkpoint, orig_w)

    def test_closed_list_and_failed_install_restores(self):
        mods, _ = fake_frozen()
        orig_w = mods["r1r11_fast_resume"].write_anchor_checkpoint
        with self.assertRaises(ValueError):
            with self.stack(mods, {"interrupt_target": "NOT_A_TARGET"}):
                pass
        st = self.stack(mods, {"fault": "after_journal"}, block_anchor_ordinal=99)  # ordinal inexistente => falha após instalar
        o_fault = mods["r1r11_coordinator"].Runtime.__dict__["fault_at"]
        with self.assertRaises(KeyError):
            with st:
                pass
        self.assertIs(mods["r1r11_coordinator"].Runtime.__dict__["fault_at"], o_fault)
        self.assertIs(mods["r1r11_fast_resume"].write_anchor_checkpoint, orig_w)

    def test_r3_seam_module_pin(self):
        cp = Path(tempfile.mkdtemp(prefix="r3pin_", dir=SCRATCH)) / "A"
        shutil.copytree(R3, cp)
        p = cp / "qualification" / "phase_b_qualification_seams.py"
        p.write_bytes(p.read_bytes() + b"\n# tamper\n")
        with self.assertRaises(RuntimeError) as cm:
            self.S.r3_seams(cp)
        self.assertEqual(str(cm.exception), "QS4_R3_SEAM_MODULE_PIN")
        self.assertNotIn("phase_b_qualification_seams", sys.modules)

    def test_restore_identity_violation_detected(self):
        mods, _ = fake_frozen()
        st = self.stack(mods, {"anchor_ordinal": 4})
        with self.assertRaises(RuntimeError) as cm:
            with st:
                st.anchor.orig = lambda *a: None  # restauração adulterada (simula falha de restauração)
        self.assertIn("QS4_SEAM_RESTORE_IDENTITY", str(cm.exception))


# =========================================================================== processes (POSIX analogs of P5/P10)
class H_Processes(unittest.TestCase):
    def test_descendants_terminate_and_orphans(self):
        code = ("import subprocess,sys,time; p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)']);"
                " print(p.pid, flush=True); time.sleep(30)")
        p = subprocess.Popen([sys.executable, "-c", code], stdout=subprocess.PIPE, text=True, **L.popen_kwargs())
        gpid = int(p.stdout.readline())
        d = L.descendants(p.pid)
        self.assertIn(gpid, [x[0] for x in d])
        ctime = dict(d)[gpid]
        self.assertTrue(L.alive(gpid, ctime))
        L.terminate_p10(p.pid)
        p.wait(10)
        time.sleep(0.3)
        self.assertTrue(L.alive(gpid, ctime))  # neto sobrevive ao TerminateProcess do filho => órfão detectável
        self.assertIn(gpid, [x[0] for x in L.descendants(p.pid)])  # mesmo grupo de processo
        self.assertFalse(L.alive(gpid, (ctime or 0) + 1))  # identidade = pid + creation time
        os.kill(gpid, signal.SIGKILL)  # limpeza do TESTE
        time.sleep(0.3)
        self.assertFalse(L.alive(gpid, ctime))

    def test_descendants_pid_reuse_safe(self):
        code = ("import subprocess,sys,time; p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)']);"
                " print(p.pid, flush=True); time.sleep(30)")
        p = subprocess.Popen([sys.executable, "-c", code], stdout=subprocess.PIPE, text=True, **L.popen_kwargs())
        try:
            gpid = int(p.stdout.readline())
            pct = L.process_ctime(p.pid)
            self.assertIn(gpid, [x[0] for x in L.descendants(p.pid, pct)])
            # o mesmo pid hoje "pertence a outro processo" (ctime registrado diferente => reuso): filhos dele ficam fora
            self.assertEqual(L.descendants(p.pid, pct - 1), [])
            # aresta com filho mais antigo que o pai registrado: fora
            self.assertEqual(L.descendants(p.pid, pct + 10 ** 9), [])
        finally:
            os.killpg(p.pid, signal.SIGKILL)  # limpeza do TESTE
            p.wait(10)

    def test_sigint_group_reaches_child_as_keyboardinterrupt(self):
        code = ("import time,sys\ntry:\n    print('R', flush=True); time.sleep(30)\nexcept KeyboardInterrupt as e:\n"
                "    print('KI', repr(e.args), flush=True); sys.exit(0)")
        p = subprocess.Popen([sys.executable, "-c", code], stdout=subprocess.PIPE, text=True, **L.popen_kwargs())
        self.assertEqual(p.stdout.readline().strip(), "R")
        os.killpg(p.pid, signal.SIGINT)
        self.assertEqual(p.stdout.readline().strip(), "KI ()")  # Ctrl+C real: KeyboardInterrupt SEM argumentos
        p.wait(10)

    def test_ctrlc_cli_closed_on_posix(self):
        r = subprocess.run([sys.executable, "-B", str(HARNESS / "qs4_harness.py"), "ctrlc", "--pid", "1"], capture_output=True)
        self.assertEqual(r.returncode, 2)


# =========================================================================== CLI
class H_CLI(unittest.TestCase):
    def run_h(self, *a, env=None, flags=("-B",)):
        e = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        if env is not None:
            e = env
        return subprocess.run([sys.executable, *flags, str(HARNESS / "qs4_harness.py"), *a], capture_output=True, text=True, env=e)

    def test_argv_closed(self):
        self.assertEqual(self.run_h().returncode, 2)
        self.assertEqual(self.run_h("finalize").returncode, 2)
        self.assertEqual(self.run_h("orchestrate", "--attempt-id", "x").returncode, 2)
        r = self.run_h("orchestrate", "--attempt-id", "bad", "--r3-dir", "x", "--qs3-receipt", "y", "--qs3-receipt-sha256", "z")
        self.assertIn("QS4_HARNESS_ATTEMPT_ID=BLOCKED", r.stdout)
        env = {k: v for k, v in os.environ.items() if k != "PYTHONDONTWRITEBYTECODE"}
        r = self.run_h("orchestrate", "--attempt-id", "20261003T000000Z_0000abcd", "--r3-dir", "x", "--qs3-receipt", "y",
                       "--qs3-receipt-sha256", "z", env=env, flags=())
        self.assertIn("QS4_HARNESS_BYTECODE=BLOCKED", r.stdout)
        self.assertEqual(r.returncode, 2)
        self.assertFalse(any(d.name == "__pycache__" for d in HARNESS.rglob("*") if d.is_dir()))
        self.assertEqual(self.run_h("invoke", "--step-json").returncode, 2)

    def test_plan(self):
        r = self.run_h("plan")
        self.assertEqual(r.returncode, 0)
        self.assertIn("STEPS_TOTAL=45", r.stdout)
        self.assertEqual(r.stdout.count("CASE="), 24)


# =========================================================================== literal world: REAL invoke (até RunLock)
class H_RealDirect(unittest.TestCase):
    def test_t22_variant_blocks_and_seam_module_order(self):
        r = e2e("real-direct")
        s0 = r["step0"]
        self.assertEqual(s0["exit"], 0)
        self.assertTrue(s0["receipt_valid"])
        self.assertEqual(s0["gates"][-4:], ["G18:PASS", "G19:PASS", "G20:PASS", "G21:PASS"])
        self.assertEqual(s0["outcome"]["class"], "ERROR")  # sandbox: RunLock exige Win32
        self.assertEqual(s0["outcome"]["code"], "MemoryProbeError")
        self.assertEqual(s0["seamset_probe"], ["QS4_TEST_SEAMSET_ENTER seams_loaded=False"])
        self.assertEqual(s0["seams"]["r3_interrupt_after"], "RUNLOCK_ENTER")
        self.assertTrue(s0["run_binding_present"])
        s1 = r["step1_variant"]
        self.assertNotEqual(r["variant_identity"], r["r3_test_identity"])
        self.assertEqual(s1["exit"], 0)
        self.assertTrue(s1["receipt_valid"])
        self.assertEqual((s1["outcome"]["class"], s1["outcome"]["code"]), ("BLOCKED", "ADAPTER_IDENTITY_MISMATCH"))
        self.assertEqual(s1["gates"][-1], "G12:BLOCKED")
        self.assertEqual(s1["blocked_gate"], "G12")
        self.assertIn("adapter_identity_sha256", s1["outcome"]["detail"])
        self.assertEqual(s1["state_after"], "PREPARED")  # raiz do passo 0 (sandbox: parou em RunLock antes de RUN.lock)
        self.assertNotIn("detail", s0["outcome"])  # DD-7: texto do CODE congelado só em quarentena
        self.assertTrue(s0["quarantine"]["sha256"])
        self.assertTrue(s1["root_unchanged"] and r["root_unchanged_by_variant"])


class H_RealOrchestrator(unittest.TestCase):
    def test_real_children_reach_runlock_and_orchestrator_fails_closed(self):
        r = e2e("real-orchestrator")
        self.assertEqual(r["exit"], 2)
        self.assertTrue(r["receipt_valid"])
        self.assertTrue(r["protected_unchanged_external"] and r["protected_equal"])
        self.assertEqual(r["status_final"], {"ACTIVE": "NO", "exit": 2, "sha_matches_receipt": True})
        det = r["step_details"]
        self.assertEqual(sorted(det), sorted(c["id"] for c in C["cases"]))
        self.assertEqual(set(r["cases"].values()), {"FAIL"})
        for case in C["cases"]:
            d, stop = det[case["id"]], case["steps"][0]["stop"]
            self.assertEqual((d["outcome"]["class"], d["outcome"]["code"]), ("ERROR", "MemoryProbeError"), case["id"])
            self.assertEqual(d["gates"][-4:], ["G18:PASS", "G19:PASS", "G20:PASS", "G21:PASS"], case["id"])
            self.assertEqual(d["seamset_probe"], ["QS4_TEST_SEAMSET_ENTER seams_loaded=False"], case["id"])
            self.assertEqual(d["template_mode"], case["steps"][0]["template"], case["id"])
            self.assertEqual(d["t30_foreign"], [], case["id"])
            self.assertEqual(d["seams"].get("r3_interrupt_after"), stop.get("interrupt_target"), case["id"])
            self.assertEqual(d["seams"].get("r3_fault_at"), stop.get("fault"), case["id"])
            want = {C_O2D[C["endpoints"][case["family"]]]: "interrupt"}
            if "anchor_ordinal" in stop:
                want[C_O2D[stop["anchor_ordinal"]]] = "interrupt"
            for k, a in (("notify_anchor_ordinal", "notify"), ("block_anchor_ordinal", "block")):
                if k in case["steps"][0]:
                    want[C_O2D[case["steps"][0][k]]] = a
            self.assertEqual(d["seams"]["anchor_actions"], want, case["id"])
        self.assertEqual({k: v for k, v in r["items"].items() if v != "FAIL"}, {"T30": "PASS"})  # nenhum estranho visto


# =========================================================================== literal world: orquestrador com invocação SIMULADA
class H_FakeMatrix(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r = e2e("fake-matrix")

    def test_pass_path(self):
        p = self.r["PASS"]
        self.assertEqual(p["exit"], 0, p.get("log_tail"))
        self.assertTrue(p["receipt_valid"])
        self.assertEqual(set(p["items"].values()), {"PASS"})
        self.assertEqual(len(p["items"]), 9)
        self.assertEqual(set(p["cases"].values()), {"PASS"})
        self.assertEqual(len(p["cases"]), 24)
        self.assertTrue(p["protected_equal"] and p["protected_unchanged_external"] and p["top_level_only_shadow_base"])
        self.assertEqual(p["status_final"], {"ACTIVE": "NO", "exit": 0, "sha_matches_receipt": True})
        self.assertEqual(p["status_write_failures"], 0)
        self.assertTrue(p["t22_variant"])
        self.assertGreater(p["growth"], 0)
        steps = {(s["case"], s["step"]): s for s in p["steps"]}
        self.assertEqual(len(steps), 45)
        self.assertEqual(steps[("T18_P5_CTRL_C", 0)]["outcome"]["class"], "INTERRUPT_SIGNAL")
        self.assertIn("SIGINT", steps[("T18_P5_CTRL_C", 0)]["ctrl_c"]["method"])
        self.assertEqual(steps[("T18_P10_TERMINATE", 0)]["outcome"]["class"], "TERMINATED")
        self.assertEqual(steps[("REF_E3", 0)]["expect"]["code"], "session=2026-01-07")
        self.assertEqual(steps[("REF_E23", 0)]["expect"]["code"], "session=2026-02-04")
        self.assertEqual(steps[("T16_K21", 0)]["expect"]["code"], "r1r11_fast_resume/clear_anchor_checkpoint")
        self.assertEqual(steps[("T16_K21", 0)]["expect"]["committed"], 21)
        self.assertEqual(steps[("REF_E3", 0)]["expect"]["committed"], 3)
        self.assertEqual(steps[("REF_E23", 0)]["expect"]["committed"], 23)
        for cid in ("T18_P1_RUNLOCK", "T18_P2_PREPARE_VOLUME", "T18_P3_RECOVER"):
            self.assertEqual((steps[(cid, 1)]["outcome"]["class"], steps[(cid, 1)]["outcome"]["code"]), ("BLOCKED", "STATE_BLOCKED_AMBIGUOUS"))
            self.assertEqual((steps[(cid, 0)]["state_after"], steps[(cid, 1)]["state_after"]), ("BLOCKED_AMBIGUOUS", "BLOCKED_AMBIGUOUS"))
        self.assertEqual(steps[("T29_RELOCATION", 1)]["outcome"]["code"], "STATE_BLOCKED_AMBIGUOUS")
        self.assertIn("SEAL_KEY_FOREIGN:", steps[("T29_RELOCATION", 1)]["outcome"]["detail"])
        self.assertEqual(steps[("T18_P10_TERMINATE", 0)]["state_after"], "IN_PROGRESS")
        for cid, cmp_ in p["comparisons"].items():
            self.assertTrue(cmp_["equal"], cid)
        self.assertEqual(p["p5_microprobe"]["result"], "PASS")
        self.assertEqual(p["multiwork"], "NOT_APPLICABLE")
        self.assertIn("NAO significa auto-resume em P1-P3", p["t18_semantics"])
        self.assertEqual(p["durable_units"], 45)
        self.assertEqual((p["progress_final"]["PCT"], p["progress_final"]["RECONCILED"]), ("100.0", True))

    def test_p5_microprobe_blocks_before_matrix(self):
        for k in ("P5_PROBE_NOSIGNAL", "P5_PROBE_HELPERFAIL"):
            d = self.r[k]
            self.assertEqual(d["exit"], 2, k)
            self.assertFalse(d["shadow_exists"], k)
            self.assertTrue(d["blocked_reason"].startswith("H07_P5_MICROPROBE_FAILED"), (k, d["blocked_reason"]))
            self.assertEqual(d["durable_units"], 0, k)
        self.assertIn("HELPER_EXIT", self.r["P5_PROBE_HELPERFAIL"]["blocked_reason"])
        self.assertIn("NO_KEYBOARDINTERRUPT_WITHOUT_ARGS", self.r["P5_PROBE_NOSIGNAL"]["blocked_reason"])

    def test_divergence_fails_without_values(self):
        d = self.r["DIVERGE"]
        self.assertFalse(d["progress_final"]["RECONCILED"])
        self.assertEqual(d["progress_final"]["PCT"], "99.9")  # 45/45 duráveis, mas sem PASS => nunca 100
        self.assertEqual(d["exit"], 2)
        self.assertTrue(d["receipt_valid"])
        self.assertEqual(d["cases"]["T16_K1"], "FAIL")
        self.assertEqual(d["items"]["T16"], "FAIL")
        self.assertEqual(d["comparisons"]["T16_K1"]["diffs"], ["SESSION_FILE:2026-01-02/trades.jsonl.gz"])

    def test_wrong_stop_point_fails(self):
        d = self.r["EARLYSTOP"]
        self.assertEqual(d["exit"], 2)
        self.assertEqual(d["cases"]["REF_E3"], "FAIL")
        self.assertEqual(d["comparisons"].get("T16_K1", {}).get("diffs"), ["REFERENCE_UNAVAILABLE"])
        self.assertTrue(all(d["items"][k] == "FAIL" for k in ("T16", "T18", "T33")))

    def test_foreign_entry_fails(self):
        d = self.r["FOREIGN"]
        self.assertEqual(d["exit"], 2)
        self.assertEqual(d["items"]["T30"], "FAIL")
        self.assertEqual(d["cases"]["T16_K2"], "FAIL")

    def test_missing_step_receipt_is_unproven(self):
        d = self.r["NORECEIPT"]
        self.assertEqual(d["exit"], 3)
        self.assertTrue(d["receipt_valid"])
        self.assertTrue(d["blocked_reason"].startswith("STEP_RESULT_NOT_PROVEN T16_K1#1"))
        self.assertTrue(d["unproven"])
        self.assertEqual(d["status_final"]["ACTIVE"], "NO")

    def test_watchdog_never_kills(self):
        d = self.r["HANG"]
        self.assertEqual(d["exit"], 3)
        self.assertTrue(d["blocked_reason"].startswith("WATCHDOG_EXPIRED REF_E3#0"))
        self.assertTrue(d["child_alive_after_exit"])
        self.assertIn("auto_kill=NO", d["log_watchdog"][0])

    def test_orphan_never_killed(self):
        d = self.r["ORPHAN"]
        self.assertEqual(d["exit"], 3)
        self.assertTrue(d["blocked_reason"].startswith("ORPHAN_ACTIVE REF_E3#0"))
        self.assertTrue(d["orphans_alive_after_exit"])

    def test_status_failure_never_pass(self):
        d = self.r["STATUS_FAIL"]
        self.assertEqual(d["exit"], 2)
        self.assertEqual(d["status_write_failures"], 1)
        self.assertEqual(d["result"], "NOT_PASS")
        self.assertTrue(d["receipt_valid"])
        self.assertEqual(set(d["items"].values()), {"PASS"})  # itens PASS, mas B08 recusa o PASS do estágio
        self.assertEqual(d["status_final"], {"ACTIVE": "NO", "exit": 2, "sha_matches_receipt": True})
        self.assertEqual((d["ledger_final"]["complete"], d["ledger_final"]["resumable"]), (False, True))
        r = self.r["STATUS_FAIL_RESUME"]
        self.assertEqual(r["exit"], 0)
        self.assertEqual(r["resume_reconcile"], [])  # todos os casos já duráveis: nada é reexecutado
        self.assertEqual(r["durable_units"], 45)
        self.assertEqual(r["progress_final"]["PCT"], "100.0")

    def test_items_verdict_seals_attempt(self):
        d = self.r["DIVERGE_RESUME"]
        self.assertEqual(d["exit"], 2)
        self.assertTrue(d["blocked_reason"].startswith("RESUME_ATTEMPT_ALREADY_FINAL 2"))

    def test_preconditions_block_before_shadow(self):
        for k, want in (("H01_BAD_SHA", "H01_QS3_RECEIPT_SHA_MISMATCH"), ("H00_TAMPER", "PACKAGE_MEMBER_HASH"),
                        ("H02_R3_TAMPER", "PACKAGE_MEMBER_HASH")):
            d = self.r[k]
            self.assertEqual(d["exit"], 2, k)
            self.assertFalse(d["shadow_exists"], k)
            self.assertTrue(d["blocked_reason"].startswith(want), (k, d["blocked_reason"]))
            self.assertTrue(d["receipt_valid"], k)
            self.assertEqual(d["status_final"]["ACTIVE"] if d.get("status_final") else "NO", "NO", k)
            self.assertIn("QS4_HARNESS_EXIT=2", d["log_tail"], k)
        self.assertTrue(self.r["NO_PYCACHE_IN_TEST_HARNESSES"])
        nb = self.r["NO_BYTECODE_FLAG"]
        self.assertEqual(nb["exit"], 2)
        self.assertFalse(nb["evidence_exists"])

    def test_signal_with_args_fails_p5(self):
        d = self.r["SIGARGS"]
        self.assertEqual(d["exit"], 2)
        self.assertEqual(d["cases"]["T18_P5_CTRL_C"], "FAIL")
        st = [s for s in d["steps"] if s["case"] == "T18_P5_CTRL_C"][0]
        self.assertIn("SIGNAL_KEYBOARDINTERRUPT_HAS_ARGS", st["reasons"])

    def test_dirty_state_fails(self):
        d = self.r["DIRTY"]
        self.assertEqual(d["exit"], 2)
        st = [s for s in d["steps"] if s["case"] == "T16_K1" and s["step"] == 1][0]
        self.assertIn("STATE_NOT_CLEAN", st["reasons"])

    def test_block_after_frontier(self):
        d = self.r["BLOCK_AFTER_FRONTIER"]
        self.assertEqual(d["exit"], 2)
        self.assertTrue(d["blocked_reason"].startswith("TEST_INJECTED_BLOCK_AFTER_CASE REF_E3"))
        self.assertTrue(d["receipt_valid"])
        b = self.r["BLOCK_AFTER_TOUCH"]
        self.assertTrue(self.r["RESTORED_BEFORE_BLOCK_TOUCH"])
        self.assertEqual(b["exit"], 3)  # finish() recalculou os protegidos e achou o delta
        self.assertIn("PROTECTED_DELTA finish:control", b["blocked_reason"])
        self.assertTrue(b["unproven"])

    def test_protected_delta_is_three(self):
        self.assertTrue(self.r["PROTECTED_BEFORE_TOUCH"])
        d = self.r["TOUCHCONTROL"]
        self.assertEqual(d["exit"], 3)
        self.assertTrue(d["blocked_reason"].startswith("PROTECTED_DELTA after_case_T16_K1:control"))


# =========================================================================== Q4-02/Q4-03: ledger, progresso, lock
class H_Ledger(unittest.TestCase):
    def write_atomic(self, path, obj):
        from phase_b_effects import write_status_atomic
        return write_status_atomic(path, obj)

    def test_seal_write_verify_and_tamper(self):
        d = Path(tempfile.mkdtemp(prefix="led_", dir=SCRATCH))
        lp, jp = d / "QS4_LEDGER.json", d / "QS4_LEDGER.jsonl"
        doc = {"schema": L.LEDGER_SCHEMA, "seq": 0, "ledger_sha256": None, "cases": {}}
        doc = L.ledger_write(lp, jp, doc, self.write_atomic, "INIT")
        doc["cases"]["X"] = {"steps": [1]}
        doc = L.ledger_write(lp, jp, doc, self.write_atomic, "STEP")
        self.assertEqual(L.ledger_verify(lp, jp)["seq"], 2)
        self.assertEqual(doc["prev_ledger_sha256"], json.loads(jp.read_text().splitlines()[0])["ledger_sha256"])
        raw = lp.read_bytes()
        lp.write_bytes(raw.replace(b'"steps":[1]', b'"steps":[2]'))
        self.assertEqual(code_of(lambda: L.ledger_verify(lp, jp)), "RESUME_LEDGER_INTEGRITY")
        lp.write_bytes(raw)
        lines = jp.read_text().splitlines()
        jp.write_text(lines[1] + "\n")  # diário truncado/reordenado
        self.assertEqual(code_of(lambda: L.ledger_verify(lp, jp)), "RESUME_LEDGER_INTEGRITY")
        jp.write_text("\n".join(lines) + "\n")
        L.ledger_verify(lp, jp)
        lp.write_bytes(json.dumps(dict(json.loads(raw), schema="X")).encode())
        self.assertEqual(code_of(lambda: L.ledger_verify(lp, jp)), "RESUME_LEDGER_SCHEMA")
        self.assertEqual(code_of(lambda: L.ledger_verify(d / "none.json", jp)), "RESUME_LEDGER_MISSING")

    def test_journal_missing_tail_and_fragment_repair(self):
        for frag_len in (0, 11):  # (a) linha do diário que faltou; (b) linha truncada pela queda
            d = Path(tempfile.mkdtemp(prefix="ledr_", dir=SCRATCH))
            lp, jp = d / "QS4_LEDGER.json", d / "QS4_LEDGER.jsonl"
            doc = L.ledger_write(lp, jp, {"schema": L.LEDGER_SCHEMA, "seq": 0, "ledger_sha256": None, "n": 1}, self.write_atomic, "A")
            L.ledger_write(lp, jp, dict(doc, n=2), self.write_atomic, "B")
            lines = jp.read_text().splitlines()
            jp.write_text(lines[0] + "\n" + lines[1][:frag_len])  # TESTE: queda entre o ledger e o diário
            v = L.ledger_verify(lp, jp)
            self.assertEqual(v["_journal_repair"]["missing_seq"], 2)
            self.assertEqual((v["_journal_repair"]["mode"], bool(v["_journal_repair"]["skipped"])), ("APPEND", bool(frag_len)))
            L.ledger_repair_journal(jp, v)
            v2 = L.ledger_verify(lp, jp)
            self.assertNotIn("_journal_repair", v2)
            self.assertEqual(json.loads(jp.read_text().splitlines()[-1])["event"], "JOURNAL_REPAIR")
            L.ledger_write(lp, jp, dict(v2, n=3), self.write_atomic, "C")  # a cadeia continua normalmente
            self.assertEqual(L.ledger_verify(lp, jp)["seq"], 3)
        # (c) linha inteira gravada, faltou só o '\n': completa com '\n' (sem linha duplicada)
        d = Path(tempfile.mkdtemp(prefix="ledr_", dir=SCRATCH))
        lp, jp = d / "QS4_LEDGER.json", d / "QS4_LEDGER.jsonl"
        doc = L.ledger_write(lp, jp, {"schema": L.LEDGER_SCHEMA, "seq": 0, "ledger_sha256": None}, self.write_atomic, "A")
        L.ledger_write(lp, jp, dict(doc, n=2), self.write_atomic, "B")
        jp.write_text(jp.read_text().rstrip("\n"))
        v = L.ledger_verify(lp, jp)
        self.assertEqual(v["_journal_repair"]["mode"], "TERMINATE_LINE")
        L.ledger_repair_journal(jp, v)
        self.assertEqual(len(jp.read_text().splitlines()), 2)
        self.assertNotIn("_journal_repair", L.ledger_verify(lp, jp))
        L.ledger_write(lp, jp, dict(L.ledger_verify(lp, jp), n=3), self.write_atomic, "C")
        self.assertEqual(L.ledger_verify(lp, jp)["seq"], 3)
        # (d) queda DURANTE o próprio reparo (fragmento + reparo truncado): novo reparo lista os dois restos
        d = Path(tempfile.mkdtemp(prefix="ledr_", dir=SCRATCH))
        lp, jp = d / "QS4_LEDGER.json", d / "QS4_LEDGER.jsonl"
        doc = L.ledger_write(lp, jp, {"schema": L.LEDGER_SCHEMA, "seq": 0, "ledger_sha256": None}, self.write_atomic, "A")
        L.ledger_write(lp, jp, dict(doc, n=2), self.write_atomic, "B")
        lines = jp.read_text().splitlines()
        jp.write_text(lines[0] + "\n" + lines[1][:9])
        v = L.ledger_verify(lp, jp)
        with open(jp, "a") as f:
            f.write("\n" + '{"event":"JOURNAL_REP')  # TESTE: queda no meio do append do reparo
        v = L.ledger_verify(lp, jp)
        self.assertEqual((v["_journal_repair"]["mode"], len(v["_journal_repair"]["skipped"])), ("APPEND", 2))
        L.ledger_repair_journal(jp, v)
        self.assertNotIn("_journal_repair", L.ledger_verify(lp, jp))
        L.ledger_write(lp, jp, dict(L.ledger_verify(lp, jp), n=3), self.write_atomic, "C")
        self.assertEqual(L.ledger_verify(lp, jp)["seq"], 3)
        # cauda dois passos atrás: nunca reparada
        d = Path(tempfile.mkdtemp(prefix="ledr_", dir=SCRATCH))
        lp, jp = d / "QS4_LEDGER.json", d / "QS4_LEDGER.jsonl"
        doc = L.ledger_write(lp, jp, {"schema": L.LEDGER_SCHEMA, "seq": 0, "ledger_sha256": None}, self.write_atomic, "A")
        doc = L.ledger_write(lp, jp, dict(doc, n=2), self.write_atomic, "B")
        L.ledger_write(lp, jp, dict(doc, n=3), self.write_atomic, "C")
        jp.write_text(jp.read_text().splitlines()[0] + "\n")
        self.assertEqual(code_of(lambda: L.ledger_verify(lp, jp)), "RESUME_LEDGER_INTEGRITY")
        # lixo no meio do diário sem JOURNAL_REPAIR: integridade
        lines = [ln for ln in (d / "QS4_LEDGER.jsonl").read_text().splitlines()]
        jp.write_text(lines[0] + "\n{garbage\n")
        self.assertEqual(code_of(lambda: L.ledger_verify(lp, jp)), "RESUME_LEDGER_INTEGRITY")

    def test_progress_view(self):
        self.assertEqual(L.progress_view(0, 45)["PCT"], "0.0")
        self.assertEqual(L.progress_view(22, 45)["PCT"], "48.9")
        self.assertEqual(L.progress_view(45, 45)["PCT"], "99.9")  # sem receipt final reconciliado nunca 100
        v = L.progress_view(45, 45, reconciled=True)
        self.assertEqual((v["PCT"], v["RECONCILED"]), ("100.0", True))
        self.assertTrue(v["BAR"].startswith("[" + "#" * 30 + "]"))

    def test_attempt_lock_exclusive(self):
        d = Path(tempfile.mkdtemp(prefix="lock_", dir=SCRATCH))
        code = ("import sys,time; sys.path.insert(0, sys.argv[1]); import qs4_lib as L; from pathlib import Path;"
                " k=L.AttemptLock('20261003T000000Z_00000001', Path(sys.argv[2])); k.acquire(); print('HELD', flush=True); time.sleep(30)")
        p = subprocess.Popen([sys.executable, "-B", "-c", code, str(HARNESS), str(d)], stdout=subprocess.PIPE, text=True,
                             env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        self.assertEqual(p.stdout.readline().strip(), "HELD")
        try:
            self.assertEqual(code_of(lambda: L.AttemptLock("20261003T000000Z_00000001", d).acquire()), "RESUME_ATTEMPT_LOCKED")
        finally:
            p.kill()  # limpeza do TESTE
            p.wait(10)
        k = L.AttemptLock("20261003T000000Z_00000001", d)
        k.acquire()  # liberado pelo SO na morte do dono
        self.assertTrue(k.name.startswith("Global\\MinotauroQS4Harness_"))


# =========================================================================== Q4-01: alvo do CTRL_C e microprobe
class H_P5Probe(unittest.TestCase):
    def target(self, timeout_s):
        d = Path(tempfile.mkdtemp(prefix="p5_", dir=SCRATCH))
        p = subprocess.Popen([sys.executable, "-B", str(HARNESS / "qs4_harness.py"), "p5probe-target", "--marker-dir", str(d),
                              "--timeout-s", str(timeout_s)], env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
                             **L.popen_kwargs(console=True))
        t0 = time.time()
        while not (d / "READY.json").is_file() and time.time() - t0 < 20:
            time.sleep(0.05)
        return p, d

    def test_signal_delivered_keyboardinterrupt_without_args(self):
        p, d = self.target(30)
        os.killpg(p.pid, signal.SIGINT)  # análogo POSIX do CTRL_C_EVENT
        self.assertEqual(p.wait(20), 0)
        self.assertEqual(json.loads((d / "CAUGHT.json").read_text())["args_len"], 0)
        self.assertTrue(json.loads((d / "READY.json").read_text())["ctrl_c_enable"]["enabled"])

    def test_target_self_terminates_without_signal(self):
        p, d = self.target(1)
        self.assertEqual(p.wait(20), 3)  # nunca morto: encerra-se sozinho
        self.assertFalse((d / "CAUGHT.json").exists())

    def test_console_flag_and_cli(self):
        self.assertEqual(L.popen_kwargs(console=True), {"start_new_session": True})  # POSIX; Windows: CREATE_NEW_CONSOLE
        r = subprocess.run([sys.executable, "-B", str(HARNESS / "qs4_harness.py"), "p5probe-target", "--marker-dir", "/nonexistent_x",
                            "--timeout-s", "1"], env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        self.assertEqual(r.returncode, 2)
        r = subprocess.run([sys.executable, "-B", str(HARNESS / "qs4_harness.py"), "orchestrate", "--attempt-id", "20261003T000000Z_00000001",
                            "--r3-dir", "x", "--qs3-receipt", "y", "--qs3-receipt-sha256", "z", "--resume-from", "20261003T000000Z_00000001"],
                           capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        self.assertIn("QS4_HARNESS_ATTEMPT_ID=BLOCKED", r.stdout)  # retomada não pode reutilizar o id da sessão


class H_ResumeMatrix(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r = e2e("resume-matrix")

    def full_pass(self, d):
        self.assertEqual(d["exit"], 0, d.get("log_tail"))
        self.assertTrue(d["receipt_valid"])
        self.assertEqual(set(d["items"].values()), {"PASS"})
        self.assertEqual(d["durable_units"], 45)
        self.assertEqual(sum(d["step_counts"].values()), 45)  # nenhuma unidade duplicada nem descartada
        self.assertEqual(d["progress_final"]["PCT"], "100.0")
        self.assertTrue(d["progress_final"]["RECONCILED"])

    def test_retry_without_effect(self):
        x = self.r["RETRY"]
        self.assertEqual(x["first"]["exit"], 77)
        self.assertEqual((x["first"]["ledger_partial"]["case"], x["first"]["ledger_partial"]["step"]), ("T16_K1", 1))
        self.assertIsNone(x["first"]["ledger_partial"]["child"])
        self.assertLess(float(x["first"]["status_progress"]["PCT"]), 100.0)
        self.full_pass(x["resume"])
        self.assertEqual(x["resume"]["resume_reconcile"], ["T16_K1#1:RETRY_NO_EFFECT"])
        self.assertEqual(len(x["resume"]["sessions"]), 2)
        self.assertEqual(set(x["resume"]["gens"].values()), {1})

    def test_adopt_completed_child(self):
        x = self.r["ADOPT"]
        self.assertEqual(x["first"]["exit"], 77)
        self.full_pass(x["resume"])
        self.assertEqual(x["resume"]["resume_reconcile"], ["REF_E3#0:ADOPT"])
        self.assertEqual(x["resume"]["adopted"], ["REF_E3#0"])

    def test_abandon_unproven_partial_preserves_shadow(self):
        x = self.r["ABANDON"]
        self.assertEqual(x["first"]["exit"], 3)
        self.assertFalse(x["first"]["ledger_final"]["complete"])
        self.full_pass(x["resume"])
        self.assertEqual(x["resume"]["resume_reconcile"], ["T16_K2:ABANDON_PARTIAL_STEP"])
        self.assertEqual(x["resume"]["gens"]["T16_K2"], 2)
        self.assertEqual([a["case"] for a in x["resume"]["abandoned"]], ["T16_K2"])
        self.assertEqual(x["resume"]["case_dirs"]["T16_K2"], ["R1", "R2"])  # geração anterior preservada

    def test_abandon_interrupted_seeding(self):
        x = self.r["SEEDING"]
        self.assertEqual(x["first"]["exit"], 77)
        self.full_pass(x["resume"])
        self.assertEqual(x["resume"]["resume_reconcile"], ["T16_K2:ABANDON_SEEDING"])

    def test_lock_and_live_child_block_then_reconciled_resume(self):
        x = self.r["LOCK_ALIVE"]
        self.assertTrue(x["child_seen"])
        self.assertEqual(x["locked"]["exit"], 2)
        self.assertTrue(x["locked"]["blocked_reason"].startswith("RESUME_ATTEMPT_LOCKED"))
        self.assertEqual(x["child_alive"]["exit"], 2)
        self.assertTrue(x["child_alive"]["blocked_reason"].startswith("RESUME_PREVIOUS_SESSION_PROCESS_ALIVE"))
        self.full_pass(x["after_reconcile"])
        self.assertEqual(x["after_reconcile"]["resume_reconcile"], ["REF_E3#0:RETRY_NO_EFFECT"])

    def test_relocation_retry_keeps_durable_step0(self):
        x = self.r["RELOCATE"]
        self.assertEqual(x["first"]["exit"], 77)
        self.full_pass(x["resume"])
        self.assertEqual(x["resume"]["resume_reconcile"], ["T29_RELOCATION:RELOCATE_RETRY_N1"])
        self.assertEqual(x["resume"]["gens"]["T29_RELOCATION"], 1)  # passo 0 durável preservado (sem abandono)
        self.assertEqual(x["resume"]["reloc_dirs"], ["R1_1"])

    def test_variant_rebuild_next_gen(self):
        x = self.r["VARIANT"]
        self.assertEqual(x["first"]["exit"], 77)
        self.full_pass(x["resume"])
        self.assertEqual(x["resume"]["resume_reconcile"], ["VARIANT_V1:REBUILD_NEXT_GEN", "T22_ADAPTER_IDENTITY:CONTINUE_AT_STEP_1"])
        self.assertEqual(x["resume"]["variant_dirs"], ["V2"])  # queda antes da cópia: V1 nunca existiu; a geração avança

    def test_nonzero_exit_never_adopted(self):
        x = self.r["EXITNONZERO"]
        self.assertEqual(x["first"]["exit"], 3)
        self.assertEqual(x["first"]["ledger_partial"]["observed"]["native_exit"], 1)
        self.full_pass(x["resume"])
        self.assertEqual(x["resume"]["resume_reconcile"], ["T16_K1:ABANDON_PARTIAL_STEP"])
        self.assertEqual(x["resume"]["adopted"], [])

    def test_final_pending_is_resumable(self):
        x = self.r["FINAL_PENDING"]
        self.assertEqual(x["first"]["exit"], 77)
        self.assertTrue(x["first"]["ledger_final"]["receipt_pending"])
        self.assertFalse(x["first"]["ledger_final"]["complete"])
        self.full_pass(x["resume"])
        self.assertEqual(x["resume"]["resume_reconcile"], [])
        self.assertTrue(x["resume"]["ledger_final"]["complete"])

    def test_gap_between_popen_and_ledger(self):
        g = self.r["GAP"]
        self.assertEqual(g["first"]["exit"], 77)
        self.assertIsNone(g["ledger_partial"]["child"])
        self.assertEqual(g["blocked"]["exit"], 2)
        self.assertTrue(g["blocked"]["blocked_reason"].startswith("RESUME_PREVIOUS_SESSION_PROCESS_ALIVE"))
        self.full_pass(g["resume"])
        self.assertEqual(g["resume"]["resume_reconcile"], ["REF_E3:ABANDON_PARTIAL_STEP"])  # pid desconhecido => nunca adota

    def test_action_step_crash_never_adopted(self):
        x = self.r["P5_CRASH"]
        self.assertEqual(x["first"]["exit"], 77)
        self.full_pass(x["resume"])
        self.assertEqual(x["resume"]["resume_reconcile"], ["T18_P5_CTRL_C:ABANDON_PARTIAL_STEP"])

    def test_journal_desync_repaired_append_only(self):
        d = self.r["JOURNAL_DESYNC"]
        self.full_pass(d)
        self.assertEqual(d["resume_reconcile"][0][:19], "JOURNAL_REPAIR:seq=")
        self.assertIn("T16_K1#0:RETRY_NO_EFFECT", d["resume_reconcile"])
        # B-1 (R2): o diário continua verificável depois da retomada; reparo antes da 1ª gravação da retomada
        self.assertEqual(d["journal_verify_after"], "OK")
        ev = d["journal_events"]
        self.assertLess(ev.index("JOURNAL_REPAIR"), ev.index("SESSION_HISTORY"))
        self.assertEqual(ev[-1], "FINAL_SEALED")

    def test_resume_negatives(self):
        for k, want in (("FINAL_ALREADY", "RESUME_ATTEMPT_ALREADY_FINAL"), ("BINDING", "RESUME_BINDING_MISMATCH qs3_receipt_sha256"),
                        ("DURABLE_CHANGED", "RESUME_DURABLE_BYTES_CHANGED REF_E3"), ("LEDGER_TAMPER", "RESUME_LEDGER_INTEGRITY"),
                        ("UNKNOWN_ATTEMPT", "RESUME_LEDGER_MISSING")):
            d = self.r[k]
            self.assertEqual(d["exit"], 2, k)
            self.assertTrue(d["receipt_valid"], k)
            self.assertTrue(d["blocked_reason"].startswith(want), (k, d["blocked_reason"]))
        self.assertTrue(self.r["LEDGER_UNCHANGED_BY_NEGATIVES"])
        self.full_pass(self.r["RESUME_OK_AFTER_NEGATIVES"])
        self.assertTrue(self.r["NO_PYCACHE"])


# =========================================================================== R1-01 / R1-02: state-transfer e adoção
class H_R102Unit(unittest.TestCase):
    """revalidate_durable_steps: exit nativo autoritativo; adoção com prova pai-observada completa."""
    def setUp(self):
        import qs4_harness as H
        self.H = H
        self.d = Path(tempfile.mkdtemp(prefix="r102_", dir=SCRATCH))
        self.att = "20261003T000000Z_0000a102"
        self.sha = L.write_receipt_with_companion(self.d / "STEP_RECEIPT.json", {"schema": L.STEP_RECEIPT_SCHEMA,
                                                  "attempt_id": self.att, "exit_code": 0}, write_json_durable)
        self.csha = L.sha_file(self.d / "STEP_RECEIPT.VERIFIED.json")

    def led(self, **chg):
        child = {"pid": 4242, "ctime": 1.5}
        st = {"case": "REF_E3", "step": 0, "action": None, "step_dir": str(self.d), "invocation_attempt_id": self.att,
              "native_exit": 0, "child": child, "receipt": {"valid": True, "reason": "OK", "sha256": self.sha},
              "adopted_on_resume": True,
              "adoption": {"source_session": "S", "source_partial_seq": 7, "source_partial_ledger_sha256": "A" * 64,
                           "source_child": dict(child), "source_native_exit": 0, "receipt_sha256": self.sha,
                           "companion_sha256": self.csha, "receipt_exit_code": 0}}
        for k, v in chg.items():
            if k.startswith("adoption."):
                st["adoption"][k[9:]] = v
            else:
                st[k] = v
        return {"cases": {"REF_E3": {"steps": [st]}}}

    def code(self, led):
        return code_of(lambda: self.H.Orchestrator.revalidate_durable_steps(types.SimpleNamespace(L=L), led, "RESUME"))

    def test_matrix(self):
        self.assertEqual(self.code(self.led()), "NO_ERROR")
        self.assertEqual(self.code(self.led(native_exit=None)), "RESUME_DURABLE_STEP_PROOF")  # o defeito do R1
        self.assertEqual(self.code(self.led(native_exit=3)), "RESUME_DURABLE_STEP_PROOF")
        self.assertEqual(self.code(self.led(child=None)), "RESUME_DURABLE_STEP_PROOF")
        for k, v in (("source_partial_seq", None), ("source_partial_ledger_sha256", None), ("source_native_exit", None),
                     ("receipt_sha256", "0" * 64), ("companion_sha256", "0" * 64), ("receipt_exit_code", None),
                     ("source_child", {"pid": 1, "ctime": 0})):
            self.assertEqual(self.code(self.led(**{"adoption." + k: v})), "RESUME_DURABLE_STEP_PROOF", k)
        self.assertEqual(self.code(self.led(receipt={"valid": True, "sha256": "0" * 64})), "RESUME_DURABLE_RECEIPT_CHANGED")
        cp = self.d / "STEP_RECEIPT.VERIFIED.json"
        cp.write_text(json.dumps(dict(json.loads(cp.read_text()), exit_code=3, readback="FAIL")), encoding="utf-8")
        self.assertEqual(self.code(self.led()), "RESUME_DURABLE_RECEIPT_CHANGED")
        # P10: sem receipt do filho; exige ação TERMINATE e exit nativo inteiro registrado
        p10 = {"cases": {"T18_P10_TERMINATE": {"steps": [{"case": "T18_P10_TERMINATE", "step": 0, "action": "TERMINATE",
               "native_exit": 1, "receipt": {"valid": True, "reason": "TERMINATED_BY_P10_NO_CHILD_RECEIPT"}}]}}}
        self.assertEqual(self.code(p10), "NO_ERROR")
        p10["cases"]["T18_P10_TERMINATE"]["steps"][0]["native_exit"] = None
        self.assertEqual(self.code(p10), "RESUME_DURABLE_STEP_PROOF")


class H_StateTransfer(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r = e2e("state-transfer")

    def test_r1_01_not_pass_session_negatives(self):
        n = self.r["NEG"]
        want = {"RECEIPT_TAMPER": "RESUME_PREVIOUS_RECEIPT_INVALID", "COMPANION_CONTRADICTORY": "RESUME_PREVIOUS_RECEIPT_INVALID",
                "COMPANION_MISSING": "RESUME_PREVIOUS_RECEIPT_INVALID", "RECEIPT_AND_COMPANION_MISSING": "RESUME_PREVIOUS_RECEIPT_MISSING",
                "STATUS_TAMPER": "RESUME_PREVIOUS_STATUS_MISMATCH"}
        for k, code in want.items():
            self.assertEqual(n[k]["exit"], 2, k)
            self.assertTrue(n[k]["blocked_reason"].startswith(code), (k, n[k]["blocked_reason"]))
            self.assertFalse(n[k]["terminal"], k)
        self.assertIn("COMPANION_EXIT_NE_RECEIPT", n["COMPANION_CONTRADICTORY"]["blocked_reason"])
        self.assertIn("COMPANION_MISSING", n["COMPANION_MISSING"]["blocked_reason"])
        self.assertTrue(n["LEDGER_UNCHANGED"])

    def test_r1_01_pass_binds_previous_session(self):
        s1, p = self.r["S1"], self.r["S1_RESUME_PASS"]
        self.assertEqual((s1["exit"], s1["terminal"], s1["resumable"]), (2, False, True))
        self.assertEqual(s1["ledger_final"]["receipt_sha256"], s1["receipt_sha256"])
        self.assertEqual(s1["ledger_final"]["status_file_sha256_at_close"], s1["status_sha256"])
        self.assertEqual(p["exit"], 0, p.get("log_tail"))
        self.assertTrue(p["receipt_valid"] and p["terminal"])
        self.assertEqual(p["progress_final"]["PCT"], "100.0")
        h = p["session_history"]
        self.assertEqual(len(h), 1)
        e = h[0]
        self.assertEqual((e["session"], e["closure"], e["exit_code"], e["result"]), (p["s1_session"], "RECEIPT", 2, "NOT_PASS"))
        self.assertEqual((e["receipt_sha256"], e["companion_sha256"], e["status_file_sha256"]),
                         (s1["receipt_sha256"], s1["companion_sha256"], s1["status_sha256"]))
        self.assertEqual(e["status_write_failures"], 1)
        for k in ("blocked_reason", "receipt_path", "status_final_sha256", "ledger_seq", "ledger_sha256", "reason_for_resume"):
            self.assertIn(k, e)
        self.assertIsInstance(e["ledger_seq"], int)
        self.assertEqual(p["session_history_head"], e["entry_sha256"])
        self.assertTrue(p["ledger_final"]["complete"])
        self.assertEqual(p["ledger_final"]["session_history_head_sha256"], e["entry_sha256"])

    def test_r1_01_two_sessions_chain_and_history_tamper(self):
        x = self.r["TWO_SESSIONS"]
        self.assertEqual(x["second"]["exit"], 2)
        self.assertEqual([e["closure"] for e in x["second"]["session_history"]], ["NO_RECEIPT_CRASH_GAP"])
        t = x["history_tamper"]
        self.assertEqual(t["exit"], 2)
        self.assertTrue(t["blocked_reason"].startswith("SESSION_HISTORY_TAMPERED " + x["crash_logical"] + ":STATUS"), t["blocked_reason"])
        f = x["final"]
        self.assertEqual(f["exit"], 0, f.get("log_tail"))
        h = f["session_history"]
        self.assertEqual([e["closure"] for e in h], ["NO_RECEIPT_CRASH_GAP", "RECEIPT"])
        self.assertEqual(h[0]["session"], x["crash_logical"])
        self.assertEqual(h[1]["session"], x["second_session"])
        self.assertEqual((h[0]["prev_entry_sha256"], h[1]["prev_entry_sha256"]), (None, h[0]["entry_sha256"]))
        self.assertEqual(h[1]["exit_code"], 2)
        self.assertEqual(f["durable_units"], 45)
        self.assertEqual(sum(f["step_counts"].values()), 45)

    def test_r1_02_adoption_persists_native_proof(self):
        a = self.r["ADOPT"]
        ad = a["adopted_in_ledger"]
        self.assertTrue(ad["adopted_on_resume"])
        self.assertEqual(ad["native_exit"], 0)
        self.assertIsInstance(ad["child"]["pid"], int)
        self.assertEqual(ad["adoption"]["source_child"], ad["child"])
        self.assertEqual(ad["adoption"]["source_native_exit"], 0)
        self.assertEqual(ad["adoption"]["source_session"], a["first_session"])  # sessão cujo pai observou STEP_EXITED
        self.assertEqual(ad["adoption"]["receipt_exit_code"], 0)
        self.assertEqual(ad["adoption"]["receipt_sha256"], ad["receipt"]["sha256"])
        self.assertIsInstance(ad["adoption"]["source_partial_seq"], int)
        self.assertRegex(ad["adoption"]["source_partial_ledger_sha256"], "^[0-9A-F]{64}$")
        c3 = a["companion_contradictory"]
        self.assertEqual(c3["exit"], 2)
        self.assertTrue(c3["blocked_reason"].startswith("RESUME_DURABLE_RECEIPT_CHANGED REF_E3#0:COMPANION_EXIT_NE_RECEIPT"),
                        c3["blocked_reason"])
        f = a["final"]
        self.assertEqual(f["exit"], 0, f.get("log_tail"))
        self.assertEqual([s["case"] for s in f["adopted_steps"]], ["REF_E3"])
        self.assertEqual(f["adopted_steps"][0]["native_exit"], 0)
        self.assertEqual(f["steps_without_native"], [])

    def test_terminal_certificate_unique(self):
        s = self.r["SEAL_FAIL"]
        self.assertEqual(s["first"]["exit"], 3)
        self.assertEqual(s["first"]["receipt_doc_exit"], 0)
        self.assertFalse(s["first"]["receipt_valid"])  # exit nativo 3 != receipt 0: o bootstrap/consumidor recusa
        self.assertFalse((s["first"]["ledger_final"] or {}).get("complete"))
        r = s["resume"]
        self.assertEqual(r["exit"], 2)
        self.assertTrue(r["blocked_reason"].startswith("RESUME_TERMINAL_RECEIPT_EXISTS"), r["blocked_reason"])
        x = s["receipt_deleted"]
        self.assertEqual(x["exit"], 2)
        self.assertTrue(x["blocked_reason"].startswith("RESUME_PREVIOUS_RECEIPT_MISSING"), x["blocked_reason"])
        self.assertTrue(self.r["NO_PYCACHE"])


# =========================================================================== QS0-H: controles negativos (mutantes)
class H_QS0Mutants(unittest.TestCase):
    MUTANTS = {
        "M01_PS_STOP_PROCESS": ("BOOTSTRAP_QS4_HARNESS.ps1", "$script:AdapterChildStarted = $true\r\n    $hstatus",
                                "$script:AdapterChildStarted = $true\r\n    Stop-Process -Id 1\r\n    $hstatus", "S04_PS_FORBIDDEN_CONSTRUCTS"),
        "M02_PS_VERBATIM_DRIFT": ("BOOTSTRAP_QS4_HARNESS.ps1", "    Write-Host $Text\r\n", "    Write-Host ($Text)\r\n",
                                  "S03_PS_FUNCTIONS_VERBATIM_R3"),
        "M03_PS_LASTEXITCODE": ("BOOTSTRAP_QS4_HARNESS.ps1", "    $FinalCode = Get-StageExit $Items $RequiredItems[$Stage]\r\n",
                                "    $FinalCode = $LASTEXITCODE\r\n", "S04_PS_NO_LASTEXITCODE_SENTINEL"),
        "M04_PY_REMOVE": ("qs4_lib.py", "def is_inside(child, parent) -> bool:\n",
                          "def is_inside(child, parent) -> bool:\n    os.remove(str(child)) if False else None\n", "S05_NO_FILE_REMOVAL"),
        "M05_PY_KILL_OUTSIDE_P10": ("qs4_harness.py", "        ok = all(s[\"evaluation\"][\"pass\"] for s in cl[\"steps\"])\n",
                                    "        ok = all(s[\"evaluation\"][\"pass\"] for s in cl[\"steps\"])\n        os.kill(0, 0) if False else None\n",
                                    "S05_KILL_ONLY_P10_AND_P5"),
        "M06_SEAMS_TOP_IMPORT": ("qs4_flow.py", "from qs4_lib import (", "import qs4_seams  # noqa\nfrom qs4_lib import (",
                                 "S07_SEAMS_AFTER_SEAMSET_ENTER"),
        "M07_FINALIZE": ("qs4_flow.py", "                    rec[\"outcome\"] = {\"class\": \"COMPLETED_UNEXPECTED\"",
                         "                    ps.phase_b_only(fz.full.finalize_phase)(root, \"B\")\n"
                         "                    rec[\"outcome\"] = {\"class\": \"COMPLETED_UNEXPECTED\"", "S05_NEVER_FINALIZE"),
        "M08_PHASE_C": ("qs4_flow.py", "ps.phase_b_only(fz.full.run_phase)(root, \"B\",", "ps.phase_b_only(fz.full.run_phase)(root, \"C\",",
                        "S05_PHASE_B_ONLY"),
        "M09_ZIP_PIN": ("qs4_constants.json", "F14E7B149BDFB5184D09116122C7A6264F7A4798E08799DEBD852B45E959A775",
                        "EF06ABB72BB4341E1215155CFDD8B6D36C593CA1F125FB11E4EDC17F40D00217", "S02_R3_ZIP_PIN"),
        "M10_IMPORT_EFFECT": ("qs4_lib.py", "import time\n", "import time\nimport phase_b_shared  # noqa\n", "S08_IMPORT_SAFETY"),
        "M11_SHELL_TRUE": ("qs4_harness.py", "p = subprocess.Popen(cmd, stdout=fo, stderr=subprocess.STDOUT, env=self.child_env(), **self.L.popen_kwargs())",
                           "p = subprocess.Popen(cmd, stdout=fo, stderr=subprocess.STDOUT, env=self.child_env(), shell=True)",
                           "S05_NO_SHELL_TRUE"),
        "M12_EXTRA_FILE": (None, None, None, "S01_ALLOWED_FILES_ONLY"),
        "M13_LITERAL_DRIVE": ("qs4_lib.py", "ATTEMPT_RE = ", "_X = \"D:\\\\MinotauroRuns\"\nATTEMPT_RE = ", "S05_NO_LITERAL_DRIVE_PATHS"),
        "M14_P5_NO_CONSOLE": ("qs4_harness.py", "**L.popen_kwargs(console=(action == \"CTRL_C\")))", "**L.popen_kwargs())",
                              "S12_P5_OWN_REAL_CONSOLE"),
        "M15_PROCESS_GROUP": ("qs4_lib.py", "CREATE_NEW_CONSOLE = 0x00000010\n",
                              "CREATE_NEW_CONSOLE = 0x00000010\nCREATE_NEW_PROCESS_GROUP = 0x00000200\n", "S12_P5_OWN_REAL_CONSOLE"),
        "M16_NO_STEP_INTENT": ("qs4_harness.py", "        self.save(\"STEP_INTENT\")\n", "", "S14_LEDGER_INTENT_BEFORE_EFFECT"),
        "M17_MULTIWORK_PARALLEL": ("qs4_constants.json", "\"value\": \"NOT_APPLICABLE\"", "\"value\": \"PARALLEL\"",
                                   "S15_MULTIWORK_DECLARED"),
        "M18_CONCURRENCY_IMPORT": ("qs4_harness.py", "import threading\n", "import threading\nimport concurrent.futures  # noqa\n",
                                   "S15_PROOF_TEST_ISOLATION"),
        "M19_MICROPROBE_AFTER_REHASH": ("qs4_harness.py", "        self.phase = \"H07_P5_CONSOLE_MICROPROBE\"\n        self.status()\n        self.p5_microprobe()\n",
                                        "", "S13_P5_MICROPROBE_BEFORE_MATRIX"),
        "M20_NO_RESUME_GUARD": ("qs4_harness.py", "RESUME_PARTIAL_CHILD_ALIVE_RECONCILIATION_REQUIRED", "RESUME_PARTIAL_CHILD_X",
                                "S14_RESUME_GUARDS"),
        "M21_RELEASE_ROOT_REPLACED": ("qs4_flow.py", "control_root=str(root), shadow_base=", "control_root=str(root), release_root=str(root), shadow_base=",
                                      "S15_PROOF_R3_GLOBAL_NAMED_MUTEX"),
        "M22_COMPANION_NO_READBACK": ("qs4_lib.py", 'if comp.get("readback") != "PASS":', 'if False:', "S16_COMPANION_CONTRACT"),
        "M23_ADOPT_NATIVE_NONE": ("qs4_harness.py", '"native_exit": part["exited"]["native_exit"], "child"',
                                  '"native_exit": None, "child"', "S17_ADOPT_NATIVE_EXIT_PERSISTED"),
        "M24_HISTORY_AFTER_FINAL_CLEAR": ("qs4_harness.py", 'self.save("SESSION_HISTORY")', 'pass  # sem histórico',
                                          "S18_SESSION_STATE_TRANSFER"),
    }

    def test_mutants_killed(self):
        sys.path.insert(0, str(HARNESS / "qualification"))
        import qs0_qs4 as Q
        base = Path(tempfile.mkdtemp(prefix="qs0m_", dir=SCRATCH))
        clean = base / "CLEAN"
        shutil.copytree(HARNESS, clean, ignore=shutil.ignore_patterns("__pycache__"))
        res0 = {x["check"]: x["result"] for x in Q.check_all(clean, R3, os.environ.get("MINOTAURO_PWSH"))}
        self.assertEqual({k for k, v in res0.items() if v != "PASS"}, set())
        killed = {}
        for name, (f, old, new, want) in self.MUTANTS.items():
            d = base / name
            shutil.copytree(HARNESS, d, ignore=shutil.ignore_patterns("__pycache__"))
            if f is None:
                (d / "NOTES.txt").write_text("x")
            else:
                raw = (d / f).read_bytes()
                self.assertEqual(raw.count(old.encode("utf-8")), 1, name)
                (d / f).write_bytes(raw.replace(old.encode("utf-8"), new.encode("utf-8")))
            subprocess.run([sys.executable, "-B", str(d / "qualification" / "build_qs4_package.py"), str(d)], check=True,
                           capture_output=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
            got = {x["check"]: x["result"] for x in Q.check_all(d, R3, None)}
            killed[name] = got.get(want) == "FAIL" and got.get("S01_MANIFEST_EXACT") == "PASS"
        self.assertEqual({k for k, v in killed.items() if not v}, set())


# =========================================================================== bootstrap (PowerShell 7 Linux)
class H_Bootstrap(unittest.TestCase):
    def test_bootstrap_harness_ps(self):
        pwsh = os.environ.get("MINOTAURO_PWSH")
        if not pwsh or not Path(pwsh).is_file():
            self.fail("MINOTAURO_PWSH_REQUIRED")
        work = Path(tempfile.mkdtemp(prefix="bh_", dir=SCRATCH))
        r = subprocess.run([pwsh, "-NoProfile", "-NonInteractive", "-File", str(HERE / "qs4_bootstrap_harness.ps1"),
                            "-Bootstrap", str(HARNESS / "BOOTSTRAP_QS4_HARNESS.ps1"), "-Work", str(work), "-Harness", str(HARNESS),
                            "-R3", str(R3), "-Pwsh", pwsh], capture_output=True, text=True, timeout=600)
        self.assertEqual(r.returncode, 0, r.stdout[-3000:] + r.stderr[-2000:])
        self.assertIn("QS4_BOOTSTRAP_HARNESS=PASS", r.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
