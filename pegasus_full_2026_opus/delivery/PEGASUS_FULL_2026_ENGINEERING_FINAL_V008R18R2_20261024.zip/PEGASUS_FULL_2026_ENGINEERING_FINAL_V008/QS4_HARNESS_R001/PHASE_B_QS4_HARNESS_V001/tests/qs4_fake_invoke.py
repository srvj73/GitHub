"""PHASE_B_QS4_HARNESS_V001 — invocação SIMULADA (TESTE do orquestrador na sandbox). NUNCA usada no alvo.

Uso: python -B qs4_fake_invoke.py <harness_dir> --step-json <STEP.json>

Simula, de forma determinística e ROTULADA (bytes sintéticos, nenhum dado de mercado), o efeito estrutural que a
invocação real teria na raiz do caso, usando os NOMES do R3 (5 arquivos por sessão, selos em
TELEMETRY/SESSION_SEALS/<seal_key(raiz)>, RUN binding, journal no padrão do R3, RUN.lock/telemetria como resíduo) e o
PRÓPRIO classificador do R3 (classify_structure) para state_before/state_after e para recusar retomadas (G12).
Serve para provar o ORQUESTRADOR (sequência, comparação com referências, itens, códigos de saída, watchdog sem kill,
órfãos, deltas protegidos, B08), não o runtime congelado.

Falhas injetáveis por QS4_FAKE=<modo>:<CASE>[#<step>] (vários separados por vírgula):
  diverge      bytes de uma sessão diferentes da referência        -> caso FAIL, itens FAIL, exit 2
  noreceipt    sai 0 sem STEP_RECEIPT                               -> STEP_RESULT_NOT_PROVEN, exit 3
  hang         nunca termina                                        -> WATCHDOG_EXPIRED (sem kill), exit 3
  orphan       deixa um neto vivo                                   -> ORPHAN_ACTIVE (sem kill), exit 3
  touchcontrol altera o CONTROL real (literal)                      -> PROTECTED_DELTA, exit 3
  foreign      cria marcador _avast_ na raiz do caso (T30)          -> passo FAIL
  earlystop    para numa sessão diferente da pedida                  -> passo FAIL (ponto exato de parada)
  sigargs      Ctrl+C simulado com argumentos                        -> P5 FAIL (KeyboardInterrupt real não tem args)
  dirty        deixa um journal órfão no fim do passo                -> STATE_NOT_CLEAN
  exitnonzero  receipt válido + exit 1                               -> não provado ao vivo; NUNCA adotado na retomada
  slow         dorme QS4_FAKE_SLOW_S s (padrão 8) antes de agir (janela para quedas com o filho vivo)
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

TARGET_CODE = {"RUNLOCK_ENTER": "r1r11_resources/RunLock/__enter__", "PREPARE_VOLUME": "r1r11_full_2026/prepare_volume",
               "RECOVER": "r1r11_full_2026/recover", "LOAD_CHECKPOINT": "minotauro_v004_runner/_load_checkpoint",
               "WRITE_ANCHOR": "r1r11_fast_resume/write_anchor_checkpoint",
               "CLEAR_ANCHOR": "r1r11_fast_resume/clear_anchor_checkpoint"}


def _fake(case: str, step: int) -> set:
    out = set()
    for tok in filter(None, os.environ.get("QS4_FAKE", "").split(",")):
        mode, _, target = tok.partition(":")
        tc, _, ts = target.partition("#")
        if tc == case and (ts == "" or int(ts) == step):
            out.add(mode)
    return out


def main(argv) -> int:
    harness = Path(argv[0]).resolve()
    st = json.loads(Path(argv[2]).read_text(encoding="utf-8"))
    sys.path.insert(0, str(harness))
    sys.path.insert(0, str(Path(st["adapter_dir"])))
    from phase_b_contract import load_constants
    from phase_b_effects import inventory, inventory_digest, sha256_bytes, write_json_durable
    from phase_b_state import BLOCKED, classify_structure, seal_key
    from qs4_lib import STEP_RECEIPT_SCHEMA, write_receipt_with_companion

    c = load_constants(Path(st["adapter_dir"]) / "phase_b_constants.json")
    names = c["run_owned_names"]
    case, idx, stop = st["case"], int(st["step_index"]), st["stop"]
    modes = _fake(case, idx)
    root = Path(st["root"])
    sdir = Path(st["step_dir"])
    o2d = {int(k): v for k, v in st["ordinal_to_date"].items()}
    po = root / "PHASE_B"
    sd = po / "sessions"
    jdir = po / "_commit_journal"
    cp_p = po / "CHECKPOINT.json"
    rec = {"schema": STEP_RECEIPT_SCHEMA, "attempt_id": st["invocation_attempt_id"], "case": case, "step": idx,
           "kind": st["kind"], "root": str(root), "simulated": "FAKE_INVOKE_TEST_ONLY", "pid": os.getpid()}
    rec["root_digest_before"] = inventory_digest(inventory(root))
    if "slow" in modes:
        time.sleep(float(os.environ.get("QS4_FAKE_SLOW_S", "8")))
    if "hang" in modes:
        while True:
            time.sleep(1)
    if "orphan" in modes:
        subprocess.Popen([sys.executable, "-c", "import time; time.sleep(30)"])  # mesmo grupo de processo
    if "touchcontrol" in modes:
        with (Path(c["paths"]["control_root"]) / "FULL_2026_CONFIGURATION.json").open("ab") as f:
            f.write(b" ")

    def classify():
        return classify_structure(inventory(root), c, root)

    def finish_rec():
        struct = classify()
        rec["state_after"] = struct["state"]
        rec["state_after_findings"] = struct["findings"][:20]
        rec["state_after_detail"] = {"journal": bool(struct.get("journal")), "pending": len(struct.get("pending") or [])}
        rec["committed_count"] = len([p for p in sd.iterdir() if p.is_dir()]) if sd.is_dir() else 0
        if struct["state"] == "IN_PROGRESS" and rec["outcome"]["class"] != "BLOCKED":
            rec["t17"] = {"validate_in_progress": "PASS"}
        rec["t30"] = {"foreign": (["control:_avast_"] if "foreign" in modes else [])}
        rec["root_digest_after"] = inventory_digest(inventory(root))
        rec["exit_code"] = 0

    def blocked(code, detail):
        rec["outcome"] = {"class": "BLOCKED", "seam": None, "code": code, "detail": (code + " " + detail).strip(),
                          "detail_len": len(detail)}
        rec["blocked_gate"] = "G12"
        rec["runtime_evidence"] = {"started": False, "clean": False}
        finish_rec()

    s0 = classify()
    lines = []
    if "VARIANT_ADAPTER" in st["adapter_dir"].replace("\\", "/"):
        blocked("ADAPTER_IDENTITY_MISMATCH", "adapter_identity_sha256")
    elif s0["state"] == BLOCKED:
        blocked("STATE_BLOCKED_AMBIGUOUS", ";".join(s0["findings"]))
    else:
        rec["state_before"] = s0["state"]
        (root / "GATES").mkdir(exist_ok=True)
        rb = root / names["run_binding"]
        if not rb.exists():  # G19 simulado
            rb.write_text(json.dumps({"schema": "FAKE_RUN_BINDING_TEST_ONLY"}), encoding="utf-8")
        cp = json.loads(cp_p.read_text()) if cp_p.is_file() else None
        jb = len(list(jdir.iterdir())) if jdir.is_dir() else 0
        if jdir.is_dir():  # G21 PRE_RECOVER simulado: journal resolvido antes do run_phase
            for p in list(jdir.iterdir()):
                p.unlink()  # TESTE: raiz temporária da sandbox
        rec["t31b"] = {"journal_before_g21": jb, "journal_after_g21": len(list(jdir.iterdir())) if jdir.is_dir() else 0,
                       "stale_line_before_g21": False}
        key = seal_key(root)

        def runlock():
            (root / "RUN.lock").write_text(json.dumps({"pid": os.getpid(), "creation_time_100ns": 1}), encoding="utf-8")

        def telemetry():
            (root / "TELEMETRY").mkdir(exist_ok=True)
            (root / "TELEMETRY" / "R1R11_STATUS.json").write_text("{}", encoding="utf-8")

        def load_cp():
            nonlocal cp
            if cp is None:
                cp = {"completed": [], "phase": "B"}
                save_cp()

        def save_cp():
            cp["config_sha256"] = hashlib.sha256(str(root).encode()).hexdigest().upper()  # volátil (raiz)
            cp["checkpoint_content_sha256"] = os.urandom(32).hex().upper()  # volátil
            cp["cash_units"] = 1000 + len(cp["completed"])
            po.mkdir(exist_ok=True)
            cp_p.write_text(json.dumps(cp, sort_keys=True), encoding="utf-8")

        def commit(n):
            sd.mkdir(exist_ok=True)
            for o in range(1, n + 1):
                d = o2d[o]
                if d in cp["completed"]:
                    continue
                (sd / d).mkdir()
                for i, nm in enumerate(names["session_files"]):
                    body = hashlib.sha256(f"SYNTHETIC_FAKE {d} {nm}".encode()).digest() * (16 + o + i)
                    if "diverge" in modes and o == 1 and i == 0:
                        body += b"DIVERGE"
                    (sd / d / nm).write_bytes(body)
                seal = root / "TELEMETRY" / "SESSION_SEALS" / key / (d + ".json")
                seal.parent.mkdir(parents=True, exist_ok=True)
                seal.write_text("{}", encoding="utf-8")
                cp["completed"].append(d)
            save_cp()

        def unlock():
            if (root / "RUN.lock").exists():
                (root / "RUN.lock").unlink()  # RunLock.__exit__ simulado

        tgt = stop.get("interrupt_target")
        try:
            if st.get("template") == "ALTERED":
                runlock(); telemetry(); load_cp(); unlock()
                rec["outcome"] = {"class": "TRACE_GUARD", "code": "TRACE_GUARD_MISMATCH", "seam": None, "detail_len": 20}
            elif tgt in ("RUNLOCK_ENTER", "PREPARE_VOLUME", "RECOVER"):
                runlock()  # P1: interrupção logo após RunLock.__enter__ => RUN.lock fica (o __exit__ não roda)
                if tgt != "RUNLOCK_ENTER":
                    telemetry()  # P2/P3: Runtime() já gravou telemetria; o __exit__ do RunLock roda
                    unlock()
                rec["outcome"] = {"class": "INTERRUPT_SEAM", "seam": "SEAM_INTERRUPT_AFTER", "code": TARGET_CODE[tgt], "detail_len": 40}
            else:
                runlock(); telemetry(); load_cp()
                if tgt in ("LOAD_CHECKPOINT", "WRITE_ANCHOR"):
                    if tgt == "WRITE_ANCHOR":
                        lines.append("SAFE_STOP_REQUESTED=YES phase=B session=" + o2d[1])
                    rec["outcome"] = {"class": "INTERRUPT_SEAM", "seam": "SEAM_INTERRUPT_AFTER", "code": TARGET_CODE[tgt], "detail_len": 40}
                elif tgt == "CLEAR_ANCHOR":
                    commit(21)
                    rec["outcome"] = {"class": "INTERRUPT_SEAM", "seam": "SEAM_INTERRUPT_AFTER", "code": TARGET_CODE[tgt], "detail_len": 40}
                elif "fault" in stop:
                    if stop["fault"] != "before_journal":
                        jdir.mkdir(parents=True, exist_ok=True)
                        (jdir / (o2d[1] + f".{os.getpid()}_1.json")).write_text("{}", encoding="utf-8")
                    rec["outcome"] = {"class": "FAULT", "code": "FAULT_" + stop["fault"].upper(), "seam": None, "detail_len": 20}
                elif "notify_anchor_ordinal" in st:
                    commit(int(st["notify_anchor_ordinal"]) - 1)
                    (sdir / "QS4_MARKER_NOTIFY.txt").write_text("NOTIFY\n")
                    try:
                        time.sleep(60)
                        raise RuntimeError("FAKE_P5_SIGNAL_NOT_RECEIVED")
                    except KeyboardInterrupt as e:
                        lines.append("SAFE_STOP_REQUESTED=YES phase=B session=SIGNAL")
                        n = len(str(e)) + (8 if "sigargs" in modes else 0)
                        rec["outcome"] = {"class": "INTERRUPT_SIGNAL", "seam": None, "code": None, "detail_len": n}
                elif "block_anchor_ordinal" in st:
                    commit(int(st["block_anchor_ordinal"]) - 1)
                    (sdir / "QS4_MARKER_BLOCK.txt").write_text("BLOCK\n")
                    while True:
                        time.sleep(0.2)  # aguarda o P10 (SIGKILL na sandbox)
                else:
                    n = int(stop["anchor_ordinal"])
                    commit(n - 1)
                    stop_o = n + (1 if "earlystop" in modes else 0)
                    lines.append("SAFE_STOP_REQUESTED=YES phase=B session=" + o2d[stop_o])
                    rec["outcome"] = {"class": "INTERRUPT_SEAM", "seam": "QS4_STOP_ANCHOR", "code": "session=" + o2d[stop_o],
                                      "detail_len": 40}
                unlock()
        finally:
            rec.setdefault("outcome", {"class": "ERROR", "seam": None, "code": "FAKE_INCOMPLETE", "detail_len": 0})
        if "dirty" in modes:
            jdir.mkdir(parents=True, exist_ok=True)
            (jdir / (o2d[1] + f".{os.getpid()}_9.json")).write_text("{}", encoding="utf-8")
        rec["trace_guard"] = ("PASS_COMPARED" if st.get("template") == "QS3" else "PASS_NOT_APPLICABLE") \
            if rec["outcome"]["class"] not in ("TRACE_GUARD",) else "NOT_REACHED"
        rec["runtime_evidence"] = {"started": True, "clean": True}
        if "foreign" in modes:
            (root / "_avast_").mkdir(exist_ok=True)
        finish_rec()
    rec["safe_stop_requested_line"] = any(x.startswith("SAFE_STOP_REQUESTED=YES") for x in lines)
    rec["raw_trace_sha256"] = sha256_bytes("\n".join(lines).encode())
    if "noreceipt" in modes:
        return 0
    if "exitnonzero" in modes:  # receipt válido gravado, mas o processo termina com exit != 0 (queda no encerramento)
        write_receipt_with_companion(sdir / "STEP_RECEIPT.json", rec, write_json_durable)
        return 1
    write_receipt_with_companion(sdir / "STEP_RECEIPT.json", rec, write_json_durable)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
