"""PHASE_B_QS4_HARNESS_V001 — wrapper de TESTE do orquestrador (sandbox Linux). NUNCA usado no alvo.

Uso: python -B qs4_orch_wrapper.py <harness_dir> <real|fake> orchestrate --attempt-id ... (CLI fechada do harness)

  real  cada invocação usa tests/qs4_invoke_wrapper.py (fluxo REAL do harness + R3 + CODE congelado; plataforma fake;
        para em RunLock por exigir Win32)
  fake  cada invocação usa tests/qs4_fake_invoke.py (efeitos SIMULADOS rotulados) para provar o orquestrador
QS4_TEST_STATUS_FAIL=1  faz UMA gravação de HARNESS_STATUS falhar depois das pré-condições (B08 no harness).
QS4_TEST_BLOCK_AFTER_CASE=<id>  levanta HarnessBlocked logo após o caso <id> (antes do check_protected do caso).
QS4_TEST_CRASH=<case>#<step>:<EVENT>  queda simulada do orquestrador (os._exit(77)) após o evento durável do ledger
   (STEP_INTENT, STEP_CHILD, CASE_SEEDING, RELOCATE_INTENT; '*' para VARIANT_BUILDING/FINAL_PENDING), STEP_CHILD_GAP
   (antes do registro do pid do filho) ou BEFORE_COMMIT (filho terminou com receipt; registro não feito).
QS4_TEST_SEAL_FAIL=1  a gravação FINAL_SEALED do ledger falha depois do receipt (certificado terminal sem STATE selado).
QS4_TEST_P5_PROBE=nosignal|helperfail  o auxiliar de CTRL_C não entrega o sinal / falha (microprobe P5 deve bloquear).
Nada além de Orchestrator.invoke_cmd (e, opcionalmente, write_status_atomic / run_case / save / commit_step /
send_ctrl_c) é substituído.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main(argv) -> int:
    harness = Path(argv[0]).resolve()
    mode = argv[1]
    sys.path.insert(0, str(harness))
    import qs4_harness as H
    import qs4_lib as L
    script = {"real": HERE / "qs4_invoke_wrapper.py", "fake": HERE / "qs4_fake_invoke.py"}[mode]

    def invoke_cmd(self, step_json):
        return L.python_cmd() + [str(script), str(harness), "--step-json", str(step_json)]
    H.Orchestrator.invoke_cmd = invoke_cmd
    if os.environ.get("QS4_TEST_STATUS_FAIL") == "1":
        orig_pre = H.Orchestrator.preconditions

        def pre(self):
            orig_pre(self)
            E = self.E
            real = E.write_status_atomic
            state = {"n": 0}

            def failing(path, doc):
                if Path(path).name != "HARNESS_STATUS.json":  # ledger/checkpoint usam o mesmo escritor: não afetados
                    return real(path, doc)
                state["n"] += 1
                if state["n"] == 1:
                    raise OSError("TEST_INJECTED_STATUS_FAILURE")
                return real(path, doc)
            E.write_status_atomic = failing
        H.Orchestrator.preconditions = pre
    blk = os.environ.get("QS4_TEST_BLOCK_AFTER_CASE")
    if blk:
        orig_case = H.Orchestrator.run_case

        def run_case(self, case):
            r = orig_case(self, case)
            if case["id"] == blk:  # bloqueio injetado ANTES do check_protected do caso
                raise L.HarnessBlocked("TEST_INJECTED_BLOCK_AFTER_CASE", blk)
            return r
        H.Orchestrator.run_case = run_case
    crash = os.environ.get("QS4_TEST_CRASH")  # "<case>#<step>:<EVENT>" => os._exit(77) do orquestrador (queda simulada)
    if crash:
        target, _, point = crash.partition(":")
        tc, _, ts = target.partition("#")
        orig_save = H.Orchestrator.save

        def save(self, event):
            part = (self.led or {}).get("partial") or {}
            if point == "STEP_CHILD_GAP" and event == "STEP_CHILD" and part.get("case") == tc and str(part.get("step")) == ts:
                os._exit(77)  # queda ENTRE o Popen e o registro do pid do filho (filho vivo e desconhecido do ledger)
            orig_save(self, event)
            part = (self.led or {}).get("partial") or {}
            if event == point and (tc == "*" or (part.get("case") == tc and str(part.get("step")) == ts)):
                os._exit(77)
            if event == point == "CASE_SEEDING" and tc in (self.led or {}).get("cases", {}):
                os._exit(77)
        H.Orchestrator.save = save
        if point == "BEFORE_COMMIT":
            orig_commit = H.Orchestrator.commit_step

            def commit_step(self, case, i, step, res, rec, root, action, adopted=False):
                if case["id"] == tc and str(i) == ts and not adopted:
                    os._exit(77)
                return orig_commit(self, case, i, step, res, rec, root, action, adopted)
            H.Orchestrator.commit_step = commit_step
    if os.environ.get("QS4_TEST_SEAL_FAIL") == "1":  # o selo FINAL_SEALED do ledger falha (após o receipt)
        orig_save2 = H.Orchestrator.save

        def save2(self, event):
            if event == "FINAL_SEALED":
                raise H.Unproven("LEDGER_WRITE_FAILED", "FINAL_SEALED TEST_INJECTED")
            return orig_save2(self, event)
        H.Orchestrator.save = save2
    probe = os.environ.get("QS4_TEST_P5_PROBE")  # nosignal | helperfail: o microprobe P5 tem de BLOQUEAR
    if probe:
        def send_ctrl_c(self, pid):
            return {"method": "TEST_" + probe.upper(), "helper_exit": 0 if probe == "nosignal" else 2}
        H.Orchestrator.send_ctrl_c = send_ctrl_c
    return H.main(argv[2:])


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
