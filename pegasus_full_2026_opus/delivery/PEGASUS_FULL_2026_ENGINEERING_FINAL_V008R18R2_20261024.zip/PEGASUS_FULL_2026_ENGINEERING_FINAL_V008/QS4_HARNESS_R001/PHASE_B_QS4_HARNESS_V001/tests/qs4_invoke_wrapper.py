"""PHASE_B_QS4_HARNESS_V001 — wrapper de TESTE (sandbox Linux) para `qs4_harness.py invoke`. NUNCA usado no alvo.

Uso: python -B qs4_invoke_wrapper.py <harness_dir> --step-json <STEP.json>

Únicas substituições (rotuladas, só sandbox):
  * phase_b_shared.WindowsPlatform -> plataforma FAKE (mutex em memória; observação de runtime = constantes; espaço livre
    fictício), porque a sandbox não tem Win32;
  * emulação N-15: após prepare_preflight/build_binding CONGELADOS, SPEC_HASH.txt/RUNNER_HASH.txt recebem CRLF (no Windows o
    write_text sem newline= já grava CRLF — byte-igualdade só existe no alvo).
O CODE congelado, o fluxo do harness e o R3 são executados sem alteração; o runtime para em RunLock (Win32).
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path


def main(argv) -> int:
    harness = Path(argv[0]).resolve()
    if argv[1] != "--step-json":
        return 2
    step_json = Path(argv[2])
    st = json.loads(step_json.read_text(encoding="utf-8"))
    sys.path.insert(0, str(harness))
    sys.path.insert(0, str(Path(st["adapter_dir"])))
    import phase_b_shared as ps
    from phase_b_effects import AdapterBlocked

    c = json.loads((Path(st["adapter_dir"]) / "phase_b_constants.json").read_text(encoding="utf-8"))
    observed = {k: c["runtime"][k] for k in ("python_exe", "python_exe_sha256", "python_version", "numpy", "numpy_origin")}

    class FakePlatform:  # TESTE — não Win32
        held: dict = {}

        def acquire_named_mutex(self, name):
            if name in self.held:
                raise AdapterBlocked("MUTEX_ACTIVE_OR_UNAVAILABLE", name)
            self.held[name] = True
            return name

        def release_named_mutex(self, h):
            self.held.pop(h)

        def runtime_observation(self):
            return dict(observed)

        @staticmethod
        def free_bytes(path):
            return 10 ** 13

        def host_observation(self, paths):
            return {"platform": "FIXTURE_FAKE_PLATFORM", "status": "FIXTURE"}

    ps.WindowsPlatform = FakePlatform
    tolerant = list(c["platform_dependent_prepared_files"]["files"])
    orig_only = ps.phase_b_only

    def phase_b_only(fn):
        g = orig_only(fn)
        if getattr(fn, "__name__", "") not in ("prepare_preflight", "build_binding"):
            return g

        def emulate(out, phase, *a, **k):
            r = g(out, phase, *a, **k)
            for rel in tolerant:
                p = Path(out) / rel
                if p.is_file():
                    data = p.read_bytes()
                    if b"\r\n" not in data:
                        p.write_bytes(data.replace(b"\n", b"\r\n"))
            return r
        return emulate
    ps.phase_b_only = phase_b_only
    if os.environ.get("QS4_TEST_SEAM_PROBE") == "1":
        # TESTE: registra a ordem real de carga do módulo de seams do R3 relativa ao SeamSet.__enter__
        orig_enter = ps.SeamSet.__enter__

        def enter(self):
            sys.stdout.write("QS4_TEST_SEAMSET_ENTER seams_loaded=" + str("phase_b_qualification_seams" in sys.modules) + "\n")
            return orig_enter(self)
        ps.SeamSet.__enter__ = enter
    import qs4_flow
    return qs4_flow.invoke(step_json)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
