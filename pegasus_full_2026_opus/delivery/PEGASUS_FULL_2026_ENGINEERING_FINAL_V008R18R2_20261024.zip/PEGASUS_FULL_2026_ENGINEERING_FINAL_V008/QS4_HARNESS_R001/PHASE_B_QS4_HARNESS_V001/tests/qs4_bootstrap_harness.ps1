<#
PHASE_B_QS4_HARNESS_V001 - QS1-H harness do BOOTSTRAP_QS4_HARNESS.ps1 (sandbox; pwsh 7 Linux). Somente ASCII.
Carrega SOMENTE as definicoes de funcao via AST para B1-B3; B4-B5 executam o script inteiro em cwd temporario
(o corpo para cedo: autorizacao/pinos/QS3 ou WINDOWS_POWERSHELL_5_1_REQUIRED), provando a cauda B08 (status final
ACTIVE=NO, receipt do estagio com companion, FINAL_EXIT no log) sem nenhum efeito alem da pasta de evidencia.
  B1 Confirm-PackageIdentity: R3 real (identidade pinada), harness real, adulteracao/extra/entrada invalida/identidade
  B2 Test-HarnessReceipt: positivo exit 0 (status final vinculado) e exit 2; 16 negativos (identidades R3/harness,
     attempt lógico da retomada, MULTIWORK)
  B3 Get-StageExit com os itens QS4 (0 so com todos PASS; 3 com efeito nao provado)
  B4 bloqueios antes da pasta de tentativa: texto de autorizacao, zip R3 nao pinado, QS3 relativo, SHA do QS3
  B5 bloqueio apos a pasta de tentativa (PowerShell != 5.1): exit 2, status final ACTIVE=NO, receipt + companion
Limitacao declarada: pwsh 7 em Linux, nao Windows PowerShell 5.1.
#>
param(
    [Parameter(Mandatory = $true)][string]$Bootstrap,
    [Parameter(Mandatory = $true)][string]$Work,
    [Parameter(Mandatory = $true)][string]$Harness,
    [Parameter(Mandatory = $true)][string]$R3,
    [Parameter(Mandatory = $true)][string]$Pwsh
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$StatusFields = @('PHASE', 'PROGRESS', 'COMMITTED', 'TOTAL', 'RATE', 'ETA', 'FINISH', 'ACTIVE', 'READY_WAITING', 'CHECKPOINT', 'SAFE_STOP')
$AttemptId = '20261003T000000Z_0000c0de'
$R3IdentityPinned = '05A0CF3D807A63BA7FD5BB36374D93E56E3D727183CFD3C62D3C0D637F1DDD0A'
$script:Unproven = $false
$script:LastReceiptDoc = $null
$script:HarnessIdentity = 'E' * 64
$script:Qs4Logical = '20261003T000000Z_00000aaa'
$Work = (Resolve-Path -LiteralPath $Work).Path
$tokens = $null
$errors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($Bootstrap, [ref]$tokens, [ref]$errors)
if ($errors.Count -ne 0) { throw 'BOOTSTRAP_PARSE_ERRORS' }
$fns = $ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true)
foreach ($f in $fns) { . ([ScriptBlock]::Create($f.Extent.Text)) }
Write-Host ('FUNCTIONS_LOADED=' + $fns.Count)
$results = [ordered]@{}
function Assert-True([bool]$Cond, [string]$Msg) { if (-not $Cond) { throw ('ASSERT ' + $Msg) } }
function Get-Throw([scriptblock]$Sb) { try { & $Sb; return 'NO_THROW' } catch { return $_.Exception.Message } }
function Copy-Tree([string]$Src, [string]$Dst) { Copy-Item -LiteralPath $Src -Destination $Dst -Recurse }

# B1
$r3Id = Confirm-PackageIdentity $R3 'ADAPTER_IDENTITY.json' 'adapter_identity_sha256'
Assert-True ($r3Id -eq $R3IdentityPinned) 'B1 r3 pinned identity'
$hId = Confirm-PackageIdentity $Harness 'HARNESS_IDENTITY.json' 'harness_identity_sha256'
Assert-True ($hId -eq (Get-Sha256 (Join-Path $Harness 'MANIFEST_SHA256.txt'))) 'B1 harness identity'
$c1 = Join-Path $Work 'B1_TAMPER'; Copy-Tree $Harness $c1
[System.IO.File]::AppendAllText((Join-Path $c1 'qs4_lib.py'), "#x`n")
Assert-True ((Get-Throw { Confirm-PackageIdentity $c1 'HARNESS_IDENTITY.json' 'harness_identity_sha256' }) -eq 'PACKAGE_MEMBER_HASH qs4_lib.py') 'B1 tamper'
$c2 = Join-Path $Work 'B1_EXTRA'; Copy-Tree $Harness $c2
New-Item -ItemType Directory -Path (Join-Path $c2 '__pycache__') | Out-Null
[System.IO.File]::WriteAllText((Join-Path (Join-Path $c2 '__pycache__') 'x.pyc'), 'x')
Assert-True ((Get-Throw { Confirm-PackageIdentity $c2 'HARNESS_IDENTITY.json' 'harness_identity_sha256' }) -eq 'PACKAGE_EXTRA_FILE __pycache__/x.pyc') 'B1 extra'
$c3 = Join-Path $Work 'B1_ENTRY'; Copy-Tree $Harness $c3
[System.IO.File]::AppendAllText((Join-Path $c3 'MANIFEST_SHA256.txt'), ('0' * 64) + '  ../escape.txt' + "`n")
Assert-True ((Get-Throw { Confirm-PackageIdentity $c3 'HARNESS_IDENTITY.json' 'harness_identity_sha256' }).StartsWith('PACKAGE_MANIFEST_ENTRY')) 'B1 entry'
$c4 = Join-Path $Work 'B1_IDENT'; Copy-Tree $Harness $c4
$idp = Join-Path $c4 'HARNESS_IDENTITY.json'
[System.IO.File]::WriteAllText($idp, ([System.IO.File]::ReadAllText($idp)).Replace($hId, ('A' * 64)))
Assert-True ((Get-Throw { Confirm-PackageIdentity $c4 'HARNESS_IDENTITY.json' 'harness_identity_sha256' }).StartsWith('PACKAGE_IDENTITY_NE_MANIFEST')) 'B1 identity'
$c5 = Join-Path $Work 'B1_MISSING'; Copy-Tree $Harness $c5
Remove-Item -LiteralPath (Join-Path $c5 'qs4_seams.py')
Assert-True ((Get-Throw { Confirm-PackageIdentity $c5 'HARNESS_IDENTITY.json' 'harness_identity_sha256' }) -eq 'PACKAGE_MEMBER_MISSING qs4_seams.py') 'B1 missing'
$results['B1_CONFIRM_PACKAGE_IDENTITY'] = 'PASS'

# B2
function Write-Canon([string]$Path, $Obj) {
    $t = $Obj | ConvertTo-Json -Depth 8 -Compress
    [System.IO.File]::WriteAllBytes($Path, $Utf8NoBom.GetBytes($t + "`n"))
    return (Get-BytesSha256 ([System.IO.File]::ReadAllBytes($Path)))
}
function New-Hr([string]$Name, [int]$Exit, [hashtable]$Mut) {
    $d = Join-Path $Work ('B2_' + $Name)
    [void](New-Item -ItemType Directory -Path $d)
    $st = [ordered]@{ schema = 'MINOTAURO_PHASE_B_QS4_HARNESS_STATUS_V001'; fields = [ordered]@{ ACTIVE = 'NO' }; extra = [ordered]@{ exit_code = $Exit } }
    if ($Mut.ContainsKey('status_active')) { $st.fields.ACTIVE = 'YES' }
    $ssha = Write-Canon (Join-Path $d 'HARNESS_STATUS.json') $st
    $rec = [ordered]@{ schema = 'MINOTAURO_PHASE_B_QS4_HARNESS_RECEIPT_V001'; attempt_id = $AttemptId; exit_code = $Exit;
                       result = $(if ($Exit -eq 0) { 'PASS' } else { 'NOT_PASS' }); r3_identity_sha256 = $R3IdentityPinned;
                       harness_identity_sha256 = ('E' * 64); logical_attempt = '20261003T000000Z_00000aaa';
                       multiwork = [ordered]@{ value = 'NOT_APPLICABLE' }; terminal = ($Exit -eq 0);
                       status_write_failures = 0; status_final_persisted = $true; status_final_sha256 = $ssha }
    foreach ($k in @('schema', 'attempt_id', 'exit_code', 'result', 'r3_identity_sha256', 'harness_identity_sha256', 'logical_attempt', 'multiwork', 'terminal', 'status_write_failures', 'status_final_persisted', 'status_final_sha256')) {
        if ($Mut.ContainsKey($k)) { $rec[$k] = $Mut[$k] }
    }
    $p = Join-Path $d 'QS4_HARNESS_RECEIPT.json'
    $sha = Write-Canon $p $rec
    if (-not $Mut.ContainsKey('no_companion')) {
        $comp = [ordered]@{ schema = 'MINOTAURO_PHASE_B_QS4_RECEIPT_VERIFIED_V001'; receipt_sha256 = $sha; attempt_id = $AttemptId; exit_code = $Exit; readback = 'PASS' }
        if ($Mut.ContainsKey('comp_sha')) { $comp.receipt_sha256 = '0' * 64 }
        if ($Mut.ContainsKey('comp_exit')) { $comp.exit_code = $Mut['comp_exit'] }
        if ($Mut.ContainsKey('comp_readback')) { $comp.readback = $Mut['comp_readback'] }
        if ($Mut.ContainsKey('comp_attempt')) { $comp.attempt_id = $Mut['comp_attempt'] }
        [void](Write-Canon (Join-Path $d 'QS4_HARNESS_RECEIPT.VERIFIED.json') $comp)
    }
    if ($Mut.ContainsKey('status_tamper')) { [System.IO.File]::AppendAllText((Join-Path $d 'HARNESS_STATUS.json'), ' ') }
    return $p
}
$ok0 = Test-HarnessReceipt (New-Hr 'OK0' 0 @{}) 0
Assert-True ($ok0.valid -and $ok0.reason -eq 'OK') ('B2 ok0 ' + $ok0.reason)
Assert-True ($null -ne $script:LastReceiptDoc) 'B2 doc kept'
$ok2 = Test-HarnessReceipt (New-Hr 'OK2' 2 @{ status_active = $true }) 2
Assert-True ($ok2.valid) ('B2 ok2 (exit 2 nao exige status final) ' + $ok2.reason)
$neg = [ordered]@{
    'N_SCHEMA' = @(0, @{ schema = 'X' }, 0, 'RECEIPT_SCHEMA');
    'N_ATTEMPT' = @(0, @{ attempt_id = '20261003T000000Z_00000000' }, 0, 'RECEIPT_ATTEMPT_ID');
    'N_EXIT' = @(0, @{}, 2, 'RECEIPT_EXIT_CODE_NE_NATIVE');
    'N_RESULT' = @(0, @{ result = 'NOT_PASS' }, 0, 'RECEIPT_RESULT_NE_NATIVE');
    'N_RESULT2' = @(2, @{ result = 'PASS' }, 2, 'RECEIPT_RESULT_NE_NATIVE');
    'N_R3' = @(0, @{ r3_identity_sha256 = ('B' * 64) }, 0, 'RECEIPT_R3_IDENTITY');
    'N_HID' = @(0, @{ harness_identity_sha256 = ('F' * 64) }, 0, 'RECEIPT_HARNESS_IDENTITY');
    'N_LOGICAL' = @(0, @{ logical_attempt = '20261003T000000Z_00000bbb' }, 0, 'RECEIPT_LOGICAL_ATTEMPT');
    'N_MULTIWORK' = @(0, @{ multiwork = [ordered]@{ value = 'PARALLEL' } }, 0, 'RECEIPT_MULTIWORK');
    'N_NOCOMP' = @(0, @{ no_companion = $true }, 0, 'RECEIPT_NOT_VERIFIED_BY_HARNESS');
    'N_COMPSHA' = @(0, @{ comp_sha = $true }, 0, 'RECEIPT_COMPANION_MISMATCH');
    'N_COMP_CONTRA' = @(0, @{ comp_exit = 3; comp_readback = 'FAIL' }, 0, 'RECEIPT_COMPANION_MISMATCH');
    'N_COMP_READBACK' = @(0, @{ comp_readback = 'FAIL' }, 0, 'RECEIPT_COMPANION_MISMATCH');
    'N_COMP_EXITSTR' = @(0, @{ comp_exit = '0' }, 0, 'RECEIPT_COMPANION_MISMATCH');
    'N_COMP_ATTEMPT' = @(0, @{ comp_attempt = '20261003T000000Z_00000000' }, 0, 'RECEIPT_COMPANION_MISMATCH');
    'N_TERMINAL0' = @(0, @{ terminal = $false }, 0, 'RECEIPT_TERMINAL_FLAG');
    'N_TERMINALTYPE' = @(2, @{ terminal = 'false' }, 2, 'RECEIPT_TERMINAL_FLAG');
    'N_STFAIL' = @(0, @{ status_write_failures = 1 }, 0, 'RECEIPT_STATUS_NOT_PERSISTED');
    'N_STNOTPERS' = @(0, @{ status_final_persisted = $false }, 0, 'RECEIPT_STATUS_NOT_PERSISTED');
    'N_STTAMPER' = @(0, @{ status_tamper = $true }, 0, 'RECEIPT_STATUS_FINAL_MISMATCH');
    'N_STACTIVE' = @(0, @{ status_active = $true }, 0, 'RECEIPT_STATUS_FINAL_MISMATCH')
}
foreach ($k in $neg.Keys) {
    $v = $neg[$k]
    $r = Test-HarnessReceipt (New-Hr $k $v[0] $v[1]) $v[2]
    Assert-True ((-not $r.valid) -and $r.reason -eq $v[3]) ('B2 ' + $k + ' got=' + $r.reason)
}
$missing = Test-HarnessReceipt (Join-Path $Work 'NOPE.json') 0
Assert-True ($missing.reason -eq 'RECEIPT_MISSING') 'B2 missing'
$results['B2_TEST_HARNESS_RECEIPT_POS_2_NEG_22'] = 'PASS'

# B3
$req = @('T26', 'QS4_HARNESS', 'T16', 'T17', 'T18', 'T22', 'T29', 'T30', 'T31b', 'T33', 'GROWTH_G16')
$it = [ordered]@{}
foreach ($q in $req) { $it[$q] = [ordered]@{ result = 'PASS' } }
Assert-True ((Get-StageExit $it $req) -eq 0) 'B3 all pass'
$it2 = [ordered]@{}; foreach ($q in $req) { if ($q -ne 'T29') { $it2[$q] = [ordered]@{ result = 'PASS' } } }
Assert-True ((Get-StageExit $it2 $req) -eq 2) 'B3 missing item'
$it['T31b'] = [ordered]@{ result = 'FAIL' }
Assert-True ((Get-StageExit $it $req) -eq 2) 'B3 failed item'
$script:Unproven = $true
Assert-True ((Get-StageExit $it $req) -eq 3) 'B3 unproven'
$script:Unproven = $false
$results['B3_GET_STAGE_EXIT_QS4'] = 'PASS'

# B4/B5: script inteiro (pwsh). Unica adaptacao de sandbox (rotulada): as duas constantes de caminho 'D:\...'
# ($PackageBase/$EvidenceBase) sao trocadas por pastas temporarias, pois o pwsh Linux nao tem a unidade D:.
$bootText = [System.IO.File]::ReadAllText($Bootstrap)
$lineE = "`$EvidenceBase    = 'D:\MinotauroRuns\MINOTAURO_PHASE_B_ADAPTER_EVIDENCE'"
$lineP = "`$PackageBase     = 'D:\MinotauroRuns\MINOTAURO_PHASE_B_ADAPTER_PKG'"
Assert-True (([regex]::Matches($bootText, [regex]::Escape($lineE))).Count -eq 1) 'B4 evidence line'
Assert-True (([regex]::Matches($bootText, [regex]::Escape($lineP))).Count -eq 1) 'B4 package line'
$zipH = Join-Path $Work 'H.zip'; [System.IO.File]::WriteAllText($zipH, 'not-a-zip')
$zipR = Join-Path $Work 'R.zip'; [System.IO.File]::WriteAllText($zipR, 'not-a-zip')
$qs3 = Join-Path $Work 'QS3_RECEIPT.json'; [System.IO.File]::WriteAllText($qs3, '{}')
$qs3Sha = Get-Sha256 $qs3
function Invoke-Boot([string]$Name, [string[]]$Extra) {
    $cwd = Join-Path $Work ('RUN_' + $Name)
    [void](New-Item -ItemType Directory -Path $cwd)
    $evb = Join-Path $cwd 'EVIDENCE'
    $t = $bootText.Replace($lineE, "`$EvidenceBase    = '" + $evb + "'").Replace($lineP, "`$PackageBase     = '" + (Join-Path $cwd 'PKG') + "'")
    $boot = Join-Path $Work ('BOOT_' + $Name + '.ps1')
    [System.IO.File]::WriteAllText($boot, $t, (New-Object System.Text.UTF8Encoding($true)))
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Pwsh
    $psi.WorkingDirectory = $cwd
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $a = @('-NoProfile', '-NonInteractive', '-File', $boot) + $Extra
    $psi.Arguments = (($a | ForEach-Object { '"' + $_ + '"' }) -join ' ')
    $p = [System.Diagnostics.Process]::Start($psi)
    $out = $p.StandardOutput.ReadToEnd()
    [void]$p.StandardError.ReadToEnd()
    $p.WaitForExit()
    return @{ exit = $p.ExitCode; out = $out; cwd = $cwd; evb = $evb }
}
$base = @('-Stage', 'QS4_SHADOW', '-HarnessZip', $zipH, '-HarnessZipSha256', ('A' * 64), '-R3PackageZip', $zipR,
          '-R3PackageZipSha256', 'F14E7B149BDFB5184D09116122C7A6264F7A4798E08799DEBD852B45E959A775', '-Qs3Receipt', $qs3,
          '-Qs3ReceiptSha256', $qs3Sha)
$cases = [ordered]@{
    'AUTH' = @(($base + @('-AuthorizationText', 'AUTORIZO QS3 PHASE_B_ADAPTER_V001 R3')), 'STAGE_AUTHORIZATION_TEXT_MISMATCH');
    'R3ZIP' = @((($base[0..7]) + @('-R3PackageZipSha256', ('C' * 64), '-Qs3Receipt', $qs3, '-Qs3ReceiptSha256', $qs3Sha, '-AuthorizationText', 'AUTORIZO QS4 PHASE_B_ADAPTER_V001 R3')), 'R3_PACKAGE_ZIP_SHA_NOT_PINNED_R3');
    'QS3REL' = @((($base[0..9]) + @('-Qs3Receipt', 'QS3_RECEIPT.json', '-Qs3ReceiptSha256', $qs3Sha, '-AuthorizationText', 'AUTORIZO QS4 PHASE_B_ADAPTER_V001 R3')), 'QS3_RECEIPT_PATH_INVALID_ABSOLUTE_FILE_REQUIRED');
    'QS3SHA' = @((($base[0..11]) + @('-Qs3ReceiptSha256', ('D' * 64), '-AuthorizationText', 'AUTORIZO QS4 PHASE_B_ADAPTER_V001 R3')), 'QS3_RECEIPT_SHA_MISMATCH');
    'RESUMEBAD' = @(($base + @('-AuthorizationText', 'AUTORIZO QS4 PHASE_B_ADAPTER_V001 R3', '-ResumeQs4AttemptId', '..\x')), 'RESUME_QS4_ATTEMPT_ID_INVALID');
    'RESUMEUNKNOWN' = @(($base + @('-AuthorizationText', 'AUTORIZO QS4 PHASE_B_ADAPTER_V001 R3', '-ResumeQs4AttemptId', '20261003T000000Z_0000dead')), 'RESUME_QS4_ATTEMPT_UNKNOWN')
}
foreach ($k in $cases.Keys) {
    $r = Invoke-Boot $k $cases[$k][0]
    Assert-True ($r.exit -eq 2) ('B4 ' + $k + ' exit=' + $r.exit)
    Assert-True ($r.out.Contains('BOOTSTRAP_BLOCKED=' + $cases[$k][1])) ('B4 ' + $k + ' reason')
    Assert-True ($r.out.Contains('FINAL_EXIT=2')) ('B4 ' + $k + ' final')
    Assert-True (@(Get-ChildItem -LiteralPath $r.cwd -Force).Count -eq 0) ('B4 ' + $k + ' nothing written (no evidence/pkg dir)')
}
$results['B4_BLOCKS_BEFORE_ATTEMPT_DIR'] = 'PASS'

$r = Invoke-Boot 'PS51' ($base + @('-AuthorizationText', 'AUTORIZO QS4 PHASE_B_ADAPTER_V001 R3'))
Assert-True ($r.exit -eq 2) ('B5 exit ' + $r.exit)
Assert-True ($r.out.Contains('BOOTSTRAP_BLOCKED=WINDOWS_POWERSHELL_5_1_REQUIRED')) 'B5 reason'
$evb = $r.evb
$dirs = @(Get-ChildItem -LiteralPath $evb -Directory)
Assert-True (@(Get-ChildItem -LiteralPath $r.cwd -Force | Where-Object { $_.Name -ne 'EVIDENCE' }).Count -eq 0) 'B5 only evidence written'
Assert-True ($r.out.Contains('LOG=' + (Join-Path $dirs[0].FullName 'BOOTSTRAP.log'))) 'B5 absolute fixed log path'
Assert-True ($dirs.Count -eq 1) 'B5 one attempt'
$ad = $dirs[0].FullName
$rp = Join-Path $ad 'QS4_RECEIPT.json'
$rb = [System.IO.File]::ReadAllBytes($rp)
$rsha = Get-BytesSha256 $rb
$rd = $Utf8NoBom.GetString($rb) | ConvertFrom-Json
Assert-True ($rd.final_exit -eq 2 -and $rd.stage -eq 'QS4_SHADOW' -and $rd.run_released -eq 'NO' -and $rd.phase_c_execution -eq 'NO') 'B5 receipt'
Assert-True ($rd.final_status_written -eq $true) 'B5 final status written'
$sp = Join-Path $ad 'BOOTSTRAP_STATUS.json'
Assert-True ((Get-Sha256 $sp) -eq $rd.final_status_sha256) 'B5 status bound'
$sd = Get-Content -LiteralPath $sp -Raw | ConvertFrom-Json
Assert-True ($sd.fields.ACTIVE -eq 'NO' -and $sd.extra.final_exit -eq 2) 'B5 status final'
Assert-True ($sd.extra.qs4_pct -eq '0.0' -and $sd.extra.qs4_logical_attempt -eq $dirs[0].Name) 'B5 pct/logical (PCT nunca 100 sem reconciliação)'
Assert-True ($rd.facts.multiwork -eq 'NOT_APPLICABLE' -and $rd.facts.t18_p1_p3.StartsWith('FAIL_CLOSED_HUMAN_RECONCILIATION_REQUIRED')) 'B5 facts multiwork/T18'
$cd = Get-Content -LiteralPath (Join-Path $ad 'QS4_RECEIPT.VERIFIED.json') -Raw | ConvertFrom-Json
Assert-True ($cd.receipt_sha256 -eq $rsha -and $cd.final_exit -eq 2) 'B5 companion'
$log = [System.IO.File]::ReadAllText((Join-Path $ad 'BOOTSTRAP.log'))
Assert-True ($log.Contains('STAGE_RECEIPT=') -and $log.Contains('FINAL_EXIT=2') -and $log.Contains('BLIND_RETRY=FORBIDDEN')) 'B5 log'
$results['B5_B08_TAIL_AFTER_ATTEMPT_DIR'] = 'PASS'

foreach ($k in $results.Keys) { Write-Host ($k + '=' + $results[$k]) }
Write-Host 'QS4_BOOTSTRAP_HARNESS=PASS'
exit 0
