"""Bounded observation and stable-copy same-run failure evidence. No process kill."""
from __future__ import annotations
import os
import time
import zipfile
from pathlib import Path
import qs4_attempt_lifecycle_v002 as L


def bounded_census(identities, process_api, *, rounds=3, interval=.05):
    if type(rounds) is not int or not 1 <= rounds <= 5 or not 0 <= interval <= .2:
        raise L.LifecycleBlocked('CENSUS_BOUND_INVALID')
    observations = []
    for _ in range(rounds):
        rows, errors = [], []
        for ident in identities:
            pid, ct = ident.get('pid'), ident.get('ctime')
            if type(pid) is not int or pid <= 0 or type(ct) is not int:
                rows.append(dict(ident, state=L.UNKNOWN, descendants=[]))
                errors.append('IDENTITY_UNPROVEN'); continue
            try:
                state = process_api.process_liveness(pid, ct)
                desc = process_api.descendants(pid, ct)
                rows.append(dict(ident, state=state, descendants=[{'pid':p,'ctime':c,'state':L.ALIVE} for p,c in desc]))
            except Exception as exc:
                rows.append(dict(ident, state=L.UNKNOWN, descendants=[]))
                errors.append(type(exc).__name__+':'+str(exc))
        clean = not errors and all(r['state'] in (L.TERMINATED, L.PID_REUSED) and not r['descendants'] for r in rows)
        observations.append({'identities':rows,'errors':errors,'clean':clean})
        if clean:
            break
        if len(observations) < rounds:
            time.sleep(interval)
    last = observations[-1]
    return {'state':'PASS_CLEAN' if last['clean'] else 'UNKNOWN_OR_ACTIVE',
            'complete':not last['errors'] and all(r['state'] != L.UNKNOWN for r in last['identities']),
            'shutdown':'OBSERVED_ONLY_NO_KILL','round_limit':rounds,'observations':observations}


def durable_write(path, raw):
    with Path(path).open('xb') as f:
        f.write(raw); f.flush(); os.fsync(f.fileno())
    if Path(path).read_bytes() != raw:
        raise L.LifecycleBlocked('FAILURE_READBACK_MISMATCH')


def collect_failure_bundle(*, output_dir, primary_error, stage, native_exit,
                           protected_effects_committed, identities, source_roots, process_api):
    out = Path(output_dir)
    resolved = out.resolve()
    for root in source_roots.values():
        root = Path(root).resolve()
        if resolved == root or resolved.is_relative_to(root):
            raise L.LifecycleBlocked('FAILURE_OUTPUT_INSIDE_SOURCE')
    out.mkdir(parents=True, exist_ok=False)
    census = bounded_census(identities, process_api)
    items, errors = [], []
    if not census['complete']:
        errors.append('CENSUS_UNKNOWN')
    for label, root in sorted(source_roots.items()):
        L.safe_relative_path(label)
        root = Path(root)
        if not root.is_dir() or root.is_symlink():
            errors.append('SOURCE_ROOT_UNAVAILABLE:'+label); continue
        try:
            paths = sorted(root.rglob('*'))
        except Exception as exc:
            errors.append('SOURCE_ENUMERATION:'+label+':'+str(exc)); continue
        for p in paths:
            rel = p.relative_to(root)
            try:
                if p.is_symlink() or (hasattr(p,'is_junction') and p.is_junction()):
                    raise L.LifecycleBlocked('SOURCE_REPARSE_OR_SYMLINK')
                if p.is_dir():
                    continue
                before = p.stat()
                # Hash, copy, and rehash source. Changing logs are captured as unstable evidence.
                raw = p.read_bytes(); sha = L.sha256_bytes(raw)
                dest = out/'STABLE_COPY'/label/rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                durable_write(dest, raw)
                after = p.stat()
                stable = ((before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
                          and L.sha256_bytes(p.read_bytes()) == sha)
                items.append({'path':str(dest.relative_to(out)).replace('\\','/'), 'bytes':len(raw),'sha256':sha,'stable':stable})
                if not stable:
                    errors.append('SOURCE_UNSTABLE:'+label+'/'+str(rel))
            except Exception as exc:
                errors.append('COPY:'+label+'/'+str(rel)+':'+type(exc).__name__+':'+str(exc))
    if not items:
        errors.append('NO_EVIDENCE_COPIED')
    bundle = L.build_failure_bundle(primary_error=primary_error,stage=stage,native_exit=native_exit,
        protected_effects_committed=protected_effects_committed,process_ownership={'identities':list(identities)},
        bounded_post_shutdown_census=census,evidence_items=items,collection_errors=errors)
    durable_write(out/'FAILURE_BUNDLE.json',L.canonical_json_bytes(bundle))
    members = items + [{'path':'FAILURE_BUNDLE.json','bytes':(out/'FAILURE_BUNDLE.json').stat().st_size,
                        'sha256':L.sha256_bytes((out/'FAILURE_BUNDLE.json').read_bytes())}]
    durable_write(out/'RESULT_MANIFEST.json',L.canonical_json_bytes({'schema':'QS4_FAILURE_RESULT_MANIFEST_V002','members':members}))
    zip_path = out.with_suffix('.zip')
    # Exclusive creation; never overwrite a historical bundle.
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob('*')):
            if p.is_file():
                z.write(p,str(p.relative_to(out)).replace('\\','/'))
    with zipfile.ZipFile(zip_path) as z:
        if z.testzip() is not None:
            raise L.LifecycleBlocked('FAILURE_ZIP_CRC')
        for e in members:
            raw = z.read(e['path'])
            if len(raw) != e['bytes'] or L.sha256_bytes(raw) != e['sha256']:
                raise L.LifecycleBlocked('FAILURE_ZIP_READBACK')
    return {'bundle':bundle,'zip_path':str(zip_path),'zip_sha256':L.sha256_bytes(zip_path.read_bytes())}
