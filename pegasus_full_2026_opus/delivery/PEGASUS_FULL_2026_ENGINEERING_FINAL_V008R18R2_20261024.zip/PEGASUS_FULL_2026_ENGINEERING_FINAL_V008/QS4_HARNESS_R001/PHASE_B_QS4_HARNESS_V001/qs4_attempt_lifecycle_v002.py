"""QS4_ATTEMPT_LIFECYCLE_V002 — semantic lifecycle, liveness, retirement,
CONTROL binding and FULL readiness/admission contracts.

Pure stdlib. No import-time effects. Historical evidence is never deleted by this module.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Iterable
import hashlib
import json

ALIVE = "ALIVE"
TERMINATED = "TERMINATED"
PID_REUSED = "PID_REUSED"
UNKNOWN = "UNKNOWN"

ACTIVE = "ACTIVE"
CONTINUABLE_INTERRUPTED = "CONTINUABLE_INTERRUPTED"
FAILED_DURABLE_NONRESUMABLE = "FAILED_DURABLE_NONRESUMABLE"
TERMINAL_PASS = "TERMINAL_PASS"
TERMINAL_VERDICT = "TERMINAL_VERDICT"
RETIRED = "RETIRED"

PRE_BIND_EXACT = "PRE_BIND_EXACT"
POST_BIND_EXACT = "POST_BIND_EXACT"
MIXED_OR_UNKNOWN = "MIXED_OR_UNKNOWN"

QS5_PREPARED = "QS5_PREPARED"
FULL_ADMISSION_PASS = "FULL_ADMISSION_PASS"

class LifecycleBlocked(Exception):
    def __init__(self, code: str, detail: str = ""):
        self.code, self.detail = str(code), str(detail)
        super().__init__((self.code + " " + self.detail).strip())


def sha256_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest().upper()


def canonical_json_bytes(obj: Any) -> bytes:
    return (json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")


def durable_failed_cases(ledger: Mapping[str, Any] | None) -> list[str]:
    if not ledger:
        return []
    out=[]
    for cid, case in (ledger.get("cases") or {}).items():
        if case.get("status") == "DONE" and (case.get("out") or {}).get("result") == "FAIL":
            out.append(str(cid))
    return sorted(out)


def attempt_lifecycle_state(ledger: Mapping[str, Any] | None) -> str:
    if not ledger:
        return ACTIVE
    final = ledger.get("final") or {}
    if durable_failed_cases(ledger):
        return FAILED_DURABLE_NONRESUMABLE
    if final.get("complete") is True:
        if int(final.get("exit_code", 999999)) == 0 and str(final.get("result")) == "PASS":
            return TERMINAL_PASS
        return TERMINAL_VERDICT
    if durable_failed_cases(ledger):
        return FAILED_DURABLE_NONRESUMABLE
    # Any durable logical attempt that is not terminal and has no durable FAIL can only
    # continue through the resume reconciliation path; it is not silently called PASS.
    if ledger.get("sessions") or ledger.get("cases") or ledger.get("partial") or ledger.get("seq") is not None:
        return CONTINUABLE_INTERRUPTED
    return ACTIVE


def assert_resume_allowed(ledger: Mapping[str, Any]) -> str:
    state = attempt_lifecycle_state(ledger)
    if state != CONTINUABLE_INTERRUPTED:
        detail = state
        failed = durable_failed_cases(ledger)
        if failed:
            detail += " failed=" + ",".join(failed)
        raise LifecycleBlocked("RESUME_STATE_NOT_CONTINUABLE", detail)
    return state


def classify_process_observation(*, present: bool, open_succeeded: bool,
                                 exit_query_succeeded: bool, exit_code: int | None,
                                 creation_time: int | None,
                                 expected_creation_time: int | None) -> str:
    """Classify one PID observation without converting visibility failure into death.

    PID_REUSED means the *owned historical identity* is not alive even though the numeric
    PID is currently occupied by another process. UNKNOWN always blocks admission.
    """
    if not present:
        return TERMINATED
    if not open_succeeded:
        return UNKNOWN
    if not exit_query_succeeded:
        return UNKNOWN
    if exit_code is None:
        return UNKNOWN
    if int(exit_code) != 259:  # STILL_ACTIVE
        return TERMINATED
    if creation_time is None or expected_creation_time is None:
        return UNKNOWN
    if expected_creation_time is not None and int(creation_time) != int(expected_creation_time):
        return PID_REUSED
    return ALIVE


def lineage_admission(states: Iterable[str]) -> str:
    seen=list(states)
    if any(s == UNKNOWN for s in seen):
        raise LifecycleBlocked("OWNED_PROCESS_LIVENESS_UNKNOWN")
    if any(s == ALIVE for s in seen):
        raise LifecycleBlocked("OWNED_PROCESS_TREE_ACTIVE")
    bad=[s for s in seen if s not in {TERMINATED, PID_REUSED}]
    if bad:
        raise LifecycleBlocked("OWNED_PROCESS_STATE_INVALID", repr(bad))
    return "PASS_CLEAN"


def validate_retirement_receipt(receipt: Mapping[str, Any], *, expected_attempt_id: str | None = None,
                                evidence_root=None, expected_receipt_sha256=None) -> str:
    if evidence_root is None or expected_receipt_sha256 is None or expected_attempt_id is None:
        raise LifecycleBlocked("RETIREMENT_PHYSICAL_BINDING_REQUIRED")
    if receipt.get("schema") != "ATTEMPT_RETIREMENT_RECEIPT_V002":
        raise LifecycleBlocked("RETIREMENT_SCHEMA_INVALID")
    if sha256_bytes(canonical_json_bytes(receipt)) != expected_receipt_sha256:
        raise LifecycleBlocked("RETIREMENT_RECEIPT_SHA_MISMATCH")
    payload = dict(receipt); payload.pop("receipt_readback_sha256", None)
    if sha256_bytes(canonical_json_bytes(payload)) != receipt.get("receipt_readback_sha256"):
        raise LifecycleBlocked("RETIREMENT_READBACK_MISMATCH")
    required = {
        "evidence_files", "schema", "attempt_id", "source_result_sha256", "ledger_sha256", "journal_sha256",
        "harness_identity_sha256", "adapter_identity_sha256", "historical_native_exit_proofs",
        "owned_process_identities", "lineage_census_sha256", "census_timestamp", "mutex_observation",
        "historical_evidence_inventory_sha256", "state_before", "state_after", "resume_forbidden",
        "preserve_history", "receipt_readback_sha256"
    }
    missing=sorted(required-set(receipt))
    if missing:
        raise LifecycleBlocked("RETIREMENT_RECEIPT_FIELDS_MISSING", ",".join(missing))
    if expected_attempt_id is not None and str(receipt["attempt_id"]) != str(expected_attempt_id):
        raise LifecycleBlocked("RETIREMENT_ATTEMPT_ID_MISMATCH")
    if str(receipt["state_after"]) != RETIRED or receipt["resume_forbidden"] is not True or receipt["preserve_history"] is not True:
        raise LifecycleBlocked("RETIREMENT_STATE_CONTRACT")
    for key in ("source_result_sha256", "ledger_sha256", "journal_sha256", "harness_identity_sha256",
                "adapter_identity_sha256", "lineage_census_sha256", "historical_evidence_inventory_sha256",
                "receipt_readback_sha256"):
        v=str(receipt[key])
        if len(v) != 64 or any(c not in "0123456789ABCDEFabcdef" for c in v):
            raise LifecycleBlocked("RETIREMENT_HASH_INVALID", key)
    if receipt["state_before"] not in {ACTIVE, CONTINUABLE_INTERRUPTED, FAILED_DURABLE_NONRESUMABLE, TERMINAL_PASS, TERMINAL_VERDICT}:
        raise LifecycleBlocked("RETIREMENT_PRIOR_STATE_INVALID")
    bound = verify_retirement_files(receipt, Path(evidence_root))
    import qs4_lib as Q
    entries = receipt["evidence_files"]
    ledger = Q.ledger_verify(Path(evidence_root) / safe_relative_path(entries["ledger_sha256"]["path"]),
                             Path(evidence_root) / safe_relative_path(entries["journal_sha256"]["path"]))
    if ledger.get("logical_attempt") != expected_attempt_id or attempt_lifecycle_state(ledger) != receipt["state_before"]:
        raise LifecycleBlocked("RETIREMENT_LEDGER_STATE_BINDING")
    known = set()
    def visit(obj):
        if isinstance(obj, dict):
            if "pid" in obj and "ctime" in obj:
                if type(obj["pid"]) is not int or type(obj["ctime"]) is not int:
                    raise LifecycleBlocked("RETIREMENT_LEDGER_IDENTITY_UNKNOWN")
                known.add((obj["pid"], obj["ctime"]))
            for v in obj.values(): visit(v)
        elif isinstance(obj, list):
            for v in obj: visit(v)
    visit(ledger)
    actual = {(x.get("pid"), x.get("ctime")) for x in receipt["owned_process_identities"]}
    if not known or not known.issubset(actual):
        raise LifecycleBlocked("RETIREMENT_LEDGER_IDENTITY_CENSUS_GAP")
    census = strict_json(bound["lineage_census_sha256"])
    mutex = strict_json(bound["mutex_sha256"])
    if (census.get("complete") is not True or census.get("timestamp") != receipt["census_timestamp"]
            or census.get("attempt_id") != expected_attempt_id
            or census.get("identities") != receipt["owned_process_identities"]
            or mutex != receipt["mutex_observation"]):
        raise LifecycleBlocked("RETIREMENT_CENSUS_OR_MUTEX_BINDING")
    proofs = strict_json(bound["native_exit_proofs_sha256"])
    if proofs != receipt["historical_native_exit_proofs"]:
        raise LifecycleBlocked("RETIREMENT_NATIVE_PROOF_BINDING")
    states=[]
    identities = receipt.get("owned_process_identities")
    if not isinstance(identities, list) or not identities:
        raise LifecycleBlocked("RETIREMENT_OWNED_IDENTITIES_REQUIRED")
    for rec in identities:
        if type(rec.get("pid")) is not int or rec["pid"] <= 0 or type(rec.get("ctime")) is not int:
            raise LifecycleBlocked("RETIREMENT_IDENTITY_INVALID")
        state=str(rec.get("state"))
        states.append(state)
        if state == PID_REUSED:
            proof = rec.get("historical_termination_proof")
            if (not isinstance(proof, dict) or proof not in proofs
                    or proof.get("pid") != rec["pid"] or proof.get("ctime") != rec["ctime"]
                    or type(proof.get("native_exit")) is not int or proof["native_exit"] == 259):
                raise LifecycleBlocked("RETIREMENT_PID_REUSE_WITHOUT_TERMINATION_PROOF", str(rec.get("pid")))
    lineage_admission(states)
    if str((receipt.get("mutex_observation") or {}).get("state")) != "ABSENT":
        raise LifecycleBlocked("RETIREMENT_MUTEX_NOT_ABSENT")
    # Recheck pinned bytes after parsing/lineage reconciliation; do not write history.
    verify_retirement_files(receipt, Path(evidence_root))
    return RETIRED


def admit_new_attempt(*, retirement_receipt: Mapping[str, Any] | None,
                      historical_residue_paths: Iterable[str] = (),
                      expected_attempt_id: str | None = None,
                      evidence_root=None, expected_receipt_sha256=None) -> str:
    # Historical residue is evidence after authenticated retirement and is not a liveness authority.
    # The iterable is intentionally not used as a blocker; it is accepted for explicit audit logging.
    _ = tuple(historical_residue_paths)
    if retirement_receipt is None:
        raise LifecycleBlocked("RETIREMENT_REQUIRED")
    validate_retirement_receipt(retirement_receipt, expected_attempt_id=expected_attempt_id,
                                evidence_root=evidence_root, expected_receipt_sha256=expected_receipt_sha256)
    return "ALLOW_NEW_ATTEMPT_PRESERVE_HISTORY"


def _normalize_file_map(m: Mapping[str, str]) -> dict[str, str]:
    out = {}
    for k, v in m.items():
        rel = str(k).replace("\\", "/")
        if rel.casefold() in {x.casefold() for x in out}:
            raise LifecycleBlocked("CONTROL_PATH_COLLISION")
        safe_relative_path(rel)
        out[rel] = str(v).upper()
    return out


def classify_control_binding(*, actual_files: Mapping[str, str], actual_dirs: Iterable[str],
                             pre_files: Mapping[str, str], post_files: Mapping[str, str],
                             expected_dirs: Iterable[str]) -> str:
    actual=_normalize_file_map(actual_files); pre=_normalize_file_map(pre_files); post=_normalize_file_map(post_files)
    ad={str(x).replace("\\", "/").rstrip("/") for x in actual_dirs}
    ed={str(x).replace("\\", "/").rstrip("/") for x in expected_dirs}
    if (ad != ed or set(actual) != set(pre) or set(actual) != set(post)
            or sum(pre[k] != post[k] for k in pre if k in post) != 2):
        return MIXED_OR_UNKNOWN
    if actual == pre:
        return PRE_BIND_EXACT
    if actual == post:
        return POST_BIND_EXACT
    return MIXED_OR_UNKNOWN


def control_binding_plan(state: str) -> dict[str, Any]:
    if state == PRE_BIND_EXACT:
        return {"state": state, "mutations": 2, "action": "VERIFIED_REBIND_TWO_FILES"}
    if state == POST_BIND_EXACT:
        return {"state": state, "mutations": 0, "action": "NO_WRITE_ALREADY_BOUND"}
    raise LifecycleBlocked("CONTROL_BINDING_MIXED_OR_UNKNOWN")


def build_failure_bundle(*, primary_error: str, stage: str, native_exit: int | None,
                         protected_effects_committed: list[str], process_ownership: Mapping[str, Any],
                         bounded_post_shutdown_census: Mapping[str, Any], evidence_items: list[Mapping[str, Any]],
                         collection_errors: list[str] | None = None) -> dict[str, Any]:
    if not primary_error:
        raise LifecycleBlocked("FAILURE_BUNDLE_PRIMARY_ERROR_REQUIRED")
    bundle={
        "schema":"QS4_SAME_RUN_FAILURE_BUNDLE_V002",
        "primary_error":str(primary_error),
        "stage":str(stage),
        "native_exit":native_exit,
        "protected_effects_committed":list(protected_effects_committed),
        "process_ownership":dict(process_ownership),
        "bounded_post_shutdown_census":dict(bounded_post_shutdown_census),
        "evidence_items":[dict(x) for x in evidence_items],
        "collection_errors":list(collection_errors or []),
        "auto_kill":"NO",
        "auto_successor":"NO",
        "collection_complete":(not bool(collection_errors) and bool(evidence_items)
                               and bounded_post_shutdown_census.get("complete") is True),
    }
    bundle["bundle_sha256"] = sha256_bytes(canonical_json_bytes(bundle))
    return bundle


def qs5_prepared(*, lifecycle_qualified: bool, qs4_pass: bool, growth_known: bool,
                 final_run_identity_frozen: bool, dry_receipt_pass: bool,
                 predelivery_audit_pass: bool, matrix_safestop_receipts_pass: bool) -> dict[str, Any]:
    checks={
        "lifecycle_qualified":lifecycle_qualified,
        "qs4_pass":qs4_pass,
        "growth_known":growth_known,
        "final_run_identity_frozen":final_run_identity_frozen,
        "dry_receipt_pass":dry_receipt_pass,
        "predelivery_audit_pass_R02":predelivery_audit_pass,
        "matrix_safestop_receipts_pass_R03":matrix_safestop_receipts_pass,
    }
    ok=all(v is True for v in checks.values())
    return {
        "state": QS5_PREPARED if ok else "QS5_NOT_PREPARED",
        "technical_ready": ok,
        "checks": checks,
        "deferred_to_full_invocation": ["R01_SPECIFIC_OWNER_AUTH", "R04_FRESH_TICK_REHASH", "R05_LIVE_POLICY_CURRENTNESS", "R06_LOCK_AND_LINEAGE_CENSUS"],
    }


def full_admission(*, qs5_receipt: Mapping[str, Any], specific_owner_authorization: bool,
                   fresh_tick_rehash_pass: bool, live_policy_currentness_pass: bool,
                   lock_acquired: bool, lineage_states: Iterable[str],
                   package_identity_match: bool, dry_identity_current: bool,
                   phase_c_requested: bool=False, reselection_requested: bool=False) -> dict[str, Any]:
    if str(qs5_receipt.get("state")) != QS5_PREPARED or qs5_receipt.get("technical_ready") is not True:
        raise LifecycleBlocked("FULL_ADMISSION_QS5_NOT_PREPARED")
    required_checks = {"lifecycle_qualified", "qs4_pass", "growth_known", "final_run_identity_frozen",
                       "dry_receipt_pass", "predelivery_audit_pass_R02", "matrix_safestop_receipts_pass_R03"}
    checks = qs5_receipt.get("checks") or {}
    if set(checks) != required_checks or not all(v is True for v in checks.values()):
        raise LifecycleBlocked("FULL_ADMISSION_QS5_CHECKS_INVALID")
    if phase_c_requested:
        raise LifecycleBlocked("PHASE_C_FORBIDDEN")
    if reselection_requested:
        raise LifecycleBlocked("RESELECTION_2026_FORBIDDEN")
    gates={
        "R01_SPECIFIC_OWNER_AUTH":specific_owner_authorization,
        "R04_FRESH_TICK_REHASH":fresh_tick_rehash_pass,
        "R05_LIVE_POLICY_CURRENTNESS":live_policy_currentness_pass,
        "R06_LOCK_ACQUIRED":lock_acquired,
        "R02_R03_PACKAGE_IDENTITY_CURRENT":package_identity_match,
        "R03_DRY_IDENTITY_CURRENT":dry_identity_current,
    }
    if not all(v is True for v in gates.values()):
        failed=[k for k,v in gates.items() if not v]
        raise LifecycleBlocked("FULL_ADMISSION_GATE_FAILED", ",".join(failed))
    lineage_admission(lineage_states)
    return {"state":FULL_ADMISSION_PASS,"gates":gates,"phase_c_execution":"NO","reselection_2026":"FORBIDDEN"}


def strict_json(raw: bytes):
    def hook(pairs):
        obj = {}
        for k, v in pairs:
            if k in obj:
                raise LifecycleBlocked("JSON_DUPLICATE_KEY", k)
            obj[k] = v
        return obj
    return json.loads(raw.decode("utf-8-sig"), object_pairs_hook=hook)


def safe_relative_path(rel: str) -> Path:
    from pathlib import PurePosixPath
    norm = rel.replace("\\", "/")
    parts = PurePosixPath(norm).parts
    if not norm or norm.startswith("/") or ":" in norm or ".." in parts or "." in norm.split("/"):
        raise LifecycleBlocked("UNSAFE_EVIDENCE_PATH", rel)
    return Path(*parts)


def read_bound_file(root: Path, entry: Mapping[str, Any]) -> bytes:
    rel = safe_relative_path(str(entry["path"]))
    if root.is_symlink() or (hasattr(root, "is_junction") and root.is_junction()):
        raise LifecycleBlocked("EVIDENCE_ROOT_REPARSE_OR_SYMLINK")
    root = root.resolve()
    p = root / rel
    for node in [p, *p.parents]:
        if node == root:
            break
        if node.is_symlink():
            raise LifecycleBlocked("EVIDENCE_REPARSE_OR_SYMLINK", str(rel))
        if hasattr(node, "is_junction") and node.is_junction():
            raise LifecycleBlocked("EVIDENCE_REPARSE_OR_SYMLINK", str(rel))
    if not p.resolve().is_relative_to(root):
        raise LifecycleBlocked("EVIDENCE_OUTSIDE_ROOT")
    before = p.stat()
    raw = p.read_bytes()
    after = p.stat()
    if ((before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns)
            or len(raw) != entry["bytes"] or sha256_bytes(raw) != entry["sha256"]):
        raise LifecycleBlocked("EVIDENCE_PHYSICAL_HASH_MISMATCH", str(rel))
    return raw


def verify_retirement_files(receipt, root):
    roles = {"source_result_sha256", "ledger_sha256", "journal_sha256", "harness_identity_sha256",
             "adapter_identity_sha256", "lineage_census_sha256", "historical_evidence_inventory_sha256",
             "native_exit_proofs_sha256", "mutex_sha256"}
    entries = receipt["evidence_files"]
    if set(entries) != roles:
        raise LifecycleBlocked("RETIREMENT_EVIDENCE_EXACT_SET")
    out = {}
    for role, entry in entries.items():
        if role in receipt and entry["sha256"] != receipt[role]:
            raise LifecycleBlocked("RETIREMENT_EVIDENCE_ROLE_HASH", role)
        out[role] = read_bound_file(root, entry)
    inventory = strict_json(out["historical_evidence_inventory_sha256"])
    if inventory.get("attempt_id") != receipt["attempt_id"] or not inventory.get("files"):
        raise LifecycleBlocked("RETIREMENT_INVENTORY_INVALID")
    seen = set()
    for entry in inventory["files"]:
        key = str(safe_relative_path(entry["path"])).casefold()
        if key in seen:
            raise LifecycleBlocked("RETIREMENT_INVENTORY_DUPLICATE")
        seen.add(key)
        read_bound_file(root, entry)
    for role in ("source_result_sha256", "ledger_sha256", "journal_sha256", "harness_identity_sha256", "adapter_identity_sha256", "native_exit_proofs_sha256"):
        if entries[role] not in inventory["files"]:
            raise LifecycleBlocked("RETIREMENT_INVENTORY_ROLE_MISSING", role)
    return out
