param([string]$ChildResultPath)
function Require([bool]$Condition,[string]$Reason){if (-not $Condition){throw ('BLOCKED|' + $Reason)}}
function Get-Prop([AllowNull()]$Object,[string]$Name){
    if ($null -eq $Object){return $null}
    if ($Object -is [System.Collections.IDictionary]){if ($Object.Contains($Name)){return $Object[$Name]};return $null}
    $p=$Object.PSObject.Properties[$Name];if ($null -eq $p){return $null};return $p.Value
}
function Write-AtomicBytes([string]$Path,[byte[]]$Bytes){
    $dir=[IO.Path]::GetDirectoryName($Path);if (-not (Test-Path -LiteralPath $dir -PathType Container)){New-Item -ItemType Directory -Path $dir -Force|Out-Null}
    $tmp=$Path+'.tmp.'+$PID+'.'+[Guid]::NewGuid().ToString('N')
    try {
        $fs=New-Object IO.FileStream($tmp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
        try {$fs.Write($Bytes,0,$Bytes.Length);$fs.Flush($true)}finally {$fs.Dispose()}
        if (Test-Path -LiteralPath $Path -PathType Leaf){[IO.File]::Replace($tmp,$Path,[System.Management.Automation.Language.NullString]::Value)}else {[IO.File]::Move($tmp,$Path)}
        $committed=New-Object IO.FileStream($Path,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::Read)
        try {$committed.Flush($true)}finally {$committed.Dispose()}
    }finally {if (Test-Path -LiteralPath $tmp -PathType Leaf){Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue}}
}
function Write-AtomicJson([string]$Path,$Object){$json=($Object|ConvertTo-Json -Depth 32 -Compress)+"`n";$enc=New-Object Text.UTF8Encoding($false);Write-AtomicBytes $Path ($enc.GetBytes($json))}
function Write-StopRequest([string]$Reason,[string]$TargetPath=$StopFile){
    try {
        $targetDir=[IO.Path]::GetDirectoryName($TargetPath);if (-not (Test-Path -LiteralPath $targetDir -PathType Container)){New-Item -ItemType Directory -Path $targetDir -Force|Out-Null}
        $text='reason='+$Reason+"`nrequested_at="+[DateTimeOffset]::Now.ToString('o')+"`n"
        $enc=New-Object Text.UTF8Encoding($false);Write-AtomicBytes $TargetPath ($enc.GetBytes($text))
        $script:StopPersisted=$true;$script:StopWriteError='';return $true
    }catch {$script:StopPersisted=$false;$script:StopWriteError=$_.Exception.Message;return $false}
}
function Write-ChildResult([string]$Status,[int]$ExitCode,[string]$PrimaryError){
    if ([string]::IsNullOrWhiteSpace($ChildResultPath)){return }
    $obj=[ordered]@{schema='TICKSTORE_D4_RESUME_EFFECTFUL_V002R22_CHILD_RESULT';status=$Status;exit_code=$ExitCode;primary_error=$PrimaryError;pid=$PID;written_at=[DateTimeOffset]::Now.ToString('o')}
    Write-AtomicJson $ChildResultPath $obj
}
function Assert-D4ResumeState($State){
    $stateStatus=[string](Get-Prop $State 'status')
    $allowedStatus=($stateStatus -ceq 'FAIL') -or (($stateStatus -ceq 'SAFE_STOP') -and $ResumeAfterSafeStop)
    Require ($allowedStatus -and [string](Get-Prop $State 'next_node') -ceq 'D4') 'CURRENT_STATE_NOT_D4'
    Require ($null -eq (Get-Prop $State 'canary_scratch_cert')) 'CURRENT_STATE_CERT_PRESENT'
}
Write-ChildResult 'BLOCKED_OR_FAIL' 7 'ISOLATED_FIXTURE'; exit 7