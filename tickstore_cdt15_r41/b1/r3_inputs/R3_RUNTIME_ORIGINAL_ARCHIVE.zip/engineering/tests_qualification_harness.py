"""Harness regression only; these tests do not count toward G4/G5."""
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_current_delta as runner


class DurableQualification(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.base = Path(temp.name)
        self.root = self.base / 'runtime'
        self.root.mkdir()
        self.member = self.root / 'fixture.txt'
        self.member.write_bytes(b'original')
        self.manifest = {'files': [{'path': 'fixture.txt', 'bytes': 8,
                                   'sha256': runner.sha(b'original')}]}
        self.raw = json.dumps(self.manifest).encode()
        self.out = self.base / 'result'
        self.out.mkdir()

    def execute(self, *functions):
        suite = unittest.TestSuite(unittest.FunctionTestCase(fn) for fn in functions)
        result = runner.execute_suite(suite, self.root, self.manifest, self.raw, self.out)
        self.assertEqual(json.loads((self.out / 'RESULT.json').read_text()), result)
        return result

    def test_error_details_survive_later_keyboard_interrupt(self):
        def earlier_error():
            raise RuntimeError('NATIVE_MANIFEST_DIAGNOSTIC')
        def interrupted():
            log = (self.out / 'TESTS.log').read_text()
            self.assertIn('NATIVE_MANIFEST_DIAGNOSTIC', log)
            progress = json.loads((self.out / 'PROGRESS.json').read_text())
            self.assertEqual(progress['tests'][0]['status'], 'ERROR')
            raise KeyboardInterrupt('fixture interruption')
        def not_reached():
            raise AssertionError('should not run after interrupt')
        r = self.execute(earlier_error, interrupted, not_reached)
        self.assertEqual([t['status'] for t in r['tests']], ['ERROR', 'INTERRUPTED', 'NOT_RUN'])
        self.assertFalse(r['success'])
        self.assertTrue(r['tested_code_unchanged'])
        self.assertEqual(r['totals']['errors'], 1)

    def test_complete_suite_emits_success_and_progress(self):
        def passes():
            self.assertEqual(self.member.read_bytes(), b'original')
        r = self.execute(passes)
        self.assertTrue(r['success'])
        self.assertEqual(r['tests_expected'], 1)
        self.assertEqual(json.loads((self.out / 'PROGRESS.json').read_text())['tests'][0]['status'], 'PASS')

    def test_preexisting_byte_drift_prevents_execution(self):
        self.member.write_bytes(b'changed!')
        def prohibited():
            self.fail('must not execute')
        r = self.execute(prohibited)
        self.assertFalse(r['success'])
        self.assertFalse(r['tested_code_unchanged'])
        self.assertEqual(r['tests'][0]['status'], 'NOT_RUN')

    def test_post_test_byte_drift_blocks_success(self):
        def drifts():
            self.member.write_bytes(b'changed!')
        r = self.execute(drifts)
        self.assertFalse(r['success'])
        self.assertFalse(r['tested_code_unchanged'])
        self.assertIsNotNone(r['byte_revalidation_error'])

    def test_skip_never_becomes_success(self):
        def skips():
            raise unittest.SkipTest('fixture')
        r = self.execute(skips)
        self.assertFalse(r['success'])
        self.assertEqual(r['tests'][0]['status'], 'SKIP')


if __name__ == '__main__':
    unittest.main(verbosity=2)
