"""Bounded read-only inventory of the exact installation paths in CDT15 handoff."""
from pathlib import Path
import os,sys,json,argparse,hashlib
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'cdt15/work/implementation_v001/candidate/control'))
from D4_FIRST_ADMISSION_PREP import Reads

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);a=ap.parse_args()
 if os.name!='nt':raise RuntimeError('WINDOWS_REQUIRED')
 out=Path(a.output);out.mkdir(parents=True,exist_ok=False)
 base=Path(r'D:\Base CSV')
 state=base/'Scripts/TICKSTORE_R9_DEV/WORK_R9_PUBLISHER_RECOVERY_V004R1R1/ORCHESTRATOR_V001R9R1_B6_R8_PROVENANCE_VSS_SCOPE_FIX/state'
 paths={'MENU.py':base/'Scripts/Biblioteca/MENU.py','MANUTENCAO_BASE.bat':base/'Manutenção Base de Dados.bat',
        'STATE.json':state/'STATE.json','STATE_JOURNAL.jsonl':state/'STATE_JOURNAL.jsonl'}
 results=[]
 for name,path in paths.items():
  try:
   with Reads() as r:
    raw=r.read(path);r.revalidate()
    (out/name).write_bytes(raw)
    results.append(dict(path=str(path),saved_as=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest().upper(),status='READ_ONLY'))
  except (RuntimeError,OSError) as exc:results.append(dict(path=str(path),status='UNAVAILABLE',reason=str(exc)))
 report=dict(schema='TICKSTORE_CDT15_INSTALLATION_INVENTORY_V001',read_only=True,production_execution=False,
  authority_created=False,files=results,native_vss_qualification='NOT_ATTEMPTED')
 (out/'OBSERVATION.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
 print('INSTALLATION_INVENTORY_READ_ONLY='+str(out/'OBSERVATION.json'))
if __name__=='__main__':main()
