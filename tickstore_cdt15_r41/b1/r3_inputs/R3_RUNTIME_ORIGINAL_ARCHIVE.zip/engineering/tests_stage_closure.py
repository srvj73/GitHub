"""Directed closure tests on current CDT15 bytes; no productive entrypoint."""
from pathlib import Path
import sys,unittest,tempfile,types,json,os
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'cdt15'))
import tests_delta as prior
from D4_FIRST_ADMISSION_PREP import Reads,canonical,sha
from FULL_STAGE_EVIDENCE import publish,closed_results
from FULL_RELEASE_CHAIN import REQUIRED_CHECKS
class CheckpointProof(prior.D4ClosureProofTests):
 def run_proof(self,sign_key=None):
  signed=self.ns['_d4r_sign'](self.cp,sign_key or self.key,'TICKSTORE_D4_SIGNED_CHECKPOINT_V003')
  return self.verify(self.ns,self.ra_raw,self.descriptor,self.key,self.canon(signed),lambda p,e:Path(p).read_bytes(),expected_shadow_root='FIXTURE_SHADOW')
 def test_signed_wrong_shadow_cannot_self_attest(self):
  p=self.att['payload'];p['binding']['shadow_root']='UNRELATED_SHADOW'
  self.att=self.ns['_d4r_sign'](p,self.key,'TICKSTORE_D4_SIGNED_ATTESTATION_V003');self.update_attestation()
  with self.assertRaisesRegex(RuntimeError,'SHADOW_ROOT_BINDING'):self.run_proof()
class JournalProof(prior.ClosedStageEvidenceTests):
 def test_finish_explicit_foreign_run_rejected(self):
  raw=self.journal([dict(node='D4',phase='STARTED',run_id='current'),dict(node='D4',phase='FINISHED',run_id='foreign',status='PASS')])
  with self.assertRaisesRegex(RuntimeError,'FINISH_RUN_MISMATCH'):closed_results(raw,('D4',),Path('fixture'),lambda *a:b'{}')
class PublicationProof(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
  self.result=self.root/'RESULT_D5.json';self.result.write_bytes(b'original')
  self.r=Reads();self.addCleanup(self.r.close)
  self.r.descriptor={'code_manifest_sha256':'A'*64,'instance_sha256':'B'*64,'receipts':{'D4':{'path':'prior','sha256':'C'*64}}};self.r.receipt_sha='C'*64
  self.out=self.root/'new';self.out.mkdir()
 def writer(self,p,raw):
  with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 def call(self,writer=None):
  return publish('D5',self.r,self.out,writer or self.writer,{'STATE_AFTER.json':b'state'},{'unused'} if False else [{'path':str(self.result),'sha256':sha(b'original')}],checks={k:True for k in REQUIRED_CHECKS['D5']})
 def test_result_and_snapshots_retained_through_chain_commit(self):
  def writer(p,raw):
   if p.name=='EXECUTION_CHAIN.json':
    self.assertIn(str(self.result),self.r.items);self.assertIn(str(self.out/'STATE_AFTER.json'),self.r.items);self.assertIn(str(self.out/'STAGE_D5.json'),self.r.items)
   self.writer(p,raw)
  p,d=self.call(writer);self.assertEqual(sha(p.read_bytes()),d)
 def test_result_drift_blocks_chain_publication(self):
  def writer(p,raw):
   self.writer(p,raw)
   if p.name=='STAGE_D5.json':self.result.write_bytes(b'tampered')
  with self.assertRaises((RuntimeError,OSError)):self.call(writer)
  self.assertFalse((self.out/'EXECUTION_CHAIN.json').exists())
 def test_preexisting_chain_preserved(self):
  p=self.out/'EXECUTION_CHAIN.json';p.write_bytes(b'winner')
  with self.assertRaises(FileExistsError):self.call()
  self.assertEqual(p.read_bytes(),b'winner')
 def test_evidence_wrong_hash_blocks_before_any_write(self):
  self.result.write_bytes(b'changed')
  with self.assertRaisesRegex(RuntimeError,'SHA_MISMATCH'):self.call()
  self.assertEqual(list(self.out.iterdir()),[])
if __name__=='__main__':unittest.main(verbosity=2)
