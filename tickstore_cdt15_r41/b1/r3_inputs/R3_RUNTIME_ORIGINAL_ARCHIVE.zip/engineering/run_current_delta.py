"""Exact selected tests on frozen candidate bytes. No historical full rerun."""
from pathlib import Path
import os,sys,json,hashlib,unittest,platform,argparse,datetime,traceback
HERE=Path(__file__).resolve().parent
os.environ.setdefault('TICKSTORE_TEST_CANDIDATE',str(HERE.parent/'cdt15/work/implementation_v001/candidate'))
os.environ.setdefault('TICKSTORE_TEST_MANIFEST',str(HERE/'FINAL_RUNTIME_CODE_MANIFEST.json'))
sys.path[:0]=[str(HERE),str(HERE.parent/'cdt15')]
import tests_stage_closure as closure
import tests_full_lifecycle as lifecycle
import tests_resume_delta as resume
import test_first_admission_transaction as transaction
import test_bootstrap_contract as bootstrap
import tests_native_delta as native
import tests_delta as prior

def collect(native_windows=False):
 loader=unittest.defaultTestLoader;suite=unittest.TestSuite()
 for cls in [closure.CheckpointProof,closure.JournalProof,closure.PublicationProof,lifecycle.FullLifecycle,
             resume.StageHistory,resume.HeartbeatProof,resume.EntryRouting,resume.QualificationContract,
             resume.InstancePreparation,transaction.TransactionTests,bootstrap.BootstrapContract]:
  suite.addTests(loader.loadTestsFromTestCase(cls))
 suite.addTest(lifecycle.Readmission('test_refresh_preserves_instance_predecessor_and_prior_receipt'))
 for name in ['test_path_escape_blocks','test_legacy_admission_rejected_before_any_data_access','test_missing_chain_rejected_before_any_data_access']:
  suite.addTest(prior.ChainTests(name))
 if native_windows:
  for cls in [native.NativeDelta,prior.NativeJobTests,prior.NativeResumeTests,prior.InstallerAndLauncherTests]:
   suite.addTests(loader.loadTestsFromTestCase(cls))
  for name in ['test_native_job_memory_contains_coordinator_and_child','test_launch_drain_stop_controls','test_namespace_reuse_and_history_preserved','test_auto_cpu_zero_one_n_and_invalid_request','test_resource_stop_uses_checkpoint_cleanup']:
   suite.addTest(prior.ResourceAndNamespaceTests(name))
  for name in ['test_state_constructor_does_not_rewrite','test_single_stage_commit_and_native_readback','test_cannot_skip_to_full']:
   suite.addTest(prior.StageGuardTests(name))
 return suite

def leaves(suite):
 for obj in suite:
  if isinstance(obj,unittest.TestSuite):yield from leaves(obj)
  else:yield obj

def sha(raw):return hashlib.sha256(raw).hexdigest().upper()
def check_bytes(root,manifest):
 seen=set()
 for r in manifest['files']:
  p=root/r['path'];raw=p.read_bytes();assert len(raw)==r['bytes'] and sha(raw)==r['sha256'],r['path'];seen.add(r['path'])
 assert seen=={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
 return True

class Record(unittest.TextTestResult):
 def __init__(self,*a,checkpoint=None,**kw):super().__init__(*a,**kw);self.records={};self.checkpoint=checkpoint
 def persist(self):
  self.stream.flush()
  if self.checkpoint is not None:
   payload=dict(schema='TICKSTORE_DELTA_PROGRESS_V001',tests=[dict(id=k,status=v) for k,v in self.records.items()])
   p=self.checkpoint;temp=p.with_suffix('.tmp')
   with temp.open('w',encoding='utf-8') as f:
    json.dump(payload,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
   os.replace(temp,p)
 def startTest(self,test):self.records[test.id()]='RUNNING';super().startTest(test);self.persist()
 def stopTest(self,test):super().stopTest(test);self.persist()
 def detail(self,test,err):
  self.stream.write('\nIMMEDIATE_DIAGNOSTIC: '+test.id()+'\n'+self._exc_info_to_string(err,test)+'\n');self.persist()
 def addSuccess(self,test):self.records[test.id()]='PASS';super().addSuccess(test)
 def addFailure(self,test,err):self.records[test.id()]='FAIL';super().addFailure(test,err);self.detail(test,err)
 def addError(self,test,err):self.records[test.id()]='ERROR';super().addError(test,err);self.detail(test,err)
 def addSkip(self,test,reason):self.records[test.id()]='SKIP';super().addSkip(test,reason)
 def addSubTest(self,test,subtest,err):
  if err is not None:self.records[test.id()]='FAIL' if issubclass(err[0],test.failureException) else 'ERROR'
  super().addSubTest(test,subtest,err)
  if err is not None:self.detail(test,err)

def execute_suite(suite,root,manifest,raw,out,native_selection=False):
 ids=[t.id() for t in leaves(suite)]
 assert len(ids)==len(set(ids)),'DUPLICATE_TEST_ID'
 after=False;interruption=None;byte_error=None;holder=[]
 with (out/'TESTS.log').open('x',encoding='utf-8') as log:
  def factory(*args,**kwargs):
   result=Record(*args,checkpoint=out/'PROGRESS.json',**kwargs);holder.append(result);return result
  try:
   check_bytes(root,manifest)
   unittest.TextTestRunner(stream=log,verbosity=2,resultclass=factory).run(suite)
  except BaseException as exc:
   interruption=type(exc).__name__+': '+str(exc)
   log.write('\nCAMPAIGN_INTERRUPTED\n'+traceback.format_exc());log.flush()
  try:after=check_bytes(root,manifest)
  except BaseException as exc:
   byte_error=type(exc).__name__+': '+str(exc)
   log.write('\nCODE_REVALIDATION_FAILED\n'+traceback.format_exc());log.flush()
  result=holder[0] if holder else None
  records=dict(result.records) if result else {}
  for key,value in list(records.items()):
   if value=='RUNNING':records[key]='INTERRUPTED'
  tests=[dict(id=key,status=records.get(key,'NOT_RUN')) for key in ids]
  report=dict(schema='TICKSTORE_CDT15_EXECUTED_DELTA_V001',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
   platform=platform.platform(),python=sys.version,native_windows=os.name=='nt',selection='NATIVE' if native_selection else 'PORTABLE',
   code_manifest_sha256=sha(raw),tested_code_unchanged=after,production_execution=False,
   success=after and interruption is None and len(tests)>0 and all(t['status']=='PASS' for t in tests),tests=tests,
   totals=dict(tests_run=result.testsRun if result else 0,failures=len(result.failures) if result else 0,
               errors=len(result.errors) if result else 0,skips=len(result.skipped) if result else 0),
   tests_expected=len(ids),tests_not_run=sum(t['status']=='NOT_RUN' for t in tests),
   tests_interrupted=sum(t['status']=='INTERRUPTED' for t in tests),interruption=interruption,byte_revalidation_error=byte_error,
   baseline_results_counted_as_delta=False,G4='INCOMPLETE_PENDING_END_TO_END',G5='NOT_PROVEN',B06='NOT_STARTED',B07='PENDING',
   formal_audit_dispatch='BLOCKED',qualification_contract_satisfied=False)
  with (out/'RESULT.json').open('x',encoding='utf-8') as f:
   json.dump(report,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 return report

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--native',action='store_true');ap.add_argument('--list',action='store_true');ap.add_argument('--output',required=True);a=ap.parse_args()
 suite=collect(a.native);ids=[t.id() for t in leaves(suite)];assert len(ids)==len(set(ids)),'DUPLICATE_TEST_ID'
 out=Path(a.output)
 if a.list:out.write_text(json.dumps(ids,indent=2)+'\n');return 0
 if a.native and os.name!='nt':raise RuntimeError('NATIVE_WINDOWS_REQUIRED')
 out.mkdir(exist_ok=False,parents=True)
 os.environ['TICKSTORE_NATIVE_ARTIFACTS']=str(out/'test_artifacts')
 root=Path(os.environ['TICKSTORE_TEST_CANDIDATE']);raw=Path(os.environ['TICKSTORE_TEST_MANIFEST']).read_bytes();manifest=json.loads(raw)
 report=execute_suite(suite,root,manifest,raw,out,a.native)
 print(json.dumps({k:v for k,v in report.items() if k!='tests'},indent=2))
 if not report['success']:print((out/'TESTS.log').read_text())
 return 0 if report['success'] else 2
if __name__=='__main__':raise SystemExit(main())
