"""New CDT15 controls. Synthetic portable proofs; no productive admission."""
from pathlib import Path
import sys,unittest,tempfile,types,json,copy,threading,time
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'cdt15'))
import tests_delta as prior
import FULL_STAGE_CONTINUATION as cont
import FULL_QUALIFICATION_CONTRACT as qual
from D4_FIRST_ADMISSION_PREP import canonical,sha,require
from FULL_OBSERVABILITY import Heartbeat
import tickstore_full_multiwork as mw
import FULL_RELEASE_CHAIN as chain
import FULL_RUNNER as runner

class StageHistory(unittest.TestCase):
 def setUp(self):
  self.boundary=cont.StageBoundary('D5')
  self.state=dict(schema='TICKSTORE_ORCH_STATE_V001',next_node='D5',status='PASS',completed=['D4'],canary_scratch_cert='fixture')
 def journal(self,items):
  result=[];prev=''
  for item in items:
   raw=canonical(dict(item,prev_line_sha256=prev)).rstrip(b'\n');result.append(raw);prev=sha(raw)
  return b'\n'.join(result)+b'\n'
 def check(self,items):cont.validate_stage_history(self.journal(items),self.boundary,self.state)
 def test_fresh_stage_accepts_closed_predecessor(self):self.check([dict(node='D4',phase='STARTED',run_id='old'),dict(node='D4',phase='FINISHED',status='PASS')])
 def test_open_started_blocks_replay(self):
  with self.assertRaisesRegex(RuntimeError,'UNCLOSED_STARTED'):self.check([dict(node='D5',phase='STARTED',run_id='x')])
 def test_nested_started_blocks(self):
  with self.assertRaisesRegex(RuntimeError,'UNCLOSED_STARTED'):self.check([dict(node='D5',phase='STARTED',run_id='x')]*2)
 def test_unpaired_finish_blocks(self):
  with self.assertRaisesRegex(RuntimeError,'UNPAIRED_FINISH'):self.check([dict(node='D5',phase='FINISHED',status='PASS')])
 def test_foreign_finish_blocks(self):
  with self.assertRaisesRegex(RuntimeError,'FINISH_RUN'):self.check([dict(node='D5',phase='STARTED',run_id='x'),dict(node='D5',phase='FINISHED',run_id='y',status='PASS')])
 def test_journal_pass_state_gap_blocks(self):
  with self.assertRaisesRegex(RuntimeError,'STATE_RECONCILIATION'):self.check([dict(node='D5',phase='STARTED',run_id='x'),dict(node='D5',phase='FINISHED',status='PASS')])
 def test_safe_stop_current_node_accepts(self):
  self.state['status']='SAFE_STOP';self.check([dict(node='D5',phase='STARTED',run_id='x'),dict(node='D5',phase='FINISHED',status='SAFE_STOP')])
 def test_safe_stop_status_gap_blocks(self):
  with self.assertRaisesRegex(RuntimeError,'PENDING_STATUS'):self.check([dict(node='D5',phase='STARTED',run_id='x'),dict(node='D5',phase='FINISHED',status='SAFE_STOP')])
 def test_completed_node_missing_attempt_blocks(self):
  self.state.update(next_node='D6',completed=['D4','D5']);self.boundary=cont.StageBoundary('D5',close_only=True)
  with self.assertRaisesRegex(RuntimeError,'COMPLETED_WITHOUT_ATTEMPT'):self.check([dict(node='D4',phase='STARTED',run_id='old'),dict(node='D4',phase='FINISHED',status='PASS')])
 def test_malformed_start_identity_blocks(self):
  self.state['status']='SAFE_STOP'
  with self.assertRaisesRegex(RuntimeError,'RUN_ID'):self.check([dict(node='D5',phase='STARTED',run_id='../escape'),dict(node='D5',phase='FINISHED',status='SAFE_STOP')])
 def test_unknown_status_blocks(self):
  self.state['status']='FAIL'
  with self.assertRaisesRegex(RuntimeError,'FINISH_STATUS'):self.check([dict(node='D5',phase='STARTED',run_id='x'),dict(node='D5',phase='FINISHED',status='MADE_UP')])

class HeartbeatProof(unittest.TestCase):
 def make(self,writer=lambda *a:None):return Heartbeat(Path('unused'),writer,dict(run_id='fixture'),interval=.01)
 def test_normalization_eta_unknown(self):
  h=self.make();h.update(phase='NORMALIZATION',total_rows=10);self.assertIsNone(h.sample()['eta_seconds'])
 def test_pipeline_eta_and_cap(self):
  h=self.make();h.update(phase='PIPELINE',total_rows=10,committed_rows=5);self.assertGreaterEqual(h.sample()['eta_seconds'],0)
  h.update(committed_rows=10);self.assertLess(h.sample()['committed_percent'],100);self.assertIsNone(h.sample()['eta_seconds'])
 def test_invalid_committed_rejected(self):
  for bad in (-1,True,1.5):
   h=self.make();h.update(committed_rows=bad)
   with self.assertRaisesRegex(RuntimeError,'COUNTS'):h.sample()
 def test_flush_failure_propagates_and_thread_closes(self):
  reached=threading.Event();count=[0]
  def writer(*a):
   count[0]+=1
   if count[0]>1:reached.set();raise OSError('flush failed')
  h=self.make(writer).start();self.addCleanup(h.stop.set);self.assertTrue(reached.wait(2));h.thread.join(2)
  with self.assertRaisesRegex(RuntimeError,'DURABLE_HEARTBEAT_FAILED'):h.close('PASS')
  self.assertFalse(h.thread.is_alive())
 def test_shutdown_keeps_emitting_until_explicit_close(self):
  emitted=threading.Event();rows=[]
  def writer(p,r):
   rows.append(r)
   if len(rows)>2:emitted.set()
  h=self.make(writer).start();self.addCleanup(h.stop.set);h.update(phase='CLEANUP');self.assertTrue(emitted.wait(2));h.close('SAFE_STOP')
  self.assertFalse(h.thread.is_alive());self.assertEqual(rows[-1]['status'],'SAFE_STOP');self.assertEqual([r['sequence'] for r in rows],list(range(1,len(rows)+1)))
 def test_identity_cannot_be_overwritten(self):
  h=self.make()
  with self.assertRaisesRegex(RuntimeError,'IDENTITY'):h.update(run_id='foreign')

class EntryRouting(unittest.TestCase):
 def setUp(self):
  self.i=dict(bindings=dict(source_root='/source',dest_root='/dest',scratch_root='/scratch'),ledger_path='/ledger',resources=dict(max_workers=4,ram_target_percent=50))
  self.a=types.SimpleNamespace(instance=self.i,revalidate=lambda:None)
  self.cm=patch.object(chain,'ReleaseChain');self.mock=self.cm.start();self.addCleanup(self.cm.stop);self.mock.return_value.__enter__.return_value=self.a
 def call(self,**kw):return mw.execute_multiwork(Path('/source'),Path('/dest'),Path('/scratch'),Path('/ledger'),max_workers=kw.get('max_workers',4),ram_target_percent=50,chain_file='chain',chain_sha256='A'*64,b06_sha256='B'*64)
 def test_compatibility_calls_full_lifecycle_not_engine(self):
  import subprocess
  for entry in ('control/FULL_RUNNER.py','control/FULL_STAGE_CONTINUATION.py','control/FULL_INSTANCE_PREPARE.py','full/tickstore_full_multiwork.py'):
   result=subprocess.run([sys.executable,'-I','-B',str(prior.ROOT/entry),'--help'],capture_output=True,text=True,timeout=15)
   self.assertEqual(result.returncode,0,result.stderr)
  with patch.object(runner,'main',return_value=130) as route,patch.object(mw,'_execute_admitted_multiwork',side_effect=AssertionError('engine bypass')):
   self.assertEqual(self.call(),130);self.assertIn('FULL',route.call_args[0][0])
 def test_root_drift_blocks_route(self):
  self.i['bindings']['source_root']='/other'
  with patch.object(runner,'main',side_effect=AssertionError('must block')),self.assertRaisesRegex(RuntimeError,'ROOT_DRIFT'):self.call()
 def test_limit_drift_blocks_route(self):
  with patch.object(runner,'main',side_effect=AssertionError('must block')),self.assertRaisesRegex(RuntimeError,'RESOURCE_DRIFT'):self.call(max_workers=3)


class QualificationContract(unittest.TestCase):
 def setUp(self):
  import test_first_admission_transaction as f
  self.f=f.TransactionTests();self.f.setUp();self.addCleanup(self.f.doCleanups)
 def check(self):qual.validate(self.f.complete,self.f.contract,self.f.delta,'A'*64,require)
 def test_exact_bound_contract_accepts_fixture(self):self.check()
 def test_linux_cannot_be_promoted(self):
  self.f.delta.update(native_windows=False)
  with self.assertRaisesRegex(RuntimeError,'NATIVE_WINDOWS'):self.check()
 def test_each_bad_test_status_blocks(self):
  for s in ('FAIL','ERROR','SKIP','UNKNOWN'):
   self.f.delta['tests'][0]['status']=s
   with self.subTest(s=s),self.assertRaisesRegex(RuntimeError,'FAILURE_ERROR_OR_SKIP'):self.check()
 def test_recounted_baseline_blocks(self):
  self.f.complete['baseline_results_counted_as_delta']=True
  with self.assertRaisesRegex(RuntimeError,'BASELINE_NOT_NEW'):self.check()
 def test_wrong_final_bytes_blocks(self):
  self.f.delta['code_manifest_sha256']='B'*64
  with self.assertRaisesRegex(RuntimeError,'FINAL_BYTES'):self.check()
 def test_missing_physical_baseline_blocks(self):
  del self.f.complete['baseline_archive_evidence']
  with self.assertRaisesRegex(RuntimeError,'BASELINE_PHYSICAL'):self.check()
 def test_duplicate_test_ids_block(self):
  self.f.contract['required_tests'].append('second');self.f.delta['tests']*=2
  with self.assertRaisesRegex(RuntimeError,'TEST_SET'):self.check()
 def test_duplicate_required_proof_blocks(self):
  self.f.contract['required_target_proofs']*=2
  with self.assertRaisesRegex(RuntimeError,'PROOFS_CONTRACT'):self.check()
 def test_missing_target_proof_blocks(self):
  self.f.delta['target_proofs']={}
  with self.assertRaisesRegex(RuntimeError,'PROOFS_SET'):self.check()
 def test_unhashed_target_evidence_blocks(self):
  self.f.delta['target_proofs']['fixture-proof']['evidence'][0]['sha256']='0'
  with self.assertRaisesRegex(RuntimeError,'TARGET_EVIDENCE'):self.check()
 def test_count_substitution_blocks(self):
  self.f.complete['delta_test_totals']['run']=127
  with self.assertRaisesRegex(RuntimeError,'TOTALS_PARITY'):self.check()


class InstancePreparation(unittest.TestCase):
 def setUp(self):
  import FULL_INSTANCE_PREPARE as prep
  self.prep=prep;self.bindings={k+'_root':__import__('os').path.normcase(__import__('os').path.abspath(k)) for k in ('source','dest','scratch')}
  self.inputs=dict(schema='TICKSTORE_INSTANCE_INPUTS_V001',source_root='source',dest_root='dest',scratch_root='scratch',
     ledger_path='ledger',config_sha256='C'*64,d4_resume_root='resume',policy_root='policy',origin_witness='witness',resources=dict(max_workers=4,ram_target_percent=60),d4_parameters={k:'fixture' for k in runner.D4_PARAMETERS})
  for key in ('source_root','dest_root','scratch_root','ledger_path','d4_resume_root','policy_root','origin_witness'):self.inputs[key]=str(Path(self.inputs[key]).absolute())
  self.inputs['d4_parameters']={k:str(Path(v).absolute()) if not k.endswith('Sha') else v for k,v in self.inputs['d4_parameters'].items()}
  self.inputs['d4_parameters'].update(FinalCodeManifestSha='A'*64,PolicyRoot=self.inputs['policy_root'],OriginCapturePath=self.inputs['origin_witness'])
 def compile(self):return self.prep.compile_instance(self.inputs,self.bindings,{'control_root':str(Path('control').absolute())},'A'*64,'B'*64,run_id='1'*32)
 def test_preparation_never_grants_authority(self):
  obj=self.compile();self.assertFalse(obj['authority_created']);self.assertFalse(obj['production_started']);self.assertEqual(obj['state_path'],str(Path('control/state/STATE.json').absolute()))
 def test_changed_root_blocks(self):
  self.inputs['scratch_root']=str(Path('other').absolute())
  with self.assertRaisesRegex(RuntimeError,'ROOT_BINDING'):self.compile()
 def test_resource_booleans_rejected(self):
  self.inputs['resources']['max_workers']=True
  with self.assertRaisesRegex(RuntimeError,'RESOURCE_LIMITS'):self.compile()
 def test_manifest_drift_blocks(self):
  self.inputs['d4_parameters']['FinalCodeManifestSha']='D'*64
  with self.assertRaisesRegex(RuntimeError,'MANIFEST_BINDING'):self.compile()
 def test_policy_source_drift_blocks(self):
  self.inputs['origin_witness']=str(Path('other').absolute())
  with self.assertRaisesRegex(RuntimeError,'POLICY_INPUTS'):self.compile()

if __name__=='__main__':unittest.main(verbosity=2)
