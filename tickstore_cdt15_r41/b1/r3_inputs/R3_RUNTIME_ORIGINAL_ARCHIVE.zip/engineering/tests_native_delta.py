"""Windows-only fixtures; never touches productive roots or creates real admission."""
from pathlib import Path
import os,sys,tempfile,unittest,json,time,subprocess,ctypes,threading,uuid
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'cdt15'))
import tests_delta as prior
from FULL_PROCESS_CONTROL import ProcessJob
from FULL_OBSERVABILITY import Heartbeat
import tickstore_full_multiwork as mw
import tickstore_serial_runner as core

def evidence(name, value):
 root=os.environ.get('TICKSTORE_NATIVE_ARTIFACTS')
 if root:
  path=Path(root);path.mkdir(parents=True,exist_ok=True)
  (path/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

def child_alive(marker):
 Path(marker).write_text(str(os.getpid()))
 while True:time.sleep(.1)

def coordinator(marker):
 import multiprocessing
 job=ProcessJob();child=job.start(multiprocessing.get_context('spawn'),child_alive,args=(marker,))
 while not Path(marker).exists():time.sleep(.02)
 # Actual abrupt coordinator exit: no finally or Python Job.close().
 os._exit(77)

class NativeDelta(unittest.TestCase):
 def test_four_workers_real_ntfs_zstd_deterministic_replay(self):
  self.assertEqual(os.name,'nt')
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);source,dest,days,months,contract,ids,cert=prior.fixture(root,('20260302','20260401','20260504','20260601'))
   scratch=root/'scratch';scratch.mkdir();admission=prior.FixtureAdmission();csv={p.name:core.sha256_file(p) for p in source.iterdir()}
   rec=[]
   with patch.object(core,'full_release_materials',return_value=(contract,cert,ids)),patch.object(core,'load_ledgers',return_value=(days,months,core.EXPECTED_P4A_LEDGER_SHA256)):
    self.assertEqual(mw._execute_admitted_multiwork(source,dest,scratch,root/'fixture','4',4,60,admission,completion=rec.append),0)
    before=core.sha256_file(core.manifest_path(dest))
    self.assertEqual(mw._execute_admitted_multiwork(source,dest,scratch,root/'fixture','2',4,60,admission,completion=rec.append),0)
   self.assertEqual(before,core.sha256_file(core.manifest_path(dest)));self.assertEqual(len(rec),2)
   self.assertEqual(rec[0]['rows'],12);self.assertEqual(csv,{p.name:core.sha256_file(p) for p in source.iterdir()})
   heartbeats=list((scratch/'RUN_INSTANCES'/admission.instance['run_id']).glob('HEARTBEAT_*.json'))
   self.assertEqual(len(heartbeats),2)
   for p in heartbeats:
    h=json.loads(p.read_bytes());self.assertEqual(h['status'],'ENGINE_PASS_PENDING_POSTFULL');self.assertLess(h['committed_percent'],100)
   evidence('FOUR_WORKERS_REPLAY',dict(reconciliations=rec,manifest=core.load_manifest(dest),
     source_before=csv,source_after={p.name:core.sha256_file(p) for p in source.iterdir()},
     heartbeats=[json.loads(p.read_bytes()) for p in heartbeats],native_windows=True,production_execution=False))
 def test_coordinator_abrupt_exit_contains_native_child(self):
  self.assertEqual(os.name,'nt')
  with tempfile.TemporaryDirectory() as td:
   marker=Path(td)/'child';p=subprocess.Popen([sys.executable,'-B',str(Path(__file__)),'--crash-coordinator',str(marker)])
   try:
    self.assertEqual(p.wait(timeout=30),77)
    self.assertTrue(marker.exists());pid=int(marker.read_text())
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];k.OpenProcess.restype=ctypes.c_void_p
    k.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong];k.WaitForSingleObject.restype=ctypes.c_ulong
    k.CloseHandle.argtypes=[ctypes.c_void_p];k.CloseHandle.restype=ctypes.c_int
    h=k.OpenProcess(0x100000,False,pid)
    if h:
     try:self.assertEqual(k.WaitForSingleObject(h,10000),0,'orphan child still alive')
     finally:k.CloseHandle(h)
    else:self.assertEqual(ctypes.get_last_error(),87)
    evidence('COORDINATOR_CRASH',dict(coordinator_exit=77,child_pid=pid,child_terminated=True,native_job=True,production_execution=False))
   finally:
    if p.poll() is None:p.kill();p.wait(10)
 def test_heartbeat_reparse_destination_cannot_modify_target(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);target=root/'target';target.write_bytes(b'untouched');link=root/'heartbeat';link.symlink_to(target)
   with self.assertRaises((RuntimeError,OSError)):mw._atomic_coordinator_state(link,{'fixture':True})
   self.assertEqual(target.read_bytes(),b'untouched')
 def test_dpapi_key_roundtrip_and_tamper_rejection(self):
  import D4_FIRST_ADMISSION_BOOTSTRAP as b
  key=os.urandom(32);blob=b.dpapi(key,True);self.assertEqual(b.dpapi(blob,False),key)
  bad=bytearray(blob);bad[len(bad)//2]^=1
  with self.assertRaises(OSError):b.dpapi(bytes(bad),False)

if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='--crash-coordinator':coordinator(sys.argv[2])
 else:unittest.main(verbosity=2)
