"""Re-bind the integration map (built on the V004 bytes) to the final V005 bytes.

Usage: python -I make_v005_map.py <V004_FULL_INVENTORY.json> <V004 zip> <V005 zip> <out V005_COMPONENT_MAP.json>
For each of the 163 runtime components of the inventory: V004 and V005 SHA-256 read from the ZIPs, changed flag, and
the inventory's roles/consumers.  Also lists every package member that differs between V004 and V005 (added, removed,
changed), so the auditor sees the complete delta in the final bytes, not only the runtime part.
"""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

inv_p, z4, z5, out = map(Path, sys.argv[1:5])
H = lambda b: hashlib.sha256(b).hexdigest().upper()
inv = json.loads(inv_p.read_text(encoding='utf-8'))


def members(zp):
    with zipfile.ZipFile(zp) as z:
        return {n: H(z.read(n)) for n in z.namelist() if not n.endswith('/')}


m4, m5 = members(z4), members(z5)
with zipfile.ZipFile(z5) as z:
    rc5 = json.loads(z.read('implementation_v001/RUNTIME_CODE_MANIFEST.json'))
rc5 = {r['path']: r['sha256'].upper() for r in rc5['files']}
comps = []
for c in inv['components']:
    rel = c['path'][len('candidate/'):]
    k = 'implementation_v001/' + c['path']
    v4, v5 = m4.get(k), m5.get(k)
    assert v4 == c['actual_sha256'], ('INVENTORY_NOT_V004', c['path'])
    assert v5 is not None and rc5.get(rel) == v5, ('V005_RUNTIME_MANIFEST', c['path'])
    comps.append({'path': c['path'], 'v004_sha256': v4, 'v005_sha256': v5, 'changed_in_v005': v4 != v5,
                  'categories': c['categories'], 'role': c['role'], 'entry_points': c['entry_points'],
                  'imports_from_candidate': c['imports_from_candidate'], 'reverse_deps_runtime': c['reverse_deps_runtime'],
                  'reverse_deps_tests_qual_other': c['reverse_deps_tests_qual_other']})
assert len(comps) == len(rc5) == 163
delta = {'added': sorted(set(m5) - set(m4)), 'removed': sorted(set(m4) - set(m5)),
         'changed': sorted(n for n in set(m4) & set(m5) if m4[n] != m5[n])}
doc = {'schema': 'CDT21_V005_COMPONENT_MAP_V001',
       'basis': 'inventario de integracao feito sobre os bytes do V004 (V004_FULL_INVENTORY.json), revinculado aos bytes finais do V005',
       'v004_zip_sha256': H(z4.read_bytes()), 'v005_zip_sha256': H(z5.read_bytes()),
       'runtime_components': len(comps), 'runtime_changed_in_v005': [c['path'] for c in comps if c['changed_in_v005']],
       'package_delta_v004_to_v005': delta, 'components': comps}
out.write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding='utf-8')
print('V005_MAP', len(comps), 'runtime changed', doc['runtime_changed_in_v005'], 'pkg delta', {k: len(v) for k, v in delta.items()})
print(json.dumps(delta, indent=0))
