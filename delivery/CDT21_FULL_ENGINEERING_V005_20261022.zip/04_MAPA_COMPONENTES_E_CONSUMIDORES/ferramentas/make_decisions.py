"""Write INTEGRATION_REVIEW_DECISIONS.json: one decision per gap of the integration review, the pre-delivery matrix
rows (every item of the consolidated mission and A1-A6) and the state of every operational gate.

Usage: python -I make_decisions.py <V004_FULL_INVENTORY.json> <V005_COMPONENT_MAP.json> <V005_REGRESSION_NEGATIVE_CONTROL.json> <out.json>
Gap ids, severities and titles are copied from the inventory (built on the V004 bytes); decisions refer to the V005
bytes.  A decision is never "closed" without a pointer to the evidence that travels in the FULL package.
"""
import json
import sys
from pathlib import Path

inv, cmap, reg = (json.loads(Path(p).read_text(encoding='utf-8')) for p in sys.argv[1:4])
out = Path(sys.argv[4])
EV_REG = '06_EVIDENCIAS/V005_DELTA/V005_REGRESSION_NEGATIVE_CONTROL.json'
EV_SWEEP = '06_EVIDENCIAS/V005_DELTA/SWEEP_V004.json + SWEEP_V005.json'
EV_MAP = '04_MAPA_COMPONENTES_E_CONSUMIDORES/V005_COMPONENT_MAP.json'
NATIVE_P1 = 'nativo no P1: a suite esta no plano G5 congelado de 38 unidades'
assert reg['pass'] is True and reg['summary']['new_tests_fail_on_v004'] == 7 and reg['summary']['new_tests_pass_on_v005'] == 7

D = {
 'GAP-01': ('CLOSED_IN_CODE_V005', 'FULL_STAGE_EVIDENCE.publish espelha FULL_RELEASE_CHAIN.validate_chain: testemunhas de no so de D5 a FULL_ADMISSION; o D4 e publicado sem elas e testemunhas inventadas sao recusadas.',
            [EV_REG + ' (test_cdt18_stage_proof_integrated_reconcile test_06/test_07: falham no V004, passam no V005)', NATIVE_P1],
            'Publicacao real do recibo D4 (D4Close) ocorre somente no D4.'),
 'GAP-02': ('CLOSED_IN_CODE_V005', 'FULL_RUNNER.d4_command exige e passa -G5StageReceiptPath/-G5InstancePath tirados da cadeia admitida (recibo G5 e INSTANCE da propria cadeia); o operador nao os digita.',
            [EV_REG + ' (test_operator_entry_points test_v005_01..03)', NATIVE_P1], 'Execucao real do wrapper selado ocorre somente no D4.'),
 'GAP-03': ('CLOSED_IN_CODE_V005', 'Launcher adaptado fixa a entrada inline vinculada (9BFFE835...); RUNTIME_LOCATOR_ADAPTER_BINDING.adapted_launch_sha256 e FIRST_ADMISSION_BINDING acompanham. DIVULGACAO: regressao introduzida pelo delta V003 do implementador (F-01/F-04), que mudou a entrada sem atualizar o pin.',
            [EV_REG + ' (test_v005_04)', NATIVE_P1 + ' (igualdade de pins lida no Windows)'],
            'Execucao nativa do launcher adaptado (lancamento de bundle) so ocorre no D4 (CERTIFY_SCRATCH).'),
 'GAP-04': ('CLOSED_IN_CODE_V005', 'Identidade unica do ZIP sucessor = a da migracao RC1R1 (8A05E761...); o bootstrap D4 exige o mesmo digest. Procedimento 8b corrigido (V002R24).',
            [EV_REG + ' (test_v005_05)', 'Q do P1 registra, somente leitura e sem bloquear, presenca e SHA-256 do arquivo fisico em D:'],
            'Se o arquivo fisico tiver outro SHA-256, a decisao e da origem; o pin nao e trocado.'),
 'GAP-05': ('GATED_NATIVE_PRODUCTION_AT_D4', 'Nenhum produtor de TICKSTORE_D4_PREDECESSOR_OBSERVATION_V001 / _SYSTEM_OBSERVATION_V001 existe no pacote nem em qualquer artefato disponivel (busca recursiva em todos os ZIPs, inclusive aninhados). O contrato esta completo em D4_PREDECESSOR_RECONCILIATION.reconcile e D4_FIRST_ADMISSION_BOOTSTRAP.fresh_predecessor: censo nativo administrativo, mutex, ids de arquivo historicos das raizes, journal STARTED anterior a um boot posterior, idade <= 300 s. A observacao descreve o estado real da producao no instante da admissao; nao pode ser produzida nem qualificada antes do D4 sem ler producao fora dos gates.',
            ['procedimento operacional, secao V005 item 4 (contrato e local dos arquivos)', '10_PROCEDIMENTOS/P4 (preparacao do D4)'],
            'Observador somente leitura a preparar pelo Opus na preparacao do D4 (apos B07), com execucao e qualificacao no Windows do titular.'),
 'GAP-06': ('CLOSED_IN_DOCS_V005__ISSUER_IS_ORIGIN', 'Recibo TICKSTORE_D4_POLICY_ADMISSION_RECEIPT_V001 e registro da origem; o V005 traz TEMPLATE_D4_POLICY_ADMISSION_RECEIPT.json com os campos exigidos pelos consumidores. O implementador nao o emite.',
            ['implementation_v001/procedures/TEMPLATE_D4_POLICY_ADMISSION_RECEIPT.json'], 'Emissao pela origem antes do D4.'),
 'GAP-07': ('CLOSED_IN_DOCS_V005', 'Procedimento corrigido: o G5 admitido e o V003; comando do G5_FINAL_COMPLETENESS_PRODUCER sobre a INSTANCE operacional documentado (secao V005 item 1). Confirmado no codigo: o caminho V003 do ORIGIN_DECISION_BINDER valida o R08_RETURN.zip da campanha PRE_G06 por verify_native_campaign; nao ha G4/QUAL separado nesse caminho.',
            ['procedimento operacional, secao V005 item 1'], 'Execucao apos o P1 e a INSTANCE operacional (etapa 2).'),
 'GAP-08': ('NOT_CHANGED_JUSTIFIED__NEW_EXECUTORS_FOLLOW_OWNER_RULE', 'Raiz de log congelada C:\\Users\\silvi\\OneDrive\\Downloads\\TICKSTORE_RUNS: absoluta, fixa, nunca derivada do cwd, provada nativamente e fixada por teste; migrar exigiria alterar 3 executores congelados e o teste. Executores novos (supervisor/launcher G5 V005) gravam em C:\\Users\\silvi\\Downloads\\CDT21_G5_V005_RUNS\\G5V5_<stamp>. Instalador: usar -WitnessPath com caminho em C:\\Users\\silvi\\Downloads (evita o default legado e a cardinalidade de testemunhas). Saida do wrapper D4 no console: os efeitos e o resultado do D4 ficam no journal/STATE/RUN_AUTHORITY e no recibo D4; redirecionar alteraria a semantica de Ctrl+C provada nativamente (R45 G7).',
            ['procedimento operacional, secao V005 item 5', '10_PROCEDIMENTOS/P1 e P4'], 'Nenhum efeito funcional; registrado para a origem.'),
 'GAP-09': ('CLOSED_IN_CODE_V005', 'SOURCE_MANIFEST fechado (inclui RUNTIME_CODE_MANIFEST.json); VERIFY_FULL_COMPOSITION_SOURCE_ONLY.py do proprio candidato passa nos bytes do V005. DIVULGACAO: a omissao veio das montagens V003/V004 do implementador. Documentos de status CDT17 mantidos como historico; estado vigente em README_CDT21_V005_FULL_INTEGRATION.md e CDT21_V005_ENGINEERING_COMPLETENESS.json.',
            ['05_MANIFESTOS/SOURCE_MANIFEST.json', '02_CANDIDATO_V005/V005_CANDIDATE_VERIFICATION.json'], 'Nenhum.'),
 'GAP-10': ('RESERVED_TO_ORIGIN__GATED_AT_B07', 'B07 exige 4 overlays derivados aprovados pela origem: o arquivo R3 (2379512B...) e 2 overlays (tests_full_lifecycle 29981D15..., tests_delta 2E95CADE...) estao no B1_APPROVED_INPUTS empacotado; os derivados test_first_admission_transaction (E74F3701...) e test_bootstrap_contract (40B396FC...) nao existem em nenhum artefato disponivel (as copias b1/ empacotadas sao outras derivacoes: F9160008..., 3A8C64CA...). Fabricar derivados aprovados pela origem seria forjar entrada. O pacote QUAL (QUAL_MANIFEST, qual/QUAL_PLAN.json, QUAL_DRIVER.py) esta no mesmo arquivo empacotado; o launcher B07 e montado no despacho da B07. Modulos de teste executados pela B07 fora do manifesto de runtime sao vinculados pelo PACKAGE/SOURCE_MANIFEST e reconferidos pelo produtor B07 contra o ZIP final.',
            ['busca recursiva registrada no relatorio', 'B07_TECHNICAL_PRODUCER.TEST_TREE'], 'Origem fornece os 2 overlays derivados; Opus monta o launcher B07 apos B06 PASS.'),
 'GAP-11': ('CLOSED_IN_DOCS_V005', 'TEMPLATE_B06_VERDICT.txt = cabecalho unico TICKSTORE_D4_RESUMABLE_CODE_DELTA_REVIEW_V002R22 + exatamente 31 chaves, lido igualmente pelo produtor B07 e pelo motor D4.',
            ['implementation_v001/procedures/TEMPLATE_B06_VERDICT.txt'], 'O revisor independente deve usar o modelo literalmente.'),
 'GAP-12': ('NOT_CHANGED_JUSTIFIED', 'control/FULL_QUALIFICATION_CONTRACT.py = SUPPORT/FULL_QUALIFICATION_CONTRACT.py + evaluate_formal_g5_stage (diferenca apos normalizar CRLF); qualquer ordem de importacao entrega todas as funcoes que os consumidores SUPPORT usam. Alterar a maquinaria G5 congelada nao traz ganho funcional.',
            [EV_MAP], 'Registrado para o auditor.'),
 'GAP-13': ('NOT_CHANGED_JUSTIFIED', 'D4Close nao elevado e decisao de projeto explicita, fixada por test_full_runner_observability_r41 test_30; o efeito alegado (VSS sem elevacao) nao foi verificado. Avaliacao nativa no D4Close.',
            ['tests/test_full_runner_observability_r41.py test_30'], 'Se o D4Close bloquear por privilegio no D4, o retorno vai ao Opus.'),
 'GAP-14': ('INFO_RECORDED', 'Rotulos de rota/versao antigos sem efeito funcional; V38/V002R22 sao ABI congelada.', [], 'Nenhum.'),
 'GAP-15': ('INFO_RECORDED', 'Contagens do razao certificado (1550 dias, 7.049.522.162 linhas, 3101 arquivos) fixas por projeto: qualquer mudanca bloqueia CANARY/FULL (falha fechada).', [], 'Nenhum.'),
 'GAP-16': ('PHYSICAL_OWNER_WINDOWS__P1', 'Nao ha evidencia nativa dos bytes do V005 (nem poderia haver antes do P1). O G0 nativo do V004 vale para os bytes do V004 e nao e apresentado como aprovacao do V005.',
            ['10_PROCEDIMENTOS/P1'], 'Campanha G5 nativa do V005 no Windows do titular.'),
 'GAP-17': ('RESERVED_TO_ORIGIN__TEST_ONLY', 'Achado desta entrega (varredura Linux): tests/test_b2c_policy_capture_binding.py e tests/test_b07_technical_producer.py importam fixtures de captura de politica (R40_CAPTURE_NON_AUTHORITATIVE, V38_CAPTURE_HISTORICAL) que o pacote carrega somente dentro de B1_APPROVED_INPUTS/TICKSTORE_CDT16_FULL_C5R44_G5_CONTRACT_REBASED_SOURCE_ONLY_20261015.zip; por isso nao rodam a partir da arvore empacotada (V003, V004 e V005). Nenhum dos dois esta no plano G5 nem nos runners B07. Com as fixtures copiadas do arquivo empacotado para uma arvore descartavel (hash registrado, conteudo nao lido): test_b07_technical_producer 21/21 OK no V004 e no V005; test_b2c test_34 (adaptado no V005) OK no V005 e ERROR no V004; test_b2c 30-33 falham de forma identica no V004 e no V005 (esperam a ordem de bloqueio de um G5 V002; a transacao atual bloqueia antes, em FINAL_G5_V003_REQUIRED_NO_V002_PROMOTION). Colocar copias de MASTER/HEAD na arvore do pacote e decisao de custodia da origem; por isso nao foi feito.',
            [EV_REG], 'Origem decide se as capturas historicas podem ser copiadas para tests/fixtures; com isso, os testes 30-33 sao atualizados para o contrato G5 V003 numa revisao seguinte, sem efeito no runtime.'),
}
inv_gaps = {g['id']: g for g in inv['gaps']}
assert set(inv_gaps) | {'GAP-17'} == set(D), sorted(set(D) ^ set(inv_gaps))
gaps = []
for gid in sorted(D):
    decision, basis, evidence, residual = D[gid]
    g = inv_gaps.get(gid, {'severity': 'LOW', 'title': 'Two non-plan test modules need policy-capture fixtures carried only inside a packaged archive'})
    gaps.append({'id': gid, 'severity': g['severity'], 'title': g['title'], 'decision': decision, 'basis': basis,
                 'evidence': evidence, 'residual': residual})
assert not [g for g in gaps if g['decision'].startswith('OPEN')]

ROW = lambda item, comps, status, ev, native, gate: {'item': item, 'components': comps, 'status_v005': status, 'evidence': ev,
                                                    'native_state': native, 'operational_gate': gate}
cat = {}
for c in cmap['components']:
    for k in c['categories']:
        cat.setdefault(k, []).append(c['path'])
n = lambda *ks: sorted({p for k in ks for p in cat.get(k, [])})
rows = [
 ROW('Instalador, ativacao oficial e menu', n('INSTALLER', 'OFFICIAL_ACTIVATION', 'MENU'), 'CONECTADO_EM_CODIGO',
     ['04: caminho a (V004_FULL_INVENTORY.md)', 'testemunha do instalador V005 (02)', 'G5_PS51_INSTALL_MENU no plano G5'],
     'PENDENTE_P1 (unidade G5_PS51_INSTALL_MENU); ativacao exige cadeia ate B07', 'ACTIVATION apos B07'),
 ROW('FULL_RUNNER e cadeia de admissao', n('FULL_RUNNER', 'ADMISSION_CHAIN'), 'CONECTADO_EM_CODIGO_V005 (D4 ligado: GAP-01/02)',
     [EV_REG, EV_SWEEP], 'PENDENTE_P1 (suites operator_entry_points, cdt18 stage proof, full_runner_observability)', 'G5..FULL_ADMISSION'),
 ROW('G5', n('G5'), 'PRONTO: supervisor/launcher G5 V005 qualificados (Linux, bytes exatos)',
     ['06_EVIDENCIAS/G5_V005_SUPERVISOR'], 'PENDENTE_P1', 'G5'),
 ROW('B06', n('B06'), 'MODELOS CORRIGIDOS (GAP-11); B06_RECEIPT_CHECK congelado', ['implementation_v001/procedures/TEMPLATE_B06_VERDICT.txt'],
     'NAO_APLICAVEL (revisao independente)', 'B06 reservada ao Work independente'),
 ROW('B07', n('B07'), 'CONECTADO_EM_CODIGO; entradas externas pendentes (GAP-10)', ['04: GAP-10'], 'PENDENTE (apos B06)', 'B07'),
 ROW('D4', n('D4'), 'CONECTADO_EM_CODIGO_V005 (GAP-01/02/03/04); entradas da origem e observacao nativa pendentes (GAP-05/06)',
     [EV_REG], 'PENDENTE (apos B07)', 'D4'),
 ROW('D5, canario, FULL_PREP, FULL_ADMISSION', n('D5', 'CANARY', 'FULL_PREP', 'FULL_ADMISSION'), 'CONECTADO_EM_CODIGO; alcancavel apos o recibo D4 (GAP-01 fechado)',
     ['04: caminho c', EV_REG + ' (test_07: D5 continua exigindo testemunhas)'], 'PENDENTE (apos D4)', 'D5..FULL_ADMISSION'),
 ROW('MULTIWORK/AUTOCPU', n('MULTIWORK', 'AUTOCPU'), 'CONECTADO_EM_CODIGO (no G3 do FULL)', ['04: caminho c', 'SUITE_test_full_multiwork no plano G5'],
     'PENDENTE_P1 (suite); execucao real no FULL', 'FULL'),
 ROW('Checkpoints e commits atomicos', n('CHECKPOINT_ATOMIC_COMMIT'), 'CONECTADO_EM_CODIGO', ['04: caminho c', 'SUITE_test_scratch_powerloss_debris, test_state_cas_recovery no plano G5'],
     'PENDENTE_P1 (suites); queda fisica de energia NOT_TESTED_PHYSICAL_POWERLOSS', 'D4..FULL'),
 ROW('SAFE_STOP e recuperacao', n('SAFE_STOP', 'CRASH_RECOVERY', 'PROCESS_CONTROL'), 'CONECTADO_EM_CODIGO; supervisor G5: SAFE_STOP, morte abrupta e retomada (R3/R4)',
     ['06_EVIDENCIAS/G5_V005_SUPERVISOR', '10_PROCEDIMENTOS/P2'], 'PENDENTE_P1 (suites native_process_control_r41)', 'todos'),
 ROW('Retomada deterministica sem duplicacao', n('DETERMINISTIC_RESUME'), 'CONECTADO_EM_CODIGO; G5: retomada da mesma campanha + reconciliacao R4 por prova',
     ['06_EVIDENCIAS/G5_V005_SUPERVISOR (W1-W4, NR01-NR14)'], 'PENDENTE_P1', 'todos'),
 ROW('Watchdog, heartbeat, progresso e ETA', n('WATCHDOG', 'HEARTBEAT_PROGRESS_ETA'), 'CONECTADO_EM_CODIGO (Monitor somente leitura; heartbeat do G5)',
     ['04: caminho c', 'SUITE_test_full_runner_observability_r41 no plano G5'], 'PENDENTE_P1 (suite)', 'FULL'),
 ROW('Verificacao final e recibos fisicos', n('FINAL_VERIFICATION_RECEIPTS'), 'CONECTADO_EM_CODIGO; recibo D4 publicavel (GAP-01)',
     ['04: caminho c', EV_REG], 'PENDENTE (no FULL)', 'FULL'),
]
gates_state = [
 {'gate': 'G0 (delta F01R1 do V004)', 'state': 'PASS_NATIVE_SOBRE_BYTES_V004', 'note': 'historico; nao aprova os bytes do V005', 'executor': 'titular (feito)'},
 {'gate': 'G5 tecnico do V005 (campanha nativa PRE_G06, 38 unidades)', 'state': 'NOT_STARTED__READY', 'prerequisite': 'nenhum', 'executor': 'titular no Windows (P1)', 'return_to': 'Opus'},
 {'gate': 'Instalacao do V005 (INSTALLED_NOT_PRODUCTION_ADMISSION)', 'state': 'NOT_STARTED__OPTIONAL_BEFORE_ACTIVATION', 'prerequisite': 'nenhum (nao e admissao)', 'executor': 'titular (P4)'},
 {'gate': 'INSTANCE operacional (etapa 2)', 'state': 'NOT_STARTED', 'prerequisite': 'P1 PASS', 'executor': 'titular'},
 {'gate': 'Completude G5 V003 sobre a INSTANCE operacional', 'state': 'NOT_STARTED', 'prerequisite': 'P1 PASS + INSTANCE', 'executor': 'titular (comando na secao V005 item 1)'},
 {'gate': 'Decisao G5 (etapa 3) e recibo de estagio G5 (3b)', 'state': 'NOT_STARTED', 'prerequisite': 'completude G5 + reconciliacao de politica corrente', 'executor': 'origem (decisao) + titular (binder)'},
 {'gate': 'B06', 'state': 'NOT_STARTED__RESERVED_INDEPENDENT_WORK', 'prerequisite': 'P1 PASS verificado pelo Opus', 'executor': 'Work independente (irma do titular)'},
 {'gate': 'B07', 'state': 'NOT_STARTED', 'prerequisite': 'B06 PASS + 2 overlays derivados da origem (GAP-10) + launcher B07 montado no despacho + decisao da origem', 'executor': 'titular no Windows; decisao da origem'},
 {'gate': 'Ativacao oficial do menu', 'state': 'NOT_STARTED', 'prerequisite': 'cadeia ate B07', 'executor': 'titular'},
 {'gate': 'LEGACY_ENTRY_FENCE (pre-requisito do D4)', 'state': 'NOT_APPLIED', 'prerequisite': 'cadeia ate B07; PROCEDIMENTO_CDT21_LEGACY_ENTRY_FENCE.md', 'executor': 'titular'},
 {'gate': 'Migracao 8b do sucessor D4 (V002R22 -> V002R24)', 'state': 'NOT_STARTED', 'prerequisite': 'cadeia ate B07; ZIP fisico 8A05E761... (Q do P1 informa)', 'executor': 'titular'},
 {'gate': 'Recibo de admissao de politica D4 + pacote de revisao D4 + reconciliacao corrente', 'state': 'NOT_ISSUED', 'prerequisite': 'B07', 'executor': 'origem'},
 {'gate': 'Observacao nativa do predecessor D4 (<= 300 s)', 'state': 'NOT_STARTED__PRODUCER_AT_D4_PREPARATION', 'prerequisite': 'B07 + autorizacao de preparacao do D4', 'executor': 'Opus prepara; titular executa no Windows'},
 {'gate': 'D4', 'state': 'NOT_STARTED', 'prerequisite': 'tudo acima', 'executor': 'titular (MENU opcao 10 ou RUN_TICKSTORE_FULL.ps1 -Stage D4)'},
 {'gate': 'D5', 'state': 'NOT_STARTED', 'prerequisite': 'recibo D4', 'executor': 'titular'},
 {'gate': 'CANARY', 'state': 'NOT_STARTED', 'prerequisite': 'recibo D5', 'executor': 'titular'},
 {'gate': 'FULL_PREP', 'state': 'NOT_STARTED', 'prerequisite': 'recibo CANARY', 'executor': 'titular'},
 {'gate': 'Revisao Stage B + FULL_GO', 'state': 'NOT_STARTED', 'prerequisite': 'FULL_PREP', 'executor': 'revisor/origem'},
 {'gate': 'FULL_ADMISSION', 'state': 'NOT_STARTED', 'prerequisite': 'FULL_PREP + Stage B + FULL_GO', 'executor': 'titular'},
 {'gate': 'FULL', 'state': 'NOT_STARTED', 'prerequisite': 'FULL_ADMISSION fresca (<= 300 s)', 'executor': 'titular'},
 {'gate': 'Queda fisica de energia', 'state': 'NOT_TESTED_PHYSICAL_POWERLOSS', 'prerequisite': 'laboratorio separado com autorizacao especifica', 'executor': 'fora do escopo'},
]
doc = {'schema': 'CDT21_FULL_INTEGRATION_REVIEW_DECISIONS_V001', 'review_basis': 'inventario sobre os bytes do V004 (04/V004_FULL_INVENTORY.*) revinculado aos bytes do V005 (04/V005_COMPONENT_MAP.json)',
       'v005_zip_sha256': cmap['v005_zip_sha256'], 'v004_zip_sha256': cmap['v004_zip_sha256'], 'gaps': gaps, 'matrix_rows': rows,
       'a2_status': 'CLOSED_IN_V005_CODE__NATIVE_PENDING_P1',
       'a2_basis': 'cadeia FULL percorrida caminho a caminho nos bytes; a quebra no D4 (GAP-01/02/03/04) foi corrigida no V005 com 7 testes de regressao que falham no V004 e passam no V005; o mapa de 163 componentes foi revinculado aos bytes finais (6 alterados)',
       'a4_status': 'CLOSED_FOR_NEW_EXECUTORS__FROZEN_LOG_ROOT_JUSTIFIED',
       'a4_basis': 'executores novos em C:\\Users\\silvi\\Downloads\\<FAMILIA>_RUNS; retorno nativo ao Opus, consolidado a origem, B06 ao Work; raiz de log congelada OneDrive mantida (GAP-08); instalador por -WitnessPath',
       'five': {'all_implementations_integrated': 'PASS_SOURCE_TRACE_AND_LINUX__D4_PATH_CONNECTED_IN_CODE_V005'},
       'closed_items': ['GAP-01 recibo D4 publicavel', 'GAP-02 entradas G5 do D4', 'GAP-03 pin do launcher adaptado (regressao do V003)',
                        'GAP-04 identidade unica do ZIP sucessor', 'GAP-09 manifesto de fontes fechado', 'GAP-06/07/11 documentos de operacao'],
       'gates_state': gates_state}
out.write_text(json.dumps(doc, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')
print('DECISIONS', len(gaps), {g['id']: g['decision'] for g in gaps})
