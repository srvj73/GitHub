# V004 FULL inventory: component map and execution-path trace

Candidate: `scratchpad/f01r1/final/v004` (Tickstore CDT21 V004, F-01R1). Review date: 2026-10-22. Mode: read-only.

**Method.** Static reading, grep and AST parsing of the frozen bytes. Only three things were executed: (1) my own analysis scripts; (2) the candidate's pure reader `implementation_v001/VERIFY_FULL_COMPOSITION_SOURCE_ONLY.py` with `python3 -I -B` (it only reads, hashes, parses and prints); (3) `FULL_STAGE_EVIDENCE.publish` imported from **copies** of three modules in the scratchpad, to confirm GAP-01 (it raises before any write). Nothing under the candidate was written; no `__pycache__` exists there.

**Headline.** The installer, official activation, menu, FULL_RUNNER and the G5 -> B06 -> B07 admission chain exist and are wired. The chain cannot be carried end to end in these bytes. D4 is blocked twice: the menu/runner never passes two inputs the sealed D4 wrapper requires (GAP-02), and the D4 stage receipt cannot be published (GAP-01). Without a D4 receipt, D5, CANARY, FULL_PREP, FULL_ADMISSION and FULL are unreachable, although their code is connected. GAP-03 to GAP-06 are further hard blockers on the D4 path: a sealed hash contradiction, a second sealed hash contradiction, and two receipts with no producer in the package.

## 1. Component map

### 1.1 Manifest verification

| Manifest | sha256 (computed) | Entries | Result |
|---|---|---|---|
| `implementation_v001/RUNTIME_CODE_MANIFEST.json` (TICKSTORE_FINAL_RUNTIME_CODE_MANIFEST_V001) | `D2C626FD2819B86D472433CB2B26C6688B1688E5E5474402162B67C5048666FF` | 163 | All entries exist; size and sha256 match: **True**. Candidate files not in the manifest: **0**. |
| `implementation_v001/SOURCE_MANIFEST.json` | `459535EAB971474930F52A0F0380F909259431D3B9EE19323805082871B676DD` | 317 | All entries match. Not listed: `RUNTIME_CODE_MANIFEST.json`, `SOURCE_MANIFEST.json`. |
| `PACKAGE_MANIFEST.json` (TICKSTORE_FINAL_PACKAGE_MANIFEST_V001) | `F6225EA6720FCA558F8BBAD70B3ED46687103374873439E0FADDB4FEA9D3A813` | 319 | All entries match; only `PACKAGE_MANIFEST.json` itself is unlisted. |

- Runtime manifest `engineering_status`: `CDT21_V004_F01R1_DELTA_INTEGRATED_LINUX_QUALIFIED_WINDOWS_G0_TARGET_RUNTIME_PENDING`. Its sha256 `D2C626FD...` equals `runtime_code_manifest_sha256` in `CDT21_V004_ENGINEERING_COMPLETENESS.json` and `CDT21_V004_DELTA_RECEIPT.json`.
- The runtime manifest covers `implementation_v001/candidate/**` only. Code outside it (`qual/`, `tests/`, `powerloss_lab/`, root `*.py`) is bound only by SOURCE/PACKAGE manifests, yet some of it is executed by the B07 runner (GAP-10).
- recovery/CODE_MANIFEST.json (35) and recovery/99_MANIFEST_SHA256.json (41): all entries match; FIRST_ADMISSION_BINDING.json, RUNTIME_LOCATOR_ADAPTER_BINDING.json and PRE_G06_CONSUMER_REVIEW.json digests match current files (except GAP-03 pin inside the launcher).

### 1.2 All runtime files (163)

Categories follow the requested vocabulary. Full sha256 values come from the manifest and were recomputed; all match.

| # | Path (under `implementation_v001/candidate/`) | Bytes | sha256 (manifest = computed) | Categories | Role / entry points |
|---|---|---|---|---|---|
| 1 | `SUPPORT/FULL_QUALIFICATION_CONTRACT.py` | 28530 | `C184D8DC7CD9827313999635AA8CE08C4B67A8E1EA86485E794FDE2D958710CA` | SUPPORT, G5 | Older copy of the G5 qualification-contract library (control/ copy = this + evaluate_formal_g5_stage). Same module name as control/FULL_QUALIFICATION_CONTRACT.py; imported by SUPPORT/G5_C6_B1_FORMAL_CONSUMER.py when SUPPORT is first on sys.path. Entry: library |
| 2 | `SUPPORT/G5_C6_B1_FORMAL_CONSUMER.py` | 15726 | `41C78A16A4F7BE78C314CC707A685A367026BC8A7422A45567DA55B847545926` | SUPPORT, G5 | Scoped G5 C6 B1 formal consumer (historical owner-scoped G5 C6 evidence); loaded by control/G5_C6_FORMAL_CONTRACT.py. Entry: __main__: --inputs-dir --out-dir |
| 3 | `adapter/INLINE_ROOT_LOADER_V004_R1R1_ADAPTER.ps1` | 18402 | `10104BE1731E1FA27C51E9730C9F9334D1782C3673EFABDC225A6B7166B59855` | D4, D5, CANARY, FULL_PREP, PROCESS_CONTROL | Adapted inline root loader (defines Invoke-TickstoreInlineRootV004R1Adapter); pins bundle, python, adapter entry; launches child bundle. Entry: dot-sourced by Launch-TickstoreBundle-Adapter.ps1 |
| 4 | `adapter/Launch-TickstoreBundle-Adapter.ps1` | 2218 | `2732AFB300EBCFF7FA72DD3F18F80481E920E61697DCAE7B5679EE2AA94E808D` | D4, D5, CANARY, FULL_PREP, PROCESS_CONTROL | Launcher for target-generation child bundles (CERTIFY_SCRATCH at D4; CERTIFY_CANONICAL/MANIFEST_REDERIVATION/LIVE_EQUALITY/RECOVER/STALE_LOCK post-D4). Hard-codes ExpectedAdapterEntry=9DEE7D6C... (see GAP-03). Entry: powershell -File (from runtime_locator_adapter.adapted_launch) |
| 5 | `adapter/RUNTIME_LOCATOR_ADAPTER_BINDING.json` | 1461 | `6D82F50E85C241F4BA388C77192A6C01556D5DD4BB5E439349A30DC113049C90` | D4 | Sealed binding: adapter/entry/loader/launch digests, frozen engine+orchestrator digests, target VSS snapshot identity, policy pins. Entry: data |
| 6 | `adapter/adapter_tests.py` | 18786 | `280212DCBF9AB4C6E069A68783D09ADAB6D5F1766BE3A53770D3531D9DFB3809` | TEST_ONLY, B07 | Adapter unit tests; also executed by B07 probe g_ca_native_locator (b07/B07_CHECK_RUNNERS.py:160-166). Entry: __main__ unittest |
| 7 | `adapter/runtime_locator_adapter.py` | 29674 | `00F9C7AB69D034F8A26CA7BFDDC0876E105F0A60BCBF23F08659AD08C251B98A` | D4, D5, CANARY, FULL_PREP, CHECKPOINT_ATOMIC_COMMIT | G_CA runtime-locator adapter: validate_binding/receipt, install_orchestrator_namespace (patches O.n_d4/bundle/launch), install_engine_namespace, make_no_clobber_receipt_writer (immutable receipts). Entry: library |
| 8 | `adapter/runtime_locator_inline_entry.py` | 4947 | `9BFFE8358ABB36D68EF5D6ECA3B1319939612B31F22F40CD52176CC621EC6DAC` | D4, D5, CANARY, FULL_PREP | Child-bundle Python entry: preverifies payload (RELEASE_MANIFEST, OWNER_GATE, adapter, receipt) and composes runtime. Entry: __main__ --bootstrap-handle |
| 9 | `adapter/runtime_locator_orchestrator_entry.py` | 63997 | `496D64083A878E3D570B8C4EC949E4FAB8037207FFE428575EA848548F324EF5` | D4, CRASH_RECOVERY, CHECKPOINT_ATOMIC_COMMIT, SAFE_STOP | Elevated D4 entry + shared STATE boundary: acquire_state_boundary, guard_frozen_state_reads (STATE CAS commits), require_legacy_entry_fence, validate_d4_start, reconcile_resume_identity, read_pinned_regular. Entry: __main__ command --until --package --python; library for FULL_STAGE_CONTINUATION/FULL_D4_CLOSURE |
| 10 | `b07/B07_CHECK_RUNNERS.py` | 14067 | `B4907AB4470B849B3A6FE2A52D062982DAA9BA94A486CF8B56383553B347BC2F` | B07 | Native B07 check runner: requires chain until B06 (ReleaseChain), builds R3 test tree from external origin archive + 4 overlays, runs 10 checks, writes EVIDENCE/B07/<CHECK>/CHECK_RECEIPT.json. Entry: __main__ --chain-file --chain-sha256 --b06-sha256 --evidence --work --run-id --final-zip-sha256 --code-manifest-sha256 --policy-root --policy-reconciliation(-sha256) --r3-archive --overlay |
| 11 | `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1` | 53958 | `B8FC4099F1F6AA87CFA627ACC893247874FE1A3E6CCBF4F5D4C64FC4C2C0485B` | D4, SAFE_STOP, PROCESS_CONTROL | Sealed D4 effectful wrapper: first admission boundary (runs D4_FIRST_ADMISSION_BOOTSTRAP via base64 stdin), RUN_AUTHORITY, launches frozen master orchestrator for D4_ONLY, STOP file SAFE_STOP, child result. Entry: powershell -File -FirstAdmission\|-ResumeAdmittedRun -ExecuteD4 ... (from FULL_RUNNER.d4_command) |
| 12 | `control/B06_RECEIPT_CHECK.py` | 4445 | `CDA4800E36096E3B3B829F941F0AEAC0501200496198E6256BC8CD7879B833CD` | B06 | Read-only conformance check of the independent B06 stage receipt + verdict; outputs B06 receipt/verdict digests. Entry: __main__ --b06-receipt --g5-receipt --code-manifest --instance --verdict --verdict-sha256 (fixed log) |
| 13 | `control/B07_TECHNICAL_PRODUCER.py` | 16834 | `2F9472E58C99B2D4EB67A522436AABF25FF9CAC5CDBE66A9580145C993C49589` | B07 | Builds TICKSTORE_B07_TECHNICAL_RECEIPT_V001 from closed native B07 RETURN ZIP, FINAL ZIP, B06 verdict and physically verified policy; defines CHECKS and TEST_TREE pins. Entry: library build(); called by qual/QUAL_DRIVER.py:478-490 (--mode B07); CHECKS used by B07_CHECK_RUNNERS |
| 14 | `control/B1_DISTRIBUTED_ADMISSION_CONTRACT_V003.json` | 1551 | `88BA16500D3913EAD3EDF11FF6CF80AD9DFD3B6962B2CCE3407D471979BE4FEE` | G5, SUPPORT | B1 distributed admission contract data (G5 qualification input). Entry: data |
| 15 | `control/B1_DISTRIBUTED_CONTRACT_CONSUMER.py` | 4016 | `EF1401825C88ABABB50EC1A13EEE14D4DE4F09B0A0FF4BACAD424C22E84FB7CC` | G5, SUPPORT | B1 distributed contract consumer used by FULL_QUALIFICATION_CONTRACT. Entry: library |
| 16 | `control/B1_DISTRIBUTED_EVIDENCE_ADMISSION.py` | 12563 | `ADAB48B739922609942DCA22DD1825C0E3287B15E557B96083F321B477A984CC` | G5, SUPPORT | B1 distributed evidence admission (CDT16 historical evidence zips). Entry: __main__ evidence_zip b1_bundle_zip full_zip |
| 17 | `control/B1_DISTRIBUTED_PROVENANCE_BRIDGE.py` | 6392 | `93B768F916A1A056AC67F61B0EB625FD45C62770146B51CF5509457B74A06493` | G5, SUPPORT | B1 provenance bridge. Entry: __main__ --evidence --b1 --full --output |
| 18 | `control/B1_FORMAL_ADMISSION.py` | 9186 | `8BA13CA0334FB59BB39F239477A059C4751E6945C897B1574C461503D1DEB442` | G5, SUPPORT | B1 formal admission (G5 qualification contract dependency). Entry: library |
| 19 | `control/D4_FIRST_ADMISSION_BOOTSTRAP.py` | 20048 | `D65B475845403A9235A2BC47FF1797359368AC8BEDB6D1FD686203C1DE16EC81` | D4, ADMISSION_CHAIN | Native D4 first-admission producer: verifies final code set, review pack, G5 V003 completeness, B06 review verdict, B07 technical receipt, policy receipt, fresh predecessor evidence; materializes RUN_AUTHORITY (--admit-first) or validates it (--validate-existing). Entry: __main__ (exec from wrapper stdin) --admit-first\|--validate-existing + 18 required args |
| 20 | `control/D4_FIRST_ADMISSION_PREP.py` | 20068 | `9F611EF8DC50768C81E27A6604D028600653AD2C8E0E8CE72B0F536043B015A1` | D4, SUPPORT | Read-only D4 preparation AND shared primitives used by the whole chain (Reads pinned reader, require/Blocked, sha, canonical, strict_json, validate_journal, library). Entry: __main__ --policy-root ... --observe-native; library |
| 21 | `control/D4_FIRST_ADMISSION_TRANSACTION.py` | 18303 | `CA7443BC1F44604026C9C13D72A02BC10865C3CEA18CE84A09DDDC5B2B78E826` | D4, G5, B06, B07, ADMISSION_CHAIN | D4 gate consumer: verify_final_g5_completeness (V003 + FULL_G5_COMPLETE_PROOF_GATE), validate_gates (B06 REVIEW_CHECKS, B07 10 checks, policy admission receipt), materialize RUN_AUTHORITY/locator receipt. Entry: library (loaded by bootstrap) |
| 22 | `control/D4_IDENTITY_DIAGNOSTIC.py` | 7411 | `EC960B9270CBB3572F621AAA0B71F06CF8030C38245657631A3615229E459D23` | D4 | Read-only D4 identity diagnostic. Entry: __main__ --locator-receipt --adapter-dir (fixed log) |
| 23 | `control/D4_PREDECESSOR_RECONCILIATION.py` | 5622 | `2F96470E336CBDFB88A92C7BF4494DA99C9BCEFF5EA3635805F460515A11FD97` | D4, CRASH_RECOVERY | Reconciles predecessor observation + system observation + roots evidence (consumer only). Entry: __main__ (no args); library for bootstrap |
| 24 | `control/D4_ROOTS_EVIDENCE.py` | 15193 | `048190A53BF432D4F7341D3FA2DAEFC192E680EC189AEBAF4C65BBF1B7A7729F` | D4 | Producer of TICKSTORE_D4_ROOTS_EVIDENCE_V001 (D4_ROOTS_REPORT.json). Entry: __main__ --resume-root --control-root --receipts-root --extra-root --out (fixed log) |
| 25 | `control/FIRST_ADMISSION_BINDING.json` | 1066 | `AC51F240C6FF5AC4F7634F63CC953B04AF7018371D582FEA5697151CE031CA86` | D4 | Sealed first-admission code binding (digests verified equal to current files). Entry: data |
| 26 | `control/FULL_D4_CLOSURE.py` | 12179 | `7413DA09DDB899EEF04AA1C55E764A0A0524968002964C7931128B4DC3EDCA49` | D4, FINAL_VERIFICATION_RECEIPTS | D4Close: read-only D4 checkpoint/cert closure then publishes STAGE_D4 receipt + EXECUTION_CHAIN (broken: GAP-01). Entry: library close_d4 (FULL_RUNNER) |
| 27 | `control/FULL_G3_INTERRUPTION.py` | 7146 | `4578CCD20BEBDE66B36344602873409B83FE8368A19E68E1A5A9DF51737690CE` | CRASH_RECOVERY, DETERMINISTIC_RESUME | G3 attempt record (begin) and reconciliation of a dead G3 attempt as FAIL (requires FULL_READMIT). Entry: library |
| 28 | `control/FULL_G5_COMPLETE_PROOF_GATE.py` | 37333 | `EC6D9B2D9FE3A09318F6E91308ED90C10365CEDFDD4EAA84604676B7BDD49E1D` | G5, ADMISSION_CHAIN | Fail-closed G5-to-FULL validator: V003 completeness, five-part proofs, FINAL zip, origin decision, native campaign, integration manifest. Entry: library validate_g5_complete_proof |
| 29 | `control/FULL_INSTANCE_PREPARE.py` | 8432 | `2ECBCCF02CDD6E5C70B3419CE6FDE05BB8B0B085637EFDB98B0248D87572DD94` | ADMISSION_CHAIN, FULL_PREP | Produces TICKSTORE_FULL_INSTANCE_V001 (prepare) and initial TICKSTORE_EXECUTION_CHAIN_V001 until B06/B07 (chain). Entry: __main__ prepare\|chain (fixed log INSTANCE_PREPARE) |
| 30 | `control/FULL_LIFECYCLE.py` | 21771 | `812AD0B988B83F1DB4777A0708848B6748D32412C3589A210F36DB5049BCA20F` | MULTIWORK, FINAL_VERIFICATION_RECEIPTS, DETERMINISTIC_RESUME, CRASH_RECOVERY | FULL overlay: G3 runs MULTIWORK, G5/G6/G7/H3 overrides, publish_completion (FULL_COMPLETION.json), refresh_admission (FULL_READMIT). Entry: library |
| 31 | `control/FULL_QUALIFICATION_CONTRACT.py` | 29430 | `04223C7DA696827E487146AC21AAEC0E5A8C68F6C12B7D72A42EE471236426A8` | G5, SUPPORT | G5 qualification contract library (control copy). Entry: library |
| 32 | `control/FULL_RELEASE_CHAIN.py` | 11031 | `F687104CD4110951DB5F7A9A19341B36358F526EDBD682759E68F12DC8436164` | ADMISSION_CHAIN | Chain consumer: STAGES order, REQUIRED_CHECKS, validate_chain, ReleaseChain (closed code set, pinned receipts/evidence, G5 proof gate, python identity), validate_full. Entry: library |
| 33 | `control/FULL_RUNNER.py` | 11692 | `1A184116A8B81A2D2AC85B5F0565BB3E3E6C7862F5682E801006AC85A847FE28` | FULL_RUNNER, HEARTBEAT_PROGRESS_ETA, WATCHDOG, SAFE_STOP | Single entry for Check/Monitor/D4/D4Close/D5/CANARY/FULL_PREP/FULL_ADMIT/FULL_READMIT/FULL/Stop. Entry: __main__ --stage --chain-file --chain-sha256 --b06-sha256 [...] (fixed log FULL_RUNNER) |
| 34 | `control/FULL_STAGE_CONTINUATION.py` | 26183 | `DD501C4DF959C1257E972A58C91003F9C23B114FA7CC52EC551BCF5EE9DAB81D` | FULL_RUNNER, D5, CANARY, FULL_PREP, FULL_ADMISSION, SAFE_STOP, HEARTBEAT_PROGRESS_ETA | Bounded post-D4 continuation of the frozen orchestrator node ranges; publishes D5/CANARY/FULL_PREP/FULL_ADMISSION receipts; FULL/FULL_READMIT lifecycle. Entry: __main__ --stage ... (fixed log STAGE_CONTINUATION); library run() |
| 35 | `control/FULL_STAGE_EVIDENCE.py` | 7707 | `5632B85B5417306F53BDC59FA5039E679D1E70A64DD5DFF308983BB0FBD82AA6` | ADMISSION_CHAIN, FINAL_VERIFICATION_RECEIPTS | closed_results, STAGE_CHECK_WITNESSES, checks_from_closed_results, publish (STAGE_<X>.json + EXECUTION_CHAIN.json). Entry: library |
| 36 | `control/G5_C6_FORMAL_CONTRACT.py` | 4855 | `A61DFB642C44C1A1A38016DE250D02BCF1D0D0E4F1059B463CEDB57F2A823EBC` | G5 | G5 C6 formal provenance contract (integration source). Entry: library |
| 37 | `control/G5_C6_FORMAL_STAGE_BUILDER.py` | 5501 | `6589FF68E40502F9CD251D2E0EE2A5D1126642E42D9E9EB89A3146E8B78A3389` | G5 | Builds scoped G5 C6 stage pack/draft (PENDING_ORIGIN_DECISION). Entry: __main__ --inputs-dir --out-dir |
| 38 | `control/G5_EVIDENCE_BUILDER.py` | 18181 | `0D85634D021ACA51F2E629070BD85B4FBBD0AF78B2EDEC87280A8BECB364B14A` | G5 | Scoped G5 evidence builder (ENGINEERING_COMPLETENESS_V002 + draft receipt). Entry: __main__ --known-blockers (fixed log) |
| 39 | `control/G5_FINAL_COMPLETENESS_PRODUCER.py` | 13734 | `34CA561C164512F35E8C0F819FA02C8CFD8598403B468B3224337715B99D3C74` | G5 | Produces ENGINEERING_COMPLETENESS_V003, five-part proofs, G5_EVIDENCE_PACK (COMPLETE_FINAL), G5_STAGE_COMPLETENESS, integration manifest. Entry: __main__ --final-zip --native-return --instance --adversarial --out-dir (no fixed log) |
| 40 | `control/INSTALL_TICKSTORE_FULL.ps1` | 13053 | `BB245FCF2530534BAF7E5CD4984DE791CC522F6B3B8C9D02B3B9BBF061E03C43` | INSTALLER, OFFICIAL_ACTIVATION | Installer: witness/package/manifest verification, installs into %LOCALAPPDATA%\TICKSTORE\Candidates\<pkg sha>, writes DEPLOYMENT.json + MENU_INSTALL_INTENT.json; -ActivateMenu dispatches MENU_OFFICIAL_WRITER official-publish. Entry: powershell -File [-WitnessPath] [-Downloads] [-InstallRoot] [-ActivateMenu -ChainFile -ChainSha256 -B06Sha256] |
| 41 | `control/LEGACY_ENTRY_FENCE.py` | 14635 | `5175F367125EBDF33480FCA2B58CD1F2AEA721692D03F21E3874B721F8880C8A` | D4, SAFE_STOP, CRASH_RECOVERY | Legacy cut of the frozen V004R1 orchestrator on the production control_root (fence dir + DENY ACE on journal + cut record); prerequisite for every admitted STATE commit. Entry: __main__ --state --adapter-dir [--apply] (no fixed log) |
| 42 | `control/MENU_INSTALL_INTENT_VERIFY.py` | 6832 | `5A2A34250E4B29F299D8BED637D91C96381F6D1CD2D5F028DCB5AD32C0DE8577` | OFFICIAL_ACTIVATION | Verifies the inert MENU_INSTALL_INTENT.json of an installed instance. Entry: library |
| 43 | `control/MENU_INTENT_TO_TX_SANDBOX.py` | 4378 | `4D4710871301F12896328A3CC6D8B4D33893C1209CB389F3977602D7CC2E0567` | OFFICIAL_ACTIVATION, TEST_ONLY | Sandbox bridge intent->transaction plan (qualification model). Entry: library |
| 44 | `control/MENU_OFFICIAL_ADMISSION_READONLY.py` | 10446 | `7A04037729FAEFE3555D44EA94D0A62481A5689D10D06595CB34CD726845C778` | OFFICIAL_ACTIVATION | Read-only live admission of real targets (D:\Base CSV MENU.py/BAT pinned SHAs, %LOCALAPPDATA%\TICKSTORE). Entry: __main__ (no args) |
| 45 | `control/MENU_OFFICIAL_WRITER.py` | 38725 | `DD8775DB44E854F084F8240D45FD6DE54DFDD6AFD70C2EEDF49CCC967E8C4319` | OFFICIAL_ACTIVATION | Cross-volume journaled MENU (D:) + ACTIVE_DEPLOYMENT (C:) writer; official mode requires chain until B07 + live admission. Entry: __main__ --mode qualification-*\|official-publish\|official-recover ... (fixed log) |
| 46 | `control/MENU_OFFICIAL_WRITER_CONTRACT_SOURCE_ONLY.py` | 9279 | `4D6607658578F8D2AFD258954E7847DF233A83CB040E9C4FA224C7676A4825F3` | OFFICIAL_ACTIVATION | Recovery decision table for the MENU transaction. Entry: library |
| 47 | `control/MENU_TX_FUSED_SANDBOX.py` | 3066 | `5F2088E28B9B14D46D8A550E9DDA6DF71A8F69D49B4A51B2EDDC845F34C64DD3` | OFFICIAL_ACTIVATION, TEST_ONLY | Fused sandbox transaction model. Entry: library |
| 48 | `control/MENU_TX_INTERPROCESS_SANDBOX.py` | 4700 | `36AE51AE1D425B0FA1DD98B95F5BCBE3AF66A056BDE959AA12AC2D32427D9CD8` | OFFICIAL_ACTIVATION, TEST_ONLY | Interprocess sandbox transaction model (fcntl, POSIX). Entry: library |
| 49 | `control/ORIGIN_DECISION_BINDER.py` | 27385 | `44BB839667A9C179BFFD385E2AD5F1FDA46459A3E63D3C42E90C7B686A9C9955` | G5, B07, ADMISSION_CHAIN | Materializes G5 and B07 stage receipts (copy-only) from origin decisions; FIXTURE_NOT_NATIVE unless native policy reads. Entry: __main__ --stage G5\|B07 ... (fixed log) |
| 50 | `control/POLICY_CAPTURE_BINDING.py` | 8006 | `D1783D6AECBCCBF154253B7DDED8084AE517834CD632421D32775B9A2E614381` | SUPPORT, ADMISSION_CHAIN | verify_capture: physical policy capture (1 master + 1 head) + origin reconciliation; receipt ABI fields. Entry: library (sha-sealed in FIRST_ADMISSION_BINDING) |
| 51 | `control/POLICY_PHYSICAL_VERIFY.py` | 2273 | `B8896DC9F8268E788A8518B0D3B0DFEF7B06D72F98999B181F07A7CA73D45F3F` | SUPPORT, B07, G5 | Shared policy verification (native protected reads) for B07 producer and binder. Entry: library |
| 52 | `control/PRE_B06_ENGINEERING_GATE.py` | 14887 | `92315FC42C1E81FD9DDD0C66C78045E81FFA1B24B6A337006DD2CC0A3D94F48F` | G5 | Pre-B06 eleven-consumer dossier verifier (never a G5/D4 PASS). Entry: library |
| 53 | `control/QUALIFICATION_CONTRACT.json` | 12246 | `FAA2B8A7393EC56F3C3F5753DF8CF13FB58CD3B0EAECA6DDCA7AAD0AF8934394` | G5 | Frozen qualification contract data (test IDs). Entry: data |
| 54 | `control/RC1R1_SUCCESSOR_MIGRATION.py` | 15629 | `89EDF103CEF2292DB74861C970CF7895C7D395E5DE2A7F20D9BD715A7C699253` | D4 | Migrates D4 resume-root SUCCESSOR_PACKAGE V002R22->V002R24 (dry run / --apply with chain until B07). Entry: __main__ --resume-root --successor-zip --review-pack [--apply --chain-file --chain-sha256 --b06-sha256] (fixed log) |
| 55 | `control/RUN_LOG_FIXED.py` | 3065 | `0C95B83C0AC0E5095D090320D64E1500129D76CEF970E365653D163965AEEB0D` | SUPPORT | Owner log rule helper: fixed root C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS\<MODE>_<ts>_<PID>\RUN_LOG.txt. Entry: library run_with_fixed_log |
| 56 | `control/RUN_TICKSTORE_FULL.ps1` | 9800 | `41195E53DAA5460858B5257C71E0964FFC863BF71A4DF496F977B7ED6A891E2A` | FULL_RUNNER, PROCESS_CONTROL | PowerShell launcher of FULL_RUNNER.py: run dir creation, python identity, UAC elevation (visible window), argument forwarding. Entry: powershell -File -Stage ... -ChainFile -ChainSha256 -B06Sha256 [...] |
| 57 | `control/STATE_CAS_RECOVERY.py` | 15616 | `CAEB9F3EDDDA8EF81AAE51382AA0E5B6D33B9F8589E85B38087AB34898D6925C` | CRASH_RECOVERY | Diagnose/apply STATE CAS debris recovery (R1/R2/R3) under the boundary. Entry: __main__ --state --checkpoint --adapter-dir [--apply] (fixed log) |
| 58 | `control/TX_SANDBOX_MODEL.py` | 11437 | `0892CC555B148DF0459F3D000F91C405F783D0969720665011EE3D4D616E6887` | OFFICIAL_ACTIVATION, TEST_ONLY | Transaction sandbox model. Entry: library |
| 59 | `full/CANONICAL_STATE_R8_GATE_B.txt` | 333 | `44C1071A70ACCAD5FC2D35BCC37D99C4351A631F70DD61A60D8D7915626C4C14` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 60 | `full/CHANGELOG_PREP_V001R8_NAMING.md` | 1494 | `75A174EEFEEC3AD7406D89C87FE489EB624AE930DD62DD0B5C9508305713F7FE` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 61 | `full/CHANGELOG_R9_FULL_SERIAL.md` | 7744 | `F4A23B033591C19FB291D4FECF33578E117242C031396CF696AB16178CB08F79` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 62 | `full/FULL_CRASH_RECOVERY.py` | 13998 | `18D79E33B60010C83ECB150A8530D77FAB8221CD9DE36A29AA1C3D240E1279C0` | CRASH_RECOVERY, DETERMINISTIC_RESUME | Multiwork attempt ownership: Attempt (OWNER/CHILD/LOCK/RETIRED/CLOSED receipts), dead-process proof, exact-lock retirement. Entry: library |
| 63 | `full/FULL_MULTIWORK_OWNER_GATE_TEMPLATE_DO_NOT_USE.json` | 429 | `75A64DE256C7B711DBBADD912590BB5E390566EB7A6D26863DB53E0E0DD952A2` | SUPPORT | FULL plan contract / Gate B certificate / DO_NOT_USE owner-gate templates / preaudit summary. Entry: data |
| 64 | `full/FULL_OBSERVABILITY.py` | 3971 | `C486F87244EED977231AE963B3B1430205EEFD6A77AC8AF65391DD24E666768F` | HEARTBEAT_PROGRESS_ETA | Heartbeat (5 s durable JSON), dhms, progress bar, ETA. Entry: library |
| 65 | `full/FULL_OWNER_GATE_R9_TEMPLATE_DO_NOT_USE.json` | 809 | `4E6202E02E37140C1EB7BF7C35F1E04164044223C5820908A4186175266A16A2` | SUPPORT | FULL plan contract / Gate B certificate / DO_NOT_USE owner-gate templates / preaudit summary. Entry: data |
| 66 | `full/FULL_OWNER_GATE_TEMPLATE_DO_NOT_USE.json` | 633 | `E00F904D9E8332FAE39F47B13E8F008ABAF6965712A98C5EB9B5A2C13659BCD2` | SUPPORT | FULL plan contract / Gate B certificate / DO_NOT_USE owner-gate templates / preaudit summary. Entry: data |
| 67 | `full/FULL_PROCESS_CONTROL.py` | 10013 | `DDDA70555E1A6EB468D93CB7F43080959B08AA8D06645CE6EE47B7C5F5FF61AF` | PROCESS_CONTROL, SAFE_STOP | StopEvent (Global\TICKSTORE_FULL_STOP_<run_id>), ProcessJob (kill-on-close Job, memory snapshot). Entry: library |
| 68 | `full/GATE_B_PILOT_MATRIX_V001.md` | 4824 | `C7F463C194D090331604D50833F71DCB68EAFF34491E1B950BF8B2F591192BE5` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 69 | `full/GATE_B_WINDOWS_PILOT_PROTOCOL_V005.md` | 1974 | `0A9406F66902116CEBDB11FC5A7A48C0A0D2BF1438CF6F568556184F8FB273EC` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 70 | `full/MULTIWORK_PREAUDIT_SUMMARY.json` | 2305 | `A72F17FF96EAD04DD3C53CDA08FF4E7F9FFEDD6856B397C430FE9817997EA3C4` | SUPPORT | FULL plan contract / Gate B certificate / DO_NOT_USE owner-gate templates / preaudit summary. Entry: data |
| 71 | `full/OUT_P4A_R3_FULL_HISTORY_COMPAT.zip` | 476335 | `27FF5A0FE47F3DDC5FD63F6371CCF0EDA8124E0E5D504A8F0756A4DF0DB9C3CA` | SUPPORT | P4A ledger archive (pinned EXPECTED_P4A_LEDGER_SHA256) used by tests and plan. Entry: data |
| 72 | `full/README_FIRST.md` | 2983 | `C68981282217D844A68752B9FE7311E6FAF3D06805FF7EADFED2B101914348CE` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 73 | `full/README_MULTIWORK_RC2R2.md` | 1829 | `0A200FD3E6860BC51CCF7B89C2DB3A2F6734FAD449C3544B73A2F0756FBD9E33` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 74 | `full/README_MULTIWORK_RC2R3.md` | 2452 | `5577C9C766A89533B51001EB2188BF6355B40FEEC1FBCB620498775A29A45C05` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 75 | `full/README_MULTIWORK_RC3.md` | 2552 | `9D44DF225AA792B4D2789BDBCB09AC700079842997E9836394F29F43D7111B45` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 76 | `full/README_MULTIWORK_RC4.md` | 1402 | `01AEAD999CB78DB2DD6C18B9680C37660C6D2357F1DA4DE636D4F7DD3F3A1FE1` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 77 | `full/README_MULTIWORK_RC4R2.md` | 895 | `8CBEB7DC202B21E64BE799F2E56FF2CEAEAADE590770EB34388341F269F0E7DD` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 78 | `full/README_R9.md` | 13217 | `D6D8B29B3BAA7E2534C0A96C79119EE7E0B3C47780D780C3D9A2C0F53EE8FC93` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 79 | `full/RUN_WINDOWS_MULTIWORK_PREFLIGHT.ps1` | 6028 | `7A49D1F74D75E964947D45B6D55A8472F9F04F838FD022C50814EFE99919A7F4` | TEST_ONLY | Legacy multiwork preflight launcher. Entry: powershell |
| 80 | `full/SPEC_FULL_MULTIWORK_RC2R2.md` | 3988 | `088E64C0B26CEE4F710CCC2D4E7D62F2CD6B388FADC7A7FA075708E1AA773228` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 81 | `full/SPEC_FULL_MULTIWORK_RC2R3.md` | 4450 | `CD8A499174ECCFD549E4F09A0324C05B1AA60956FD4C07E76CDEC845D5C14D7B` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 82 | `full/SPEC_FULL_MULTIWORK_RC3.md` | 3827 | `8E12E2B880AD94D33C6EAD6C4BBF55C90C96A808D1F49363369F492C13372F6F` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 83 | `full/SPEC_FULL_MULTIWORK_RC4.md` | 1256 | `FD53D6BD5CC22020F95733DAC128096538DE2D47FE30CC1FBE13C395D29BC121` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 84 | `full/SPEC_FULL_MULTIWORK_RC4R2.md` | 1355 | `1DE68A857E7E7A20432BE555CFA72BC54E482AA3CFD64EC305C4B9393783C2DE` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 85 | `full/SPEC_FULL_RUNNER_V001.md` | 12135 | `1609248D358CF65529475D6753181E4C9BBB19369E8852DD8DED1EEFE44FFCAD` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 86 | `full/SPEC_FULL_SERIAL_R9.md` | 12154 | `7CDAD2C9756AA168611C675FBEEBBAA86DF8073DB73BD3D6FAAE613EA67BE9F9` | SUPPORT | Specification/README/changelog for the FULL runner (documentation). Entry: none |
| 87 | `full/TICKSTORE_FULL_PLAN_CONTRACT_V001.json` | 761 | `D07217CDB7BB50DC6EECCC1DF7746F412BD71B1E5968CFB133B5A6E06AA3A4D5` | SUPPORT | FULL plan contract / Gate B certificate / DO_NOT_USE owner-gate templates / preaudit summary. Entry: data |
| 88 | `full/TICKSTORE_GATE_B_R8_FINAL_CERTIFICATE_20260924.json` | 2441 | `7D142D73D740986FA62219DE6CA0C9BD0AF347A9186D58AC1C8DFB35EFB5DFF7` | SUPPORT | FULL plan contract / Gate B certificate / DO_NOT_USE owner-gate templates / preaudit summary. Entry: data |
| 89 | `full/WINDOWS_GATE_B_PREFLIGHT_V005.py` | 11831 | `CDC49F5E6AC1A1A43954D36F900CC8BE82EC8FCD7EF4A903515CC92A462EAE0F` | TEST_ONLY | Historical Gate B Windows preflight. Entry: __main__ |
| 90 | `full/pts2g_reference.py` | 46397 | `74EE141B014DE7A9F9C401C2B3C5AF6BF72E5D7D80F49E67F9D9032338480165` | SUPPORT | Frozen reference codec (pinned sha). Entry: library; __main__ --self-test/--run |
| 91 | `full/run_tickstore_full_multiwork_r9.ps1` | 2313 | `E43509128734B7645681FAE3B71244B13DEAC506EC4A97B10E1EA55AED2D6B5C` | MULTIWORK | Legacy R9 multiwork launcher (compat entry; requires chain). Entry: powershell |
| 92 | `full/static_multiwork_preaudit.py` | 6112 | `B7E5AE15530C301492AE6722EC1CB2C9BA9FD6C3C23FD66D8754EE888622CDFD` | TEST_ONLY | Static multiwork pre-audit. Entry: library |
| 93 | `full/test_enospc_matrix_r4.py` | 7321 | `D9E2B19E8D65ED7B7EC24F8723788E3246E4D8D8EB813ADB553D76F96B92D54E` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 94 | `full/test_filesystem_alias_r3.py` | 8915 | `9C26B10EF2DDCA7FCB904D7641C2EAF7D986B40DC84283E458605FE40BA25F77` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 95 | `full/test_full_multiwork.py` | 27079 | `32E7146FE44292A70A7A68106AEC2D4014707B856F98BDE7D6E9CE813B76955E` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 96 | `full/test_full_serial_r9.py` | 53863 | `E462FC847CC98CFB865259F94454E386955D34A113328E638BB83CE3BA90525B` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 97 | `full/test_gate_b_r8.py` | 5600 | `212D5A1ECADF7A8BE4B78543D1777EAD473D99547460DF43407FF620E774D746` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 98 | `full/test_r3_additional_regressions.py` | 3626 | `1EACE0F673DBA12C510CF32C5FD163682110EB227B74927414CD35E298981B0A` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 99 | `full/test_runner_adversarial_r3.py` | 16921 | `AE839794D13EDE6877AA9CC9155919631CDF9993C70105EDD4226478D73B4FA6` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 100 | `full/test_runner_logic.py` | 1851 | `F33091B257AB4B10738F41DB6574B948C8AF1D4C3D793D6EC3107654F97C4A54` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 101 | `full/test_windows_create_new_mapping_r7.py` | 588 | `061BE4A6C561306E7D763B92CC3FE0A04CDCCA2F4434A6D31205E2AD7151374E` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 102 | `full/tickstore_full_multiwork.py` | 93983 | `2BC33277E7FCDFED9434E9BF6B74157EFB3D3EAF38693B8508E1F6CEB8F273E6` | MULTIWORK, AUTOCPU, SAFE_STOP, WATCHDOG, CHECKPOINT_ATOMIC_COMMIT, DETERMINISTIC_RESUME, HEARTBEAT_PROGRESS_ETA, FINAL_VERIFICATION_RECEIPTS | MULTIWORK engine: choose_workers/AUTOCPU, RAM drain, workers + single publisher, lease, StopEvent, watchdog, normalization, final read-only reconcile, reconciliation record. Entry: library _execute_admitted_multiwork; __main__ compat (requires chain; delegates to FULL_RUNNER --stage FULL) |
| 103 | `full/tickstore_serial_runner.py` | 119021 | `749EEC5DF5C4F396D553AD75C1765D5BDA108391F877CC0C9179D82590429E00` | CHECKPOINT_ATOMIC_COMMIT, FINAL_VERIFICATION_RECEIPTS, SUPPORT | Frozen RC1R1 core: plan/ledger, per-day transactions, writer lock, manifest, reconcile_full_readonly; legacy serial CLI disabled (FULL_SERIAL_EXECUTION_AUTHORIZED_BY_THIS_PACKAGE=False). Entry: library; __main__ legacy (blocked) |
| 104 | `full/windows_multiwork_smoke.py` | 3271 | `3E785027BD98177EBF7E4CF3AAD5CDE58C6BD32502438CD46116CADEF0DF889D` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 105 | `full/windows_multiwork_smoke_22.py` | 4949 | `02328152DCC81242C391FEF5C9666CE45F606B842553016D880E512A10828CE3` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 106 | `full/windows_rc1_recovery_bridge_smoke.py` | 3388 | `45BCBC7A2824129A82783034D4AF894879967A10F974920E32AB4003F7DB08CC` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 107 | `full/windows_rc4_publisher_smoke.py` | 5443 | `F67C4F1DC0759C5AB95380A531D1AC33C262ABD068A225378E5ED7ECAFDF80E0` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 108 | `full/windows_rc4r2_shutdown_smoke.py` | 2600 | `FC650A72C73A34F48937E63B0EBBE353EE82B0D3CCA4E66E23FE4B45A71674B5` | TEST_ONLY | MULTIWORK/serial runner test or Windows smoke. Entry: unittest/script |
| 109 | `g5proof/G5_MULTIWORK_SCENARIOS.py` | 18244 | `E728B8F89E1709B3FAFF54F1784ED44882D84AB07D9581E2A1A7776DC45F1880` | G5, TEST_ONLY | Native multiwork G5 scenarios (sandbox under LOCALAPPDATA). Entry: __main__ |
| 110 | `g5proof/G5_PROOF_RUNNERS.py` | 30718 | `04D32D13ED8858F360F01DAB0243C0BA503F9A93976A58092EAA4B8697BEBF5F` | G5, TEST_ONLY | Typed G5 proof runners (PS51 install/menu, D4 isolated, stage B, safe-stop resume, process-tree crash). Entry: __main__ --proof ... |
| 111 | `g5proof/NATIVE_EXECUTION_OBSERVER.py` | 8825 | `05ADFE055862E5C383DD2E7EA092C275AD809B31CDB16DD9B8F76D86E7C852DC` | G5 | Native execution observer used by pre-B06 V002 campaign. Entry: library |
| 112 | `g5proof/PRE_G06_BOUNDARY_SUITES.py` | 2725 | `772DA6D7BC1481FDD7958D65C45B72BB628056EA94B4C6AFCD3E127C6043C24F` | G5, TEST_ONLY | Boundary suites runner. Entry: __main__ |
| 113 | `g5proof/PRE_G06_CAMPAIGN.py` | 29799 | `347767D17C8526924D87732608CE2D0441E6989275B8E8E3D88E83F6A17FC79A` | G5 | Sealed native Windows campaign producing the NATIVE_RETURN_ZIP (CDT19_PRE_B06_NATIVE_ENGINEERING_V002). Entry: __main__ |
| 114 | `g5proof/PRE_G06_COMPLETENESS.py` | 9679 | `15B10B107DBD29FE497F24A0D5AE100EFAEBD5A183BA6E9905C4AF7D43A72068` | G5 | Post-native closure: lab INSTANCE + ADVERSARIAL attestation, calls G5_FINAL_COMPLETENESS_PRODUCER. Entry: library |
| 115 | `g5proof/PRE_G06_CONSUMERS.py` | 23935 | `B1D71A8E7FF0F9AF6F4E077581FECDE4C8B7E33E35788FC9E358C0A74F630C44` | G5 | Eleven legacy consumer probes. Entry: __main__ |
| 116 | `g5proof/PRE_G06_CONSUMER_REVIEW.json` | 6509 | `FBE8E9961768089ECB8C242A43282ACDD746394728B7D4FBAB222834410B0CDC` | G5 | Consumer review data (source digests verified equal to current files). Entry: data |
| 117 | `g5proof/PRE_G06_LOADER_PROBE.ps1` | 3642 | `A7CD7A75BCAA35FDCFCD9816EFB3186C235C3BC65ADC32B16DF0471D5A88260F` | G5, TEST_ONLY | Loader probe. Entry: powershell |
| 118 | `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | 28537 | `F737CCA26F52F2DA683907B7F2FBCB017C2716D7712F78181BCF81972789E419` | G5, CRASH_RECOVERY, TEST_ONLY | Native scenarios (G3/G6 crash, engineering probe, admission stub authorize_engineering_probe). Entry: library |
| 119 | `g5proof/PRE_G06_PROOF_PROJECTION.py` | 7732 | `A649C6284CA3B771B88A7CAAB6D623F6D8D4C2946E2E7C8451CB531040FA6C9C` | G5 | Projects scoped proofs into G5 target proof receipts. Entry: library |
| 120 | `menu/MENU.py` | 14738 | `D7402CAF7774620B75B201BB845945087C29E88DDE074B0CEBA392E869FCB58C` | MENU | Operator menu (replaces D:\Base CSV\Scripts\Biblioteca\MENU.py on activation); option 10 = TICKSTORE stages via RUN_TICKSTORE_FULL.ps1; imports production-only paths/GERAR_BASE_COMPLETA. Entry: python MENU.py (interactive) |
| 121 | `recovery/99_MANIFEST_SHA256.json` | 7350 | `934723BA1D215907A21218631D1CFBAE6B044B245DCA7150BE9EEDE4A59DBAAA` | D4 | Frozen recovery package manifest (41 entries; verified). Entry: data |
| 122 | `recovery/CODE_MANIFEST.json` | 6332 | `DE46741A211DBEE4318CB0FCA93435B9D8BAD0E0E390597923978482E809D1F5` | D4 | Frozen recovery code manifest (35 entries; verified). Entry: data |
| 123 | `recovery/TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1` | 1454 | `18900BCC198347A5912AA4CEC23F4D9E7A2513FC41EBE393BFD8151F9EEF259A` | D4 | Frozen master orchestrator launcher (legacy route; cut by LEGACY_ENTRY_FENCE; used by wrapper for D4). Entry: powershell (cwd must be C:\Users\silvi) |
| 124 | `recovery/config/STAGE_A_SEALED_VALUES_V001.json` | 11815 | `07DD406B9AD03EE12FAEB7E6CCD46A1C8BB04E14DE1538E7C673704641A87D60` | D4, SUPPORT | Sealed config: control_root, production roots, ledger path. Entry: data |
| 125 | `recovery/docs/D4_S0_CERT_PATH_ASSOCIATION_PROMOTION_CANDIDATE_20260930.md` | 1228 | `1FB738356D3B6E0034B941113D4AE9978D04A113EEC17D4E6D205E8A82AB3D85` | SUPPORT | Documentation (supersession/promotion notes). Entry: none |
| 126 | `recovery/docs/V001R9_B6X_R8_PROVENANCE_SUPERSESSION.md` | 1322 | `08D9B40399F5F1207B0266BA02708AEB96016426F5964EBF9E60256A5BED3C0D` | SUPPORT | Documentation (supersession/promotion notes). Entry: none |
| 127 | `recovery/docs/V002R23_RC1R1_CORE_RECERTIFICATION_SUPERSESSION.md` | 3240 | `28113C51738D76F557A37213ACCF556223E8D5356334621ECEAE23196E77768F` | SUPPORT | Documentation (supersession/promotion notes). Entry: none |
| 128 | `recovery/engine/tickstore_publisher_recovery_v004_candidate.py` | 362990 | `53F72DAE59A2663018A4C0FE6BCBB5B1338F56115826C4265EC74D73ED275FE7` | D4 | Frozen candidate engine (bound by sha in wrapper/bootstrap). Entry: library/bundle __main__ |
| 129 | `recovery/engine/tickstore_publisher_recovery_v004_release.py` | 362989 | `4BB92D88DB728F4BAE3C207C4627F6FDA4D2FAB593E785E7311A90D3CC9F11E7` | D4, D5, CANARY, FULL_PREP, CHECKPOINT_ATOMIC_COMMIT, SAFE_STOP, PROCESS_CONTROL | Frozen release engine: Win32Store, NativeVSS, D4 resumable signed checkpoints, verdict parser, process census. Entry: library (exec by sha) / bundle __main__ |
| 130 | `recovery/history/V002R22/99_MANIFEST_SHA256.json` | 11794 | `5199C7B03A442F0D33C1250E3E2A68A5A213377E012A902336502453CAAA18D6` | SUPPORT | Parent V002R22 package manifest (migration parent). Entry: data |
| 131 | `recovery/loader/INLINE_ROOT_LOADER_V004_R1R1.ps1` | 17526 | `74FE55D8FC43A5C1CEDE22887C60624DC454D3E52E26E1C3AA108072451F1597` | D4, PROCESS_CONTROL | Frozen (non-target) inline root loader. Entry: dot-sourced |
| 132 | `recovery/modules/Launch-TickstoreBundle.ps1` | 989 | `56B7F4FDF1978AB96B23A143907F697C7E89FD6DBCB272CFF9E0C9F4E7D6AB02` | D4, PROCESS_CONTROL | Frozen non-target bundle launcher. Entry: powershell |
| 133 | `recovery/modules/b6_vss_microprobe.py` | 1970 | `7A4F4A6C085EA03E0C8E241A4BAACF0FF7B069F7FF5FD426EB6C2C2FE40C50B5` | D4, SUPPORT | B6-era probe/helper referenced by the frozen orchestrator. Entry: helper |
| 134 | `recovery/modules/b6x_shadow_read_probe.py` | 7486 | `5BBC5B03CC7950DE98A1778C3BF0F7A9D4A526048EB0866A1C992BF269AAB36A` | D4, SUPPORT | B6-era probe/helper referenced by the frozen orchestrator. Entry: helper |
| 135 | `recovery/modules/event_probe.py` | 572 | `9BE3F7449F49356CE3D8A24F36DB1C183DCC3AC56E1402358CC689FB6E98B0CA` | D4, SUPPORT | B6-era probe/helper referenced by the frozen orchestrator. Entry: helper |
| 136 | `recovery/modules/orchestrator.py` | 79666 | `3C16FC13DBB2C1903DBA4D1463E1249C19086743723E72138F9EDF9A83F741A0` | D4, D5, CANARY, FULL_PREP, FULL_ADMISSION, MULTIWORK, FINAL_VERIFICATION_RECEIPTS | Frozen V004R1 orchestrator: State/journal, O class, nodes D1..I1 (D5 canonical cert, D6-E1 canary, E2-E9 prep/stage B, F1-G2 admission, G3-H6 FULL/postfull). Entry: library (exec by sha); __main__ legacy (cut) |
| 137 | `recovery/modules/postfull_verifier.py` | 7445 | `F64558BBEDC88D5AD57A3D02B6A0F70FCE4F967B4829501A09C5B2DFFEEBD6CD` | FINAL_VERIFICATION_RECEIPTS, CANARY | Independent post-FULL verifier (POSTFULL_INDEPENDENT_VERIFIER_V001). Entry: __main__ --ledger --root --output |
| 138 | `recovery/modules/shadow_inventory.ps1` | 1444 | `8A34377377105EA5C9B6933D6E13F07E6EF89A41330B659272EC0DADA6BE1334` | D4, SUPPORT | B6-era probe/helper referenced by the frozen orchestrator. Entry: helper |
| 139 | `recovery/modules/unittest_path_runner.py` | 1369 | `EE80ED1ACCBFB6BF0D82DBF8B952B7B9EAAD8E281468F8EF19EF6423822A2ACF` | TEST_ONLY | Unittest runner helper used by orchestrator. Entry: __main__ |
| 140 | `recovery/review/00_PROMPT_OPUS55_B6_CODE_DELTA_REVIEW_V005R1.md` | 3423 | `7A3DEB0B4E4D5B50CBA7CF8ADCC00E1E98349946F707AEED85EF289045F0D005` | TEST_ONLY | Historical review artifact (B6/D4 delta review, base sources). Entry: none |
| 141 | `recovery/review/B6_CODE_DELTA_REVIEW_V004.txt` | 16362 | `7BC8578888F0E3507C5688386C1FBC6036CC2F8F6B925B21095EAC595C8F7E2A` | TEST_ONLY | Historical review artifact (B6/D4 delta review, base sources). Entry: none |
| 142 | `recovery/review/B6_V005_CORE_ADAPTER_ENGINE_DIFF.patch` | 6242 | `5C336962E60572CF728CA777C2CC9AD05BA2C7F9FDC0922D9C64D0F235120877` | TEST_ONLY | Historical review artifact (B6/D4 delta review, base sources). Entry: none |
| 143 | `recovery/review/CP2_SAFE_STOP_DELTA_REVIEW_V001.txt` | 15753 | `931FB74F59E47CA16490490D2FF7FFA5CEA4560D79EB3F2E84084B890594AA1F` | TEST_ONLY | Historical review artifact (B6/D4 delta review, base sources). Entry: none |
| 144 | `recovery/review/D4_S0_CERT_PATH_ASSOCIATION_ENGINE_DIFF.patch` | 918 | `C8EE0EE05CAC582B9DA82EB29428646AD162CE72F971DF6F179EF2A3BDB40C8E` | TEST_ONLY | Historical review artifact (B6/D4 delta review, base sources). Entry: none |
| 145 | `recovery/review/D4_S0_CERT_PATH_ASSOCIATION_EXTERNAL_REVIEW_V001.md` | 7584 | `A549D624A6F6E9E4CFF0A08FCA84033D2A77145AAFA8856C378B7C7F70A73442` | TEST_ONLY | Historical review artifact (B6/D4 delta review, base sources). Entry: none |
| 146 | `recovery/review/V005_TO_V005R1_ORACLE_PROVENANCE_DIFF.patch` | 2174 | `30F99E24F6C6084AD00BCFEF347212CB5007D6CBE7506EF6C888143C2F798172` | TEST_ONLY | Historical review artifact (B6/D4 delta review, base sources). Entry: none |
| 147 | `recovery/review/base_b6_v004_candidate.py` | 317140 | `9C50EFF63E94CC963EC5E72BD6F56EDB268FC6C912E576BF0F46CAAD235B6A0F` | TEST_ONLY | Historical review artifact (B6/D4 delta review, base sources). Entry: none |
| 148 | `recovery/review/base_b6_v004_release.py` | 317139 | `D4BE49D670D29C7B7B24F4E15EB676959C6EF2B7D683CCD74F3E1C8AAACF5702` | TEST_ONLY | Historical review artifact (B6/D4 delta review, base sources). Entry: none |
| 149 | `recovery/review/base_v005_candidate.py` | 321251 | `61D27E0699CAADEE844A76BC508C1DD21AB339AB9AB451503A209D02DF3F6ADC` | TEST_ONLY | Historical review artifact (B6/D4 delta review, base sources). Entry: none |
| 150 | `recovery/review/base_v005_release.py` | 321250 | `5426F6CE68CCA46C2B65A28B1B8B764AA97C885BC17F80E420158AFFE89C3B9C` | TEST_ONLY | Historical review artifact (B6/D4 delta review, base sources). Entry: none |
| 151 | `recovery/tests/baseline/06_SAFE_STOP_DECISION_TABLE_V004R1R1.csv` | 1092 | `52297F4538F1D1F4F778035CA6DBFB5EED6FF995EFCF02FAD9E3AC25AC6C713F` | TEST_ONLY | Frozen recovery engine tests/baselines. Entry: unittest |
| 152 | `recovery/tests/test_c3_job_topology_microfix.py` | 4105 | `923EFC6A06432275FE8A5613E5CDDD37A003EE6A5FD1ED5D7C0B3894DFD68A30` | TEST_ONLY | Frozen recovery engine tests/baselines. Entry: unittest |
| 153 | `recovery/tests/test_native_rename_v004r2r1.py` | 23493 | `AF744866B3B650CF19FF3BB4498C90EE013D4119388D1B513661B3694ACBB596` | TEST_ONLY | Frozen recovery engine tests/baselines. Entry: unittest |
| 154 | `recovery/tests/test_precanary_completeness_v005.py` | 31661 | `1C1F2CCE5D4A96C85223A88E8A3BB660B86FF23DDB1CF1BA732CF5760D23D9F6` | TEST_ONLY | Frozen recovery engine tests/baselines. Entry: unittest |
| 155 | `recovery/tests/test_publisher_recovery_v004.py` | 19377 | `9DC8DD6D59FF5BA271B49CF761E38DE774F34FC05616B9F1F1BBDDA9213EC25A` | TEST_ONLY | Frozen recovery engine tests/baselines. Entry: unittest |
| 156 | `recovery/tests/test_s0_cert_path_association_microfix.py` | 3030 | `443D8A05EBC188FB973C6BE144697D814819BC1E8800E505ECF546F5AD1102B2` | TEST_ONLY | Frozen recovery engine tests/baselines. Entry: unittest |
| 157 | `recovery/tests_release/baseline/06_SAFE_STOP_DECISION_TABLE_V004R1R1.csv` | 1092 | `52297F4538F1D1F4F778035CA6DBFB5EED6FF995EFCF02FAD9E3AC25AC6C713F` | TEST_ONLY | Frozen recovery engine tests/baselines. Entry: unittest |
| 158 | `recovery/tests_release/test_c3_job_topology_microfix.py` | 4105 | `923EFC6A06432275FE8A5613E5CDDD37A003EE6A5FD1ED5D7C0B3894DFD68A30` | TEST_ONLY | Frozen recovery engine tests/baselines. Entry: unittest |
| 159 | `recovery/tests_release/test_native_rename_v004r2r1.py` | 23493 | `AF744866B3B650CF19FF3BB4498C90EE013D4119388D1B513661B3694ACBB596` | TEST_ONLY | Frozen recovery engine tests/baselines. Entry: unittest |
| 160 | `recovery/tests_release/test_precanary_completeness_v005.py` | 31656 | `22AC18481C246A14D5F72E4915563CE0674E670A5176379BFF1BD59ED51DAF26` | TEST_ONLY | Frozen recovery engine tests/baselines. Entry: unittest |
| 161 | `recovery/tests_release/test_publisher_recovery_v004.py` | 19523 | `26B334901A1C13F73F737508EDFE9CEB5A0F9228D751849DC9A70CEC373F60D8` | TEST_ONLY | Frozen recovery engine tests/baselines. Entry: unittest |
| 162 | `recovery/tests_release/test_s0_cert_path_association_microfix.py` | 3030 | `443D8A05EBC188FB973C6BE144697D814819BC1E8800E505ECF546F5AD1102B2` | TEST_ONLY | Frozen recovery engine tests/baselines. Entry: unittest |
| 163 | `recovery/tests_release/tickstore_publisher_recovery_v004.py` | 362989 | `4BB92D88DB728F4BAE3C207C4627F6FDA4D2FAB593E785E7311A90D3CC9F11E7` | TEST_ONLY | Frozen recovery engine tests/baselines. Entry: unittest |

### 1.3 Imports and reverse dependencies of the operational code

"Imports" means candidate modules imported via AST. "Consumers" means files that import the module or name the file. Both are static, and consumer matches include docstring mentions. The JSON has the full lists for every file, including tests.

| Component | Imports from candidate | Runtime consumers | Test/qual consumers (count) |
|---|---|---|---|
| `SUPPORT/FULL_QUALIFICATION_CONTRACT.py` | `control/B1_DISTRIBUTED_CONTRACT_CONSUMER.py`, `control/B1_FORMAL_ADMISSION.py` | `SUPPORT/G5_C6_B1_FORMAL_CONSUMER.py`, `control/B07_TECHNICAL_PRODUCER.py`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/G5_C6_FORMAL_CONTRACT.py`, `control/G5_C6_FORMAL_STAGE_BUILDER.py`, `control/G5_EVIDENCE_BUILDER.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py`, `control/ORIGIN_DECISION_BINDER.py` | 8 |
| `SUPPORT/G5_C6_B1_FORMAL_CONSUMER.py` | `SUPPORT/FULL_QUALIFICATION_CONTRACT.py`, `control/FULL_QUALIFICATION_CONTRACT.py` | `control/G5_C6_FORMAL_CONTRACT.py` | 1 |
| `adapter/INLINE_ROOT_LOADER_V004_R1R1_ADAPTER.ps1` | - | `adapter/Launch-TickstoreBundle-Adapter.ps1`, `adapter/runtime_locator_orchestrator_entry.py`, `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/D4_FIRST_ADMISSION_TRANSACTION.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/PRE_B06_ENGINEERING_GATE.py` | 2 |
| `adapter/Launch-TickstoreBundle-Adapter.ps1` | - | `adapter/runtime_locator_adapter.py`, `adapter/runtime_locator_orchestrator_entry.py`, `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/D4_FIRST_ADMISSION_TRANSACTION.py` | 2 |
| `adapter/adapter_tests.py` | - | `b07/B07_CHECK_RUNNERS.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py`, `g5proof/PRE_G06_CAMPAIGN.py`, `g5proof/PRE_G06_CONSUMERS.py` | 2 |
| `adapter/runtime_locator_adapter.py` | - | `adapter/runtime_locator_orchestrator_entry.py`, `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/D4_FIRST_ADMISSION_PREP.py`, `control/D4_FIRST_ADMISSION_TRANSACTION.py`, `control/FULL_D4_CLOSURE.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/FULL_INSTANCE_PREPARE.py`, `control/FULL_STAGE_CONTINUATION.py`, `control/PRE_B06_ENGINEERING_GATE.py`, `g5proof/PRE_G06_CONSUMERS.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | 2 |
| `adapter/runtime_locator_inline_entry.py` | - | `adapter/runtime_locator_adapter.py`, `adapter/runtime_locator_orchestrator_entry.py`, `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/D4_FIRST_ADMISSION_TRANSACTION.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/PRE_B06_ENGINEERING_GATE.py`, `g5proof/PRE_G06_CONSUMERS.py` | 3 |
| `adapter/runtime_locator_orchestrator_entry.py` | - | `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/D4_FIRST_ADMISSION_TRANSACTION.py`, `control/D4_IDENTITY_DIAGNOSTIC.py`, `control/FULL_D4_CLOSURE.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/FULL_STAGE_CONTINUATION.py`, `control/LEGACY_ENTRY_FENCE.py`, `control/PRE_B06_ENGINEERING_GATE.py`, `control/STATE_CAS_RECOVERY.py`, `g5proof/PRE_G06_CONSUMERS.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | 7 |
| `b07/B07_CHECK_RUNNERS.py` | `control/B07_TECHNICAL_PRODUCER.py`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/FULL_RELEASE_CHAIN.py`, `qual/R44D2_DROOT_AUDIT.py`, `qual/SANDBOX_ADMISSION.py` | `control/B07_TECHNICAL_PRODUCER.py` | 2 |
| `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1` | - | `b07/B07_CHECK_RUNNERS.py`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/D4_FIRST_ADMISSION_PREP.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/FULL_RUNNER.py`, `control/PRE_B06_ENGINEERING_GATE.py`, `g5proof/PRE_G06_CONSUMERS.py` | 4 |
| `control/B06_RECEIPT_CHECK.py` | `control/FULL_RELEASE_CHAIN.py`, `control/RUN_LOG_FIXED.py` | - | 1 |
| `control/B07_TECHNICAL_PRODUCER.py` | - | `b07/B07_CHECK_RUNNERS.py` | 2 |
| `control/B1_DISTRIBUTED_CONTRACT_CONSUMER.py` | - | `SUPPORT/FULL_QUALIFICATION_CONTRACT.py`, `control/FULL_QUALIFICATION_CONTRACT.py` | 2 |
| `control/B1_DISTRIBUTED_EVIDENCE_ADMISSION.py` | - | `control/B1_DISTRIBUTED_CONTRACT_CONSUMER.py`, `control/B1_DISTRIBUTED_PROVENANCE_BRIDGE.py` | 1 |
| `control/B1_DISTRIBUTED_PROVENANCE_BRIDGE.py` | - | `control/B1_DISTRIBUTED_CONTRACT_CONSUMER.py` | 1 |
| `control/B1_FORMAL_ADMISSION.py` | - | `SUPPORT/FULL_QUALIFICATION_CONTRACT.py`, `control/FULL_QUALIFICATION_CONTRACT.py` | 2 |
| `control/D4_FIRST_ADMISSION_BOOTSTRAP.py` | - | `b07/B07_CHECK_RUNNERS.py`, `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1`, `control/FULL_D4_CLOSURE.py`, `control/FULL_INSTANCE_PREPARE.py`, `control/FULL_STAGE_CONTINUATION.py` | 4 |
| `control/D4_FIRST_ADMISSION_PREP.py` | - | `b07/B07_CHECK_RUNNERS.py`, `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/FULL_D4_CLOSURE.py`, `control/FULL_G3_INTERRUPTION.py`, `control/FULL_INSTANCE_PREPARE.py`, `control/FULL_LIFECYCLE.py`, `control/FULL_RELEASE_CHAIN.py`, `control/FULL_RUNNER.py`, `control/FULL_STAGE_CONTINUATION.py`, `control/FULL_STAGE_EVIDENCE.py`, `control/POLICY_PHYSICAL_VERIFY.py` | 7 |
| `control/D4_FIRST_ADMISSION_TRANSACTION.py` | - | `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/FULL_INSTANCE_PREPARE.py`, `control/FULL_STAGE_CONTINUATION.py`, `control/PRE_B06_ENGINEERING_GATE.py`, `g5proof/PRE_G06_CONSUMERS.py` | 5 |
| `control/D4_IDENTITY_DIAGNOSTIC.py` | `control/RUN_LOG_FIXED.py` | - | 0 |
| `control/D4_PREDECESSOR_RECONCILIATION.py` | - | `control/D4_FIRST_ADMISSION_BOOTSTRAP.py` | 1 |
| `control/D4_ROOTS_EVIDENCE.py` | `control/RUN_LOG_FIXED.py` | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/PRE_B06_ENGINEERING_GATE.py`, `g5proof/PRE_G06_CONSUMERS.py` | 1 |
| `control/FULL_D4_CLOSURE.py` | `adapter/runtime_locator_adapter.py`, `adapter/runtime_locator_orchestrator_entry.py`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/D4_FIRST_ADMISSION_PREP.py`, `control/FULL_STAGE_CONTINUATION.py`, `control/FULL_STAGE_EVIDENCE.py` | `control/FULL_RUNNER.py` | 0 |
| `control/FULL_G3_INTERRUPTION.py` | `control/D4_FIRST_ADMISSION_PREP.py`, `control/FULL_STAGE_CONTINUATION.py`, `full/FULL_CRASH_RECOVERY.py` | `control/FULL_LIFECYCLE.py`, `control/FULL_STAGE_CONTINUATION.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | 1 |
| `control/FULL_G5_COMPLETE_PROOF_GATE.py` | - | `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/D4_FIRST_ADMISSION_TRANSACTION.py`, `control/FULL_RELEASE_CHAIN.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py`, `control/ORIGIN_DECISION_BINDER.py`, `g5proof/PRE_G06_CAMPAIGN.py`, `g5proof/PRE_G06_COMPLETENESS.py` | 10 |
| `control/FULL_INSTANCE_PREPARE.py` | `adapter/runtime_locator_adapter.py`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/D4_FIRST_ADMISSION_PREP.py`, `control/D4_FIRST_ADMISSION_TRANSACTION.py`, `control/FULL_RELEASE_CHAIN.py`, `control/FULL_RUNNER.py`, `control/RUN_LOG_FIXED.py`, `full/tickstore_serial_runner.py` | - | 3 |
| `control/FULL_LIFECYCLE.py` | `control/D4_FIRST_ADMISSION_PREP.py`, `control/FULL_G3_INTERRUPTION.py`, `control/FULL_RELEASE_CHAIN.py`, `control/FULL_STAGE_EVIDENCE.py`, `full/FULL_CRASH_RECOVERY.py`, `full/tickstore_full_multiwork.py` | `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/FULL_STAGE_CONTINUATION.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | 5 |
| `control/FULL_QUALIFICATION_CONTRACT.py` | `control/B1_DISTRIBUTED_CONTRACT_CONSUMER.py`, `control/B1_FORMAL_ADMISSION.py`, `control/G5_C6_FORMAL_CONTRACT.py` | `SUPPORT/G5_C6_B1_FORMAL_CONSUMER.py`, `control/B07_TECHNICAL_PRODUCER.py`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/G5_C6_FORMAL_CONTRACT.py`, `control/G5_C6_FORMAL_STAGE_BUILDER.py`, `control/G5_EVIDENCE_BUILDER.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py`, `control/ORIGIN_DECISION_BINDER.py` | 8 |
| `control/FULL_RELEASE_CHAIN.py` | `control/D4_FIRST_ADMISSION_PREP.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/FULL_STAGE_EVIDENCE.py` | `b07/B07_CHECK_RUNNERS.py`, `control/B06_RECEIPT_CHECK.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/FULL_INSTANCE_PREPARE.py`, `control/FULL_LIFECYCLE.py`, `control/FULL_RUNNER.py`, `control/FULL_STAGE_CONTINUATION.py`, `control/FULL_STAGE_EVIDENCE.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py`, `control/MENU_OFFICIAL_WRITER.py`, `control/ORIGIN_DECISION_BINDER.py`, `control/RC1R1_SUCCESSOR_MIGRATION.py`, `full/tickstore_full_multiwork.py` | 7 |
| `control/FULL_RUNNER.py` | `control/D4_FIRST_ADMISSION_PREP.py`, `control/FULL_D4_CLOSURE.py`, `control/FULL_RELEASE_CHAIN.py`, `control/FULL_STAGE_CONTINUATION.py`, `control/RUN_LOG_FIXED.py`, `full/FULL_OBSERVABILITY.py`, `full/FULL_PROCESS_CONTROL.py` | `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/FULL_INSTANCE_PREPARE.py`, `control/RUN_TICKSTORE_FULL.ps1`, `full/tickstore_full_multiwork.py` | 4 |
| `control/FULL_STAGE_CONTINUATION.py` | `adapter/runtime_locator_adapter.py`, `adapter/runtime_locator_orchestrator_entry.py`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/D4_FIRST_ADMISSION_PREP.py`, `control/D4_FIRST_ADMISSION_TRANSACTION.py`, `control/FULL_G3_INTERRUPTION.py`, `control/FULL_LIFECYCLE.py`, `control/FULL_RELEASE_CHAIN.py`, `control/FULL_STAGE_EVIDENCE.py`, `control/RUN_LOG_FIXED.py`, `full/FULL_OBSERVABILITY.py`, `full/tickstore_full_multiwork.py`, `full/tickstore_serial_runner.py` | `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/FULL_D4_CLOSURE.py`, `control/FULL_G3_INTERRUPTION.py`, `control/FULL_RUNNER.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | 8 |
| `control/FULL_STAGE_EVIDENCE.py` | `control/D4_FIRST_ADMISSION_PREP.py`, `control/FULL_RELEASE_CHAIN.py` | `control/FULL_D4_CLOSURE.py`, `control/FULL_LIFECYCLE.py`, `control/FULL_RELEASE_CHAIN.py`, `control/FULL_STAGE_CONTINUATION.py` | 2 |
| `control/G5_C6_FORMAL_CONTRACT.py` | `SUPPORT/G5_C6_B1_FORMAL_CONSUMER.py` | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/FULL_QUALIFICATION_CONTRACT.py`, `control/G5_C6_FORMAL_STAGE_BUILDER.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py`, `control/ORIGIN_DECISION_BINDER.py` | 4 |
| `control/G5_C6_FORMAL_STAGE_BUILDER.py` | `control/G5_C6_FORMAL_CONTRACT.py` | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/G5_EVIDENCE_BUILDER.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py` | 3 |
| `control/G5_EVIDENCE_BUILDER.py` | `control/G5_C6_FORMAL_STAGE_BUILDER.py`, `control/RUN_LOG_FIXED.py` | - | 4 |
| `control/G5_FINAL_COMPLETENESS_PRODUCER.py` | `control/FULL_G5_COMPLETE_PROOF_GATE.py` | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `g5proof/PRE_G06_CAMPAIGN.py`, `g5proof/PRE_G06_COMPLETENESS.py` | 3 |
| `control/INSTALL_TICKSTORE_FULL.ps1` | - | `g5proof/G5_PROOF_RUNNERS.py` | 3 |
| `control/LEGACY_ENTRY_FENCE.py` | - | `adapter/runtime_locator_orchestrator_entry.py` | 4 |
| `control/MENU_INSTALL_INTENT_VERIFY.py` | - | `control/MENU_INTENT_TO_TX_SANDBOX.py`, `control/MENU_OFFICIAL_WRITER.py` | 4 |
| `control/MENU_INTENT_TO_TX_SANDBOX.py` | `control/MENU_INSTALL_INTENT_VERIFY.py`, `control/TX_SANDBOX_MODEL.py` | `control/MENU_TX_FUSED_SANDBOX.py`, `control/MENU_TX_INTERPROCESS_SANDBOX.py` | 2 |
| `control/MENU_OFFICIAL_ADMISSION_READONLY.py` | - | `control/MENU_OFFICIAL_WRITER.py`, `control/MENU_OFFICIAL_WRITER_CONTRACT_SOURCE_ONLY.py` | 2 |
| `control/MENU_OFFICIAL_WRITER.py` | `control/FULL_RELEASE_CHAIN.py`, `control/MENU_INSTALL_INTENT_VERIFY.py`, `control/MENU_OFFICIAL_ADMISSION_READONLY.py`, `control/MENU_OFFICIAL_WRITER_CONTRACT_SOURCE_ONLY.py`, `control/RUN_LOG_FIXED.py`, `full/tickstore_serial_runner.py` | `control/INSTALL_TICKSTORE_FULL.ps1`, `g5proof/G5_PROOF_RUNNERS.py` | 3 |
| `control/MENU_OFFICIAL_WRITER_CONTRACT_SOURCE_ONLY.py` | `control/MENU_OFFICIAL_ADMISSION_READONLY.py` | `control/MENU_OFFICIAL_WRITER.py` | 1 |
| `control/MENU_TX_FUSED_SANDBOX.py` | `control/MENU_INTENT_TO_TX_SANDBOX.py`, `control/MENU_TX_INTERPROCESS_SANDBOX.py`, `control/TX_SANDBOX_MODEL.py` | - | 2 |
| `control/MENU_TX_INTERPROCESS_SANDBOX.py` | `control/MENU_INTENT_TO_TX_SANDBOX.py`, `control/TX_SANDBOX_MODEL.py` | `control/MENU_TX_FUSED_SANDBOX.py` | 3 |
| `control/ORIGIN_DECISION_BINDER.py` | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/G5_C6_FORMAL_CONTRACT.py`, `control/RUN_LOG_FIXED.py` | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py` | 5 |
| `control/POLICY_CAPTURE_BINDING.py` | - | `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/D4_FIRST_ADMISSION_PREP.py`, `control/FULL_INSTANCE_PREPARE.py`, `control/FULL_STAGE_CONTINUATION.py` | 3 |
| `control/POLICY_PHYSICAL_VERIFY.py` | - | `control/B07_TECHNICAL_PRODUCER.py`, `control/ORIGIN_DECISION_BINDER.py` | 0 |
| `control/PRE_B06_ENGINEERING_GATE.py` | - | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py`, `g5proof/PRE_G06_CAMPAIGN.py`, `g5proof/PRE_G06_CONSUMERS.py` | 2 |
| `control/RC1R1_SUCCESSOR_MIGRATION.py` | `control/FULL_RELEASE_CHAIN.py`, `control/RUN_LOG_FIXED.py` | - | 2 |
| `control/RUN_LOG_FIXED.py` | - | `control/B06_RECEIPT_CHECK.py`, `control/D4_IDENTITY_DIAGNOSTIC.py`, `control/D4_ROOTS_EVIDENCE.py`, `control/FULL_INSTANCE_PREPARE.py`, `control/FULL_RUNNER.py`, `control/FULL_STAGE_CONTINUATION.py`, `control/G5_EVIDENCE_BUILDER.py`, `control/MENU_OFFICIAL_WRITER.py`, `control/ORIGIN_DECISION_BINDER.py`, `control/RC1R1_SUCCESSOR_MIGRATION.py`, `control/STATE_CAS_RECOVERY.py`, `full/tickstore_full_multiwork.py` | 0 |
| `control/RUN_TICKSTORE_FULL.ps1` | - | `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1`, `control/FULL_STAGE_CONTINUATION.py`, `control/INSTALL_TICKSTORE_FULL.ps1`, `control/MENU_INSTALL_INTENT_VERIFY.py`, `control/RUN_LOG_FIXED.py`, `menu/MENU.py` | 4 |
| `control/STATE_CAS_RECOVERY.py` | `control/RUN_LOG_FIXED.py` | `control/D4_IDENTITY_DIAGNOSTIC.py` | 1 |
| `control/TX_SANDBOX_MODEL.py` | - | `control/MENU_INTENT_TO_TX_SANDBOX.py`, `control/MENU_TX_FUSED_SANDBOX.py`, `control/MENU_TX_INTERPROCESS_SANDBOX.py` | 3 |
| `full/FULL_CRASH_RECOVERY.py` | `full/tickstore_serial_runner.py` | `control/FULL_G3_INTERRUPTION.py`, `control/FULL_LIFECYCLE.py`, `full/tickstore_full_multiwork.py`, `g5proof/PRE_G06_CAMPAIGN.py`, `g5proof/PRE_G06_COMPLETENESS.py`, `g5proof/PRE_G06_CONSUMERS.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py`, `g5proof/PRE_G06_PROOF_PROJECTION.py` | 8 |
| `full/FULL_OBSERVABILITY.py` | - | `control/FULL_RUNNER.py`, `control/FULL_STAGE_CONTINUATION.py`, `full/tickstore_full_multiwork.py` | 1 |
| `full/FULL_PROCESS_CONTROL.py` | - | `control/FULL_RUNNER.py`, `full/static_multiwork_preaudit.py`, `full/tickstore_full_multiwork.py`, `g5proof/G5_PROOF_RUNNERS.py`, `g5proof/PRE_G06_CAMPAIGN.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | 1 |
| `full/pts2g_reference.py` | - | `full/tickstore_full_multiwork.py`, `full/tickstore_serial_runner.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | 0 |
| `full/run_tickstore_full_multiwork_r9.ps1` | - | `full/static_multiwork_preaudit.py` | 0 |
| `full/tickstore_full_multiwork.py` | `control/FULL_RELEASE_CHAIN.py`, `control/FULL_RUNNER.py`, `control/RUN_LOG_FIXED.py`, `full/FULL_CRASH_RECOVERY.py`, `full/FULL_OBSERVABILITY.py`, `full/FULL_PROCESS_CONTROL.py`, `full/pts2g_reference.py`, `full/tickstore_serial_runner.py` | `control/FULL_LIFECYCLE.py`, `control/FULL_RELEASE_CHAIN.py`, `control/FULL_STAGE_CONTINUATION.py`, `full/RUN_WINDOWS_MULTIWORK_PREFLIGHT.ps1`, `full/run_tickstore_full_multiwork_r9.ps1`, `full/static_multiwork_preaudit.py`, `full/windows_multiwork_smoke.py`, `full/windows_multiwork_smoke_22.py`, `full/windows_rc1_recovery_bridge_smoke.py`, `full/windows_rc4_publisher_smoke.py`, `full/windows_rc4r2_shutdown_smoke.py`, `g5proof/G5_MULTIWORK_SCENARIOS.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | 6 |
| `full/tickstore_serial_runner.py` | `full/pts2g_reference.py` | `control/FULL_INSTANCE_PREPARE.py`, `control/FULL_RELEASE_CHAIN.py`, `control/FULL_STAGE_CONTINUATION.py`, `control/MENU_OFFICIAL_WRITER.py`, `full/FULL_CRASH_RECOVERY.py`, `full/RUN_WINDOWS_MULTIWORK_PREFLIGHT.ps1`, `full/WINDOWS_GATE_B_PREFLIGHT_V005.py`, `full/static_multiwork_preaudit.py`, `full/tickstore_full_multiwork.py`, `full/windows_multiwork_smoke.py`, `full/windows_multiwork_smoke_22.py`, `full/windows_rc1_recovery_bridge_smoke.py`, `full/windows_rc4_publisher_smoke.py`, `g5proof/G5_MULTIWORK_SCENARIOS.py`, `g5proof/PRE_G06_CAMPAIGN.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | 17 |
| `g5proof/G5_MULTIWORK_SCENARIOS.py` | `full/test_full_serial_r9.py`, `full/tickstore_full_multiwork.py`, `full/tickstore_serial_runner.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | `g5proof/G5_PROOF_RUNNERS.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | 4 |
| `g5proof/G5_PROOF_RUNNERS.py` | `full/FULL_PROCESS_CONTROL.py`, `g5proof/G5_MULTIWORK_SCENARIOS.py` | `SUPPORT/FULL_QUALIFICATION_CONTRACT.py`, `control/FULL_QUALIFICATION_CONTRACT.py`, `g5proof/G5_MULTIWORK_SCENARIOS.py`, `g5proof/PRE_G06_CAMPAIGN.py` | 3 |
| `g5proof/NATIVE_EXECUTION_OBSERVER.py` | - | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py` | 0 |
| `g5proof/PRE_G06_BOUNDARY_SUITES.py` | - | `g5proof/G5_PROOF_RUNNERS.py` | 0 |
| `g5proof/PRE_G06_CAMPAIGN.py` | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py`, `control/PRE_B06_ENGINEERING_GATE.py`, `full/FULL_CRASH_RECOVERY.py`, `full/FULL_PROCESS_CONTROL.py`, `g5proof/G5_PROOF_RUNNERS.py`, `g5proof/PRE_G06_CONSUMERS.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py`, `g5proof/PRE_G06_PROOF_PROJECTION.py` | - | 6 |
| `g5proof/PRE_G06_COMPLETENESS.py` | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py`, `full/FULL_CRASH_RECOVERY.py` | - | 2 |
| `g5proof/PRE_G06_CONSUMERS.py` | `adapter/adapter_tests.py`, `control/PRE_B06_ENGINEERING_GATE.py`, `full/FULL_CRASH_RECOVERY.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | `g5proof/PRE_G06_CAMPAIGN.py` | 1 |
| `g5proof/PRE_G06_LOADER_PROBE.ps1` | - | `g5proof/PRE_G06_CONSUMERS.py` | 0 |
| `g5proof/PRE_G06_NATIVE_SCENARIOS.py` | `adapter/runtime_locator_adapter.py`, `adapter/runtime_locator_orchestrator_entry.py`, `control/FULL_G3_INTERRUPTION.py`, `control/FULL_LIFECYCLE.py`, `control/FULL_STAGE_CONTINUATION.py`, `full/FULL_CRASH_RECOVERY.py`, `full/FULL_PROCESS_CONTROL.py`, `full/tickstore_full_multiwork.py`, `g5proof/G5_MULTIWORK_SCENARIOS.py` | `g5proof/G5_MULTIWORK_SCENARIOS.py`, `g5proof/PRE_G06_CAMPAIGN.py`, `g5proof/PRE_G06_CONSUMERS.py` | 2 |
| `g5proof/PRE_G06_PROOF_PROJECTION.py` | `full/FULL_CRASH_RECOVERY.py` | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `g5proof/PRE_G06_CAMPAIGN.py` | 2 |
| `menu/MENU.py` | - | `control/INSTALL_TICKSTORE_FULL.ps1`, `control/MENU_INSTALL_INTENT_VERIFY.py`, `control/MENU_OFFICIAL_ADMISSION_READONLY.py`, `control/MENU_OFFICIAL_WRITER.py`, `control/TX_SANDBOX_MODEL.py`, `g5proof/G5_PROOF_RUNNERS.py` | 7 |
| `recovery/TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1` | - | `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/LEGACY_ENTRY_FENCE.py` | 1 |
| `recovery/engine/tickstore_publisher_recovery_v004_candidate.py` | - | `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/PRE_B06_ENGINEERING_GATE.py`, `g5proof/PRE_G06_CONSUMERS.py`, `recovery/modules/orchestrator.py` | 3 |
| `recovery/engine/tickstore_publisher_recovery_v004_release.py` | - | `adapter/runtime_locator_orchestrator_entry.py`, `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/D4_FIRST_ADMISSION_PREP.py`, `control/D4_IDENTITY_DIAGNOSTIC.py`, `control/D4_ROOTS_EVIDENCE.py`, `control/FULL_D4_CLOSURE.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/FULL_RELEASE_CHAIN.py`, `control/FULL_STAGE_CONTINUATION.py`, `control/POLICY_CAPTURE_BINDING.py`, `control/PRE_B06_ENGINEERING_GATE.py`, `control/RC1R1_SUCCESSOR_MIGRATION.py`, `recovery/modules/b6_vss_microprobe.py`, `recovery/modules/b6x_shadow_read_probe.py`, `recovery/modules/orchestrator.py` | 3 |
| `recovery/loader/INLINE_ROOT_LOADER_V004_R1R1.ps1` | - | `adapter/runtime_locator_adapter.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/PRE_B06_ENGINEERING_GATE.py`, `recovery/modules/Launch-TickstoreBundle.ps1` | 1 |
| `recovery/modules/Launch-TickstoreBundle.ps1` | - | `adapter/runtime_locator_adapter.py`, `recovery/modules/orchestrator.py` | 1 |
| `recovery/modules/b6_vss_microprobe.py` | - | - | 0 |
| `recovery/modules/b6x_shadow_read_probe.py` | - | `recovery/modules/orchestrator.py` | 0 |
| `recovery/modules/event_probe.py` | - | `recovery/modules/orchestrator.py` | 0 |
| `recovery/modules/orchestrator.py` | - | `adapter/runtime_locator_orchestrator_entry.py`, `control/60_EFFECTFUL_WRAPPER_RELEASE.ps1`, `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/D4_FIRST_ADMISSION_PREP.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/FULL_STAGE_CONTINUATION.py`, `control/LEGACY_ENTRY_FENCE.py`, `control/PRE_B06_ENGINEERING_GATE.py`, `g5proof/PRE_G06_CONSUMERS.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py`, `recovery/TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1` | 5 |
| `recovery/modules/postfull_verifier.py` | - | `recovery/modules/orchestrator.py` | 2 |
| `recovery/modules/shadow_inventory.ps1` | - | `recovery/modules/orchestrator.py` | 0 |

## 2. Execution paths

### 2a. Installer -> official activation -> menu

**Connected end to end:** PARTIAL

1. Operator: powershell -File <...>\control\INSTALL_TICKSTORE_FULL.ps1 [-WitnessPath] (from PS C:\Users\silvi>). Log: C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS\INSTALL_<ts>_<PID>\RUN_LOG.txt (:15,:65-70). Requires PS 5.1 (:71).
2. Without -ActivateMenu chain arguments are rejected (:79-81). Witness WITNESS_TICKSTORE_FULL_FINAL_*.json found in -Downloads (default C:\Users\silvi\OneDrive\Downloads, :4,:83-84), schema TICKSTORE_FINAL_PACKAGE_WITNESS_V001 (:87). Witness producer in package: g5proof/G5_PROOF_RUNNERS.py:266 (qualification); operational witness producer is external (packaging step).
3. Package ZIP sha == witness (:92), member safety (:96-102), PACKAGE_MANIFEST.json sha/schema/cardinality (:103-118), pinned python sha 4942B86A... (:119-121), CRC via python -I -S -B (:122-123), MENU.py must be in manifest (:125-127).
4. Install to %LOCALAPPDATA%\TICKSTORE\Candidates\<package_sha256> (create-new, readback each member :135-147); writes DEPLOYMENT.json (TICKSTORE_DEPLOYMENT_V001, status INSTALLED_NOT_PRODUCTION_ADMISSION, launcher_sha256 of RUN_TICKSTORE_FULL.ps1, :151-155) and MENU_INSTALL_INTENT.json (TICKSTORE_MENU_INSTALL_INTENT_V001, :162-179).
5. -ActivateMenu (requires -ChainFile/-ChainSha256/-B06Sha256 and the official install root, :76-78): runs installed MENU_OFFICIAL_WRITER.py --mode official-publish with pinned python (:186-191).
6. MENU_OFFICIAL_WRITER.main (:736-786): official_admission (:713-733) requires Windows, installed_root == code_root.parent.parent, ReleaseChain(..., until='B07') (:725) and MENU_OFFICIAL_ADMISSION_READONLY.run_readonly (live targets D:\Base CSV\Scripts\Biblioteca\MENU.py sha 7080DCB0..., BAT sha 9C2CAB19..., :19-24). publish (:510-594): verify_inert_intent, ExclusiveLock MENU_WRITER.lock, PREPARED staging -> MENU_TRANSACTION, ReplaceFileW MENU with backup on D:, ACTIVE_DEPLOYMENT.json on C: (%LOCALAPPDATA%\TICKSTORE), journal COMMITTED. Log: fixed RUN_LOG_FIXED mode MENU_OFFICIAL_WRITER (:790-791).
7. MENU (published at D:\Base CSV\Scripts\Biblioteca\MENU.py) imports production-only paths and GERAR_BASE_COMPLETA (:35-47; not in package). Option 10 -> rodar_tickstore_full (:188-228): reads %LOCALAPPDATA%\TICKSTORE\ACTIVE_DEPLOYMENT.json + MENU_TRANSACTION PLAN/JOURNAL (COMMITTED, digests, :113-180), checks installation root and launcher sha (:193-200), prompts stage/chain/sha/B06 sha/policy reconciliation, runs powershell -File <install>\...\RUN_TICKSTORE_FULL.ps1 (:210-225).
8. Connected end to end in code, but activation requires a technical chain through B07, which no V004 receipt exists for; MENU depends on production modules outside the package.

### 2b. Menu -> FULL runner -> admission chain

**Connected end to end:** NO (breaks at D4: GAP-01, GAP-02; GAP-03..06 behind it)

**Gate order enforced by `FULL_RELEASE_CHAIN.STAGES` (line 17):** G5 -> B06 -> B07 -> D4 -> D5 -> CANARY -> FULL_PREP -> FULL_ADMISSION.

1. RUN_TICKSTORE_FULL.ps1 (:3 stages Check/Monitor/D4/D4Close/D5/CANARY/FULL_PREP/FULL_ADMIT/FULL_READMIT/FULL/Stop): new run dir under the fixed root (:101-109,125), python identity (:130), UAC re-launch in a visible window for all stages except Check/Monitor/D4Close (:133-150), then python -I -X utf8 -B FULL_RUNNER.py --stage ... --log-file <RUN_LOG.txt> (:152-159).
2. FULL_RUNNER.run (:159-203): Monitor -> monitor(); D5/CANARY/FULL_PREP/FULL_ADMIT/FULL/FULL_READMIT -> FULL_STAGE_CONTINUATION.run (:163-165); Check/D4/D4Close/Stop -> ReleaseChain(until=REQUIRED_PREFIX[stage]) (:15-16,:176).
3. ReleaseChain (FULL_RELEASE_CHAIN.py:103-158): descriptor TICKSTORE_EXECUTION_CHAIN_V001 (environment WINDOWS_PRODUCTION) read with the separately supplied digest; instance TICKSTORE_FULL_INSTANCE_V001; code manifest TICKSTORE_FINAL_RUNTIME_CODE_MANIFEST_V001 with every member read and the CLOSED physical file set of candidate/ (:119-132); receipts exactly STAGES[:until] (:135-140); validate_chain (:41-89) in order G5 -> B06 -> B07 -> D4 -> D5 -> CANARY -> FULL_PREP -> FULL_ADMISSION, each TICKSTORE_STAGE_RECEIPT_V001 PASS, environment, code/instance binding, predecessor hash chain, blockers [], REQUIRED_CHECKS, evidence; B06 digest == operator-supplied B06 sha; D5..FULL_ADMISSION need check_proofs bound to STAGE_CHECK_WITNESSES; all evidence re-read (:145-147); FULL_G5_COMPLETE_PROOF_GATE (:151-152); pinned python == instance python_sha256 (:153-154). Any missing/mismatching receipt raises Blocked -> FULL_RUNNER_BLOCKED=..., exit 2 (fail-closed).
4. Producers: G5 stage receipt = ORIGIN_DECISION_BINDER --stage G5 (origin decision); B06 = independent reviewer (template), checked by B06_RECEIPT_CHECK; chain until B06/B07 = FULL_INSTANCE_PREPARE.py chain (:85-111, until only B06|B07); B07 technical = B07_CHECK_RUNNERS + B07_TECHNICAL_PRODUCER (via qual/QUAL_DRIVER.py), B07 stage = ORIGIN_DECISION_BINDER --stage B07; D4 = FULL_D4_CLOSURE (BROKEN, GAP-01); D5/CANARY/FULL_PREP/FULL_ADMISSION = FULL_STAGE_CONTINUATION.publish_stage -> FULL_STAGE_EVIDENCE.publish (each writes STAGE_<X>.json + next EXECUTION_CHAIN.json, prints NEXT_CHAIN_FILE/NEXT_CHAIN_SHA256, :135-146).
5. D4: FULL_RUNNER.d4_command (:25-44) -> powershell 60_EFFECTFUL_WRAPPER_RELEASE.ps1 -FirstAdmission|-ResumeAdmittedRun -ExecuteD4 [-ResumeAfterSafeStop] with the 12 instance d4_parameters and -OriginReconciliationSha256; parent ignores SIGINT while the wrapper runs (:47-65). Wrapper Invoke-FirstAdmissionBoundary (:274-321) requires G5StageReceiptPath/G5InstancePath (GAP-02) and runs D4_FIRST_ADMISSION_BOOTSTRAP (sealed sha) which validates G5 V003 + B06 review verdict + B07 technical + policy admission receipt (D4_FIRST_ADMISSION_TRANSACTION.validate_gates :77-107), predecessor freshness (GAP-05), package ZIP sha CAC345D3 (GAP-04), legacy fence, then materializes RUN_AUTHORITY; wrapper launches the frozen master orchestrator (D4_ONLY). On exit 0 FULL_RUNNER calls close_d4 (:193-195) -> GAP-01.
6. D5..FULL_ADMIT: FULL_STAGE_CONTINUATION.run (:259-407) requires Windows+admin and TICKSTORE_D4_RESUME_ENABLE != 1 (:265-266), ReleaseChain until PREVIOUS[stage] (:274-275), current policy reconciliation (:280-282), sealed config/STATE path (:283-289), predecessor STATE == previous receipt state_after_sha256 (:290-292), journal closure (:293-302), adapter binding/locator from the D4 receipt (:303-308), frozen engine/orchestrator by sha (:309-316), adapter installation (:317-326), Stage B inbox for FULL_ADMIT/FULL (:327-334). Missing receipt -> CONTINUATION_BLOCKED (fail-closed).

### 2c. FULL execution

**Connected end to end:** Code-connected from FULL_ADMISSION onward (all called functions exist); unreachable while GAP-01/02 stand; no native evidence

1. FULL: FULL_STAGE_CONTINUATION.run stage FULL requires FULL_ADMISSION.state_after_sha256 == current STATE and receipt age <= 300 s (:378-384), full_admission_facts re-check (:387, :233-256), FULL_LIFECYCLE.install (:388; FULL_LIFECYCLE.py:206-288) then execute_nodes G3..H6 (:389; :122-168).
2. MULTIWORK/AUTOCPU: node G3 -> tickstore_full_multiwork._execute_admitted_multiwork (FULL_LIFECYCLE.py:226-230; multiwork :1355+). choose_workers (:234-260): AUTO = min(months, instance max_workers<=32, logical CPUs-2 (affinity-aware :185-197), RAM budget (target% of total vs 85% available minus 2 GiB, 1.25 GiB/worker)); explicit integer validated against the same budgets. admission.validate_full (:1366; FULL_RELEASE_CHAIN.py:160-187). RAM governor memory_decision LAUNCH/DRAIN/SAFE_STOP (:57-64, :1505-1530).
3. Checkpoints/atomic commits: per-day canonical publication by a single publisher process after month SHA verification (:991+, _publish_ready_day :823-845 using frozen core transactions); destination writer lock (core.acquire_lock :1553) + native lease mutex Global\TICKSTORE_FULL_<hash> (:98-134,:1537); COORDINATOR_STATE.json written atomically (tmp + fsync + replace + readback, :856-877) but never read back for resume; STATE commits through the CAS guard (runtime_locator_orchestrator_entry.guard_frozen_state_reads :955) with node RESULT/RECEIPT published before STATE advance (FULL_STAGE_CONTINUATION.py:152-157).
4. SAFE_STOP: FULL_RUNNER -Stage Stop opens Global\TICKSTORE_FULL_STOP_<run_id> (FULL_RUNNER.py:197-202; FULL_PROCESS_CONTROL.py:8-38); Ctrl+C in the elevated window; multiwork polls native_stop/watchdog (:1597-1601; also :1565,:1821) -> bounded process-tree shutdown (:1841-1846, _bounded_shutdown_process_tree :1127) -> CooperativeSafeStop only if cooperative (:1907-1908) -> FULL_LIFECYCLE converts to SafeStopFlow (:231-235) -> node finished SAFE_STOP, exit 130 (FULL_STAGE_CONTINUATION.py:158-161). D4 SAFE_STOP is owned by the wrapper (60_EFFECTFUL_WRAPPER_RELEASE.ps1:471-478 -RequestSafeStop writes STOP.request; Ctrl+C handled by the wrapper while FULL_RUNNER ignores SIGINT, FULL_RUNNER.py:47-65).
5. Crash recovery: FULL_CRASH_RECOVERY.Attempt (:169-262) records OWNER/CHILD/LOCK, retires only the exact dead owner lock, CLOSED on exit; FULL_G3_INTERRUPTION.reconcile (:53-128) closes a dead G3 attempt as FAIL and requires FULL_READMIT (FULL_STAGE_CONTINUATION.py:340-347); STATE_CAS_RECOVERY.py for CAS debris.
6. Deterministic resume without duplication: any FULL relaunch needs a fresh FULL_ADMISSION (FULL_READMIT -> FULL_LIFECYCLE.refresh_admission :323-366); G5 requires re-entry of G3 after SAFE_STOP (FULL_LIFECYCLE.py:239-241); multiwork pre-normalizes interrupted canonical transactions (:1555-1560) and classifies each day as existing (container+commit, validated and REUSED) or to build (:942-958); transient state after normalization blocks. Duplicate-tick control is a CANARY check (D9).
7. Watchdog/heartbeat/progress/ETA: MainLoopWatchdog 600 s -> cooperative stop (:200-231,:1583,:1599-1601); productivity stall 180 s -> MultiworkBlocked (:1605-1607); Heartbeat every 5 s to scratch\RUN_INSTANCES\<run_id>\HEARTBEAT_<uuid>.json and runs\<id>\STAGE_HEARTBEAT.json (FULL_OBSERVABILITY.py:23-86; multiwork :1547-1551; continuation :351-357) with percent, ETA (PIPELINE phase only), dhms; FULL_RUNNER Monitor (read-only, :105-156) prints bar/PCT/ETA and HEARTBEAT_STALE/MAIN_LOOP_STALL verdicts.
8. Final verification and physical receipts: core.reconcile_full_readonly (:1818-1820) -> TICKSTORE_MULTIWORK_RECONCILIATION_V001 (:1823-1833) written immutably as MULTIWORK_RECONCILIATION.json (FULL_LIFECYCLE.py:218-223); G6 same-instance check (:242-267); H2 postverify + independent verifier (recovery/modules/postfull_verifier.py) compared in H3 (:274-285, verify_postfull :17-44); H6 FINAL_EVIDENCE pack; FULL_LIFECYCLE.publish_completion -> FULL_COMPLETION.json TICKSTORE_FULL_COMPLETION_V001 (:291-320).

### 2d. Is each path connected? Missing links

| Path | Verdict | Exact missing link |
|---|---|---|
| Installer -> activation -> menu | Code connected | Activation needs a chain through B07 (`MENU_OFFICIAL_WRITER.py:725`), and no V004 G5/B06/B07 receipt exists. MENU imports production-only `paths` and `GERAR_BASE_COMPLETA` (`MENU.py:35-47`). The operational witness producer is outside the package. |
| Menu -> runner -> G5/B06/B07 | Code connected | Producers: G5 and B07 stage receipts come from the origin decision + `ORIGIN_DECISION_BINDER`; B06 comes from an independent reviewer. B07 needs external launchers and inputs (GAP-10). |
| Runner -> D4 | **Broken** | GAP-02 (G5StageReceiptPath/G5InstancePath never passed), GAP-03 (adapted launcher hash), GAP-04 (successor ZIP hash), GAP-05 (no predecessor observer), GAP-06 (no policy admission receipt producer). |
| D4 -> D4 receipt | **Broken** | GAP-01: `FULL_D4_CLOSURE.py:158-167` -> `FULL_STAGE_EVIDENCE.publish` without `check_proofs`. |
| D5 -> CANARY -> FULL_PREP -> FULL_ADMISSION -> FULL | Code connected (all called symbols exist; AST cross-check found no missing module attribute) | Unreachable without a D4 receipt. External inputs: Stage B review / FULL_GO in `inbox`, origin policy reconciliation. |
| FULL completion | Code connected | Terminal receipt `FULL_COMPLETION.json`; nothing in the package consumes it. |

## 3. Gates

| Gate | Producer | Consumer | Receipt / schema | Native Windows | Independent auditor | Production data touched | Status / notes |
|---|---|---|---|---|---|---|---|
| G4 (pre-chain) | Native QUAL campaign: qual/QUAL_DRIVER.py launched by RUN_TICKSTORE_CDT15_<REV>_QUAL.ps1 (launcher NOT in package) | ORIGIN_DECISION_BINDER (NATIVE_RETURN_ZIP role), G5_EVIDENCE_BUILDER | closed RETURN ZIP + TICKSTORE_CDT15_WINDOWS_QUALIFICATION_RECEIPT_V003 (no stage receipt) | True | False | No (sandbox; real targets snapshotted read-only) |  |
| G5 | Origin decision (OWNER_RELEASE_AUTHORITY, TEMPLATE_ORIGIN_STAGE_DECISION.json) materialized by control/ORIGIN_DECISION_BINDER.py --stage G5 (:327-388); evidence from control/G5_FINAL_COMPLETENESS_PRODUCER.py (V003) + native campaign g5proof/PRE_G06_CAMPAIGN.py/qual/CDT21_F01R1_G0_QUALIFICATION.py | FULL_RELEASE_CHAIN.validate_chain (:60-64) + FULL_G5_COMPLETE_PROOF_GATE.validate_g5_complete_proof (:55-232) via ReleaseChain (:151-152); D4_FIRST_ADMISSION_TRANSACTION.verify_final_g5_completeness (:47-75) | TICKSTORE_STAGE_RECEIPT_V001 stage=G5, environment WINDOWS_PRODUCTION, full_candidate_completeness=PASS, evidence roles ENGINEERING_COMPLETENESS(V003), G5_STAGE_COMPLETENESS, G5_EVIDENCE_PACK, ORIGIN_DECISION, G5_INTEGRATION_MANIFEST, G5_INTEGRATION_SOURCE, NATIVE_RETURN_ZIP, FINAL_PACKAGE_ZIP; checks features_implemented, blockers_closed, tested_equals_packaged, adversarial_completeness, byte_freeze | True | No (origin/owner decision; owner_is_independent_b06_auditor must be false) | No | NOT ISSUED for V004 (CDT21_V004_ENGINEERING_COMPLETENESS.json producer_five_part_receipt_v004) |
| B06 | Independent reviewer (outside package); templates procedures/TEMPLATE_B06_STAGE_RECEIPT.json, TEMPLATE_B06_VERDICT.txt | FULL_RELEASE_CHAIN.validate_chain (:84-87: digest supplied separately, reviewer, implementation_participant false); B06_RECEIPT_CHECK.py (read-only); B07_CHECK_RUNNERS.require_b06_pass (ReleaseChain until B06); B07_TECHNICAL_PRODUCER (verdict); ORIGIN_DECISION_BINDER B07; D4 review verdict parser (engine :1295-1309, D4_FIRST_ADMISSION_TRANSACTION.REVIEW_CHECKS :31-40) | TICKSTORE_STAGE_RECEIPT_V001 stage=B06 (checks independent_review, final_bytes, no_critical_or_major_findings) + verdict text (key=value; D4 consumer additionally requires header TICKSTORE_D4_RESUMABLE_CODE_DELTA_REVIEW_V002R22 and exact REVIEW_CHECKS key set) | Receipt must declare environment WINDOWS_PRODUCTION | True | No | NOT_STARTED |
| B07 | Native runner b07/B07_CHECK_RUNNERS.py (10 CHECK_RECEIPTs) -> technical receipt by control/B07_TECHNICAL_PRODUCER.build (called from qual/QUAL_DRIVER.py:478-490, --mode B07; launcher RUN_TICKSTORE_CDT15_<REV>_B07.ps1 NOT in package) -> origin decision (CHATGPT_ORIGIN) -> stage receipt by ORIGIN_DECISION_BINDER --stage B07 | FULL_RELEASE_CHAIN (6 checks); D4_FIRST_ADMISSION_TRANSACTION.validate_gates (:86-90, technical receipt with 10 B07_CHECKS, platform WINDOWS_NTFS_PS51, review_verdict_sha256 binding); MENU_OFFICIAL_WRITER.official_admission (until B07, :725); RC1R1_SUCCESSOR_MIGRATION --apply | TICKSTORE_B07_TECHNICAL_RECEIPT_V001 + TICKSTORE_B07_CHECK_RECEIPT_V001 x10 + TICKSTORE_STAGE_RECEIPT_V001 stage=B07 (checks native_windows, physical_policy_capture, state_continuity, vss_identity, negative_controls, process_tree_cleanup; b06_receipt_sha256, b06_verdict_sha256) | True | Origin decision required (not the implementer) | Reads the live policy capture; sandbox probes only | External inputs: origin R3 archive (sha 2379512B...) + 4 approved overlay files (B07_TECHNICAL_PRODUCER.TEST_TREE :87-102) - not in package |
| D4 | RUN_TICKSTORE_FULL.ps1 -Stage D4 -> FULL_RUNNER.d4_command -> 60_EFFECTFUL_WRAPPER_RELEASE.ps1 -FirstAdmission\|-ResumeAdmittedRun -ExecuteD4 -> D4_FIRST_ADMISSION_BOOTSTRAP (RUN_AUTHORITY) -> frozen master orchestrator D4_ONLY; stage receipt by FULL_D4_CLOSURE.close_d4 (-Stage D4Close or automatically after D4 exit 0) | FULL_RELEASE_CHAIN (checks scratch_certification, checkpoint_readback, journal_closed); FULL_STAGE_CONTINUATION (D5 predecessor; adapter_binding_path, g_ca_receipt_path, state_after_sha256) | TICKSTORE_STAGE_RECEIPT_V001 stage=D4 + extras (run_authority_*, d4_run_id, g_ca_receipt_*, adapter_binding_*, state_after_sha256) | True | False | Yes: production control_root STATE/journal under D:\Base CSV\Scripts\TICKSTORE_R9_DEV\..., D4 resume root D:\Base CSV\Scripts\TICKSTORE_R9_DEV\TICKSTORE_D4_RESUMABLE_V002R22, canary scratch/VSS (reads D:\Base CSV\WIN@N via shadow copy) | BROKEN IN THESE BYTES: GAP-01 (receipt cannot be published), GAP-02 (wrapper input missing), GAP-03/04/05/06 |
| D5 | FULL_STAGE_CONTINUATION.run stage D5 (node D5 CERTIFY_CANONICAL) -> publish_stage -> FULL_STAGE_EVIDENCE.publish | FULL_RELEASE_CHAIN; CANARY continuation | TICKSTORE_STAGE_RECEIPT_V001 stage=D5 with check_proofs bound to node D5 (STAGE_CHECK_WITNESSES :47-49), state_after_sha256 | True | False | Canary canonical roots (D:\PEGASUS_TICKSTORE_CANARY_V004 per config) | Code connected; unreachable because no D4 receipt can be produced (GAP-01) |
| CANARY | FULL_STAGE_CONTINUATION stage CANARY (nodes D6..D11,E1) -> publish_stage (:183-204 hard-coded 1550 days / 7,049,522,162 rows / 3101 files) | FULL_RELEASE_CHAIN; FULL_PREP continuation | TICKSTORE_STAGE_RECEIPT_V001 stage=CANARY (readback E1, safe_stop_resume D8, no_duplicate_ticks D9, failure_recovery D10, source_reconciliation E1, process_tree_cleanup D11) | True | False | Canary roots; reads source CSV | Code connected; unreachable (GAP-01) |
| FULL_PREP | FULL_STAGE_CONTINUATION stage FULL_PREP (nodes E2..E9; E9 AWAITING_STAGE_B packs evidence) | FULL_RELEASE_CHAIN; FULL_ADMIT continuation | TICKSTORE_STAGE_RECEIPT_V001 stage=FULL_PREP (production_certificates E3, manifest_rederivation E4, live_equality E5, admission_simulation E7, stage_b_evidence_pack E9) | True | Stage B review follows (inbox\STAGE_B_REVIEW_V001.txt, FULL_GO.txt - external) | Production VSS generation G_PA, D:\TICKSTORE / scratch certification (read) | Code connected; unreachable (GAP-01) |
| FULL_ADMISSION | FULL_STAGE_CONTINUATION stage FULL_ADMIT (nodes F1,F2,F3,G1,G2) -> publish_stage with full_admission_facts (generation, vss_profile, root_identities); FULL_READMIT -> FULL_LIFECYCLE.refresh_admission | FULL_RELEASE_CHAIN.validate_full (:160-187, 300 s freshness, root identities, VSS, process census); FULL_STAGE_CONTINUATION FULL (:378-388); FULL_RUNNER Stop | TICKSTORE_STAGE_RECEIPT_V001 stage=FULL_ADMISSION (fresh_instance G1, source_plan F3, resource_limits G2, locks_and_leases G1, vss_identity G1, root_identities G1, stage_b_review F1, production_freeze F2) + created_unix_ns, generation, vss_profile, root_identities, state_after_sha256 | True | Consumes external Stage B review + FULL_GO | Reads D:\TICKSTORE, scratch, source roots; PRODUCTION_FREEZE_V004R1.json | Code connected; unreachable (GAP-01) |
| FULL (completion) | FULL_STAGE_CONTINUATION stage FULL -> FULL_LIFECYCLE.install (G3 = MULTIWORK) -> execute_nodes G3..H6 -> FULL_LIFECYCLE.publish_completion | none in package (terminal; next_node I1) | TICKSTORE_FULL_COMPLETION_V001 (FULL_LIFECYCLE.py:309-316) + TICKSTORE_MULTIWORK_RECONCILIATION_V001 + H6 FINAL_EVIDENCE pack | True | False | YES: writes canonical D:\TICKSTORE from source CSV (D:\Base CSV\WIN@N per config); csv_deletion_authorized False | Code connected; unreachable (GAP-01) |
| OFFICIAL_ACTIVATION (menu) | INSTALL_TICKSTORE_FULL.ps1 -ActivateMenu -> MENU_OFFICIAL_WRITER.py --mode official-publish | menu/MENU.py._tickstore_committed_deployment (:113-180) | TICKSTORE_MENU_INSTALL_TRANSACTION_V001 PLAN.json + JOURNAL.json (phase COMMITTED) + ACTIVE_DEPLOYMENT.json (TICKSTORE_DEPLOYMENT_V001) | True | Requires chain until B07 | Replaces D:\Base CSV\Scripts\Biblioteca\MENU.py (backup kept); reads BAT | Requires chain through B07 (not available) |
| LEGACY_ENTRY_FENCE (prerequisite) | control/LEGACY_ENTRY_FENCE.py --apply (procedures/PROCEDIMENTO_CDT21_LEGACY_ENTRY_FENCE.md) | runtime_locator_orchestrator_entry.require_legacy_entry_fence (:769) at D4 admission, every admitted STATE commit and journal append | TICKSTORE_LEGACY_ENTRY_FENCE_V001 marker + TICKSTORE_LEGACY_JOURNAL_CUT_V001 inside STATE.json.partial fence dir; report TICKSTORE_LEGACY_ENTRY_FENCE_REPORT_V002 | True | Origin authorization required | Yes: production control_root state dir (fence + DENY ACE on STATE_JOURNAL.jsonl) | Not installed in production (V004 completeness not_claimed) |
| POLICY (current origin reconciliation) | Origin (TICKSTORE_ORIGIN_POLICY_RECONCILIATION_V001) - external; capture folder 1 MASTER + 1 HEAD | POLICY_CAPTURE_BINDING.verify_capture via D4 bootstrap, FULL_STAGE_CONTINUATION (:280-282), B07 producer, ORIGIN_DECISION_BINDER, FULL_INSTANCE_PREPARE | TICKSTORE_ORIGIN_POLICY_RECONCILIATION_V001 -> TICKSTORE_VERIFIED_POLICY_CAPTURE_V001 | Native protected reads for operational receipts | Origin | No |  |
| D4 POLICY ADMISSION RECEIPT | NONE IN PACKAGE (GAP-06) | D4_FIRST_ADMISSION_TRANSACTION.validate_gates (:91-105); 60_EFFECTFUL_WRAPPER_RELEASE.ps1:257; engine :1639 | TICKSTORE_D4_POLICY_ADMISSION_RECEIPT_V001 | n/a | UNVERIFIED (no producer named) | No |  |
| D4 PREDECESSOR EVIDENCE | D4_ROOTS_EVIDENCE.py (roots report) + NO producer for OBSERVATION.json / PREDECESSOR_SYSTEM.json (GAP-05) | D4_FIRST_ADMISSION_BOOTSTRAP.fresh_predecessor (:72-84) -> D4_PREDECESSOR_RECONCILIATION.reconcile | TICKSTORE_D4_PREDECESSOR_OBSERVATION_V001, TICKSTORE_D4_PREDECESSOR_SYSTEM_OBSERVATION_V001 (<=300 s old), TICKSTORE_D4_ROOTS_EVIDENCE_V001 | True | False | Reads production control_root |  |

Fail-closed behaviour: every consumer raises (`Blocked`, `RuntimeError`, `G5Incomplete`, `DecisionBlocked`) on a missing or mismatching receipt. The entry points map this to exit code 2 and print `*_BLOCKED=<reason>`. I found no path that infers a PASS from an absent receipt. The FIXTURE environment is never consumable: `FULL_RELEASE_CHAIN.py:55,112` and `ORIGIN_DECISION_BINDER` set `FIXTURE_NOT_NATIVE` without native reads.

## 4. Hard-coded paths

### 4.1 How each log path is chosen

| Component | Choice | Detail | cwd-derived |
|---|---|---|---|
| candidate/control/RUN_TICKSTORE_FULL.ps1 (lines 24,101-109,116-126,152-154) | FIXED_ABSOLUTE | `C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS` -> <Stage>_<yyyyMMdd_HHmmss_fff>_<PID>\RUN_LOG.txt, created new (collision -> RUN_DIR_COLLISION); elevated child reuses the parent run dir only if it is a direct child of the fixed root with matching name; passes --log-file to FULL_RUNNER.py | No |
| candidate/control/INSTALL_TICKSTORE_FULL.ps1 (lines 15,65-70) | FIXED_ABSOLUTE | `C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS` -> INSTALL_<yyyyMMdd_HHmmss_fff>_<PID>\RUN_LOG.txt Witness search default -Downloads C:\Users\silvi\OneDrive\Downloads (line 4, overridable parameter); install root %LOCALAPPDATA%\TICKSTORE\Candidates (line 5). | No |
| candidate/control/RUN_LOG_FIXED.py (lines 20,39-79) | FIXED_ABSOLUTE | `C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS` -> <MODE>_<yyyyMMdd_HHmmss_fff>_<PID>\RUN_LOG.txt (mkdir exist_ok=False, open "x"); only on Windows; skipped when --log-file or --help is passed Modes: FULL_RUNNER (FULL_RUNNER.py:247); STAGE_CONTINUATION (FULL_STAGE_CONTINUATION.py:427); INSTANCE_PREPARE (FULL_INSTANCE_PREPARE.py:129); MENU_OFFICIAL_WRITER (MENU_OFFICIAL_WRITER.py:791); ORIGIN_DECISION_BINDER (ORIGIN_DECISION_BINDER.py:443); B06_RECEIPT_CHECK (B06_RECEIPT_CHECK.py:91); RC1R1_MIGRATION (RC1R1_SUCCESSOR_MIGRATION.py:314); STATE_CAS_RECOVERY (STATE_CAS_RECOVERY.py:307); D4_ROOTS_EVIDENCE (D4_ROOTS_EVIDENCE.py:275); D4_IDENTITY_DIAGNOSTIC (D4_IDENTITY_DIAGNOSTIC.py:129); G5_EVIDENCE_BUILDER (G5_EVIDENCE_BUILDER.py:347); MULTIWORK_COMPAT (tickstore_full_multiwork.py:1954) | No |
| operator CLIs WITHOUT a fixed RUN_LOG | STDOUT_ONLY |  candidate/control/LEGACY_ENTRY_FENCE.py:241-256 (--apply writes into the production control_root); candidate/b07/B07_CHECK_RUNNERS.py:193-264 (writes only under operator --evidence/--work); candidate/control/G5_FINAL_COMPLETENESS_PRODUCER.py:186-195; candidate/control/G5_C6_FORMAL_STAGE_BUILDER.py; candidate/control/D4_FIRST_ADMISSION_PREP.py:328-343; candidate/control/D4_FIRST_ADMISSION_BOOTSTRAP.py:256-267 (stdout captured by the wrapper); candidate/control/D4_PREDECESSOR_RECONCILIATION.py; candidate/control/MENU_OFFICIAL_ADMISSION_READONLY.py; candidate/menu/MENU.py (launches RUN_TICKSTORE_FULL.ps1, which logs); candidate/g5proof/* runners (qualification) | No |
| D4 wrapper output | CONSOLE_ONLY (static inference) | FULL_RUNNER.run_wrapper_cooperatively uses subprocess.call(command) (FULL_RUNNER.py:62) with no stdout redirection, so the PowerShell wrapper inherits the OS console handle and bypasses the Python _Tee (FULL_RUNNER.py:68-81,221-224); the wrapper prints child output with Write-Host (60_EFFECTFUL_WRAPPER_RELEASE.ps1:555). D4 effect output is therefore not in RUN_LOG.txt. Native confirmation UNVERIFIED. | No |
| No log path derived from cwd | n/a | Only cwd use: recovery/TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1:6 requires cwd == C:\Users\silvi (launch precondition, not a log path); the wrapper sets WorkingDirectory=C:\Users\silvi (60_EFFECTFUL_WRAPPER_RELEASE.ps1:544). | No |

All fixed log roots point to `C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS`. The owner standard registered on 2026-10-21 is `C:\Users\silvi\Downloads\<FAMILIA>_RUNS\...` (GAP-08). No log path is derived from the current directory.

### 4.2 Every occurrence (`Downloads`, `OneDrive`, `C:\Users`, `D:\Base CSV`, `TICKSTORE_RUNS`, `LOCALAPPDATA`)

Scope: RUNTIME = candidate code (not tests/review); TEST, QUAL, REVIEW_HISTORY, DOC_OR_RECEIPT = everything else. Patches and ZIP members are excluded.

| file:line | Scope | Kind | Text |
|---|---|---|---|
| `candidate/control/60_EFFECTFUL_WRAPPER_RELEASE.ps1:22` | RUNTIME | PINNED_PYTHON | `[string]$PreparationPython = 'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe',` |
| `candidate/control/60_EFFECTFUL_WRAPPER_RELEASE.ps1:23` | RUNTIME | PRODUCTION_D_BASE_CSV | `[string]$PreparationResumeRoot = 'D:\Base CSV\Scripts\TICKSTORE_R9_DEV\TICKSTORE_D4_RESUMABLE_V002R22',` |
| `candidate/control/60_EFFECTFUL_WRAPPER_RELEASE.ps1:130` | RUNTIME | PINNED_PYTHON | `$Python='C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe'` |
| `candidate/control/60_EFFECTFUL_WRAPPER_RELEASE.ps1:131` | RUNTIME | PRODUCTION_D_BASE_CSV | `$ResumeRoot = 'D:\Base CSV\Scripts\TICKSTORE_R9_DEV\TICKSTORE_D4_RESUMABLE_V002R22'` |
| `candidate/control/60_EFFECTFUL_WRAPPER_RELEASE.ps1:141` | RUNTIME | PRODUCTION_D_BASE_CSV | `$ControlRoot = 'D:\Base CSV\Scripts\TICKSTORE_R9_DEV\WORK_R9_PUBLISHER_RECOVERY_V004R1R1\ORCHESTRATOR_V001R9R1_B6_R8_PROVENANCE_VSS_SCOPE_FIX'` |
| `candidate/control/60_EFFECTFUL_WRAPPER_RELEASE.ps1:544` | RUNTIME | CWD | `$psi=New-Object Diagnostics.ProcessStartInfo;$psi.FileName=$Python;$psi.WorkingDirectory='C:\Users\silvi';$psi.UseShellExecute=$false;$psi.CreateNoWin` |
| `candidate/control/INSTALL_TICKSTORE_FULL.ps1:4` | RUNTIME | DOWNLOADS_INPUT_OR_DOC | `[string]$Downloads='C:\Users\silvi\OneDrive\Downloads',` |
| `candidate/control/INSTALL_TICKSTORE_FULL.ps1:5` | RUNTIME | LOCALAPPDATA | `[string]$InstallRoot=(Join-Path $env:LOCALAPPDATA 'TICKSTORE\Candidates'),` |
| `candidate/control/INSTALL_TICKSTORE_FULL.ps1:15` | RUNTIME | LOG_ROOT | `$LogRoot='C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS'` |
| `candidate/control/INSTALL_TICKSTORE_FULL.ps1:64` | RUNTIME | LOG_ROOT | `# Run-owned log folder only (TICKSTORE_RUNS); no installation write precedes the gates below.` |
| `candidate/control/INSTALL_TICKSTORE_FULL.ps1:78` | RUNTIME | LOCALAPPDATA | `Require ([IO.Path]::GetFullPath($InstallRoot) -ceq [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'TICKSTORE\Candidates'))) 'MENU_ACTIVATION_REQU` |
| `candidate/control/INSTALL_TICKSTORE_FULL.ps1:83` | RUNTIME | DOWNLOADS_INPUT_OR_DOC | `$found=@(Get-ChildItem -LiteralPath $Downloads -Filter 'WITNESS_TICKSTORE_FULL_FINAL_*.json' -File)` |
| `candidate/control/INSTALL_TICKSTORE_FULL.ps1:119` | RUNTIME | PINNED_PYTHON | `$python='C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe'` |
| `candidate/control/MENU_OFFICIAL_ADMISSION_READONLY.py:19` | RUNTIME | PRODUCTION_D_BASE_CSV | `MENU = r'D:\Base CSV\Scripts\Biblioteca\MENU.py'` |
| `candidate/control/MENU_OFFICIAL_ADMISSION_READONLY.py:20` | RUNTIME | PRODUCTION_D_BASE_CSV | `BAT = r'D:\Base CSV\Manutenção Base de Dados.bat'` |
| `candidate/control/MENU_OFFICIAL_ADMISSION_READONLY.py:49` | RUNTIME | LOCALAPPDATA | `raise Blocked('LOCALAPPDATA_NOT_ABSOLUTE')` |
| `candidate/control/MENU_OFFICIAL_ADMISSION_READONLY.py:199` | RUNTIME | LOCALAPPDATA | `app=os.environ.get('LOCALAPPDATA','')` |
| `candidate/control/MENU_OFFICIAL_ADMISSION_READONLY.py:200` | RUNTIME | LOCALAPPDATA | `if not re.fullmatch(r'[A-Za-z]:\\[^%]+',app):raise Blocked('LOCALAPPDATA_INVALID')` |
| `candidate/control/MENU_OFFICIAL_WRITER.py:6` | RUNTIME | LOCALAPPDATA | `the evidence live on the LOCALAPPDATA volume (C:).  This is a cross-volume` |
| `candidate/control/MENU_OFFICIAL_WRITER.py:347` | RUNTIME | LOCALAPPDATA | `tickstore_root: Path      # %LOCALAPPDATA%\TICKSTORE (C:)` |
| `candidate/control/MENU_OFFICIAL_WRITER.py:394` | RUNTIME | LOCALAPPDATA | `"""Fixed historical targets; LOCALAPPDATA is validated after real expansion."""` |
| `candidate/control/MENU_OFFICIAL_WRITER.py:396` | RUNTIME | LOCALAPPDATA | `app = os.environ.get('LOCALAPPDATA', '')` |
| `candidate/control/MENU_OFFICIAL_WRITER.py:397` | RUNTIME | LOCALAPPDATA | `require(re.fullmatch(r'[A-Za-z]:\\[^%]+', app) is not None, 'LOCALAPPDATA_INVALID')` |
| `candidate/control/MENU_OFFICIAL_WRITER.py:399` | RUNTIME | LOCALAPPDATA | `'LOCALAPPDATA_NOT_CANONICAL')` |
| `candidate/control/MENU_OFFICIAL_WRITER.py:406` | RUNTIME | PRODUCTION_D_BASE_CSV | `reals = [r'D:\Base CSV']` |
| `candidate/control/MENU_OFFICIAL_WRITER.py:426` | RUNTIME | LOCALAPPDATA | `require(not touches_real_target(str(root), os.environ.get('LOCALAPPDATA', '')),` |
| `candidate/control/MENU_OFFICIAL_WRITER.py:567` | RUNTIME | LOCALAPPDATA | `# 3. ACTIVE on the LOCALAPPDATA volume: absent target, no-replace move.` |
| `candidate/control/MENU_OFFICIAL_WRITER_CONTRACT_SOURCE_ONLY.py:51` | RUNTIME | LOCALAPPDATA | `'LOCALAPPDATA_INVALID')` |
| `candidate/control/MENU_OFFICIAL_WRITER_CONTRACT_SOURCE_ONLY.py:53` | RUNTIME | LOCALAPPDATA | `_require(norm.casefold() == value.casefold() and not value.endswith('\\'), 'LOCALAPPDATA_NOT_CANONICAL')` |
| `candidate/control/MENU_OFFICIAL_WRITER_CONTRACT_SOURCE_ONLY.py:105` | RUNTIME | LOCALAPPDATA | `# ACTIVE and transaction records belong to C: (LOCALAPPDATA).` |
| `candidate/control/RC1R1_SUCCESSOR_MIGRATION.py:35` | RUNTIME | PRODUCTION_D_BASE_CSV | `DEFAULT_RESUME_ROOT = r'D:\Base CSV\Scripts\TICKSTORE_R9_DEV\TICKSTORE_D4_RESUMABLE_V002R22'` |
| `candidate/control/RUN_LOG_FIXED.py:6` | RUNTIME | LOG_ROOT | `C:\\Users\\silvi\\OneDrive\\Downloads\\TICKSTORE_RUNS\\<MODE>_<yyyyMMdd_HHmmss_fff>_<PID>\\RUN_LOG.txt` |
| `candidate/control/RUN_LOG_FIXED.py:20` | RUNTIME | LOG_ROOT | `LOG_ROOT = r'C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS'` |
| `candidate/control/RUN_TICKSTORE_FULL.ps1:21` | RUNTIME | PINNED_PYTHON | `$python='C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe'` |
| `candidate/control/RUN_TICKSTORE_FULL.ps1:24` | RUNTIME | LOG_ROOT | `$LogRoot='C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS'` |
| `candidate/control/RUN_TICKSTORE_FULL.ps1:43` | RUNTIME | OTHER | `# OneDrive marks synced folders as reparse points (observed natively on` |
| `candidate/control/RUN_TICKSTORE_FULL.ps1:44` | RUNTIME | LOG_ROOT | `# TICKSTORE_RUNS in R41R1/R41R2; FindFirstFile reported tag 0).` |
| `candidate/control/RUN_TICKSTORE_FULL.ps1:45` | RUNTIME | OTHER | `$under=($p -ieq 'C:\Users\silvi\OneDrive' -or $p.StartsWith('C:\Users\silvi\OneDrive\',[StringComparison]::OrdinalIgnoreCase))` |
| `candidate/full/WINDOWS_GATE_B_PREFLIGHT_V005.py:171` | RUNTIME | OTHER | `# OneDrive is observational here; actual transient-denial behavior is tested above and must remain fail-closed.` |
| `candidate/full/WINDOWS_GATE_B_PREFLIGHT_V005.py:173` | RUNTIME | OTHER | `tl=subprocess.run(['tasklist','/FI','IMAGENAME eq OneDrive.exe'],capture_output=True,text=True,timeout=15)` |
| `candidate/full/WINDOWS_GATE_B_PREFLIGHT_V005.py:192` | RUNTIME | OTHER | `'OneDrive/antivirus behavior is represented by fail-closed external-lock simulation plus process observation; real pilot evidence remains required.'` |
| `candidate/full/run_tickstore_full_multiwork_r9.ps1:15` | RUNTIME | PINNED_PYTHON | `[string]$PythonPath = 'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe'` |
| `candidate/g5proof/G5_MULTIWORK_SCENARIOS.py:207` | RUNTIME | LOCALAPPDATA | `lab_base = Path(os.environ['LOCALAPPDATA']).absolute()/'CDT20_R08'` |
| `candidate/g5proof/G5_MULTIWORK_SCENARIOS.py:302` | RUNTIME | LOCALAPPDATA | `'sandbox_only': Path(work).is_relative_to(Path(os.environ['LOCALAPPDATA'])),` |
| `candidate/g5proof/G5_MULTIWORK_SCENARIOS.py:348` | RUNTIME | LOCALAPPDATA | `'sandbox_only': Path(work).is_relative_to(Path(os.environ['LOCALAPPDATA'])),` |
| `candidate/g5proof/G5_PROOF_RUNNERS.py:45` | RUNTIME | PRODUCTION_D_BASE_CSV | `REAL_MENU = r'D:\Base CSV\Scripts\Biblioteca\MENU.py'` |
| `candidate/g5proof/G5_PROOF_RUNNERS.py:46` | RUNTIME | PRODUCTION_D_BASE_CSV | `REAL_BAT = 'D:\\Base CSV\\Manuten\u00e7\u00e3o Base de Dados.bat'` |
| `candidate/g5proof/G5_PROOF_RUNNERS.py:422` | RUNTIME | PRODUCTION_D_BASE_CSV | `'run_owned_only': within(a.work,a.work) and not within(a.work,r'D:\Base CSV')` |
| `candidate/g5proof/PRE_G06_CAMPAIGN.py:157` | RUNTIME | LOCALAPPDATA | `'--d-parent',spec['d_parent'],'--local-appdata',os.environ['LOCALAPPDATA']]` |
| `candidate/g5proof/PRE_G06_CAMPAIGN.py:398` | RUNTIME | LOCALAPPDATA | `require(root.is_relative_to(no_alias(os.environ['LOCALAPPDATA'])),'LOCALAPPDATA_OWNED_RUN')` |
| `candidate/g5proof/PRE_G06_NATIVE_SCENARIOS.py:465` | RUNTIME | LOCALAPPDATA | `require(root.is_relative_to(Path(os.environ['LOCALAPPDATA']).absolute()), 'LOCAL_OWNED_ROOT_REQUIRED')` |
| `candidate/menu/MENU.py:18` | RUNTIME | OTHER | `USO (PowerShell, que abre em C:\Users\silvi)` |
| `candidate/menu/MENU.py:20` | RUNTIME | PRODUCTION_D_BASE_CSV,CWD | `cd "D:\Base CSV"` |
| `candidate/menu/MENU.py:190` | RUNTIME | LOCALAPPDATA | `receipt_path = Path(os.environ['LOCALAPPDATA'])/'TICKSTORE/ACTIVE_DEPLOYMENT.json'` |
| `candidate/menu/MENU.py:194` | RUNTIME | LOCALAPPDATA | `expected = Path(os.environ['LOCALAPPDATA'])/'TICKSTORE/Candidates'/deploy['package_sha256']` |
| `candidate/recovery/TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1:6` | RUNTIME | CWD | `if((Get-Location).Path-cne'C:\Users\silvi'){throw ('LAUNCH_CWD_REQUIRED=C:\Users\silvi actual='+(Get-Location).Path)}` |
| `candidate/recovery/TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1:7` | RUNTIME | PINNED_PYTHON | `$Python='C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe';$PythonSha='4942B86A6597E5AEE0128DAA00050ED79BC21F6E709A78EB19CBFEB0C2F39A` |
| `candidate/recovery/config/STAGE_A_SEALED_VALUES_V001.json:38` | RUNTIME | PRODUCTION_D_BASE_CSV | `"control_root": "D:\\Base CSV\\Scripts\\TICKSTORE_R9_DEV\\WORK_R9_PUBLISHER_RECOVERY_V004R1R1\\ORCHESTRATOR_V001R9R1_B6_R8_PROVENANCE_VSS_SCOPE_FIX",` |
| `candidate/recovery/config/STAGE_A_SEALED_VALUES_V001.json:50` | RUNTIME | PRODUCTION_D_BASE_CSV | `"corrective_receipt_path": "D:\\Base CSV\\Scripts\\TICKSTORE_R9_DEV\\WORK_R9_PUBLISHER_RECOVERY_V004R1R1\\evidence\\GATE2_CONTRACT_ID_REPAIR_QUALIFICA` |
| `candidate/recovery/config/STAGE_A_SEALED_VALUES_V001.json:52` | RUNTIME | PRODUCTION_D_BASE_CSV | `"corrective_result_path": "D:\\Base CSV\\Scripts\\TICKSTORE_R9_DEV\\WORK_R9_PUBLISHER_RECOVERY_V004R1R1\\evidence\\GATE2_CONTRACT_ID_REPAIR_QUALIFICAT` |
| `candidate/recovery/config/STAGE_A_SEALED_VALUES_V001.json:81` | RUNTIME | PRODUCTION_D_BASE_CSV | `"D:\\Base CSV\\Scripts\\TICKSTORE_R9_DEV\\WORK_R9_PUBLISHER_RECOVERY_V004R1R1\\ORCHESTRATOR_V001R2_HASHFIX",` |
| `candidate/recovery/config/STAGE_A_SEALED_VALUES_V001.json:82` | RUNTIME | PRODUCTION_D_BASE_CSV | `"D:\\Base CSV\\Scripts\\TICKSTORE_R9_DEV\\WORK_R9_PUBLISHER_RECOVERY_V004R1R1\\ORCHESTRATOR_V001R5_B6_CODE_DELTA",` |
| `candidate/recovery/config/STAGE_A_SEALED_VALUES_V001.json:83` | RUNTIME | PRODUCTION_D_BASE_CSV | `"D:\\Base CSV\\Scripts\\TICKSTORE_R9_DEV\\WORK_R9_PUBLISHER_RECOVERY_V004R1R1\\ORCHESTRATOR_V001R6_B6_ROOTSLASH"` |
| `candidate/recovery/config/STAGE_A_SEALED_VALUES_V001.json:86` | RUNTIME | PRODUCTION_D_BASE_CSV | `"ledger_path": "D:\\Base CSV\\Scripts\\TICKSTORE_R9_DEV\\WORK_R9_FULL_MULTIWORK_RC4R2\\OUT_P4A_R3_FULL_HISTORY_COMPAT.zip",` |
| `candidate/recovery/config/STAGE_A_SEALED_VALUES_V001.json:98` | RUNTIME | PRODUCTION_D_BASE_CSV | `"production_csv_root_metadata_only": "D:\\Base CSV\\WIN@N",` |
| `candidate/recovery/config/STAGE_A_SEALED_VALUES_V001.json:181` | RUNTIME | PRODUCTION_D_BASE_CSV | `"v001r8_failed_control_root": "D:\\Base CSV\\Scripts\\TICKSTORE_R9_DEV\\WORK_R9_PUBLISHER_RECOVERY_V004R1R1\\ORCHESTRATOR_V001R8_B6_CORE_VSS_ADAPTER",` |
| `candidate/recovery/config/STAGE_A_SEALED_VALUES_V001.json:192` | RUNTIME | PRODUCTION_D_BASE_CSV | `"workspace": "D:\\Base CSV\\Scripts\\TICKSTORE_R9_DEV\\WORK_R9_PUBLISHER_RECOVERY_V004R1R1"` |
| `candidate/recovery/engine/tickstore_publisher_recovery_v004_candidate.py:2447` | RUNTIME | PRODUCTION_D_BASE_CSV | `protected=(norm(r"D:\TICKSTORE"),norm(r"D:\TICKSTORE_GATE_B_SCRATCH"),norm(r"D:\Base CSV\WIN@N"))` |
| `candidate/recovery/engine/tickstore_publisher_recovery_v004_release.py:2447` | RUNTIME | PRODUCTION_D_BASE_CSV | `protected=(norm(r"D:\TICKSTORE"),norm(r"D:\TICKSTORE_GATE_B_SCRATCH"),norm(r"D:\Base CSV\WIN@N"))` |
| `powerloss_lab/LAB_POWERLOSS.py:36` | QUAL | PRODUCTION_D_BASE_CSV | `PRODUCTION_PATH_MARKERS = (r'D:\Base CSV', r'\TICKSTORE\ACTIVE_DEPLOYMENT.json')` |
| `powerloss_lab/PROTOCOLO_POWERLOSS_FISICO_V001.md:7` | QUAL | PRODUCTION_D_BASE_CSV | `- Computador Windows **separado** do PC produtivo. O preflight recusa qualquer máquina que exponha os volumes produtivos (seriais 'C4B23CE5'/'7435A171` |
| `qual/CDT21_F01R1_G0_QUALIFICATION.py:19` | QUAL | LOCALAPPDATA | `python -I -B CDT21_F01R1_G0_QUALIFICATION.py --run-root <LOCALAPPDATA\\CDT21_F01R1_G0\\R08_Q1_...> --package <V004 zip>` |
| `qual/CDT21_F01R1_G0_QUALIFICATION.py:115` | QUAL | LOCALAPPDATA | `require(root.is_relative_to(campaign.no_alias(os.environ['LOCALAPPDATA'])), 'LOCALAPPDATA_OWNED_RUN')` |
| `qual/CDT21_F01_G0_QUALIFICATION.py:17` | QUAL | LOCALAPPDATA | `python -I -B CDT21_F01_G0_QUALIFICATION.py --run-root <LOCALAPPDATA\\CDT21_F01_G0\\R08_Q1_...> --package <V003 zip>` |
| `qual/CDT21_F01_G0_QUALIFICATION.py:82` | QUAL | LOCALAPPDATA | `require(root.is_relative_to(campaign.no_alias(os.environ['LOCALAPPDATA'])), 'LOCALAPPDATA_OWNED_RUN')` |
| `qual/QUAL_DRIVER.py:44` | QUAL | PRODUCTION_D_BASE_CSV | `REAL_MENU = r'D:\Base CSV\Scripts\Biblioteca\MENU.py'` |
| `qual/QUAL_DRIVER.py:45` | QUAL | PRODUCTION_D_BASE_CSV | `REAL_BAT = 'D:\\Base CSV\\Manuten\u00e7\u00e3o Base de Dados.bat'` |
| `qual/QUAL_DRIVER.py:503` | QUAL | LOCALAPPDATA | `'--d-parent', str(Path(d_parent) / 'PS51_D'), '--local-appdata', os.environ.get('LOCALAPPDATA', '')]` |
| `qual/QUAL_DRIVER.py:594` | QUAL | LOCALAPPDATA | `app = os.environ.get('LOCALAPPDATA', '') if native else ''` |
| `qual/QUAL_DRIVER.py:598` | QUAL | LOCALAPPDATA | `require(re.fullmatch(r'[A-Za-z]:\\[^%]+', app) is not None and not app.endswith('\\'), 'LOCALAPPDATA_INVALID')` |
| `qual/R44D2_DROOT_AUDIT.py:207` | QUAL | LOCALAPPDATA | `app = os.environ.get('LOCALAPPDATA', '')` |
| `qual/R44D2_DROOT_AUDIT.py:226` | QUAL | LOG_ROOT | `Path(r'C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS') / R1.R44_RUN)` |
| `qual/R44D2_DROOT_AUDIT.py:232` | QUAL | LOCALAPPDATA | `# 2. C: private work root (created by the bootstrap under LOCALAPPDATA) admitted and held.` |
| `qual/R44D_DROOT_AUDIT.py:100` | QUAL | OTHER | `# The log root lives under OneDrive (Cloud Files reparse folders by design): informative only.` |
| `qual/R44D_DROOT_AUDIT.py:180` | QUAL | LOCALAPPDATA | `app = os.environ.get('LOCALAPPDATA', '')` |
| `qual/R44D_DROOT_AUDIT.py:197` | QUAL | LOG_ROOT | `r44_log = Path(r'C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS') / R44_RUN` |
| `tests/test_cdt19_native_campaign_contract.py:124` | TEST | LOCALAPPDATA | `# really outside LOCALAPPDATA/CDT19_R08, not merely outside run/TEMP.` |
| `tests/test_cdt19_native_campaign_contract.py:126` | TEST | LOCALAPPDATA | `lab_base=Path(os.environ['LOCALAPPDATA']).absolute()/'CDT20_R08' if os.name=='nt' else self.root` |
| `tests/test_cdt19_native_campaign_contract.py:127` | TEST | LOCALAPPDATA | `fixture_parent=Path(os.environ['LOCALAPPDATA']).absolute() if os.name=='nt' else self.root` |
| `tests/test_cdt21_f01_legacy_entry_fence.py:46` | TEST | PINNED_PYTHON | `PINNED_PYTHON = Path(r'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe')` |
| `tests/test_cdt21_f01_legacy_entry_fence.py:47` | TEST | OTHER | `LAUNCHER_HOME = Path(r'C:\Users\silvi')` |
| `tests/test_full_runner_observability_r41.py:135` | TEST | LOG_ROOT | `self.assertIn("$LogRoot='C:\\Users\\silvi\\OneDrive\\Downloads\\TICKSTORE_RUNS'", self.text)` |
| `tests/test_installer_legacy_activation_prune.py:29` | TEST | LOG_ROOT | `# The only earlier write is the run-owned log folder under the fixed TICKSTORE_RUNS root.` |
| `tests/test_installer_legacy_activation_prune.py:59` | TEST | LOG_ROOT | `self.assertIn("$LogRoot='C:\\Users\\silvi\\OneDrive\\Downloads\\TICKSTORE_RUNS'", self.text)` |
| `tests/test_lab_powerloss.py:58` | TEST | PRODUCTION_D_BASE_CSV | `e = FakeEnv(); e.files['D:\\Base CSV'] = b''` |
| `tests/test_official_target_readonly_admission.py:7` | TEST | OTHER | `APP=r'C:\Users\silvi\AppData\Local'` |
| `tests/test_official_target_readonly_admission.py:52` | TEST | LOCALAPPDATA | `with self.assertRaisesRegex(a.Blocked,'LOCALAPPDATA_NOT_ABSOLUTE'):` |
| `tests/test_official_target_readonly_admission.py:61` | TEST | PRODUCTION_D_BASE_CSV | `self.assertEqual(a.MENU,r'D:\Base CSV\Scripts\Biblioteca\MENU.py')` |
| `tests/test_official_target_readonly_admission.py:62` | TEST | PRODUCTION_D_BASE_CSV | `self.assertEqual(a.BAT,r'D:\Base CSV\Manutenção Base de Dados.bat')` |
| `tests/test_official_writer_contract.py:6` | TEST | OTHER | `APP=r'C:\Users\silvi\AppData\Local'` |
| `tests/test_official_writer_contract.py:43` | TEST | LOCALAPPDATA | `def test_07_unexpanded_appdata(self):self.blocked('LOCALAPPDATA',a=r'%USERPROFILE%\AppData\Local')` |
| `tests/test_official_writer_effectful.py:400` | TEST | OTHER | `app = 'C:\\Users\\x\\AppData\\Local'` |
| `tests/test_official_writer_effectful.py:401` | TEST | PRODUCTION_D_BASE_CSV | `for bad in (r'D:\Base CSV\CDT15_R41_WRITER_QUAL_D_1', r'D:\Base CSV', 'D:\\',` |
| `tests/test_official_writer_effectful.py:407` | TEST | PRODUCTION_D_BASE_CSV | `r'D:\Base CSV2\CDT15_R41_WRITER_QUAL_D_1'):` |
| `tests/test_operator_entry_points.py:50` | TEST | LOCALAPPDATA | `self.local = self.t / 'LOCALAPPDATA'` |
| `tests/test_operator_entry_points.py:57` | TEST | LOCALAPPDATA | `self.env = dict(os.environ, LOCALAPPDATA=str(self.local), SystemRoot=str(self.t / 'Windows'))` |
| `README_CDT17_CORRECTIVE_CURRENT_G5_FIXTURE.md:9` | DOC_OR_RECEIPT | OTHER | `Resultados 29/29 na sandbox: PASS_SCOPEED. TARGET_WINDOWS_NATIVE: NÃO PROVADO nesta emissão. Runner 'VERIFY_CDT17_CORRECTIVE_DELTA.py' roda APENAS a n` |
| `README_FIRST.txt:8` | DOC_OR_RECEIPT | DOWNLOADS_INPUT_OR_DOC | `launcher from the same Downloads folder. It validates physical ZIP identity,` |
| `README_R41_ENGINEERING.md:12` | DOC_OR_RECEIPT | LOCALAPPDATA | `- MENU, pendente e backup no volume do MENU (D:); ACTIVE, journal e evidências em '%LOCALAPPDATA%\TICKSTORE' (C:). Protocolo entre volumes, **não** tr` |
| `README_R41_ENGINEERING.md:23` | DOC_OR_RECEIPT | LOG_ROOT | `- log por execução em pasta absoluta fixa 'C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS\<ETAPA>_<yyyyMMdd_HHmmss_fff>_<PID>\RUN_LOG.txt';` |
| `README_R41_ENGINEERING.md:31` | DOC_OR_RECEIPT | DOWNLOADS_INPUT_OR_DOC | `Coloque em 'C:\Users\silvi\OneDrive\Downloads':` |
| `README_R41_ENGINEERING.md:35` | DOC_OR_RECEIPT | DOWNLOADS_INPUT_OR_DOC | `powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Users\silvi\OneDrive\Downloads\RUN_TICKSTORE_CDT15_R41_QUAL.ps1"` |
| `README_R41_ENGINEERING.md:39` | DOC_OR_RECEIPT | LOG_ROOT,LOCALAPPDATA | `Pastas criadas (todas próprias da execução): '...\Downloads\TICKSTORE_RUNS\R41_QUAL_*', '%LOCALAPPDATA%\TICKSTORE_QUAL_R41\R41_QUAL_*', 'D:\TICKSTORE_` |
| `README_R41_ENGINEERING.md:40` | DOC_OR_RECEIPT | PRODUCTION_D_BASE_CSV,LOCALAPPDATA | `Nunca escreve em 'D:\Base CSV', '%LOCALAPPDATA%\TICKSTORE', MENU, BAT, ACTIVE_DEPLOYMENT ou STATE; o driver comprova isso comparando instantâneos some` |
| `candidate/full/GATE_B_PILOT_MATRIX_V001.md:66` | DOC_OR_RECEIPT | OTHER | `- OneDrive active synchronization lock;` |
| `candidate/full/GATE_B_PILOT_MATRIX_V001.md:123` | DOC_OR_RECEIPT | OTHER | `OneDrive/antivirus locks and real process-level sharing behavior.` |
| `candidate/full/README_R9.md:90` | DOC_OR_RECEIPT | PRODUCTION_D_BASE_CSV | `Set-Location -LiteralPath 'D:\Base CSV\Scripts\TICKSTORE_R9_DEV\WORK_R9_FULL_RELEASE_RC1'` |
| `candidate/full/README_R9.md:162` | DOC_OR_RECEIPT | PRODUCTION_D_BASE_CSV | `& git -C 'D:\Base CSV\Scripts' diff --check -- 'TICKSTORE_R9_DEV/WORK_R9_FULL_RELEASE_RC1'` |
| `candidate/full/README_R9.md:175` | DOC_OR_RECEIPT | PRODUCTION_D_BASE_CSV | `$tickstoreEmptyFile = Join-Path 'D:\Base CSV\Scripts\TICKSTORE_R9_DEV\WORK_R9_FULL_RELEASE_RC1' (` |
| `candidate/full/README_R9.md:181` | DOC_OR_RECEIPT | PRODUCTION_D_BASE_CSV | `$tickstoreTextPath = Join-Path 'D:\Base CSV\Scripts\TICKSTORE_R9_DEV\WORK_R9_FULL_RELEASE_RC1' $tickstoreFile` |
| `candidate/full/SPEC_FULL_RUNNER_V001.md:133` | DOC_OR_RECEIPT | OTHER | `ancestor rename attempts and OneDrive/antivirus locks.` |
| `candidate/full/SPEC_FULL_RUNNER_V001.md:320` | DOC_OR_RECEIPT | OTHER | `OneDrive/antivirus observations and resource instrumentation.` |
| `procedures/PROCEDIMENTO_CDT21_LEGACY_ENTRY_FENCE.md:30` | DOC_OR_RECEIPT | OTHER | `Use PowerShell 5.1 **elevado**, a partir de 'C:\Users\silvi', com o Python fixado e o diretório 'adapter' instalado do V004:` |
| `procedures/PROCEDIMENTO_CDT21_LEGACY_ENTRY_FENCE.md:33` | DOC_OR_RECEIPT | PINNED_PYTHON,PRODUCTION_D_BASE_CSV | `& 'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe' -I -B <V004>\implementation_v001\candidate\control\LEGACY_ENTRY_FENCE.py --state` |
| `procedures/PROCEDIMENTO_OPERACIONAL_GATES.md:6` | DOC_OR_RECEIPT | OTHER | `- Todos os comandos rodam em 'PS C:\Users\silvi>', sem 'cd'.` |
| `procedures/PROCEDIMENTO_OPERACIONAL_GATES.md:7` | DOC_OR_RECEIPT | PINNED_PYTHON | `- 'PY' = 'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe' (SHA fixado).` |
| `procedures/PROCEDIMENTO_OPERACIONAL_GATES.md:9` | DOC_OR_RECEIPT | LOG_ROOT | `- Logs: cada ferramenta grava em 'C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS\<MODO>_<yyyyMMdd_HHmmss_fff>_<PID>\RUN_LOG.txt'.` |
| `candidate/recovery/review/base_b6_v004_candidate.py:1800` | REVIEW_HISTORY | PRODUCTION_D_BASE_CSV | `protected=(norm(r"D:\TICKSTORE"),norm(r"D:\TICKSTORE_GATE_B_SCRATCH"),norm(r"D:\Base CSV\WIN@N"))` |
| `candidate/recovery/review/base_b6_v004_release.py:1800` | REVIEW_HISTORY | PRODUCTION_D_BASE_CSV | `protected=(norm(r"D:\TICKSTORE"),norm(r"D:\TICKSTORE_GATE_B_SCRATCH"),norm(r"D:\Base CSV\WIN@N"))` |
| `candidate/recovery/review/base_v005_candidate.py:1894` | REVIEW_HISTORY | PRODUCTION_D_BASE_CSV | `protected=(norm(r"D:\TICKSTORE"),norm(r"D:\TICKSTORE_GATE_B_SCRATCH"),norm(r"D:\Base CSV\WIN@N"))` |
| `candidate/recovery/review/base_v005_release.py:1894` | REVIEW_HISTORY | PRODUCTION_D_BASE_CSV | `protected=(norm(r"D:\TICKSTORE"),norm(r"D:\TICKSTORE_GATE_B_SCRATCH"),norm(r"D:\Base CSV\WIN@N"))` |
| `candidate/recovery/tests_release/tickstore_publisher_recovery_v004.py:2447` | REVIEW_HISTORY | PRODUCTION_D_BASE_CSV | `protected=(norm(r"D:\TICKSTORE"),norm(r"D:\TICKSTORE_GATE_B_SCRATCH"),norm(r"D:\Base CSV\WIN@N"))` |
| `tests/fixtures/RC1R1_HISTORICAL/tickstore_publisher_recovery_v004_candidate.E9980324.py.txt:2433` | REVIEW_HISTORY | PRODUCTION_D_BASE_CSV | `protected=(norm(r"D:\TICKSTORE"),norm(r"D:\TICKSTORE_GATE_B_SCRATCH"),norm(r"D:\Base CSV\WIN@N"))` |
| `tests/fixtures/RC1R1_HISTORICAL/tickstore_publisher_recovery_v004_release.BFC44DA9.py.txt:2433` | REVIEW_HISTORY | PRODUCTION_D_BASE_CSV | `protected=(norm(r"D:\TICKSTORE"),norm(r"D:\TICKSTORE_GATE_B_SCRATCH"),norm(r"D:\Base CSV\WIN@N"))` |

## 5. Tests and status documents

Counts come from an AST scan: `def test*` methods in classes plus module-level `test*` functions. Script-style files (0) run their own asserts in `__main__`. Total: **1069** test functions in 79 files. The `recovery/tests` and `recovery/tests_release` trees duplicate each other (101 each).

| Test file | Tests | Covers (candidate modules imported or named) |
|---|---|---|
| `tests/cdt16_c5_unit_g5_fixture.py` | 0 | `control/G5_EVIDENCE_BUILDER.py` |
| `tests/g5_native_fixture.py` | 0 | `SUPPORT/FULL_QUALIFICATION_CONTRACT.py`, `control/FULL_QUALIFICATION_CONTRACT.py` |
| `tests/test_b07_technical_producer.py` | 21 | `b07/B07_CHECK_RUNNERS.py`, `control/B07_TECHNICAL_PRODUCER.py`, `control/D4_FIRST_ADMISSION_TRANSACTION.py`, `control/POLICY_CAPTURE_BINDING.py` |
| `tests/test_b1_distributed_approved_integration.py` | 14 | `SUPPORT/FULL_QUALIFICATION_CONTRACT.py`, `control/B1_DISTRIBUTED_CONTRACT_CONSUMER.py`, `control/FULL_QUALIFICATION_CONTRACT.py` |
| `tests/test_b2c_policy_capture_binding.py` | 19 | - |
| `tests/test_b2d_origin_decision_binder.py` | 29 | - |
| `tests/test_canary_receipt_readback.py` | 13 | `control/FULL_STAGE_CONTINUATION.py` |
| `tests/test_cdt16_delete_share_denial.py` | 7 | - |
| `tests/test_cdt16_held_rename_failure.py` | 4 | - |
| `tests/test_cdt16_native_pin_contract.py` | 2 | `full/tickstore_serial_runner.py` |
| `tests/test_cdt17_b1_formal_admission.py` | 10 | `SUPPORT/FULL_QUALIFICATION_CONTRACT.py`, `control/B1_FORMAL_ADMISSION.py`, `control/FULL_QUALIFICATION_CONTRACT.py` |
| `tests/test_cdt17_final_binder_bridge.py` | 7 | `control/ORIGIN_DECISION_BINDER.py` |
| `tests/test_cdt17_final_g5_complete_proof_gate.py` | 13 | `control/FULL_G5_COMPLETE_PROOF_GATE.py` |
| `tests/test_cdt17_full_composition_scope.py` | 15 | `control/G5_C6_FORMAL_CONTRACT.py` |
| `tests/test_cdt18_pre_g06_v003_d4_technical_bridge.py` | 7 | `control/D4_FIRST_ADMISSION_TRANSACTION.py`, `control/FULL_G5_COMPLETE_PROOF_GATE.py` |
| `tests/test_cdt18_r25_review_binding.py` | 8 | `control/FULL_RELEASE_CHAIN.py`, `control/RC1R1_SUCCESSOR_MIGRATION.py` |
| `tests/test_cdt18_stage_proof_integrated_reconcile.py` | 5 | `control/D4_FIRST_ADMISSION_PREP.py`, `control/FULL_RELEASE_CHAIN.py`, `control/FULL_STAGE_EVIDENCE.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py` |
| `tests/test_cdt19_durable_barrier_contract.py` | 15 | `g5proof/PRE_G06_NATIVE_SCENARIOS.py` |
| `tests/test_cdt19_final_completeness_contract.py` | 6 | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `full/FULL_CRASH_RECOVERY.py`, `g5proof/PRE_G06_CAMPAIGN.py`, `g5proof/PRE_G06_COMPLETENESS.py` |
| `tests/test_cdt19_final_transport_closure.py` | 20 | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `full/FULL_CRASH_RECOVERY.py`, `g5proof/PRE_G06_CAMPAIGN.py`, `g5proof/PRE_G06_PROOF_PROJECTION.py` |
| `tests/test_cdt19_g6_ownership_closure.py` | 8 | `control/FULL_LIFECYCLE.py`, `full/FULL_CRASH_RECOVERY.py` |
| `tests/test_cdt19_instance_binding.py` | 3 | `control/D4_FIRST_ADMISSION_BOOTSTRAP.py`, `control/FULL_INSTANCE_PREPARE.py` |
| `tests/test_cdt19_integrated_crash_recovery.py` | 11 | `adapter/runtime_locator_orchestrator_entry.py`, `control/FULL_G3_INTERRUPTION.py`, `control/FULL_STAGE_CONTINUATION.py`, `full/FULL_CRASH_RECOVERY.py` |
| `tests/test_cdt19_native_campaign_contract.py` | 13 | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `full/FULL_CRASH_RECOVERY.py`, `g5proof/G5_MULTIWORK_SCENARIOS.py`, `g5proof/PRE_G06_CAMPAIGN.py`, `g5proof/PRE_G06_CONSUMERS.py`, `g5proof/PRE_G06_PROOF_PROJECTION.py` |
| `tests/test_cdt19_r04_evidence_contract.py` | 9 | - |
| `tests/test_cdt19_r04_native_integration_gate.py` | 4 | - |
| `tests/test_cdt19_r04_preb06_g6.py` | 13 | - |
| `tests/test_cdt19_r06_integrated_contract.py` | 7 | `control/FULL_G5_COMPLETE_PROOF_GATE.py` |
| `tests/test_cdt19_r07_g3_g6_integrated_causality.py` | 14 | `control/FULL_LIFECYCLE.py`, `full/FULL_CRASH_RECOVERY.py`, `full/tickstore_full_multiwork.py`, `g5proof/PRE_G06_NATIVE_SCENARIOS.py` |
| `tests/test_cdt20_pre_g06_integrated_closure.py` | 17 | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/ORIGIN_DECISION_BINDER.py`, `full/FULL_CRASH_RECOVERY.py`, `g5proof/PRE_G06_CAMPAIGN.py`, `g5proof/PRE_G06_COMPLETENESS.py` |
| `tests/test_cdt21_f01_legacy_entry_fence.py` | 30 | `adapter/INLINE_ROOT_LOADER_V004_R1R1_ADAPTER.ps1`, `adapter/Launch-TickstoreBundle-Adapter.ps1`, `adapter/runtime_locator_adapter.py`, `adapter/runtime_locator_inline_entry.py`, `adapter/runtime_locator_orchestrator_entry.py`, `recovery/modules/orchestrator.py`, `recovery/tests_release/tickstore_publisher_recovery_v004.py` |
| `tests/test_cdt21_f01r1_preexisting_legacy_cut.py` | 16 | - |
| `tests/test_full_postverify_readback.py` | 17 | `control/FULL_LIFECYCLE.py` |
| `tests/test_full_runner_observability_r41.py` | 14 | `control/FULL_RUNNER.py`, `full/FULL_OBSERVABILITY.py` |
| `tests/test_fused_sandbox_writer.py` | 18 | `control/MENU_TX_FUSED_SANDBOX.py`, `control/MENU_TX_INTERPROCESS_SANDBOX.py`, `control/TX_SANDBOX_MODEL.py` |
| `tests/test_g5_evidence_builder.py` | 43 | `control/FULL_RELEASE_CHAIN.py`, `control/G5_EVIDENCE_BUILDER.py` |
| `tests/test_g5_producer_consumer_roundtrip.py` | 4 | `control/FULL_G5_COMPLETE_PROOF_GATE.py`, `control/G5_FINAL_COMPLETENESS_PRODUCER.py` |
| `tests/test_g5_proof_runner_contract.py` | 3 | - |
| `tests/test_gate_chain_procedures.py` | 11 | `control/B06_RECEIPT_CHECK.py`, `control/FULL_INSTANCE_PREPARE.py`, `control/FULL_RELEASE_CHAIN.py`, `control/FULL_STAGE_CONTINUATION.py`, `full/tickstore_full_multiwork.py`, `full/tickstore_serial_runner.py` |
| `tests/test_installer_intent.py` | 18 | `control/MENU_INSTALL_INTENT_VERIFY.py` |
| `tests/test_installer_legacy_activation_prune.py` | 12 | - |
| `tests/test_integrated_evidence_contract.py` | 22 | - |
| `tests/test_intent_to_transaction_sandbox.py` | 16 | `control/MENU_INSTALL_INTENT_VERIFY.py`, `control/MENU_INTENT_TO_TX_SANDBOX.py`, `control/TX_SANDBOX_MODEL.py` |
| `tests/test_lab_powerloss.py` | 15 | - |
| `tests/test_legacy_entry_isolation.py` | 9 | `full/tickstore_full_multiwork.py` |
| `tests/test_menu_tx_interprocess.py` | 17 | `control/MENU_INSTALL_INTENT_VERIFY.py`, `control/MENU_INTENT_TO_TX_SANDBOX.py`, `control/MENU_TX_INTERPROCESS_SANDBOX.py`, `control/TX_SANDBOX_MODEL.py` |
| `tests/test_native_process_control_r41.py` | 5 | `full/FULL_CRASH_RECOVERY.py`, `full/FULL_PROCESS_CONTROL.py`, `full/tickstore_full_multiwork.py`, `full/tickstore_serial_runner.py` |
| `tests/test_official_target_readonly_admission.py` | 16 | - |
| `tests/test_official_writer_contract.py` | 40 | `control/MENU_OFFICIAL_ADMISSION_READONLY.py`, `control/MENU_OFFICIAL_WRITER_CONTRACT_SOURCE_ONLY.py` |
| `tests/test_official_writer_effectful.py` | 27 | `control/MENU_INSTALL_INTENT_VERIFY.py`, `control/MENU_OFFICIAL_WRITER.py` |
| `tests/test_operator_entry_points.py` | 11 | `control/D4_FIRST_ADMISSION_PREP.py`, `control/FULL_RUNNER.py`, `control/FULL_STAGE_CONTINUATION.py` |
| `tests/test_pre_g06_d4_real_runtime_isolated.py` | 4 | - |
| `tests/test_rc1r1_recertification.py` | 9 | `full/test_full_serial_r9.py`, `full/tickstore_serial_runner.py` |
| `tests/test_rc1r1_successor_migration.py` | 15 | `control/FULL_RELEASE_CHAIN.py`, `control/RC1R1_SUCCESSOR_MIGRATION.py` |
| `tests/test_sandbox_admission.py` | 9 | - |
| `tests/test_scratch_powerloss_debris.py` | 1 | - |
| `tests/test_stage_canary_physical_publication.py` | 7 | `control/D4_FIRST_ADMISSION_PREP.py`, `control/FULL_STAGE_CONTINUATION.py`, `control/FULL_STAGE_EVIDENCE.py` |
| `tests/test_stageb_full_physical_closure.py` | 12 | `control/D4_FIRST_ADMISSION_PREP.py`, `control/FULL_LIFECYCLE.py`, `control/FULL_STAGE_CONTINUATION.py` |
| `tests/test_state_cas_recovery.py` | 11 | `control/STATE_CAS_RECOVERY.py` |
| `candidate/full/test_enospc_matrix_r4.py` | 0 | `full/tickstore_serial_runner.py` |
| `candidate/full/test_filesystem_alias_r3.py` | 0 | `full/tickstore_serial_runner.py` |
| `candidate/full/test_full_multiwork.py` | 38 | `full/test_full_serial_r9.py`, `full/tickstore_full_multiwork.py`, `full/tickstore_serial_runner.py` |
| `candidate/full/test_full_serial_r9.py` | 43 | `full/tickstore_serial_runner.py` |
| `candidate/full/test_gate_b_r8.py` | 0 | `full/tickstore_serial_runner.py` |
| `candidate/full/test_r3_additional_regressions.py` | 0 | `full/tickstore_serial_runner.py` |
| `candidate/full/test_runner_adversarial_r3.py` | 11 | `full/tickstore_serial_runner.py` |
| `candidate/full/test_runner_logic.py` | 0 | `full/tickstore_serial_runner.py` |
| `candidate/full/test_windows_create_new_mapping_r7.py` | 0 | `full/tickstore_serial_runner.py` |
| `candidate/recovery/tests/test_c3_job_topology_microfix.py` | 8 | `recovery/tests_release/tickstore_publisher_recovery_v004.py` |
| `candidate/recovery/tests/test_native_rename_v004r2r1.py` | 25 | `recovery/tests_release/tickstore_publisher_recovery_v004.py` |
| `candidate/recovery/tests/test_precanary_completeness_v005.py` | 38 | `recovery/tests_release/test_publisher_recovery_v004.py`, `recovery/tests_release/tickstore_publisher_recovery_v004.py` |
| `candidate/recovery/tests/test_publisher_recovery_v004.py` | 29 | `recovery/tests_release/tickstore_publisher_recovery_v004.py` |
| `candidate/recovery/tests/test_s0_cert_path_association_microfix.py` | 1 | `recovery/tests_release/tickstore_publisher_recovery_v004.py` |
| `candidate/recovery/tests_release/test_c3_job_topology_microfix.py` | 8 | `recovery/tests_release/tickstore_publisher_recovery_v004.py` |
| `candidate/recovery/tests_release/test_native_rename_v004r2r1.py` | 25 | `recovery/tests_release/tickstore_publisher_recovery_v004.py` |
| `candidate/recovery/tests_release/test_precanary_completeness_v005.py` | 38 | `recovery/tests_release/test_publisher_recovery_v004.py`, `recovery/tests_release/tickstore_publisher_recovery_v004.py` |
| `candidate/recovery/tests_release/test_publisher_recovery_v004.py` | 29 | `recovery/tests_release/tickstore_publisher_recovery_v004.py` |
| `candidate/recovery/tests_release/test_s0_cert_path_association_microfix.py` | 1 | `recovery/tests_release/tickstore_publisher_recovery_v004.py` |
| `candidate/adapter/adapter_tests.py` | 29 | `adapter/INLINE_ROOT_LOADER_V004_R1R1_ADAPTER.ps1`, `adapter/Launch-TickstoreBundle-Adapter.ps1`, `adapter/runtime_locator_adapter.py`, `adapter/runtime_locator_inline_entry.py`, `adapter/runtime_locator_orchestrator_entry.py`, `recovery/tests_release/tickstore_publisher_recovery_v004.py` |

Tests that do **not** exist: no test calls `FULL_D4_CLOSURE.close_d4` or publishes a D4 stage receipt (GAP-01). No test runs `Launch-TickstoreBundle-Adapter.ps1` or checks its pinned entry hash against the binding (GAP-03). No test checks the wrapper parameter set against `FULL_RUNNER.D4_PARAMETERS` (GAP-02). No test reconciles the migration ZIP digest with the bootstrap digest (GAP-04).

### 5.1 Status documents: native vs SOURCE_ONLY/Linux claims

**`CDT21_V004_ENGINEERING_COMPLETENESS.json`**

- `schema`: TICKSTORE_CDT21_V004_ENGINEERING_COMPLETENESS_V001
- `status`: ENGINEERING_DELTA_COMPLETE__WINDOWS_NATIVE_QUALIFICATION_PENDING
- `runtime_code_manifest_sha256`: D2C626FD... (matches current RUNTIME_CODE_MANIFEST.json)
- `native_windows_claims`: none: tested_equals_packaged_new_final_code=LINUX_PASS__WINDOWS_TARGET_RUNTIME_PENDING; all_known_fixable_blockers_closed=PASS_IN_CODE_F01R1__NATIVE_PROOF_PENDING
- `source_or_linux_claims`: all_implementations_integrated=PASS_SOURCE_AND_LINUX; adversarial check PASS_STATEMENTS_BOUNDED
- `not_claimed`: Windows native PASS, G5 of V003 transferred to V004, B06/B07/D4/D5/canary/FULL, physical power loss, cut installed in production
- `open`: frozen_for_independent_audit requires native V004 G0 PASS, origin admission, origin decision on a V004 G5 campaign, independent B06; producer_five_part_receipt_v004 NOT_ISSUED; physical_powerloss NOT_TESTED_PHYSICAL_POWERLOSS

**`FULL_COMPOSITION_EVIDENCE.json`**

- `schema`: TICKSTORE_CDT17_FULL_COMPOSITION_EVIDENCE_V001
- `status`: INTEGRATED_SOURCE_CANDIDATE_NOT_RELEASED
- `native`: owner_g5_native_receipt_status PASS_PRIOR_PARENT_SCOPE_ONLY; tested_equals_packaged NOT_PROVEN_WINDOWS
- `five_part`: all_implementations_integrated NOT_PROVEN, all_known_fixable_blockers_closed NOT_PROVEN, frozen NO, adversarial PASS_SANDBOX_SCOPED_GUARD_ONLY
- `known_critical`: ORIGINAL_G5_RECEIPT_BINDS_OLD_CODE_MANIFEST, NEW_FIVE_G5_MODULES_HAVE_NO_NATIVE_WIN_PROOF_IN_FUSED_TREE, POST_G5_CHAIN_NOT_ADMITTED_WITH_NEW_CODE_MANIFEST, PRE_B06_STATE_RECREATION_CONFIG_TOCTOU_RECEIPT_OVERWRITE_CHECKPOINT_FAILURE_UNRESOLVED_IN_EVIDENCE, TECHNICAL_OWNER_GATE_LEGACY_CONSUMERS_REQUIRE_RECONCILIATION
- `staleness`: CDT17-era: listed module digests differ from current bytes (GAP-09)

**`CDT17_FINAL_ENGINEERING_INTEGRATION_STATUS.json`**

- `schema`: TICKSTORE_CDT17_INTEGRATED_ENGINEERING_RECONCILIATION_V001
- `release_state`: INTEGRATED_ENGINEERING_SOURCE_ONLY_NOT_READY_FOR_FORMAL_B06
- `b06`: NOT_STARTED
- `full_started`: False
- `production_modified`: False
- `five_part`: adversarial PARTIAL_SOURCE_ONLY; integrated NOT_PROVEN; blockers NOT_PROVEN; NOT_FROZEN_FOR_B06; tested_equals_packaged LOCAL_SOURCE_AND_ARCHIVE_ONLY_NATIVE_WINDOWS_PENDING
- `native`: prior_evidence_retained win_critical_9 / win_full_fusion_r0 / win_g5_29 = PASS_PRIOR_SCOPED_CODE_ONLY
- `staleness`: runtime_members 147 and manifest 43738755... (current 163 / D2C626FD...)

**`README_FIRST.txt`**

- `content`: CDT17 integrated G5 final completeness guard (SOURCE_ONLY); previous G5 29/29 and critical 9/9 Windows scoped PASS bound to their exact bytes; not a complete FULL release; no B06/B07/D4/D5/canary/FULL issued; five-part completion and final native qualification open; production not mutated.
- `staleness`: Refers to a CDT17 launcher not in package; does not describe V004/F01R1.

Native evidence in the package (`NATIVE_EVIDENCE_IMMUTABLE/WIN_CRITICAL_9_RETURN.zip`, `WIN_FULL_FUSION_R0_RETURN.zip`, `WIN_G5_CURRENT_29_RETURN.zip`, `G5_APPROVED_INPUTS/*.zip`) covers prior code only. Every V004 claim is SOURCE_ONLY or Linux; the Windows G0 qualification of V004 is pending.

## 6. Gaps

### GAP-01 [CRITICAL] D4 stage receipt can never be published (D4Close always blocks)

- candidate/control/FULL_D4_CLOSURE.py:158-167 calls publish('D4', ..., checks=..., extra=...) without check_proofs
- candidate/control/FULL_STAGE_EVIDENCE.py:97,100-101 publish() requires isinstance(check_proofs, dict) and set(check_proofs)==set(checks) -> Blocked STAGE_CHECK_PROOF_EXACT_SET
- candidate/control/FULL_STAGE_EVIDENCE.py:46-63 STAGE_CHECK_WITNESSES has no "D4" entry, so even with proofs :105 would raise KeyError
- Reproduced by calling FULL_STAGE_EVIDENCE.publish with the exact keyword set of close_d4 on COPIES of the three modules (scratchpad/inv_work/sim): result "Blocked STAGE_CHECK_PROOF_EXACT_SET" before any write
- No test calls close_d4 / FULL_D4_CLOSURE (grep over tests/, qual/, g5proof/); no packaged native evidence exercises it
- **Why it matters:** FULL_RUNNER D4 (auto-close after wrapper exit 0, FULL_RUNNER.py:193-195) and D4Close (:185-187) fail after D4 effects; the chain cannot be extended beyond B07 by candidate code, so D5, CANARY, FULL_PREP, FULL_ADMISSION and FULL are unreachable end to end.

### GAP-02 [CRITICAL] Menu/FULL_RUNNER D4 dispatch omits two inputs the sealed wrapper requires

- candidate/control/FULL_RUNNER.py:17-22 D4_PARAMETERS (12 names) and d4_command :25-44 never pass -G5StageReceiptPath / -G5InstancePath
- candidate/control/60_EFFECTFUL_WRAPPER_RELEASE.ps1:8-9 declares them (default ''), :279-281 requires them non-empty -> FIRST_ADMISSION_REQUIRED_INPUT_MISSING; :303 forwards them as --g5-stage-receipt/--g5-instance
- candidate/control/D4_FIRST_ADMISSION_BOOTSTRAP.py:259-262 marks --g5-stage-receipt and --g5-instance required
- procedures/TEMPLATE_INSTANCE_INPUTS.json d4_parameters lacks both; no .py/.json/.md in the package mentions G5StageReceiptPath/G5InstancePath outside the wrapper
- **Why it matters:** Both D4 first admission and D4 resume (-ResumeAdmittedRun runs the same boundary, wrapper :483) fail closed before any effect when launched from the menu or RUN_TICKSTORE_FULL.ps1. Fail-closed, but the operational D4 path is not integrated.

### GAP-03 [HIGH] Adapted child-bundle launcher pins an inline-entry hash that matches no packaged file

- candidate/adapter/Launch-TickstoreBundle-Adapter.ps1:17,23 ExpectedAdapterEntry=9DEE7D6CFD075E042CA09B51B6FB05944488CE416690F4371764F732E6EDD9ED; throws ADAPTER_INLINE_ENTRY_HASH_MISMATCH otherwise (also passed to loader :35 -> INLINE_ROOT_LOADER_V004_R1R1_ADAPTER.ps1:215-217)
- candidate/adapter/runtime_locator_adapter.py:475-481 requires runtime_locator_inline_entry.py == binding inline_entry_sha256 and :576-581 passes that same file as -AdapterEntryPath
- candidate/adapter/RUNTIME_LOCATOR_ADAPTER_BINDING.json:11 inline_entry_sha256=9BFFE835... == manifest sha of adapter/runtime_locator_inline_entry.py; 9DEE7D6C... occurs nowhere else in the package (also not as LF/CRLF/BOM variant)
- Binding adapted_launch_sha256 (2732AFB3...) pins this exact launcher, so both pins are sealed together; no test or packaged native evidence executes the adapted launcher
- **Why it matters:** Every target-generation bundle launch (CERTIFY_SCRATCH in D4; CERTIFY_CANONICAL/MANIFEST_REDERIVATION/LIVE_EQUALITY/RECOVER/STALE_LOCK after D4, runtime_locator_adapter.py:515-518) would fail closed. Statically certain for byte hashes; native execution UNVERIFIED.

### GAP-04 [HIGH] Contradictory identities for the D4 successor package ZIP

- candidate/control/RC1R1_SUCCESSOR_MIGRATION.py:36-37,97,144-154,226-230: artifacts\TICKSTORE_V004R1_D4_RESUMABLE_V002R24_PACKAGE.zip must hash 8A05E76189E6...
- candidate/control/60_EFFECTFUL_WRAPPER_RELEASE.ps1:139,154,298 passes the same path; candidate/control/D4_FIRST_ADMISSION_BOOTSTRAP.py:154 requires it to hash CAC345D321E0...
- procedures/PROCEDIMENTO_OPERACIONAL_GATES.md step 8b still names V002R22 -> V002R23 and TICKSTORE_V004R1_D4_RESUMABLE_V002R23_PACKAGE.zip, while code uses V002R24
- **Why it matters:** After the documented migration the D4 bootstrap blocks with SHA_MISMATCH on the package ZIP (or the migration blocks if the CAC345 ZIP is present). One of the two digests is stale.

### GAP-05 [HIGH] No producer for the fresh D4 predecessor observations

- candidate/control/D4_FIRST_ADMISSION_BOOTSTRAP.py:72-84 reads predecessor_observer/predecessor_evidence/OBSERVATION.json and predecessor_observer/PREDECESSOR_SYSTEM.json, requires age <= 300 s
- candidate/control/D4_PREDECESSOR_RECONCILIATION.py:19-20 expects schemas TICKSTORE_D4_PREDECESSOR_OBSERVATION_V001 / TICKSTORE_D4_PREDECESSOR_SYSTEM_OBSERVATION_V001
- No file in the package writes either schema (grep over candidate/, qual/, tests/, procedures/); only D4_ROOTS_REPORT.json has a producer (D4_ROOTS_EVIDENCE.py --out)
- **Why it matters:** D4 first admission depends on an external, unpackaged native observer that must run within 5 minutes before admission.

### GAP-06 [HIGH] No producer for TICKSTORE_D4_POLICY_ADMISSION_RECEIPT_V001

- Consumers: candidate/control/D4_FIRST_ADMISSION_TRANSACTION.py:91-105, 60_EFFECTFUL_WRAPPER_RELEASE.ps1:257, recovery/engine/tickstore_publisher_recovery_v004_release.py:1639
- POLICY_CAPTURE_BINDING.py:136 only lists the fields; procedures/PROCEDIMENTO_OPERACIONAL_GATES.md has no step producing PolicyAdmissionReceiptPath
- **Why it matters:** Required D4 input with no named producer or procedure step (consumer expects a schema nobody in the package writes).

### GAP-07 [MEDIUM] Operational G5 V003 completeness path not documented; procedure points at the V002 builder

- procedures/PROCEDIMENTO_OPERACIONAL_GATES.md step 1 names control/G5_EVIDENCE_BUILDER.py, which writes TICKSTORE_ENGINEERING_COMPLETENESS_V002 (G5_EVIDENCE_BUILDER.py:5,26)
- D4_FIRST_ADMISSION_BOOTSTRAP.py:204-205, D4_FIRST_ADMISSION_TRANSACTION.py:54-55 and FULL_G5_COMPLETE_PROOF_GATE.py:85-86 require V003 (written only by G5_FINAL_COMPLETENESS_PRODUCER.py:142)
- g5proof/PRE_G06_COMPLETENESS.py:124-131 runs the producer with a LAB instance (qualification_scope OWNED_ISOLATED_NTFS_PRE_B06), whose sha cannot equal the operational INSTANCE.json from FULL_INSTANCE_PREPARE (chain binds instance_sha256: FULL_RELEASE_CHAIN.py:57, FULL_G5_COMPLETE_PROOF_GATE.py:63-64,87-88)
- **Why it matters:** An operator following the procedure cannot produce an admissible G5; a manual re-run of G5_FINAL_COMPLETENESS_PRODUCER with the operational instance is needed (code supports it: producer only checks instance schema + code manifest, :78-80). UNVERIFIED end to end: no test builds a G5 on an operational instance.

### GAP-08 [MEDIUM] Log location does not follow the owner rule registered 2026-10-21; some operator tools have no fixed log; D4 output escapes RUN_LOG

- RUN_LOG_FIXED.py:20, RUN_TICKSTORE_FULL.ps1:24, INSTALL_TICKSTORE_FULL.ps1:15 use C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS; INSTALL_TICKSTORE_FULL.ps1:4 default witness folder C:\Users\silvi\OneDrive\Downloads; owner standard is C:\Users\silvi\Downloads\<FAMILIA>_RUNS\<MODO>_<yyyyMMdd_HHmmss_fff_PID>\RUN_LOG.txt
- No fixed RUN_LOG: LEGACY_ENTRY_FENCE.py:241-256 (--apply mutates production state dir), B07_CHECK_RUNNERS.py, G5_FINAL_COMPLETENESS_PRODUCER.py, D4_PREDECESSOR_RECONCILIATION.py, G5_C6_FORMAL_STAGE_BUILDER.py, MENU_OFFICIAL_ADMISSION_READONLY.py
- FULL_RUNNER.py:62 subprocess.call without redirection + 60_EFFECTFUL_WRAPPER_RELEASE.ps1:555 Write-Host: D4 wrapper output is not teed into RUN_LOG.txt (static inference)
- **Why it matters:** Logs are fixed and absolute (never cwd-derived), but in the superseded OneDrive location; operator evidence for the fence and B07 runs exists only on stdout.

### GAP-09 [MEDIUM] The candidate's own read-only verifier fails on these bytes; composition/status files are stale (CDT17)

- Ran implementation_v001/VERIFY_FULL_COMPOSITION_SOURCE_ONLY.py (pure reader: reads, hashes, ast.parse, prints) with python3 -I -B: "COMPOSITION_SOURCE_INTEGRITY=BLOCKED SOURCE_EXACT_SET", exit 2 (lines 17-19: SOURCE_MANIFEST.json, 317 entries, omits RUNTIME_CODE_MANIFEST.json)
- QUALIFY_COMPOSED_FULL_NATIVE.py runs that verifier first, so it would also fail
- FULL_COMPOSITION_EVIDENCE.json lists FULL_RELEASE_CHAIN 09D200B7..., FULL_G5_COMPLETE_PROOF_GATE 47E3932A..., ORIGIN_DECISION_BINDER 35C963C7...; current bytes are F687104C..., EC6D9B2D..., 44BB8396...
- CDT17_FINAL_ENGINEERING_INTEGRATION_STATUS.json: runtime_members 147 (current 163), ORIGIN_DECISION_BINDER new_sha256 DC6182C9... (current 44BB8396...), runtime_code_manifest_sha256 43738755... (current D2C626FD...)
- README_FIRST.txt (CDT17) instructs RUN_CDT17_FINAL_G5_COMPLETENESS_GUARD_DELTA_SOURCE_ONLY.ps1, which is not in the package
- **Why it matters:** Only CDT21_V004_ENGINEERING_COMPLETENESS.json and CDT21_V004_DELTA_RECEIPT.json describe these bytes (runtime manifest sha D2C626FD... matches).

### GAP-10 [MEDIUM] Executed producers/launchers not in the package or not in the runtime manifest

- Launchers RUN_TICKSTORE_CDT15_<REV>_QUAL.ps1 and RUN_TICKSTORE_CDT15_<REV>_B07.ps1 (procedure steps 0 and 6) are absent; no .ps1 exists outside candidate/
- b07/B07_CHECK_RUNNERS.py:176-180 imports qual/SANDBOX_ADMISSION.py and qual/R44D2_DROOT_AUDIT.py and :78 runs tests/test_official_writer_effectful.py, tests/test_native_process_control_r41.py - outside RUNTIME_CODE_MANIFEST (only PACKAGE_MANIFEST/SOURCE_MANIFEST bind them; B07 producer re-checks the two test digests against the FINAL ZIP)
- B07 requires the origin R3 archive (sha 2379512B...) and 4 overlay files (B07_TECHNICAL_PRODUCER.py:87-102), first-admission review pack with member revision_v38/FINAL_RUNTIME_CODE_MANIFEST.json (D4_FIRST_ADMISSION_BOOTSTRAP.py:117-125) - external
- **Why it matters:** These producers cannot be audited from these bytes; their integration is UNVERIFIED.

### GAP-11 [LOW] B06 verdict template is incompatible with the D4 verdict parser that must consume the same file

- B07 technical receipt binds review_verdict_sha256 = sha(B06 verdict) (B07_TECHNICAL_PRODUCER.py:266) and D4 requires it to equal the ReviewVerdictPath digest (D4_FIRST_ADMISSION_TRANSACTION.py:88-89)
- Engine _d4r_parse_verdict requires the only non key=value line to be TICKSTORE_D4_RESUMABLE_CODE_DELTA_REVIEW_V002R22 and the exact REVIEW_CHECKS key set (tickstore_publisher_recovery_v004_release.py:1297-1309)
- procedures/TEMPLATE_B06_VERDICT.txt has other free-text lines and placeholder keys only
- **Why it matters:** A verdict written from the template would fail REVIEW_VERDICT_HEADER at D4; template only (UNVERIFIED whether reviewers use it verbatim).

### GAP-12 [LOW] Duplicate module name FULL_QUALIFICATION_CONTRACT (SUPPORT/ vs control/)

- candidate/SUPPORT/FULL_QUALIFICATION_CONTRACT.py (28530 B) and candidate/control/FULL_QUALIFICATION_CONTRACT.py (29430 B); control = SUPPORT + evaluate_formal_g5_stage (diff after CRLF normalization)
- control/G5_C6_FORMAL_CONTRACT.py:7-8 prepends SUPPORT to sys.path, so the module bound depends on import order / sys.modules
- **Why it matters:** Functionally benign today (superset); UNVERIFIED for every import order.

### GAP-13 [LOW] D4Close runs non-elevated but queries native VSS and the process census

- RUN_TICKSTORE_FULL.ps1:133 skips elevation for Check/Monitor/D4Close
- FULL_D4_CLOSURE.py:133-139 NativeVSS + reconcile_generation + assert_present, :148 recovery_process_census
- **Why it matters:** UNVERIFIED: VSS queries normally need administrator rights; may block at D4Close (moot while GAP-01 exists).

### GAP-14 [INFO] Stale routing/version labels in runtime code

- THREAD labels Ticks 7/14/15/16/17/18 (60_EFFECTFUL_WRAPPER_RELEASE.ps1:113,127-129; Launch-TickstoreBundle-Adapter.ps1:11; run_tickstore_full_multiwork_r9.ps1:19; B1_DISTRIBUTED_*; B1_FORMAL_ADMISSION.py:33; RC1R1_SUCCESSOR_MIGRATION.py:49); POLICY_CAPTURE_BINDING.py:39 "Ticks 7" is frozen engine ABI
- V38/V002R22 identifiers kept as ABI (D4_FIRST_ADMISSION_BOOTSTRAP.py:123 revision_v38/, engine :1307 V002R22 header)
- No runtime reference to a V002/V003 package digest (V003 parent sha 69DA2D59... appears only in receipts/README)
- **Why it matters:** No functional effect found; noted for the origin auditor.

### GAP-15 [INFO] Dataset counts hard-coded in CANARY and FULL verification

- FULL_STAGE_CONTINUATION.py:194-204 and FULL_LIFECYCLE.py:27: days 1550, rows 7,049,522,162, namespace files 3101
- **Why it matters:** Any change of the certified ledger blocks CANARY/FULL closure (fail-closed by design).

### GAP-16 [INFO] No native evidence for V004 bytes

- NATIVE_EVIDENCE_IMMUTABLE/WIN_*.zip and G5_APPROVED_INPUTS/*.zip are prior scoped code only (CDT17 status prior_evidence_retained = PASS_PRIOR_SCOPED_CODE_ONLY)
- CDT21_V004_ENGINEERING_COMPLETENESS.json: tested_equals_packaged LINUX_PASS__WINDOWS_TARGET_RUNTIME_PENDING; producer_five_part_receipt_v004 NOT_ISSUED
- None of the packaged native returns contains Launch-TickstoreBundle-Adapter, D4 closure publication or G5StageReceiptPath usage
- **Why it matters:** G5 for V004 cannot pass FULL_G5_COMPLETE_PROOF_GATE until a native campaign on the exact FINAL zip exists (expected state, not a code defect).

