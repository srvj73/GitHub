# P4 — Gates seguintes, do G5 operacional ao FULL (preparado; não executado)

**Fonte normativa:** `implementation_v001/procedures/PROCEDIMENTO_OPERACIONAL_GATES.md` do V005. A seção “CDT21 V005 — correções de integração da cadeia” prevalece sobre o texto anterior a ela. Este P4 resume a ordem, os pré-requisitos e quem executa cada etapa; ele não autoriza etapa alguma.

**Convenções do procedimento congelado:**
- execução a partir de `PS C:\Users\silvi>`, sem `cd`;
- `PY` = Python 3.14 fixado por SHA;
- `CAND` = `implementation_v001\candidate` da instalação ativa;
- todo digest marcado como “à parte” é digitado separadamente pelo operador.

## Ordem e responsáveis

| # | Etapa | Quem | Pré-requisito | Observação V005 |
|---|---|---|---|---|
| 0 | G5 técnico nativo do V005 | titular (P1) → Opus (P3) | — | única prova nativa desta entrega |
| — | Instalação do V005 (não é admissão) | titular | P1 PASS (recomendado) | ver “Instalação” abaixo; resultado `INSTALLED_NOT_PRODUCTION_ADMISSION` em `%LOCALAPPDATA%\TICKSTORE\Candidates\<sha do pacote>` |
| 2 | `INSTANCE.json` operacional | titular | — | `FULL_INSTANCE_PREPARE.py prepare` |
| 1 | Completude G5 V003 sobre a instância operacional | titular | P1 PASS + etapa 2 | comando `G5_FINAL_COMPLETENESS_PRODUCER.py` da seção V005, item 1 |
| 3 | Decisão G5 | **origem** | completude + pacote G5 | `TEMPLATE_ORIGIN_STAGE_DECISION.json` |
| 3b | Recibo de estágio G5 | titular | decisão + reconciliação de política corrente (origem) | `ORIGIN_DECISION_BINDER.py --stage G5` |
| 4 | B06 | **Work independente** | despacho do Opus (P3) | veredito exatamente no `TEMPLATE_B06_VERDICT.txt` |
| 4b, 5 | Conformidade B06 e cadeia até B06 | titular | B06 | `B06_RECEIPT_CHECK.py`; `FULL_INSTANCE_PREPARE.py chain --until B06` |
| 6 | Verificações nativas B07 | titular no Windows | cadeia até B06; **2 overlays derivados fornecidos pela origem** (`E74F3701…`, `40B396FC…`, GAP-10); launcher B07 montado pelo Opus no despacho | o pacote QUAL está em `B1_APPROVED_INPUTS` do V005 |
| 7, 7b, 8 | Decisão B07 (origem), recibo B07 e cadeia até B07 | origem + titular | B07 técnico | — |
| — | Ativação oficial do menu | titular | cadeia até B07 | `INSTALL_TICKSTORE_FULL.ps1 -ActivateMenu -ChainFile … -ChainSha256 … -B06Sha256 …` |
| — | LEGACY_ENTRY_FENCE | titular | cadeia até B07 | `PROCEDIMENTO_CDT21_LEGACY_ENTRY_FENCE.md` |
| 8b | Migração do sucessor D4 (V002R22 → V002R24) | titular | cadeia até B07 | ZIP com identidade única `8A05E76189E63379A60E2447DAA313765D30A2EAB78EAF4E9D91AA19CBFE3E73`; a Q do P1 já informa o arquivo físico |
| — | Entradas do D4 emitidas pela origem | **origem** | B07 | recibo `TICKSTORE_D4_POLICY_ADMISSION_RECEIPT_V001` (`TEMPLATE_D4_POLICY_ADMISSION_RECEIPT.json`), pacote de revisão D4 e reconciliação corrente |
| — | Observação nativa do predecessor D4 (no máximo 300 s antes da admissão) | Opus prepara o observador somente leitura; titular executa | B07 + autorização de preparação do D4 | contrato na seção V005, item 4 (GAP-05) |
| 9 | D4 | titular | todas as linhas acima | MENU opção 10 ou `RUN_TICKSTORE_FULL.ps1 -Stage D4`; o `FULL_RUNNER` passa ao wrapper o recibo G5 e a instância da cadeia (GAP-02); `D4Close` publica o recibo D4 (GAP-01) |
| 10–12 | D5, CANARY, FULL_PREP | titular | recibo anterior + reconciliação | `MENU` → etapa |
| 13 | Revisão Stage B + `FULL_GO` | revisor/origem | FULL_PREP | `inbox\STAGE_B_REVIEW_V001.txt`, `inbox\FULL_GO.txt` |
| 14 | FULL_ADMIT | titular | FULL_PREP + revisão | recibo válido por 300 s; `FULL_READMIT` reemite |
| 15 | FULL | titular | FULL_ADMISSION fresca | MULTIWORK/AUTOCPU, heartbeat, ETA, Monitor somente leitura, `Stop` cooperativo |

## Instalação (instalador congelado do V005)

O instalador congelado está dentro do ZIP (`implementation_v001/candidate/control/INSTALL_TICKSTORE_FULL.ps1`, SHA-256 `BB245FCF2530534BAF7E5CD4984DE791CC522F6B3B8C9D02B3B9BBF061E03C43`, no `RUNTIME_CODE_MANIFEST`). Ele não depende da pasta onde está. A partir de `PS C:\Users\silvi>`:

```powershell
Add-Type -AssemblyName System.IO.Compression.FileSystem
$z=[IO.Compression.ZipFile]::OpenRead("C:\Users\silvi\Downloads\CDT21_FINAL_PACKAGE_V005_20261022.zip")
[void](New-Item -ItemType Directory -Path "C:\Users\silvi\Downloads\CDT21_INSTALADOR_V005" -Force)
[IO.Compression.ZipFileExtensions]::ExtractToFile($z.GetEntry('implementation_v001/candidate/control/INSTALL_TICKSTORE_FULL.ps1'),"C:\Users\silvi\Downloads\CDT21_INSTALADOR_V005\INSTALL_TICKSTORE_FULL.ps1",$false)
$z.Dispose()
(Get-FileHash -Algorithm SHA256 "C:\Users\silvi\Downloads\CDT21_INSTALADOR_V005\INSTALL_TICKSTORE_FULL.ps1").Hash
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\silvi\Downloads\CDT21_INSTALADOR_V005\INSTALL_TICKSTORE_FULL.ps1" -WitnessPath "C:\Users\silvi\Downloads\WITNESS_TICKSTORE_FULL_FINAL_V005_20261022.json"
```

**Antes de executar o instalador:**
- o hash impresso deve ser `BB245FCF…C43`; se for outro, pare;
- o ZIP precisa estar na mesma pasta da testemunha.

**Comportamento do instalador:**
- `-WitnessPath` evita o padrão legado `C:\Users\silvi\OneDrive\Downloads` e o bloqueio por cardinalidade quando há testemunhas antigas na pasta;
- confere a testemunha, o SHA do ZIP, o `PACKAGE_MANIFEST`, o CRC e o Python fixado;
- instala por criação nova, com releitura de cada membro;
- grava o log em `C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS\INSTALL_<carimbo>_<PID>\RUN_LOG.txt` (raiz congelada, GAP-08).

A ativação do menu (`-ActivateMenu`) exige a cadeia até B07.

## Regras

- **Retornos:**
  - prova nativa → Opus;
  - fechamento consolidado → ChatGPT (origem);
  - B06 → Work independente.
- **Parada em bloqueio:** qualquer `*_BLOCKED=<motivo>` encerra a etapa; nada é inferido e nada é repetido por conta própria.
- **Escritas:** nenhuma etapa antes do D4 escreve em `D:\Base CSV`. A migração 8b, a cerca legada e a ativação do menu têm efeitos próprios e documentados; executam-se somente com a cadeia até B07.
