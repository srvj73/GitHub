# P2 — Recuperação: SAFE_STOP, queda e retomada determinística sem duplicação

**Aplica-se a:** campanha G5 do V005 (launcher `RUN_CDT21_G5_V005_20261022.ps1`). Para D4 em diante, a recuperação é a do código congelado e está resumida no fim deste documento.


**Regra geral:** nenhuma raiz, COMMIT, livro-razão ou diário é apagado ou editado à mão. A retomada é admitida somente pela Fase Q do supervisor que criou a raiz, com os mesmos bytes do supervisor.

## 1. Parada segura (SAFE_STOP)

O supervisor imprime `SAFE_STOP=<raiz>\SAFE_STOP.request`. Crie esse arquivo para pedir a parada.

O comportamento segue o código congelado:
- a unidade em curso termina dentro do seu limite;
- a próxima unidade não começa;
- a campanha grava o terminal e sela o retorno;
- o supervisor termina com o código 130 e imprime `RETOMADA_DA_MESMA_CAMPANHA: -RetomarRaiz "<raiz>"`.

## 2. Queda (energia, fechamento da janela, término do processo)

O Job kill-on-close do supervisor encerra toda a árvore da campanha. Não sobra processo órfão.

Uma unidade interrompida antes do COMMIT não é promovida. O `run_unit` congelado arquiva seus bytes em `INTERRUPTED_ATTEMPTS` e a reexecuta na retomada.

**Janela R3-F01, fechada no R4 (lógica mantida no supervisor V005).** O COMMIT pode ter sido publicado (durável) sem que a linha `COMMITTED` tenha chegado ao livro-razão. Na retomada, a Fase Q reconcilia esse COMMIT **somente se todas** as condições abaixo valerem:
- é o único COMMIT sem registro;
- é a próxima unidade do plano;
- tem dono único (pid, criação) igual ao processo do seu `RESULT.json`;
- esse dono consta do censo do Job do supervisor tirado na última tentativa (`CDT21_SUPERVISOR_JOURNAL`), enquanto a campanha relatava aquela unidade ativa;
- esse dono não é o supervisor nem o filho de campanha.

A reconciliação é gravada no livro-razão (`basis=RECONCILED_BY_SUPERVISOR_JOB_CENSUS`) sob o lock da campanha, antes do início dela. O `run_unit` congelado então **reutiliza** o COMMIT, sem reexecução e sem duplicação.

Faltando qualquer condição, a raiz é recusada com `COMMIT_NOT_LEDGERED:<chave>:RECONCILE_<motivo>`. Nesse caso, nenhum COMMIT sem proveniência é aceito e nada é reexecutado sobre ele. O caminho restante é uma campanha nova (P1).

## 3. Retomada

Execute a partir de `PS C:\Users\silvi>`, com a raiz informada pelo supervisor:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\silvi\Downloads\RUN_CDT21_G5_V005_20261022.ps1" -AutorizoLabD -RetomarRaiz "<raiz>"
```

**A Fase Q admite a raiz somente se:**
- a raiz estiver em `%LOCALAPPDATA%\CDT20_R08\R08_Q1_<14 dígitos>_<12 hex>`;
- o bootstrap for deste mesmo supervisor, com os bytes do V005 e o livro-razão e o diário declarados;
- dono, laboratório D:, testemunha e pacote coincidirem;
- cada COMMIT estiver fechado, vinculado ao V005 (nunca ao V003 nem ao V004), íntegro e no livro-razão (ou reconciliado por prova, item 2);
- os processos anteriores estiverem mortos;
- o lock estiver livre.

A Fase E repete a admissão, grava a reconciliação (se houver) e preserva o terminal anterior. Em seguida, executa a campanha congelada, que reutiliza o que estiver íntegro e executa o restante. Ao fim, exige: reutilizadas ⊆ admitidas, nenhuma unidade recomitada, reutilizadas + novas = 38 e 38 registros no livro-razão.

**Recusas que exigem campanha nova:**
- COMMIT do V003, do V004, de outro candidato ou de outra campanha;
- livro-razão adulterado;
- reconciliação sem prova;
- raiz criada por outro supervisor.

## 4. Classificação de uma morte abrupta numa tentativa retomada (corrigida no R4, mantida no V005)

Uma tentativa retomada que morre sem terminal próprio termina `BLOCKED` com `CAMPAIGN_ABRUPT_EXIT_NO_TERMINAL_OF_THIS_ATTEMPT:<código>`. Não é mais classificada pelo terminal da tentativa anterior, que podia indicar `SAFE_STOP`. A retomada segue o item 3.

## 5. Recuperação nos estágios com efeito (código congelado do V005; referência)

| Estágio | Parada segura | Queda/interrupção | Retomada |
|---|---|---|---|
| D4 | `RUN_TICKSTORE_FULL.ps1 -Stage Stop` ou Ctrl+C na janela elevada: o wrapper selado grava `STOP.request` e conduz o SAFE_STOP; o `FULL_RUNNER` ignora Ctrl+C enquanto o wrapper roda | journal, checkpoint e `RUN_AUTHORITY` do motor D4 | `-ResumeAdmittedRun` (mesma fronteira de admissão, mesmas entradas G5 da cadeia) e, depois, `D4Close` |
| D5, CANARY, FULL_PREP | Ctrl+C: o nó fica `FAIL` | `FULL_CRASH_RECOVERY` retira somente o lock do dono morto | reexecutar a mesma etapa retoma do nó interrompido |
| FULL | `Stop` (mutex `Global\TICKSTORE_FULL_STOP_<run_id>`) ou Ctrl+C → desligamento limitado da árvore → SAFE_STOP (código 130); watchdog do laço principal (600 s) e de produtividade (180 s) | `FULL_G3_INTERRUPTION.reconcile` fecha a tentativa G3 morta como `FAIL`; publicação diária por um único publicador, após verificar o SHA do mês, sob lock do destino e mutex nativo | readmissão (`FULL_READMIT`, recibo válido por 300 s) e novo FULL: o MULTIWORK normaliza transações interrompidas e classifica cada dia como existente (container + commit validado, reutilizado) ou a construir; estado transitório após a normalização bloqueia. O controle de ticks duplicados é a checagem D9 do CANARY |
| Qualquer | Lock órfão: falha fechada (`WRITER_LOCK_EXISTS`); reconciliação só após provar que não há processo vivo | Debris de CAS do STATE: `STATE_CAS_RECOVERY.py` diagnostica somente leitura e aplica R1/R2/R3 só sob a fronteira | — |
