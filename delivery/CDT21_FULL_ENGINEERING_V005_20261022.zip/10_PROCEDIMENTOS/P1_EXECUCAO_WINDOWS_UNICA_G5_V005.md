# P1 — Procedimento Windows único: campanha G5 nativa do V005

**Executor:** titular, no próprio Windows.
**Retorno:** diretamente ao Opus (Claude Code), na mesma conversa de engenharia CDT21.
**Escopo:** G5 técnico do V005 em laboratório próprio. É a única prova nativa indispensável desta entrega (A3).

Não fazem parte deste procedimento: produção, B06, B07, D4/D5 produtivos, canário e FULL.

## 1. Arquivos (todos em `C:\Users\silvi\Downloads`)

| Arquivo | SHA-256 |
|---|---|
| `CDT21_FINAL_PACKAGE_V005_20261022.zip` (candidato congelado) | `E3F1F4790D6AE6E5639F137FAEE3E91B2B8E6FFB51A95F18078DF734553CB145` |
| `RUN_CDT21_G5_V005_20261022.ps1` (launcher único; supervisor e revisão de fonte embutidos) | `2767A823550C7DF3D6C75F301215DB721E895C09545468E66E23E0145B8867FA` |

O supervisor V005 embutido tem SHA-256 `363D1654681D690C247903F440568238E678FC04B22F6F0DB62462B85458700A`. O launcher confere esse pin antes de qualquer uso.

Os dois arquivos estão no pacote FULL (`02_CANDIDATO_V005` e `03_SUPERVISOR_E_LAUNCHER_G5_V005`) e também são entregues avulsos, com os mesmos bytes.

Antes de executar, confira os SHA-256 a partir de `PS C:\Users\silvi>`, sem usar `cd`:

```powershell
Get-FileHash -Algorithm SHA256 "C:\Users\silvi\Downloads\CDT21_FINAL_PACKAGE_V005_20261022.zip","C:\Users\silvi\Downloads\RUN_CDT21_G5_V005_20261022.ps1"
```

## 2. Execução

Execute a partir de `PS C:\Users\silvi>`, no PowerShell 5.1. O launcher pede elevação por UAC quando necessário.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\silvi\Downloads\RUN_CDT21_G5_V005_20261022.ps1" -AutorizoLabD
```

**Fase Q** (sempre executada; não cria raiz nem laboratório):
- verifica pacote, revisão de fonte, NTFS, elevação e o plano de 38 unidades;
- verifica o isolamento de escrita;
- registra, somente para leitura, as raízes preexistentes (inclusive as das campanhas V003 e V004);
- executa nativamente a suíte b2d congelada (29/29) e o controle negativo;
- prova que o censo do Job do supervisor enxerga um processo colocado num Job aninhado (`job_census_sees_nested_child`, R4);
- registra a identidade física do ZIP sucessor do D4 (`D4_SUCCESSOR_ARTIFACT=`), somente leitura, sem bloquear (GAP-04).

Se a Fase Q falhar, nada é criado. Sem `-AutorizoLabD`, o launcher executa somente a Fase Q e termina com o código 10.

**Fase E:**
- cria uma raiz e um laboratório novos;
- executa as 38 unidades congeladas e o fechamento de cinco partes (`PRE_G06_COMPLETENESS`);
- os 7 testes de regressão do V005 rodam aqui nativamente, dentro das suítes do plano: `test_operator_entry_points` (FULL_RUNNER → wrapper D4; pin do launcher adaptado; identidade do ZIP sucessor) e `test_cdt18_stage_proof_integrated_reconcile` (recibo D4 publicável);
- mantém o diário de tentativas e o censo por unidade, base da reconciliação R4.

Duração de referência: a base de ETA congelada (durações observadas na execução nativa `R08_Q1_20261020121927`) soma cerca de 12 minutos para as 38 unidades, mais as fases Q e de fechamento. O heartbeat mostra a unidade ativa, o progresso e o ETA.

## 3. Log e retorno

**Log** (pasta absoluta fixa, nova a cada execução, independente da pasta atual):
`C:\Users\silvi\Downloads\CDT21_G5_V005_RUNS\G5V5_<yyyyMMdd_HHmmss_fff_PID>\RUN_LOG.txt` (pai) e `RUN_LOG_ELEVATED.txt` (filho elevado).

O código congelado também grava seu próprio log fixo em `C:\Users\silvi\OneDrive\Downloads\TICKSTORE_RUNS`. Esse caminho é legado, absoluto e congelado (GAP-08).

**Retorno:** o launcher gera `ENVIAR_AO_OPUS_CDT21_G5_V005_<stamp>.zip` na pasta do log e imprime `ENVIE_O_RETORNO=` e `ENVIE_O_RETORNO_SHA256=`. Envie esse ZIP e o texto do log **diretamente ao Opus**. A origem recebe do Opus o fechamento consolidado.

## 4. Resultado esperado e critério de parada

| Resultado | Situação | Próximo passo |
|---|---|---|
| `SUPERVISOR_STATUS=PASS_NATIVE_V005_G5_TECHNICAL_FIVE_PART EXIT_CODE=0` | G5 técnico nativo do V005, emitido pelos produtores congelados | O Opus verifica o retorno fisicamente e segue o P3 |
| `SAFE_STOP`, ou queda com `RETOMADA_DA_MESMA_CAMPANHA` | Parada ou interrupção | Seguir o P2. Não apagar raiz alguma. |
| `BLOCKED` na Fase Q ou E | Bloqueio | Enviar o retorno ao Opus como está. Não repetir a execução por conta própria. |
