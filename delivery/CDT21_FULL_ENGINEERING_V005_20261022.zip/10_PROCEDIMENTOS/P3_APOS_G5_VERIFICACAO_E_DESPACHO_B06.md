# P3 — Depois do G5 nativo do V005: verificação física e despacho da B06 independente

1. **Verificação física pelo Opus.** O Opus recebe `ENVIAR_AO_OPUS_CDT21_G5_V005_<stamp>.zip` e verifica fisicamente:
   - integridade e CRC;
   - `SUPERVISOR_RESULT.json`;
   - 38 COMMITs vinculados ao V005 (pacote `E3F1F4790D6AE6E5639F137FAEE3E91B2B8E6FFB51A95F18078DF734553CB145`, código `63CBA7065A719CBCF58F1EB1F088D090B87AE7ABBAF37BE03856619CE1D0D74E`), nenhum do V003 ou do V004;
   - livro-razão 38/38, com a base de cada registro (observado ou reconciliado por prova R4);
   - diário de tentativas e censo;
   - `R08_RETURN.zip` relido pelo `gate.verify_native_campaign` congelado;
   - as unidades `SUITE_test_operator_entry_points.py` e `SUITE_test_cdt18_stage_proof_integrated_reconcile.py` aprovadas sobre os bytes do V005 (são os módulos que contêm os 7 testes de regressão);
   - os cinco critérios de completude (`FINAL_G5/ENGINEERING_COMPLETENESS.json`) emitidos pelos produtores congelados;
   - a sonda `D4_SUCCESSOR_ARTIFACT` (presença e SHA-256 do ZIP sucessor; informativa);
   - raízes preexistentes inalteradas;
   - `D:\Base CSV` inalterado.

   Nenhuma verificação reexecuta testes nativos.
2. **Recibo do implementador.** Com a verificação aprovada, o Opus emite o recibo de engenharia `PASS_NATIVE_V005_G5_TECHNICAL_FIVE_PART`. Esse recibo é do implementador; **não** é a B06 nem a decisão G5 da origem.
3. **Despacho da B06.** O Opus monta o despacho da B06 para o Work independente (irmã do titular), com:
   - o candidato V005;
   - o retorno G5 nativo;
   - este pacote FULL;
   - a matriz de admissão;
   - o modelo de veredito `TEMPLATE_B06_VERDICT.txt` (cabeçalho único + 31 chaves), que a B07 e o motor D4 leem igualmente.

   O resultado da B06 não é produzido nem antecipado pelo implementador.
4. **Gates seguintes.** A sequência, os pré-requisitos, os executores e as entradas reservadas à origem estão no P4 e em `09_ESTADO_DOS_GATES.json`. O implementador não executa nenhum deles.
