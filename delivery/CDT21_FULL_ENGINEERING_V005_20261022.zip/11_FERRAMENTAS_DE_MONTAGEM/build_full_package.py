"""Assemble the single CDT21 FULL engineering package (V005 frozen candidate + G5 V005 supervisor/launcher + map + evidence).

Usage: python -I build_full_package.py
Inputs are fixed paths in this scratchpad and in delivery/; every member is hashed into MANIFESTO.json.  Large historical
evidence that already lives in delivery/ (V004 and V003 candidates, B06 dispatch parts) is referenced by SHA-256 instead
of being copied twice.
"""
import difflib
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

S = Path('/tmp/claude-0/-home-user-GitHub/ece1d4c3-5fd3-5d37-a54a-2c0b4e5a2396/scratchpad')
D = Path('/home/user/GitHub/delivery')
SRC = S / 'fullpkg' / 'src'; OUT = S / 'fullpkg' / 'stage'
W4 = S / 'g5v4s4'; V5 = S / 'v005'; G5 = V5 / 'g5'
NAME = 'CDT21_FULL_ENGINEERING_V005_20261022'
V005_ZIP_NAME = 'CDT21_FINAL_PACKAGE_V005_20261022.zip'
V005_ZIP_SHA = 'E3F1F4790D6AE6E5639F137FAEE3E91B2B8E6FFB51A95F18078DF734553CB145'
H = lambda b: hashlib.sha256(b).hexdigest().upper()
Hf = lambda p: H(Path(p).read_bytes())

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)


def cp(src, rel):
    dst = OUT / rel; dst.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(src, dst)


sup = G5 / 'build/CDT21_G5_V005_SUPERVISOR.py'; lau = G5 / 'build/RUN_CDT21_G5_V005_20261022.ps1'
review = G5 / 'CDT19_IMPLEMENTER_SOURCE_REVIEW_V005.json'
SUP_SHA, LAU_SHA = Hf(sup), Hf(lau)
assert Hf(V5 / 'out' / V005_ZIP_NAME) == V005_ZIP_SHA

# 00/01/07/08/09/10: authored documents (placeholders bound to the real hashes here).
for p in sorted(SRC.rglob('*')):
    if p.is_file():
        text = p.read_text(encoding='utf-8').replace('@@SUPERVISOR_SHA@@', SUP_SHA).replace('@@LAUNCHER_SHA@@', LAU_SHA)
        assert '@@' not in text, p
        dst = OUT / p.relative_to(SRC); dst.parent.mkdir(parents=True, exist_ok=True); dst.write_bytes(text.encode('utf-8'))

# 02: the frozen V005 candidate, byte-exact, its installer witness and the independent verifications.
C2 = '02_CANDIDATO_V005/'
cp(V5 / 'out' / V005_ZIP_NAME, C2 + V005_ZIP_NAME)
cp(V5 / 'out/WITNESS_TICKSTORE_FULL_FINAL_V005_20261022.json', C2 + 'WITNESS_TICKSTORE_FULL_FINAL_V005_20261022.json')
cp(S / 'fullpkg/work/V005_CANDIDATE_VERIFICATION.json', C2 + 'V005_CANDIDATE_VERIFICATION.json')
cp(S / 'fullpkg/work/V004_CANDIDATE_VERIFICATION.json', C2 + 'V004_PARENT_VERIFICATION.json')
cp(S / 'fullpkg/verify_candidate.py', C2 + 'verify_candidate.py')

# 03: G5 V005 supervisor and launcher (the only executors outside the frozen candidate) and how they were derived.
C3 = '03_SUPERVISOR_E_LAUNCHER_G5_V005/'
cp(sup, C3 + 'CDT21_G5_V005_SUPERVISOR.py')
cp(lau, C3 + 'RUN_CDT21_G5_V005_20261022.ps1')
cp(review, C3 + 'CDT19_IMPLEMENTER_SOURCE_REVIEW_V005.json')
for f in ('make_v005_supervisor.py', 'build_v005_launcher.py', 'check_v005_launcher.py'):
    cp(V5 / 'tools' / f, C3 + 'build/' + f)
for f in ('V005_LAUNCHER_STATIC_CHECK.json', 'parse_check_v005.ps1'):
    cp(G5 / 'build' / f, C3 + 'build/' + f)
r4_sup = W4 / 'build/CDT21_G5_V004_SUPERVISOR.py'; r4_lau = W4 / 'build/RUN_CDT21_G5_V004_R4_20261021.ps1'
cp(r4_sup, C3 + 'build/PARENT_R4_CDT21_G5_V004_SUPERVISOR_02DDB290.py')
cp(r4_lau, C3 + 'build/PARENT_R4_RUN_CDT21_G5_V004_R4_20261021.ps1')
d = difflib.unified_diff(r4_sup.read_text(encoding='utf-8').splitlines(), sup.read_text(encoding='utf-8').splitlines(),
                         'R4/CDT21_G5_V004_SUPERVISOR.py', 'V005/CDT21_G5_V005_SUPERVISOR.py', lineterm='', n=2)
(OUT / C3 / 'build/R4_TO_V005_SUPERVISOR.diff').write_text('\n'.join(d) + '\n', encoding='utf-8')


def outside_payloads(raw):
    t = raw.decode('ascii').split('\r\n'); keep, skip = [], False
    for line in t:
        if line in ("$SupervisorB64 = @'", "$ReviewB64 = @'"):
            keep.append(line); keep.append('<payload base64 omitido; SHA-256 fixado no proprio launcher>'); skip = True; continue
        if skip and line == "'@":
            skip = False
        if not skip:
            keep.append(line)
    return keep


d = difflib.unified_diff(outside_payloads(r4_lau.read_bytes()), outside_payloads(lau.read_bytes()),
                         'R4/RUN_CDT21_G5_V004_R4_20261021.ps1', 'V005/RUN_CDT21_G5_V005_20261022.ps1', lineterm='', n=1)
(OUT / C3 / 'build/R4_TO_V005_LAUNCHER_OUTSIDE_PAYLOADS.diff').write_text('\n'.join(d) + '\n', encoding='utf-8')

# 04: component map / consumers / execution paths (integration review) and its decisions.
C4 = '04_MAPA_COMPONENTES_E_CONSUMIDORES/'
for p in sorted((S / 'fullpkg/inventory').glob('*')):
    cp(p, C4 + p.name)
for f in ('make_v005_map.py', 'make_decisions.py'):
    cp(S / 'fullpkg' / f, C4 + 'ferramentas/' + f)

# 05: frozen manifests and V005 records (verbatim members of the candidate ZIP).
with zipfile.ZipFile(V5 / 'out' / V005_ZIP_NAME) as z:
    for m in ('PACKAGE_MANIFEST.json', 'implementation_v001/RUNTIME_CODE_MANIFEST.json', 'implementation_v001/SOURCE_MANIFEST.json',
              'implementation_v001/CDT21_V005_ENGINEERING_COMPLETENESS.json', 'implementation_v001/CDT21_V005_DELTA_RECEIPT.json',
              'implementation_v001/CDT21_V005_DELTA.patch', 'implementation_v001/README_CDT21_V005_FULL_INTEGRATION.md'):
        dst = OUT / '05_MANIFESTOS' / Path(m).name; dst.parent.mkdir(parents=True, exist_ok=True); dst.write_bytes(z.read(m))

# 06: evidence.
E = '06_EVIDENCIAS/'
for f in ('V005_REGRESSION_NEGATIVE_CONTROL.json', 'VERIFY_FULL_COMPOSITION_SOURCE_ONLY_V005.out'):
    cp(V5 / 'regproof' / f, E + 'V005_DELTA/' + f)
for f in ('SWEEP_V004.json', 'SWEEP_V005.json'):
    cp(V5 / 'sweep' / f, E + 'V005_DELTA/' + f)
for f in ('apply_v005_delta.py', 'apply_v005_tests.py', 'apply_v005_docs.py', 'build_v005.py', 'sweep.py', 'regression_proof.py'):
    cp(V5 / 'tools' / f, E + 'V005_DELTA/ferramentas/' + f)
Q5 = G5 / 'qual'
for f in ['V005_SUPERVISOR_QUALIFICATION.json', 'mutants_summary_v005.txt'] + sorted(p.name for p in Q5.glob('V005_MUTANT_*.json')):
    cp(Q5 / f, E + 'G5_V005_SUPERVISOR/resultados/' + f)
cp(G5 / 'test_v005_supervisor.py', E + 'G5_V005_SUPERVISOR/ferramentas/test_v005_supervisor.py')
cp(G5 / 'stub_campaign_r4.py', E + 'G5_V005_SUPERVISOR/ferramentas/stub_campaign_r4.py')
cp(G5 / 'run_all_v005.sh', E + 'G5_V005_SUPERVISOR/ferramentas/run_all_v005.sh')
cp(V5 / 'tools/make_test_v005.py', E + 'G5_V005_SUPERVISOR/ferramentas/make_test_v005.py')
Q = W4 / 'qual'
for f in ['R4_RECONCILE_QUALIFICATION.json', 'mutants_summary_r4.txt'] + sorted(p.name for p in Q.glob('R4_MUTANT_*.json')):
    cp(Q / f, E + 'R4_A1/resultados/' + f)
for f in ('test_r4_reconcile.py', 'test_r4_additions.py', 'make_test_r4.py', 'stub_campaign_r4.py', 'run_all_r4.sh', 'make_v004_r4_supervisor.py',
          'build_v004_r4_launcher.py', 'check_r4_launcher.py'):
    cp(W4 / f, E + 'R4_A1/ferramentas/' + f)
for f in ('R3_TO_R4_SUPERVISOR.diff', 'R3_TO_R4_SUPERVISOR_IGNORING_WHITESPACE.diff', 'R4_LAUNCHER_STATIC_CHECK.json'):
    cp(W4 / 'build' / f, E + 'R4_A1/build/' + f)
cp(S / 'g5v4s3/build/CDT21_G5_V004_SUPERVISOR.py', E + 'R4_A1/build/PARENT_CDT21_G5_V004_SUPERVISOR_R3_2765FAAA.py')
cp(S / 'g5v4s3/test_r3_resume.py', E + 'R4_A1/ferramentas/PARENT_test_r3_resume.py')
V = S / 'f01r1/final/v004/implementation_v001'
for f, rel in (('candidate/g5proof/PRE_G06_CAMPAIGN.py', 'PRE_G06_CAMPAIGN.py'), ('candidate/full/FULL_CRASH_RECOVERY.py', 'FULL_CRASH_RECOVERY.py'),
               ('candidate/full/FULL_PROCESS_CONTROL.py', 'FULL_PROCESS_CONTROL.py')):
    assert Hf(V / f) == Hf(S / 'fullpkg/work/v005ext/implementation_v001' / f), f  # frozen contract unchanged in V005
    cp(V / f, E + 'R4_A1/contrato_congelado_V004_igual_V005/' + rel)
HIST = ['WITNESS_CDT21_V004_F01R1_G0_NATIVE_20261021.json', 'CDT21_V004_F01R1_QUALIFICACAO_NATIVA_PARA_ORIGEM_20261021.zip',
        'WITNESS_CDT21_V004_F01R1_DELTA_20261021.json', 'CDT21_V004_F01R1_DELTA_PARA_ORIGEM_20261021.zip', 'RELATORIO_F01R1_V004_20261021.md',
        'CDT21_G5_V003_FINAL_ENGINEERING_RECEIPT.json', 'RELATORIO_FINAL_G5_V003_E_DESPACHO_B06_20261021.md',
        'WITNESS_CDT21_G5_V004_LAUNCHER_20261021.json', 'CDT21_G5_V004_SUPERVISOR_EVIDENCE_20261021.zip', 'RELATORIO_G5_V004_LAUNCHER_20261021.md',
        'WITNESS_CDT21_G5_V004_R1_LAUNCHER_20261021.json', 'CDT21_G5_V004_R1_LAUNCHER_QUALIFICATION_20261021.zip', 'RELATORIO_G5_V004_R1_LAUNCHER_20261021.md',
        'WITNESS_CDT21_G5_V004_DIAGQ_20261021.json', 'CDT21_G5_V004_DIAGQ_EVIDENCE_20261021.zip', 'RELATORIO_G5_V004_DIAGQ_20261021.md',
        'WITNESS_CDT21_G5_V004_R2_20261021.json', 'CDT21_G5_V004_R2_SUPERVISOR_FIX_EVIDENCE_20261021.zip', 'RELATORIO_G5_V004_R2_CAUSA_E_CORRECAO_20261021.md',
        'WITNESS_CDT21_G5_V004_R3_20261021.json', 'CDT21_G5_V004_R3_RETOMADA_EVIDENCE_20261021.zip', 'RELATORIO_G5_V004_R3_RETOMADA_20261021.md']
for f in HIST:
    cp(D / f, E + 'HISTORICO_LINHA_V004/' + f)
REFERENCED = ['CDT21_FINAL_PACKAGE_V004_20261021.zip', 'CDT21_FINAL_PACKAGE_V003_20261020.zip'] + \
             ['CDT21_V003_B06_DISPATCH_PARTE_%02d_DE_05.zip' % i for i in range(1, 6)] + ['CDT21_B06_RESULT_V002_20261020.zip', 'B06_DISPATCH_ADMISSION_MATRIX.json']
ref = {'schema': 'CDT21_FULL_REFERENCED_EVIDENCE_V002',
       'note': 'grandes ou de candidatos anteriores; referenciados por SHA-256 em delivery/ do ramo claude/awesome-sagan-kb9llj; o V004 e o pai preservado do V005',
       'files': {f: {'sha256': Hf(D / f), 'bytes': (D / f).stat().st_size} for f in REFERENCED}}
assert ref['files']['CDT21_FINAL_PACKAGE_V004_20261021.zip']['sha256'] == 'AD33486954F1248AF28A78677377E83AB979AB86EDD5F71F5B7D108CBA8F99DD'
(OUT / E / 'EVIDENCIAS_REFERENCIADAS_POR_HASH.json').write_text(json.dumps(ref, indent=1, sort_keys=True), encoding='utf-8')

# 11: the tools that assembled this package.
for f in ('build_full_package.py', 'make_receipts.py'):
    cp(S / 'fullpkg' / f, '11_FERRAMENTAS_DE_MONTAGEM/' + f)

# Manifest of every member, then the single ZIP.
members = sorted(p for p in OUT.rglob('*') if p.is_file() and p.name != 'MANIFESTO.json')
man = {'schema': 'CDT21_FULL_ENGINEERING_PACKAGE_MANIFEST_V002', 'package': NAME,
       'candidate_v005_sha256': V005_ZIP_SHA, 'supervisor_g5_v005_sha256': SUP_SHA, 'launcher_g5_v005_sha256': LAU_SHA,
       'members': {str(p.relative_to(OUT)): {'sha256': Hf(p), 'bytes': p.stat().st_size} for p in members}}
(OUT / 'MANIFESTO.json').write_text(json.dumps(man, indent=1, sort_keys=True), encoding='utf-8')
zp = D / (NAME + '.zip')
with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(p for p in OUT.rglob('*') if p.is_file()):
        zi = zipfile.ZipInfo(str(p.relative_to(OUT)), date_time=(2026, 10, 22, 12, 0, 0))
        zi.compress_type = zipfile.ZIP_STORED if p.suffix == '.zip' else zipfile.ZIP_DEFLATED
        zi.external_attr = 0o644 << 16
        z.writestr(zi, p.read_bytes())
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None
    m = json.loads(z.read('MANIFESTO.json'))
    assert all(H(z.read(k)) == v['sha256'] for k, v in m['members'].items()) and len(z.namelist()) == len(m['members']) + 1
    n = len(z.namelist())
print(zp.name, Hf(zp), zp.stat().st_size, n, 'MANIFESTO', Hf(OUT / 'MANIFESTO.json'), 'SUP', SUP_SHA, 'LAU', LAU_SHA)
