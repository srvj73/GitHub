"""Generate 07_MATRIZ_PRE_ENTREGA.json, 08_RECIBO_CINCO_CRITERIOS.json and 09_ESTADO_DOS_GATES.json from the evidence.

Usage: python -I make_receipts.py
Every status is derived from a file that travels in the package (or is referenced by SHA-256); no status is asserted
without its evidence, and Linux/source evidence is never labelled native.
"""
import hashlib
import json
from pathlib import Path

S = Path('/tmp/claude-0/-home-user-GitHub/ece1d4c3-5fd3-5d37-a54a-2c0b4e5a2396/scratchpad')
D = Path('/home/user/GitHub/delivery'); SRC = S / 'fullpkg/src'; W4 = S / 'g5v4s4'; G5 = S / 'v005/g5'
Hf = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
J = lambda p: json.loads(Path(p).read_text(encoding='utf-8'))
V005_ZIP = 'E3F1F4790D6AE6E5639F137FAEE3E91B2B8E6FFB51A95F18078DF734553CB145'
V005_CODE = '63CBA7065A719CBCF58F1EB1F088D090B87AE7ABBAF37BE03856619CE1D0D74E'


def mutants(folder, pattern):
    ms = [J(p) for p in sorted(folder.glob(pattern))]
    return ms, [m['mutant'] for m in ms if m['passed'] < m['total']]


q5 = J(G5 / 'qual/V005_SUPERVISOR_QUALIFICATION.json'); m5, k5 = mutants(G5 / 'qual', 'V005_MUTANT_*.json')
q4 = J(W4 / 'qual/R4_RECONCILE_QUALIFICATION.json'); m4, k4 = mutants(W4 / 'qual', 'R4_MUTANT_*.json')
cand = J(S / 'fullpkg/work/V005_CANDIDATE_VERIFICATION.json')
cand4 = J(S / 'fullpkg/work/V004_CANDIDATE_VERIFICATION.json')
lstat = J(G5 / 'build/V005_LAUNCHER_STATIC_CHECK.json')
reg = J(S / 'v005/regproof/V005_REGRESSION_NEGATIVE_CONTROL.json')
sw4, sw5 = J(S / 'v005/sweep/SWEEP_V004.json'), J(S / 'v005/sweep/SWEEP_V005.json')
comp_out = (S / 'v005/regproof/VERIFY_FULL_COMPOSITION_SOURCE_ONLY_V005.out').read_text(encoding='utf-8')
g0 = J(D / 'WITNESS_CDT21_V004_F01R1_G0_NATIVE_20261021.json')
review = J(S / 'fullpkg/inventory/INTEGRATION_REVIEW_DECISIONS.json')
SUP, LAU = Hf(G5 / 'build/CDT21_G5_V005_SUPERVISOR.py'), Hf(G5 / 'build/RUN_CDT21_G5_V005_20261022.ps1')
assert cand['zip_sha256'] == V005_ZIP and cand['pass'] and cand4['pass']
sup_ok = q5['passed'] == q5['total'] and q5['supervisor_sha256'] == SUP and bool(m5) and len(k5) == len(m5)
r4_ok = q4['passed'] == q4['total'] and bool(m4) and len(k4) == len(m4)
lau_ok = lstat['pass'] and lstat['sha256'] == LAU and lstat['supervisor_payload_sha256'] == SUP
comp_ok = 'COMPOSITION_SOURCE_INTEGRITY=PASS' in comp_out and 'exit=0' in comp_out
diff_sw = sorted(k for k in sw5['results'] if sw4['results'].get(k) != sw5['results'][k])
sweep_ok = sw4['modules'] == sw5['modules'] and diff_sw == ['tests/test_cdt18_stage_proof_integrated_reconcile.py', 'tests/test_operator_entry_points.py'] \
    and all(sw5['results'][k]['exit'] == 0 for k in diff_sw)
assert sup_ok and r4_ok and lau_ok and comp_ok and sweep_ok and reg['pass'], (sup_ok, r4_ok, lau_ok, comp_ok, sweep_ok, reg['pass'])
open_gaps = [g['id'] for g in review['gaps'] if g['decision'].startswith('OPEN')]
assert not open_gaps, open_gaps  # condition of delivery: no internally fixable gap left open

ev = {'candidate_verification_v005': {'file': '02_CANDIDATO_V005/V005_CANDIDATE_VERIFICATION.json', 'pass': cand['pass'],
                                      'members': cand['package_members'], 'runtime_code_files': cand['runtime_code_files']},
      'parent_v004_verification': {'file': '02_CANDIDATO_V005/V004_PARENT_VERIFICATION.json', 'pass': cand4['pass'], 'zip_sha256': cand4['zip_sha256']},
      'v005_regression_negative_control': {'file': '06_EVIDENCIAS/V005_DELTA/V005_REGRESSION_NEGATIVE_CONTROL.json', **reg['summary']},
      'linux_sweep': {'files': ['06_EVIDENCIAS/V005_DELTA/SWEEP_V004.json', '06_EVIDENCIAS/V005_DELTA/SWEEP_V005.json'], 'modules': sw5['modules'],
                      'tests_run_v004': sum(r['ran'] for r in sw4['results'].values()), 'tests_run_v005': sum(r['ran'] for r in sw5['results'].values()),
                      'modules_with_different_result': diff_sw,
                      'note': 'comparacao modulo a modulo; modulos que nao rodam no Linux falham igual nos dois e nao sao lidos como aprovacao'},
      'candidate_composition_verifier': {'file': '06_EVIDENCIAS/V005_DELTA/VERIFY_FULL_COMPOSITION_SOURCE_ONLY_V005.out', 'pass': comp_ok},
      'g5_v005_supervisor': {'file': '06_EVIDENCIAS/G5_V005_SUPERVISOR/V005_SUPERVISOR_QUALIFICATION.json', 'passed': q5['passed'], 'total': q5['total'],
                             'mutants_killed': len(k5), 'mutants_total': len(m5), 'supervisor_sha256': SUP},
      'g5_v005_launcher_static': {'file': '03_SUPERVISOR_E_LAUNCHER_G5_V005/build/V005_LAUNCHER_STATIC_CHECK.json', 'pass': lau_ok, 'launcher_sha256': LAU},
      'r4_a1_v004_line': {'file': '06_EVIDENCIAS/R4_A1/resultados/R4_RECONCILE_QUALIFICATION.json', 'passed': q4['passed'], 'total': q4['total'],
                          'mutants_killed': len(k4), 'mutants_total': len(m4)},
      'v004_g0_native_history': {'file': '06_EVIDENCIAS/HISTORICO_LINHA_V004/WITNESS_CDT21_V004_F01R1_G0_NATIVE_20261021.json',
                                 'verdict': g0['independent_check']['verdict'], 'native_tests': g0['independent_check']['native_tests'],
                                 'scope': 'bytes do V004; nao aprova o V005'},
      'integration_review': {'file': '04_MAPA_COMPONENTES_E_CONSUMIDORES/INTEGRATION_REVIEW_DECISIONS.json',
                             'gaps_total': len(review['gaps']), 'open_internally_fixable': 0}}

matrix = {'schema': 'CDT21_FULL_PRE_DELIVERY_MATRIX_V002', 'candidate_v005_sha256': V005_ZIP, 'runtime_code_manifest_sha256': V005_CODE,
          'supervisor_g5_v005_sha256': SUP, 'launcher_g5_v005_sha256': LAU, 'evidence': ev, 'rows': review['matrix_rows'],
          'gap_decisions': {g['id']: g['decision'] for g in review['gaps']},
          'findings': {
              'A1': {'status': 'CLOSED_IN_CODE_R4__CARRIED_INTO_G5_V005__LINUX_QUALIFIED_ON_EXACT_BYTES__NATIVE_Q_PROBE_IN_P1',
                     'basis': 'reconciliacao COMMIT->livro-razao por prova de proveniencia; R4 %d/%d + mutantes %d/%d (linha V004); V005 %d/%d (inclui NR14: COMMIT do pai V004 recusado) + mutantes %d/%d'
                              % (q4['passed'], q4['total'], len(k4), len(m4), q5['passed'], q5['total'], len(k5), len(m5))},
              'A2': {'status': review['a2_status'], 'basis': review['a2_basis']},
              'A3': {'status': 'PHYSICAL_IMPEDIMENT_REQUIRES_OWNER_WINDOWS__PROCEDURE_P1_READY',
                     'basis': 'os deltas materiais do V005 rodam nativamente dentro das suites do plano G5; a campanha G5 nativa do V005 so pode ocorrer no Windows do titular; procedimento unico, hash-bound e delimitado: P1, retorno direto ao Opus'},
              'A4': {'status': review['a4_status'], 'basis': review['a4_basis']},
              'A5': {'status': 'CLOSED',
                     'basis': 'universo congelado = RUNTIME_CODE_MANIFEST do V005 (%d arquivos) verificado membro a membro; 163 componentes com papel, consumidores e dependencias (04), 6 alterados em relacao ao V004; dependencias externas por gate em 09' % cand['runtime_code_files']},
              'A6': {'status': 'CLOSED', 'basis': 'pacote unico com candidato, executores, instalador, mapa, manifestos, evidencias, recibos e procedimentos; o V005 substitui a sequencia de patches por um sucessor congelado unico'}}}

five = {'schema': 'CDT21_FULL_ENGINEERING_FIVE_CRITERIA_RECEIPT_V002', 'issuer': 'IMPLEMENTER_ENGINEERING_RECEIPT_NOT_B06',
        'binds': {'candidate_v005_sha256': V005_ZIP, 'runtime_code_manifest_sha256': V005_CODE,
                  'package_manifest_sha256': 'F2DC5643FA9BA5DFFBBD4E02013856943F47FF84F5ACA6309F7EEB2D981785DF',
                  'supervisor_g5_v005_sha256': SUP, 'launcher_g5_v005_sha256': LAU,
                  'parent_v004_sha256': 'AD33486954F1248AF28A78677377E83AB979AB86EDD5F71F5B7D108CBA8F99DD'},
        'criteria_names_from_frozen_gate': ['all_implementations_integrated', 'all_known_fixable_blockers_closed',
                                            'tested_equals_packaged_new_final_code', 'adversarial_false_completeness_check',
                                            'frozen_for_independent_audit'],
        'five_part_completeness': {
            'all_implementations_integrated': {'status': review['five']['all_implementations_integrated'],
                                               'evidence': ['04_MAPA_COMPONENTES_E_CONSUMIDORES/V004_FULL_INVENTORY.md', '04_MAPA_COMPONENTES_E_CONSUMIDORES/V005_COMPONENT_MAP.json',
                                                            '04_MAPA_COMPONENTES_E_CONSUMIDORES/INTEGRATION_REVIEW_DECISIONS.json', ev['v005_regression_negative_control']['file']]},
            'all_known_fixable_blockers_closed': {'status': 'PASS_IN_CODE__NATIVE_PROOF_PENDING_P1',
                                                  'closed_in_this_delivery': ['R3-F01 (A1) supervisor R4, levado ao G5 V005',
                                                                              'classificacao de morte abrupta em tentativa retomada (R4)',
                                                                              'roteamento do retorno nativo ao Opus (A4)'] + review['closed_items'],
                                                  'remaining_not_internally_fixable': [
                                                      'G5 nativo do V005 (Windows do titular, P1)', 'B06 (Work independente)',
                                                      'decisoes e registros da origem: decisao G5, decisao B07, recibo de admissao de politica D4, pacote de revisao D4, reconciliacao corrente',
                                                      '2 overlays derivados aprovados pela origem para a B07 (GAP-10)',
                                                      'observacao nativa do predecessor D4 no instante da admissao (GAP-05)',
                                                      'copia de capturas MASTER/HEAD historicas para tests/fixtures (custodia da origem, GAP-17, so testes)']},
            'tested_equals_packaged_new_final_code': {'status': 'LINUX_PASS_ON_EXTRACTED_FINAL_ZIP__WINDOWS_NATIVE_PENDING_P1',
                                                      'evidence': ['controle negativo e varreduras rodados a partir dos ZIPs extraidos (V004 e V005)',
                                                                   'supervisor V005: harness sobre os bytes exatos %s' % SUP,
                                                                   'a campanha G5 nativa vincula testado == empacotado (verify_package) no P1']},
            'adversarial_false_completeness_check': {'status': 'PASS_STATEMENTS_BOUNDED', 'not_claimed': [
                'G5 nativo do V005', 'Q nativa do supervisor V005 (censo do Job)', 'execucao nativa do launcher adaptado (so no D4)',
                'B06', 'B07/D4/D5 produtivos', 'canario', 'FULL_PREP', 'FULL_ADMISSION', 'FULL',
                'perda fisica de energia (NOT_TESTED_PHYSICAL_POWERLOSS)', 'G5 do V003 ou do V004 transferido ao V005',
                'G0 nativo do V004 como aprovacao do V005', 'qualificacao Linux como aprovacao nativa']},
            'frozen_for_independent_audit': {'status': 'FROZEN_PACKAGE__B06_NOT_STARTED__REQUIRES_NATIVE_G5_V005_FIRST',
                                             'requires': ['P1 executado no Windows do titular com PASS', 'verificacao fisica do retorno pelo Opus (P3)',
                                                          'despacho ao Work independente']}},
        'disclosures': ['GAP-03 foi regressao introduzida pelo delta V003 do implementador (F-01/F-04)',
                        'GAP-09 (SOURCE_MANIFEST sem RUNTIME_CODE_MANIFEST.json) veio das montagens V003/V004 do implementador'],
        'producer_five_part_receipt_native_v005': 'NOT_ISSUED__EMITIDO_PELO_PRE_G06_COMPLETENESS_CONGELADO_NO_P1'}

gates = {'schema': 'CDT21_FULL_GATE_STATE_V002', 'as_of': '2026-10-22', 'candidate_v005_sha256': V005_ZIP,
         'canonical_sequence': 'G4(pre-cadeia; no contrato G5 V003 a prova nativa e o R08_RETURN da campanha PRE_G06) -> G5 -> B06 -> B07 -> D4 -> D5 -> CANARY -> FULL_PREP -> FULL_ADMISSION -> FULL',
         'gates': review['gates_state']}

for name, obj in (('07_MATRIZ_PRE_ENTREGA.json', matrix), ('08_RECIBO_CINCO_CRITERIOS.json', five), ('09_ESTADO_DOS_GATES.json', gates)):
    (SRC / name).write_text(json.dumps(obj, indent=1, ensure_ascii=False, sort_keys=False) + '\n', encoding='utf-8')
print('RECEIPTS', 'A1', matrix['findings']['A1']['status'], 'v005', q5['passed'], '/', q5['total'], 'mut', len(k5), '/', len(m5),
      'r4', q4['passed'], '/', q4['total'], 'mut', len(k4), '/', len(m4), 'sweep diff', diff_sw)
