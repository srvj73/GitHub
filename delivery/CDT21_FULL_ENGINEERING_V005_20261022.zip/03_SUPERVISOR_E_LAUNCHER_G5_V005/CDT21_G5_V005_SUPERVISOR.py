"""CDT21 G5 V005 - native supervisor for a NEW frozen PRE_G06 campaign bound to the V005 manifest.
V005 line (consolidated FULL integration, 2026-10-22): logic identical to the qualified R4 supervisor of the V004
line (02DDB290...), re-bound to the V005 candidate (E3F1F479...); plus a read-only, non-blocking Q probe of the D4
successor artifact identity.  V003 and V004 bytes are other candidates and are never reused.

Origin decision (2026-10-21): the G5 of V003 stays valid for the V003 bytes only; its 38 COMMITs cannot
take the V005 identity.  This supervisor is the proven R2 (99704BA5...) adapted to V005:
  * kept byte-identical from R2: byte-exact extraction into the layout required by the frozen b2d fixture
    (%LOCALAPPDATA%/CDT21_G5_V005/CURRENT_G5_DELTA_<stamp>/EXTRACTED), the fixture contract check, the
    38-unit plan read from frozen constants, the kill-on-close Job, the read-only tree digest (R2: per-entry
    metadata from the entry itself, below) and
    production fingerprint of D:\\Base CSV, write-root isolation, the native b2d runner;
  * new run: creates a NEW run root and a NEW D-lab; no root, COMMIT or terminal receipt of another run or
    candidate (the V003 run included) is opened for writing, resumed or reused;
  * R3 resume, same V005 campaign only (origin audit 2026-10-21): --resume-root re-enters a run root created
    by this exact supervisor for the V005 bytes; the frozen campaign reuses only COMMITs of that root that are
    closed, bound to the V005 package and code, artifact-intact and recorded in this campaign's ledger;
  * added: a native qualification (Q) for a new run, required by the effectful phase (E);
    a digest of every pre-existing run root and D-lab (unchanged from Q to the end of E); refusal of any
    REUSE_COMMITTED line; the 38 COMMITs must equal the plan and be bound to the V005 package and code;
    LIVE_STATUS and R08_RETURN checkpoints consistent with them.
  * R2 (2026-10-21, native DIAGQ 4FEBE2F7...): every digest takes size/mtime of an entry from the entry itself
    (os.lstat -> GetFileInformationByHandle), never from the NTFS directory index (FindFirstFile /
    DirEntry.stat), which can lag for hours and is refreshed by the first enumeration; a refused foreign-root
    check records the difference per root and per entry.  Names, types, fields and checks are unchanged.
  * R4 (origin finding R3-F01): a COMMIT made durable by the frozen campaign whose ledger entry was lost in a
    crash (R.publish before 'COMMITTED <key>') is reconciled on resume only by proof of its own provenance:
    next plan unit, single owner identity equal to its RESULT.json process and listed in this supervisor's own
    Job census of that unit in the latest attempt (journal).  Without that proof the root is refused.

Executes only frozen V005 code, in this order:
  1. g5proof/PRE_G06_CAMPAIGN.py main()   (child process, all 38 planned units)
  2. g5proof/PRE_G06_COMPLETENESS.close() (five-part producer, after a PASS)
It never writes a PASS, never edits extracted bytes, never touches D:\\Base CSV.
B06/B07/D4/D5/canary/FULL/production: NOT_STARTED.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import threading
import time
import traceback
import uuid
import zipfile

PACKAGE_NAME = 'CDT21_FINAL_PACKAGE_V005_20261022.zip'
PACKAGE_SHA = 'E3F1F4790D6AE6E5639F137FAEE3E91B2B8E6FFB51A95F18078DF734553CB145'
V004_PACKAGE_SHA = 'AD33486954F1248AF28A78677377E83AB979AB86EDD5F71F5B7D108CBA8F99DD'  # parent: other candidate
CODE_SHA = '63CBA7065A719CBCF58F1EB1F088D090B87AE7ABBAF37BE03856619CE1D0D74E'
MANIFEST_SHA = 'F2DC5643FA9BA5DFFBBD4E02013856943F47FF84F5ACA6309F7EEB2D981785DF'
V003_PACKAGE_SHA = '69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50'  # never accepted
V003_CODE_SHA = 'D59BC4EE4F0D5C689335C8F478A0342CC0146930E3B0B44C707B6B95267B3953'     # never accepted
CAMPAIGN_REL = 'implementation_v001/candidate/g5proof/PRE_G06_CAMPAIGN.py'
CAMPAIGN_SHA = '347767D17C8526924D87732608CE2D0441E6989275B8E8E3D88E83F6A17FC79A'
COMPLETENESS_REL = 'implementation_v001/candidate/g5proof/PRE_G06_COMPLETENESS.py'
COMPLETENESS_SHA = '15B10B107DBD29FE497F24A0D5AE100EFAEBD5A183BA6E9905C4AF7D43A72068'
REVIEW_NAME = 'CDT19_IMPLEMENTER_SOURCE_REVIEW_V005.json'
WITNESS_NAME = 'CDT19_R08Q1_ENGINEERING_WITNESS.json'
RUN_PARENT = 'CDT20_R08'                       # G5_MULTIWORK_SCENARIOS lab_base
D_LABS = 'D:\\TICKSTORE_CDT19_PRE_G06_LABS'    # PRE_G06_CAMPAIGN CROSS_VOLUME_OWNED_LAB
PRODUCTION = 'D:\\Base CSV'
PLANNED_UNITS = 38
RUN_NAME = re.compile(r'R08_Q1_[0-9]{14}_[0-9a-f]{12}')
RESULT_SCHEMA = 'CDT21_G5_V005_SUPERVISOR_RESULT_V001'
B2D_TEST_REL = 'implementation_v001/tests/test_b2d_origin_decision_binder.py'
B2D_TEST_SHA = 'D19EF3BA870D4065CFDF6C39B35EEB8D24CE9FAEF171E2C6806D9C4E7708DAA0'
EXTRACT_HOME = 'CDT21_G5_V005'
DELTA_PREFIX = 'CURRENT_G5_DELTA_'
D_LABS_NAME = 'TICKSTORE_CDT19_PRE_G06_LABS'
QUAL_SCHEMA = 'CDT21_G5_V005_WINDOWS_QUALIFICATION_V001'
QUAL_MAX_AGE_S = 7200
SUPERVISOR_NAME = 'CDT21_G5_V005_SUPERVISOR.py'
FROZEN_LOG_ROOT = 'C:\\Users\\silvi\\OneDrive\\Downloads\\TICKSTORE_RUNS'  # hard-coded in frozen V005 (installer/RUN_LOG_FIXED)
MODE_NEW = 'NEW_RUN_V005'
MODE_RESUME = 'RESUME_SAME_V005_CAMPAIGN'
LEDGER_DIR = 'CDT21_SUPERVISOR_LEDGER'       # inside the run root: one record per COMMIT observed by the supervisor
LEDGER_SCHEMA = 'CDT21_G5_V005_COMMIT_LEDGER_V001'
JOURNAL_DIR = 'CDT21_SUPERVISOR_JOURNAL'     # inside the run root: attempt records and the supervisor's unit census
ATTEMPT_SCHEMA = 'CDT21_G5_V005_ATTEMPT_V001'
CENSUS_SCHEMA = 'CDT21_G5_V005_UNIT_CENSUS_V001'
RECONCILED_BASIS = 'RECONCILED_BY_SUPERVISOR_JOB_CENSUS'


class Blocked(RuntimeError):
    pass


def require(ok, why):
    if not ok:
        raise Blocked(why)


def sha_bytes(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def sha_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest().upper()


def encoded(obj):
    # Same bytes as FULL_CRASH_RECOVERY.encoded (read back by R.read).
    return (json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def write_new(path, raw):
    with open(path, 'xb') as f:
        f.write(raw); f.flush(); os.fsync(f.fileno())
    require(Path(path).read_bytes() == raw, 'READBACK:' + str(path))


def strict_json(raw):
    def pairs(items):
        out = {}
        for k, v in items:
            require(k not in out, 'JSON_DUPLICATE_KEY')
            out[k] = v
        return out
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs)


_out_lock = threading.Lock()
_console = None
_ROWS = {}  # rows of the last link_safe_digest per base path (evidence only)


def emit(line):
    text = str(line).encode('ascii', 'replace').decode('ascii')
    with _out_lock:
        print(text, flush=True)
        if _console is not None:
            _console.write((str(line) + '\n').encode('utf-8')); _console.flush()


def validate_review(raw):
    """Same binding PRE_G06_COMPLETENESS.close requires; checked before any effect."""
    review = strict_json(raw)
    require(review.get('schema') == 'CDT19_IMPLEMENTER_SOURCE_REVIEW_V001'
            and review.get('status') == 'SOURCE_REVIEW_COMPLETE_PENDING_NATIVE'
            and review.get('package_sha256') == PACKAGE_SHA
            and review.get('code_manifest_sha256') == CODE_SHA
            and review.get('known_fixable_blockers') == []
            and review.get('independent_b06_audit') is False, 'SOURCE_REVIEW_BINDING')
    return review


def extract_package(package, dest):
    """Byte-exact extraction; every member is read back against the archive."""
    dest.mkdir()
    count = 0
    with zipfile.ZipFile(package) as arc:
        require(arc.testzip() is None, 'PACKAGE_CRC')
        names = [i.filename for i in arc.infolist()]
        require(len(names) == len({n.casefold() for n in names}), 'PACKAGE_DUPLICATE_MEMBER')
        for info in arc.infolist():
            name = info.filename
            parts = PurePosixPath(name).parts
            require(name and not name.startswith('/') and '\\' not in name and ':' not in name
                    and all(p not in ('', '.', '..') for p in parts), 'PACKAGE_UNSAFE_MEMBER:' + name)
            target = dest.joinpath(*parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            write_new(target, arc.read(info))
            count += 1
    return count


def verify_extract(package, dest):
    with zipfile.ZipFile(package) as arc:
        for info in arc.infolist():
            if not info.is_dir():
                path = dest.joinpath(*PurePosixPath(info.filename).parts)
                require(path.read_bytes() == arc.read(info), 'TESTED_BYTES_NE_PACKAGED:' + info.filename)


def make_witness(run_id, manifest_sha):
    return {'schema': 'CDT19_R08Q1_ENGINEERING_WITNESS_V001', 'package_name': PACKAGE_NAME,
            'package_sha256': PACKAGE_SHA, 'manifest_sha256': manifest_sha,
            'code_manifest_sha256': CODE_SHA, 'run_id': run_id,
            'qualification_scope': 'OWNED_ISOLATED_NTFS_PRE_B06', 'production_authorized': False,
            'b06': 'NOT_STARTED', 'issued_by': 'CDT21_G5_V005_SUPERVISOR'}



def make_owner(run_id):
    return {'schema': 'CDT19_ENGINEERING_RUN_OWNER_V001', 'package_sha256': PACKAGE_SHA,
            'production_authorized': False, 'run_id': run_id}


def plain_directory(path):
    """Existing component must be a real directory, never a link or junction."""
    if os.path.lexists(path):
        require(path.is_dir() and not path.is_symlink() and not path.is_junction(), 'ALIASED_DIRECTORY:' + str(path))


def build_return(root, stage, out_zip, package_sha, native_sha):
    """Outer return. Duplicates of the V005 package and of R08_RETURN.zip are
    indexed by hash instead of being copied a second time."""
    skip = {'FINAL_G5/INPUTS/FINAL_PACKAGE.zip': package_sha, 'FINAL_G5/INPUTS/NATIVE_RETURN.zip': native_sha}
    picked, index, excluded = [], [], []
    for name in ['R08_RETURN.zip', 'R08_RETURN.sha256', 'ENGINEERING_RESULT.json', 'LIVE_STATUS.json',
                 'OWNER.json', 'RETURN_LOCK_SCOPE.json', 'CDT21_SUPERVISOR_BOOTSTRAP.json'] + \
                sorted(p.name for p in root.glob('CDT21_SUPERVISOR_RESUME_*.json')):
        if (root / name).is_file():
            picked.append((root / name, name))
    for name in (WITNESS_NAME, 'TICKSTORE_ISOLATED_INSTALL_WITNESS.json'):
        if (root / 'INPUTS' / name).is_file():
            picked.append((root / 'INPUTS' / name, 'INPUTS/' + name))
    trees = [root / 'FINAL_G5', root / 'SOURCE_REVIEW', root / LEDGER_DIR, root / JOURNAL_DIR] + sorted(root.glob('G5_ASSEMBLY_INPUTS_*'))
    for tree in trees:
        if tree.is_dir():
            for p in sorted(tree.rglob('*')):
                if p.is_file():
                    rel = p.relative_to(root).as_posix()
                    if rel in skip:
                        actual = sha_file(p)
                        excluded.append({'member': rel, 'sha256': actual, 'bytes': p.stat().st_size,
                                         'expected_sha256': skip[rel], 'equal': actual == skip[rel]})
                    else:
                        picked.append((p, rel))
    for p, rel in ((stage / SUPERVISOR_NAME, 'SUPERVISOR/' + SUPERVISOR_NAME),
                   (stage / 'SUPERVISOR_CONSOLE.log', 'SUPERVISOR/SUPERVISOR_CONSOLE.log'),
                   (stage / 'SUPERVISOR_CONSOLE_QUALIFY.log', 'SUPERVISOR/SUPERVISOR_CONSOLE_QUALIFY.log')):
        if p.is_file():
            picked.append((p, rel))
    partial = out_zip.with_name(out_zip.name + '.partial')
    with zipfile.ZipFile(partial, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as arc:
        for p, rel in picked:
            if rel.endswith('.zip'):
                arc.write(p, rel, compress_type=zipfile.ZIP_STORED)
            else:
                arc.write(p, rel)
            index.append({'member': rel, 'sha256': sha_file(p), 'bytes': p.stat().st_size})
        arc.writestr('RETURN_INDEX.json', encoded({'schema': 'CDT21_G5_V005_RETURN_INDEX_V001',
                     'run_id': root.name, 'members': index, 'excluded_duplicates': excluded}))
    with zipfile.ZipFile(partial) as arc:
        require(arc.testzip() is None, 'RETURN_CRC')
    os.replace(partial, out_zip)
    return excluded


class SupervisorJob:
    """Kill-on-close Job that holds this supervisor and, by inheritance, the
    whole campaign tree; closing it (normal exit or crash) leaves no orphan."""
    def __init__(self):
        import ctypes
        from ctypes import wintypes as w
        self.ctypes = ctypes
        k = self.k = ctypes.WinDLL('kernel32', use_last_error=True)
        k.CreateJobObjectW.argtypes = [ctypes.c_void_p, w.LPCWSTR]; k.CreateJobObjectW.restype = w.HANDLE
        k.SetInformationJobObject.argtypes = [w.HANDLE, ctypes.c_int, ctypes.c_void_p, w.DWORD]
        k.SetInformationJobObject.restype = w.BOOL
        k.QueryInformationJobObject.argtypes = [w.HANDLE, ctypes.c_int, ctypes.c_void_p, w.DWORD, ctypes.c_void_p]
        k.QueryInformationJobObject.restype = w.BOOL
        k.AssignProcessToJobObject.argtypes = [w.HANDLE, w.HANDLE]; k.AssignProcessToJobObject.restype = w.BOOL
        k.GetCurrentProcess.restype = w.HANDLE
        k.CloseHandle.argtypes = [w.HANDLE]; k.CloseHandle.restype = w.BOOL
        k.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]; k.OpenProcess.restype = w.HANDLE
        k.IsProcessInJob.argtypes = [w.HANDLE, w.HANDLE, ctypes.POINTER(w.BOOL)]; k.IsProcessInJob.restype = w.BOOL
        k.GetProcessTimes.argtypes = [w.HANDLE] + [ctypes.POINTER(w.FILETIME)] * 4; k.GetProcessTimes.restype = w.BOOL
        k.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]; k.WaitForSingleObject.restype = w.DWORD
        self.w = w

        class Basic(ctypes.Structure):
            _fields_ = [('PerProcessUserTimeLimit', ctypes.c_int64), ('PerJobUserTimeLimit', ctypes.c_int64),
                        ('LimitFlags', w.DWORD), ('MinimumWorkingSetSize', ctypes.c_size_t),
                        ('MaximumWorkingSetSize', ctypes.c_size_t), ('ActiveProcessLimit', w.DWORD),
                        ('Affinity', ctypes.c_size_t), ('PriorityClass', w.DWORD), ('SchedulingClass', w.DWORD)]
        class IO(ctypes.Structure):
            _fields_ = [(n, ctypes.c_uint64) for n in ('ReadOperationCount', 'WriteOperationCount',
                         'OtherOperationCount', 'ReadTransferCount', 'WriteTransferCount', 'OtherTransferCount')]
        class Extended(ctypes.Structure):
            _fields_ = [('BasicLimitInformation', Basic), ('IoInfo', IO),
                        ('ProcessMemoryLimit', ctypes.c_size_t), ('JobMemoryLimit', ctypes.c_size_t),
                        ('PeakProcessMemoryUsed', ctypes.c_size_t), ('PeakJobMemoryUsed', ctypes.c_size_t)]
        class Accounting(ctypes.Structure):
            _fields_ = [('TotalUserTime', ctypes.c_int64), ('TotalKernelTime', ctypes.c_int64),
                        ('ThisPeriodTotalUserTime', ctypes.c_int64), ('ThisPeriodTotalKernelTime', ctypes.c_int64),
                        ('TotalPageFaultCount', w.DWORD), ('TotalProcesses', w.DWORD),
                        ('ActiveProcesses', w.DWORD), ('TotalTerminatedProcesses', w.DWORD)]
        self.Accounting = Accounting
        self.handle = k.CreateJobObjectW(None, None)
        require(bool(self.handle), 'SUPERVISOR_JOB_CREATE:' + str(ctypes.get_last_error()))
        limits = Extended(); limits.BasicLimitInformation.LimitFlags = 0x2000  # KILL_ON_JOB_CLOSE
        require(bool(k.SetInformationJobObject(self.handle, 9, ctypes.byref(limits), ctypes.sizeof(limits))),
                'SUPERVISOR_JOB_LIMITS:' + str(ctypes.get_last_error()))
        require(bool(k.AssignProcessToJobObject(self.handle, k.GetCurrentProcess())),
                'SUPERVISOR_JOB_ASSIGN:' + str(ctypes.get_last_error()))

    def active(self):
        info = self.Accounting()
        ok = self.k.QueryInformationJobObject(self.handle, 1, self.ctypes.byref(info),
                                              self.ctypes.sizeof(info), None)
        return int(info.ActiveProcesses) if ok else -1

    def census(self):
        """R4: live processes of this Job, nested Jobs included (JobObjectBasicProcessIdList), as (pid, creation)
        read through a held handle; a PID reused outside this Job (IsProcessInJob) is not counted."""
        ctypes, k, w = self.ctypes, self.k, self.w
        capacity = 64
        for _ in range(8):
            class PIDs(ctypes.Structure):
                _fields_ = [('assigned', w.DWORD), ('count', w.DWORD), ('pids', ctypes.c_size_t * capacity)]
            info = PIDs()
            ok = k.QueryInformationJobObject(self.handle, 3, ctypes.byref(info), ctypes.sizeof(info), None)
            if ok and info.count == info.assigned:
                pids = list(info.pids[:info.count]); break
            require(ok or ctypes.get_last_error() == 234, 'JOB_CENSUS_QUERY:' + str(ctypes.get_last_error()))
            capacity = max(capacity * 2, int(info.assigned))
        else:
            raise Blocked('JOB_CENSUS_UNSTABLE')
        seen = []
        for pid in sorted(set(pids)):
            handle = k.OpenProcess(0x00101000, False, pid)  # SYNCHRONIZE | QUERY_LIMITED_INFORMATION
            if not handle:
                require(ctypes.get_last_error() == 87, 'JOB_CENSUS_OPEN:' + str(ctypes.get_last_error()))
                continue  # exited before open
            try:
                member = w.BOOL()
                require(bool(k.IsProcessInJob(handle, self.handle, ctypes.byref(member))), 'JOB_CENSUS_MEMBERSHIP')
                if not member.value:
                    continue  # PID reused outside this Job
                times = [w.FILETIME() for _ in range(4)]
                require(bool(k.GetProcessTimes(handle, *(ctypes.byref(t) for t in times))), 'JOB_CENSUS_TIMES')
                wait = k.WaitForSingleObject(handle, 0)
                require(wait in (0, 258), 'JOB_CENSUS_WAIT')
                if wait == 258:
                    seen.append({'pid': pid, 'creation_filetime': (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime})
            finally:
                k.CloseHandle(handle)
        return seen

    def nested_census_probe(self, native):
        """R4 Q (no effect): a child moved into a nested Job, as the frozen ProcessJob does with every unit, is seen
        by census() with the identity that the frozen R.native_process reports; so is this process."""
        import subprocess
        child = subprocess.Popen([sys.executable, '-I', '-S', '-c', 'import time; time.sleep(60)'],
                                 stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        nested = None
        try:
            nested = self.k.CreateJobObjectW(None, None)
            require(bool(nested), 'PROBE_NESTED_JOB_CREATE:' + str(self.ctypes.get_last_error()))
            require(bool(self.k.AssignProcessToJobObject(nested, int(child._handle))),
                    'PROBE_NESTED_JOB_ASSIGN:' + str(self.ctypes.get_last_error()))
            mine, theirs = native(os.getpid()), native(child.pid)
            seen = {(p['pid'], p['creation_filetime']) for p in self.census()}
            return {'self': [mine['pid'], mine['creation_filetime']], 'nested_child': [theirs['pid'], theirs['creation_filetime']],
                    'census_size': len(seen), 'seen_self': (mine['pid'], mine['creation_filetime']) in seen,
                    'seen_nested_child': (theirs['pid'], theirs['creation_filetime']) in seen}
        finally:
            child.kill(); child.wait(30)
            if nested:
                self.k.CloseHandle(nested)


def fixture_extract_dir(local, stamp):
    """Layout required by the frozen b2d fixture: <...>/CURRENT_G5_DELTA_<id>/EXTRACTED."""
    return Path(local) / EXTRACT_HOME / (DELTA_PREFIX + stamp) / 'EXTRACTED'


def check_fixture_contract(extracted):
    # Same predicate as test_b2d_origin_decision_binder.setUp (Windows branch).
    impl = extracted / 'implementation_v001'
    parent = impl.parent.parent
    require(impl.parent.name == 'EXTRACTED' and parent.name.startswith(DELTA_PREFIX), 'FIXTURE_LAYOUT')
    require(os.path.normcase(os.path.realpath(str(parent))) == os.path.normcase(str(parent)), 'FIXTURE_LAYOUT_ALIAS')
    require(sha_file(extracted / B2D_TEST_REL) == B2D_TEST_SHA, 'B2D_TEST_SOURCE_SHA')


def plan_keys(extracted):
    """The 38 keys of the frozen PRE_G06_CAMPAIGN.main plan, read from frozen constants."""
    cand = extracted / 'implementation_v001' / 'candidate'
    for folder in ('full', 'control', 'adapter', 'g5proof'):
        p = str(cand / folder)
        if p not in sys.path:
            sys.path.insert(0, p)
    import FULL_G5_COMPLETE_PROOF_GATE as gate
    import PRE_G06_CAMPAIGN as campaign
    require(Path(campaign.__file__).resolve() == (extracted / CAMPAIGN_REL).resolve(), 'CAMPAIGN_IMPORT_PATH')
    plan = (['G5_' + n for n in ('PS51_INSTALL_MENU', 'STAGE_B_REAL_ISOLATED_PATH_NATIVE', 'D4_REAL_ISOLATED_PATH_NATIVE')] +
            ['SUITE_' + n for n in gate.SUITES if n not in campaign.STAGE_SUITES] +
            ['DELTA_' + n for n in campaign.EXTRA] + ['PRE_B06_11_CHAIN', 'G3_G6_NATIVE'])
    require(len(plan) == PLANNED_UNITS and len(set(plan)) == PLANNED_UNITS, 'PLAN_SHAPE')
    return plan


def tree_digest(base):
    """Read-only fingerprint of a tree: sorted (relpath, size, mtime_ns) of every entry, links not followed."""
    base = Path(base)
    if not base.exists():
        return {'exists': False}
    rows = []
    stack = [base]
    while stack:
        d = stack.pop()
        with os.scandir(d) as it:
            for e in it:
                st = os.lstat(e.path)  # the entry itself, not the NTFS directory index (R2)
                rel = Path(e.path).relative_to(base).as_posix()
                rows.append((rel, st.st_size if e.is_file(follow_symlinks=False) else -1, st.st_mtime_ns))
                if e.is_dir(follow_symlinks=False):
                    stack.append(Path(e.path))
    rows.sort()
    return {'exists': True, 'entries': len(rows), 'sha256': sha_bytes(json.dumps(rows).encode())}


def production_fingerprint():
    """Read-only: production base must be identical before and after any effect."""
    base = Path(PRODUCTION)
    fp = {'path': PRODUCTION, 'tree': tree_digest(base)}
    for key, parts in (('menu', ('Scripts', 'Biblioteca', 'MENU.py')), ('bat', ('Manuten\u00e7\u00e3o Base de Dados.bat',))):
        p = base.joinpath(*parts)
        fp[key] = sha_file(p) if p.is_file() else 'ABSENT'
    return fp


def reparse_free(path):
    """Every existing component of path must be a plain entry (no symlink, junction or reparse point)."""
    p = Path(os.path.abspath(path)); cur = Path(p.anchor)
    for part in p.parts[1:]:
        cur = cur / part
        if not os.path.lexists(cur):
            break
        st = os.lstat(cur)
        if os.path.islink(cur) or (getattr(st, 'st_file_attributes', 0) & 0x400):
            return False, str(cur)
    return True, ''


def path_isolation(roots):
    """Every planned write root: canonical, reparse-free, outside the production base."""
    rows = {}
    for label, (path, enforce) in roots.items():
        p = Path(os.path.abspath(path))
        anc = p
        while not anc.exists() and anc != anc.parent:
            anc = anc.parent
        canonical = os.path.normcase(os.path.realpath(str(anc))) == os.path.normcase(str(anc))
        free, where = reparse_free(p)
        outside = not os.path.normcase(str(p)).startswith(os.path.normcase(PRODUCTION))
        ok = canonical and free and outside
        rows[label] = {'path': str(p), 'canonical': canonical, 'reparse_free': free, 'reparse_at': where,
                       'outside_production': outside, 'enforced': enforce, 'status': 'PASS' if ok else ('FAIL' if enforce else 'REPORT_ONLY')}
    return rows


def native_b2d(extracted, temp, log_path):
    """Run the frozen b2d suite natively from one extraction layout (no edits)."""
    import subprocess
    tests = extracted / 'implementation_v001' / 'tests'
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith('PYTHON')}
    env.update(TEMP=str(temp), TMP=str(temp))
    r = subprocess.run([sys.executable, '-I', '-B', '-m', 'unittest', 'discover', '-s', str(tests),
                        '-p', 'test_b2d_origin_decision_binder.py', '-t', str(tests), '-v'],
                       cwd=str(temp), env=env, capture_output=True, text=True, timeout=900)
    out = (r.stdout or '') + (r.stderr or '')
    Path(log_path).write_text(out, encoding='utf-8')
    ran = re.findall(r'(?m)^Ran (\d+) tests?', out)
    return {'exit': r.returncode, 'ran': int(ran[-1]) if ran else 0, 'ok': re.search(r'(?m)^OK\s*$', out) is not None,
            'contract_not_met': out.count('G5_FIXTURE_RUNROOT_CONTRACT_NOT_MET'), 'log': str(log_path),
            'log_sha256': sha_file(log_path)}


def volume_filesystem(drive_root):
    import ctypes
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    name = ctypes.create_unicode_buffer(261)
    ok = k.GetVolumeInformationW(ctypes.c_wchar_p(drive_root), None, 0, None, None, None, name, 261)
    require(bool(ok), 'VOLUME_INFORMATION:' + drive_root)
    return name.value



def owner_binding(path):
    """Read-only label of a pre-existing run root or D-lab from its OWNER.json (never opened for writing)."""
    try:
        sha = strict_json((Path(path) / 'OWNER.json').read_bytes()).get('package_sha256')
    except (OSError, ValueError, Blocked):
        return 'NO_READABLE_OWNER'
    return {PACKAGE_SHA: 'V005', V004_PACKAGE_SHA: 'V004', V003_PACKAGE_SHA: 'V003'}.get(sha, 'OTHER')


def link_safe_digest(base):
    """Read-only digest of a foreign tree that never follows a symlink, junction or other reparse point and
    records unreadable directories by name (a leftover link or ACL of another run can neither loop nor block)."""
    base = Path(base)
    rows, stack, links, unreadable = [], [base], 0, 0
    while stack:
        d = stack.pop()
        try:
            with os.scandir(d) as it:
                entries = list(it)
        except OSError:
            rows.append((d.relative_to(base).as_posix(), -3, 0)); unreadable += 1
            continue
        for e in entries:
            rel = Path(e.path).relative_to(base).as_posix()
            try:
                st = os.lstat(e.path)  # the entry itself, not the NTFS directory index (R2)
            except OSError:
                rows.append((rel, -4, 0)); unreadable += 1
                continue
            link = e.is_symlink() or e.is_junction() or bool(getattr(st, 'st_file_attributes', 0) & 0x400)
            if link:
                rows.append((rel, -2, st.st_mtime_ns)); links += 1
            elif e.is_dir(follow_symlinks=False):
                rows.append((rel, -1, st.st_mtime_ns)); stack.append(Path(e.path))
            else:
                rows.append((rel, st.st_size, st.st_mtime_ns))
    rows.sort()
    _ROWS[str(base)] = rows
    return {'exists': True, 'entries': len(rows), 'links_not_followed': links, 'unreadable_dirs': unreadable,
            'sha256': sha_bytes(json.dumps(rows).encode())}


def foreign_roots(local):
    """Read-only digest of every pre-existing run root and D-lab (the V003 runs included).

    A new campaign may add exactly its own run root and D-lab; nothing that existed before Q may change."""
    out = {}
    for label, parent in (('run', Path(local) / RUN_PARENT), ('d_lab', Path(D_LABS))):
        if os.path.lexists(parent):
            plain_directory(parent)
            with os.scandir(parent) as it:
                entries = sorted(it, key=lambda x: x.name)
            for e in entries:
                if e.is_dir(follow_symlinks=False) and not e.is_symlink() and not e.is_junction():
                    out[label + '/' + e.name] = dict(link_safe_digest(Path(e.path)), owner=owner_binding(e.path))
                else:
                    out[label + '/' + e.name] = {'not_a_directory': True, 'size': os.lstat(e.path).st_size}
    return out


def foreign_unchanged(before, after, run_id):
    changed = sorted(k for k in before if after.get(k) != before[k])
    added = sorted(k for k in after if k not in before)
    require(not changed, 'FOREIGN_ROOT_CHANGED:' + ','.join(changed))
    require(added == ['d_lab/' + run_id, 'run/' + run_id], 'FOREIGN_ROOT_ADDED:' + ','.join(added))
    return {'pre_existing': len(before), 'unchanged': len(before), 'added': added}


def foreign_path(local, key):
    label, name = key.split('/', 1)
    return str(Path(local) / RUN_PARENT / name) if label == 'run' else str(Path(D_LABS) / name)


def foreign_detail(local, before, after, rows_before, rows_after):
    """Evidence of a foreign-root difference, per root and per entry (never relaxes a check)."""
    d = {'added': sorted(k for k in after if k not in before), 'removed': sorted(k for k in before if k not in after),
         'changed': {}}
    for k in sorted(k for k in before if k in after and before[k] != after[k]):
        r1 = {r[0]: r for r in rows_before.get(foreign_path(local, k), [])}
        r2 = {r[0]: r for r in rows_after.get(foreign_path(local, k), [])}
        d['changed'][k] = {'before': before[k], 'after': after[k],
                           'entries_changed': [[r1[x], r2[x]] for x in sorted(r1) if x in r2 and r1[x] != r2[x]][:200],
                           'entries_added': [r2[x] for x in sorted(r2) if x not in r1][:200],
                           'entries_removed': [r1[x] for x in sorted(r1) if x not in r2][:200]}
    return d


def foreign_checked(local, before, rows_before, run_id, result, key, resume=False):
    """foreign_unchanged, recording result[key + '_difference'] (per entry) whenever it is going to refuse."""
    after = foreign_roots(local)
    own = ('d_lab/' + run_id, 'run/' + run_id)
    if resume:
        if set(after) != set(before) or any(after[k] != v for k, v in before.items() if k not in own):
            result[key + '_difference'] = foreign_detail(local, before, after, rows_before, dict(_ROWS))
        return foreign_unchanged_resume(before, after, run_id)
    if {k: v for k, v in after.items() if k not in own} != before or not all(k in after for k in own):
        result[key + '_difference'] = foreign_detail(local, before, after, rows_before, dict(_ROWS))
    return foreign_unchanged(before, after, run_id)


def commits_bound(root, plan):
    """The COMMITs of the new run: exactly the 38 planned keys, closed, bound to the V005 package and code."""
    keys = sorted(p.stem for p in (root / 'COMMITS').glob('*.json'))
    require(keys == sorted(plan), 'COMMIT_SET_NE_PLAN:' + str(len(keys)))
    shas = {}
    for key in keys:
        p = root / 'COMMITS' / (key + '.json')
        obj = strict_json(p.read_bytes())
        require(obj.get('package_sha256') != V003_PACKAGE_SHA and obj.get('code_sha256') != V003_CODE_SHA,
                'COMMIT_BOUND_TO_V003:' + key)
        require(obj.get('schema') == 'CDT19_NATIVE_UNIT_COMMIT_V001' and obj.get('package_sha256') == PACKAGE_SHA
                and obj.get('code_sha256') == CODE_SHA and obj.get('result', {}).get('status') == 'PASS'
                and obj['result'].get('exit_code') == 0 and obj.get('own_descendants_final') == []
                and isinstance(obj.get('artifacts'), list) and bool(obj['artifacts']), 'COMMIT_NOT_BOUND_TO_V005:' + key)
        for ref in obj['artifacts']:
            target = root.joinpath(*PurePosixPath(ref['member']).parts)
            require(target.is_file() and target.stat().st_size == ref['bytes'] and sha_file(target) == ref['sha256'],
                    'COMMIT_ARTIFACT_DRIFT:' + key + ':' + ref['member'])
        shas[key] = sha_file(p)
    return shas


def final_checkpoints(root, plan):
    """Terminal receipts of the new run agree with its COMMITs (read-only)."""
    live = strict_json((root / 'LIVE_STATUS.json').read_bytes())
    require(sorted(live.get('commit_receipt_keys', [])) == sorted(plan), 'LIVE_STATUS_COMMIT_KEYS')
    require(live.get('status') == 'PASS_NATIVE_INTEGRATED_PRE_B06', 'LIVE_STATUS_NOT_PASS')
    recorded = (root / 'R08_RETURN.sha256').read_text(encoding='ascii').split()[0]
    require(recorded == sha_file(root / 'R08_RETURN.zip'), 'R08_RETURN_SHA_FILE')
    require(strict_json((root / 'RETURN_LOCK_SCOPE.json').read_bytes()).get('run_id') == root.name, 'RETURN_LOCK_SCOPE_RUN')
    require(not (root / 'R08_RETURN.zip.partial').exists(), 'R08_RETURN_PARTIAL_LEFT')
    ia = root / 'INTERRUPTED_ATTEMPTS'
    return {'live_status_keys_equal_plan': True, 'r08_return_sha256': recorded,
            'interrupted_attempts': sorted(p.name for p in ia.iterdir()) if ia.is_dir() else []}


def foreign_unchanged_resume(before, after, run_id):
    own = ('d_lab/' + run_id, 'run/' + run_id)
    require(all(k in before and k in after for k in own), 'RESUME_ROOT_NOT_IN_FOREIGN_SET')
    changed = sorted(k for k in before if k not in own and after.get(k) != before[k])
    removed = sorted(k for k in before if k not in after)
    added = sorted(k for k in after if k not in before)
    require(not changed and not removed, 'FOREIGN_ROOT_CHANGED:' + ','.join(changed + removed))
    require(not added, 'FOREIGN_ROOT_ADDED:' + ','.join(added))
    return {'pre_existing': len(before), 'unchanged': len(before) - 2, 'resumed_own': list(own), 'added': []}


def frozen_dead():
    import FULL_CRASH_RECOVERY as R  # frozen V005 module, importable after plan_keys()
    return R.dead


def ledger_record(root, key, attempt, supervisor_sha, campaign_pid):
    """Record a COMMIT the supervisor saw its own campaign child publish (same-campaign proof). Written in TEMP
    (outside the frozen seal) and moved atomically, so a seal never contains half a record."""
    entry = {'schema': LEDGER_SCHEMA, 'run_id': root.name, 'key': key,
             'commit_file_sha256': sha_file(root / 'COMMITS' / (key + '.json')), 'attempt': attempt,
             'supervisor_sha256': supervisor_sha, 'campaign_pid': campaign_pid,
             'observed_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    target = root / LEDGER_DIR / (key + '.json')
    require(not target.exists(), 'LEDGER_ENTRY_EXISTS:' + key)
    temp = root / 'TEMP' / ('LEDGER_' + key + '_' + attempt + '.json')
    write_new(temp, encoded(entry))
    os.replace(temp, target)
    return entry


def ledger_bound(root, commit_sha):
    """Every COMMIT on disk was observed by a supervisor of this campaign, byte for byte, and vice versa."""
    entries = {}
    for p in sorted((root / LEDGER_DIR).glob('*.json')):
        e = strict_json(p.read_bytes())
        require(e.get('schema') == LEDGER_SCHEMA and e.get('run_id') == root.name and e.get('key') == p.stem
                and e.get('supervisor_sha256') == sha_file(__file__), 'LEDGER_ENTRY_INVALID:' + p.stem)
        entries[p.stem] = e
    for key, sha in sorted(commit_sha.items()):
        require(key in entries, 'COMMIT_NOT_LEDGERED:' + key)
        require(entries[key]['commit_file_sha256'] == sha, 'LEDGER_DRIFT:' + key)
    extra = sorted(set(entries) - set(commit_sha))
    require(not extra, 'LEDGER_WITHOUT_COMMIT:' + ','.join(extra))
    return {k: entries[k]['attempt'] for k in sorted(entries)}


def frozen_native():
    import FULL_CRASH_RECOVERY as R  # frozen V005 module, importable after plan_keys()
    return R.native_process


def journal_write(root, name, obj):
    """R4: create-once journal record, written and read back in TEMP (outside the frozen seal), moved atomically."""
    target = root / JOURNAL_DIR / name
    require(not target.exists(), 'JOURNAL_RECORD_EXISTS:' + name)
    temp = root / 'TEMP' / ('JOURNAL_' + name)
    write_new(temp, encoded(obj))
    os.replace(temp, target)
    return sha_file(target)


def journal_attempt(root, attempt, supervisor_sha, supervisor, plan):
    """R4: durable record of this attempt BEFORE its campaign child exists: sequence, supervisor identity and the
    ledger at start.  The latest record names the only attempt whose interrupted COMMIT may be reconciled."""
    journal = root / JOURNAL_DIR
    ledgered = {p.stem for p in (root / LEDGER_DIR).glob('*.json')}
    rec = {'schema': ATTEMPT_SCHEMA, 'run_id': root.name, 'attempt': attempt,
           'sequence': len(list(journal.glob('ATTEMPT_*.json'))), 'supervisor_sha256': supervisor_sha,
           'supervisor': {'pid': supervisor['pid'], 'creation_filetime': supervisor['creation_filetime']},
           'ledger_keys_at_start': [k for k in plan if k in ledgered],
           'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    journal_write(root, 'ATTEMPT_' + attempt + '.json', rec)
    return rec


def journal_census(root, attempt, key, processes, campaign_pid, supervisor_sha, line):
    """R4: the supervisor's own Job census while ITS campaign child reports unit <key> active (HEARTBEAT on its
    stdout).  The Job holds only this supervisor's tree (no breakaway; unit Jobs are nested), so a process listed
    here belongs to this attempt.  Recorded once per unit, and only when a unit process is seen."""
    if not [p for p in processes if p['pid'] not in (os.getpid(), campaign_pid)]:
        return False
    journal_write(root, 'CENSUS_' + attempt + '_' + key + '.json',
                  {'schema': CENSUS_SCHEMA, 'run_id': root.name, 'attempt': attempt, 'key': key,
                   'supervisor_sha256': supervisor_sha, 'supervisor_pid': os.getpid(), 'campaign_pid': campaign_pid,
                   'processes': [{'pid': p['pid'], 'creation_filetime': p['creation_filetime']} for p in processes],
                   'trigger': line[:240], 'observed_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())})
    return True


def reconcile_proof(root, key, commit_sha, ledgered):
    """R4 (origin finding R3-F01): the frozen campaign publishes COMMITS/<key>.json BEFORE printing COMMITTED and
    the ledger follows that line, so a crash in between leaves one durable, unledgered COMMIT.  It is this
    campaign's own only if all hold: its single owner identity (pid, creation) is the process of its committed
    RESULT.json; the latest attempt record of this root, written by this supervisor, did not have it ledgered;
    and this supervisor's own Job census of that attempt, taken while its campaign child reported that unit active,
    lists that owner, which is neither the supervisor nor the campaign child.  Any doubt refuses."""
    def need(ok, why):
        require(ok, 'COMMIT_NOT_LEDGERED:' + key + ':RECONCILE_' + why)
    commit = strict_json((root / 'COMMITS' / (key + '.json')).read_bytes())
    owner = commit.get('owner')
    need(isinstance(owner, list) and len(owner) == 1 and isinstance(owner[0], dict)
         and type(owner[0].get('pid')) is int and owner[0]['pid'] > 0
         and type(owner[0].get('creation_filetime')) is int and owner[0]['creation_filetime'] > 0, 'OWNER_IDENTITY')
    ident = (owner[0]['pid'], owner[0]['creation_filetime'])
    need(('UNITS/' + key + '/RESULT.json') in [r.get('member') for r in commit['artifacts']], 'RESULT_NOT_COMMITTED')
    res = strict_json((root / 'UNITS' / key / 'RESULT.json').read_bytes())  # bytes re-hashed against the COMMIT
    proc = res.get('process') if isinstance(res.get('process'), dict) else {}
    need(res.get('unit') == key and commit.get('result') == res
         and (proc.get('pid'), proc.get('creation_filetime')) == ident, 'RESULT_PROCESS_NE_OWNER')
    journal = root / JOURNAL_DIR
    records = [strict_json(p.read_bytes()) for p in sorted(journal.glob('ATTEMPT_*.json'))]
    seqs = [r.get('sequence') for r in records]
    need(bool(records) and all(type(s) is int for s in seqs) and sorted(seqs) == list(range(len(seqs))), 'ATTEMPT_JOURNAL')
    last = max(records, key=lambda r: r['sequence'])
    start = last.get('ledger_keys_at_start')
    need(last.get('schema') == ATTEMPT_SCHEMA and last.get('run_id') == root.name
         and last.get('supervisor_sha256') == sha_file(__file__) and isinstance(last.get('attempt'), str)
         and (journal / ('ATTEMPT_' + last['attempt'] + '.json')).is_file()
         and isinstance(start, list) and set(start) <= set(ledgered) and key not in start, 'ATTEMPT_RECORD')
    path = journal / ('CENSUS_' + last['attempt'] + '_' + key + '.json')
    need(path.is_file(), 'NO_CENSUS_IN_LAST_ATTEMPT')
    census = strict_json(path.read_bytes())
    need(census.get('schema') == CENSUS_SCHEMA and census.get('run_id') == root.name
         and census.get('attempt') == last['attempt'] and census.get('key') == key
         and census.get('supervisor_sha256') == sha_file(__file__), 'CENSUS_RECORD')
    seen = {(p.get('pid'), p.get('creation_filetime')) for p in census.get('processes') or [] if isinstance(p, dict)}
    need(ident in seen, 'OWNER_NOT_IN_SUPERVISOR_CENSUS')
    sup = last.get('supervisor') or {}
    need(ident != (sup.get('pid'), sup.get('creation_filetime'))
         and ident[0] not in (census.get('campaign_pid'), census.get('supervisor_pid')), 'OWNER_IS_SUPERVISOR_OR_CAMPAIGN')
    return {'key': key, 'commit_file_sha256': commit_sha, 'owner': {'pid': ident[0], 'creation_filetime': ident[1]},
            'result_sha256': sha_file(root / 'UNITS' / key / 'RESULT.json'), 'attempt': last['attempt'],
            'attempt_sequence': last['sequence'], 'campaign_pid': census.get('campaign_pid'),
            'attempt_record_sha256': sha_file(journal / ('ATTEMPT_' + last['attempt'] + '.json')),
            'census_record_sha256': sha_file(path), 'basis': RECONCILED_BASIS}


def ledger_admit(root, commit_sha, plan):
    """R4 resume admission of the ledger: ledger_bound on every COMMIT except at most ONE unledgered COMMIT, which
    must be the next plan unit after the ledger and pass reconcile_proof.  Returns (attempts, proof or None)."""
    entries = {p.stem for p in (root / LEDGER_DIR).glob('*.json')}
    pending = [k for k in plan if k in commit_sha and k not in entries]
    if not pending:
        return ledger_bound(root, commit_sha), None
    require(len(pending) == 1, 'COMMIT_NOT_LEDGERED:' + ','.join(pending) + ':RECONCILE_MORE_THAN_ONE')
    key = pending[0]
    attempts = ledger_bound(root, {k: v for k, v in commit_sha.items() if k != key})
    n = len(attempts)
    require(set(attempts) == set(plan[:n]), 'COMMIT_NOT_LEDGERED:' + key + ':RECONCILE_LEDGER_NOT_PLAN_PREFIX')
    require(key == plan[n], 'COMMIT_NOT_LEDGERED:' + key + ':RECONCILE_NOT_NEXT_PLAN_KEY')
    return attempts, reconcile_proof(root, key, commit_sha[key], set(attempts))


def ledger_reconcile(root, proof, attempt, supervisor_sha):
    """R4 E, under the campaign lock and before the frozen campaign starts: record the reconciled COMMIT in the ledger
    with its proof (create-once, via TEMP).  The frozen run_unit then reuses it; it is never re-executed."""
    key = proof['key']
    require(sha_file(root / 'COMMITS' / (key + '.json')) == proof['commit_file_sha256'], 'RECONCILE_COMMIT_CHANGED:' + key)
    entry = {'schema': LEDGER_SCHEMA, 'run_id': root.name, 'key': key, 'commit_file_sha256': proof['commit_file_sha256'],
             'attempt': proof['attempt'], 'supervisor_sha256': supervisor_sha, 'campaign_pid': proof['campaign_pid'],
             'basis': RECONCILED_BASIS, 'reconciled_by_attempt': attempt, 'proof': proof,
             'observed_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    target = root / LEDGER_DIR / (key + '.json')
    require(not target.exists(), 'LEDGER_ENTRY_EXISTS:' + key)
    temp = root / 'TEMP' / ('LEDGER_' + key + '_' + attempt + '.json')
    write_new(temp, encoded(entry))
    os.replace(temp, target)
    return entry


def resume_precheck(root, local, plan):
    """Read-only admission of an interrupted run of THIS campaign: same root, same supervisor, same V005 bytes;
    every COMMIT closed, bound to V005, artifact-intact and in this campaign's ledger.  No effect."""
    root = Path(os.path.abspath(root))
    require(root.parent == Path(local) / RUN_PARENT and RUN_NAME.fullmatch(root.name) is not None, 'RESUME_ROOT_LOCATION')
    plain_directory(root)
    run_id = root.name; dlab = Path(D_LABS) / run_id
    boot = strict_json((root / 'CDT21_SUPERVISOR_BOOTSTRAP.json').read_bytes())
    require(boot.get('schema') == 'CDT21_G5_V005_SUPERVISOR_BOOTSTRAP_V001' and boot.get('run_id') == run_id
            and boot.get('mode') == MODE_NEW and boot.get('package_sha256') == PACKAGE_SHA
            and boot.get('code_manifest_sha256') == CODE_SHA and boot.get('package_manifest_sha256') == MANIFEST_SHA
            and boot.get('campaign_source_sha256') == CAMPAIGN_SHA and boot.get('completeness_source_sha256') == COMPLETENESS_SHA
            and boot.get('supervisor_sha256') == sha_file(__file__) and boot.get('v003_commits_reused') == 0
            and boot.get('commit_ledger') == LEDGER_DIR and boot.get('attempt_journal') == JOURNAL_DIR, 'RESUME_BOOTSTRAP_BINDING')
    owner_raw = encoded(make_owner(run_id))
    require((root / 'OWNER.json').read_bytes() == owner_raw, 'RESUME_OWNER')
    plain_directory(dlab)
    require((dlab / 'OWNER.json').read_bytes() == owner_raw, 'RESUME_D_LAB_OWNER')
    zips = sorted(p.name for p in (root / 'INPUTS').iterdir() if p.is_file() and p.suffix.lower() == '.zip')
    require(zips == [PACKAGE_NAME] and sha_file(root / 'INPUTS' / PACKAGE_NAME) == PACKAGE_SHA, 'RESUME_INPUT_PACKAGE')
    require((root / 'INPUTS' / WITNESS_NAME).read_bytes() == encoded(make_witness(run_id, MANIFEST_SHA)), 'RESUME_WITNESS')
    require((root / 'CAMPAIGN.lock').is_file() and (root / 'TEMP').is_dir() and (root / 'QUAL_C').is_dir()
            and (dlab / 'WRITER_EFFECTFUL').is_dir() and (root / LEDGER_DIR).is_dir()
            and (root / JOURNAL_DIR).is_dir(), 'RESUME_LAYOUT')
    prior = 'NO_TERMINAL_INTERRUPTED'
    if (root / 'ENGINEERING_RESULT.json').exists():
        eng = strict_json((root / 'ENGINEERING_RESULT.json').read_bytes())
        prior = eng.get('status')
        bound = (('run_id', run_id), ('final_zip_sha256', PACKAGE_SHA), ('code_manifest_sha256', CODE_SHA))
        # The frozen main records these bindings right after verify_package; only an early BLOCKED may lack them.
        require(eng.get('schema') == 'CDT19_PRE_B06_NATIVE_ENGINEERING_V002' and all(eng.get(k) in (None, v) for k, v in bound)
                and (prior == 'BLOCKED' or all(eng.get(k) == v for k, v in bound)), 'RESUME_ENGINEERING_BINDING')
        require(prior in ('BLOCKED', 'SAFE_STOP', 'PASS_NATIVE_INTEGRATED_PRE_B06'), 'RESUME_PRIOR_STATUS:' + str(prior))
    commit_sha = {}
    for p in sorted((root / 'COMMITS').glob('*.json')) if (root / 'COMMITS').is_dir() else []:
        require(p.stem in plan, 'RESUME_FOREIGN_COMMIT:' + p.stem)
        obj = strict_json(p.read_bytes())
        require(obj.get('package_sha256') != V003_PACKAGE_SHA and obj.get('code_sha256') != V003_CODE_SHA,
                'RESUME_COMMIT_BOUND_TO_V003:' + p.stem)
        require(obj.get('schema') == 'CDT19_NATIVE_UNIT_COMMIT_V001' and obj.get('package_sha256') == PACKAGE_SHA
                and obj.get('code_sha256') == CODE_SHA and obj.get('result', {}).get('status') == 'PASS'
                and obj['result'].get('exit_code') == 0 and obj.get('own_descendants_final') == []
                and isinstance(obj.get('artifacts'), list) and bool(obj['artifacts']), 'RESUME_COMMIT_NOT_BOUND_TO_V005:' + p.stem)
        for ref in obj['artifacts']:
            member = PurePosixPath(ref['member'])
            require(not member.is_absolute() and '..' not in member.parts, 'RESUME_COMMIT_ARTIFACT_ESCAPE:' + p.stem)
            target = root.joinpath(*member.parts)
            require(target.is_file() and target.stat().st_size == ref['bytes'] and sha_file(target) == ref['sha256'],
                    'RESUME_COMMIT_ARTIFACT_DRIFT:' + p.stem + ':' + ref['member'])
        commit_sha[p.stem] = sha_file(p)
    attempts, reconcile = ledger_admit(root, commit_sha, plan)
    return {'run_id': run_id, 'run_root': str(root), 'd_lab': str(dlab), 'prior_status': prior,
            'committed_before': [k for k in plan if k in commit_sha], 'commit_file_sha256': commit_sha,
            'ledger_attempts': attempts, 'pending': [k for k in plan if k not in commit_sha],
            'safe_stop_request_present': (root / 'SAFE_STOP.request').exists(),
            'prior_closure_present': (root / 'FINAL_G5').exists(), 'reconcile': reconcile}


def prior_processes_dead(root, dead):
    """Every process identity recorded by the prior attempt is dead or its PID reused (frozen R.dead)."""
    ids = {}
    for p in sorted((root / 'COMMITS').glob('*.json')):
        obj = strict_json(p.read_bytes())
        for ident in list(obj.get('owner') or []) + list(obj.get('observed_processes') or []):
            if isinstance(ident, dict) and type(ident.get('pid')) is int and type(ident.get('creation_filetime')) is int:
                ids[(ident['pid'], ident['creation_filetime'])] = {'pid': ident['pid'], 'creation_filetime': ident['creation_filetime']}
    for p in sorted((root / 'UNITS').glob('*/RESULT.json')):
        proc = strict_json(p.read_bytes()).get('process')
        if isinstance(proc, dict) and type(proc.get('pid')) is int and type(proc.get('creation_filetime')) is int:
            ids[(proc['pid'], proc['creation_filetime'])] = {'pid': proc['pid'], 'creation_filetime': proc['creation_filetime']}
    return [dict(dead(i), checked=True) for i in ids.values()]


def lock_probe(lock_path):
    """Read-only handle: the prior supervisor lock must be acquirable (then released at once)."""
    import msvcrt
    f = open(lock_path, 'rb')
    try:
        try:
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            return 'HELD_BY_ANOTHER_PROCESS'
        f.seek(0); msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        return 'ACQUIRED_AND_RELEASED'
    finally:
        f.close()


def preserve_prior_terminal(root, stage, stamp):
    """Copy (never move) the prior terminal receipts that the frozen campaign will overwrite; the consumed
    SAFE_STOP.request (which would stop the resumed campaign at once) is moved into the same folder."""
    keep = root / 'INTERRUPTED_ATTEMPTS' / ('PRIOR_TERMINAL_' + stamp)
    keep.mkdir(parents=True)
    copied = {}
    for name in ('ENGINEERING_RESULT.json', 'LIVE_STATUS.json', 'R08_RETURN.sha256', 'RETURN_LOCK_SCOPE.json'):
        if (root / name).is_file():
            raw = (root / name).read_bytes(); write_new(keep / name, raw); copied[name] = sha_bytes(raw)
    prior = {'schema': 'CDT21_G5_V005_PRIOR_TERMINAL_PRESERVATION_V001', 'run_id': root.name, 'copied': copied,
             'status': 'COPIED_NO_DELETE'}
    if (root / 'R08_RETURN.zip').is_file():
        z = root / 'R08_RETURN.zip'; copy = stage / ('PRIOR_R08_RETURN_' + root.name + '_' + stamp + '.zip')
        prior.update(prior_r08_return_sha256=sha_file(z), prior_r08_return_bytes=z.stat().st_size, prior_r08_return_copy=str(copy))
        shutil.copyfile(z, copy)
        require(sha_file(copy) == prior['prior_r08_return_sha256'], 'PRIOR_RETURN_COPY')
    stop = root / 'SAFE_STOP.request'
    if os.path.lexists(stop):
        require(stop.is_file() and not stop.is_symlink(), 'SAFE_STOP_REQUEST_TYPE')
        prior['safe_stop_request_sha256'] = sha_file(stop)
        os.replace(stop, keep / 'SAFE_STOP.request')
        prior['safe_stop_request_moved_to'] = (keep / 'SAFE_STOP.request').relative_to(root).as_posix()
    write_new(keep / 'PRESERVATION.json', encoded(prior))
    return prior


D4_SUCCESSOR_ARTIFACT = ('D:\\Base CSV\\Scripts\\TICKSTORE_R9_DEV\\TICKSTORE_D4_RESUMABLE_V002R22\\artifacts\\'
                         'TICKSTORE_V004R1_D4_RESUMABLE_V002R24_PACKAGE.zip')
D4_SUCCESSOR_ZIP_SHA = '8A05E76189E63379A60E2447DAA313765D30A2EAB78EAF4E9D91AA19CBFE3E73'  # V005: migration == bootstrap


def d4_successor_artifact_probe():
    """V005 (FULL integration GAP-04): read-only identity of the D4 successor artifact on D:, for the D4 preparation.
    Information only: never blocks this G5 campaign, never writes; a different file needs an origin decision."""
    p = Path(D4_SUCCESSOR_ARTIFACT)
    rec = {'path': str(p), 'expected_single_identity_sha256': D4_SUCCESSOR_ZIP_SHA, 'read_only': True}
    try:
        rec['present'] = p.is_file()
        if rec['present']:
            rec.update(bytes=p.stat().st_size, sha256=sha_file(p))
            rec['matches_single_identity'] = rec['sha256'] == D4_SUCCESSOR_ZIP_SHA
        rec['successor_package_dir_present'] = (p.parent.parent / 'SUCCESSOR_PACKAGE').is_dir()
    except OSError as exc:
        rec['error'] = type(exc).__name__ + ':' + str(exc)
    return rec


def qualify_main(a):
    """Native Windows qualification before any effect: no run root and no D-lab are created here."""
    global _console
    log_dir = Path(os.path.abspath(a.log_dir)); stage = Path(os.path.abspath(a.stage))
    started = time.time()
    q = {'schema': QUAL_SCHEMA, 'status': 'BLOCKED', 'supervisor_sha256': sha_file(__file__), 'candidate_sha256': PACKAGE_SHA,
         'code_manifest_sha256': CODE_SHA, 'log_dir': str(log_dir), 'mode': MODE_RESUME if a.resume_root else MODE_NEW,
         'resume_root': os.path.abspath(a.resume_root) if a.resume_root else '', 'checks': {}, 'blockers': [],
         'effects': 'EXTRACT_HOME_QUALIFICATION_COPIES_AND_LOG_DIR_ONLY', 'b06': 'NOT_STARTED'}
    def ok(k, v, d=''):
        q['checks'][k] = {'status': 'PASS' if v else 'FAIL', 'detail': d}
        require(v, 'QUAL_' + k + ':' + str(d)[:200])
    code = 2
    try:
        _console = open(stage / 'SUPERVISOR_CONSOLE_QUALIFY.log', 'xb')
        emit('QUALIFY SUPERVISOR=' + str(Path(__file__)) + ' SHA256=' + q['supervisor_sha256'])
        ok('windows_python_admin', os.name == 'nt' and sys.version_info[:2] == (3, 14), sys.version.split()[0])
        import ctypes
        ok('elevated', bool(ctypes.WinDLL('shell32').IsUserAnAdmin()))
        package = Path(os.path.abspath(a.package))
        ok('package_sha_v004', package.is_file() and sha_file(package) == PACKAGE_SHA and PACKAGE_SHA != V003_PACKAGE_SHA)
        review_raw = Path(a.review).read_bytes(); validate_review(review_raw); ok('source_review_binding', True, sha_bytes(review_raw))
        local = os.environ.get('LOCALAPPDATA', '')
        ok('localappdata_canonical', bool(local) and '%' not in local and '~' not in local
           and os.path.normcase(os.path.realpath(local)) == os.path.normcase(os.path.abspath(local)), local)
        ok('run_root_not_on_d', Path(local).drive.upper() != 'D:', local)
        ok('volumes_ntfs', volume_filesystem(Path(local).drive + '\\') == 'NTFS' and volume_filesystem('D:\\') == 'NTFS')
        ok('free_space', shutil.disk_usage(Path(local).drive + '\\').free >= 4 * 1024**3 and shutil.disk_usage('D:\\').free >= 1024**3)
        job = SupervisorJob(); ok('job_kill_on_close_nested', job.active() >= 1, job.active())
        prod_before = production_fingerprint(); q['production_fingerprint'] = prod_before
        foreign = foreign_roots(local); q['foreign_roots'] = foreign; rows_q = dict(_ROWS)
        q['foreign_roots_by_owner'] = {k: v.get('owner') for k, v in foreign.items()}
        ok('foreign_roots_recorded_read_only', True, len(foreign))
        stamp = time.strftime('%Y%m%d%H%M%S') + '_' + uuid.uuid4().hex[:6]; q['stamp'] = stamp
        home = Path(local) / EXTRACT_HOME
        home.mkdir(exist_ok=True); plain_directory(home)
        ext = home / (DELTA_PREFIX + 'QUAL_' + stamp) / 'EXTRACTED'
        ext.parent.mkdir()
        extract_package(package, ext); check_fixture_contract(ext)
        ok('package_manifest_and_frozen_sources', sha_file(ext / 'PACKAGE_MANIFEST.json') == MANIFEST_SHA
           and sha_file(ext / CAMPAIGN_REL) == CAMPAIGN_SHA and sha_file(ext / COMPLETENESS_REL) == COMPLETENESS_SHA)
        plan = plan_keys(ext); q['plan'] = plan
        ok('plan_38_from_frozen_constants', len(plan) == PLANNED_UNITS and len(set(plan)) == PLANNED_UNITS, len(plan))
        import PRE_G06_CAMPAIGN as campaign
        code_sha, _ = campaign.verify_package(package)
        ok('frozen_verify_package_fixed_layout', code_sha == CODE_SHA, str(ext))
        q['job_census_probe'] = job.nested_census_probe(frozen_native())
        ok('job_census_sees_nested_child', q['job_census_probe']['seen_self'] and q['job_census_probe']['seen_nested_child'],
           q['job_census_probe'])
        roots = {'run_parent': (Path(local) / RUN_PARENT, True), 'd_labs': (Path(D_LABS), True), 'extract_home': (home, True),
                 'stage': (stage, True), 'log_dir': (log_dir, True), 'frozen_log_root': (Path(FROZEN_LOG_ROOT), False)}
        if a.resume_root:
            pre = resume_precheck(a.resume_root, local, plan); q['resume'] = pre
            ok('resume_precheck_same_v004_campaign', True, {'committed': len(pre['committed_before']),
               'pending': len(pre['pending']), 'prior_status': pre['prior_status'],
               'reconcile': (pre['reconcile'] or {}).get('key')})
            q['prior_processes'] = prior_processes_dead(Path(pre['run_root']), frozen_dead())
            ok('prior_processes_dead', True, len(q['prior_processes']))
            q['campaign_lock'] = lock_probe(Path(pre['run_root']) / 'CAMPAIGN.lock')
            ok('campaign_lock_free', q['campaign_lock'] == 'ACQUIRED_AND_RELEASED', q['campaign_lock'])
            roots.update(resume_root=(Path(pre['run_root']), True), resume_d_lab=(Path(pre['d_lab']), True))
        q['write_roots'] = path_isolation(roots)
        ok('write_roots_isolated', all(r['status'] != 'FAIL' for r in q['write_roots'].values()),
           [k for k, r in q['write_roots'].items() if r['status'] == 'FAIL'])
        qtemp = ext.parent / 'QTEMP'; qtemp.mkdir()
        q['b2d_native_positive'] = native_b2d(ext, qtemp, log_dir / 'B2D_NATIVE_FIXED_LAYOUT.log')
        p = q['b2d_native_positive']
        ok('b2d_native_fixed_layout_29_ok', p['exit'] == 0 and p['ran'] == 29 and p['ok'] and p['contract_not_met'] == 0, p)
        neg = home / ('QUAL_NEG_' + stamp) / 'R08_Q1_00000000000000_000000000000' / 'PACKAGED'
        neg.parent.mkdir(parents=True); extract_package(package, neg)
        ntemp = neg.parent / 'QTEMP'; ntemp.mkdir()
        q['b2d_native_negative_r1_layout'] = native_b2d(neg, ntemp, log_dir / 'B2D_NATIVE_R1_LAYOUT.log')
        n = q['b2d_native_negative_r1_layout']
        ok('b2d_native_r1_layout_reproduces_failure', n['exit'] != 0 and n['ran'] == 29 and n['contract_not_met'] >= 29, n)
        after = foreign_roots(local)
        if after != foreign:
            q['foreign_roots_after'] = after
            q['foreign_roots_difference'] = foreign_detail(local, foreign, after, rows_q, dict(_ROWS))
        ok('q_no_effect_on_foreign_roots', after == foreign,
           '' if after == foreign else {k: sorted(v) for k, v in q['foreign_roots_difference'].items()})
        ok('production_unchanged_during_q', production_fingerprint() == prod_before)
        q['d4_successor_artifact'] = d4_successor_artifact_probe()
        emit('D4_SUCCESSOR_ARTIFACT=' + json.dumps(q['d4_successor_artifact'], sort_keys=True) + ' (somente leitura; informativo)')
        q['status'] = 'PASS_WINDOWS_QUALIFICATION'; code = 0
        emit('WINDOWS_QUALIFICATION=PASS CHECKS=' + str(len(q['checks'])) + ' FOREIGN_ROOTS=' + str(len(foreign)))
    except BaseException as exc:
        q['blockers'].append(type(exc).__name__ + ':' + str(exc)); q['traceback'] = traceback.format_exc()
        emit('WINDOWS_QUALIFICATION_BLOCKED=' + q['blockers'][-1])
    finally:
        q['finished_epoch'] = time.time(); q['seconds'] = round(time.time() - started, 3)
        (log_dir / 'QUALIFICATION_RESULT.json').write_bytes(
            (json.dumps(q, sort_keys=True, indent=1, ensure_ascii=True) + '\n').encode('ascii'))
        emit('QUALIFICATION_RESULT=' + str(log_dir / 'QUALIFICATION_RESULT.json') + ' SHA256=' +
             sha_file(log_dir / 'QUALIFICATION_RESULT.json') + ' EXIT_CODE=' + str(code))
        if _console is not None:
            _console.close(); _console = None
    return code


def require_qualification(path, log_dir, resume_root=''):
    """E is admitted only after a PASS native qualification of these exact bytes, this log dir, this mode and root."""
    q = strict_json(Path(path).read_bytes())
    require(q.get('schema') == QUAL_SCHEMA and q.get('status') == 'PASS_WINDOWS_QUALIFICATION', 'QUALIFICATION_NOT_PASS')
    require(q.get('supervisor_sha256') == sha_file(__file__), 'QUALIFICATION_OTHER_SUPERVISOR')
    require(q.get('log_dir') == str(log_dir) and q.get('mode') == (MODE_RESUME if resume_root else MODE_NEW)
            and q.get('resume_root', '') == resume_root, 'QUALIFICATION_OTHER_RUN')
    require(0 <= time.time() - float(q.get('finished_epoch', 0)) <= QUAL_MAX_AGE_S, 'QUALIFICATION_STALE')
    return {'qualification_sha256': sha_file(path), 'checks': len(q['checks']), 'production_fingerprint': q['production_fingerprint'],
            'foreign_roots': q['foreign_roots'], 'resume': q.get('resume')}


def main(argv=None):
    global _console
    ap = argparse.ArgumentParser(allow_abbrev=False)
    for name in ('package', 'review', 'log-dir', 'stage'):
        ap.add_argument('--' + name, required=True)
    ap.add_argument('--qualify-only', action='store_true')
    ap.add_argument('--require-qualification', default='')
    ap.add_argument('--resume-root', default='')
    a = ap.parse_args(argv)
    if a.qualify_only:
        return qualify_main(a)
    log_dir = Path(os.path.abspath(a.log_dir)); stage = Path(os.path.abspath(a.stage))
    resume_root = os.path.abspath(a.resume_root) if a.resume_root else ''
    result = {'schema': RESULT_SCHEMA, 'status': 'BLOCKED', 'exit_code': 2, 'phase': 'PREFLIGHT',
              'candidate_sha256': PACKAGE_SHA, 'code_manifest_sha256': CODE_SHA,
              'supervisor_sha256': sha_file(__file__), 'planned_units': PLANNED_UNITS,
              'mode': MODE_RESUME if resume_root else MODE_NEW, 'other_campaign_commits_reused': 0,
              'v003_evidence': 'PRESERVED_NOT_REUSED_NOT_RELABELED', 'v003_commits_reused': 0, 'production_modified': False,
              'b06': 'NOT_STARTED', 'b07': 'NOT_STARTED', 'd4_d5': 'NOT_STARTED', 'canary': 'NOT_STARTED',
              'full': 'NOT_STARTED', 'physical_powerloss': 'NOT_TESTED_PHYSICAL_POWERLOSS',
              'g5_decision': 'NEW_NATIVE_G5_REQUIRED_FOR_V005_FULL_INTEGRATION_20261022', 'blockers': []}
    stamp = time.strftime('%Y%m%d%H%M%S') + '_' + uuid.uuid4().hex[:6]
    root = None; lock = None; job = None; started = time.monotonic(); local = ''
    try:
        _console = open(stage / 'SUPERVISOR_CONSOLE.log', 'xb')
        emit('SUPERVISOR=' + str(Path(__file__)) + ' SHA256=' + result['supervisor_sha256'])
        # ---------------------------------------------------------------- preflight (no lab effects)
        require(bool(a.require_qualification), 'NEW_RUN_REQUIRES_WINDOWS_QUALIFICATION')
        require(os.name == 'nt', 'WINDOWS_REQUIRED')
        require(sys.version_info[:2] == (3, 14), 'PYTHON_3_14_REQUIRED:' + sys.version.split()[0])
        import ctypes
        require(bool(ctypes.WinDLL('shell32').IsUserAnAdmin()), 'ELEVATION_REQUIRED')
        package = Path(os.path.abspath(a.package))
        require(package.is_file() and sha_file(package) == PACKAGE_SHA, 'PACKAGE_SHA_MISMATCH')
        review_raw = Path(a.review).read_bytes(); validate_review(review_raw)
        result['source_review_sha256'] = sha_bytes(review_raw)
        local = os.environ.get('LOCALAPPDATA', '')
        require(local and '%' not in local and '~' not in local and Path(local).is_absolute(), 'LOCALAPPDATA_INVALID')
        require(os.path.normcase(os.path.realpath(local)) == os.path.normcase(os.path.abspath(local)),
                'LOCALAPPDATA_NOT_CANONICAL')
        run_parent = Path(local) / RUN_PARENT; d_labs = Path(D_LABS)
        require(Path('D:\\').is_dir(), 'D_VOLUME_REQUIRED')
        require(Path(local).drive.upper() != 'D:', 'RUN_ROOT_MUST_NOT_BE_ON_D')
        require(volume_filesystem(Path(local).drive + '\\') == 'NTFS', 'C_NTFS_REQUIRED')
        require(volume_filesystem('D:\\') == 'NTFS', 'D_NTFS_REQUIRED')
        require(shutil.disk_usage(Path(local).drive + '\\').free >= 4 * 1024**3, 'C_FREE_SPACE_4GIB')
        require(shutil.disk_usage('D:\\').free >= 1 * 1024**3, 'D_FREE_SPACE_1GIB')
        for p in (run_parent, d_labs):
            plain_directory(p)
        require(not Path(os.path.normcase(D_LABS)).is_relative_to(os.path.normcase(PRODUCTION)), 'PRODUCTION_ROOT')
        result['qualification'] = require_qualification(a.require_qualification, log_dir, resume_root)
        foreign_before = foreign_roots(local); rows_e = dict(_ROWS)
        if foreign_before != result['qualification']['foreign_roots']:
            result['foreign_roots_difference'] = foreign_detail(local, result['qualification']['foreign_roots'],
                                                                foreign_before, {}, rows_e)
        require(foreign_before == result['qualification']['foreign_roots'], 'FOREIGN_ROOTS_CHANGED_SINCE_QUALIFICATION')
        result['foreign_roots_before'] = len(foreign_before)
        job = SupervisorJob()
        emit('PREFLIGHT=PASS PYTHON=' + sys.version.split()[0] + ' ELEVATED=YES C_D_NTFS=YES JOB=KILL_ON_CLOSE QUALIFICATION=PASS'
             ' PRE_EXISTING_ROOTS=' + str(len(foreign_before)) + ' (somente leitura; nenhuma retomada)')
        # ---------------------------------------------------------------- owned NEW run root (lab effects only)
        result['phase'] = 'BOOTSTRAP'
        packaged = fixture_extract_dir(local, stamp)
        (packaged.parent.parent).mkdir(exist_ok=True); plain_directory(packaged.parent.parent)
        packaged.parent.mkdir()
        files = extract_package(package, packaged)
        check_fixture_contract(packaged)
        manifest_sha = sha_file(packaged / 'PACKAGE_MANIFEST.json')
        require(manifest_sha == MANIFEST_SHA, 'PACKAGE_MANIFEST_SHA')
        require(sha_file(packaged / CAMPAIGN_REL) == CAMPAIGN_SHA, 'CAMPAIGN_SOURCE_SHA')
        require(sha_file(packaged / COMPLETENESS_REL) == COMPLETENESS_SHA, 'COMPLETENESS_SOURCE_SHA')
        plan = plan_keys(packaged)
        result['extracted'] = str(packaged)
        emit('EXTRACTED=' + str(packaged) + ' FILES=' + str(files) + ' BYTE_EXACT=YES FIXTURE_LAYOUT=CURRENT_G5_DELTA_EXTRACTED')
        import msvcrt
        if resume_root:
            pre = resume_precheck(resume_root, local, plan)
            qres = result['qualification']['resume'] or {}
            require(pre['committed_before'] == qres.get('committed_before')
                    and pre['commit_file_sha256'] == qres.get('commit_file_sha256')
                    and pre['reconcile'] == qres.get('reconcile'), 'RESUME_STATE_CHANGED_SINCE_QUALIFICATION')
            result['resume'] = pre
            run_id = pre['run_id']; root = Path(pre['run_root']); dlab = Path(pre['d_lab'])
            result.update(run_id=run_id, run_root=str(root))
            emit('RESUME_ROOT=' + str(root) + ' PRIOR_STATUS=' + str(pre['prior_status']) + ' (mesma campanha V005, mesmos bytes)')
            emit('COMMITTED_BEFORE=' + str(len(pre['committed_before'])) + ' ' + ','.join(pre['committed_before']))
            emit('PENDING=' + str(len(pre['pending'])))
            lock = open(root / 'CAMPAIGN.lock', 'r+b')
            try:
                msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                raise Blocked('CAMPAIGN_LOCK_HELD_BY_ANOTHER_PROCESS')
            result['prior_processes'] = prior_processes_dead(root, frozen_dead())
            if pre['reconcile']:
                result['reconciled'] = ledger_reconcile(root, pre['reconcile'], stamp, result['supervisor_sha256'])
                emit('RECONCILIADO=' + pre['reconcile']['key'] + ' (COMMIT duravel sem registro da tentativa '
                     + pre['reconcile']['attempt'] + '; dono provado pelo censo do Job deste supervisor; nao sera reexecutado)')
            inputs_pkg = root / 'INPUTS' / PACKAGE_NAME
            witness = root / 'INPUTS' / WITNESS_NAME
            qual_c = root / 'QUAL_C'; qual_d = dlab / 'WRITER_EFFECTFUL'
            result['prior_terminal'] = preserve_prior_terminal(root, stage, stamp)
            resume = {'schema': 'CDT21_G5_V005_SUPERVISOR_RESUME_V001', 'run_id': run_id, 'stamp': stamp, 'mode': MODE_RESUME,
                      'package_sha256': PACKAGE_SHA, 'code_manifest_sha256': CODE_SHA,
                      'supervisor_sha256': result['supervisor_sha256'],
                      'qualification_sha256': result['qualification']['qualification_sha256'], 'extracted': str(packaged),
                      'prior_status': pre['prior_status'], 'committed_before': pre['committed_before'],
                      'commit_file_sha256': pre['commit_file_sha256'], 'ledger_attempts': pre['ledger_attempts'],
                      'pending': pre['pending'], 'prior_terminal': result['prior_terminal'], 'reconciled': pre['reconcile'],
                      'python_sha256': sha_file(sys.executable), 'supervisor_pid': os.getpid(),
                      'campaign_lock': 'HELD_EXCLUSIVE_BYTE_RANGE', 'v003_commits_reused': 0,
                      'other_campaign_commits_reused': 0, 'production_authorized': False, 'b06': 'NOT_STARTED'}
            write_new(root / ('CDT21_SUPERVISOR_RESUME_' + stamp + '.json'), encoded(resume))
        else:
            run_id = 'R08_Q1_' + time.strftime('%Y%m%d%H%M%S') + '_' + uuid.uuid4().hex[:12]
            require(RUN_NAME.fullmatch(run_id) is not None, 'RUN_NAME')
            require('run/' + run_id not in foreign_before and 'd_lab/' + run_id not in foreign_before, 'RUN_ID_COLLISION')
            run_parent.mkdir(exist_ok=True); plain_directory(run_parent)
            root = run_parent / run_id; root.mkdir()  # never exist_ok: no root is ever reused
            result.update(run_id=run_id, run_root=str(root))
            emit('RUN_ROOT=' + str(root) + ' (nova; nenhum COMMIT de outra execucao e reutilizado)')
            (root / 'TEMP').mkdir()
            (root / LEDGER_DIR).mkdir()
            (root / JOURNAL_DIR).mkdir()
            (root / 'INPUTS').mkdir()
            inputs_pkg = root / 'INPUTS' / PACKAGE_NAME
            shutil.copyfile(package, inputs_pkg)
            require(sha_file(inputs_pkg) == PACKAGE_SHA, 'INPUT_PACKAGE_COPY')
            witness = root / 'INPUTS' / WITNESS_NAME
            write_new(witness, encoded(make_witness(run_id, manifest_sha)))
            owner_raw = encoded(make_owner(run_id))
            write_new(root / 'OWNER.json', owner_raw)
            d_labs.mkdir(exist_ok=True); plain_directory(d_labs)
            dlab = d_labs / run_id; dlab.mkdir()
            write_new(dlab / 'OWNER.json', owner_raw)
            qual_c = root / 'QUAL_C'; qual_d = dlab / 'WRITER_EFFECTFUL'
            qual_c.mkdir(); qual_d.mkdir()
            lock = open(root / 'CAMPAIGN.lock', 'x+b')
            lock.write(encoded({'schema': 'CDT21_G5_V005_CAMPAIGN_LOCK_V001', 'run_id': run_id, 'supervisor_pid': os.getpid()}))
            lock.flush(); os.fsync(lock.fileno()); lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            require(not (root / 'COMMITS').exists(), 'NEW_ROOT_HAS_COMMITS')
            bootstrap = {'schema': 'CDT21_G5_V005_SUPERVISOR_BOOTSTRAP_V001', 'run_id': run_id,
                         'package_sha256': PACKAGE_SHA, 'code_manifest_sha256': CODE_SHA,
                         'package_manifest_sha256': manifest_sha, 'campaign_source_sha256': CAMPAIGN_SHA,
                         'completeness_source_sha256': COMPLETENESS_SHA,
                         'supervisor_sha256': result['supervisor_sha256'],
                         'source_review_sha256': result['source_review_sha256'],
                         'qualification_sha256': result['qualification']['qualification_sha256'],
                         'python': sys.version, 'python_executable': sys.executable,
                         'python_sha256': sha_file(sys.executable), 'localappdata': local,
                         'd_parent': str(dlab), 'temp': str(root / 'TEMP'), 'extracted': str(packaged),
                         'qual_c_parent': str(qual_c), 'qual_d_parent': str(qual_d),
                         'campaign_lock': 'HELD_EXCLUSIVE_BYTE_RANGE', 'supervisor_pid': os.getpid(),
                         'mode': 'NEW_RUN_V005', 'v003_commits_reused': 0, 'pre_existing_roots_read_only': len(foreign_before),
                         'commit_ledger': LEDGER_DIR, 'attempt_journal': JOURNAL_DIR,
                         'production_authorized': False, 'b06': 'NOT_STARTED'}
            write_new(root / 'CDT21_SUPERVISOR_BOOTSTRAP.json', encoded(bootstrap))
        result['production_fingerprint_before'] = production_fingerprint()
        require(result['production_fingerprint_before'] == result['qualification']['production_fingerprint'],
                'PRODUCTION_CHANGED_SINCE_QUALIFICATION')
        emit('D_LAB=' + str(dlab) + ' OWNER_IDENTICAL=YES WITNESS=' + str(witness))
        emit('SAFE_STOP=' + str(root / 'SAFE_STOP.request') + ' (crie este arquivo para parada segura)')
        # ---------------------------------------------------------------- frozen campaign (child)
        result['phase'] = 'CAMPAIGN'
        env = {k: v for k, v in os.environ.items() if not k.upper().startswith('PYTHON')}
        env.update(TEMP=str(root / 'TEMP'), TMP=str(root / 'TEMP'),
                   TICKSTORE_QUAL_C_PARENT=str(qual_c), TICKSTORE_QUAL_D_PARENT=str(qual_d))
        cmd = [sys.executable, '-I', '-B', str(packaged / CAMPAIGN_REL), '--run-root', str(root),
               '--package', str(inputs_pkg), '--witness', str(witness), '--d-parent', str(dlab)]
        import subprocess
        emit('NATIVE_BEGIN=PRE_G06_CAMPAIGN UNITS=' + str(PLANNED_UNITS) +
             ' ETA_BASE_S=~700-1500 (referencia nativa V003: 653 s para 33 unidades + 5 reutilizadas; nao e evidencia)')
        result['attempt'] = journal_attempt(root, stamp, result['supervisor_sha256'], frozen_native()(os.getpid()), plan)
        proc = subprocess.Popen(cmd, cwd=str(root), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        reused, committed_now, ledger_errors = [], [], []
        census_done, census_errors = [], []
        def pump():
            for raw in iter(proc.stdout.readline, b''):
                line = raw.decode('utf-8', 'replace').rstrip('\r\n')
                if line.startswith('REUSE_COMMITTED '):
                    reused.append(line.split(' ', 1)[1])
                elif line.startswith('COMMITTED '):
                    committed_now.append(line.split(' ', 1)[1])
                    try:
                        ledger_record(root, committed_now[-1], stamp, result['supervisor_sha256'], proc.pid)
                    except BaseException as exc:
                        ledger_errors.append(committed_now[-1] + ':' + type(exc).__name__ + ':' + str(exc))
                elif line.startswith('HEARTBEAT ACTIVE_TEST='):
                    key = line.split(' ', 2)[1].split('=', 1)[1]
                    if key in plan and key not in census_done:
                        try:
                            if journal_census(root, stamp, key, job.census(), proc.pid, result['supervisor_sha256'], line):
                                census_done.append(key)
                        except BaseException as exc:
                            census_errors.append(key + ':' + type(exc).__name__ + ':' + str(exc))
                emit(line)
        reader = threading.Thread(target=pump, daemon=True); reader.start()
        last = 0.0
        while proc.poll() is None:
            try:
                now = time.monotonic()
                if now >= last:
                    commits = len(list((root / 'COMMITS').glob('*.json'))) if (root / 'COMMITS').is_dir() else 0
                    emit('SUPERVISOR_HEARTBEAT OWNED_PROCESSES=' + str(job.active() - 1) +
                         ' COMMITTED_UNIT_RECEIPTS=' + str(commits) + '/' + str(PLANNED_UNITS) +
                         ' ELAPSED_S=' + str(int(now - started)) +
                         ' AS_OF=' + time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
                    last = now + 10
                time.sleep(0.5)
            except KeyboardInterrupt:
                emit('CTRL_C: aguardando o encerramento e o selo da campanha (sem matar o filho)')
        reader.join(60)
        result['unit_census_recorded'] = list(census_done)
        result['unit_census_errors'] = list(census_errors)
        code = proc.returncode
        result['campaign_exit_code'] = code
        result['reused_committed_units'] = sorted(reused)
        result['newly_committed_units'] = committed_now
        emit('NATIVE_END=PRE_G06_CAMPAIGN EXIT_CODE=' + str(code))
        result['production_fingerprint_after'] = production_fingerprint()
        require(result['production_fingerprint_after'] == result['production_fingerprint_before'], 'PRODUCTION_FINGERPRINT_CHANGED')
        result['foreign_roots'] = foreign_checked(local, foreign_before, rows_e, run_id, result, 'foreign_roots',
                                                  bool(resume_root))
        require(not ledger_errors, 'LEDGER_WRITE:' + ';'.join(ledger_errors))
        if resume_root:
            before_set = set(result['resume']['committed_before'])
            require(set(reused) <= before_set, 'RESUME_REUSED_OUTSIDE_ADMISSION:' + ','.join(sorted(set(reused) - before_set)))
            require(not set(committed_now) & before_set, 'RESUME_RECOMMITTED:' + ','.join(sorted(set(committed_now) & before_set)))
        else:
            require(not reused, 'NEW_RUN_REUSED_A_COMMIT:' + ','.join(sorted(reused)))
        native = root / 'R08_RETURN.zip'
        require(native.is_file(), 'R08_RETURN_NOT_SEALED')
        # R4: any other exit is an abrupt death; the terminal on disk is then not this attempt's (resume).
        require(code in (0, 3, 130), 'CAMPAIGN_ABRUPT_EXIT_NO_TERMINAL_OF_THIS_ATTEMPT:' + str(code))
        native_sha = sha_file(native)
        recorded = (root / 'R08_RETURN.sha256').read_text(encoding='ascii').split()[0]
        require(recorded == native_sha, 'R08_RETURN_SHA_FILE_MISMATCH')
        result['native_return_sha256'] = native_sha
        engineering = strict_json((root / 'ENGINEERING_RESULT.json').read_bytes())
        result['campaign_status'] = engineering.get('status')
        if code == 130 or engineering.get('status') == 'SAFE_STOP':
            result.update(status='SAFE_STOP', exit_code=130)
            raise Blocked('CAMPAIGN_SAFE_STOP')
        require(code == 0 and engineering.get('status') == 'PASS_NATIVE_INTEGRATED_PRE_B06'
                and engineering.get('final_zip_sha256') == PACKAGE_SHA
                and engineering.get('code_manifest_sha256') == CODE_SHA, 'CAMPAIGN_NOT_PASS:' +
                str(engineering.get('status')) + ':' + repr(engineering.get('blockers')))
        if resume_root:
            require(sorted(committed_now + reused) == sorted(plan)
                    and sorted(reused) == sorted(result['resume']['committed_before']),
                    'RESUMED_UNITS_NE_PLAN:' + str(len(committed_now)) + '+' + str(len(reused)))
        else:
            require(sorted(committed_now) == sorted(plan), 'COMMITTED_NOW_NE_PLAN:' + str(len(committed_now)))
        result['commit_file_sha256'] = commits_bound(root, plan)
        result['ledger_attempts'] = ledger_bound(root, result['commit_file_sha256'])
        result['checkpoints'] = final_checkpoints(root, plan)
        # ---------------------------------------------------------------- frozen five-part closure
        result['phase'] = 'FIVE_PART_CLOSE'
        verify_extract(package, packaged)
        review = root / 'SOURCE_REVIEW' / REVIEW_NAME
        if review.exists():
            require(bool(resume_root) and review.read_bytes() == review_raw, 'SOURCE_REVIEW_DRIFT')
        else:
            review.parent.mkdir(exist_ok=bool(resume_root))
            write_new(review, review_raw)
        os.environ.update(TEMP=str(root / 'TEMP'), TMP=str(root / 'TEMP'))
        for folder in ('full', 'control', 'adapter', 'g5proof'):  # same import roots as PRE_G06_CAMPAIGN
            p = str(packaged / 'implementation_v001/candidate' / folder)
            if p not in sys.path:
                sys.path.insert(0, p)
        import PRE_G06_COMPLETENESS as completeness
        require(Path(completeness.__file__).resolve() == (packaged / COMPLETENESS_REL).resolve(), 'COMPLETENESS_IMPORT_PATH')
        closed = completeness.close(str(inputs_pkg), str(native), str(review), str(root))
        require(closed.get('engineering_five_part_completeness') == 'PASS'
                and closed.get('four_pre_b06_findings') == 'PASS_NATIVE_REGRESSION'
                and closed.get('independent_b06_audit') is False, 'FIVE_PART_NOT_PASS')
        comp_path = root / 'FINAL_G5' / 'ENGINEERING_COMPLETENESS.json'
        comp = strict_json(comp_path.read_bytes())
        require(comp.get('code_manifest_sha256') == CODE_SHA and comp.get('final_package_sha256') == PACKAGE_SHA,
                'COMPLETENESS_BINDING')
        result['five_part'] = {k: {'status': v.get('status'), 'sha256': v.get('sha256')}
                               for k, v in sorted(comp['five_part_completeness'].items())}
        result['engineering_completeness_sha256'] = sha_file(comp_path)
        result['final_engineering_status_sha256'] = sha_file(root / 'FINAL_G5' / 'FINAL_ENGINEERING_STATUS.json')
        result['four_pre_b06_findings_sha256'] = sha_file(root / 'FINAL_G5' / 'FOUR_PRE_B06_FINDINGS.json')
        result['final_engineering_status'] = closed.get('status')
        result['foreign_roots_after_close'] = foreign_checked(local, foreign_before, rows_e, run_id, result,
                                                              'foreign_roots_after_close', bool(resume_root))
        result['production_fingerprint_after_close'] = production_fingerprint()
        require(result['production_fingerprint_after_close'] == result['production_fingerprint_before'],
                'PRODUCTION_FINGERPRINT_CHANGED_AT_CLOSE')
        result.update(status='PASS_NATIVE_V005_G5_TECHNICAL_FIVE_PART', exit_code=0, phase='DONE')
        emit('ENGINEERING_FIVE_PART_COMPLETENESS=PASS FOUR_PRE_B06_FINDINGS=PASS_NATIVE_REGRESSION B06=NOT_STARTED')
    except BaseException as exc:
        if result['status'] != 'SAFE_STOP':
            result['exit_code'] = {'PREFLIGHT': 2, 'BOOTSTRAP': 2, 'CAMPAIGN': 3, 'FIVE_PART_CLOSE': 4}.get(result['phase'], 2)
        result['blockers'].append(type(exc).__name__ + ':' + str(exc))
        result['traceback'] = traceback.format_exc()
        if root is not None:
            result['partial_effect_scope'] = 'RUN_OWNED_LAB_ONLY'
        emit('SUPERVISOR_BLOCKED=' + result['blockers'][-1])
        if root is not None and result['phase'] in ('CAMPAIGN', 'FIVE_PART_CLOSE'):
            emit('RETOMADA_DA_MESMA_CAMPANHA: -RetomarRaiz "' + str(root) + '" (a Fase Q decide a admissao)')
        emit('PRIMARY_TRACEBACK_BEGIN\n' + result['traceback'] + 'PRIMARY_TRACEBACK_END')
    finally:
        if job is not None:
            result['owned_processes_at_end'] = job.active() - 1
            if result['owned_processes_at_end'] != 0 and result['exit_code'] == 0:
                result.update(status='BLOCKED', exit_code=3)
                result['blockers'].append('SUPERVISOR_OWNED_ORPHANS:' + str(result['owned_processes_at_end']))
        if lock is not None:
            lock.close()  # releases the byte-range lock after the child exited
        result['seconds'] = round(time.monotonic() - started, 3)
        if root is not None:
            try:
                ret = log_dir / 'CDT21_G5_V005_RETURN.zip'
                excluded = build_return(root, stage, ret, PACKAGE_SHA, result.get('native_return_sha256'))
                result['return_zip'] = str(ret); result['return_sha256'] = sha_file(ret)
                result['return_excluded_duplicates'] = excluded
                if result['exit_code'] == 0:
                    require(all(e['equal'] for e in excluded) and len(excluded) == 2, 'RETURN_DUPLICATE_IDENTITY')
                emit('RETURN=' + str(ret) + ' SHA256=' + result['return_sha256'])
            except BaseException as exc:
                result['blockers'].append('RETURN_PACKAGING:' + type(exc).__name__ + ':' + str(exc))
                if result['exit_code'] == 0:
                    result.update(status='BLOCKED', exit_code=5)
                emit('RETURN_PACKAGING_FAILED=' + str(exc))
        try:
            (log_dir / 'SUPERVISOR_RESULT.json').write_bytes(
                (json.dumps(result, sort_keys=True, indent=1, ensure_ascii=True) + '\n').encode('ascii'))
            emit('SUPERVISOR_RESULT=' + str(log_dir / 'SUPERVISOR_RESULT.json') +
                 ' SHA256=' + sha_file(log_dir / 'SUPERVISOR_RESULT.json'))
        except BaseException as exc:
            emit('SUPERVISOR_RESULT_WRITE_FAILED=' + str(exc))
        emit('SUPERVISOR_STATUS=' + result['status'] + ' EXIT_CODE=' + str(result['exit_code']))
        if _console is not None:
            _console.close(); _console = None
    return result['exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
