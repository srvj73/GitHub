# A1 — R3-F01 fechado (supervisor R4) e supervisor/launcher G5 do V005

**Executores fora do candidato congelado, nesta pasta:**

| Arquivo | SHA-256 |
|---|---|
| `CDT21_G5_V005_SUPERVISOR.py` | `363D1654681D690C247903F440568238E678FC04B22F6F0DB62462B85458700A` |
| `RUN_CDT21_G5_V005_20261022.ps1` (launcher único; supervisor e revisão de fonte embutidos e fixados) | `2767A823550C7DF3D6C75F301215DB721E895C09545468E66E23E0145B8867FA` |
| `CDT19_IMPLEMENTER_SOURCE_REVIEW_V005.json` | `CA8E525287D0D1EC27F2F42DDC8DD4D1267E1DBAEE258464DF284F12C8F94D82` |

**Linhagem:** R1 → R2 → R3 → R4 (linha V004, `02DDB290…`) → **V005**. O supervisor V005 tem a lógica do R4 sem alteração e muda apenas o vínculo:
- o candidato vinculado passa a ser o V005;
- os bytes do V003 e do V004 passam a ser “outro candidato”: suas raízes são lidas somente como raízes alheias, e seus COMMITs são recusados;
- a Fase Q ganha uma sonda informativa, somente leitura e não bloqueante, do ZIP sucessor do D4 em `D:` (GAP-04).

A derivação é feita por substituições contadas (`build/make_v005_supervisor.py`) e o diff completo está em `build/R4_TO_V005_SUPERVISOR.diff`.

**Qualificação nos bytes exatos do V005** (`06_EVIDENCIAS/G5_V005_SUPERVISOR`):
- 53/53 casos: regressão R3 + grupos R4 + NR14, este último um COMMIT do pai V004 numa janela de reconciliação, recusado;
- 11/11 mutantes mortos.

## O que o R4 fechou (A1)

## A lacuna

Dois trechos do código determinam a lacuna:
- o código congelado `PRE_G06_CAMPAIGN.py:228-232` executa `R.publish(COMMIT)` (com fsync) **antes** de imprimir `COMMITTED <chave>`;
- o R3 só registra o COMMIT no livro-razão depois de ler essa linha.

Uma queda entre os dois pontos deixava um COMMIT durável sem registro, e o R3 recusava a raiz (`COMMIT_NOT_LEDGERED`).

## A prova (R4)

O R4 deriva do R3 (`2765FAAA…`) por substituições contadas (`make_v004_r4_supervisor.py`). As 9 linhas removidas são todas assinaturas estendidas ou textos substituídos.

**1. Diário de tentativas** (`CDT21_SUPERVISOR_JOURNAL/ATTEMPT_<stamp>.json`). É gravado, criado uma única vez via TEMP e movido atomicamente, **antes** de o filho de campanha existir. Contém: sequência, identidade do supervisor (pid e criação, pelo `R.native_process` congelado) e o livro-razão no início da tentativa.

**2. Censo por unidade** (`CENSUS_<stamp>_<chave>.json`).
- **Gatilho:** o próprio filho de campanha imprime `HEARTBEAT ACTIVE_TEST=<chave>`, o que o `run_unit` congelado faz logo depois de admitir o filho da unidade.
- **Fonte:** o supervisor lista os processos vivos do **seu** Job kill-on-close.
- **Por que isso prova a origem:** o filho da unidade herda esse Job (sem breakaway; o `ProcessJob` congelado o aninha), e o Job contém só a árvore deste supervisor. Logo, um processo listado pertence a esta tentativa.
- **Frequência:** um registro por unidade, gravado apenas quando um processo de unidade é visto.

**3. Admissão na retomada (Q e E).** Admite-se no máximo **um** COMMIT sem registro, e somente se:
- for a **próxima unidade do plano** (o livro-razão é exatamente um prefixo do plano);
- passar pelas checagens do R3 (fechado, vinculado ao candidato da campanha e a nenhum outro, artefatos íntegros dentro da raiz);
- tiver um **dono único** (pid, criação) igual ao `process` do seu `RESULT.json` (artefato re-hasheado);
- a **última** tentativa do diário for deste supervisor e não tiver a chave no livro-razão inicial;
- o **censo dessa tentativa para essa chave** listar o dono;
- o dono não for o supervisor nem o filho de campanha.

Qualquer falha recusa com `COMMIT_NOT_LEDGERED:<chave>:RECONCILE_<motivo>`.

**4. Gravação (fase E).** Sob o lock da campanha e antes de ela começar, a fase E grava o registro com `basis=RECONCILED_BY_SUPERVISOR_JOB_CENSUS` e a prova. A Q e a E precisam calcular a mesma prova. O `run_unit` congelado reutiliza o COMMIT (`REUSE_COMMITTED`). **Não há replay.**

**5. Q nativa.** `job_census_sees_nested_child` prova, no Windows e antes de qualquer efeito, que o censo enxerga um filho movido para um Job aninhado, com a identidade dada pelo `R.native_process` congelado.

**Separação preservada.** Um COMMIT de outra raiz, de outra campanha, do V003, do V004 (no supervisor V005) ou de outro candidato tem outro dono, ou outro vínculo, e é recusado.

**Resíduo declarado (falha fechada).** A reconciliação é recusada, sem replay e sem aceitação, quando o censo não chegou a ser gravado. Isso exige uma de três situações:
- a leitura do pipe ficou atrasada durante toda a vida do filho da unidade;
- o censo falhou, e a falha fica registrada em `unit_census_errors`;
- uma perda física de energia reordenou a durabilidade, caso `NOT_TESTED_PHYSICAL_POWERLOSS`, igual à declaração do código congelado.

## Defeito adicional encontrado e corrigido pela qualificação (preexistente no R3)

Quando uma tentativa **retomada** morria abruptamente, o R3 classificava o resultado pelo terminal da tentativa anterior, que continua na raiz. Uma queda podia, assim, aparecer como `SAFE_STOP` (130).

O `main` congelado só termina com 0, 3 ou 130, sempre depois de `write_terminal` e `seal_return`. O R4 exige isso e, em qualquer outro caso, retorna `BLOCKED` com `CAMPAIGN_ABRUPT_EXIT_NO_TERMINAL_OF_THIS_ATTEMPT:<código>`. O cenário W4 e o mutante MR10 cobrem essa correção.

## Launcher G5 V005

`RUN_CDT21_G5_V005_20261022.ps1` deriva do launcher R4 (`F83DD8E6…`) por `build/build_v005_launcher.py`. As linhas alteradas fora de comentários são somente rótulos e pins:
- pacote V005 e o SHA-256 dele;
- supervisor e revisão de fonte V005, com os pins;
- família de log `CDT21_G5_V005_RUNS\G5V5_<stamp>`;
- nomes de retorno `ENVIAR_AO_OPUS_CDT21_G5_V005_<stamp>.zip`.

Parâmetros, validação de `-RetomarRaiz`, classificação R1, transporte por UAC, invocação Q/E e roteamento do retorno ao Opus são idênticos ao R4. `build/V005_LAUNCHER_STATIC_CHECK.json` confirma: parser com 0 erros, ASCII, CRLF e fragmentos qualificados idênticos. O launcher R4 da linha V004 continua válido somente para os bytes do V004.
