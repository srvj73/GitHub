# CDT21 V005 — integração FULL (sucessor mínimo do V004)

**Origem:** missão consolidada da origem (2026-10-21/22). Revisão integrada dos caminhos completos de execução sobre os bytes do V004.

**Papel:** implementador, não B06. O V004 continua congelado e preservado como pai.

## Achados corrigidos no código (runtime)

| Achado | Defeito no V004 | Correção no V005 | Teste de regressão (suíte do plano G5) |
|---|---|---|---|
| GAP-01 | `FULL_STAGE_EVIDENCE.publish` exigia testemunhas de nó (`check_proofs`) para todo estágio; o D4 não as tem. O recibo D4 nunca era publicado (`STAGE_CHECK_PROOF_EXACT_SET`). | O produtor espelha o consumidor (`FULL_RELEASE_CHAIN.validate_chain`): testemunhas só de D5 a FULL_ADMISSION; no D4 nenhuma é aceita. | `test_cdt18_stage_proof_integrated_reconcile` test_06 e test_07 |
| GAP-02 | `FULL_RUNNER.d4_command` não passava `-G5StageReceiptPath`/`-G5InstancePath`, exigidos pelo wrapper selado (`FIRST_ADMISSION_REQUIRED_INPUT_MISSING`). | Ambos vêm da cadeia admitida e são obrigatórios. | `test_operator_entry_points` test_v005_01 a test_v005_03 |
| GAP-03 | **Regressão do delta V003 (F-01/F-04):** a entrada inline mudou (9DEE7D6C → 9BFFE835), mas o launcher adaptado manteve o pin antigo. Todo lançamento adaptado parava (`ADAPTER_INLINE_ENTRY_HASH_MISMATCH`). | Pin = entrada vinculada; o binding e o `FIRST_ADMISSION_BINDING` acompanham. | test_v005_04 |
| GAP-04 | O ZIP sucessor tinha duas identidades: migração `8A05E761…`, bootstrap `CAC345D3…`. | Identidade única, a da migração RC1R1. O arquivo físico é provado no P1 (somente leitura). | test_v005_05 |
| GAP-09 | O `SOURCE_MANIFEST` dos deltas V003/V004 omitia o `RUNTIME_CODE_MANIFEST.json`, e o verificador do próprio candidato falhava (`SOURCE_EXACT_SET`). | Manifesto de fontes fechado. | `VERIFY_FULL_COMPOSITION_SOURCE_ONLY.py` |

Os 7 testes novos **falham nos bytes do V004 e passam nos do V005**. Eles estão em suítes do plano G5 congelado e, por isso, rodam nativamente na campanha G5 do V005.

## Documentos de operação corrigidos

- `TEMPLATE_B06_VERDICT.txt` (GAP-11);
- `TEMPLATE_D4_POLICY_ADMISSION_RECEIPT.json` (GAP-06);
- `PROCEDIMENTO_OPERACIONAL_GATES.md`, seção V005 (GAP-04, GAP-05, GAP-07, GAP-08).

## Não alterado, com justificativa

- **GAP-13, elevação do `D4Close`:** é decisão de projeto explícita, fixada por teste (`test_full_runner_observability_r41` test_30). O efeito alegado não foi verificado; a avaliação é nativa, no D4.
- **Documentos de status da fase CDT17** (`FULL_COMPOSITION_EVIDENCE.json`, `CDT17_FINAL_ENGINEERING_INTEGRATION_STATUS.json`, `README_FIRST.txt`): ficam como histórico. O estado vigente está neste arquivo e em `CDT21_V005_ENGINEERING_COMPLETENESS.json`.
- **Logs congelados em `OneDrive\Downloads\TICKSTORE_RUNS`:** a pasta é absoluta e fixa, provada nativamente. Migrá-la exigiria alterar 3 executores congelados e o teste que a fixa, sem ganho funcional.
