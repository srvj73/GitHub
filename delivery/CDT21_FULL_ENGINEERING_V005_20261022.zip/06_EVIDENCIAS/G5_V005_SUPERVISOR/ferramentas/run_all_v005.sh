#!/bin/bash
# Final R4 qualification: ORIGINAL (R3 regression + R4 groups) and the 11 R4 mutants (R4 group), 4 processes at a time.
S=/tmp/claude-0/-home-user-GitHub/ece1d4c3-5fd3-5d37-a54a-2c0b4e5a2396/scratchpad; PY=/root/.local/share/uv/python/cpython-3.14.6-linux-x86_64-gnu/bin/python3.14; W=$S/v005/g5
cd $W/qual; rm -rf r4work mwork_* V005_MUTANT_*.json mut_*.log V005_SUPERVISOR_QUALIFICATION.json
ARGS="$W/build/CDT21_G5_V005_SUPERVISOR.py $S/v005/out/CDT21_FINAL_PACKAGE_V005_20261022.zip $W/CDT19_IMPLEMENTER_SOURCE_REVIEW_V005.json $S/coleta/rebuilt/FILES/ROOT_1 $W/stub_campaign_r4.py"
( timeout 3000 $PY -I -B $W/test_v005_supervisor.py $ARGS $W/qual/r4work $W/qual/V005_SUPERVISOR_QUALIFICATION.json > $W/qual/r4_run.log 2>&1 ) &
N=1
for M in M1R_NO_LEDGER_ADMISSION MR1_NO_OWNER_IN_CENSUS_CHECK MR2_ACCEPT_MORE_THAN_ONE_UNLEDGERED MR3_NO_NEXT_PLAN_SLOT_CHECK MR4_NO_RESULT_PROCESS_CHECK MR5_CENSUS_OF_ANY_ATTEMPT MR6_OWNER_MAY_BE_CAMPAIGN_OR_SUPERVISOR MR7_NO_CENSUS_IN_PUMP MR8_RECONCILIATION_NOT_WRITTEN MR9_NO_ATTEMPT_RECORD_CHECK MR10_STALE_TERMINAL_CLASSIFIES_ABRUPT_EXIT; do
  ( R4_GROUPS=R4 timeout 2400 $PY -I -B $W/test_v005_supervisor.py $ARGS $W/qual/mwork_$M $W/qual/V005_MUTANT_$M.json --mutant $M > $W/qual/mut_$M.log 2>&1 ) &
  sleep 2; N=$((N+1)); if [ $((N % 4)) -eq 0 ]; then wait; fi
done
wait
for M in $W/qual/V005_MUTANT_*.json; do python3 -c "
import json,sys;d=json.load(open(sys.argv[1]));print(d['mutant'], 'KILLED' if d['passed']<d['total'] else 'SURVIVED', d['passed'],'/',d['total'], [c['case'] for c in d['cases'] if not c['pass']])" $M; done > $W/qual/mutants_summary_v005.txt
tail -1 $W/qual/r4_run.log | cut -c1-400; cat $W/qual/mutants_summary_v005.txt; ls $W/qual/mut_*.log | wc -l; ls $W/qual/V005_MUTANT_*.json | wc -l
