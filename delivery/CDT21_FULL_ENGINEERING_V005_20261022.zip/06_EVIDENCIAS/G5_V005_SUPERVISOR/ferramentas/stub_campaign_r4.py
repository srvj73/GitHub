"""Contract-faithful stand-in for PRE_G06_CAMPAIGN.main on Linux (qualification of the supervisor R4 only).

The REAL frozen V004 module supplies: the plan constants, verify_package, the reuse path of run_unit (REUSE_COMMITTED,
COMMITTED_INPUT_DRIFT, artifact re-hash), heartbeat_line, physical(), write_terminal() and seal_return().
A NEW unit follows the order of the frozen run_unit: archive interrupted bytes; start the unit child (a real process,
a descendant of the supervisor, like the Job-nested Windows child) and take its identity (admit); print the frozen
HEARTBEAT line; wait for the child; RESULT.json with the child identity; R.publish(COMMIT) with owner=[identity];
then print 'COMMITTED <key>'.  The unit child lives until the supervisor's census has listed it (bounded 3 s): on
Windows the spawned unit child lives far longer than the supervisor's census, which this makes deterministic.
Controls (environment):
  STUB_STOP_AFTER=n          operator SAFE_STOP after n new commits
  STUB_KILL_AFTER=n          abrupt death inside the (n+1)-th new unit, before its COMMIT (no terminal, no seal)
  STUB_FAKE_REUSE=1          prints a REUSE_COMMITTED line in a run (negative control)
  STUB_CRASH_AFTER_PUBLISH=n crash in the R3-F01 window of the (n+1)-th new unit: COMMIT published, COMMITTED not printed
  STUB_CRASH_MODE=campaign   only the campaign dies (the supervisor survives)
                 =tree       the whole tree dies (supervisor killed first, as by power loss / kill-on-close)
"""
import argparse
import datetime
import os
import shutil
import signal
import subprocess
import sys
import uuid
from pathlib import Path

real = Path(os.environ['STUB_REAL_CAMPAIGN'])
cand = real.parents[1]
for f in ('full', 'control', 'adapter', 'g5proof'):
    sys.path.insert(0, str(cand / f))
import PRE_G06_CAMPAIGN as C          # noqa: E402  frozen V004 bytes
import FULL_CRASH_RECOVERY as R       # noqa: E402
import FULL_G5_COMPLETE_PROOF_GATE as gate  # noqa: E402

UNIT_CHILD = ('import glob, json, os, sys, time\n'
              'end = time.time() + 3\n'
              'while time.time() < end:\n'
              '    for f in glob.glob(os.path.join(sys.argv[1], "CENSUS_*_" + sys.argv[2] + ".json")):\n'
              '        try:\n'
              '            if any(p.get("pid") == os.getpid() for p in json.load(open(f))["processes"]): sys.exit(0)\n'
              '        except Exception: pass\n'
              '    time.sleep(0.01)\n')


def ident(pid):
    """Linux stand-in of R.native_process: (pid, start time since boot) through /proc."""
    stat = Path('/proc/%d/stat' % pid).read_text()
    fields = stat[stat.rindex(')') + 2:].split()
    return {'pid': pid, 'creation_filetime': int(fields[19]), 'state': 'LIVE'}


ap = argparse.ArgumentParser(allow_abbrev=False)
for name in ('run-root', 'package', 'witness', 'd-parent'):
    ap.add_argument('--' + name, required=True)
a = ap.parse_args()
root = Path(a.run_root)
result = {'schema': 'CDT19_PRE_B06_NATIVE_ENGINEERING_V002', 'status': 'BLOCKED', 'tests': {}, 'additional_tests': {},
          'production_modified': False, 'full_started': False, 'b06': 'NOT_STARTED', 'g5_final': 'NOT_ISSUED', 'blockers': []}
env_int = lambda k: int(os.environ.get(k, '0') or '0')
stop_after, kill_after = env_int('STUB_STOP_AFTER'), env_int('STUB_KILL_AFTER')
crash_after = int(os.environ['STUB_CRASH_AFTER_PUBLISH']) if os.environ.get('STUB_CRASH_AFTER_PUBLISH') else None
crash_mode = os.environ.get('STUB_CRASH_MODE', 'campaign')
code = 2; new_commits = 0
try:
    C.require(Path(os.environ['TEMP']) == root / 'TEMP', 'CANONICAL_TEMP_REQUIRED')
    code_sha, members = C.verify_package(Path(a.package)); pack = R.sha(Path(a.package).read_bytes())
    witness = R.read(a.witness)[0]
    C.require(witness['package_sha256'] == pack and witness['manifest_sha256'] == R.sha(members['PACKAGE_MANIFEST.json']), 'WITNESS_BINDING')
    owner = R.read(root / 'OWNER.json')[0]
    C.require(owner['package_sha256'] == pack and owner['run_id'] == root.name, 'RUN_OWNER')
    C.require(R.read(Path(a.d_parent) / 'OWNER.json')[0] == owner, 'D_LAB_OWNER')
    for name in ('LOGS', 'UNITS', 'COMMITS', 'EVIDENCE', 'WORK'):
        (root / name).mkdir(exist_ok=True)
    result.update(code_manifest_sha256=code_sha, final_zip_sha256=pack, run_id=root.name)
    plan = (['G5_' + n for n in ('PS51_INSTALL_MENU', 'STAGE_B_REAL_ISOLATED_PATH_NATIVE', 'D4_REAL_ISOLATED_PATH_NATIVE')] +
            ['SUITE_' + n for n in gate.SUITES if n not in C.STAGE_SUITES] + ['DELTA_' + n for n in C.EXTRA] +
            ['PRE_B06_11_CHAIN', 'G3_G6_NATIVE'])
    if os.environ.get('STUB_FAKE_REUSE') == '1':
        print('REUSE_COMMITTED ' + plan[0], flush=True)
    for key in plan:
        C.require(not (root / 'SAFE_STOP.request').exists(), 'SAFE_STOP_REQUESTED')
        commit = root / 'COMMITS' / (key + '.json')
        if commit.exists():
            C.run_unit(dict(root=str(root), key=key, package_sha256=pack, code_sha256=code_sha))  # frozen reuse path
        else:
            stale = [p for p in (root / 'UNITS' / key, root / 'WORK' / key, root / 'LOGS' / (key + '.log')) if p.exists()]
            if stale:  # same as run_unit: interrupted bytes retained, never overwritten
                archive = root / 'INTERRUPTED_ATTEMPTS' / (key + '_' + uuid.uuid4().hex); archive.mkdir(parents=True)
                for n, p in enumerate(stale):
                    shutil.move(str(p), str(archive / (str(n) + '_' + p.name)))
            child = subprocess.Popen([sys.executable, '-I', '-S', '-c', UNIT_CHILD, str(root / 'CDT21_SUPERVISOR_JOURNAL'), key])
            identity = ident(child.pid)                               # admit: identity before the unit works
            done = len([k for k in plan if (root / 'COMMITS' / (k + '.json')).exists()])
            print(C.heartbeat_line(key, 0.0, 1, str(done) + '/' + str(len(plan)), tuple(plan[plan.index(key) + 1:]),
                                   datetime.datetime.now(datetime.timezone.utc)), flush=True)
            child.wait()
            (root / 'UNITS' / key).mkdir()
            log = root / 'LOGS' / (key + '.log'); log.write_bytes(b'Ran 1 test in 0.001s\n\nOK\n')
            res = {'status': 'PASS', 'exit_code': 0, 'unit': key, 'test_count': 1, 'native_windows': False,
                   'process': identity}
            R.publish(root / 'UNITS' / key / 'RESULT.json', res)
            if kill_after and new_commits == kill_after:
                os._exit(9)  # abrupt death inside a unit: no commit, no terminal, no seal
            R.publish(commit, dict(schema='CDT19_NATIVE_UNIT_COMMIT_V001', package_sha256=pack, code_sha256=code_sha,
                                   result=res, artifacts=[C.physical(root / 'UNITS' / key / 'RESULT.json', root), C.physical(log, root)],
                                   owner=[identity], own_descendants_final=[], observed_processes=[identity], seconds=0.0))
            if crash_after is not None and new_commits == crash_after:
                # R3-F01 window: the COMMIT is durable, 'COMMITTED <key>' was never printed.
                if crash_mode == 'tree':
                    os.kill(os.getppid(), signal.SIGKILL)
                os._exit(9)
            print('COMMITTED ' + key, flush=True)
            new_commits += 1
            if stop_after and new_commits == stop_after:
                (root / 'SAFE_STOP.request').write_text('operator')
        result['tests'][key] = {'status': 'PASS_NATIVE_SCOPED', 'exit_code': 0}
    result['status'] = 'PASS_NATIVE_INTEGRATED_PRE_B06'; code = 0
except BaseException as exc:
    stopped = 'SAFE_STOP_REQUESTED' in str(exc)
    code = 130 if stopped else 3
    result.update(status='SAFE_STOP' if stopped else 'BLOCKED', blockers=[type(exc).__name__ + ':' + str(exc)])
    print(result['blockers'][0], flush=True)
finally:
    C.write_terminal(root, result)
    z = C.seal_return(root, 'R08_RETURN.zip', excluded=('R08_RETURN.zip', 'R08_RETURN.sha256'))
    (root / 'R08_RETURN.sha256').write_text(R.sha(z.read_bytes()) + '  R08_RETURN.zip\n', encoding='ascii')
sys.exit(code)
