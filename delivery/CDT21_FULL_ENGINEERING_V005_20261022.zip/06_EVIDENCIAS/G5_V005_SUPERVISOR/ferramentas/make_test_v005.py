"""Derive the V005 G5 supervisor harness from the R4 harness (test_r4_reconcile.py): labels V004 -> V005 (the bound
candidate), plus NR14: a COMMIT bound to the V004 parent placed in the window slot is refused (other candidate).
Usage: python -I make_test_v005.py <test_r4_reconcile.py> <out.py>
"""
import hashlib
import sys
from pathlib import Path

src, out = Path(sys.argv[1]), Path(sys.argv[2])
raw = src.read_bytes(); text = raw.decode('utf-8')
r4 = hashlib.sha256(raw).hexdigest().upper()
text = text.replace('V004', 'V005')
add_fn = '''

def nr_v004_parent_commit_in_slot(ctx):
    p = ctx['root'] / 'COMMITS' / (ctx['key'] + '.json'); c = jload(p)
    c['package_sha256'] = 'AD33486954F1248AF28A78677377E83AB979AB86EDD5F71F5B7D108CBA8F99DD'
    c['code_sha256'] = 'D2C626FD2819B86D472433CB2B26C6688B1688E5E5474402162B67C5048666FF'
    jdump(p, c)


def run_r4():
'''
assert text.count('\n\ndef run_r4():\n') == 1
text = text.replace('\n\ndef run_r4():\n', add_fn, 1)
anchor = "    safe(window_negative, 'NR13_attempt_record_of_other_supervisor_refused', nr_attempt_of_other_supervisor, 'RECONCILE_ATTEMPT_RECORD')\n"
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + "    safe(window_negative, 'NR14_v004_parent_commit_in_window_slot_refused', nr_v004_parent_commit_in_slot, 'RESUME_COMMIT_NOT_BOUND_TO_V005')\n")
text = text.replace('"""End-to-end qualification of the G5 V005 supervisor R4', '"""End-to-end qualification of the G5 V005 supervisor (R4 logic, V005 candidate; derived from ' + r4[:16] + ')', 1)
out.write_bytes(text.encode('utf-8'))
print(out.name, hashlib.sha256(text.encode('utf-8')).hexdigest().upper())
