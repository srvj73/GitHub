"""Durable ownership of admitted MULTIWORK attempts; never an admission issuer.

The caller holds FullProcessLease for the exact destination throughout this
protocol. Every child is recorded before its Job start barrier is released.
Unknown, live, foreign, aliased or partially described ownership fails closed.
Old lock bytes are archived before deletion through their exclusively held
Windows handle. No PID is terminated by this module.
"""
from __future__ import annotations

import ctypes
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path
import re
import time
import uuid

import tickstore_serial_runner as core


def require(value, reason):
    if not value:
        raise core.Blocked('CRASH_RECOVERY_' + reason)


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def encoded(obj):
    return (json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def read(path):
    raw = core.secure_read_all(Path(path))
    def pairs(items):
        result = {}
        for k, v in items:
            require(k not in result, 'DUPLICATE_FIELD')
            result[k] = v
        return result
    return json.loads(raw, object_pairs_hook=pairs), raw


def publish(path, obj):
    """Create once, flush, read back. Never replace a prior observation."""
    raw = encoded(obj)
    fd = core.secure_create_new_fd(Path(path))
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    require(core.secure_read_all(Path(path)) == raw, 'RECEIPT_READBACK')
    return {'path': str(path), 'sha256': sha(raw)}


def native_process(pid):
    """Snapshot through a held handle. Access denial is not evidence of death."""
    require(os.name == 'nt', 'WINDOWS_REQUIRED')
    require(type(pid) is int and pid > 0, 'PID')
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    k.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]; k.OpenProcess.restype = w.HANDLE
    k.GetProcessTimes.argtypes = [w.HANDLE] + [ctypes.POINTER(w.FILETIME)] * 4
    k.GetProcessTimes.restype = w.BOOL
    k.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]; k.WaitForSingleObject.restype = w.DWORD
    k.CloseHandle.argtypes = [w.HANDLE]; k.CloseHandle.restype = w.BOOL
    handle = k.OpenProcess(0x00101000, False, pid)  # SYNCHRONIZE | QUERY_LIMITED_INFORMATION
    if not handle:
        error = ctypes.get_last_error()
        require(error == 87, 'PROCESS_VISIBILITY:' + str(error))
        return {'pid': pid, 'state': 'ABSENT'}
    try:
        times = [w.FILETIME() for _ in range(4)]
        require(k.GetProcessTimes(handle, *(ctypes.byref(t) for t in times)), 'PROCESS_TIMES')
        wait = k.WaitForSingleObject(handle, 0)
        require(wait in (0, 258), 'PROCESS_WAIT')
        return {'pid': pid, 'creation_filetime': (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime,
                'state': 'EXITED' if wait == 0 else 'LIVE'}
    finally:
        require(k.CloseHandle(handle), 'PROCESS_CLOSE')


def dead(identity, probe=native_process):
    require(isinstance(identity, dict) and type(identity.get('pid')) is int
            and identity['pid'] > 0 and type(identity.get('creation_filetime')) is int
            and identity['creation_filetime'] > 0, 'IDENTITY')
    now = probe(identity['pid'])
    require(now.get('pid') == identity['pid'], 'CENSUS_PID')
    if now.get('state') == 'ABSENT':
        return dict(identity, observation='ABSENT')
    require(type(now.get('creation_filetime')) is int and now['creation_filetime'] > 0, 'CENSUS_CREATION')
    # PID reuse does not make the old process alive, and never authorizes a kill.
    if now['creation_filetime'] != identity['creation_filetime']:
        return dict(identity, observation='PID_REUSED_OLD_OWNER_DEAD', current_creation_filetime=now['creation_filetime'])
    require(now.get('state') == 'EXITED', 'OWNER_OR_CHILD_LIVE')
    return dict(identity, observation='EXITED')


def binding(admission, dest, instance_scratch):
    return dict(run_id=admission.instance['run_id'], instance_sha256=admission.descriptor['instance_sha256'],
                code_manifest_sha256=admission.descriptor['code_manifest_sha256'],
                destination=core._norm_binding_path(Path(dest)),
                instance_scratch=core._norm_binding_path(Path(instance_scratch)))


def inspect_attempt(directory, expected, *, probe=native_process):
    """Read-only death proof; cannot infer absence from a missing owner record."""
    directory = Path(directory)
    core.strict_directory(directory)
    owner, owner_raw = read(directory/'OWNER.json')
    require(owner.get('schema') == 'TICKSTORE_MULTIWORK_ATTEMPT_OWNER_V001'
            and owner.get('binding') == expected and owner.get('attempt_id') == directory.name, 'FOREIGN_OWNER')
    names = {p.name for p in directory.iterdir()}
    require(all(n in ('OWNER.json', 'LOCK.json', 'CLOSED.json', 'RETIRE_INTENT.json', 'RETIRED.json')
                or re.fullmatch(r'CHILD_[0-9]+_[0-9]+\.json', n) for n in names), 'UNRECOGNIZED_ATTEMPT_MEMBER')
    observations = [dead(owner.get('owner'), probe)]
    children = []
    for path in sorted(directory.glob('CHILD_*.json')):
        child, raw = read(path)
        require(child.get('schema') == 'TICKSTORE_MULTIWORK_CHILD_OWNER_V001'
                and child.get('owner_sha256') == sha(owner_raw), 'CHILD_BINDING')
        ident = child.get('identity', {})
        require(path.name == 'CHILD_%s_%s.json' % (ident.get('pid'), ident.get('creation_filetime')), 'CHILD_NAME')
        observations.append(dead(ident, probe))
        children.append({'path': str(path), 'sha256': sha(raw)})
    return owner, dict(schema='TICKSTORE_MULTIWORK_DEAD_ATTEMPT_V001', binding=expected,
                       owner={'path': str(directory/'OWNER.json'), 'sha256': sha(owner_raw)},
                       children=children, process_observations=observations,
                       own_processes_alive=0, physical_powerloss='NOT_TESTED_PHYSICAL_POWERLOSS')


def retire_lock(path, expected_raw, intent_path, intent):
    """Delete only the verified open file object; no pathname unlink race."""
    require(os.name == 'nt', 'WINDOWS_REQUIRED')
    path = Path(path)
    pins = core._windows_pin_ancestor_chain(path.parent)
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    k.CreateFileW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD, ctypes.c_void_p, w.DWORD, w.DWORD, w.HANDLE]
    k.CreateFileW.restype = w.HANDLE
    k.ReadFile.argtypes = [w.HANDLE, ctypes.c_void_p, w.DWORD, ctypes.POINTER(w.DWORD), ctypes.c_void_p]
    k.ReadFile.restype = w.BOOL
    k.SetFileInformationByHandle.argtypes = [w.HANDLE, ctypes.c_int, ctypes.c_void_p, w.DWORD]
    k.SetFileInformationByHandle.restype = w.BOOL
    k.CloseHandle.argtypes = [w.HANDLE]; k.CloseHandle.restype = w.BOOL
    handle = None
    try:
        handle = k.CreateFileW(str(path), 0x80010000, 0, None, 3, 0x00200000, None)
        require(handle != w.HANDLE(-1).value, 'LOCK_EXCLUSIVE_OPEN:' + str(ctypes.get_last_error()))
        core._windows_validate_handle(k, handle, path)
        buf = ctypes.create_string_buffer(len(expected_raw) + 1); count = w.DWORD()
        require(k.ReadFile(handle, buf, len(buf), ctypes.byref(count), None), 'LOCK_HANDLE_READ')
        require(buf.raw[:count.value] == expected_raw, 'LOCK_CHANGED')
        if core.strict_lstat(intent_path, allow_missing=True) is None:
            publish(intent_path, intent)
        else:
            require(read(intent_path)[0] == intent, 'RETIRE_INTENT_DRIFT')
        # FILE_DISPOSITION_INFO contains a BOOLEAN, not a Win32 BOOL.
        disposition = ctypes.c_ubyte(1)
        require(k.SetFileInformationByHandle(handle, 4, ctypes.byref(disposition), ctypes.sizeof(disposition)),
                'LOCK_HANDLE_DISPOSITION:' + str(ctypes.get_last_error()))
    finally:
        if handle and handle != w.HANDLE(-1).value:
            k.CloseHandle(handle)
        core._windows_unpin(pins)
    require(core.strict_lstat(path, allow_missing=True) is None, 'LOCK_NOT_RETIRED')


class Attempt:
    def __init__(self, admission, dest, scratch, owner_identity):
        self.admission = admission
        self.dest = Path(dest); self.scratch = Path(scratch)
        self.expected = binding(admission, self.dest, self.scratch)
        self.root = self.scratch/'RECOVERY_ATTEMPTS'
        core.strict_directory(self.root, create=True)
        self.recovered = self.reconcile()
        self.path = self.root/uuid.uuid4().hex
        core.strict_directory(self.path, create=True)
        self.owner = dict(schema='TICKSTORE_MULTIWORK_ATTEMPT_OWNER_V001', attempt_id=self.path.name,
                          binding=self.expected, owner=owner_identity, created_unix_ns=time.time_ns())
        self.owner_ref = publish(self.path/'OWNER.json', self.owner)

    def reconcile(self):
        lock = self.dest/'TICKSTORE_WRITER.lock'
        unresolved = []
        for path in sorted(self.root.iterdir()):
            require(re.fullmatch('[0-9a-f]{32}', path.name), 'ATTEMPT_NAME')
            core.strict_directory(path)
            owner, owner_raw = read(path/'OWNER.json')
            require(owner.get('binding') == self.expected and owner.get('attempt_id') == path.name
                    and owner.get('schema') == 'TICKSTORE_MULTIWORK_ATTEMPT_OWNER_V001', 'FOREIGN_OWNER')
            if core.strict_lstat(path/'CLOSED.json', allow_missing=True) is not None:
                closed, _ = read(path/'CLOSED.json')
                require(closed.get('owner_sha256') == sha(owner_raw)
                        and closed.get('own_processes_alive') == 0
                        and closed.get('writer_lock') == 'ABSENT', 'CLOSED_DRIFT')
                require(closed.get('schema') == 'TICKSTORE_MULTIWORK_ATTEMPT_CLOSED_V001', 'CLOSED_SCHEMA')
                for child_path in sorted(path.glob('CHILD_*.json')):
                    child, _ = read(child_path)
                    require(child.get('owner_sha256') == sha(owner_raw), 'CLOSED_CHILD_BINDING')
                    dead(child['identity'])
                continue
            owner, proof = inspect_attempt(path, self.expected)
            if core.strict_lstat(path/'RETIRED.json', allow_missing=True) is not None:
                retired, _ = read(path/'RETIRED.json')
                require(retired.get('owner') == proof['owner'] and retired.get('binding') == self.expected,
                        'RETIRED_DRIFT')
                continue
            unresolved.append((path, owner, proof))
        require(len(unresolved) <= 1, 'MULTIPLE_UNRECONCILED_ATTEMPTS')
        result = []
        for path, owner, proof in unresolved:
            meta_path = path/'LOCK.json'
            exists = core.strict_lstat(lock, allow_missing=True) is not None
            if core.strict_lstat(meta_path, allow_missing=True) is None:
                require(not exists, 'UNBOUND_LOCK')
                proof['lock_disposition'] = 'NO_LOCK_BEFORE_ADMISSION'
            else:
                meta, _ = read(meta_path)
                require(meta.get('owner_sha256') == proof['owner']['sha256'], 'LOCK_OWNER')
                raw = bytes.fromhex(meta['lock_bytes_hex'])
                require(sha(raw) == meta.get('lock_sha256') and json.loads(raw).get('pid') == owner['owner']['pid'], 'LOCK_BYTES')
                intent = dict(schema='TICKSTORE_MULTIWORK_LOCK_RETIRE_INTENT_V001',
                              owner_sha256=proof['owner']['sha256'], lock_sha256=sha(raw),
                              lock_bytes_hex=raw.hex(), binding=self.expected)
                self.admission.revalidate()
                if exists:
                    retire_lock(lock, raw, path/'RETIRE_INTENT.json', intent)
                    proof['lock_disposition'] = 'RETIRED_EXACT_DEAD_OWNER_HANDLE'
                else:
                    # Cleanup may have released the lock immediately before process
                    # death, or the retirement itself may have been interrupted.
                    # No mutation is required and no crash is inferred from absence.
                    if core.strict_lstat(path/'RETIRE_INTENT.json', allow_missing=True) is not None:
                        require(read(path/'RETIRE_INTENT.json')[0] == intent, 'RETIRE_INTENT_DRIFT')
                    proof['lock_disposition'] = 'ALREADY_ABSENT_DEAD_OWNER'
            result.append(publish(path/'RETIRED.json', proof))
        require(core.strict_lstat(lock, allow_missing=True) is None, 'FOREIGN_OR_UNBOUND_LOCK')
        return result

    def bind_lock(self, lock):
        raw = core.secure_read_all(Path(lock))
        require(json.loads(raw).get('pid') == self.owner['owner']['pid'], 'LOCK_PID')
        publish(self.path/'LOCK.json', dict(schema='TICKSTORE_MULTIWORK_LOCK_OWNER_V001',
                owner_sha256=self.owner_ref['sha256'], lock_sha256=sha(raw), lock_bytes_hex=raw.hex()))

    def register_child(self, process):
        identity = native_process(process.pid)
        require(identity.pop('state') == 'LIVE', 'CHILD_NOT_LIVE_BEFORE_ADMISSION')
        publish(self.path/('CHILD_%s_%s.json' % (identity['pid'], identity['creation_filetime'])),
                dict(schema='TICKSTORE_MULTIWORK_CHILD_OWNER_V001', owner_sha256=self.owner_ref['sha256'],
                     identity=identity, name=process.name))

    def close(self, outcome):
        observations = []
        for path in sorted(self.path.glob('CHILD_*.json')):
            observations.append(dead(read(path)[0]['identity']))
        require(core.strict_lstat(self.dest/'TICKSTORE_WRITER.lock', allow_missing=True) is None,
                'CLOSE_LOCK_REMAINS')
        return publish(self.path/'CLOSED.json', dict(schema='TICKSTORE_MULTIWORK_ATTEMPT_CLOSED_V001',
                       owner_sha256=self.owner_ref['sha256'], outcome=outcome, own_processes_alive=0,
                       writer_lock='ABSENT', process_observations=observations))
