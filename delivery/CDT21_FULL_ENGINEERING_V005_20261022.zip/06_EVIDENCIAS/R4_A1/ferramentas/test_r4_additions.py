# ------------------------------------------------------------------ R4: child-process supervisor (whole-tree crash)
import signal  # noqa: E402


def child_main():
    """One E phase in its own process, so that a crash can take the supervisor down with the campaign."""
    spec = json.loads(CHILD)
    w = Path(spec['w']); os.chdir(w); os.environ['LOCALAPPDATA'] = spec['local']
    S.D_LABS = str(w / 'D:\\TICKSTORE_CDT19_PRE_G06_LABS'); S.PRODUCTION = str(w / 'D:\\Base CSV')
    for k in [k for k in os.environ if k.startswith('STUB_')]:
        del os.environ[k]
    os.environ.update(spec.get('env') or {})
    if spec.get('die_in_ledger') is not None:
        orig, calls = S.ledger_record, [0]
        def dying(root, key, attempt, sup, cpid):
            if calls[0] == spec['die_in_ledger']:
                # Supervisor dies after reading COMMITTED <key>, its ledger entry written in TEMP but never moved;
                # kill-on-close takes the campaign tree down with it.
                S.write_new(Path(root) / 'TEMP' / ('LEDGER_' + key + '_' + attempt + '.json'),
                            b'{"partial":"supervisor died before the atomic move"}\n')
                os.kill(cpid, signal.SIGKILL)
                os._exit(9)
            calls[0] += 1
            return orig(root, key, attempt, sup, cpid)
        S.ledger_record = dying
    sys.exit(run_main(spec['args']))


if CHILD:
    child_main()


def launch_child(w, local, resume='', stub_env=None, die_in_ledger=None):
    """Q in this process (as the launcher does), E in a separate supervisor process that the scenario may kill."""
    n = len(list(w.glob('LOG_*')))
    log = w / ('LOG_%02d' % n); stage = w / ('STAGE_%02d' % n); log.mkdir(); stage.mkdir()
    base = ['--package', str(pkg), '--review', str(review), '--log-dir', str(log), '--stage', str(stage)]
    rargs = ['--resume-root', resume] if resume else []
    qcode = run_main(base + ['--qualify-only'] + rargs)
    q = json.loads((log / 'QUALIFICATION_RESULT.json').read_text())
    spec = {'w': str(w), 'local': str(local), 'env': stub_env or {}, 'die_in_ledger': die_in_ledger, 'mutant': MUTANT,
            'args': base + ['--require-qualification', str(log / 'QUALIFICATION_RESULT.json')] + rargs}
    with open(log / 'CHILD_E_STDOUT.txt', 'wb') as so:
        cp = REAL_POPEN([sys.executable, '-I', '-B', sys.argv[0]] + sys.argv[1:8] + ['--child-e', json.dumps(spec)],
                        stdout=so, stderr=subprocess.STDOUT)
        rc = cp.wait(timeout=600)
    os.chdir(w)
    res = log / 'SUPERVISOR_RESULT.json'
    return {'q_code': qcode, 'q': q, 'e_code': rc, 'e': json.loads(res.read_text()) if res.exists() else {}, 'log': log,
            'supervisor_result_written': res.exists()}


# ------------------------------------------------------------------ R4 helpers
def jload(p):
    return json.loads(Path(p).read_text())


def jdump(p, obj):
    Path(p).write_bytes((json.dumps(obj, sort_keys=True, separators=(',', ':')) + '\n').encode('ascii'))


def journal(root):
    return Path(root) / 'CDT21_SUPERVISOR_JOURNAL'


def attempts_of(root):
    return sorted((jload(p) for p in journal(root).glob('ATTEMPT_*.json')), key=lambda r: r['sequence'])


def census_of(root, attempt, key):
    p = journal(root) / ('CENSUS_' + attempt + '_' + key + '.json')
    return jload(p) if p.exists() else None


def commit_keys(root):
    return sorted(p.stem for p in (Path(root) / 'COMMITS').glob('*.json'))


def rehash_ref(root, key, member):
    """Keep a tampered artifact hash-intact in its COMMIT (so only the R4 proof can refuse it)."""
    cp = Path(root) / 'COMMITS' / (key + '.json'); c = jload(cp)
    raw = (Path(root) / member).read_bytes()
    for ref in c['artifacts']:
        if ref['member'] == member:
            ref['sha256'] = hashlib.sha256(raw).hexdigest().upper(); ref['bytes'] = len(raw)
    jdump(cp, c)


def copy_commit(src_root, dst_root, key):
    c = jload(Path(src_root) / 'COMMITS' / (key + '.json'))
    for ref in c['artifacts']:
        d = Path(dst_root) / ref['member']; d.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(Path(src_root) / ref['member'], d)
    shutil.copyfile(Path(src_root) / 'COMMITS' / (key + '.json'), Path(dst_root) / 'COMMITS' / (key + '.json'))


WINDOW = {'STUB_CRASH_AFTER_PUBLISH': '3', 'STUB_CRASH_MODE': 'campaign'}


def window_state(tag):
    """R3-F01 window: 3 units committed and ledgered; the 4th COMMIT published, the campaign dies before COMMITTED."""
    w, local = env(tag)
    r1 = launch(w, stub_env=WINDOW)
    root = own_root(r1); plan = r1['q']['plan']
    return w, local, r1, root, plan, plan[3]


def window_facts(r1, root, plan, key):
    led = ledger(root); att = attempts_of(root)
    return {'e_code': r1['e_code'], 'ledger': sorted(led), 'commits': commit_keys(root),
            'committed_line_seen': key in (r1['e'].get('newly_committed_units') or []),
            'attempts': len(att), 'census_for_key': census_of(root, att[-1]['attempt'], key) is not None if att else False}


def window_ok(f, plan, key):
    return (sorted(f['ledger']) == sorted(plan[:3]) and f['commits'] == sorted(plan[:4]) and not f['committed_line_seen']
            and f['census_for_key'])


def reconciled_pass(r, root, key, reused_n, new_n):
    led = ledger(root); e = r['e']
    entry = led.get(key, {})
    return (r['q_code'] == 0 and (((r['q'].get('resume') or {}).get('reconcile')) or {}).get('key') == key
            and r['e_code'] == 0 and e.get('status') == 'PASS_NATIVE_V004_G5_TECHNICAL_FIVE_PART'
            and entry.get('basis') == 'RECONCILED_BY_SUPERVISOR_JOB_CENSUS' and key in e.get('reused_committed_units', [])
            and key not in e.get('newly_committed_units', []) and len(e.get('reused_committed_units', [])) == reused_n
            and len(e.get('newly_committed_units', [])) == new_n and len(led) == 38
            and not ((Path(root) / 'INTERRUPTED_ATTEMPTS').is_dir()
                     and any(p.name.startswith(key + '_') for p in (Path(root) / 'INTERRUPTED_ATTEMPTS').iterdir())))


# ------------------------------------------------------------------ R4 scenarios
def Q1_census_probe_and_new_run_journal():
    w, local = env('Q1')
    r = launch(w)
    root = own_root(r); att = attempts_of(root)
    cen = sorted(journal(root).glob('CENSUS_*.json'))
    check('Q1a_q_census_sees_nested_child', r['q_code'] == 0
          and r['q']['checks'].get('job_census_sees_nested_child', {}).get('status') == 'PASS', r['q'].get('job_census_probe'))
    check('Q1b_new_run_journal_1_attempt_38_unit_census_no_error', r['e_code'] == 0 and len(att) == 1 and att[0]['sequence'] == 0
          and att[0]['ledger_keys_at_start'] == [] and len(cen) == 38 and r['e'].get('unit_census_errors') == []
          and sorted(r['e'].get('unit_census_recorded', [])) == sorted(r['q']['plan'])
          and all(any(p['pid'] == jload(Path(root) / 'COMMITS' / (k + '.json'))['owner'][0]['pid'] for p in jload(c)['processes'])
                  for c in cen for k in [jload(c)['key']]),
          {'attempts': len(att), 'census': len(cen), 'errors': r['e'].get('unit_census_errors')})
    import zipfile
    with zipfile.ZipFile(r['e']['return_zip']) as z:
        names = z.namelist()
    check('Q1c_outer_return_carries_journal', sum(n.startswith('CDT21_SUPERVISOR_JOURNAL/') for n in names) == 39, len(names))


def W1_campaign_dies_in_window():
    w, local, r1, root, plan, key = window_state('W1')
    f = window_facts(r1, root, plan, key)
    check('W1a_window_state_commit_durable_not_ledgered_supervisor_alive', r1['e_code'] == 3 and has(r1, 'R08_RETURN_NOT_SEALED')
          and window_ok(f, plan, key), f)
    before = {k: H(Path(root) / k) for k in ('COMMITS/' + key + '.json', 'UNITS/' + key + '/RESULT.json', 'LOGS/' + key + '.log')}
    r2 = launch(w, resume=root)
    proof = (r2['q'].get('resume') or {}).get('reconcile') or {}
    c = jload(Path(root) / 'COMMITS' / (key + '.json'))
    check('W1b_q_proof_owner_eq_result_process_in_census_latest_attempt', r2['q_code'] == 0 and proof.get('key') == key
          and proof.get('owner') == {'pid': c['owner'][0]['pid'], 'creation_filetime': c['owner'][0]['creation_filetime']}
          and proof.get('attempt') == attempts_of(root)[0]['attempt'] and proof.get('attempt_sequence') == 0, proof)
    check('W1c_e_reconciles_reuses_without_reexecution_pass', reconciled_pass(r2, root, key, 4, 34)
          and all(H(Path(root) / k) == v for k, v in before.items())
          and any(jload(p).get('reconciled', {}).get('key') == key for p in Path(root).glob('CDT21_SUPERVISOR_RESUME_*.json')),
          {'blockers': blockers(r2), 'reused': len(r2['e'].get('reused_committed_units', []))})


def W2_whole_tree_dies_in_window():
    w, local = env('W2')
    r1 = launch_child(w, local, stub_env={'STUB_CRASH_AFTER_PUBLISH': '3', 'STUB_CRASH_MODE': 'tree'})
    root = [p for p in (local / 'CDT20_R08').glob('R08_Q1_2026*') if p.name != 'R08_Q1_20261020210605_856fea523791']
    root = str(root[0]) if len(root) == 1 else None
    plan = r1['q']['plan']; key = plan[3]
    f = window_facts(r1, root, plan, key) if root else {}
    check('W2a_supervisor_and_campaign_killed_after_publish', r1['e_code'] == -9 and not r1['supervisor_result_written']
          and root is not None and window_ok(f, plan, key), {'rc': r1['e_code'], 'facts': f})
    r2 = launch(w, resume=root)
    check('W2b_resume_reconciles_and_passes', reconciled_pass(r2, root, key, 4, 34), {'blockers': blockers(r2)})


def W3_supervisor_dies_inside_ledger_write():
    w, local = env('W3')
    r1 = launch_child(w, local, die_in_ledger=3)
    root = [p for p in (local / 'CDT20_R08').glob('R08_Q1_2026*') if p.name != 'R08_Q1_20261020210605_856fea523791']
    root = str(root[0]) if len(root) == 1 else None
    plan = r1['q']['plan']; key = plan[3]
    led = ledger(root) if root else {}
    partial = sorted((Path(root) / 'TEMP').glob('LEDGER_' + key + '_*.json')) if root else []
    att = attempts_of(root) if root else []
    check('W3a_committed_line_read_ledger_not_moved_tree_killed', r1['e_code'] == 9 and not r1['supervisor_result_written']
          and sorted(led) == sorted(plan[:3]) and commit_keys(root) == sorted(plan[:4]) and len(partial) == 1
          and census_of(root, att[-1]['attempt'], key) is not None,
          {'rc': r1['e_code'], 'ledger': len(led), 'partial': [p.name for p in partial]})
    raw_partial = partial[0].read_bytes() if partial else b''
    r2 = launch(w, resume=root)
    check('W3b_resume_reconciles_partial_temp_preserved', reconciled_pass(r2, root, key, 4, 34)
          and partial and partial[0].read_bytes() == raw_partial, {'blockers': blockers(r2)})


def W4_window_inside_a_resumed_attempt():
    w, local, r1, root = stopped_campaign('W4', STUB_STOP_AFTER=5)
    plan = r1['q']['plan']
    r2 = launch(w, resume=root, stub_env={'STUB_CRASH_AFTER_PUBLISH': '2', 'STUB_CRASH_MODE': 'campaign'})
    key = plan[7]; att = attempts_of(root)
    ok_state = (r2['e_code'] == 3 and r2['e'].get('status') == 'BLOCKED' and has(r2, 'CAMPAIGN_ABRUPT_EXIT_NO_TERMINAL_OF_THIS_ATTEMPT:9')
                and sorted(ledger(root)) == sorted(plan[:7]) and commit_keys(root) == sorted(plan[:8])
                and len(att) == 2 and census_of(root, att[1]['attempt'], key) is not None)
    r3 = launch(w, resume=root)
    proof = (r3['q'].get('resume') or {}).get('reconcile') or {}
    check('W4_second_attempt_window_reconciled_from_latest_attempt', ok_state and reconciled_pass(r3, root, key, 8, 30)
          and proof.get('attempt') == att[1]['attempt'] and proof.get('attempt_sequence') == 1 and len(attempts_of(root)) == 3,
          {'state': ok_state, 'blockers': blockers(r3), 'proof_attempt': proof.get('attempt_sequence')})


def window_negative(tag, mutate, expect):
    w, local, r1, root, plan, key = window_state(tag)
    ctx = {'w': w, 'local': local, 'root': Path(root), 'plan': plan, 'key': key}
    mutate(ctx)
    r = launch(w, resume=root)
    check(tag, r['q_code'] not in (0, None) and has(r, expect) and len(ledger(root)) == 3 - ctx.get('ledger_removed', 0)
          and not (Path(root) / 'CDT21_SUPERVISOR_LEDGER' / (key + '.json')).exists(),
          {'q_code': r['q_code'], 'blockers': blockers(r)[:2]})
    return r


def other_v004_root(ctx):
    """A second, complete-enough V004 campaign (same bytes) in the same LOCALAPPDATA: the foreign source."""
    if 'other' not in ctx:
        r = launch(ctx['w'], stub_env={'STUB_STOP_AFTER': '6'})
        ctx['other'] = Path(own_root(r))
    return ctx['other']


def nr_foreign_commit_in_slot(ctx):
    copy_commit(other_v004_root(ctx), ctx['root'], ctx['key'])


def nr_census_deleted(ctx):
    for p in journal(ctx['root']).glob('CENSUS_*_' + ctx['key'] + '.json'):
        p.unlink()


def nr_census_of_other_unit(ctx):
    att = attempts_of(ctx['root'])[-1]['attempt']
    src = journal(ctx['root']) / ('CENSUS_' + att + '_' + ctx['plan'][2] + '.json')
    shutil.copyfile(src, journal(ctx['root']) / ('CENSUS_' + att + '_' + ctx['key'] + '.json'))


def nr_result_process_tampered(ctx):
    member = 'UNITS/' + ctx['key'] + '/RESULT.json'; p = ctx['root'] / member
    res = jload(p); res['process']['creation_filetime'] += 1; jdump(p, res)
    rehash_ref(ctx['root'], ctx['key'], member)


def nr_two_unledgered(ctx):
    copy_commit(other_v004_root(ctx), ctx['root'], ctx['plan'][4])


def nr_gap_before_slot(ctx):
    keep = ctx['root'] / 'INTERRUPTED_ATTEMPTS' / 'TEST_MOVED'; keep.mkdir(parents=True, exist_ok=True)
    k2 = ctx['plan'][2]
    shutil.move(str(ctx['root'] / 'COMMITS' / (k2 + '.json')), str(keep / ('COMMIT_' + k2 + '.json')))
    shutil.move(str(ctx['root'] / 'CDT21_SUPERVISOR_LEDGER' / (k2 + '.json')), str(keep / ('LEDGER_' + k2 + '.json')))
    ctx['ledger_removed'] = 1


def nr_later_attempt_without_census(ctx):
    last = attempts_of(ctx['root'])[-1]
    forged = dict(last, attempt='29991231235959_ffffff', sequence=last['sequence'] + 1)
    jdump(journal(ctx['root']) / 'ATTEMPT_29991231235959_ffffff.json', forged)


def nr_v003_commit_in_slot(ctx):
    v3 = ctx['local'] / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791' / 'COMMITS'
    src = v3 / (ctx['key'] + '.json')
    shutil.copyfile(src if src.exists() else sorted(v3.glob('*.json'))[0], ctx['root'] / 'COMMITS' / (ctx['key'] + '.json'))


def nr_other_candidate_in_slot(ctx):
    p = ctx['root'] / 'COMMITS' / (ctx['key'] + '.json'); c = jload(p); c['package_sha256'] = 'C' * 64; jdump(p, c)


def nr_artifact_tampered(ctx):
    p = ctx['root'] / 'LOGS' / (ctx['key'] + '.log'); p.write_bytes(p.read_bytes() + b'X')


def nr_census_creation_differs(ctx):
    att = attempts_of(ctx['root'])[-1]['attempt']
    owner = jload(ctx['root'] / 'COMMITS' / (ctx['key'] + '.json'))['owner'][0]
    p = journal(ctx['root']) / ('CENSUS_' + att + '_' + ctx['key'] + '.json'); c = jload(p)
    for q in c['processes']:
        if q['pid'] == owner['pid']:
            q['creation_filetime'] += 1  # same PID, other process (PID reuse)
    jdump(p, c)


def nr_owner_is_campaign(ctx):
    att = attempts_of(ctx['root'])[-1]['attempt']
    c = census_of(ctx['root'], att, ctx['key'])
    camp = [q for q in c['processes'] if q['pid'] == c['campaign_pid']][0]
    member = 'UNITS/' + ctx['key'] + '/RESULT.json'; rp = ctx['root'] / member
    res = jload(rp); res['process'] = {'pid': camp['pid'], 'creation_filetime': camp['creation_filetime'], 'state': 'LIVE'}
    jdump(rp, res); rehash_ref(ctx['root'], ctx['key'], member)
    cp = ctx['root'] / 'COMMITS' / (ctx['key'] + '.json'); cm = jload(cp)
    cm['owner'] = [res['process']]; cm['result'] = res; jdump(cp, cm)


def nr_attempt_of_other_supervisor(ctx):
    last = sorted(journal(ctx['root']).glob('ATTEMPT_*.json'))[-1]
    a = jload(last); a['supervisor_sha256'] = 'E' * 64; jdump(last, a)


def run_r4():
    safe(Q1_census_probe_and_new_run_journal)
    safe(W1_campaign_dies_in_window)
    safe(W2_whole_tree_dies_in_window)
    safe(W3_supervisor_dies_inside_ledger_write)
    safe(W4_window_inside_a_resumed_attempt)
    safe(window_negative, 'NR01_foreign_v004_commit_in_window_slot_refused', nr_foreign_commit_in_slot, 'RECONCILE_OWNER_NOT_IN_SUPERVISOR_CENSUS')
    safe(window_negative, 'NR02_no_supervisor_census_refused', nr_census_deleted, 'RECONCILE_NO_CENSUS_IN_LAST_ATTEMPT')
    safe(window_negative, 'NR03_census_of_another_unit_refused', nr_census_of_other_unit, 'RECONCILE_CENSUS_RECORD')
    safe(window_negative, 'NR04_result_process_ne_owner_refused', nr_result_process_tampered, 'RECONCILE_RESULT_PROCESS_NE_OWNER')
    safe(window_negative, 'NR05_two_unledgered_commits_refused', nr_two_unledgered, 'RECONCILE_MORE_THAN_ONE')
    safe(window_negative, 'NR06_unledgered_commit_not_next_plan_unit_refused', nr_gap_before_slot, 'RECONCILE_NOT_NEXT_PLAN_KEY')
    safe(window_negative, 'NR07_census_not_from_latest_attempt_refused', nr_later_attempt_without_census, 'RECONCILE_NO_CENSUS_IN_LAST_ATTEMPT')
    safe(window_negative, 'NR08_v003_commit_in_window_slot_refused', nr_v003_commit_in_slot, 'RESUME_COMMIT_BOUND_TO_V003')
    safe(window_negative, 'NR09_other_candidate_commit_in_window_slot_refused', nr_other_candidate_in_slot, 'RESUME_COMMIT_NOT_BOUND_TO_V004')
    safe(window_negative, 'NR10_artifact_drift_in_window_slot_refused', nr_artifact_tampered, 'RESUME_COMMIT_ARTIFACT_DRIFT')
    safe(window_negative, 'NR11_pid_reused_other_creation_refused', nr_census_creation_differs, 'RECONCILE_OWNER_NOT_IN_SUPERVISOR_CENSUS')
    safe(window_negative, 'NR12_owner_is_campaign_child_refused', nr_owner_is_campaign, 'RECONCILE_OWNER_IS_SUPERVISOR_OR_CAMPAIGN')
    safe(window_negative, 'NR13_attempt_record_of_other_supervisor_refused', nr_attempt_of_other_supervisor, 'RECONCILE_ATTEMPT_RECORD')


GROUPS = os.environ.get('R4_GROUPS', 'R3,R4').split(',')
if 'R3' in GROUPS:
    run_all()
if 'R4' in GROUPS:
    run_r4()
