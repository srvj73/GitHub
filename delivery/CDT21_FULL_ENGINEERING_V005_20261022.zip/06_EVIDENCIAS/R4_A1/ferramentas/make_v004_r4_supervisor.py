"""Derive the G5 V004 supervisor R4 from R3 (2765FAAA...) by exact, counted replacements.

Usage: python -I make_v004_r4_supervisor.py <CDT21_G5_V004_SUPERVISOR.py R3> <out.py>
Origin finding R3-F01 (DURABLE_COMMIT_TO_SUPERVISOR_LEDGER_CRASH_GAP): the frozen campaign publishes
COMMITS/<key>.json (R.publish, fsync) BEFORE it prints 'COMMITTED <key>', and the R3 supervisor writes its ledger
entry only after reading that line.  A crash in between leaves one durable COMMIT without a ledger entry, and R3
refuses to resume that root (COMMIT_NOT_LEDGERED).  R4 closes only that gap:
  * attempt journal (CDT21_SUPERVISOR_JOURNAL): before each campaign child exists, a create-once ATTEMPT record
    (sequence, supervisor identity, ledger at start);
  * unit census: when its own campaign child prints 'HEARTBEAT ACTIVE_TEST=<key>', the supervisor lists the live
    processes of its own kill-on-close Job (nested unit Jobs included; no breakaway) and records them once per unit;
  * resume admission: at most ONE unledgered COMMIT, the next plan unit, is reconciled, and only if its single owner
    identity (pid, creation) equals the process of its committed RESULT.json and is listed in the supervisor's census
    of that unit in the latest attempt (and is neither the supervisor nor the campaign child); the reconciliation
    is written in the ledger (basis RECONCILED_BY_SUPERVISOR_JOB_CENSUS) under the campaign lock before the frozen
    campaign starts, which then reuses that COMMIT through the frozen run_unit; it is never re-executed;
  * Q (no effect) proves natively that the census sees a child moved into a nested Job, with the identity that the
    frozen R.native_process reports.
Everything else is R3: new run, V003 / other-candidate / other-campaign refusal, R2 NTFS digests, R1 classification.
"""
import hashlib
import sys
from pathlib import Path

PARENT_SHA = '2765FAAAC4725F5925921E25B93E145D3719EFC686BDFD7511A110440B0A1DAD'
src, out = Path(sys.argv[1]), Path(sys.argv[2])
raw = src.read_bytes()
assert hashlib.sha256(raw).hexdigest().upper() == PARENT_SHA, 'PARENT_SHA'
text = raw.decode('utf-8')


def sub(old, new, count=1):
    global text
    assert text.count(old) == count, ('ANCHOR', old[:100])
    text = text.replace(old, new)


# R4-1 docstring.
sub("    check records the difference per root and per entry.  Names, types, fields and checks are unchanged.\n\n",
    "    check records the difference per root and per entry.  Names, types, fields and checks are unchanged.\n"
    "  * R4 (origin finding R3-F01): a COMMIT made durable by the frozen campaign whose ledger entry was lost in a\n"
    "    crash (R.publish before 'COMMITTED <key>') is reconciled on resume only by proof of its own provenance:\n"
    "    next plan unit, single owner identity equal to its RESULT.json process and listed in this supervisor's own\n"
    "    Job census of that unit in the latest attempt (journal).  Without that proof the root is refused.\n\n")

# R4-2 constants.
sub("LEDGER_SCHEMA = 'CDT21_G5_V004_COMMIT_LEDGER_V001'\n",
    "LEDGER_SCHEMA = 'CDT21_G5_V004_COMMIT_LEDGER_V001'\n"
    "JOURNAL_DIR = 'CDT21_SUPERVISOR_JOURNAL'     # inside the run root: attempt records and the supervisor's unit census\n"
    "ATTEMPT_SCHEMA = 'CDT21_G5_V004_ATTEMPT_V001'\n"
    "CENSUS_SCHEMA = 'CDT21_G5_V004_UNIT_CENSUS_V001'\n"
    "RECONCILED_BASIS = 'RECONCILED_BY_SUPERVISOR_JOB_CENSUS'\n")

# R4-3 outer return: the journal travels with the return (like the ledger).
sub("    trees = [root / 'FINAL_G5', root / 'SOURCE_REVIEW', root / LEDGER_DIR] + sorted(root.glob('G5_ASSEMBLY_INPUTS_*'))\n",
    "    trees = [root / 'FINAL_G5', root / 'SOURCE_REVIEW', root / LEDGER_DIR, root / JOURNAL_DIR] + sorted(root.glob('G5_ASSEMBLY_INPUTS_*'))\n")

# R4-4 SupervisorJob: census of its own Job (nested Jobs included) and the Q probe.
sub("        k.CloseHandle.argtypes = [w.HANDLE]; k.CloseHandle.restype = w.BOOL\n",
    "        k.CloseHandle.argtypes = [w.HANDLE]; k.CloseHandle.restype = w.BOOL\n"
    "        k.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]; k.OpenProcess.restype = w.HANDLE\n"
    "        k.IsProcessInJob.argtypes = [w.HANDLE, w.HANDLE, ctypes.POINTER(w.BOOL)]; k.IsProcessInJob.restype = w.BOOL\n"
    "        k.GetProcessTimes.argtypes = [w.HANDLE] + [ctypes.POINTER(w.FILETIME)] * 4; k.GetProcessTimes.restype = w.BOOL\n"
    "        k.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]; k.WaitForSingleObject.restype = w.DWORD\n"
    "        self.w = w\n")
sub("        return int(info.ActiveProcesses) if ok else -1\n",
    "        return int(info.ActiveProcesses) if ok else -1\n"
    "\n"
    "    def census(self):\n"
    "        \"\"\"R4: live processes of this Job, nested Jobs included (JobObjectBasicProcessIdList), as (pid, creation)\n"
    "        read through a held handle; a PID reused outside this Job (IsProcessInJob) is not counted.\"\"\"\n"
    "        ctypes, k, w = self.ctypes, self.k, self.w\n"
    "        capacity = 64\n"
    "        for _ in range(8):\n"
    "            class PIDs(ctypes.Structure):\n"
    "                _fields_ = [('assigned', w.DWORD), ('count', w.DWORD), ('pids', ctypes.c_size_t * capacity)]\n"
    "            info = PIDs()\n"
    "            ok = k.QueryInformationJobObject(self.handle, 3, ctypes.byref(info), ctypes.sizeof(info), None)\n"
    "            if ok and info.count == info.assigned:\n"
    "                pids = list(info.pids[:info.count]); break\n"
    "            require(ok or ctypes.get_last_error() == 234, 'JOB_CENSUS_QUERY:' + str(ctypes.get_last_error()))\n"
    "            capacity = max(capacity * 2, int(info.assigned))\n"
    "        else:\n"
    "            raise Blocked('JOB_CENSUS_UNSTABLE')\n"
    "        seen = []\n"
    "        for pid in sorted(set(pids)):\n"
    "            handle = k.OpenProcess(0x00101000, False, pid)  # SYNCHRONIZE | QUERY_LIMITED_INFORMATION\n"
    "            if not handle:\n"
    "                require(ctypes.get_last_error() == 87, 'JOB_CENSUS_OPEN:' + str(ctypes.get_last_error()))\n"
    "                continue  # exited before open\n"
    "            try:\n"
    "                member = w.BOOL()\n"
    "                require(bool(k.IsProcessInJob(handle, self.handle, ctypes.byref(member))), 'JOB_CENSUS_MEMBERSHIP')\n"
    "                if not member.value:\n"
    "                    continue  # PID reused outside this Job\n"
    "                times = [w.FILETIME() for _ in range(4)]\n"
    "                require(bool(k.GetProcessTimes(handle, *(ctypes.byref(t) for t in times))), 'JOB_CENSUS_TIMES')\n"
    "                wait = k.WaitForSingleObject(handle, 0)\n"
    "                require(wait in (0, 258), 'JOB_CENSUS_WAIT')\n"
    "                if wait == 258:\n"
    "                    seen.append({'pid': pid, 'creation_filetime': (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime})\n"
    "            finally:\n"
    "                k.CloseHandle(handle)\n"
    "        return seen\n"
    "\n"
    "    def nested_census_probe(self, native):\n"
    "        \"\"\"R4 Q (no effect): a child moved into a nested Job, as the frozen ProcessJob does with every unit, is seen\n"
    "        by census() with the identity that the frozen R.native_process reports; so is this process.\"\"\"\n"
    "        import subprocess\n"
    "        child = subprocess.Popen([sys.executable, '-I', '-S', '-c', 'import time; time.sleep(60)'],\n"
    "                                 stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)\n"
    "        nested = None\n"
    "        try:\n"
    "            nested = self.k.CreateJobObjectW(None, None)\n"
    "            require(bool(nested), 'PROBE_NESTED_JOB_CREATE:' + str(self.ctypes.get_last_error()))\n"
    "            require(bool(self.k.AssignProcessToJobObject(nested, int(child._handle))),\n"
    "                    'PROBE_NESTED_JOB_ASSIGN:' + str(self.ctypes.get_last_error()))\n"
    "            mine, theirs = native(os.getpid()), native(child.pid)\n"
    "            seen = {(p['pid'], p['creation_filetime']) for p in self.census()}\n"
    "            return {'self': [mine['pid'], mine['creation_filetime']], 'nested_child': [theirs['pid'], theirs['creation_filetime']],\n"
    "                    'census_size': len(seen), 'seen_self': (mine['pid'], mine['creation_filetime']) in seen,\n"
    "                    'seen_nested_child': (theirs['pid'], theirs['creation_filetime']) in seen}\n"
    "        finally:\n"
    "            child.kill(); child.wait(30)\n"
    "            if nested:\n"
    "                self.k.CloseHandle(nested)\n")

# R4-5 journal, census record, proof of provenance, ledger admission and reconciliation.
NEW_FUNCS = '''

def frozen_native():
    import FULL_CRASH_RECOVERY as R  # frozen V004 module, importable after plan_keys()
    return R.native_process


def journal_write(root, name, obj):
    """R4: create-once journal record, written and read back in TEMP (outside the frozen seal), moved atomically."""
    target = root / JOURNAL_DIR / name
    require(not target.exists(), 'JOURNAL_RECORD_EXISTS:' + name)
    temp = root / 'TEMP' / ('JOURNAL_' + name)
    write_new(temp, encoded(obj))
    os.replace(temp, target)
    return sha_file(target)


def journal_attempt(root, attempt, supervisor_sha, supervisor, plan):
    """R4: durable record of this attempt BEFORE its campaign child exists: sequence, supervisor identity and the
    ledger at start.  The latest record names the only attempt whose interrupted COMMIT may be reconciled."""
    journal = root / JOURNAL_DIR
    ledgered = {p.stem for p in (root / LEDGER_DIR).glob('*.json')}
    rec = {'schema': ATTEMPT_SCHEMA, 'run_id': root.name, 'attempt': attempt,
           'sequence': len(list(journal.glob('ATTEMPT_*.json'))), 'supervisor_sha256': supervisor_sha,
           'supervisor': {'pid': supervisor['pid'], 'creation_filetime': supervisor['creation_filetime']},
           'ledger_keys_at_start': [k for k in plan if k in ledgered],
           'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    journal_write(root, 'ATTEMPT_' + attempt + '.json', rec)
    return rec


def journal_census(root, attempt, key, processes, campaign_pid, supervisor_sha, line):
    """R4: the supervisor's own Job census while ITS campaign child reports unit <key> active (HEARTBEAT on its
    stdout).  The Job holds only this supervisor's tree (no breakaway; unit Jobs are nested), so a process listed
    here belongs to this attempt.  Recorded once per unit, and only when a unit process is seen."""
    if not [p for p in processes if p['pid'] not in (os.getpid(), campaign_pid)]:
        return False
    journal_write(root, 'CENSUS_' + attempt + '_' + key + '.json',
                  {'schema': CENSUS_SCHEMA, 'run_id': root.name, 'attempt': attempt, 'key': key,
                   'supervisor_sha256': supervisor_sha, 'supervisor_pid': os.getpid(), 'campaign_pid': campaign_pid,
                   'processes': [{'pid': p['pid'], 'creation_filetime': p['creation_filetime']} for p in processes],
                   'trigger': line[:240], 'observed_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())})
    return True


def reconcile_proof(root, key, commit_sha, ledgered):
    """R4 (origin finding R3-F01): the frozen campaign publishes COMMITS/<key>.json BEFORE printing COMMITTED and
    the ledger follows that line, so a crash in between leaves one durable, unledgered COMMIT.  It is this
    campaign's own only if all hold: its single owner identity (pid, creation) is the process of its committed
    RESULT.json; the latest attempt record of this root, written by this supervisor, did not have it ledgered;
    and this supervisor's own Job census of that attempt, taken while its campaign child reported that unit active,
    lists that owner, which is neither the supervisor nor the campaign child.  Any doubt refuses."""
    def need(ok, why):
        require(ok, 'COMMIT_NOT_LEDGERED:' + key + ':RECONCILE_' + why)
    commit = strict_json((root / 'COMMITS' / (key + '.json')).read_bytes())
    owner = commit.get('owner')
    need(isinstance(owner, list) and len(owner) == 1 and isinstance(owner[0], dict)
         and type(owner[0].get('pid')) is int and owner[0]['pid'] > 0
         and type(owner[0].get('creation_filetime')) is int and owner[0]['creation_filetime'] > 0, 'OWNER_IDENTITY')
    ident = (owner[0]['pid'], owner[0]['creation_filetime'])
    need(('UNITS/' + key + '/RESULT.json') in [r.get('member') for r in commit['artifacts']], 'RESULT_NOT_COMMITTED')
    res = strict_json((root / 'UNITS' / key / 'RESULT.json').read_bytes())  # bytes re-hashed against the COMMIT
    proc = res.get('process') if isinstance(res.get('process'), dict) else {}
    need(res.get('unit') == key and commit.get('result') == res
         and (proc.get('pid'), proc.get('creation_filetime')) == ident, 'RESULT_PROCESS_NE_OWNER')
    journal = root / JOURNAL_DIR
    records = [strict_json(p.read_bytes()) for p in sorted(journal.glob('ATTEMPT_*.json'))]
    seqs = [r.get('sequence') for r in records]
    need(bool(records) and all(type(s) is int for s in seqs) and sorted(seqs) == list(range(len(seqs))), 'ATTEMPT_JOURNAL')
    last = max(records, key=lambda r: r['sequence'])
    start = last.get('ledger_keys_at_start')
    need(last.get('schema') == ATTEMPT_SCHEMA and last.get('run_id') == root.name
         and last.get('supervisor_sha256') == sha_file(__file__) and isinstance(last.get('attempt'), str)
         and (journal / ('ATTEMPT_' + last['attempt'] + '.json')).is_file()
         and isinstance(start, list) and set(start) <= set(ledgered) and key not in start, 'ATTEMPT_RECORD')
    path = journal / ('CENSUS_' + last['attempt'] + '_' + key + '.json')
    need(path.is_file(), 'NO_CENSUS_IN_LAST_ATTEMPT')
    census = strict_json(path.read_bytes())
    need(census.get('schema') == CENSUS_SCHEMA and census.get('run_id') == root.name
         and census.get('attempt') == last['attempt'] and census.get('key') == key
         and census.get('supervisor_sha256') == sha_file(__file__), 'CENSUS_RECORD')
    seen = {(p.get('pid'), p.get('creation_filetime')) for p in census.get('processes') or [] if isinstance(p, dict)}
    need(ident in seen, 'OWNER_NOT_IN_SUPERVISOR_CENSUS')
    sup = last.get('supervisor') or {}
    need(ident != (sup.get('pid'), sup.get('creation_filetime'))
         and ident[0] not in (census.get('campaign_pid'), census.get('supervisor_pid')), 'OWNER_IS_SUPERVISOR_OR_CAMPAIGN')
    return {'key': key, 'commit_file_sha256': commit_sha, 'owner': {'pid': ident[0], 'creation_filetime': ident[1]},
            'result_sha256': sha_file(root / 'UNITS' / key / 'RESULT.json'), 'attempt': last['attempt'],
            'attempt_sequence': last['sequence'], 'campaign_pid': census.get('campaign_pid'),
            'attempt_record_sha256': sha_file(journal / ('ATTEMPT_' + last['attempt'] + '.json')),
            'census_record_sha256': sha_file(path), 'basis': RECONCILED_BASIS}


def ledger_admit(root, commit_sha, plan):
    """R4 resume admission of the ledger: ledger_bound on every COMMIT except at most ONE unledgered COMMIT, which
    must be the next plan unit after the ledger and pass reconcile_proof.  Returns (attempts, proof or None)."""
    entries = {p.stem for p in (root / LEDGER_DIR).glob('*.json')}
    pending = [k for k in plan if k in commit_sha and k not in entries]
    if not pending:
        return ledger_bound(root, commit_sha), None
    require(len(pending) == 1, 'COMMIT_NOT_LEDGERED:' + ','.join(pending) + ':RECONCILE_MORE_THAN_ONE')
    key = pending[0]
    attempts = ledger_bound(root, {k: v for k, v in commit_sha.items() if k != key})
    n = len(attempts)
    require(set(attempts) == set(plan[:n]), 'COMMIT_NOT_LEDGERED:' + key + ':RECONCILE_LEDGER_NOT_PLAN_PREFIX')
    require(key == plan[n], 'COMMIT_NOT_LEDGERED:' + key + ':RECONCILE_NOT_NEXT_PLAN_KEY')
    return attempts, reconcile_proof(root, key, commit_sha[key], set(attempts))


def ledger_reconcile(root, proof, attempt, supervisor_sha):
    """R4 E, under the campaign lock and before the frozen campaign starts: record the reconciled COMMIT in the ledger
    with its proof (create-once, via TEMP).  The frozen run_unit then reuses it; it is never re-executed."""
    key = proof['key']
    require(sha_file(root / 'COMMITS' / (key + '.json')) == proof['commit_file_sha256'], 'RECONCILE_COMMIT_CHANGED:' + key)
    entry = {'schema': LEDGER_SCHEMA, 'run_id': root.name, 'key': key, 'commit_file_sha256': proof['commit_file_sha256'],
             'attempt': proof['attempt'], 'supervisor_sha256': supervisor_sha, 'campaign_pid': proof['campaign_pid'],
             'basis': RECONCILED_BASIS, 'reconciled_by_attempt': attempt, 'proof': proof,
             'observed_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    target = root / LEDGER_DIR / (key + '.json')
    require(not target.exists(), 'LEDGER_ENTRY_EXISTS:' + key)
    temp = root / 'TEMP' / ('LEDGER_' + key + '_' + attempt + '.json')
    write_new(temp, encoded(entry))
    os.replace(temp, target)
    return entry
'''
sub("    return {k: entries[k]['attempt'] for k in sorted(entries)}\n\n\ndef resume_precheck(root, local, plan):\n",
    "    return {k: entries[k]['attempt'] for k in sorted(entries)}\n" + NEW_FUNCS + "\n\ndef resume_precheck(root, local, plan):\n")

# R4-6 resume admission: journal declared and present; ledger admission with reconciliation by proof.
sub("            and boot.get('commit_ledger') == LEDGER_DIR, 'RESUME_BOOTSTRAP_BINDING')\n",
    "            and boot.get('commit_ledger') == LEDGER_DIR and boot.get('attempt_journal') == JOURNAL_DIR, 'RESUME_BOOTSTRAP_BINDING')\n")
sub("and (dlab / 'WRITER_EFFECTFUL').is_dir() and (root / LEDGER_DIR).is_dir(), 'RESUME_LAYOUT')\n",
    "and (dlab / 'WRITER_EFFECTFUL').is_dir() and (root / LEDGER_DIR).is_dir()\n"
    "            and (root / JOURNAL_DIR).is_dir(), 'RESUME_LAYOUT')\n")
sub("    attempts = ledger_bound(root, commit_sha)\n",
    "    attempts, reconcile = ledger_admit(root, commit_sha, plan)\n")
sub("            'prior_closure_present': (root / 'FINAL_G5').exists()}\n",
    "            'prior_closure_present': (root / 'FINAL_G5').exists(), 'reconcile': reconcile}\n")

# R4-7 Q: native proof of the census (nested Job), and the reconciliation shown in the admission detail.
sub("        ok('frozen_verify_package_fixed_layout', code_sha == CODE_SHA, str(ext))\n",
    "        ok('frozen_verify_package_fixed_layout', code_sha == CODE_SHA, str(ext))\n"
    "        q['job_census_probe'] = job.nested_census_probe(frozen_native())\n"
    "        ok('job_census_sees_nested_child', q['job_census_probe']['seen_self'] and q['job_census_probe']['seen_nested_child'],\n"
    "           q['job_census_probe'])\n")
sub("               'pending': len(pre['pending']), 'prior_status': pre['prior_status']})\n",
    "               'pending': len(pre['pending']), 'prior_status': pre['prior_status'],\n"
    "               'reconcile': (pre['reconcile'] or {}).get('key')})\n")

# R4-8 E resume: same proof as Q; reconciliation written under the lock, before the campaign; resume receipt.
sub("                    and pre['commit_file_sha256'] == qres.get('commit_file_sha256'), 'RESUME_STATE_CHANGED_SINCE_QUALIFICATION')\n",
    "                    and pre['commit_file_sha256'] == qres.get('commit_file_sha256')\n"
    "                    and pre['reconcile'] == qres.get('reconcile'), 'RESUME_STATE_CHANGED_SINCE_QUALIFICATION')\n")
sub("            result['prior_processes'] = prior_processes_dead(root, frozen_dead())\n",
    "            result['prior_processes'] = prior_processes_dead(root, frozen_dead())\n"
    "            if pre['reconcile']:\n"
    "                result['reconciled'] = ledger_reconcile(root, pre['reconcile'], stamp, result['supervisor_sha256'])\n"
    "                emit('RECONCILIADO=' + pre['reconcile']['key'] + ' (COMMIT duravel sem registro da tentativa '\n"
    "                     + pre['reconcile']['attempt'] + '; dono provado pelo censo do Job deste supervisor; nao sera reexecutado)')\n")
sub("                      'pending': pre['pending'], 'prior_terminal': result['prior_terminal'],\n",
    "                      'pending': pre['pending'], 'prior_terminal': result['prior_terminal'], 'reconciled': pre['reconcile'],\n")

# R4-9 E new run: the journal is declared and created with the ledger.
sub("            (root / LEDGER_DIR).mkdir()\n",
    "            (root / LEDGER_DIR).mkdir()\n"
    "            (root / JOURNAL_DIR).mkdir()\n")
sub("                         'commit_ledger': LEDGER_DIR,\n",
    "                         'commit_ledger': LEDGER_DIR, 'attempt_journal': JOURNAL_DIR,\n")

# R4-10 E campaign: attempt record before the child exists; census on each unit's HEARTBEAT until recorded.
sub("        proc = subprocess.Popen(cmd, cwd=str(root), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)\n"
    "        reused, committed_now, ledger_errors = [], [], []\n",
    "        result['attempt'] = journal_attempt(root, stamp, result['supervisor_sha256'], frozen_native()(os.getpid()), plan)\n"
    "        proc = subprocess.Popen(cmd, cwd=str(root), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)\n"
    "        reused, committed_now, ledger_errors = [], [], []\n"
    "        census_done, census_errors = [], []\n")
sub("                        ledger_errors.append(committed_now[-1] + ':' + type(exc).__name__ + ':' + str(exc))\n"
    "                emit(line)\n",
    "                        ledger_errors.append(committed_now[-1] + ':' + type(exc).__name__ + ':' + str(exc))\n"
    "                elif line.startswith('HEARTBEAT ACTIVE_TEST='):\n"
    "                    key = line.split(' ', 2)[1].split('=', 1)[1]\n"
    "                    if key in plan and key not in census_done:\n"
    "                        try:\n"
    "                            if journal_census(root, stamp, key, job.census(), proc.pid, result['supervisor_sha256'], line):\n"
    "                                census_done.append(key)\n"
    "                        except BaseException as exc:\n"
    "                            census_errors.append(key + ':' + type(exc).__name__ + ':' + str(exc))\n"
    "                emit(line)\n")
sub("        reader.join(60)\n",
    "        reader.join(60)\n"
    "        result['unit_census_recorded'] = list(census_done)\n"
    "        result['unit_census_errors'] = list(census_errors)\n")

# R4-11 (found by the W4 qualification; pre-existing in R3): after an ABRUPT death of a resumed attempt the run root
# still holds the previous attempt's terminal (ENGINEERING_RESULT, R08_RETURN), and R3 classified the crash with it
# (e.g. SAFE_STOP 130).  The frozen main only ends with 0, 3 or 130, always after write_terminal and seal_return.
sub("        require(native.is_file(), 'R08_RETURN_NOT_SEALED')\n",
    "        require(native.is_file(), 'R08_RETURN_NOT_SEALED')\n"
    "        # R4: any other exit is an abrupt death; the terminal on disk is then not this attempt's (resume).\n"
    "        require(code in (0, 3, 130), 'CAMPAIGN_ABRUPT_EXIT_NO_TERMINAL_OF_THIS_ATTEMPT:' + str(code))\n")

data = text.encode('utf-8')
out.write_bytes(data)
print(out.name, hashlib.sha256(data).hexdigest().upper(), len(data), len(text.split('\n')))
