"""Derive RUN_CDT21_G5_V004_R4_20261021.ps1 from the R3 launcher (B68494D2...): only the embedded supervisor changes.

Usage: python -I build_v004_r4_launcher.py <RUN_CDT21_G5_V004_R3_20261021.ps1> <supervisor R4.py> <out.ps1>
Embeds the R4 supervisor (reconciliation of the R3-F01 crash window by proof of provenance) and pins its SHA-256;
header comments name R4.  Parameters, -RetomarRaiz validation, R1 classification, review payload, paths, log rule and
return packaging are byte-identical to R3.
"""
import base64
import hashlib
import sys
from pathlib import Path

R3_SHA = 'B68494D29563702592C867051FC94BDCE72A7A496AF006A691AC8CFB522D6E39'
OLD_SUP = '2765FAAAC4725F5925921E25B93E145D3719EFC686BDFD7511A110440B0A1DAD'
r3, sup, out = map(Path, sys.argv[1:4])
raw = r3.read_bytes()
assert hashlib.sha256(raw).hexdigest().upper() == R3_SHA, 'R3_SHA'
text = raw.decode('ascii').replace('\r\n', '\n')
sup_raw = sup.read_bytes(); new_sup = hashlib.sha256(sup_raw).hexdigest().upper()
b64 = base64.b64encode(sup_raw).decode()
start = text.index("$SupervisorB64 = @'\n") + len("$SupervisorB64 = @'\n")
end = text.index("\n'@", start)
assert hashlib.sha256(base64.b64decode(text[start:end].replace('\n', ''))).hexdigest().upper() == OLD_SUP
text = text[:start] + '\n'.join(b64[i:i + 100] for i in range(0, len(b64), 100)) + text[end:]

EDITS = [
    ("# TICKSTORE CDT21 - LAUNCHER G5 V004 R3: campanha G5 nativa vinculada ao manifesto completo do V004 (decisao da origem 21/10).\n",
     "# TICKSTORE CDT21 - LAUNCHER G5 V004 R4: campanha G5 nativa vinculada ao manifesto completo do V004 (decisao da origem 21/10).\n"
     "# R4 (achado R3-F01 da origem): so o supervisor embutido muda. Um COMMIT duravel cujo registro no livro-razao se perdeu numa\n"
     "# queda (o codigo congelado publica o COMMIT antes de imprimir COMMITTED) e reconciliado na retomada somente com prova de\n"
     "# proveniencia: proxima unidade do plano, dono unico igual ao processo do RESULT.json e listado no censo do Job deste\n"
     "# supervisor na ultima tentativa (diario CDT21_SUPERVISOR_JOURNAL). Sem a prova, a raiz e recusada. A Fase Q prova nativamente\n"
     "# que o censo enxerga um processo num Job aninhado. Uma morte abrupta numa tentativa retomada e BLOCKED (nao SAFE_STOP).\n"),
    ("# byte a byte, mesmo Job kill-on-close, impressao digital de D:\\Base CSV pela vista da entrada (R2); retomada so da mesma campanha (R3).\n",
     "# byte a byte, mesmo Job kill-on-close, impressao digital de D:\\Base CSV pela vista da entrada (R2); retomada so da mesma campanha (R3);\n"
     "# reconciliacao COMMIT->livro-razao so por prova de proveniencia (R4).\n"),
    ('#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\\Users\\silvi\\Downloads\\RUN_CDT21_G5_V004_R3_20261021.ps1" -AutorizoLabD\n',
     '#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\\Users\\silvi\\Downloads\\RUN_CDT21_G5_V004_R4_20261021.ps1" -AutorizoLabD\n'),
    ('#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\\Users\\silvi\\Downloads\\RUN_CDT21_G5_V004_R3_20261021.ps1" -AutorizoLabD -RetomarRaiz "<raiz>"\n',
     '#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\\Users\\silvi\\Downloads\\RUN_CDT21_G5_V004_R4_20261021.ps1" -AutorizoLabD -RetomarRaiz "<raiz>"\n'),
    # A4 (missao consolidada): a prova nativa volta diretamente ao Opus; a origem recebe o fechamento consolidado.
    ("        Log ('Devolva este resultado ao Opus/ChatGPT, projeto Base de Dados CSV / Tickstore, conversa ' + $Thread + '. Anexe as evidencias e cole esta resposta.')\n"
     "        Log ('RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=' + $Thread)\n",
     "        Log ('Devolva este retorno DIRETAMENTE ao Opus (Claude Code), na mesma conversa de engenharia CDT21: anexe o arquivo ENVIE_O_RETORNO acima e cole este log.')\n"
     "        Log ('A origem (ChatGPT, projeto Base de Dados CSV / Tickstore, conversa ' + $Thread + ') recebe do Opus o fechamento consolidado.')\n"
     "        Log ('RESULT_RETURN_TO=Opus | ORIGIN=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=' + $Thread)\n"),
    ("$SupervisorSha = '" + OLD_SUP + "'\n", "$SupervisorSha = '" + new_sup + "'\n"),
]
for old, new in EDITS:
    assert text.count(old) == 1, ('ANCHOR', old[:90])
    text = text.replace(old, new)
data = text.replace('\n', '\r\n').encode('ascii')
out.write_bytes(data)
print(out.name, hashlib.sha256(data).hexdigest().upper(), len(data), 'SUPERVISOR', new_sup)
