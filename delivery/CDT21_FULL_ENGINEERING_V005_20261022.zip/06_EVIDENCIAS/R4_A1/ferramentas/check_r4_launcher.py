"""Static check of RUN_CDT21_G5_V004_R4_20261021.ps1 against its R3 parent (delta-only; no re-run of passed tests).

Usage: python -I check_r4_launcher.py <R3.ps1> <R4.ps1> <supervisor R4.py> <pwsh> <out.json>
Proves: ASCII + CRLF; PowerShell parser 0 errors; embedded payload == R4 supervisor build; pin == payload; outside the
payload only the header comments, the pin and the return-routing lines differ from R3; the five fragments exercised by
the R3 launcher qualification (8/8) are byte-identical, so that qualification applies to R4 unchanged.
"""
import base64
import difflib
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

r3p, r4p, supp, pwsh, out = map(Path, sys.argv[1:6])
r3, r4, sup = r3p.read_bytes(), r4p.read_bytes(), supp.read_bytes()
H = lambda b: hashlib.sha256(b).hexdigest().upper()


def split(raw):
    t = raw.decode('ascii').split('\r\n')
    i = t.index("$SupervisorB64 = @'") + 1; j = t.index("'@", i)
    return t[:i], t[i:j], t[j:]


h3, p3, t3 = split(r3); h4, p4, t4 = split(r4)
payload = base64.b64decode(''.join(p4))
pin = re.search(r"\$SupervisorSha = '([0-9A-F]{64})'", r4.decode('ascii')).group(1)
outside3, outside4 = h3 + t3, h4 + t4
diff = [l for l in difflib.unified_diff(outside3, outside4, lineterm='', n=0) if not l.startswith(('---', '+++', '@@'))]
removed = [l[1:] for l in diff if l.startswith('-')]; added = [l[1:] for l in diff if l.startswith('+')]
allowed = lambda l: l.startswith('#') or l.startswith("$SupervisorSha = '") or l.startswith("        Log ('Devolva") \
    or l.startswith("        Log ('RESULT_RETURN_TO=") or l.startswith("        Log ('A origem (ChatGPT")
lines4 = r4.decode('ascii').split('\r\n'); lines3 = r3.decode('ascii').split('\r\n')
frag_prefix = ['param([switch]$AutorizoLabD', '        $si.Arguments = ', '            & $Python -I -B $Supervisor --qualify-only',
               '                & $Python -I -B $Supervisor --package $Package']
frags = {p: ([l for l in lines3 if l.startswith(p)], [l for l in lines4 if l.startswith(p)]) for p in frag_prefix}
v3 = lines3[lines3.index('    $ResumeArgs = @()'):][:12]; v4 = lines4[lines4.index('    $ResumeArgs = @()'):][:12]
ps = ('$e=$null;$t=$null;[void][System.Management.Automation.Language.Parser]::ParseFile($args[0],[ref]$t,[ref]$e);'
      'Write-Output $e.Count')
psf = out.with_name('parse_check.ps1')
psf.write_text('param([string]$Path)\n$e=$null;$t=$null;[void][System.Management.Automation.Language.Parser]::ParseFile($Path,[ref]$t,[ref]$e)\n'
               'Write-Output $e.Count\nforeach ($x in $e) { Write-Output $x.Message }\n')
cp = subprocess.run([str(pwsh), '-NoProfile', '-File', str(psf), str(r4p.resolve())], capture_output=True, text=True, timeout=120)
doc = {'schema': 'CDT21_G5_V004_R4_LAUNCHER_STATIC_CHECK_V001', 'sha256': H(r4), 'bytes': len(r4), 'parent_r3_sha256': H(r3),
       'ascii_only': all(b < 128 for b in r4), 'crlf_only': r4.count(b'\n') == r4.count(b'\r\n'),
       'parser_errors': cp.stdout.strip().split('\n')[0], 'parser_messages': cp.stdout.strip().split('\n')[1:], 'supervisor_payload_sha256': H(payload),
       'supervisor_payload_equals_build': payload == sup, 'supervisor_pin_equals_payload': pin == H(payload),
       'removed_lines_outside_payload': removed, 'added_lines_outside_payload': added,
       'only_header_pin_and_routing_changed': all(allowed(l) for l in removed + added),
       'r3_launcher_qualification_fragments_identical': all(a == b and len(a) == 1 for a, b in frags.values()) and v3 == v4,
       'destructive_cmdlets_absent': not re.search(r'(?i)\b(Remove-Item|Format-Volume|Clear-Content|rd /s|del /f)\b', '\r\n'.join(outside4))}
doc['pass'] = all([doc['ascii_only'], doc['crlf_only'], doc['parser_errors'] == '0', doc['supervisor_payload_equals_build'],
                   doc['supervisor_pin_equals_payload'], doc['only_header_pin_and_routing_changed'],
                   doc['r3_launcher_qualification_fragments_identical'], doc['destructive_cmdlets_absent']])
Path(out).write_text(json.dumps(doc, indent=1), encoding='utf-8')
print('R4_LAUNCHER_STATIC', doc['pass'], doc['sha256'], 'parser_errors=' + doc['parser_errors'], len(removed), len(added))
