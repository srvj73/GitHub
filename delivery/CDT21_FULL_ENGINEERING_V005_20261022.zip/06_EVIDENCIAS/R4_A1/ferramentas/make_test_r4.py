"""Derive the R4 harness test_r4_reconcile.py from the R3 harness test_r3_resume.py by counted replacements.

The R3 scenarios (S1-S5, N01-N16) are kept byte-for-byte as the regression of the paths R4 touches (E bootstrap,
pump, resume admission); R4 adds the crash-window scenarios W1-W4, the negative controls NR01-NR13, the child-process
supervisor mode (whole-tree crash) and the R4 mutants.
Usage: python -I make_test_r4.py <test_r3_resume.py> <test_r4_additions.py> <out.py>
"""
import hashlib
import sys
from pathlib import Path

R3_HARNESS_SHA = None  # recorded in the output header below
src, add, out = map(Path, sys.argv[1:4])
raw = src.read_bytes(); text = raw.decode('utf-8')
r3sha = hashlib.sha256(raw).hexdigest().upper()


def sub(old, new, count=1):
    global text
    assert text.count(old) == count, ('ANCHOR', old[:100])
    text = text.replace(old, new)


sub('"""End-to-end qualification of the G5 V004 supervisor R3 resume (Linux; real supervisor main()/qualify_main()).\n\n'
    'Usage: python -I test_r3_resume.py <R3.py> <V004.zip> <REVIEW_V004.json> <v003_root_src> <stub_campaign.py> <work> <out.json> [--mutant M]\n',
    '"""End-to-end qualification of the G5 V004 supervisor R4 (Linux; real supervisor main()/qualify_main()).\n\n'
    'Derived from the R3 harness (SHA-256 ' + r3sha + ') by make_test_r4.py: the R3 scenarios are kept as regression.\n'
    'Usage: python -I test_r4_reconcile.py <R4.py> <V004.zip> <REVIEW_V004.json> <v003_root_src> <stub_campaign_r4.py> <work> <out.json>\n'
    '       [--mutant M] | [--child-e <json>]   (child mode: one E phase in its own process, for whole-tree crashes)\n'
    'R4 stand-ins in addition to R3: SupervisorJob.census / nested_census_probe over the supervisor\'s own process tree\n'
    '(/proc), frozen_native = (pid, start time) from /proc; the unit child is a real descendant process.\n')
sub("MUTANT = sys.argv[9] if len(sys.argv) > 9 and sys.argv[8] == '--mutant' else None\n",
    "MUTANT = sys.argv[9] if len(sys.argv) > 9 and sys.argv[8] == '--mutant' else None\n"
    "CHILD = sys.argv[9] if len(sys.argv) > 9 and sys.argv[8] == '--child-e' else None\n"
    "if CHILD:\n"
    "    MUTANT = json.loads(CHILD).get('mutant')  # the child supervisor runs the same (mutated) bytes\n")
# R4 mutant set (each a list of counted substitutions on the R4 source).
i = text.index('MUTANTS = {\n'); j = text.index('}\n', text.index("'M7_NO_PRIOR_PROCESS_CHECK'")) + 2
text = text[:i] + '''MUTANTS = {
    'M1R_NO_LEDGER_ADMISSION': [("    attempts, reconcile = ledger_admit(root, commit_sha, plan)\\n", "    attempts, reconcile = {}, None\\n")],
    'MR1_NO_OWNER_IN_CENSUS_CHECK': [("    need(ident in seen, 'OWNER_NOT_IN_SUPERVISOR_CENSUS')\\n", "    pass\\n")],
    'MR2_ACCEPT_MORE_THAN_ONE_UNLEDGERED': [("    require(len(pending) == 1, 'COMMIT_NOT_LEDGERED:' + ','.join(pending) + ':RECONCILE_MORE_THAN_ONE')\\n", "    pass\\n")],
    'MR3_NO_NEXT_PLAN_SLOT_CHECK': [("    require(key == plan[n], 'COMMIT_NOT_LEDGERED:' + key + ':RECONCILE_NOT_NEXT_PLAN_KEY')\\n", "    pass\\n")],
    'MR4_NO_RESULT_PROCESS_CHECK': [("         and (proc.get('pid'), proc.get('creation_filetime')) == ident, 'RESULT_PROCESS_NE_OWNER')\\n",
                                     "         or True, 'RESULT_PROCESS_NE_OWNER')\\n")],
    'MR5_CENSUS_OF_ANY_ATTEMPT': [("    path = journal / ('CENSUS_' + last['attempt'] + '_' + key + '.json')\\n",
                                   "    path = (sorted(journal.glob('CENSUS_*_' + key + '.json')) or [journal / 'NONE'])[0]\\n"),
                                  ("         and census.get('attempt') == last['attempt'] and census.get('key') == key\\n",
                                   "         and census.get('key') == key\\n")],
    'MR6_OWNER_MAY_BE_CAMPAIGN_OR_SUPERVISOR': [("         and ident[0] not in (census.get('campaign_pid'), census.get('supervisor_pid')), 'OWNER_IS_SUPERVISOR_OR_CAMPAIGN')\\n",
                                                 "         or True, 'OWNER_IS_SUPERVISOR_OR_CAMPAIGN')\\n")],
    'MR7_NO_CENSUS_IN_PUMP': [("                    if key in plan and key not in census_done:\\n", "                    if False:\\n")],
    'MR8_RECONCILIATION_NOT_WRITTEN': [("                result['reconciled'] = ledger_reconcile(root, pre['reconcile'], stamp, result['supervisor_sha256'])\\n",
                                        "                result['reconciled'] = pre['reconcile']\\n")],
    'MR10_STALE_TERMINAL_CLASSIFIES_ABRUPT_EXIT': [("        require(code in (0, 3, 130), 'CAMPAIGN_ABRUPT_EXIT_NO_TERMINAL_OF_THIS_ATTEMPT:' + str(code))\\n", "        pass\\n")],
    'MR9_NO_ATTEMPT_RECORD_CHECK': [("         and isinstance(start, list) and set(start) <= set(ledgered) and key not in start, 'ATTEMPT_RECORD')\\n",
                                     "         or True, 'ATTEMPT_RECORD')\\n")],
}
''' + text[j:]
sub("for o, n in SUBS + ([MUTANTS[MUTANT]] if MUTANT else []):\n", "for o, n in SUBS + (MUTANTS[MUTANT] if MUTANT else []):\n")
sub("S = types.ModuleType('sup_r3'); S.__file__ = str(sup_p)\n", "S = types.ModuleType('sup_r4'); S.__file__ = str(sup_p)\n")
sub("S.SupervisorJob = type('Job', (), {'active': lambda self: 1})\n",
    "S.SupervisorJob = LinuxJob\nS.frozen_native = lambda: linux_ident\n")
# R4 stand-ins, defined before the supervisor module is built.
sub("sys.modules['PRE_G06_COMPLETENESS'] = FakeCompleteness('PRE_G06_COMPLETENESS')\n",
    "sys.modules['PRE_G06_COMPLETENESS'] = FakeCompleteness('PRE_G06_COMPLETENESS')\n"
    "\n\n"
    "def proc_table():\n"
    "    t = {}\n"
    "    for d in os.listdir('/proc'):\n"
    "        if d.isdigit():\n"
    "            try:\n"
    "                s = Path('/proc/' + d + '/stat').read_text()\n"
    "            except OSError:\n"
    "                continue\n"
    "            f = s[s.rindex(')') + 2:].split()\n"
    "            t[int(d)] = (f[0], int(f[1]), int(f[19]))  # state, ppid, start time since boot\n"
    "    return t\n"
    "\n\n"
    "def linux_ident(pid):\n"
    "    \"\"\"Stand-in of the frozen R.native_process: (pid, creation) where creation = start time since boot.\"\"\"\n"
    "    try:\n"
    "        s = Path('/proc/%d/stat' % pid).read_text()\n"
    "    except OSError:\n"
    "        return {'pid': pid, 'state': 'ABSENT'}\n"
    "    f = s[s.rindex(')') + 2:].split()\n"
    "    return {'pid': pid, 'creation_filetime': int(f[19]), 'state': 'EXITED' if f[0] == 'Z' else 'LIVE'}\n"
    "\n\n"
    "class LinuxJob:\n"
    "    \"\"\"Stand-in of the kill-on-close SupervisorJob: the Job is this process and its live descendants.\"\"\"\n"
    "    def active(self):\n"
    "        return 1\n"
    "\n"
    "    def census(self):\n"
    "        t = proc_table(); me = os.getpid(); out = []\n"
    "        for pid, (st, ppid, start) in t.items():\n"
    "            q = pid\n"
    "            while q and q != me:\n"
    "                q = t.get(q, ('', 0, 0))[1]\n"
    "            if q == me and st != 'Z':\n"
    "                out.append({'pid': pid, 'creation_filetime': start})\n"
    "        return sorted(out, key=lambda p: p['pid'])\n"
    "\n"
    "    def nested_census_probe(self, native):\n"
    "        child = REAL_POPEN([sys.executable, '-I', '-S', '-c', 'import time; time.sleep(60)'])\n"
    "        try:\n"
    "            mine, theirs = native(os.getpid()), native(child.pid)\n"
    "            seen = {(p['pid'], p['creation_filetime']) for p in self.census()}\n"
    "            return {'self': [mine['pid'], mine['creation_filetime']], 'nested_child': [theirs['pid'], theirs['creation_filetime']],\n"
    "                    'census_size': len(seen), 'seen_self': (mine['pid'], mine['creation_filetime']) in seen,\n"
    "                    'seen_nested_child': (theirs['pid'], theirs['creation_filetime']) in seen, 'stand_in': 'LINUX_PROC_TREE'}\n"
    "        finally:\n"
    "            child.kill(); child.wait(30)\n")
# A failing case recorded by safe() names the scenario tag, not only the function.
sub("        results.append({'case': fn.__name__, 'pass': False, 'detail': 'EXCEPTION ' + type(exc).__name__ + ':' + str(exc)[:300]})\n",
    "        results.append({'case': fn.__name__ + (':' + a[0] if a and isinstance(a[0], str) else ''), 'pass': False,\n"
    "                        'detail': 'EXCEPTION ' + type(exc).__name__ + ':' + str(exc)[:300]})\n")
# Disk: keep only the running scenario's work tree (each holds several byte-exact extractions of the 17 MB package).
sub("def env(tag):\n    w = work / tag\n    if w.exists():\n        shutil.rmtree(w)\n",
    "def env(tag):\n    w = work / tag\n    for old in ([p for p in work.iterdir() if p.is_dir()] if work.exists() else []):\n"
    "        shutil.rmtree(old)  # previous scenario: its verdict is already recorded in results\n")
# Tail: child mode, R4 scenarios, R4 output document.
sub("run_all()\ndoc = {'schema': 'CDT21_G5_V004_R3_RESUME_QUALIFICATION_V001', 'mutant': MUTANT, 'supervisor_sha256': SUP_SHA,\n",
    add.read_text(encoding='utf-8') +
    "doc = {'schema': 'CDT21_G5_V004_R4_RECONCILE_QUALIFICATION_V001', 'mutant': MUTANT, 'supervisor_sha256': SUP_SHA,\n"
    "       'r3_harness_sha256': '" + r3sha + "',\n")
sub("       'R.dead census', 'native_b2d', 'new-unit execution (stub_campaign.py; reuse via frozen run_unit)', 'PRE_G06_COMPLETENESS.close'],\n",
    "       'R.dead census', 'native_b2d', 'new-unit execution (stub_campaign_r4.py; reuse via frozen run_unit)', 'PRE_G06_COMPLETENESS.close',\n"
    "       'SupervisorJob.census/nested_census_probe (process tree via /proc)', 'frozen_native (pid, start time via /proc)'],\n")
sub("print('R3_RESUME', MUTANT or 'ORIGINAL', doc['passed'], '/', doc['total'], [c['case'] for c in results if not c['pass']])",
    "print('R4_RECONCILE', MUTANT or 'ORIGINAL', doc['passed'], '/', doc['total'], [c['case'] for c in results if not c['pass']])")
data = text.encode('utf-8')
out.write_bytes(data)
print(out.name, hashlib.sha256(data).hexdigest().upper(), len(data))
