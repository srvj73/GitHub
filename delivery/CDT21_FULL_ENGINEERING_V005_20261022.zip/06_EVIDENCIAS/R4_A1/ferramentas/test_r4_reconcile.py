"""End-to-end qualification of the G5 V004 supervisor R4 (Linux; real supervisor main()/qualify_main()).

Derived from the R3 harness (SHA-256 3D612C1259756A50F203D8AD4D07BEE1E2D75A90DC5BAF24053A3C49CF25BA07) by make_test_r4.py: the R3 scenarios are kept as regression.
Usage: python -I test_r4_reconcile.py <R4.py> <V004.zip> <REVIEW_V004.json> <v003_root_src> <stub_campaign_r4.py> <work> <out.json>
       [--mutant M] | [--child-e <json>]   (child mode: one E phase in its own process, for whole-tree crashes)
R4 stand-ins in addition to R3: SupervisorJob.census / nested_census_probe over the supervisor's own process tree
(/proc), frozen_native = (pid, start time) from /proc; the unit child is a real descendant process.
Real: the R3 supervisor code paths (Q and E, new run and resume), extraction, frozen verify_package and plan, the frozen
reuse path of run_unit, write_terminal and seal_return, digests, ledger, preservation, return packaging.
Stand-ins (Windows-only or native-only, recorded in the output): the platform guard (2 source substitutions),
IsUserAnAdmin, volume_filesystem, the kill-on-close Job, msvcrt byte-range locks (flock), the frozen R.dead census,
the native b2d runner (already proven natively 29/29 + R1 negative), new-unit execution (stub_campaign.py) and the
five-part closure PRE_G06_COMPLETENESS.close (fake that retains a prior FINAL_G5 exactly like the frozen one).
"""
import ctypes
import fcntl
import hashlib
import importlib
import json
import os
import shutil
import subprocess
import sys
import time
import types
import uuid
from pathlib import Path

sup_p, pkg, review, v003, stub, work, out = map(Path, sys.argv[1:8])
MUTANT = sys.argv[9] if len(sys.argv) > 9 and sys.argv[8] == '--mutant' else None
CHILD = sys.argv[9] if len(sys.argv) > 9 and sys.argv[8] == '--child-e' else None
if CHILD:
    MUTANT = json.loads(CHILD).get('mutant')  # the child supervisor runs the same (mutated) bytes
work = work.resolve()
H = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
results = []

SUBS = [("        require(os.name == 'nt', 'WINDOWS_REQUIRED')\n", "        pass  # TEST: platform guard (Linux)\n"),
        ("ok('windows_python_admin', os.name == 'nt' and sys.version_info[:2] == (3, 14),",
         "ok('windows_python_admin', sys.version_info[:2] == (3, 14),")]
MUTANTS = {
    'M1R_NO_LEDGER_ADMISSION': [("    attempts, reconcile = ledger_admit(root, commit_sha, plan)\n", "    attempts, reconcile = {}, None\n")],
    'MR1_NO_OWNER_IN_CENSUS_CHECK': [("    need(ident in seen, 'OWNER_NOT_IN_SUPERVISOR_CENSUS')\n", "    pass\n")],
    'MR2_ACCEPT_MORE_THAN_ONE_UNLEDGERED': [("    require(len(pending) == 1, 'COMMIT_NOT_LEDGERED:' + ','.join(pending) + ':RECONCILE_MORE_THAN_ONE')\n", "    pass\n")],
    'MR3_NO_NEXT_PLAN_SLOT_CHECK': [("    require(key == plan[n], 'COMMIT_NOT_LEDGERED:' + key + ':RECONCILE_NOT_NEXT_PLAN_KEY')\n", "    pass\n")],
    'MR4_NO_RESULT_PROCESS_CHECK': [("         and (proc.get('pid'), proc.get('creation_filetime')) == ident, 'RESULT_PROCESS_NE_OWNER')\n",
                                     "         or True, 'RESULT_PROCESS_NE_OWNER')\n")],
    'MR5_CENSUS_OF_ANY_ATTEMPT': [("    path = journal / ('CENSUS_' + last['attempt'] + '_' + key + '.json')\n",
                                   "    path = (sorted(journal.glob('CENSUS_*_' + key + '.json')) or [journal / 'NONE'])[0]\n"),
                                  ("         and census.get('attempt') == last['attempt'] and census.get('key') == key\n",
                                   "         and census.get('key') == key\n")],
    'MR6_OWNER_MAY_BE_CAMPAIGN_OR_SUPERVISOR': [("         and ident[0] not in (census.get('campaign_pid'), census.get('supervisor_pid')), 'OWNER_IS_SUPERVISOR_OR_CAMPAIGN')\n",
                                                 "         or True, 'OWNER_IS_SUPERVISOR_OR_CAMPAIGN')\n")],
    'MR7_NO_CENSUS_IN_PUMP': [("                    if key in plan and key not in census_done:\n", "                    if False:\n")],
    'MR8_RECONCILIATION_NOT_WRITTEN': [("                result['reconciled'] = ledger_reconcile(root, pre['reconcile'], stamp, result['supervisor_sha256'])\n",
                                        "                result['reconciled'] = pre['reconcile']\n")],
    'MR10_STALE_TERMINAL_CLASSIFIES_ABRUPT_EXIT': [("        require(code in (0, 3, 130), 'CAMPAIGN_ABRUPT_EXIT_NO_TERMINAL_OF_THIS_ATTEMPT:' + str(code))\n", "        pass\n")],
    'MR9_NO_ATTEMPT_RECORD_CHECK': [("         and isinstance(start, list) and set(start) <= set(ledgered) and key not in start, 'ATTEMPT_RECORD')\n",
                                     "         or True, 'ATTEMPT_RECORD')\n")],
}
src = sup_p.read_text(encoding='utf-8')
for o, n in SUBS + (MUTANTS[MUTANT] if MUTANT else []):
    assert src.count(o) == 1, o[:80]
    src = src.replace(o, n)
if MUTANT == 'M7_NO_PRIOR_PROCESS_CHECK':
    o = "            q['prior_processes'] = prior_processes_dead(Path(pre['run_root']), frozen_dead())\n"
    assert src.count(o) == 1; src = src.replace(o, "            q['prior_processes'] = []\n")

# ------------------------------------------------------------------ Windows-only stand-ins
ctypes.WinDLL = lambda *a, **k: types.SimpleNamespace(IsUserAnAdmin=lambda: 1)
ms = types.ModuleType('msvcrt'); ms.LK_NBLCK = 2; ms.LK_UNLCK = 0
def _locking(fd, mode, n):
    fcntl.flock(fd, fcntl.LOCK_UN if mode == ms.LK_UNLCK else fcntl.LOCK_EX | fcntl.LOCK_NB)
ms.locking = _locking; sys.modules['msvcrt'] = ms
DEAD = {'fn': lambda ident: dict(ident, observation='ABSENT')}
REAL_POPEN = subprocess.Popen
HOOK = {'campaign_calls': 0}


class HookPopen(REAL_POPEN):
    def __init__(self, cmd, *a, **kw):
        if isinstance(cmd, list) and len(cmd) > 3 and str(cmd[3]).replace('\\', '/').endswith('g5proof/PRE_G06_CAMPAIGN.py'):
            env = dict(kw.get('env') or os.environ); env['STUB_REAL_CAMPAIGN'] = str(cmd[3]); kw['env'] = env
            cmd = [cmd[0], '-I', '-B', str(stub)] + list(cmd[4:]); HOOK['campaign_calls'] += 1
        super().__init__(cmd, *a, **kw)


subprocess.Popen = HookPopen


class FakeCompleteness(types.ModuleType):
    """Stand-in for the frozen five-part closure; retains a prior FINAL_G5 like PRE_G06_COMPLETENESS does."""
    @property
    def __file__(self):
        cands = sorted(Path(os.environ['LOCALAPPDATA'], 'CDT21_G5_V004').glob('CURRENT_G5_DELTA_2*/EXTRACTED'),
                       key=lambda p: p.stat().st_mtime_ns)
        return str(cands[-1] / 'implementation_v001/candidate/g5proof/PRE_G06_COMPLETENESS.py')

    def close(self, final_zip, native_zip, review_path, root):
        root = Path(root); out_ = root / 'FINAL_G5'
        if out_.exists():
            prev = root / 'INTERRUPTED_ATTEMPTS' / ('FINAL_G5_' + uuid.uuid4().hex)
            prev.parent.mkdir(parents=True, exist_ok=True); shutil.move(str(out_), str(prev))
        (out_ / 'INPUTS').mkdir(parents=True)
        shutil.copyfile(final_zip, out_ / 'INPUTS' / 'FINAL_PACKAGE.zip'); shutil.copyfile(native_zip, out_ / 'INPUTS' / 'NATIVE_RETURN.zip')
        if os.environ.get('STUB_CLOSE_FAIL') == '1':
            raise RuntimeError('STUB_CLOSURE_INTERRUPTED')
        parts = {}
        for name in ('ENGINEERING', 'STAGE', 'FULL_CANDIDATE', 'NEGATIVE', 'TRANSPORT'):
            p = out_ / (name + '.json'); p.write_text(json.dumps({'part': name, 'status': 'PASS'}))
            parts[name] = {'status': 'PASS', 'sha256': H(p), 'path': str(p)}
        (out_ / 'ENGINEERING_COMPLETENESS.json').write_text(json.dumps({'code_manifest_sha256': S.CODE_SHA, 'final_package_sha256': S.PACKAGE_SHA,
                                                                       'five_part_completeness': parts}))
        (out_ / 'FINAL_ENGINEERING_STATUS.json').write_text('{"status":"PASS_STUB"}')
        (out_ / 'FOUR_PRE_B06_FINDINGS.json').write_text('{"status":"PASS_STUB"}')
        return {'engineering_five_part_completeness': 'PASS', 'four_pre_b06_findings': 'PASS_NATIVE_REGRESSION',
                'independent_b06_audit': False, 'status': 'PASS_STUB_CLOSURE'}


sys.modules['PRE_G06_COMPLETENESS'] = FakeCompleteness('PRE_G06_COMPLETENESS')


def proc_table():
    t = {}
    for d in os.listdir('/proc'):
        if d.isdigit():
            try:
                s = Path('/proc/' + d + '/stat').read_text()
            except OSError:
                continue
            f = s[s.rindex(')') + 2:].split()
            t[int(d)] = (f[0], int(f[1]), int(f[19]))  # state, ppid, start time since boot
    return t


def linux_ident(pid):
    """Stand-in of the frozen R.native_process: (pid, creation) where creation = start time since boot."""
    try:
        s = Path('/proc/%d/stat' % pid).read_text()
    except OSError:
        return {'pid': pid, 'state': 'ABSENT'}
    f = s[s.rindex(')') + 2:].split()
    return {'pid': pid, 'creation_filetime': int(f[19]), 'state': 'EXITED' if f[0] == 'Z' else 'LIVE'}


class LinuxJob:
    """Stand-in of the kill-on-close SupervisorJob: the Job is this process and its live descendants."""
    def active(self):
        return 1

    def census(self):
        t = proc_table(); me = os.getpid(); out = []
        for pid, (st, ppid, start) in t.items():
            q = pid
            while q and q != me:
                q = t.get(q, ('', 0, 0))[1]
            if q == me and st != 'Z':
                out.append({'pid': pid, 'creation_filetime': start})
        return sorted(out, key=lambda p: p['pid'])

    def nested_census_probe(self, native):
        child = REAL_POPEN([sys.executable, '-I', '-S', '-c', 'import time; time.sleep(60)'])
        try:
            mine, theirs = native(os.getpid()), native(child.pid)
            seen = {(p['pid'], p['creation_filetime']) for p in self.census()}
            return {'self': [mine['pid'], mine['creation_filetime']], 'nested_child': [theirs['pid'], theirs['creation_filetime']],
                    'census_size': len(seen), 'seen_self': (mine['pid'], mine['creation_filetime']) in seen,
                    'seen_nested_child': (theirs['pid'], theirs['creation_filetime']) in seen, 'stand_in': 'LINUX_PROC_TREE'}
        finally:
            child.kill(); child.wait(30)

S = types.ModuleType('sup_r4'); S.__file__ = str(sup_p)
exec(compile(src, str(sup_p), 'exec'), S.__dict__)
S.volume_filesystem = lambda d: 'NTFS'
S.SupervisorJob = LinuxJob
S.frozen_native = lambda: linux_ident
S.frozen_dead = lambda: (lambda ident: DEAD['fn'](ident))


def fake_b2d(extracted, temp, log_path):
    neg = 'QUAL_NEG_' in str(extracted)
    Path(log_path).write_text('NATIVE b2d stand-in (proven natively)\n')
    return {'exit': 1 if neg else 0, 'ran': 29, 'ok': not neg, 'contract_not_met': 58 if neg else 0, 'log': str(log_path), 'log_sha256': H(log_path)}


S.native_b2d = fake_b2d
SUP_SHA = H(sup_p)


# ------------------------------------------------------------------ environment
def env(tag):
    w = work / tag
    for old in ([p for p in work.iterdir() if p.is_dir()] if work.exists() else []):
        shutil.rmtree(old)  # previous scenario: its verdict is already recorded in results
    local = w / 'LOCAL'; (local / 'CDT20_R08').mkdir(parents=True)
    shutil.copytree(v003, local / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791', symlinks=True)
    (local / 'CDT20_R08' / 'CURRENT_09AA56B867476005.json').write_text('x' * 179)
    dl = w / 'D:\\TICKSTORE_CDT19_PRE_G06_LABS' / 'R08_Q1_20261020210605_856fea523791'
    shutil.copytree(v003 / 'COMMITS', dl / 'WRITER_EFFECTFUL')
    shutil.copyfile(v003 / 'OWNER.json', dl / 'OWNER.json')
    prod = w / 'D:\\Base CSV'; (prod / 'Scripts').mkdir(parents=True); (prod / 'a.csv').write_text('1')
    (w / 'D:\\').mkdir(); (w / '\\').mkdir()
    os.chdir(w); os.environ['LOCALAPPDATA'] = str(local)
    S.D_LABS = str(w / 'D:\\TICKSTORE_CDT19_PRE_G06_LABS'); S.PRODUCTION = str(w / 'D:\\Base CSV')  # absolute, as on Windows
    for k in [k for k in os.environ if k.startswith('STUB_')]:
        del os.environ[k]
    return w, local


BASE_PATH = list(sys.path)


def fresh_process():
    """Q and E are separate python processes under the launcher: drop modules imported from extractions."""
    for name, m in list(sys.modules.items()):
        f = getattr(type(m), '__file__', None) if isinstance(m, FakeCompleteness) else getattr(m, '__file__', None)
        if isinstance(f, str) and f.startswith(str(work)) and not isinstance(m, FakeCompleteness):
            del sys.modules[name]
    sys.path[:] = BASE_PATH
    S._ROWS.clear()


def run_main(args):
    fresh_process()
    return S.main(args)


def launch(w, resume='', stub_env=None, qual=None, skip_q=False):
    """One launcher run: same log dir and stage for Q and E, like RUN_CDT21_G5_V004_R3."""
    n = len(list(w.glob('LOG_*')))
    log = w / ('LOG_%02d' % n); stage = w / ('STAGE_%02d' % n); log.mkdir(); stage.mkdir()
    base = ['--package', str(pkg), '--review', str(review), '--log-dir', str(log), '--stage', str(stage)]
    rargs = ['--resume-root', resume] if resume else []
    qcode = None
    if not skip_q:
        qcode = run_main(base + ['--qualify-only'] + rargs)
    qfile = qual or (log / 'QUALIFICATION_RESULT.json')
    q = json.loads(Path(qfile).read_text()) if Path(qfile).exists() else {}
    if qcode not in (None, 0):
        return {'q_code': qcode, 'q': q, 'e_code': None, 'e': {}, 'log': log}
    for k in [k for k in os.environ if k.startswith('STUB_')]:
        del os.environ[k]
    os.environ.update(stub_env or {})
    ecode = run_main(base + ['--require-qualification', str(qfile)] + rargs)
    e = json.loads((log / 'SUPERVISOR_RESULT.json').read_text())
    return {'q_code': qcode, 'q': q, 'e_code': ecode, 'e': e, 'log': log}


def check(name, ok, detail=''):
    results.append({'case': name, 'pass': bool(ok), 'detail': detail})


def blockers(r):
    return (r['q'].get('blockers') or []) + (r['e'].get('blockers') or [])


def has(r, code):
    return any(code in b for b in blockers(r))


def ledger(root):
    return {p.stem: json.loads(p.read_text()) for p in sorted((Path(root) / 'CDT21_SUPERVISOR_LEDGER').glob('*.json'))}


def own_root(r):
    return r['e'].get('run_root') or r['q'].get('resume_root')


def safe(fn, *a):
    try:
        return fn(*a)
    except Exception as exc:  # a mutant may break the harness flow; that is a failing case, not a crash
        results.append({'case': fn.__name__ + (':' + a[0] if a and isinstance(a[0], str) else ''), 'pass': False,
                        'detail': 'EXCEPTION ' + type(exc).__name__ + ':' + str(exc)[:300]})


# ------------------------------------------------------------------ scenarios
def S1_new_run_unchanged():
    w, local = env('S1')
    r = launch(w)
    root = own_root(r)
    check('S1_new_run_pass_38_new_0_reused_ledger_38', r['q_code'] == 0 and r['e_code'] == 0
          and r['e']['status'] == 'PASS_NATIVE_V004_G5_TECHNICAL_FIVE_PART' and r['e']['mode'] == 'NEW_RUN_V004'
          and len(r['e']['newly_committed_units']) == 38 and r['e']['reused_committed_units'] == []
          and len(ledger(root)) == 38 and r['e']['foreign_roots']['added'] == ['d_lab/' + Path(root).name, 'run/' + Path(root).name],
          {'status': r['e'].get('status'), 'blockers': blockers(r)})


def stopped_campaign(tag, **stub):
    w, local = env(tag)
    r1 = launch(w, stub_env={k: str(v) for k, v in stub.items()})
    return w, local, r1, own_root(r1)


def S2_safe_stop_then_resume():
    w, local, r1, root = stopped_campaign('S2', STUB_STOP_AFTER=5)
    log_text = (r1['log'] / 'SUPERVISOR_RESULT.json').read_text()
    check('S2a_safe_stop_leaves_5_ledgered_commits', r1['e_code'] == 130 and r1['e']['status'] == 'SAFE_STOP'
          and sorted(ledger(root)) == sorted(p.stem for p in (Path(root) / 'COMMITS').glob('*.json')) and len(ledger(root)) == 5,
          {'code': r1['e_code'], 'status': r1['e'].get('status'), 'ledger': len(ledger(root))})
    r2 = launch(w, resume=root)
    pre = r2['q'].get('resume') or {}
    check('S2b_q_resume_admits_same_campaign', r2['q_code'] == 0 and r2['q']['mode'] == 'RESUME_SAME_V004_CAMPAIGN'
          and len(pre.get('committed_before', [])) == 5 and len(pre.get('pending', [])) == 33 and pre.get('prior_status') == 'SAFE_STOP'
          and pre.get('safe_stop_request_present') is True and r2['q']['campaign_lock'] == 'ACQUIRED_AND_RELEASED'
          and r2['q']['checks']['q_no_effect_on_foreign_roots']['status'] == 'PASS', {'blockers': blockers(r2)})
    e = r2['e']; led = ledger(root)
    attempts = sorted(set(v['attempt'] for v in led.values()))
    check('S2c_e_resume_reuses_exactly_5_commits_33_new_pass', r2['e_code'] == 0 and e['status'] == 'PASS_NATIVE_V004_G5_TECHNICAL_FIVE_PART'
          and e['mode'] == 'RESUME_SAME_V004_CAMPAIGN' and sorted(e['reused_committed_units']) == sorted(pre['committed_before'])
          and len(e['newly_committed_units']) == 33 and len(led) == 38 and len(attempts) == 2
          and e['foreign_roots']['added'] == [] and e['v003_commits_reused'] == 0 and e['other_campaign_commits_reused'] == 0,
          {'status': e.get('status'), 'blockers': blockers(r2), 'attempts': len(attempts)})
    keep = sorted((Path(root) / 'INTERRUPTED_ATTEMPTS').glob('PRIOR_TERMINAL_*'))
    check('S2d_prior_terminal_preserved_and_stop_request_consumed', len(keep) == 1 and (keep[0] / 'SAFE_STOP.request').is_file()
          and not (Path(root) / 'SAFE_STOP.request').exists() and (keep[0] / 'ENGINEERING_RESULT.json').is_file()
          and len(list(Path(root).glob('CDT21_SUPERVISOR_RESUME_*.json'))) == 1,
          [p.name for p in keep])
    import zipfile
    with zipfile.ZipFile(e['return_zip']) as z:
        names = z.namelist()
    check('S2e_outer_return_carries_resume_receipt_and_ledger', any(n.startswith('CDT21_SUPERVISOR_RESUME_') for n in names)
          and sum(n.startswith('CDT21_SUPERVISOR_LEDGER/') for n in names) == 38, len(names))
    return w, root


def S3_abrupt_interruption_then_resume():
    w, local, r1, root = stopped_campaign('S3', STUB_KILL_AFTER=3)
    check('S3a_abrupt_death_no_terminal', r1['e_code'] == 3 and has(r1, 'R08_RETURN_NOT_SEALED')
          and not (Path(root) / 'ENGINEERING_RESULT.json').exists() and len(ledger(root)) == 3, blockers(r1))
    r2 = launch(w, resume=root)
    pre = r2['q'].get('resume') or {}
    e = r2['e']
    check('S3b_resume_after_abrupt_death_pass', r2['q_code'] == 0 and pre.get('prior_status') == 'NO_TERMINAL_INTERRUPTED'
          and r2['e_code'] == 0 and len(e['reused_committed_units']) == 3 and len(e['newly_committed_units']) == 35
          and any(p.name.startswith(pre['pending'][0] + '_') for p in (Path(root) / 'INTERRUPTED_ATTEMPTS').iterdir()),
          {'blockers': blockers(r2)})


def S4_two_interruptions():
    w, local, r1, root = stopped_campaign('S4', STUB_STOP_AFTER=5)
    r2 = launch(w, resume=root, stub_env={'STUB_STOP_AFTER': '10'})
    r3 = launch(w, resume=root)
    led = ledger(root)
    check('S4_two_safe_stops_then_pass_three_attempts', r2['e_code'] == 130 and r3['e_code'] == 0
          and len(r3['e']['reused_committed_units']) == 15 and len(r3['e']['newly_committed_units']) == 23
          and len(set(v['attempt'] for v in led.values())) == 3 and len(led) == 38, {'b2': blockers(r2), 'b3': blockers(r3)})


def S5_interrupted_closure_then_resume():
    w, local, r1, root = stopped_campaign('S5', STUB_CLOSE_FAIL=1)
    check('S5a_closure_interrupted_after_campaign_pass', r1['e_code'] == 4 and has(r1, 'STUB_CLOSURE_INTERRUPTED')
          and json.loads((Path(root) / 'ENGINEERING_RESULT.json').read_text())['status'] == 'PASS_NATIVE_INTEGRATED_PRE_B06', blockers(r1))
    r2 = launch(w, resume=root)
    e = r2['e']
    check('S5b_resume_reuses_38_and_closes', r2['e_code'] == 0 and len(e['reused_committed_units']) == 38
          and e['newly_committed_units'] == [] and any(p.name.startswith('FINAL_G5_') for p in (Path(root) / 'INTERRUPTED_ATTEMPTS').iterdir()),
          {'blockers': blockers(r2)})


def negative(tag, mutate, expect, where='q', stub_env=None, resume_path=None):
    w, local, r1, root = stopped_campaign(tag, STUB_STOP_AFTER=5)
    mutate(w, local, root, None)
    resume = resume_path(w, local, root) if resume_path else root
    r = launch(w, resume=resume, stub_env=stub_env)
    blocked = (r['q_code'] not in (0, None)) if where == 'q' else (r['e_code'] not in (0, None))
    check(tag, blocked and has(r, expect), {'q_code': r['q_code'], 'e_code': r['e_code'], 'blockers': blockers(r)[:2]})
    return r


def inject_v003_commit(w, local, root, extra):
    v3 = local / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791'
    c = sorted((v3 / 'COMMITS').glob('*.json'))[0]
    shutil.copyfile(c, Path(root) / 'COMMITS' / c.name)


def other_candidate_commit(w, local, root, extra):
    k = sorted((Path(root) / 'COMMITS').glob('*.json'))[0]
    o = json.loads(k.read_text()); o['package_sha256'] = 'C' * 64
    pend = [x for x in json.loads((Path(root) / 'LIVE_STATUS.json').read_text())['contracted_evidence_roles']] or []
    (Path(root) / 'COMMITS' / 'SUITE_adapter_tests.py.json').write_text(json.dumps(o))


def second_campaign(w, local, root):
    os.environ['STUB_STOP_AFTER'] = '7'
    r = launch(w, stub_env={'STUB_STOP_AFTER': '7'})
    return own_root(r)


def import_other_v004_commit(w, local, root, other):
    other = Path(other)
    mine = {p.stem for p in (Path(root) / 'COMMITS').glob('*.json')}
    k = sorted(p for p in (other / 'COMMITS').glob('*.json') if p.stem not in mine)[0]
    obj = json.loads(k.read_text())
    for ref in obj['artifacts']:
        dst = Path(root) / ref['member']; dst.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(other / ref['member'], dst)
    shutil.copyfile(k, Path(root) / 'COMMITS' / k.name)


def ledger_drift(w, local, root, extra):
    p = sorted((Path(root) / 'CDT21_SUPERVISOR_LEDGER').glob('*.json'))[0]
    o = json.loads(p.read_text()); o['commit_file_sha256'] = 'D' * 64; p.write_text(json.dumps(o))


def artifact_drift(w, local, root, extra):
    log = sorted((Path(root) / 'LOGS').glob('*.log'))[0]; log.write_bytes(log.read_bytes() + b'X')


def ledger_without_commit(w, local, root, extra):
    c = sorted((Path(root) / 'COMMITS').glob('*.json'))[0]
    keep = Path(root) / 'INTERRUPTED_ATTEMPTS' / 'TEST_MOVED'; keep.mkdir(parents=True, exist_ok=True); shutil.move(str(c), str(keep / c.name))


def foreign_key_commit(w, local, root, extra):
    c = sorted((Path(root) / 'COMMITS').glob('*.json'))[0]; shutil.copyfile(c, Path(root) / 'COMMITS' / 'NOT_IN_PLAN.json')


def other_supervisor_bootstrap(w, local, root, extra):
    p = Path(root) / 'CDT21_SUPERVISOR_BOOTSTRAP.json'; o = json.loads(p.read_text()); o['supervisor_sha256'] = 'E' * 64
    p.write_text(json.dumps(o))


def v003_root_as_resume(w, local, root, extra):
    pass


def root_outside_cdt20(w, local, root, extra):
    pass


def hold_lock(w, local, root, extra):
    HOLD['proc'] = REAL_POPEN([sys.executable, '-c', 'import fcntl,sys,time;f=open(sys.argv[1],"rb");fcntl.flock(f.fileno(),fcntl.LOCK_EX);'
                               'print("held",flush=True);time.sleep(120)', str(Path(root) / 'CAMPAIGN.lock')], stdout=subprocess.PIPE)
    HOLD['proc'].stdout.readline()


HOLD = {}


def run_all():
    S1_new_run_unchanged()
    S2_safe_stop_then_resume()
    S3_abrupt_interruption_then_resume()
    S4_two_interruptions()
    S5_interrupted_closure_then_resume()
    negative('N01_v003_commit_refused', inject_v003_commit, 'RESUME_COMMIT_BOUND_TO_V003')
    negative('N02_other_candidate_commit_refused', other_candidate_commit, 'RESUME_COMMIT_NOT_BOUND_TO_V004')
    negative('N03_commit_of_other_v004_campaign_refused',
             lambda w, l, r, x: import_other_v004_commit(w, l, r, second_campaign(w, l, r)), 'COMMIT_NOT_LEDGERED')
    negative('N04_ledger_drift_refused', ledger_drift, 'LEDGER_DRIFT')
    negative('N05_artifact_drift_refused', artifact_drift, 'RESUME_COMMIT_ARTIFACT_DRIFT')
    negative('N06_ledger_without_commit_refused', ledger_without_commit, 'LEDGER_WITHOUT_COMMIT')
    negative('N07_commit_outside_plan_refused', foreign_key_commit, 'RESUME_FOREIGN_COMMIT')
    negative('N08_root_of_other_supervisor_refused', other_supervisor_bootstrap, 'RESUME_BOOTSTRAP_BINDING')
    negative('N09_v003_root_refused', v003_root_as_resume, 'RESUME_BOOTSTRAP_BINDING',
             resume_path=lambda w, l, r: str(l / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791'))
    negative('N10_root_outside_cdt20_refused', root_outside_cdt20, 'RESUME_ROOT_LOCATION',
                  resume_path=lambda w, l, r: (shutil.copytree(r, w / 'ELSEWHERE' / Path(r).name), str(w / 'ELSEWHERE' / Path(r).name))[1])
    negative('N11_lock_held_by_live_process_refused', hold_lock, 'QUAL_campaign_lock_free')
    if HOLD.get('proc'):
        HOLD['proc'].kill(); HOLD['proc'].wait()
    def live(ident):
        raise RuntimeError('OWNER_OR_CHILD_LIVE')
    DEAD['fn'] = live
    negative('N12_prior_process_alive_refused', lambda *a: None, 'OWNER_OR_CHILD_LIVE')
    DEAD['fn'] = lambda ident: dict(ident, observation='ABSENT')
    # N13: a NEW-run qualification cannot admit a resume, nor a resume qualification of root A a resume of root B.
    w, local, r1, root = stopped_campaign('N13', STUB_STOP_AFTER=5)
    rq = launch(w)  # new-run Q + E (complete) in LOG_01 -> use its Q for a resume
    r = launch(w, resume=root, qual=rq['log'] / 'QUALIFICATION_RESULT.json', skip_q=True)
    check('N13a_new_run_q_cannot_admit_resume', r['e_code'] == 2 and has(r, 'QUALIFICATION_OTHER_RUN'), blockers(r)[:1])
    rqa = launch(w, resume=root, stub_env={'STUB_STOP_AFTER': '1'})  # resume A stops again
    rb = launch(w, resume=own_root(rq), qual=rqa['log'] / 'QUALIFICATION_RESULT.json', skip_q=True)
    check('N13b_resume_q_of_root_a_cannot_admit_root_b', rb['e_code'] == 2 and has(rb, 'QUALIFICATION_OTHER_RUN'), blockers(rb)[:1])
    # N14: state of the root changed between Q and E (a commit added) -> refused by the foreign digest.
    w, local, r1, root = stopped_campaign('N14', STUB_STOP_AFTER=5)
    n = len(list(w.glob('LOG_*'))); log = w / ('LOG_%02d' % n); stage = w / ('STAGE_%02d' % n); log.mkdir(); stage.mkdir()
    base = ['--package', str(pkg), '--review', str(review), '--log-dir', str(log), '--stage', str(stage), '--resume-root', root]
    run_main(base + ['--qualify-only'])
    (Path(root) / 'LOGS' / 'LATE.log').write_text('late')
    code = run_main(base + ['--require-qualification', str(log / 'QUALIFICATION_RESULT.json')])
    e = json.loads((log / 'SUPERVISOR_RESULT.json').read_text())
    check('N14_root_changed_between_q_and_e_refused', code == 2 and any('FOREIGN_ROOTS_CHANGED_SINCE_QUALIFICATION' in b for b in e['blockers'])
          and 'foreign_roots_difference' in e, e['blockers'][:1])
    # N15: a new run that sees a REUSE_COMMITTED line is still refused.
    w, local = env('N15')
    r = launch(w, stub_env={'STUB_FAKE_REUSE': '1'})
    check('N15_new_run_still_refuses_reuse', r['e_code'] == 3 and has(r, 'NEW_RUN_REUSED_A_COMMIT'), blockers(r)[:1])
    # N16: during a resume, another pre-existing root changes -> refused.
    w, local, r1, root = stopped_campaign('N16', STUB_STOP_AFTER=5)
    n = len(list(w.glob('LOG_*'))); log = w / ('LOG_%02d' % n); stage = w / ('STAGE_%02d' % n); log.mkdir(); stage.mkdir()
    base = ['--package', str(pkg), '--review', str(review), '--log-dir', str(log), '--stage', str(stage), '--resume-root', root]
    run_main(base + ['--qualify-only'])
    real_popen_init = HookPopen.__init__
    def touching(self, cmd, *a, **kw):
        (local / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791' / 'LIVE_STATUS.json').open('ab').write(b' ')
        real_popen_init(self, cmd, *a, **kw)
    HookPopen.__init__ = touching
    try:
        code = run_main(base + ['--require-qualification', str(log / 'QUALIFICATION_RESULT.json')])
    finally:
        HookPopen.__init__ = real_popen_init
    e = json.loads((log / 'SUPERVISOR_RESULT.json').read_text())
    check('N16_other_root_changed_during_resume_refused', code == 3 and any('FOREIGN_ROOT_CHANGED:run/R08_Q1_20261020210605' in b for b in e['blockers'])
          and 'foreign_roots_difference' in e, e['blockers'][:1])


# ------------------------------------------------------------------ R4: child-process supervisor (whole-tree crash)
import signal  # noqa: E402


def child_main():
    """One E phase in its own process, so that a crash can take the supervisor down with the campaign."""
    spec = json.loads(CHILD)
    w = Path(spec['w']); os.chdir(w); os.environ['LOCALAPPDATA'] = spec['local']
    S.D_LABS = str(w / 'D:\\TICKSTORE_CDT19_PRE_G06_LABS'); S.PRODUCTION = str(w / 'D:\\Base CSV')
    for k in [k for k in os.environ if k.startswith('STUB_')]:
        del os.environ[k]
    os.environ.update(spec.get('env') or {})
    if spec.get('die_in_ledger') is not None:
        orig, calls = S.ledger_record, [0]
        def dying(root, key, attempt, sup, cpid):
            if calls[0] == spec['die_in_ledger']:
                # Supervisor dies after reading COMMITTED <key>, its ledger entry written in TEMP but never moved;
                # kill-on-close takes the campaign tree down with it.
                S.write_new(Path(root) / 'TEMP' / ('LEDGER_' + key + '_' + attempt + '.json'),
                            b'{"partial":"supervisor died before the atomic move"}\n')
                os.kill(cpid, signal.SIGKILL)
                os._exit(9)
            calls[0] += 1
            return orig(root, key, attempt, sup, cpid)
        S.ledger_record = dying
    sys.exit(run_main(spec['args']))


if CHILD:
    child_main()


def launch_child(w, local, resume='', stub_env=None, die_in_ledger=None):
    """Q in this process (as the launcher does), E in a separate supervisor process that the scenario may kill."""
    n = len(list(w.glob('LOG_*')))
    log = w / ('LOG_%02d' % n); stage = w / ('STAGE_%02d' % n); log.mkdir(); stage.mkdir()
    base = ['--package', str(pkg), '--review', str(review), '--log-dir', str(log), '--stage', str(stage)]
    rargs = ['--resume-root', resume] if resume else []
    qcode = run_main(base + ['--qualify-only'] + rargs)
    q = json.loads((log / 'QUALIFICATION_RESULT.json').read_text())
    spec = {'w': str(w), 'local': str(local), 'env': stub_env or {}, 'die_in_ledger': die_in_ledger, 'mutant': MUTANT,
            'args': base + ['--require-qualification', str(log / 'QUALIFICATION_RESULT.json')] + rargs}
    with open(log / 'CHILD_E_STDOUT.txt', 'wb') as so:
        cp = REAL_POPEN([sys.executable, '-I', '-B', sys.argv[0]] + sys.argv[1:8] + ['--child-e', json.dumps(spec)],
                        stdout=so, stderr=subprocess.STDOUT)
        rc = cp.wait(timeout=600)
    os.chdir(w)
    res = log / 'SUPERVISOR_RESULT.json'
    return {'q_code': qcode, 'q': q, 'e_code': rc, 'e': json.loads(res.read_text()) if res.exists() else {}, 'log': log,
            'supervisor_result_written': res.exists()}


# ------------------------------------------------------------------ R4 helpers
def jload(p):
    return json.loads(Path(p).read_text())


def jdump(p, obj):
    Path(p).write_bytes((json.dumps(obj, sort_keys=True, separators=(',', ':')) + '\n').encode('ascii'))


def journal(root):
    return Path(root) / 'CDT21_SUPERVISOR_JOURNAL'


def attempts_of(root):
    return sorted((jload(p) for p in journal(root).glob('ATTEMPT_*.json')), key=lambda r: r['sequence'])


def census_of(root, attempt, key):
    p = journal(root) / ('CENSUS_' + attempt + '_' + key + '.json')
    return jload(p) if p.exists() else None


def commit_keys(root):
    return sorted(p.stem for p in (Path(root) / 'COMMITS').glob('*.json'))


def rehash_ref(root, key, member):
    """Keep a tampered artifact hash-intact in its COMMIT (so only the R4 proof can refuse it)."""
    cp = Path(root) / 'COMMITS' / (key + '.json'); c = jload(cp)
    raw = (Path(root) / member).read_bytes()
    for ref in c['artifacts']:
        if ref['member'] == member:
            ref['sha256'] = hashlib.sha256(raw).hexdigest().upper(); ref['bytes'] = len(raw)
    jdump(cp, c)


def copy_commit(src_root, dst_root, key):
    c = jload(Path(src_root) / 'COMMITS' / (key + '.json'))
    for ref in c['artifacts']:
        d = Path(dst_root) / ref['member']; d.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(Path(src_root) / ref['member'], d)
    shutil.copyfile(Path(src_root) / 'COMMITS' / (key + '.json'), Path(dst_root) / 'COMMITS' / (key + '.json'))


WINDOW = {'STUB_CRASH_AFTER_PUBLISH': '3', 'STUB_CRASH_MODE': 'campaign'}


def window_state(tag):
    """R3-F01 window: 3 units committed and ledgered; the 4th COMMIT published, the campaign dies before COMMITTED."""
    w, local = env(tag)
    r1 = launch(w, stub_env=WINDOW)
    root = own_root(r1); plan = r1['q']['plan']
    return w, local, r1, root, plan, plan[3]


def window_facts(r1, root, plan, key):
    led = ledger(root); att = attempts_of(root)
    return {'e_code': r1['e_code'], 'ledger': sorted(led), 'commits': commit_keys(root),
            'committed_line_seen': key in (r1['e'].get('newly_committed_units') or []),
            'attempts': len(att), 'census_for_key': census_of(root, att[-1]['attempt'], key) is not None if att else False}


def window_ok(f, plan, key):
    return (sorted(f['ledger']) == sorted(plan[:3]) and f['commits'] == sorted(plan[:4]) and not f['committed_line_seen']
            and f['census_for_key'])


def reconciled_pass(r, root, key, reused_n, new_n):
    led = ledger(root); e = r['e']
    entry = led.get(key, {})
    return (r['q_code'] == 0 and (((r['q'].get('resume') or {}).get('reconcile')) or {}).get('key') == key
            and r['e_code'] == 0 and e.get('status') == 'PASS_NATIVE_V004_G5_TECHNICAL_FIVE_PART'
            and entry.get('basis') == 'RECONCILED_BY_SUPERVISOR_JOB_CENSUS' and key in e.get('reused_committed_units', [])
            and key not in e.get('newly_committed_units', []) and len(e.get('reused_committed_units', [])) == reused_n
            and len(e.get('newly_committed_units', [])) == new_n and len(led) == 38
            and not ((Path(root) / 'INTERRUPTED_ATTEMPTS').is_dir()
                     and any(p.name.startswith(key + '_') for p in (Path(root) / 'INTERRUPTED_ATTEMPTS').iterdir())))


# ------------------------------------------------------------------ R4 scenarios
def Q1_census_probe_and_new_run_journal():
    w, local = env('Q1')
    r = launch(w)
    root = own_root(r); att = attempts_of(root)
    cen = sorted(journal(root).glob('CENSUS_*.json'))
    check('Q1a_q_census_sees_nested_child', r['q_code'] == 0
          and r['q']['checks'].get('job_census_sees_nested_child', {}).get('status') == 'PASS', r['q'].get('job_census_probe'))
    check('Q1b_new_run_journal_1_attempt_38_unit_census_no_error', r['e_code'] == 0 and len(att) == 1 and att[0]['sequence'] == 0
          and att[0]['ledger_keys_at_start'] == [] and len(cen) == 38 and r['e'].get('unit_census_errors') == []
          and sorted(r['e'].get('unit_census_recorded', [])) == sorted(r['q']['plan'])
          and all(any(p['pid'] == jload(Path(root) / 'COMMITS' / (k + '.json'))['owner'][0]['pid'] for p in jload(c)['processes'])
                  for c in cen for k in [jload(c)['key']]),
          {'attempts': len(att), 'census': len(cen), 'errors': r['e'].get('unit_census_errors')})
    import zipfile
    with zipfile.ZipFile(r['e']['return_zip']) as z:
        names = z.namelist()
    check('Q1c_outer_return_carries_journal', sum(n.startswith('CDT21_SUPERVISOR_JOURNAL/') for n in names) == 39, len(names))


def W1_campaign_dies_in_window():
    w, local, r1, root, plan, key = window_state('W1')
    f = window_facts(r1, root, plan, key)
    check('W1a_window_state_commit_durable_not_ledgered_supervisor_alive', r1['e_code'] == 3 and has(r1, 'R08_RETURN_NOT_SEALED')
          and window_ok(f, plan, key), f)
    before = {k: H(Path(root) / k) for k in ('COMMITS/' + key + '.json', 'UNITS/' + key + '/RESULT.json', 'LOGS/' + key + '.log')}
    r2 = launch(w, resume=root)
    proof = (r2['q'].get('resume') or {}).get('reconcile') or {}
    c = jload(Path(root) / 'COMMITS' / (key + '.json'))
    check('W1b_q_proof_owner_eq_result_process_in_census_latest_attempt', r2['q_code'] == 0 and proof.get('key') == key
          and proof.get('owner') == {'pid': c['owner'][0]['pid'], 'creation_filetime': c['owner'][0]['creation_filetime']}
          and proof.get('attempt') == attempts_of(root)[0]['attempt'] and proof.get('attempt_sequence') == 0, proof)
    check('W1c_e_reconciles_reuses_without_reexecution_pass', reconciled_pass(r2, root, key, 4, 34)
          and all(H(Path(root) / k) == v for k, v in before.items())
          and any(jload(p).get('reconciled', {}).get('key') == key for p in Path(root).glob('CDT21_SUPERVISOR_RESUME_*.json')),
          {'blockers': blockers(r2), 'reused': len(r2['e'].get('reused_committed_units', []))})


def W2_whole_tree_dies_in_window():
    w, local = env('W2')
    r1 = launch_child(w, local, stub_env={'STUB_CRASH_AFTER_PUBLISH': '3', 'STUB_CRASH_MODE': 'tree'})
    root = [p for p in (local / 'CDT20_R08').glob('R08_Q1_2026*') if p.name != 'R08_Q1_20261020210605_856fea523791']
    root = str(root[0]) if len(root) == 1 else None
    plan = r1['q']['plan']; key = plan[3]
    f = window_facts(r1, root, plan, key) if root else {}
    check('W2a_supervisor_and_campaign_killed_after_publish', r1['e_code'] == -9 and not r1['supervisor_result_written']
          and root is not None and window_ok(f, plan, key), {'rc': r1['e_code'], 'facts': f})
    r2 = launch(w, resume=root)
    check('W2b_resume_reconciles_and_passes', reconciled_pass(r2, root, key, 4, 34), {'blockers': blockers(r2)})


def W3_supervisor_dies_inside_ledger_write():
    w, local = env('W3')
    r1 = launch_child(w, local, die_in_ledger=3)
    root = [p for p in (local / 'CDT20_R08').glob('R08_Q1_2026*') if p.name != 'R08_Q1_20261020210605_856fea523791']
    root = str(root[0]) if len(root) == 1 else None
    plan = r1['q']['plan']; key = plan[3]
    led = ledger(root) if root else {}
    partial = sorted((Path(root) / 'TEMP').glob('LEDGER_' + key + '_*.json')) if root else []
    att = attempts_of(root) if root else []
    check('W3a_committed_line_read_ledger_not_moved_tree_killed', r1['e_code'] == 9 and not r1['supervisor_result_written']
          and sorted(led) == sorted(plan[:3]) and commit_keys(root) == sorted(plan[:4]) and len(partial) == 1
          and census_of(root, att[-1]['attempt'], key) is not None,
          {'rc': r1['e_code'], 'ledger': len(led), 'partial': [p.name for p in partial]})
    raw_partial = partial[0].read_bytes() if partial else b''
    r2 = launch(w, resume=root)
    check('W3b_resume_reconciles_partial_temp_preserved', reconciled_pass(r2, root, key, 4, 34)
          and partial and partial[0].read_bytes() == raw_partial, {'blockers': blockers(r2)})


def W4_window_inside_a_resumed_attempt():
    w, local, r1, root = stopped_campaign('W4', STUB_STOP_AFTER=5)
    plan = r1['q']['plan']
    r2 = launch(w, resume=root, stub_env={'STUB_CRASH_AFTER_PUBLISH': '2', 'STUB_CRASH_MODE': 'campaign'})
    key = plan[7]; att = attempts_of(root)
    ok_state = (r2['e_code'] == 3 and r2['e'].get('status') == 'BLOCKED' and has(r2, 'CAMPAIGN_ABRUPT_EXIT_NO_TERMINAL_OF_THIS_ATTEMPT:9')
                and sorted(ledger(root)) == sorted(plan[:7]) and commit_keys(root) == sorted(plan[:8])
                and len(att) == 2 and census_of(root, att[1]['attempt'], key) is not None)
    r3 = launch(w, resume=root)
    proof = (r3['q'].get('resume') or {}).get('reconcile') or {}
    check('W4_second_attempt_window_reconciled_from_latest_attempt', ok_state and reconciled_pass(r3, root, key, 8, 30)
          and proof.get('attempt') == att[1]['attempt'] and proof.get('attempt_sequence') == 1 and len(attempts_of(root)) == 3,
          {'state': ok_state, 'blockers': blockers(r3), 'proof_attempt': proof.get('attempt_sequence')})


def window_negative(tag, mutate, expect):
    w, local, r1, root, plan, key = window_state(tag)
    ctx = {'w': w, 'local': local, 'root': Path(root), 'plan': plan, 'key': key}
    mutate(ctx)
    r = launch(w, resume=root)
    check(tag, r['q_code'] not in (0, None) and has(r, expect) and len(ledger(root)) == 3 - ctx.get('ledger_removed', 0)
          and not (Path(root) / 'CDT21_SUPERVISOR_LEDGER' / (key + '.json')).exists(),
          {'q_code': r['q_code'], 'blockers': blockers(r)[:2]})
    return r


def other_v004_root(ctx):
    """A second, complete-enough V004 campaign (same bytes) in the same LOCALAPPDATA: the foreign source."""
    if 'other' not in ctx:
        r = launch(ctx['w'], stub_env={'STUB_STOP_AFTER': '6'})
        ctx['other'] = Path(own_root(r))
    return ctx['other']


def nr_foreign_commit_in_slot(ctx):
    copy_commit(other_v004_root(ctx), ctx['root'], ctx['key'])


def nr_census_deleted(ctx):
    for p in journal(ctx['root']).glob('CENSUS_*_' + ctx['key'] + '.json'):
        p.unlink()


def nr_census_of_other_unit(ctx):
    att = attempts_of(ctx['root'])[-1]['attempt']
    src = journal(ctx['root']) / ('CENSUS_' + att + '_' + ctx['plan'][2] + '.json')
    shutil.copyfile(src, journal(ctx['root']) / ('CENSUS_' + att + '_' + ctx['key'] + '.json'))


def nr_result_process_tampered(ctx):
    member = 'UNITS/' + ctx['key'] + '/RESULT.json'; p = ctx['root'] / member
    res = jload(p); res['process']['creation_filetime'] += 1; jdump(p, res)
    rehash_ref(ctx['root'], ctx['key'], member)


def nr_two_unledgered(ctx):
    copy_commit(other_v004_root(ctx), ctx['root'], ctx['plan'][4])


def nr_gap_before_slot(ctx):
    keep = ctx['root'] / 'INTERRUPTED_ATTEMPTS' / 'TEST_MOVED'; keep.mkdir(parents=True, exist_ok=True)
    k2 = ctx['plan'][2]
    shutil.move(str(ctx['root'] / 'COMMITS' / (k2 + '.json')), str(keep / ('COMMIT_' + k2 + '.json')))
    shutil.move(str(ctx['root'] / 'CDT21_SUPERVISOR_LEDGER' / (k2 + '.json')), str(keep / ('LEDGER_' + k2 + '.json')))
    ctx['ledger_removed'] = 1


def nr_later_attempt_without_census(ctx):
    last = attempts_of(ctx['root'])[-1]
    forged = dict(last, attempt='29991231235959_ffffff', sequence=last['sequence'] + 1)
    jdump(journal(ctx['root']) / 'ATTEMPT_29991231235959_ffffff.json', forged)


def nr_v003_commit_in_slot(ctx):
    v3 = ctx['local'] / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791' / 'COMMITS'
    src = v3 / (ctx['key'] + '.json')
    shutil.copyfile(src if src.exists() else sorted(v3.glob('*.json'))[0], ctx['root'] / 'COMMITS' / (ctx['key'] + '.json'))


def nr_other_candidate_in_slot(ctx):
    p = ctx['root'] / 'COMMITS' / (ctx['key'] + '.json'); c = jload(p); c['package_sha256'] = 'C' * 64; jdump(p, c)


def nr_artifact_tampered(ctx):
    p = ctx['root'] / 'LOGS' / (ctx['key'] + '.log'); p.write_bytes(p.read_bytes() + b'X')


def nr_census_creation_differs(ctx):
    att = attempts_of(ctx['root'])[-1]['attempt']
    owner = jload(ctx['root'] / 'COMMITS' / (ctx['key'] + '.json'))['owner'][0]
    p = journal(ctx['root']) / ('CENSUS_' + att + '_' + ctx['key'] + '.json'); c = jload(p)
    for q in c['processes']:
        if q['pid'] == owner['pid']:
            q['creation_filetime'] += 1  # same PID, other process (PID reuse)
    jdump(p, c)


def nr_owner_is_campaign(ctx):
    att = attempts_of(ctx['root'])[-1]['attempt']
    c = census_of(ctx['root'], att, ctx['key'])
    camp = [q for q in c['processes'] if q['pid'] == c['campaign_pid']][0]
    member = 'UNITS/' + ctx['key'] + '/RESULT.json'; rp = ctx['root'] / member
    res = jload(rp); res['process'] = {'pid': camp['pid'], 'creation_filetime': camp['creation_filetime'], 'state': 'LIVE'}
    jdump(rp, res); rehash_ref(ctx['root'], ctx['key'], member)
    cp = ctx['root'] / 'COMMITS' / (ctx['key'] + '.json'); cm = jload(cp)
    cm['owner'] = [res['process']]; cm['result'] = res; jdump(cp, cm)


def nr_attempt_of_other_supervisor(ctx):
    last = sorted(journal(ctx['root']).glob('ATTEMPT_*.json'))[-1]
    a = jload(last); a['supervisor_sha256'] = 'E' * 64; jdump(last, a)


def run_r4():
    safe(Q1_census_probe_and_new_run_journal)
    safe(W1_campaign_dies_in_window)
    safe(W2_whole_tree_dies_in_window)
    safe(W3_supervisor_dies_inside_ledger_write)
    safe(W4_window_inside_a_resumed_attempt)
    safe(window_negative, 'NR01_foreign_v004_commit_in_window_slot_refused', nr_foreign_commit_in_slot, 'RECONCILE_OWNER_NOT_IN_SUPERVISOR_CENSUS')
    safe(window_negative, 'NR02_no_supervisor_census_refused', nr_census_deleted, 'RECONCILE_NO_CENSUS_IN_LAST_ATTEMPT')
    safe(window_negative, 'NR03_census_of_another_unit_refused', nr_census_of_other_unit, 'RECONCILE_CENSUS_RECORD')
    safe(window_negative, 'NR04_result_process_ne_owner_refused', nr_result_process_tampered, 'RECONCILE_RESULT_PROCESS_NE_OWNER')
    safe(window_negative, 'NR05_two_unledgered_commits_refused', nr_two_unledgered, 'RECONCILE_MORE_THAN_ONE')
    safe(window_negative, 'NR06_unledgered_commit_not_next_plan_unit_refused', nr_gap_before_slot, 'RECONCILE_NOT_NEXT_PLAN_KEY')
    safe(window_negative, 'NR07_census_not_from_latest_attempt_refused', nr_later_attempt_without_census, 'RECONCILE_NO_CENSUS_IN_LAST_ATTEMPT')
    safe(window_negative, 'NR08_v003_commit_in_window_slot_refused', nr_v003_commit_in_slot, 'RESUME_COMMIT_BOUND_TO_V003')
    safe(window_negative, 'NR09_other_candidate_commit_in_window_slot_refused', nr_other_candidate_in_slot, 'RESUME_COMMIT_NOT_BOUND_TO_V004')
    safe(window_negative, 'NR10_artifact_drift_in_window_slot_refused', nr_artifact_tampered, 'RESUME_COMMIT_ARTIFACT_DRIFT')
    safe(window_negative, 'NR11_pid_reused_other_creation_refused', nr_census_creation_differs, 'RECONCILE_OWNER_NOT_IN_SUPERVISOR_CENSUS')
    safe(window_negative, 'NR12_owner_is_campaign_child_refused', nr_owner_is_campaign, 'RECONCILE_OWNER_IS_SUPERVISOR_OR_CAMPAIGN')
    safe(window_negative, 'NR13_attempt_record_of_other_supervisor_refused', nr_attempt_of_other_supervisor, 'RECONCILE_ATTEMPT_RECORD')


GROUPS = os.environ.get('R4_GROUPS', 'R3,R4').split(',')
if 'R3' in GROUPS:
    run_all()
if 'R4' in GROUPS:
    run_r4()
doc = {'schema': 'CDT21_G5_V004_R4_RECONCILE_QUALIFICATION_V001', 'mutant': MUTANT, 'supervisor_sha256': SUP_SHA,
       'r3_harness_sha256': '3D612C1259756A50F203D8AD4D07BEE1E2D75A90DC5BAF24053A3C49CF25BA07',
       'substitutions': [o.strip()[:80] for o, _ in SUBS], 'stand_ins': ['IsUserAnAdmin', 'volume_filesystem', 'SupervisorJob', 'msvcrt(flock)',
       'R.dead census', 'native_b2d', 'new-unit execution (stub_campaign_r4.py; reuse via frozen run_unit)', 'PRE_G06_COMPLETENESS.close',
       'SupervisorJob.census/nested_census_probe (process tree via /proc)', 'frozen_native (pid, start time via /proc)'],
       'campaign_child_runs': HOOK['campaign_calls'], 'passed': sum(c['pass'] for c in results), 'total': len(results), 'cases': results}
Path(out).write_text(json.dumps(doc, indent=1, default=str), encoding='utf-8')
print('R4_RECONCILE', MUTANT or 'ORIGINAL', doc['passed'], '/', doc['total'], [c['case'] for c in results if not c['pass']])
