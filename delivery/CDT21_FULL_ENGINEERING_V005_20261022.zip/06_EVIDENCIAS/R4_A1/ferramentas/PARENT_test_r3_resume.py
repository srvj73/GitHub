"""End-to-end qualification of the G5 V004 supervisor R3 resume (Linux; real supervisor main()/qualify_main()).

Usage: python -I test_r3_resume.py <R3.py> <V004.zip> <REVIEW_V004.json> <v003_root_src> <stub_campaign.py> <work> <out.json> [--mutant M]
Real: the R3 supervisor code paths (Q and E, new run and resume), extraction, frozen verify_package and plan, the frozen
reuse path of run_unit, write_terminal and seal_return, digests, ledger, preservation, return packaging.
Stand-ins (Windows-only or native-only, recorded in the output): the platform guard (2 source substitutions),
IsUserAnAdmin, volume_filesystem, the kill-on-close Job, msvcrt byte-range locks (flock), the frozen R.dead census,
the native b2d runner (already proven natively 29/29 + R1 negative), new-unit execution (stub_campaign.py) and the
five-part closure PRE_G06_COMPLETENESS.close (fake that retains a prior FINAL_G5 exactly like the frozen one).
"""
import ctypes
import fcntl
import hashlib
import importlib
import json
import os
import shutil
import subprocess
import sys
import time
import types
import uuid
from pathlib import Path

sup_p, pkg, review, v003, stub, work, out = map(Path, sys.argv[1:8])
MUTANT = sys.argv[9] if len(sys.argv) > 9 and sys.argv[8] == '--mutant' else None
work = work.resolve()
H = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
results = []

SUBS = [("        require(os.name == 'nt', 'WINDOWS_REQUIRED')\n", "        pass  # TEST: platform guard (Linux)\n"),
        ("ok('windows_python_admin', os.name == 'nt' and sys.version_info[:2] == (3, 14),",
         "ok('windows_python_admin', sys.version_info[:2] == (3, 14),")]
MUTANTS = {
    'M1_NO_LEDGER_CHECK': ("    attempts = ledger_bound(root, commit_sha)\n", "    attempts = {}\n"),
    'M2_NO_V003_OR_V004_BINDING': ("        require(obj.get('package_sha256') != V003_PACKAGE_SHA and obj.get('code_sha256') != V003_CODE_SHA,\n"
                                   "                'RESUME_COMMIT_BOUND_TO_V003:' + p.stem)\n", ""),
    'M3_ANY_SUPERVISOR_BOOTSTRAP': ("            and boot.get('supervisor_sha256') == sha_file(__file__) and boot.get('v003_commits_reused') == 0\n",
                                    "            and boot.get('v003_commits_reused') == 0\n"),
    'M4_NEW_RUN_ACCEPTS_REUSE': ("            require(not reused, 'NEW_RUN_REUSED_A_COMMIT:' + ','.join(sorted(reused)))\n", "            pass\n"),
    'M5_RESUME_USES_NEW_RUN_FOREIGN_RULE': ("        result['foreign_roots'] = foreign_checked(local, foreign_before, rows_e, run_id, result, 'foreign_roots',\n"
                                            "                                                  bool(resume_root))\n",
                                            "        result['foreign_roots'] = foreign_checked(local, foreign_before, rows_e, run_id, result, 'foreign_roots')\n"),
    'M6_SAFE_STOP_REQUEST_NOT_CONSUMED': ("        os.replace(stop, keep / 'SAFE_STOP.request')\n", "        pass\n"),
    'M7_NO_PRIOR_PROCESS_CHECK': ("            result['prior_processes'] = prior_processes_dead(root, frozen_dead())\n", "            pass\n"),
}
src = sup_p.read_text(encoding='utf-8')
for o, n in SUBS + ([MUTANTS[MUTANT]] if MUTANT else []):
    assert src.count(o) == 1, o[:80]
    src = src.replace(o, n)
if MUTANT == 'M7_NO_PRIOR_PROCESS_CHECK':
    o = "            q['prior_processes'] = prior_processes_dead(Path(pre['run_root']), frozen_dead())\n"
    assert src.count(o) == 1; src = src.replace(o, "            q['prior_processes'] = []\n")

# ------------------------------------------------------------------ Windows-only stand-ins
ctypes.WinDLL = lambda *a, **k: types.SimpleNamespace(IsUserAnAdmin=lambda: 1)
ms = types.ModuleType('msvcrt'); ms.LK_NBLCK = 2; ms.LK_UNLCK = 0
def _locking(fd, mode, n):
    fcntl.flock(fd, fcntl.LOCK_UN if mode == ms.LK_UNLCK else fcntl.LOCK_EX | fcntl.LOCK_NB)
ms.locking = _locking; sys.modules['msvcrt'] = ms
DEAD = {'fn': lambda ident: dict(ident, observation='ABSENT')}
REAL_POPEN = subprocess.Popen
HOOK = {'campaign_calls': 0}


class HookPopen(REAL_POPEN):
    def __init__(self, cmd, *a, **kw):
        if isinstance(cmd, list) and len(cmd) > 3 and str(cmd[3]).replace('\\', '/').endswith('g5proof/PRE_G06_CAMPAIGN.py'):
            env = dict(kw.get('env') or os.environ); env['STUB_REAL_CAMPAIGN'] = str(cmd[3]); kw['env'] = env
            cmd = [cmd[0], '-I', '-B', str(stub)] + list(cmd[4:]); HOOK['campaign_calls'] += 1
        super().__init__(cmd, *a, **kw)


subprocess.Popen = HookPopen


class FakeCompleteness(types.ModuleType):
    """Stand-in for the frozen five-part closure; retains a prior FINAL_G5 like PRE_G06_COMPLETENESS does."""
    @property
    def __file__(self):
        cands = sorted(Path(os.environ['LOCALAPPDATA'], 'CDT21_G5_V004').glob('CURRENT_G5_DELTA_2*/EXTRACTED'),
                       key=lambda p: p.stat().st_mtime_ns)
        return str(cands[-1] / 'implementation_v001/candidate/g5proof/PRE_G06_COMPLETENESS.py')

    def close(self, final_zip, native_zip, review_path, root):
        root = Path(root); out_ = root / 'FINAL_G5'
        if out_.exists():
            prev = root / 'INTERRUPTED_ATTEMPTS' / ('FINAL_G5_' + uuid.uuid4().hex)
            prev.parent.mkdir(parents=True, exist_ok=True); shutil.move(str(out_), str(prev))
        (out_ / 'INPUTS').mkdir(parents=True)
        shutil.copyfile(final_zip, out_ / 'INPUTS' / 'FINAL_PACKAGE.zip'); shutil.copyfile(native_zip, out_ / 'INPUTS' / 'NATIVE_RETURN.zip')
        if os.environ.get('STUB_CLOSE_FAIL') == '1':
            raise RuntimeError('STUB_CLOSURE_INTERRUPTED')
        parts = {}
        for name in ('ENGINEERING', 'STAGE', 'FULL_CANDIDATE', 'NEGATIVE', 'TRANSPORT'):
            p = out_ / (name + '.json'); p.write_text(json.dumps({'part': name, 'status': 'PASS'}))
            parts[name] = {'status': 'PASS', 'sha256': H(p), 'path': str(p)}
        (out_ / 'ENGINEERING_COMPLETENESS.json').write_text(json.dumps({'code_manifest_sha256': S.CODE_SHA, 'final_package_sha256': S.PACKAGE_SHA,
                                                                       'five_part_completeness': parts}))
        (out_ / 'FINAL_ENGINEERING_STATUS.json').write_text('{"status":"PASS_STUB"}')
        (out_ / 'FOUR_PRE_B06_FINDINGS.json').write_text('{"status":"PASS_STUB"}')
        return {'engineering_five_part_completeness': 'PASS', 'four_pre_b06_findings': 'PASS_NATIVE_REGRESSION',
                'independent_b06_audit': False, 'status': 'PASS_STUB_CLOSURE'}


sys.modules['PRE_G06_COMPLETENESS'] = FakeCompleteness('PRE_G06_COMPLETENESS')

S = types.ModuleType('sup_r3'); S.__file__ = str(sup_p)
exec(compile(src, str(sup_p), 'exec'), S.__dict__)
S.volume_filesystem = lambda d: 'NTFS'
S.SupervisorJob = type('Job', (), {'active': lambda self: 1})
S.frozen_dead = lambda: (lambda ident: DEAD['fn'](ident))


def fake_b2d(extracted, temp, log_path):
    neg = 'QUAL_NEG_' in str(extracted)
    Path(log_path).write_text('NATIVE b2d stand-in (proven natively)\n')
    return {'exit': 1 if neg else 0, 'ran': 29, 'ok': not neg, 'contract_not_met': 58 if neg else 0, 'log': str(log_path), 'log_sha256': H(log_path)}


S.native_b2d = fake_b2d
SUP_SHA = H(sup_p)


# ------------------------------------------------------------------ environment
def env(tag):
    w = work / tag
    if w.exists():
        shutil.rmtree(w)
    local = w / 'LOCAL'; (local / 'CDT20_R08').mkdir(parents=True)
    shutil.copytree(v003, local / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791', symlinks=True)
    (local / 'CDT20_R08' / 'CURRENT_09AA56B867476005.json').write_text('x' * 179)
    dl = w / 'D:\\TICKSTORE_CDT19_PRE_G06_LABS' / 'R08_Q1_20261020210605_856fea523791'
    shutil.copytree(v003 / 'COMMITS', dl / 'WRITER_EFFECTFUL')
    shutil.copyfile(v003 / 'OWNER.json', dl / 'OWNER.json')
    prod = w / 'D:\\Base CSV'; (prod / 'Scripts').mkdir(parents=True); (prod / 'a.csv').write_text('1')
    (w / 'D:\\').mkdir(); (w / '\\').mkdir()
    os.chdir(w); os.environ['LOCALAPPDATA'] = str(local)
    S.D_LABS = str(w / 'D:\\TICKSTORE_CDT19_PRE_G06_LABS'); S.PRODUCTION = str(w / 'D:\\Base CSV')  # absolute, as on Windows
    for k in [k for k in os.environ if k.startswith('STUB_')]:
        del os.environ[k]
    return w, local


BASE_PATH = list(sys.path)


def fresh_process():
    """Q and E are separate python processes under the launcher: drop modules imported from extractions."""
    for name, m in list(sys.modules.items()):
        f = getattr(type(m), '__file__', None) if isinstance(m, FakeCompleteness) else getattr(m, '__file__', None)
        if isinstance(f, str) and f.startswith(str(work)) and not isinstance(m, FakeCompleteness):
            del sys.modules[name]
    sys.path[:] = BASE_PATH
    S._ROWS.clear()


def run_main(args):
    fresh_process()
    return S.main(args)


def launch(w, resume='', stub_env=None, qual=None, skip_q=False):
    """One launcher run: same log dir and stage for Q and E, like RUN_CDT21_G5_V004_R3."""
    n = len(list(w.glob('LOG_*')))
    log = w / ('LOG_%02d' % n); stage = w / ('STAGE_%02d' % n); log.mkdir(); stage.mkdir()
    base = ['--package', str(pkg), '--review', str(review), '--log-dir', str(log), '--stage', str(stage)]
    rargs = ['--resume-root', resume] if resume else []
    qcode = None
    if not skip_q:
        qcode = run_main(base + ['--qualify-only'] + rargs)
    qfile = qual or (log / 'QUALIFICATION_RESULT.json')
    q = json.loads(Path(qfile).read_text()) if Path(qfile).exists() else {}
    if qcode not in (None, 0):
        return {'q_code': qcode, 'q': q, 'e_code': None, 'e': {}, 'log': log}
    for k in [k for k in os.environ if k.startswith('STUB_')]:
        del os.environ[k]
    os.environ.update(stub_env or {})
    ecode = run_main(base + ['--require-qualification', str(qfile)] + rargs)
    e = json.loads((log / 'SUPERVISOR_RESULT.json').read_text())
    return {'q_code': qcode, 'q': q, 'e_code': ecode, 'e': e, 'log': log}


def check(name, ok, detail=''):
    results.append({'case': name, 'pass': bool(ok), 'detail': detail})


def blockers(r):
    return (r['q'].get('blockers') or []) + (r['e'].get('blockers') or [])


def has(r, code):
    return any(code in b for b in blockers(r))


def ledger(root):
    return {p.stem: json.loads(p.read_text()) for p in sorted((Path(root) / 'CDT21_SUPERVISOR_LEDGER').glob('*.json'))}


def own_root(r):
    return r['e'].get('run_root') or r['q'].get('resume_root')


def safe(fn, *a):
    try:
        return fn(*a)
    except Exception as exc:  # a mutant may break the harness flow; that is a failing case, not a crash
        results.append({'case': fn.__name__, 'pass': False, 'detail': 'EXCEPTION ' + type(exc).__name__ + ':' + str(exc)[:300]})


# ------------------------------------------------------------------ scenarios
def S1_new_run_unchanged():
    w, local = env('S1')
    r = launch(w)
    root = own_root(r)
    check('S1_new_run_pass_38_new_0_reused_ledger_38', r['q_code'] == 0 and r['e_code'] == 0
          and r['e']['status'] == 'PASS_NATIVE_V004_G5_TECHNICAL_FIVE_PART' and r['e']['mode'] == 'NEW_RUN_V004'
          and len(r['e']['newly_committed_units']) == 38 and r['e']['reused_committed_units'] == []
          and len(ledger(root)) == 38 and r['e']['foreign_roots']['added'] == ['d_lab/' + Path(root).name, 'run/' + Path(root).name],
          {'status': r['e'].get('status'), 'blockers': blockers(r)})


def stopped_campaign(tag, **stub):
    w, local = env(tag)
    r1 = launch(w, stub_env={k: str(v) for k, v in stub.items()})
    return w, local, r1, own_root(r1)


def S2_safe_stop_then_resume():
    w, local, r1, root = stopped_campaign('S2', STUB_STOP_AFTER=5)
    log_text = (r1['log'] / 'SUPERVISOR_RESULT.json').read_text()
    check('S2a_safe_stop_leaves_5_ledgered_commits', r1['e_code'] == 130 and r1['e']['status'] == 'SAFE_STOP'
          and sorted(ledger(root)) == sorted(p.stem for p in (Path(root) / 'COMMITS').glob('*.json')) and len(ledger(root)) == 5,
          {'code': r1['e_code'], 'status': r1['e'].get('status'), 'ledger': len(ledger(root))})
    r2 = launch(w, resume=root)
    pre = r2['q'].get('resume') or {}
    check('S2b_q_resume_admits_same_campaign', r2['q_code'] == 0 and r2['q']['mode'] == 'RESUME_SAME_V004_CAMPAIGN'
          and len(pre.get('committed_before', [])) == 5 and len(pre.get('pending', [])) == 33 and pre.get('prior_status') == 'SAFE_STOP'
          and pre.get('safe_stop_request_present') is True and r2['q']['campaign_lock'] == 'ACQUIRED_AND_RELEASED'
          and r2['q']['checks']['q_no_effect_on_foreign_roots']['status'] == 'PASS', {'blockers': blockers(r2)})
    e = r2['e']; led = ledger(root)
    attempts = sorted(set(v['attempt'] for v in led.values()))
    check('S2c_e_resume_reuses_exactly_5_commits_33_new_pass', r2['e_code'] == 0 and e['status'] == 'PASS_NATIVE_V004_G5_TECHNICAL_FIVE_PART'
          and e['mode'] == 'RESUME_SAME_V004_CAMPAIGN' and sorted(e['reused_committed_units']) == sorted(pre['committed_before'])
          and len(e['newly_committed_units']) == 33 and len(led) == 38 and len(attempts) == 2
          and e['foreign_roots']['added'] == [] and e['v003_commits_reused'] == 0 and e['other_campaign_commits_reused'] == 0,
          {'status': e.get('status'), 'blockers': blockers(r2), 'attempts': len(attempts)})
    keep = sorted((Path(root) / 'INTERRUPTED_ATTEMPTS').glob('PRIOR_TERMINAL_*'))
    check('S2d_prior_terminal_preserved_and_stop_request_consumed', len(keep) == 1 and (keep[0] / 'SAFE_STOP.request').is_file()
          and not (Path(root) / 'SAFE_STOP.request').exists() and (keep[0] / 'ENGINEERING_RESULT.json').is_file()
          and len(list(Path(root).glob('CDT21_SUPERVISOR_RESUME_*.json'))) == 1,
          [p.name for p in keep])
    import zipfile
    with zipfile.ZipFile(e['return_zip']) as z:
        names = z.namelist()
    check('S2e_outer_return_carries_resume_receipt_and_ledger', any(n.startswith('CDT21_SUPERVISOR_RESUME_') for n in names)
          and sum(n.startswith('CDT21_SUPERVISOR_LEDGER/') for n in names) == 38, len(names))
    return w, root


def S3_abrupt_interruption_then_resume():
    w, local, r1, root = stopped_campaign('S3', STUB_KILL_AFTER=3)
    check('S3a_abrupt_death_no_terminal', r1['e_code'] == 3 and has(r1, 'R08_RETURN_NOT_SEALED')
          and not (Path(root) / 'ENGINEERING_RESULT.json').exists() and len(ledger(root)) == 3, blockers(r1))
    r2 = launch(w, resume=root)
    pre = r2['q'].get('resume') or {}
    e = r2['e']
    check('S3b_resume_after_abrupt_death_pass', r2['q_code'] == 0 and pre.get('prior_status') == 'NO_TERMINAL_INTERRUPTED'
          and r2['e_code'] == 0 and len(e['reused_committed_units']) == 3 and len(e['newly_committed_units']) == 35
          and any(p.name.startswith(pre['pending'][0] + '_') for p in (Path(root) / 'INTERRUPTED_ATTEMPTS').iterdir()),
          {'blockers': blockers(r2)})


def S4_two_interruptions():
    w, local, r1, root = stopped_campaign('S4', STUB_STOP_AFTER=5)
    r2 = launch(w, resume=root, stub_env={'STUB_STOP_AFTER': '10'})
    r3 = launch(w, resume=root)
    led = ledger(root)
    check('S4_two_safe_stops_then_pass_three_attempts', r2['e_code'] == 130 and r3['e_code'] == 0
          and len(r3['e']['reused_committed_units']) == 15 and len(r3['e']['newly_committed_units']) == 23
          and len(set(v['attempt'] for v in led.values())) == 3 and len(led) == 38, {'b2': blockers(r2), 'b3': blockers(r3)})


def S5_interrupted_closure_then_resume():
    w, local, r1, root = stopped_campaign('S5', STUB_CLOSE_FAIL=1)
    check('S5a_closure_interrupted_after_campaign_pass', r1['e_code'] == 4 and has(r1, 'STUB_CLOSURE_INTERRUPTED')
          and json.loads((Path(root) / 'ENGINEERING_RESULT.json').read_text())['status'] == 'PASS_NATIVE_INTEGRATED_PRE_B06', blockers(r1))
    r2 = launch(w, resume=root)
    e = r2['e']
    check('S5b_resume_reuses_38_and_closes', r2['e_code'] == 0 and len(e['reused_committed_units']) == 38
          and e['newly_committed_units'] == [] and any(p.name.startswith('FINAL_G5_') for p in (Path(root) / 'INTERRUPTED_ATTEMPTS').iterdir()),
          {'blockers': blockers(r2)})


def negative(tag, mutate, expect, where='q', stub_env=None, resume_path=None):
    w, local, r1, root = stopped_campaign(tag, STUB_STOP_AFTER=5)
    mutate(w, local, root, None)
    resume = resume_path(w, local, root) if resume_path else root
    r = launch(w, resume=resume, stub_env=stub_env)
    blocked = (r['q_code'] not in (0, None)) if where == 'q' else (r['e_code'] not in (0, None))
    check(tag, blocked and has(r, expect), {'q_code': r['q_code'], 'e_code': r['e_code'], 'blockers': blockers(r)[:2]})
    return r


def inject_v003_commit(w, local, root, extra):
    v3 = local / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791'
    c = sorted((v3 / 'COMMITS').glob('*.json'))[0]
    shutil.copyfile(c, Path(root) / 'COMMITS' / c.name)


def other_candidate_commit(w, local, root, extra):
    k = sorted((Path(root) / 'COMMITS').glob('*.json'))[0]
    o = json.loads(k.read_text()); o['package_sha256'] = 'C' * 64
    pend = [x for x in json.loads((Path(root) / 'LIVE_STATUS.json').read_text())['contracted_evidence_roles']] or []
    (Path(root) / 'COMMITS' / 'SUITE_adapter_tests.py.json').write_text(json.dumps(o))


def second_campaign(w, local, root):
    os.environ['STUB_STOP_AFTER'] = '7'
    r = launch(w, stub_env={'STUB_STOP_AFTER': '7'})
    return own_root(r)


def import_other_v004_commit(w, local, root, other):
    other = Path(other)
    mine = {p.stem for p in (Path(root) / 'COMMITS').glob('*.json')}
    k = sorted(p for p in (other / 'COMMITS').glob('*.json') if p.stem not in mine)[0]
    obj = json.loads(k.read_text())
    for ref in obj['artifacts']:
        dst = Path(root) / ref['member']; dst.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(other / ref['member'], dst)
    shutil.copyfile(k, Path(root) / 'COMMITS' / k.name)


def ledger_drift(w, local, root, extra):
    p = sorted((Path(root) / 'CDT21_SUPERVISOR_LEDGER').glob('*.json'))[0]
    o = json.loads(p.read_text()); o['commit_file_sha256'] = 'D' * 64; p.write_text(json.dumps(o))


def artifact_drift(w, local, root, extra):
    log = sorted((Path(root) / 'LOGS').glob('*.log'))[0]; log.write_bytes(log.read_bytes() + b'X')


def ledger_without_commit(w, local, root, extra):
    c = sorted((Path(root) / 'COMMITS').glob('*.json'))[0]
    keep = Path(root) / 'INTERRUPTED_ATTEMPTS' / 'TEST_MOVED'; keep.mkdir(parents=True, exist_ok=True); shutil.move(str(c), str(keep / c.name))


def foreign_key_commit(w, local, root, extra):
    c = sorted((Path(root) / 'COMMITS').glob('*.json'))[0]; shutil.copyfile(c, Path(root) / 'COMMITS' / 'NOT_IN_PLAN.json')


def other_supervisor_bootstrap(w, local, root, extra):
    p = Path(root) / 'CDT21_SUPERVISOR_BOOTSTRAP.json'; o = json.loads(p.read_text()); o['supervisor_sha256'] = 'E' * 64
    p.write_text(json.dumps(o))


def v003_root_as_resume(w, local, root, extra):
    pass


def root_outside_cdt20(w, local, root, extra):
    pass


def hold_lock(w, local, root, extra):
    HOLD['proc'] = REAL_POPEN([sys.executable, '-c', 'import fcntl,sys,time;f=open(sys.argv[1],"rb");fcntl.flock(f.fileno(),fcntl.LOCK_EX);'
                               'print("held",flush=True);time.sleep(120)', str(Path(root) / 'CAMPAIGN.lock')], stdout=subprocess.PIPE)
    HOLD['proc'].stdout.readline()


HOLD = {}


def run_all():
    S1_new_run_unchanged()
    S2_safe_stop_then_resume()
    S3_abrupt_interruption_then_resume()
    S4_two_interruptions()
    S5_interrupted_closure_then_resume()
    negative('N01_v003_commit_refused', inject_v003_commit, 'RESUME_COMMIT_BOUND_TO_V003')
    negative('N02_other_candidate_commit_refused', other_candidate_commit, 'RESUME_COMMIT_NOT_BOUND_TO_V004')
    negative('N03_commit_of_other_v004_campaign_refused',
             lambda w, l, r, x: import_other_v004_commit(w, l, r, second_campaign(w, l, r)), 'COMMIT_NOT_LEDGERED')
    negative('N04_ledger_drift_refused', ledger_drift, 'LEDGER_DRIFT')
    negative('N05_artifact_drift_refused', artifact_drift, 'RESUME_COMMIT_ARTIFACT_DRIFT')
    negative('N06_ledger_without_commit_refused', ledger_without_commit, 'LEDGER_WITHOUT_COMMIT')
    negative('N07_commit_outside_plan_refused', foreign_key_commit, 'RESUME_FOREIGN_COMMIT')
    negative('N08_root_of_other_supervisor_refused', other_supervisor_bootstrap, 'RESUME_BOOTSTRAP_BINDING')
    negative('N09_v003_root_refused', v003_root_as_resume, 'RESUME_BOOTSTRAP_BINDING',
             resume_path=lambda w, l, r: str(l / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791'))
    negative('N10_root_outside_cdt20_refused', root_outside_cdt20, 'RESUME_ROOT_LOCATION',
                  resume_path=lambda w, l, r: (shutil.copytree(r, w / 'ELSEWHERE' / Path(r).name), str(w / 'ELSEWHERE' / Path(r).name))[1])
    negative('N11_lock_held_by_live_process_refused', hold_lock, 'QUAL_campaign_lock_free')
    if HOLD.get('proc'):
        HOLD['proc'].kill(); HOLD['proc'].wait()
    def live(ident):
        raise RuntimeError('OWNER_OR_CHILD_LIVE')
    DEAD['fn'] = live
    negative('N12_prior_process_alive_refused', lambda *a: None, 'OWNER_OR_CHILD_LIVE')
    DEAD['fn'] = lambda ident: dict(ident, observation='ABSENT')
    # N13: a NEW-run qualification cannot admit a resume, nor a resume qualification of root A a resume of root B.
    w, local, r1, root = stopped_campaign('N13', STUB_STOP_AFTER=5)
    rq = launch(w)  # new-run Q + E (complete) in LOG_01 -> use its Q for a resume
    r = launch(w, resume=root, qual=rq['log'] / 'QUALIFICATION_RESULT.json', skip_q=True)
    check('N13a_new_run_q_cannot_admit_resume', r['e_code'] == 2 and has(r, 'QUALIFICATION_OTHER_RUN'), blockers(r)[:1])
    rqa = launch(w, resume=root, stub_env={'STUB_STOP_AFTER': '1'})  # resume A stops again
    rb = launch(w, resume=own_root(rq), qual=rqa['log'] / 'QUALIFICATION_RESULT.json', skip_q=True)
    check('N13b_resume_q_of_root_a_cannot_admit_root_b', rb['e_code'] == 2 and has(rb, 'QUALIFICATION_OTHER_RUN'), blockers(rb)[:1])
    # N14: state of the root changed between Q and E (a commit added) -> refused by the foreign digest.
    w, local, r1, root = stopped_campaign('N14', STUB_STOP_AFTER=5)
    n = len(list(w.glob('LOG_*'))); log = w / ('LOG_%02d' % n); stage = w / ('STAGE_%02d' % n); log.mkdir(); stage.mkdir()
    base = ['--package', str(pkg), '--review', str(review), '--log-dir', str(log), '--stage', str(stage), '--resume-root', root]
    run_main(base + ['--qualify-only'])
    (Path(root) / 'LOGS' / 'LATE.log').write_text('late')
    code = run_main(base + ['--require-qualification', str(log / 'QUALIFICATION_RESULT.json')])
    e = json.loads((log / 'SUPERVISOR_RESULT.json').read_text())
    check('N14_root_changed_between_q_and_e_refused', code == 2 and any('FOREIGN_ROOTS_CHANGED_SINCE_QUALIFICATION' in b for b in e['blockers'])
          and 'foreign_roots_difference' in e, e['blockers'][:1])
    # N15: a new run that sees a REUSE_COMMITTED line is still refused.
    w, local = env('N15')
    r = launch(w, stub_env={'STUB_FAKE_REUSE': '1'})
    check('N15_new_run_still_refuses_reuse', r['e_code'] == 3 and has(r, 'NEW_RUN_REUSED_A_COMMIT'), blockers(r)[:1])
    # N16: during a resume, another pre-existing root changes -> refused.
    w, local, r1, root = stopped_campaign('N16', STUB_STOP_AFTER=5)
    n = len(list(w.glob('LOG_*'))); log = w / ('LOG_%02d' % n); stage = w / ('STAGE_%02d' % n); log.mkdir(); stage.mkdir()
    base = ['--package', str(pkg), '--review', str(review), '--log-dir', str(log), '--stage', str(stage), '--resume-root', root]
    run_main(base + ['--qualify-only'])
    real_popen_init = HookPopen.__init__
    def touching(self, cmd, *a, **kw):
        (local / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791' / 'LIVE_STATUS.json').open('ab').write(b' ')
        real_popen_init(self, cmd, *a, **kw)
    HookPopen.__init__ = touching
    try:
        code = run_main(base + ['--require-qualification', str(log / 'QUALIFICATION_RESULT.json')])
    finally:
        HookPopen.__init__ = real_popen_init
    e = json.loads((log / 'SUPERVISOR_RESULT.json').read_text())
    check('N16_other_root_changed_during_resume_refused', code == 3 and any('FOREIGN_ROOT_CHANGED:run/R08_Q1_20261020210605' in b for b in e['blockers'])
          and 'foreign_roots_difference' in e, e['blockers'][:1])


run_all()
doc = {'schema': 'CDT21_G5_V004_R3_RESUME_QUALIFICATION_V001', 'mutant': MUTANT, 'supervisor_sha256': SUP_SHA,
       'substitutions': [o.strip()[:80] for o, _ in SUBS], 'stand_ins': ['IsUserAnAdmin', 'volume_filesystem', 'SupervisorJob', 'msvcrt(flock)',
       'R.dead census', 'native_b2d', 'new-unit execution (stub_campaign.py; reuse via frozen run_unit)', 'PRE_G06_COMPLETENESS.close'],
       'campaign_child_runs': HOOK['campaign_calls'], 'passed': sum(c['pass'] for c in results), 'total': len(results), 'cases': results}
Path(out).write_text(json.dumps(doc, indent=1, default=str), encoding='utf-8')
print('R3_RESUME', MUTANT or 'ORIGINAL', doc['passed'], '/', doc['total'], [c['case'] for c in results if not c['pass']])
