"""Linux regression sweep: every test module of an extracted FINAL package, each in its own interpreter.

Usage: python -I sweep.py <python3.14> <final zip> <work dir> <out.json>
The package is extracted fresh (tested bytes == packaged bytes); each module runs with -I -B from a neutral cwd.
Windows-only modules fail or skip here by design: the sweep is compared V004 vs V005 file by file, never read alone.
"""
import concurrent.futures
import hashlib
import json
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

py, zp, work, out = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
if work.exists():
    shutil.rmtree(work)
work.mkdir(parents=True)
with zipfile.ZipFile(zp) as z:
    z.extractall(work)
impl = work / 'implementation_v001'
mods = sorted(p for p in impl.rglob('*.py') if '__pycache__' not in p.parts and
              (p.name.startswith('test') or p.name == 'adapter_tests.py') and 'fixtures' not in p.parts)


def run(p):
    try:
        cp = subprocess.run([py, '-I', '-B', str(p)], cwd=str(work), capture_output=True, text=True, timeout=900)
        text = cp.stdout + cp.stderr; code = cp.returncode
    except subprocess.TimeoutExpired:
        text, code = 'TIMEOUT', -1
    ran = re.findall(r'(?m)^Ran (\d+) tests?', text)
    last = [l for l in text.strip().splitlines() if l.startswith(('OK', 'FAILED', 'NO TESTS RAN'))]
    fails = re.findall(r'(?m)^(?:FAIL|ERROR): (\S+)', text)
    return p.relative_to(impl).as_posix(), {'exit': code, 'ran': int(ran[-1]) if ran else 0, 'summary': last[-1] if last else text.strip()[-160:],
                                            'failing': sorted(set(fails))}


with concurrent.futures.ThreadPoolExecutor(4) as ex:
    res = dict(ex.map(run, mods))
doc = {'schema': 'CDT21_LINUX_SWEEP_V001', 'package': zp.name, 'package_sha256': hashlib.sha256(zp.read_bytes()).hexdigest().upper(),
       'python': subprocess.run([py, '-c', 'import sys;print(sys.version)'], capture_output=True, text=True).stdout.strip(),
       'modules': len(res), 'results': res}
out.write_text(json.dumps(doc, indent=1, sort_keys=True), encoding='utf-8')
shutil.rmtree(work)
print(zp.name, len(res), 'modules', sum(r['ran'] for r in res.values()), 'tests run')
