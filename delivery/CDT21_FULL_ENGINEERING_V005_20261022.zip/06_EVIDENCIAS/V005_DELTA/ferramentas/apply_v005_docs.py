"""CDT21 V005: operator documents of the FULL chain aligned with the code that consumes them.

Usage: python -I apply_v005_docs.py <work root>
GAP-11  TEMPLATE_B06_VERDICT.txt: the same verdict file is parsed by B07_TECHNICAL_PRODUCER.parse_verdict and by the
        frozen engine _d4r_parse_verdict (one header line TICKSTORE_D4_RESUMABLE_CODE_DELTA_REVIEW_V002R22 and EXACTLY the
        REVIEW_CHECKS keys + 5 digests); the V004 template had free-text lines that the D4 parser refuses.
GAP-06  TEMPLATE_D4_POLICY_ADMISSION_RECEIPT.json: the origin-issued receipt consumed by D4_FIRST_ADMISSION_TRANSACTION.
        validate_gates and the engine (no producer exists in code by design: it is an origin decision record).
GAP-07  procedure step 1: the admitted G5 contract is V003 (G5_FINAL_COMPLETENESS_PRODUCER on the OPERATIONAL instance).
GAP-04  procedure step 8b: V002R24 names and the single successor identity.
GAP-05  procedure: the D4 predecessor observation contract (native, fresh <= 300 s) made explicit.
"""
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]) / 'implementation_v001'
PROC = ROOT / 'procedures'

VERDICT = """TICKSTORE_D4_RESUMABLE_CODE_DELTA_REVIEW_V002R22
VERDICT=<PASS|FAIL>
INDEPENDENT_REVIEW=YES
TESTED_CODE_EQUALS_PACKAGED_CODE=<YES|NO>
CANDIDATE_RELEASE_FUSE_ONLY=<PASS|FAIL>
CERTIFY_SCRATCH_FINAL_SEMANTICS_PRESERVED=<YES|NO>
RESUME_ATTESTATION_AUTHORITY=<PASS|FAIL>
RUNTIME_IDENTITY_BINDING=<PASS|FAIL>
CHECKPOINT_ATOMIC_DURABLE=<PASS|FAIL>
CHECKPOINT_RECONCILIATION=<PASS|FAIL>
COMMITTED_REVALIDATION=<PASS|FAIL>
SAFE_STOP_COOPERATIVE=<PASS|FAIL>
EFFECTFUL_WRAPPER_D4_ONLY=<PASS|FAIL>
RESUME_CHUNK_UNIT=<DATE_KEY|...>
AUTO_KILL_DELTA=<NO|YES>
RUN_AUTHORITY_SINGLE_ATOMIC_FILE=<PASS|FAIL>
CTRL_C_STOP_DURABLE=<PASS|FAIL>
LONG_RUNNER_OBSERVABILITY=<PASS|FAIL>
POLICY_ADMISSION_BINDING=<PASS|FAIL>
SUPPORT_TOPOLOGY_REPRODUCIBLE=<PASS|FAIL>
NESTED_EXIT_PROPAGATION=<PASS|FAIL>
THREAD_ROUTING_IDENTITY=<PASS|FAIL>
D4_RESUME_AUTHORIZED=<YES|NO>
D5_AUTHORIZED=NO
FULL_AUTHORIZED=NO
CRITICAL_FINDINGS=<n>
MAJOR_FINDINGS=<n>
REVIEW_PACK_SHA256=<hex>
BASE_RELEASE_SHA256=<hex>
SUCCESSOR_RELEASE_SHA256=<hex>
SUCCESSOR_CANDIDATE_SHA256=<hex>
EFFECTFUL_WRAPPER_SHA256=<hex>
"""

POLICY = """{
 "schema": "TICKSTORE_D4_POLICY_ADMISSION_RECEIPT_V001",
 "status": "<PASS|FAIL>",
 "issuer": "CHATGPT_ORIGIN",
 "template_only_issued_by_the_origin": true,
 "project": "PEGASUS_TICKSTORE",
 "thread": "Compress\\u00e3o De Ticks 7",
 "effect_scope": "D4_ONLY",
 "active_master_sha256": "<hex da captura verificada>",
 "active_head_sha256": "<hex da captura verificada>",
 "active_revision_id": "<revisao da captura verificada>",
 "origin_policy_reconciliation_sha256": "<hex da reconciliacao corrente da origem>",
 "policy_source_cardinality": "PASS_1_MASTER_PLUS_1_HEAD",
 "policy_head_state": "FROZEN",
 "material_delta_reconciled": "<YES|NO>",
 "material_delta_blocks_execution": "<NO|YES>",
 "artifact_base_master_sha256": "C7697B1798A02DF2CF128B2A28247182C8D36A9924C52A0844BCDDE66B956AE1",
 "review_pack_sha256": "<hex do pacote de revisao D4>",
 "review_verdict_sha256": "<hex do veredito B06 (mesmo arquivo do recibo B07)>",
 "effectful_wrapper_sha256": "<hex de control\\\\60_EFFECTFUL_WRAPPER_RELEASE.ps1 do FINAL>"
}
"""

SECTION = """

## CDT21 V005 — correções de integração da cadeia (prevalecem sobre o texto acima)

Revisão integrada dos caminhos completos de execução, feita sobre os bytes do V004 e corrigida no V005 (ver `implementation_v001/README_CDT21_V005_FULL_INTEGRATION.md`).

1. **Etapa 1 (G5):** o contrato G5 admitido pelo D4 é o **V003** (`TICKSTORE_ENGINEERING_COMPLETENESS_V003`). O `G5_EVIDENCE_BUILDER.py` (V002) e a prova física da etapa 1b pertencem ao contrato V002, que foi substituído. A prova de queda de energia exigida pelo G5 V003 é a emulada (`POWERLOSS_EMULATED`, dentro da campanha G5). A queda física de energia continua `NOT_TESTED_PHYSICAL_POWERLOSS`.
   - A campanha G5 nativa (launcher `RUN_CDT21_G5_V005_*.ps1`) emite a completude de cinco partes sobre uma instância de laboratório.
   - Para a cadeia operacional, depois da etapa 2 (`INSTANCE.json` operacional), emita a completude V003 **sobre a instância operacional**, com o produtor congelado:
     `PY -I -B CAND\\control\\G5_FINAL_COMPLETENESS_PRODUCER.py --final-zip <FINAL.zip> --native-return <R08_RETURN.zip do G5> --instance <INSTANCE.json operacional> --adversarial <raiz G5\\G5_ASSEMBLY_INPUTS_*\\ADVERSARIAL.json> --out-dir <pasta nova>`.
   - O recibo de estágio G5 (etapa 3b) cita essa completude. O D4 exige que `instance_sha256` coincida com o da instância da cadeia.
2. **Etapa 4 (veredito B06):** o mesmo arquivo de veredito é lido pela B07 e pelo motor D4. Use `TEMPLATE_B06_VERDICT.txt` exatamente:
   - uma única linha de cabeçalho `TICKSTORE_D4_RESUMABLE_CODE_DELTA_REVIEW_V002R22`;
   - exatamente as chaves listadas, sem linhas livres.
3. **Etapa 8b:** o sucessor é `TICKSTORE_V004R1_D4_RESUMABLE_V002R24_PACKAGE.zip`, com identidade única `8A05E76189E63379A60E2447DAA313765D30A2EAB78EAF4E9D91AA19CBFE3E73`. A migração e o bootstrap do D4 exigem o mesmo digest no V005. O procedimento P1 identifica, somente para leitura, o arquivo físico presente. Um arquivo diferente exige decisão da origem; não se troca o pin.
4. **Etapa 9 (D4):** o `FULL_RUNNER` passa ao wrapper selado o recibo de estágio G5 e a instância da própria cadeia admitida (`-G5StageReceiptPath`, `-G5InstancePath`). O operador não os digita. O recibo D4 é publicado pelo `D4Close` sem testemunhas de nó, como exige o consumidor.
   - **Entradas emitidas pela origem:** `TICKSTORE_D4_POLICY_ADMISSION_RECEIPT_V001` (`TEMPLATE_D4_POLICY_ADMISSION_RECEIPT.json`), o pacote de revisão D4 (`revision_v38/FINAL_RUNTIME_CODE_MANIFEST.json`) e a reconciliação de política corrente.
   - **Observação nativa do predecessor** (`<EvidenceDir>\\predecessor_observer\\predecessor_evidence\\OBSERVATION.json` = `TICKSTORE_D4_PREDECESSOR_OBSERVATION_V001`, `<EvidenceDir>\\predecessor_observer\\PREDECESSOR_SYSTEM.json` = `TICKSTORE_D4_PREDECESSOR_SYSTEM_OBSERVATION_V001`, `<EvidenceDir>\\D4_ROOTS_REPORT.json` = `D4_ROOTS_EVIDENCE.py --out`):
     - deve ter no máximo 300 s no momento da admissão;
     - seu contrato está em `D4_PREDECESSOR_RECONCILIATION.reconcile` e `D4_FIRST_ADMISSION_BOOTSTRAP.fresh_predecessor`;
     - deve descrever o estado de produção real, por isso é produzida e qualificada no Windows do titular, na preparação do D4, depois da B07.
5. **Logs:** as ferramentas congeladas gravam em `C:\\Users\\silvi\\OneDrive\\Downloads\\TICKSTORE_RUNS\\<MODO>_<carimbo>_<PID>\\RUN_LOG.txt`. É uma pasta absoluta fixa, nunca derivada da pasta atual, mas está no local legado. Os executores novos (G5 V005) gravam em `C:\\Users\\silvi\\Downloads\\<FAMILIA>_RUNS\\...`.
6. **Retornos:** prova nativa → Opus; fechamento consolidado → ChatGPT (origem); B06 → Work independente.
"""

README = """# CDT21 V005 — integração FULL (sucessor mínimo do V004)

**Origem:** missão consolidada da origem (2026-10-21/22). Revisão integrada dos caminhos completos de execução sobre os bytes do V004.

**Papel:** implementador, não B06. O V004 continua congelado e preservado como pai.

## Achados corrigidos no código (runtime)

| Achado | Defeito no V004 | Correção no V005 | Teste de regressão (suíte do plano G5) |
|---|---|---|---|
| GAP-01 | `FULL_STAGE_EVIDENCE.publish` exigia testemunhas de nó (`check_proofs`) para todo estágio; o D4 não as tem. O recibo D4 nunca era publicado (`STAGE_CHECK_PROOF_EXACT_SET`). | O produtor espelha o consumidor (`FULL_RELEASE_CHAIN.validate_chain`): testemunhas só de D5 a FULL_ADMISSION; no D4 nenhuma é aceita. | `test_cdt18_stage_proof_integrated_reconcile` test_06 e test_07 |
| GAP-02 | `FULL_RUNNER.d4_command` não passava `-G5StageReceiptPath`/`-G5InstancePath`, exigidos pelo wrapper selado (`FIRST_ADMISSION_REQUIRED_INPUT_MISSING`). | Ambos vêm da cadeia admitida e são obrigatórios. | `test_operator_entry_points` test_v005_01 a test_v005_03 |
| GAP-03 | **Regressão do delta V003 (F-01/F-04):** a entrada inline mudou (9DEE7D6C → 9BFFE835), mas o launcher adaptado manteve o pin antigo. Todo lançamento adaptado parava (`ADAPTER_INLINE_ENTRY_HASH_MISMATCH`). | Pin = entrada vinculada; o binding e o `FIRST_ADMISSION_BINDING` acompanham. | test_v005_04 |
| GAP-04 | O ZIP sucessor tinha duas identidades: migração `8A05E761…`, bootstrap `CAC345D3…`. | Identidade única, a da migração RC1R1. O arquivo físico é provado no P1 (somente leitura). | test_v005_05 |
| GAP-09 | O `SOURCE_MANIFEST` dos deltas V003/V004 omitia o `RUNTIME_CODE_MANIFEST.json`, e o verificador do próprio candidato falhava (`SOURCE_EXACT_SET`). | Manifesto de fontes fechado. | `VERIFY_FULL_COMPOSITION_SOURCE_ONLY.py` |

Os 7 testes novos **falham nos bytes do V004 e passam nos do V005**. Eles estão em suítes do plano G5 congelado e, por isso, rodam nativamente na campanha G5 do V005.

## Documentos de operação corrigidos

- `TEMPLATE_B06_VERDICT.txt` (GAP-11);
- `TEMPLATE_D4_POLICY_ADMISSION_RECEIPT.json` (GAP-06);
- `PROCEDIMENTO_OPERACIONAL_GATES.md`, seção V005 (GAP-04, GAP-05, GAP-07, GAP-08).

## Não alterado, com justificativa

- **GAP-13, elevação do `D4Close`:** é decisão de projeto explícita, fixada por teste (`test_full_runner_observability_r41` test_30). O efeito alegado não foi verificado; a avaliação é nativa, no D4.
- **Documentos de status da fase CDT17** (`FULL_COMPOSITION_EVIDENCE.json`, `CDT17_FINAL_ENGINEERING_INTEGRATION_STATUS.json`, `README_FIRST.txt`): ficam como histórico. O estado vigente está neste arquivo e em `CDT21_V005_ENGINEERING_COMPLETENESS.json`.
- **Logs congelados em `OneDrive\\Downloads\\TICKSTORE_RUNS`:** a pasta é absoluta e fixa, provada nativamente. Migrá-la exigiria alterar 3 executores congelados e o teste que a fixa, sem ganho funcional.
"""

(PROC / 'TEMPLATE_B06_VERDICT.txt').write_text(VERDICT, encoding='utf-8', newline='\n')
(PROC / 'TEMPLATE_D4_POLICY_ADMISSION_RECEIPT.json').write_text(POLICY, encoding='utf-8', newline='\n')
gates = PROC / 'PROCEDIMENTO_OPERACIONAL_GATES.md'
text = gates.read_text(encoding='utf-8')
old8b = ('| 8b | Migração do pacote sucessor D4 (RC1R1, V002R22 → V002R23) | titular, no Windows | cadeia até B07; '
         '`TICKSTORE_V004R1_D4_RESUMABLE_V002R23_PACKAGE.zip` |')
new8b = ('| 8b | Migração do pacote sucessor D4 (RC1R1, V002R22 → V002R24) | titular, no Windows | cadeia até B07; '
         '`TICKSTORE_V004R1_D4_RESUMABLE_V002R24_PACKAGE.zip` (SHA-256 `8A05E761…`, ver seção V005) |')
assert text.count(old8b) == 1, '8B_ANCHOR'
text = text.replace(old8b, new8b).replace('`SUCCESSOR_PACKAGE` = V002R23;', '`SUCCESSOR_PACKAGE` = V002R24;')
assert 'V002R23' not in text
gates.write_text(text.rstrip('\n') + '\n' + SECTION, encoding='utf-8', newline='\n')
(ROOT / 'README_CDT21_V005_FULL_INTEGRATION.md').write_text(README, encoding='utf-8', newline='\n')
print('DOCS_APPLIED')
