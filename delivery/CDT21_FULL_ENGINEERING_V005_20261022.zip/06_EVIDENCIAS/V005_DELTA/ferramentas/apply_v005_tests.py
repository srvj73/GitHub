"""CDT21 V005: regression tests for the FULL-integration delta, placed in suites of the frozen G5 plan
(gate.SUITES: test_operator_entry_points.py, test_cdt18_stage_proof_integrated_reconcile.py), so that the native G5
campaign of the V005 bytes executes them natively.  test_b2c test_34 follows the new d4_command contract.

Usage: python -I apply_v005_tests.py <work root>
"""
import sys
from pathlib import Path

T = Path(sys.argv[1]) / 'implementation_v001' / 'tests'
MAIN = "\n\nif __name__ == '__main__':\n    unittest.main(verbosity=2)\n"


def insert_before_main(rel, block):
    p = T / rel
    text = p.read_text(encoding='utf-8')
    assert text.count(MAIN) == 1 and text.endswith(MAIN), ('MAIN', rel)
    p.write_text(text[:-len(MAIN)] + block + MAIN, encoding='utf-8', newline='')


OPERATOR = r'''


class CDT21V005D4Integration(unittest.TestCase):
    """CDT21 V005 FULL-integration review: the D4 path is connected in these bytes.

    GAP-02 every input the sealed wrapper requires at the first-admission boundary is supplied by FULL_RUNNER
           (the G5 stage receipt and the G5 instance come from the admitted release chain).
    GAP-03 the adapted launcher pins the inline entry that the adapter binding admits and the adapter passes.
    GAP-04 one successor-package ZIP identity for the RC1R1 migration and the D4 bootstrap.
    """
    WRAPPER = (C / 'control/60_EFFECTFUL_WRAPPER_RELEASE.ps1').read_text(encoding='utf-8')

    def command(self, **kw):
        inst = {'d4_parameters': {k: 'C:\\x\\' + k for k in runner.D4_PARAMETERS}}
        os.environ.setdefault('SystemRoot', 'C:\\Windows')
        args = dict(policy_reconciliation='C:\\rec.json', policy_reconciliation_sha256='A' * 64)
        args.update(kw)
        return runner.d4_command(inst, C, **args)

    def test_v005_01_g5_receipt_and_instance_required(self):
        for kw in ({}, {'g5_stage_receipt': 'C:\\chain\\STAGE_G5.json'}, {'g5_instance': 'C:\\chain\\INSTANCE.json'}):
            with self.assertRaisesRegex(RuntimeError, 'D4_G5_STAGE_RECEIPT_AND_INSTANCE_REQUIRED'):
                self.command(**kw)
        cmd = self.command(g5_stage_receipt='C:\\chain\\STAGE_G5.json', g5_instance='C:\\chain\\INSTANCE.json')
        self.assertEqual(cmd[cmd.index('-G5StageReceiptPath') + 1], 'C:\\chain\\STAGE_G5.json')
        self.assertEqual(cmd[cmd.index('-G5InstancePath') + 1], 'C:\\chain\\INSTANCE.json')

    def test_v005_02_command_supplies_every_input_of_the_admission_boundary(self):
        body = self.WRAPPER[self.WRAPPER.index('function Invoke-FirstAdmissionBoundary'):]
        listed = re.search(r'foreach\(\$p in @\(([^)]*)\)\)', body).group(1)
        required = [v.strip().lstrip('$') for v in listed.split(',')]
        self.assertIn('G5StageReceiptPath', required); self.assertIn('G5InstancePath', required)
        head = self.WRAPPER[self.WRAPPER.index('param ('):]
        params = set(re.findall(r'\[(?:string|switch|int)\]\$(\w+)', head[:head.index('\n)')]))
        cmd = self.command(g5_stage_receipt='C:\\g5.json', g5_instance='C:\\inst.json')
        for name in required:
            self.assertIn(name, params, name)
            self.assertIn('-' + name, cmd, name)
            self.assertTrue(cmd[cmd.index('-' + name) + 1], name)
        self.assertEqual(cmd[cmd.index('-OriginReconciliationSha256') + 1], 'A' * 64)
        self.assertIn('-FirstAdmission', cmd)
        self.assertIn('-ResumeAdmittedRun', self.command(resume=True, g5_stage_receipt='C:\\g5.json', g5_instance='C:\\i.json'))

    def test_v005_03_runner_takes_g5_files_from_the_admitted_chain(self):
        src = (C / 'control/FULL_RUNNER.py').read_text(encoding='utf-8')
        self.assertIn("g5_stage_receipt=admission.descriptor['receipts']['G5']['path']", src)
        self.assertIn("g5_instance=admission.descriptor['instance_path']", src)

    def test_v005_04_adapted_launcher_pins_the_bound_inline_entry(self):
        sha = lambda raw: hashlib.sha256(raw).hexdigest().upper()
        binding = json.loads((C / 'adapter/RUNTIME_LOCATOR_ADAPTER_BINDING.json').read_bytes())
        launch = (C / 'adapter/Launch-TickstoreBundle-Adapter.ps1').read_text(encoding='utf-8')
        pinned = re.search(r"\$ExpectedAdapterEntry='([0-9A-F]{64})'", launch).group(1)
        inline = sha((C / 'adapter/runtime_locator_inline_entry.py').read_bytes())
        self.assertEqual(pinned, binding['inline_entry_sha256'])
        self.assertEqual(pinned, inline)
        self.assertEqual(binding['adapted_launch_sha256'], sha((C / 'adapter/Launch-TickstoreBundle-Adapter.ps1').read_bytes()))
        adapter = (C / 'adapter/runtime_locator_adapter.py').read_text(encoding='utf-8')
        self.assertIn('"-AdapterEntryPath", str(inline_entry_path)', adapter)

    def test_v005_05_successor_zip_has_one_identity(self):
        mig = (C / 'control/RC1R1_SUCCESSOR_MIGRATION.py').read_text(encoding='utf-8')
        boot = (C / 'control/D4_FIRST_ADMISSION_BOOTSTRAP.py').read_text(encoding='utf-8')
        migrated = re.search(r"SUCCESSOR_ZIP_SHA256 = '([0-9A-F]{64})'", mig).group(1)
        pins = re.findall(r"reads\.read\(a\.package_zip,'([0-9A-F]{64})'\)", boot)
        self.assertEqual(pins, [migrated])
        first = json.loads((C / 'control/FIRST_ADMISSION_BINDING.json').read_bytes())
        self.assertEqual(first['bootstrap_sha256'], hashlib.sha256((C / 'control/D4_FIRST_ADMISSION_BOOTSTRAP.py').read_bytes()).hexdigest().upper())
        self.assertEqual(first['runtime_binding_sha256'],
                         hashlib.sha256((C / 'adapter/RUNTIME_LOCATOR_ADAPTER_BINDING.json').read_bytes()).hexdigest().upper())'''

STAGE = r'''

    # CDT21 V005 (GAP-01): the D4 stage receipt is publishable, carries no node witness, and the chain admits it.
    def _d4_fixture(self, d):
        base = pathlib.Path(d); out = base / 'out'; out.mkdir()
        evidence = []
        for name in ('CHECKPOINT.json', 'SCRATCH_CERT.json', 'RUN_AUTHORITY.json'):
            p = base / name; p.write_bytes(canonical({'fixture': name})); evidence.append({'path': str(p), 'sha256': sha(p.read_bytes())})
        def read(path, expected):
            raw = pathlib.Path(path).read_bytes()
            if sha(raw) != expected: raise Blocked('MISMATCH')
            return raw
        def writer(path, raw):
            with open(path, 'xb') as f: f.write(raw); f.flush()
        from types import SimpleNamespace
        admission = SimpleNamespace(descriptor={'code_manifest_sha256': 'A' * 64, 'instance_sha256': 'B' * 64,
                                                'receipts': {s: {'path': s, 'sha256': 'C' * 64} for s in ('G5', 'B06', 'B07')}},
                                    receipt_sha='C' * 64, read=read, revalidate=lambda: None)
        return out, evidence, admission, writer

    def test_06_d4_receipt_publishes_without_node_witness_and_chain_admits_it(self):
        from FULL_STAGE_EVIDENCE import publish
        with tempfile.TemporaryDirectory() as d:
            out, evidence, admission, writer = self._d4_fixture(d)
            chain_path, chain_sha = publish('D4', admission, out, writer, {'STATE_AFTER.json': b'{}\n'}, evidence,
                                            checks={k: True for k in REQUIRED_CHECKS['D4']}, extra={'state_after_sha256': sha(b'{}\n')})
            raw = (out / 'STAGE_D4.json').read_bytes(); receipt = json.loads(raw)
            self.assertEqual(receipt['check_proofs'], {})
            self.assertEqual(json.loads(chain_path.read_bytes())['receipts']['D4']['sha256'], sha(raw))
            rows, hashes, prev = {}, {}, None
            for stage in ('G5', 'B06', 'B07'):
                ob = {'schema': 'TICKSTORE_STAGE_RECEIPT_V001', 'stage': stage, 'status': 'PASS', 'environment': 'WINDOWS_PRODUCTION',
                      'code_manifest_sha256': 'A' * 64, 'instance_sha256': 'B' * 64, 'previous_receipt_sha256': prev, 'blockers': [],
                      'checks': {k: True for k in REQUIRED_CHECKS[stage]}, 'evidence': [{'path': 'x', 'sha256': 'E' * 64}]}
                if stage == 'G5': ob['full_candidate_completeness'] = 'PASS'
                if stage == 'B06': ob.update(reviewer='independent', implementation_participant=False)
                rows[stage] = ob; hashes[stage] = 'C' * 64; prev = 'C' * 64
            rows['D4'] = receipt; hashes['D4'] = sha(raw)
            self.assertEqual(validate_chain(rows, hashes, code_sha='A' * 64, instance_sha='B' * 64, b06_sha='C' * 64, until='D4'), sha(raw))

    def test_07_d4_refuses_invented_witnesses_and_d5_still_requires_them(self):
        from FULL_STAGE_EVIDENCE import publish
        with tempfile.TemporaryDirectory() as d:
            out, evidence, admission, writer = self._d4_fixture(d)
            invented = {k: {'node': 'D4', 'path': evidence[0]['path'], 'sha256': evidence[0]['sha256']} for k in REQUIRED_CHECKS['D4']}
            with self.assertRaisesRegex(RuntimeError, 'STAGE_CHECK_PROOF_EXACT_SET'):
                publish('D4', admission, out, writer, {}, evidence, checks={k: True for k in REQUIRED_CHECKS['D4']}, check_proofs=invented)
            with self.assertRaisesRegex(RuntimeError, 'STAGE_CHECK_PROOF_EXACT_SET'):
                publish('D5', admission, out, writer, {}, evidence, checks={k: True for k in REQUIRED_CHECKS['D5']})
            self.assertEqual(list(out.iterdir()), [])'''


insert_before_main('test_operator_entry_points.py', OPERATOR)
# test_cdt18: the methods join the existing Witness class (the file ends with its last method).
p = T / 'test_cdt18_stage_proof_integrated_reconcile.py'
text = p.read_text(encoding='utf-8')
tail = "\nif __name__=='__main__':unittest.main(verbosity=2)\n"
assert text.endswith(tail) and text.count(tail) == 1
text = text[:-len(tail)] + STAGE + '\n' + tail
text = text.replace('import hashlib,json,pathlib,sys,tempfile,unittest\n', 'import hashlib,json,pathlib,sys,tempfile,unittest\n', 1)
p.write_text(text, encoding='utf-8', newline='')
# test_b2c test_34 follows the d4_command contract (G5 stage receipt and instance now required).
p = T / 'test_b2c_policy_capture_binding.py'
text = p.read_text(encoding='utf-8')
old = ("        cmd = R.d4_command(inst, MERGED, policy_reconciliation='C:\\\\rec.json', policy_reconciliation_sha256='A' * 64)\n")
new = ("        cmd = R.d4_command(inst, MERGED, policy_reconciliation='C:\\\\rec.json', policy_reconciliation_sha256='A' * 64,\n"
       "                           g5_stage_receipt='C:\\\\STAGE_G5.json', g5_instance='C:\\\\INSTANCE.json')\n")
assert text.count(old) == 1, 'B2C_ANCHOR'
p.write_text(text.replace(old, new), encoding='utf-8', newline='')
print('TESTS_APPLIED')
