"""Negative control of the V005 regression tests, from fresh extractions of both ZIPs (tested bytes == packaged bytes).

Usage: python -I regression_proof.py <python3.14> <V004 zip> <V005 zip> <work dir> <out.json>
Trees: V004_WITH_V005_TESTS = V004 bytes with only the 3 changed test files overlaid from V005; V005 = V005 bytes.
  * the 7 new tests (test_operator_entry_points test_v005_01..05; test_cdt18_stage_proof_integrated_reconcile
    test_06/test_07) must FAIL on V004 and PASS on V005;
  * test_b2c_policy_capture_binding (test_34 adapted to the new d4_command contract) and test_b07_technical_producer
    import historical policy-capture fixtures that the package carries only inside
    B1_APPROVED_INPUTS/TICKSTORE_CDT16_FULL_C5R44_G5_CONTRACT_REBASED_SOURCE_ONLY_20261015.zip.  For this check the four
    fixture members are copied from that packaged archive into the scratch tree (hash-recorded, contents not read);
    the package itself is not changed.  These two modules import sibling test helpers, so they run with -B -E -s
    (script directory on sys.path) instead of -I.
"""
import hashlib
import json
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

py, z4, z5, work, out = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4]), Path(sys.argv[5])
H = lambda b: hashlib.sha256(b).hexdigest().upper()
NEW = {'tests/test_operator_entry_points.py': ['CDT21V005D4Integration.test_v005_01_g5_receipt_and_instance_required',
                                               'CDT21V005D4Integration.test_v005_02_command_supplies_every_input_of_the_admission_boundary',
                                               'CDT21V005D4Integration.test_v005_03_runner_takes_g5_files_from_the_admitted_chain',
                                               'CDT21V005D4Integration.test_v005_04_adapted_launcher_pins_the_bound_inline_entry',
                                               'CDT21V005D4Integration.test_v005_05_successor_zip_has_one_identity'],
       'tests/test_cdt18_stage_proof_integrated_reconcile.py': [
           'Witness.test_06_d4_receipt_publishes_without_node_witness_and_chain_admits_it',
           'Witness.test_07_d4_refuses_invented_witnesses_and_d5_still_requires_them']}
FIXTURE_MODULES = ['tests/test_b2c_policy_capture_binding.py', 'tests/test_b07_technical_producer.py']
CHANGED_TESTS = list(NEW) + ['tests/test_b2c_policy_capture_binding.py']
ARCHIVE = 'B1_APPROVED_INPUTS/TICKSTORE_CDT16_FULL_C5R44_G5_CONTRACT_REBASED_SOURCE_ONLY_20261015.zip'
LINE = re.compile(r'(?m)^(test_\w+) \([^)]*\)[^\n]*?\.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$')


def run(cmd, cwd):
    cp = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True, timeout=900)
    text = cp.stdout + cp.stderr
    return {'exit': cp.returncode, 'tests': dict(LINE.findall(text)),
            'summary': ([l for l in text.splitlines() if l.startswith(('OK', 'FAILED'))] or [text.strip()[-200:]])[-1]}


if work.exists():
    shutil.rmtree(work)
doc = {'schema': 'CDT21_V005_REGRESSION_NEGATIVE_CONTROL_V002', 'trees': {}}
for label, zp in (('V004_WITH_V005_TESTS', z4), ('V005', z5)):
    root = work / label; root.mkdir(parents=True); impl = root / 'implementation_v001'
    with zipfile.ZipFile(zp) as z:
        z.extractall(root)
    overlay = {}
    if label.startswith('V004'):
        with zipfile.ZipFile(z5) as z:
            for rel in CHANGED_TESTS:
                data = z.read('implementation_v001/' + rel); (impl / rel).write_bytes(data); overlay[rel] = H(data)
    fixtures = {}
    with zipfile.ZipFile(impl / ARCHIVE) as z:
        for n in z.namelist():
            if '/tests/fixtures/R40_CAPTURE_NON_AUTHORITATIVE/' in n or '/tests/fixtures/V38_CAPTURE_HISTORICAL/' in n:
                rel = n.split('implementation_v001/', 1)[1]; data = z.read(n)
                assert not (impl / rel).exists(), rel  # the packaged tree does not carry them
                (impl / rel).parent.mkdir(parents=True, exist_ok=True); (impl / rel).write_bytes(data); fixtures[rel] = H(data)
    res = {}
    for rel, names in NEW.items():
        res[rel] = run([py, '-I', '-B', str(impl / rel), '-v'] + names, root)
    for rel in FIXTURE_MODULES:
        res[rel] = run([py, '-B', '-E', '-s', str(impl / rel), '-v'], root)
    doc['trees'][label] = {'zip': zp.name, 'zip_sha256': H(zp.read_bytes()), 'overlaid_test_files_from_v005': overlay,
                           'fixtures_copied_from_packaged_archive': {'archive': ARCHIVE, 'archive_sha256': H((impl / ARCHIVE).read_bytes()), 'files': fixtures},
                           'results': res}
doc['python'] = subprocess.run([py, '-c', 'import sys;print(sys.version)'], capture_output=True, text=True).stdout.strip()
v4 = doc['trees']['V004_WITH_V005_TESTS']['results']; v5 = doc['trees']['V005']['results']
new = [(rel, n.split('.')[-1]) for rel, ns in NEW.items() for n in ns]
b2c, b07 = 'tests/test_b2c_policy_capture_binding.py', 'tests/test_b07_technical_producer.py'
bad = lambda r: sorted(t for t, s in r['tests'].items() if s != 'ok')
doc['summary'] = {
    'new_tests': len(new),
    'new_tests_fail_on_v004': sum(v4[r]['tests'].get(t) in ('FAIL', 'ERROR') for r, t in new),
    'new_tests_pass_on_v005': sum(v5[r]['tests'].get(t) == 'ok' for r, t in new),
    'b2c_test_34_adapted': {'v004_bytes': v4[b2c]['tests'].get('test_34_d4_dispatch_requires_current_reconciliation'),
                            'v005_bytes': v5[b2c]['tests'].get('test_34_d4_dispatch_requires_current_reconciliation')},
    'b2c_not_ok_v004': bad(v4[b2c]), 'b2c_not_ok_v005': bad(v5[b2c]),
    # tests 30-33 predate the G5 V003 contract: same result on both trees (not touched by V005)
    'b2c_preexisting_identical_on_both': sorted(set(bad(v4[b2c])) - {'test_34_d4_dispatch_requires_current_reconciliation'}) == bad(v5[b2c]),
    'b07_technical_producer_v004': v4[b07]['summary'], 'b07_technical_producer_v005': v5[b07]['summary']}
s = doc['summary']
doc['pass'] = (s['new_tests_fail_on_v004'] == len(new) and s['new_tests_pass_on_v005'] == len(new)
               and s['b2c_test_34_adapted']['v005_bytes'] == 'ok' and s['b2c_preexisting_identical_on_both']
               and v5[b07]['exit'] == 0)
out.write_text(json.dumps(doc, indent=1, sort_keys=True), encoding='utf-8')
shutil.rmtree(work)
print('REGRESSION_NEGATIVE_CONTROL', doc['pass'], json.dumps(s))
