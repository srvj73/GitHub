"""CDT21 V005: freeze the V005 successor from the edited tree; never touches the V004 parent.

Usage: python -I build_v005.py <work root> <V004 zip> <output zip> <installer witness out>
Writes the delta patch, delta receipt and engineering completeness record into the tree, regenerates
RUNTIME_CODE_MANIFEST, SOURCE_MANIFEST (closed: every implementation file but itself, RUNTIME_CODE_MANIFEST included,
GAP-09) and PACKAGE_MANIFEST, writes a deterministic ZIP, verifies it with the project's own verify_final_zip and its
own VERIFY_FULL_COMPOSITION_SOURCE_ONLY reader, and writes the installer witness (TICKSTORE_FINAL_PACKAGE_WITNESS_V001).
"""
import difflib
import hashlib
import importlib.util
import io
import json
import subprocess
import sys
import zipfile
from pathlib import Path

WORK, PARENT_ZIP, OUT, WITNESS = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
IMPL = WORK / 'implementation_v001'
CAND = IMPL / 'candidate'
PARENT_SHA = 'AD33486954F1248AF28A78677377E83AB979AB86EDD5F71F5B7D108CBA8F99DD'
PARENT_CODE_SHA = 'D2C626FD2819B86D472433CB2B26C6688B1688E5E5474402162B67C5048666FF'
STAMP = (2026, 10, 22, 12, 0, 0)


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def compact(obj):
    return (json.dumps(obj, sort_keys=True, separators=(',', ':')) + '\n').encode('ascii')


parent_raw = PARENT_ZIP.read_bytes()
assert sha(parent_raw) == PARENT_SHA, 'PARENT_SHA'
parent = zipfile.ZipFile(io.BytesIO(parent_raw))
pmembers = {n: parent.read(n) for n in parent.namelist() if not n.endswith('/')}
assert sha(pmembers['implementation_v001/RUNTIME_CODE_MANIFEST.json']) == PARENT_CODE_SHA, 'PARENT_CODE_SHA'

DELTA = ['implementation_v001/CDT21_V005_DELTA.patch', 'implementation_v001/CDT21_V005_DELTA_RECEIPT.json',
         'implementation_v001/CDT21_V005_ENGINEERING_COMPLETENESS.json']
GENERATED = {'PACKAGE_MANIFEST.json', 'implementation_v001/SOURCE_MANIFEST.json', 'implementation_v001/RUNTIME_CODE_MANIFEST.json', *DELTA}
REGENERATED_FROM_PARENT = {'PACKAGE_MANIFEST.json', 'implementation_v001/SOURCE_MANIFEST.json',
                           'implementation_v001/RUNTIME_CODE_MANIFEST.json'}


def tree():
    out = {}
    for p in sorted(WORK.rglob('*')):
        if p.is_file():
            rel = p.relative_to(WORK).as_posix()
            assert '__pycache__' not in rel and not rel.endswith('.pyc'), rel
            if rel not in GENERATED:
                out[rel] = p.read_bytes()
    return out


cur = tree()
modified = sorted(n for n in cur if n in pmembers and cur[n] != pmembers[n])
added = sorted(n for n in cur if n not in pmembers)
removed = sorted(n for n in pmembers if n not in cur and n not in REGENERATED_FROM_PARENT)
assert not removed, removed
EXPECTED_MODIFIED = ['implementation_v001/candidate/adapter/Launch-TickstoreBundle-Adapter.ps1',
                     'implementation_v001/candidate/adapter/RUNTIME_LOCATOR_ADAPTER_BINDING.json',
                     'implementation_v001/candidate/control/D4_FIRST_ADMISSION_BOOTSTRAP.py',
                     'implementation_v001/candidate/control/FIRST_ADMISSION_BINDING.json',
                     'implementation_v001/candidate/control/FULL_RUNNER.py',
                     'implementation_v001/candidate/control/FULL_STAGE_EVIDENCE.py',
                     'implementation_v001/procedures/PROCEDIMENTO_OPERACIONAL_GATES.md',
                     'implementation_v001/procedures/TEMPLATE_B06_VERDICT.txt',
                     'implementation_v001/tests/test_b2c_policy_capture_binding.py',
                     'implementation_v001/tests/test_cdt18_stage_proof_integrated_reconcile.py',
                     'implementation_v001/tests/test_operator_entry_points.py']
EXPECTED_ADDED = ['implementation_v001/README_CDT21_V005_FULL_INTEGRATION.md',
                  'implementation_v001/procedures/TEMPLATE_D4_POLICY_ADMISSION_RECEIPT.json']
assert modified == EXPECTED_MODIFIED, modified
assert added == EXPECTED_ADDED, added

patch = []
for n in modified + added:
    a = pmembers.get(n, b'').decode('utf-8').splitlines(keepends=True)
    b = cur[n].decode('utf-8').splitlines(keepends=True)
    patch.extend(difflib.unified_diff(a, b, 'a/' + n if n in pmembers else '/dev/null', 'b/' + n))
patch_raw = ''.join(patch).encode('utf-8')
(IMPL / 'CDT21_V005_DELTA.patch').write_bytes(patch_raw)

runtime_rows = [{'bytes': len(raw), 'path': n.removeprefix('implementation_v001/candidate/'), 'sha256': sha(raw)}
                for n, raw in sorted(cur.items()) if n.startswith('implementation_v001/candidate/')]
runtime_raw = compact({'engineering_status': 'CDT21_V005_FULL_INTEGRATION_DELTA_LINUX_QUALIFIED_WINDOWS_NATIVE_G5_PENDING',
                       'files': runtime_rows, 'schema': 'TICKSTORE_FINAL_RUNTIME_CODE_MANIFEST_V001'})
(IMPL / 'RUNTIME_CODE_MANIFEST.json').write_bytes(runtime_raw)
code_sha = sha(runtime_raw)

UNCHANGED = ['recovery/TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1', 'recovery/modules/orchestrator.py',
             'recovery/engine/tickstore_publisher_recovery_v004_release.py', 'recovery/engine/tickstore_publisher_recovery_v004_candidate.py',
             'recovery/CODE_MANIFEST.json', 'recovery/99_MANIFEST_SHA256.json', 'control/60_EFFECTFUL_WRAPPER_RELEASE.ps1',
             'control/FULL_STAGE_CONTINUATION.py', 'control/FULL_D4_CLOSURE.py', 'control/FULL_RELEASE_CHAIN.py',
             'control/QUALIFICATION_CONTRACT.json', 'control/RC1R1_SUCCESSOR_MIGRATION.py', 'control/D4_FIRST_ADMISSION_TRANSACTION.py',
             'control/D4_FIRST_ADMISSION_PREP.py', 'control/FULL_G5_COMPLETE_PROOF_GATE.py', 'control/G5_FINAL_COMPLETENESS_PRODUCER.py',
             'control/INSTALL_TICKSTORE_FULL.ps1', 'control/RUN_TICKSTORE_FULL.ps1', 'menu/MENU.py',
             'adapter/runtime_locator_adapter.py', 'adapter/runtime_locator_inline_entry.py', 'adapter/runtime_locator_orchestrator_entry.py',
             'adapter/INLINE_ROOT_LOADER_V004_R1R1_ADAPTER.ps1', 'g5proof/PRE_G06_CAMPAIGN.py', 'g5proof/PRE_G06_COMPLETENESS.py',
             'g5proof/PRE_G06_CONSUMER_REVIEW.json', 'full/tickstore_full_multiwork.py', 'full/tickstore_serial_runner.py',
             'full/FULL_CRASH_RECOVERY.py', 'full/FULL_PROCESS_CONTROL.py']
for p in UNCHANGED:
    assert cur['implementation_v001/candidate/' + p] == pmembers['implementation_v001/candidate/' + p], p
history = ['implementation_v001/CDT21_F01R1_DELTA.patch', 'implementation_v001/CDT21_V004_DELTA_RECEIPT.json',
           'implementation_v001/CDT21_V004_ENGINEERING_COMPLETENESS.json', 'implementation_v001/README_CDT21_V004_F01R1.md',
           'implementation_v001/CDT21_F01_F04_DELTA.patch', 'implementation_v001/CDT21_V003_DELTA_RECEIPT.json']
for n in history:
    assert cur[n] == pmembers[n], n
receipt = {
    'schema': 'TICKSTORE_CDT21_V005_DELTA_RECEIPT_V001',
    'successor_label': 'V005', 'parent_label': 'V004', 'parent_final_package_sha256': PARENT_SHA,
    'parent_runtime_code_manifest_sha256': PARENT_CODE_SHA, 'runtime_code_manifest_sha256': code_sha,
    'origin': 'MISSAO_CONSOLIDADA_FULL_DE_ENGENHARIA (2026-10-21/22): integrated review of the complete execution paths',
    'findings_closed_in_code': {
        'GAP-01': 'D4 stage receipt unpublishable: FULL_STAGE_EVIDENCE.publish demanded node witnesses for D4; now mirrors validate_chain',
        'GAP-02': 'FULL_RUNNER D4 dispatch omitted -G5StageReceiptPath/-G5InstancePath required by the sealed wrapper; now from the admitted chain',
        'GAP-03': 'regression of the V003 delta: adapted launcher pinned the pre-V003 inline entry (9DEE7D6C); now the bound entry 9BFFE835',
        'GAP-04': 'two identities for the successor ZIP (migration 8A05E761, bootstrap CAC345D3); one identity (the migration one)',
        'GAP-09': 'SOURCE_MANIFEST omitted RUNTIME_CODE_MANIFEST.json since the V003 build; closed set restored'},
    'documents_aligned': {'GAP-04': 'procedure step 8b V002R24', 'GAP-05': 'predecessor observation contract in the procedure',
                          'GAP-06': 'TEMPLATE_D4_POLICY_ADMISSION_RECEIPT.json', 'GAP-07': 'G5 V003 completeness on the operational instance',
                          'GAP-11': 'TEMPLATE_B06_VERDICT.txt accepted by both parsers'},
    'not_changed': {'GAP-13': 'D4Close non-elevation is an explicit design decision pinned by test_full_runner_observability_r41 test_30; unverified effect',
                    'GAP-08': 'frozen fixed absolute log root kept (natively proven; pinned by test_32)'},
    'modified': [{'path': n, 'pre_sha256': sha(pmembers[n]), 'post_sha256': sha(cur[n]),
                  'pre_bytes': len(pmembers[n]), 'post_bytes': len(cur[n])} for n in modified],
    'added': [{'path': n, 'sha256': sha(cur[n]), 'bytes': len(cur[n])} for n in added],
    'generated': sorted(GENERATED - {'PACKAGE_MANIFEST.json'}),
    'patch': {'path': 'implementation_v001/CDT21_V005_DELTA.patch', 'sha256': sha(patch_raw)},
    'unchanged_runtime_files': {p: sha(cur['implementation_v001/candidate/' + p]) for p in UNCHANGED},
    'v004_v003_history_unchanged': {n: sha(cur[n]) for n in history},
    'regression_tests_in_frozen_g5_plan': ['SUITE_test_operator_entry_points.py: CDT21V005D4Integration test_v005_01..05',
                                           'SUITE_test_cdt18_stage_proof_integrated_reconcile.py: Witness test_06, test_07'],
    'g5': 'the frozen G5 contract binds the whole code manifest: V005 needs its own native campaign (procedure P1); '
          'the V004 G0 native PASS (164 tests) remains valid for the V004 bytes it ran',
    'b06': 'NOT_STARTED', 'b07': 'NOT_STARTED', 'd4_d5': 'NOT_STARTED', 'canary': 'NOT_STARTED', 'full': 'NOT_STARTED',
    'production_effects': 'NONE',
}
receipt_raw = (json.dumps(receipt, indent=1, sort_keys=True) + '\n').encode('ascii')
(IMPL / 'CDT21_V005_DELTA_RECEIPT.json').write_bytes(receipt_raw)

completeness = {
    'schema': 'TICKSTORE_CDT21_V005_ENGINEERING_COMPLETENESS_V001',
    'runtime_code_manifest_sha256': code_sha, 'parent_final_package_sha256': PARENT_SHA,
    'status': 'ENGINEERING_FULL_INTEGRATION_DELTA_COMPLETE__WINDOWS_NATIVE_G5_PENDING',
    'five_part_completeness': {
        'all_implementations_integrated': {
            'status': 'PASS_SOURCE_TRACE_AND_LINUX__D4_PATH_CONNECTED_IN_CODE',
            'basis': 'integrated review of installer, activation, menu, FULL_RUNNER, admission chain G5..FULL_ADMISSION, '
                     'MULTIWORK/AUTOCPU, checkpoints, SAFE_STOP, recovery, resume, watchdog/heartbeat/ETA, final verification; '
                     'the D4 break (GAP-01/02/03/04) closed in code with regression tests'},
        'all_known_fixable_blockers_closed': {
            'status': 'PASS_IN_CODE__NATIVE_PROOF_PENDING',
            'closed': ['GAP-01', 'GAP-02', 'GAP-03', 'GAP-04', 'GAP-09', 'R3-F01 (supervisor R4)'],
            'not_internally_fixable': ['native G5 V005 campaign (owner Windows)', 'independent B06 (Work)',
                                       'origin decisions/records (G5, B07 stage, policy admission, D4 review pack)',
                                       'D4 predecessor native observation (production state, fresh at D4)']},
        'tested_equals_packaged_new_final_code': {
            'status': 'LINUX_PASS__WINDOWS_TARGET_RUNTIME_PENDING',
            'basis': 'regression tests run from the extracted final ZIP; the G5 campaign binds tested==packaged (verify_package)'},
        'frozen_for_independent_audit': {
            'status': 'FROZEN_SUCCESSOR_BYTES__B06_NOT_STARTED',
            'requires': ['native G5 V005 PASS (P1)', 'independent B06 auditor']},
        'adversarial_false_completeness_check': {
            'status': 'PASS_STATEMENTS_BOUNDED',
            'not_claimed': ['Windows native PASS of V005', 'G5 of V003/V004 transferred to V005', 'B06/B07/D4/D5/canary/FULL',
                            'D4 executed', 'physical power loss (NOT_TESTED_PHYSICAL_POWERLOSS)', 'legacy cut installed in production']},
    },
    'producer_five_part_receipt_v005': 'NOT_ISSUED_REQUIRES_NATIVE_CAMPAIGN_P1',
    'physical_powerloss': 'NOT_TESTED_PHYSICAL_POWERLOSS',
}
(IMPL / 'CDT21_V005_ENGINEERING_COMPLETENESS.json').write_bytes((json.dumps(completeness, indent=1, sort_keys=True) + '\n').encode('ascii'))

cur = tree()
cur.update({n: (WORK / n).read_bytes() for n in DELTA + ['implementation_v001/RUNTIME_CODE_MANIFEST.json']})
source_rows = [{'bytes': len(raw), 'path': n.removeprefix('implementation_v001/'), 'sha256': sha(raw)}
               for n, raw in sorted(cur.items()) if n.startswith('implementation_v001/') and n != 'implementation_v001/SOURCE_MANIFEST.json']
source_raw = compact({'file_count': len(source_rows), 'files': source_rows})
(IMPL / 'SOURCE_MANIFEST.json').write_bytes(source_raw)
cur['implementation_v001/SOURCE_MANIFEST.json'] = source_raw
package_rows = [{'bytes': len(raw), 'path': n, 'sha256': sha(raw)} for n, raw in sorted(cur.items())]
package_raw = compact({'files': package_rows, 'schema': 'TICKSTORE_FINAL_PACKAGE_MANIFEST_V001'})
(WORK / 'PACKAGE_MANIFEST.json').write_bytes(package_raw)

assert not OUT.exists(), 'OUTPUT_EXISTS'
with zipfile.ZipFile(OUT, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in [('PACKAGE_MANIFEST.json', package_raw)] + sorted(cur.items()):
        info = zipfile.ZipInfo(name, STAMP)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.create_system = 3
        info.external_attr = 0o644 << 16
        z.writestr(info, raw)
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(set(names)) == len(cur) + 1

spec = importlib.util.spec_from_file_location('cdt21_producer', CAND / 'control/G5_FINAL_COMPLETENESS_PRODUCER.py')
sys.path.insert(0, str(CAND / 'control'))
prod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prod)
vcode, vmembers = prod.verify_final_zip(OUT)
assert vcode == code_sha
comp = subprocess.run([sys.executable, '-I', '-B', str(IMPL / 'VERIFY_FULL_COMPOSITION_SOURCE_ONLY.py')], capture_output=True, text=True)
assert comp.returncode == 0 and 'COMPOSITION_SOURCE_INTEGRITY=PASS' in comp.stdout, comp.stdout
witness = {'schema': 'TICKSTORE_FINAL_PACKAGE_WITNESS_V001', 'package_name': OUT.name, 'package_sha256': sha(OUT.read_bytes()),
           'manifest_sha256': sha(package_raw), 'production_authorized': False,
           'scope': 'CDT21_V005_FULL_ENGINEERING_CANDIDATE_NOT_PRODUCTION_ADMISSION'}
WITNESS.write_bytes((json.dumps(witness, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n').encode('utf-8'))
print(json.dumps({'final_zip': str(OUT), 'final_zip_sha256': sha(OUT.read_bytes()), 'bytes': OUT.stat().st_size,
                  'members': len(names), 'runtime_code_manifest_sha256': code_sha, 'runtime_files': len(runtime_rows),
                  'source_manifest_sha256': sha(source_raw), 'source_files': len(source_rows),
                  'package_manifest_sha256': sha(package_raw), 'patch_sha256': sha(patch_raw),
                  'delta_receipt_sha256': sha(receipt_raw), 'modified': len(modified), 'added': len(added),
                  'composition_verifier': comp.stdout.strip().splitlines()[0], 'witness_sha256': sha(WITNESS.read_bytes())}, indent=1))
