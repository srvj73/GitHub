"""CDT21 V005: apply the minimal FULL-integration delta to a V004 work tree by exact, counted replacements.

Usage: python -I apply_v005_delta.py <work root holding implementation_v001/ extracted from V004>
Findings of the consolidated FULL integration review (origin mission 2026-10-21/22) closed here:
  GAP-01  FULL_STAGE_EVIDENCE.publish demanded node witnesses (check_proofs) for EVERY stage, but D4 has none
          (STAGE_CHECK_WITNESSES has no 'D4'; FULL_RELEASE_CHAIN.validate_chain requires them only for D5..FULL_ADMISSION,
          as the frozen test_cdt18 test_05 shows) and FULL_D4_CLOSURE proves its three checks physically itself:
          the D4 stage receipt could never be published (STAGE_CHECK_PROOF_EXACT_SET).  The producer now mirrors
          the consumer exactly: node witnesses for the witnessed stages, none (and none accepted) for D4.
  GAP-02  FULL_RUNNER.d4_command never passed -G5StageReceiptPath/-G5InstancePath, which the sealed wrapper requires
          (FIRST_ADMISSION_REQUIRED_INPUT_MISSING) for first admission and resume: both now come from the admitted
          release chain (receipts['G5'].path and instance_path) and are required.
  GAP-03  Regression of the V003 delta (F-01/F-04): runtime_locator_inline_entry.py changed (9DEE7D6C -> 9BFFE835)
          and the adapter binding followed, but the adapted launcher kept its internal pin 9DEE7D6C, so every adapted
          bundle launch would stop at ADAPTER_INLINE_ENTRY_HASH_MISMATCH.  The pin now equals the bound inline entry;
          the binding (adapted_launch_sha256) and FIRST_ADMISSION_BINDING (runtime_binding_sha256) follow.
  GAP-04  The D4 bootstrap pinned the successor package ZIP as CAC345D3... while the documented migration (RC1R1,
          R46 option A) installs and pins 8A05E761... for the same file: one artifact, one identity now (the
          migration's), so either both admit it or both refuse it.  The physical artifact is identified natively
          (read-only) by procedure P1; a different file requires an origin decision.  FIRST_ADMISSION_BINDING
          (bootstrap_sha256) follows.
"""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]) / 'implementation_v001'
C = ROOT / 'candidate'
V004_CODE_SHA = 'D2C626FD2819B86D472433CB2B26C6688B1688E5E5474402162B67C5048666FF'
assert hashlib.sha256((ROOT / 'RUNTIME_CODE_MANIFEST.json').read_bytes()).hexdigest().upper() == V004_CODE_SHA, 'NOT_A_V004_TREE'


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def sub(rel, old, new, count=1):
    p = C / rel
    text = p.read_text(encoding='utf-8')
    assert text.count(old) == count, ('ANCHOR', rel, old[:90])
    p.write_text(text.replace(old, new), encoding='utf-8', newline='')


# ---------------------------------------------------------------- GAP-01
sub('control/FULL_STAGE_EVIDENCE.py',
    "    require(isinstance(check_proofs, dict) and set(check_proofs) == set(checks),\n"
    "            'STAGE_CHECK_PROOF_EXACT_SET')\n",
    "    if stage in STAGE_CHECK_WITNESSES:\n"
    "        require(isinstance(check_proofs, dict) and set(check_proofs) == set(checks),\n"
    "                'STAGE_CHECK_PROOF_EXACT_SET')\n"
    "    else:\n"
    "        # CDT21 V005 (GAP-01): exactly the stages FULL_RELEASE_CHAIN.validate_chain binds to node witnesses carry\n"
    "        # them.  D4 has no orchestrator node witness: FULL_D4_CLOSURE proves its three checks physically (signed\n"
    "        # checkpoint, canary scratch certificate, closed journal) before publishing; none is invented or accepted.\n"
    "        require(stage == 'D4' and check_proofs is None, 'STAGE_CHECK_PROOF_EXACT_SET')\n"
    "        check_proofs = {}\n")

# ---------------------------------------------------------------- GAP-02
sub('control/FULL_RUNNER.py',
    "def d4_command(instance, candidate, *, resume=False, policy_reconciliation='', policy_reconciliation_sha256=''):\n",
    "def d4_command(instance, candidate, *, resume=False, policy_reconciliation='', policy_reconciliation_sha256='',\n"
    "               g5_stage_receipt='', g5_instance=''):\n")
sub('control/FULL_RUNNER.py',
    "    params = dict(params, OriginCapturePath=policy_reconciliation)\n",
    "    params = dict(params, OriginCapturePath=policy_reconciliation)\n"
    "    # CDT21 V005 (GAP-02): the sealed wrapper requires the G5 stage receipt and the G5 instance for first admission\n"
    "    # and resume; both are the admitted release chain's own files (never instance data or operator input).\n"
    "    require(isinstance(g5_stage_receipt, str) and bool(g5_stage_receipt) and isinstance(g5_instance, str)\n"
    "            and bool(g5_instance), 'D4_G5_STAGE_RECEIPT_AND_INSTANCE_REQUIRED')\n"
    "    params.update(G5StageReceiptPath=g5_stage_receipt, G5InstancePath=g5_instance)\n")
sub('control/FULL_RUNNER.py',
    "            command = d4_command(i, root, resume=a.resume, policy_reconciliation=a.policy_reconciliation,\n"
    "                                 policy_reconciliation_sha256=a.policy_reconciliation_sha256)\n",
    "            command = d4_command(i, root, resume=a.resume, policy_reconciliation=a.policy_reconciliation,\n"
    "                                 policy_reconciliation_sha256=a.policy_reconciliation_sha256,\n"
    "                                 g5_stage_receipt=admission.descriptor['receipts']['G5']['path'],\n"
    "                                 g5_instance=admission.descriptor['instance_path'])\n")

# ---------------------------------------------------------------- GAP-04 (bootstrap; binding updated below)
SUCCESSOR_ZIP = '8A05E76189E63379A60E2447DAA313765D30A2EAB78EAF4E9D91AA19CBFE3E73'
mig = (C / 'control/RC1R1_SUCCESSOR_MIGRATION.py').read_text(encoding='utf-8')
assert "SUCCESSOR_ZIP_SHA256 = '" + SUCCESSOR_ZIP + "'" in mig, 'MIGRATION_IDENTITY'
sub('control/D4_FIRST_ADMISSION_BOOTSTRAP.py',
    "        reads.read(a.package_zip,'CAC345D321E09F9126188AD93D27733452DEF8B5C8EE499597E7EC282AFD37AB')\n",
    "        # CDT21 V005 (GAP-04): the same identity the RC1R1 migration installs and verifies (one artifact, one pin).\n"
    "        reads.read(a.package_zip,'" + SUCCESSOR_ZIP + "')\n")

# ---------------------------------------------------------------- GAP-03 (launcher pin) + transitive pins
binding_path = C / 'adapter/RUNTIME_LOCATOR_ADAPTER_BINDING.json'
binding_raw = binding_path.read_bytes(); binding = json.loads(binding_raw)
dump = lambda o: (json.dumps(o, indent=2, sort_keys=True) + '\n').encode('ascii')
assert dump(binding) == binding_raw, 'BINDING_ROUND_TRIP'
inline = sha((C / 'adapter/runtime_locator_inline_entry.py').read_bytes())
assert inline == binding['inline_entry_sha256'] and inline.startswith('9BFFE8358ABB36D6'), 'INLINE_ENTRY_BINDING'
sub('adapter/Launch-TickstoreBundle-Adapter.ps1',
    "$ExpectedAdapterEntry='9DEE7D6CFD075E042CA09B51B6FB05944488CE416690F4371764F732E6EDD9ED'\n",
    "$ExpectedAdapterEntry='" + inline + "'\n")
binding['adapted_launch_sha256'] = sha((C / 'adapter/Launch-TickstoreBundle-Adapter.ps1').read_bytes())
new_binding = dump(binding); binding_path.write_bytes(new_binding)

first_path = C / 'control/FIRST_ADMISSION_BINDING.json'
first_raw = first_path.read_bytes(); first = json.loads(first_raw)
assert dump(first) == first_raw, 'FIRST_BINDING_ROUND_TRIP'
assert first['runtime_binding_sha256'] == sha(binding_raw), 'FIRST_BINDING_PARENT'
first['runtime_binding_sha256'] = sha(new_binding)
first['bootstrap_sha256'] = sha((C / 'control/D4_FIRST_ADMISSION_BOOTSTRAP.py').read_bytes())
first_path.write_bytes(dump(first))
for rel in ('control/FULL_STAGE_EVIDENCE.py', 'control/FULL_RUNNER.py', 'control/D4_FIRST_ADMISSION_BOOTSTRAP.py',
            'adapter/Launch-TickstoreBundle-Adapter.ps1', 'adapter/RUNTIME_LOCATOR_ADAPTER_BINDING.json',
            'control/FIRST_ADMISSION_BINDING.json'):
    print(rel, sha((C / rel).read_bytes()))
