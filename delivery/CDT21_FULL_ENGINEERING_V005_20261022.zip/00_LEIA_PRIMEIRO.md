# CDT21 — FULL de engenharia consolidado (V005), 2026-10-22

**Papel:** implementador (não B06). **Origem:** missão consolidada “entrega definitiva do FULL de engenharia”.

## O que é este pacote

Este é um pacote único que reúne:
- o código completo e integrado (candidato V005 congelado);
- os executores e o instalador definitivos;
- os manifestos;
- o mapa de componentes e consumidores;
- as evidências e os controles negativos;
- o MISSION_LOCK, a matriz de pré-entrega, o recibo dos cinco critérios e o estado dos gates;
- os procedimentos de execução e de recuperação.

Cada membro tem o SHA-256 registrado em `MANIFESTO.json`.

## Por que V005 e não V004

A revisão integrada percorreu os caminhos completos sobre os bytes do V004. O resultado:
- a cadeia `G5 → B06 → B07 → D4 → D5 → CANARY → FULL_PREP → FULL_ADMISSION → FULL` estava **interrompida no D4**;
  - o recibo D4 nunca era publicável (GAP-01);
  - o `FULL_RUNNER` não passava ao wrapper selado duas entradas obrigatórias (GAP-02);
- o launcher adaptado fixava uma entrada inexistente (GAP-03, regressão do meu delta V003);
- o ZIP sucessor tinha duas identidades (GAP-04).

Por isso, nenhum G5 do V004 levaria ao FULL. O V005 é o sucessor mínimo:
- 6 arquivos de runtime, 3 testes e 3 documentos de operação;
- 7 testes de regressão que falham no V004 e passam no V005;
- o V004 preservado byte a byte, com todas as suas evidências.

## Estrutura

| Pasta/arquivo | Conteúdo |
|---|---|
| `01_MISSION_LOCK.json` | escopo, achados A1–A6, candidato congelado, efeitos permitidos, proibições e rotas de retorno |
| `02_CANDIDATO_V005/` | ZIP congelado, testemunha do instalador, verificação independente (CRC, manifestos, 163 arquivos de runtime) e o verificador |
| `03_SUPERVISOR_E_LAUNCHER_G5_V005/` | supervisor e launcher G5 do V005, revisão de fonte, construtores, diffs e checagem estática |
| `04_MAPA_COMPONENTES_E_CONSUMIDORES/` | inventário integrado (V004), mapa revinculado ao V005 e decisões por GAP (01–17) |
| `05_MANIFESTOS/` | `PACKAGE_MANIFEST`, `RUNTIME_CODE_MANIFEST`, `SOURCE_MANIFEST`, recibo e patch do delta e completude V005 |
| `06_EVIDENCIAS/` | delta V005 (controle negativo, varreduras, composição), qualificação do supervisor V005, R4 (A1) e histórico da linha V004 |
| `07_MATRIZ_PRE_ENTREGA.json` | linhas por item da missão e achados A1–A6 |
| `08_RECIBO_CINCO_CRITERIOS.json` | recibo vinculante do implementador (não é B06 nem o recibo do produtor congelado) |
| `09_ESTADO_DOS_GATES.json` | estado explícito de cada gate ainda não executado |
| `10_PROCEDIMENTOS/` | P1 (G5 nativo), P2 (recuperação), P3 (após G5 e despacho B06), P4 (gates até o FULL) |

## Próximo passo único

Executar o **P1** no Windows do titular e enviar o retorno **diretamente ao Opus**. Até lá:
- o G5 do V005 é `NOT_STARTED`;
- a B06 continua reservada ao Work independente;
- nenhum gate produtivo é executado.
