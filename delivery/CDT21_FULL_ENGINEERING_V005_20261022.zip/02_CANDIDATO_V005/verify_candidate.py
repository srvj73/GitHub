"""Independent read-only verification of a frozen candidate ZIP (no candidate code is executed).

Usage: python -I verify_candidate.py <CDT21_FINAL_PACKAGE_V00x.zip> <extracted_dir> <out.json> <package sha256> <package manifest sha256> <runtime code manifest sha256>
Checks: ZIP CRC; no duplicate or unsafe member names; PACKAGE_MANIFEST.json lists every other member exactly once with
the right size and SHA-256; RUNTIME_CODE_MANIFEST.json entries resolve to members with the right SHA-256; the SHA-256
of PACKAGE_MANIFEST.json and RUNTIME_CODE_MANIFEST.json equal the pins used by the supervisor; and the extracted tree
used for the integration review is byte-identical to the ZIP.
"""
import hashlib
import json
import sys
import zipfile
from pathlib import Path, PurePosixPath

zp, ext, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
H = lambda b: hashlib.sha256(b).hexdigest().upper()
PINS = dict(zip(('package_sha256', 'package_manifest_sha256', 'runtime_code_manifest_sha256'), (s.upper() for s in sys.argv[4:7])))
assert len(PINS) == 3
raw = zp.read_bytes()
doc = {'schema': 'CDT21_FULL_CANDIDATE_INDEPENDENT_VERIFICATION_V002', 'zip': zp.name, 'pins': PINS, 'zip_sha256': H(raw),
       'zip_bytes': len(raw), 'checks': {}}
ok = lambda k, v, d='': doc['checks'].__setitem__(k, {'status': 'PASS' if v else 'FAIL', 'detail': d})
with zipfile.ZipFile(zp) as z:
    names = z.namelist()
    ok('zip_crc', z.testzip() is None)
    ok('no_duplicate_members', len(names) == len(set(names)), len(names))
    ok('safe_member_names', all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n for n in names))
    members = {n: z.read(n) for n in names if not n.endswith('/')}
pm_raw = members['PACKAGE_MANIFEST.json']; pm = json.loads(pm_raw)
listed = {f['path']: f for f in pm['files']}
ok('package_sha256_pin', H(raw) == PINS['package_sha256'], H(raw))
ok('package_manifest_sha256_pin', H(pm_raw) == PINS['package_manifest_sha256'], H(pm_raw))
others = sorted(n for n in members if n != 'PACKAGE_MANIFEST.json')
ok('package_manifest_lists_every_member_once', sorted(listed) == others and len(listed) == len(pm['files']), len(others))
bad = [p for p, f in listed.items() if p not in members or len(members[p]) != f['bytes'] or H(members[p]) != f['sha256']]
ok('package_manifest_sizes_and_hashes', not bad, bad[:5])
rc_name = 'implementation_v001/RUNTIME_CODE_MANIFEST.json'; rc_raw = members[rc_name]; rc = json.loads(rc_raw)
ok('runtime_code_manifest_sha256_pin', H(rc_raw) == PINS['runtime_code_manifest_sha256'], H(rc_raw))
rows = rc.get('files', [])
miss = []
for r in rows:
    p = 'implementation_v001/candidate/' + r['path']  # runtime paths are relative to the candidate folder
    if p not in members or H(members[p]) != r['sha256'].upper() or len(members[p]) != r['bytes']:
        miss.append(r['path'])
ok('runtime_code_manifest_entries_resolve', bool(rows) and not miss, {'entries': len(rows), 'bad': miss[:5]})
diff = [n for n, b in members.items() if not (ext / n).is_file() or (ext / n).read_bytes() != b]
extra = sorted(str(p.relative_to(ext)) for p in ext.rglob('*') if p.is_file() and str(p.relative_to(ext)) not in members)
ok('extracted_review_tree_equals_zip', not diff and not extra, {'differ': diff[:5], 'extra': extra[:5]})
doc['runtime_code_files'] = len(rows); doc['package_members'] = len(members)
doc['pass'] = all(c['status'] == 'PASS' for c in doc['checks'].values())
out.write_text(json.dumps(doc, indent=1), encoding='utf-8')
print('CANDIDATE_VERIFICATION', doc['pass'], len(members), len(rows), [k for k, c in doc['checks'].items() if c['status'] != 'PASS'])
