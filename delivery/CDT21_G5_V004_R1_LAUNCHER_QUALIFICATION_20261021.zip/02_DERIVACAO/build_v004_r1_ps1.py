"""Derive RUN_CDT21_G5_V004_R1_20261021.ps1 from the V004 launcher (54C5ED19...) by exact, counted replacements.

Usage: python -I build_v004_r1_ps1.py <RUN_CDT21_G5_V004_20261021.ps1> <out.ps1>
Only the classification of concurrent G5 campaigns changes (origin finding, 21/10): the own tree (this process and,
in the UAC child, the parent that launched it) is identified by PID + creation instant; every other G5 process still
blocks.  Embedded supervisor/review payloads, paths, log rule, phases Q/E and the return packaging are untouched.
"""
import hashlib
import sys
from pathlib import Path

PARENT_SHA = '54C5ED1991AE3BEDAC656E96772DB4DF41E5D99A7385B22405AAB39B82393372'
src, out = Path(sys.argv[1]), Path(sys.argv[2])
raw = src.read_bytes()
assert hashlib.sha256(raw).hexdigest().upper() == PARENT_SHA, 'PARENT_SHA'
assert raw.count(b'\r\n') == raw.count(b'\n') == raw.count(b'\r'), 'CRLF_ONLY'
text = raw.decode('ascii').replace('\r\n', '\n')

EDITS = [
    # E1 header: identify R1 and state the scope of the fix.
    ("# TICKSTORE CDT21 - LAUNCHER G5 V004: campanha G5 nativa NOVA vinculada ao manifesto completo do V004 (decisao da origem 21/10).\n",
     "# TICKSTORE CDT21 - LAUNCHER G5 V004 R1: campanha G5 nativa NOVA vinculada ao manifesto completo do V004 (decisao da origem 21/10).\n"
     "# R1 (defeito material apontado pela origem): muda somente a classificacao de campanhas G5 concorrentes. A arvore propria\n"
     "# (este processo e, no filho UAC, o pai que o lancou) e identificada por PID + instante de criacao, e o filho exige que seu\n"
     "# pai real seja esse processo. Qualquer outro processo G5 continua bloqueando (LIVE_G5_CAMPAIGN_PROCESS).\n"),
    # E2 documented command names this file.
    ('#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\\Users\\silvi\\Downloads\\RUN_CDT21_G5_V004_20261021.ps1" -AutorizoLabD\n',
     '#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\\Users\\silvi\\Downloads\\RUN_CDT21_G5_V004_R1_20261021.ps1" -AutorizoLabD\n'),
    # E3 parameters carrying the parent identity to the UAC child.
    ("param([switch]$AutorizoLabD, [switch]$ElevatedChild, [string]$SharedLogDir = '')\n",
     "param([switch]$AutorizoLabD, [switch]$ElevatedChild, [string]$SharedLogDir = '', [int]$LauncherParentPid = 0, [string]$LauncherParentCreation = '')\n"),
    # E4 identity and classification functions (after Unpack, before the main flow).
    ("    Log ('UNPACKED=' + $Path + ' SHA256=' + $Expected)\n}\n",
     "    Log ('UNPACKED=' + $Path + ' SHA256=' + $Expected)\n}\n"
     "function CreationKey($Proc) {\n"
     "    if ($null -eq $Proc.CreationDate) { return '' }\n"
     "    return [string]([DateTime]$Proc.CreationDate).ToUniversalTime().Ticks\n"
     "}\n"
     "function ClassifyG5Processes($Snapshot, [int]$SelfPid, [bool]$IsElevatedChild, [int]$ParentPid, [string]$ParentCreation) {\n"
     "    # Arvore propria = este processo e, no filho UAC, o pai que o lancou; identidade = PID + instante de criacao.\n"
     "    $self = @($Snapshot | Where-Object { [int]$_.ProcessId -eq $SelfPid })\n"
     "    if ($self.Count -ne 1) { throw 'OWN_TREE_SELF_NOT_FOUND' }\n"
     "    $selfKey = CreationKey $self[0]\n"
     "    if ($selfKey -notmatch '^[0-9]+$') { throw 'OWN_TREE_SELF_CREATION_MISSING' }\n"
     "    $own = @{}\n"
     "    $own[[string]$SelfPid] = $selfKey\n"
     "    if ($IsElevatedChild) {\n"
     "        if ($ParentPid -le 0 -or $ParentCreation -notmatch '^[0-9]+$') { throw 'OWN_TREE_PARENT_IDENTITY_MISSING' }\n"
     "        if ([int]$self[0].ParentProcessId -ne $ParentPid) { throw ('OWN_TREE_PARENT_PID_MISMATCH: pai real=' + $self[0].ParentProcessId + ' informado=' + $ParentPid) }\n"
     "        $parent = @($Snapshot | Where-Object { [int]$_.ProcessId -eq $ParentPid })\n"
     "        if ($parent.Count -ne 1) { throw ('OWN_TREE_PARENT_NOT_ALIVE: ocorrencias=' + $parent.Count) }\n"
     "        $parentKey = CreationKey $parent[0]\n"
     "        if ($parentKey -cne $ParentCreation) { throw ('OWN_TREE_PARENT_CREATION_MISMATCH: real=' + $parentKey + ' informado=' + $ParentCreation) }\n"
     "        if ([long]$parentKey -gt [long]$selfKey) { throw 'OWN_TREE_PARENT_NEWER_THAN_CHILD' }\n"
     "        $own[[string]$ParentPid] = $parentKey\n"
     "    } elseif ($ParentPid -ne 0 -or $ParentCreation) { throw 'OWN_TREE_PARENT_ARGS_WITHOUT_ELEVATED_CHILD' }\n"
     "    $live = @($Snapshot | Where-Object { $_.CommandLine -and\n"
     "              ($_.CommandLine.IndexOf('PRE_G06_CAMPAIGN', [StringComparison]::OrdinalIgnoreCase) -ge 0 -or\n"
     "               $_.CommandLine.IndexOf('CDT21_G5_V00', [StringComparison]::OrdinalIgnoreCase) -ge 0) -and\n"
     "              -not ($own.ContainsKey([string]$_.ProcessId) -and $own[[string]$_.ProcessId] -ceq (CreationKey $_)) })\n"
     "    $desc = (@($own.Keys | Sort-Object) | ForEach-Object { $_ + '@' + $own[$_] }) -join ';'\n"
     "    return New-Object PSObject -Property @{ Own = $desc; Live = $live }\n"
     "}\n"),
    # E5 the non-elevated parent records its own identity before requesting UAC.
    ("        if ($ElevatedChild) { throw 'ELEVATION_REENTRY_GUARD: rights missing after RunAs' }\n",
     "        if ($ElevatedChild) { throw 'ELEVATION_REENTRY_GUARD: rights missing after RunAs' }\n"
     "        $selfProc = @(Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $PID) -ErrorAction Stop)\n"
     "        if ($selfProc.Count -ne 1) { throw 'OWN_TREE_SELF_NOT_FOUND' }\n"
     "        $selfCreation = CreationKey $selfProc[0]\n"
     "        if ($selfCreation -notmatch '^[0-9]+$') { throw 'OWN_TREE_SELF_CREATION_MISSING' }\n"),
    # E6 the identity travels to the UAC child.
    ("        $si.Arguments = '-NoProfile -ExecutionPolicy Bypass -File \"' + $PSCommandPath + '\"' + $(if ($AutorizoLabD) { ' -AutorizoLabD' } else { '' }) + ' -ElevatedChild -SharedLogDir \"' + $LogDir + '\"'\n"
     "        Log ('UAC_REQUEST=YES LOG_COMPARTILHADO=' + $LogDir)\n",
     "        $si.Arguments = '-NoProfile -ExecutionPolicy Bypass -File \"' + $PSCommandPath + '\"' + $(if ($AutorizoLabD) { ' -AutorizoLabD' } else { '' }) + ' -ElevatedChild -SharedLogDir \"' + $LogDir + '\" -LauncherParentPid ' + $PID + ' -LauncherParentCreation ' + $selfCreation\n"
     "        Log ('UAC_REQUEST=YES LOG_COMPARTILHADO=' + $LogDir + ' IDENTIDADE_PAI=' + $PID + '@' + $selfCreation)\n"),
    # E7 the concurrency check excludes exactly the validated own tree.
    ("        $live = @(Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -and\n"
     "                  ($_.CommandLine.IndexOf('PRE_G06_CAMPAIGN', [StringComparison]::OrdinalIgnoreCase) -ge 0 -or\n"
     "                   $_.CommandLine.IndexOf('CDT21_G5_V00', [StringComparison]::OrdinalIgnoreCase) -ge 0) })\n"
     "        foreach ($p in $live) {",
     "        $snapshot = @(Get-CimInstance Win32_Process -ErrorAction Stop)\n"
     "        $scan = ClassifyG5Processes $snapshot $PID $ElevatedChild.IsPresent $LauncherParentPid $LauncherParentCreation\n"
     "        Log ('ARVORE_PROPRIA=' + $scan.Own)\n"
     "        $live = @($scan.Live)\n"
     "        foreach ($p in $live) {"),
]
for old, new in EDITS:
    assert text.count(old) == 1, ('ANCHOR', old[:80])
    text = text.replace(old, new)
data = text.replace('\n', '\r\n').encode('ascii')
out.write_bytes(data)
print(out.name, hashlib.sha256(data).hexdigest().upper(), len(data))
