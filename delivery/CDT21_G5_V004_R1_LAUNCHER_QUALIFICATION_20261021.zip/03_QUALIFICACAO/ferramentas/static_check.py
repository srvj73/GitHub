"""Static qualification of the R1 launcher against its V004 parent (no execution)."""
import base64, difflib, hashlib, json, re, subprocess, sys
from pathlib import Path

r1, parent, sup, rev, pwsh, tokens_ps1, out = map(Path, sys.argv[1:8])
H = lambda b: hashlib.sha256(b).hexdigest().upper()
b1, b0 = r1.read_bytes(), parent.read_bytes()
t1, t0 = b1.decode('ascii'), b0.decode('ascii')
checks = {}
checks['R1_SHA256'] = H(b1)
checks['PARENT_SHA256_IS_V004_LAUNCHER'] = H(b0) == '54C5ED1991AE3BEDAC656E96772DB4DF41E5D99A7385B22405AAB39B82393372'
checks['ASCII_ONLY'] = all(c < 128 for c in b1)
checks['CRLF_ONLY'] = b1.count(b'\r\n') == b1.count(b'\n') == b1.count(b'\r')
tk = json.loads(subprocess.run([str(pwsh), '-NoProfile', '-File', str(tokens_ps1), '-Path', str(r1)], capture_output=True, text=True, check=True).stdout)
checks['PARSE_ERRORS'] = tk['parse_errors']
checks['PS7_ONLY_TOKENS'] = tk['ps7_only_tokens']

def here(text, var):
    m = re.search(r'\$' + var + r" = @'\r\n(.*?)\r\n'@", text, re.S)
    return m.group(1)
for var, ref, exp in (('SupervisorB64', sup, '273E620746FD5293D87858847CEBE035328B2A354F4371BBB18D82195A410126'),
                      ('ReviewB64', rev, 'E84E5C39F37E73C08DE913403D41045F622916063190638DEA308F668C86C802')):
    blob = base64.b64decode(re.sub(r'\s', '', here(t1, var)))
    checks[var + '_IDENTICAL_TO_V004_LAUNCHER'] = here(t1, var) == here(t0, var)
    checks[var + '_DECODES_TO_PINNED_SHA'] = H(blob) == exp == H(ref.read_bytes())
checks['DESTRUCTIVE_CMDLETS_ABSENT'] = not re.search(r'(?i)\b(Remove-Item|Clear-Content|Clear-Item|Stop-Process|Format-Volume|Move-Item|Rename-Item|taskkill|rmdir|Remove-ItemProperty)\b|\b(rm|del|rd|erase|kill)\s', t1.split("$SupervisorB64 = @'")[0] + t1.split("'@", 2)[-1])
checks['NO_RESUME_ARGUMENTS'] = 'resume' not in t1.lower().split("$supervisorb64 = @'")[0] and '--resume' not in t1
l0, l1 = t0.split('\r\n'), t1.split('\r\n')
hunks = []
for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, l0, l1, autojunk=False).get_opcodes():
    if tag != 'equal':
        hunks.append({'tag': tag, 'v004_lines': [i1 + 1, i2], 'r1_lines': [j1 + 1, j2], 'removed': l0[i1:i2], 'added': l1[j1:j2]})
checks['DIFF_HUNKS'] = len(hunks)
removed = [x for h in hunks for x in h['removed']]
added = [x for h in hunks for x in h['added']]
# Every removed line is one of: header title, documented command, param, Arguments + UAC log, old scan filter.
allowed_removed = ('# TICKSTORE CDT21 - LAUNCHER G5 V004:', '#   powershell -NoProfile', 'param([switch]$AutorizoLabD', "        $si.Arguments = ",
                   "        Log ('UAC_REQUEST=YES", '        $live = @(Get-CimInstance Win32_Process', "                  ($_.CommandLine.IndexOf('PRE_G06_CAMPAIGN'",
                   "                   $_.CommandLine.IndexOf('CDT21_G5_V00'")
checks['REMOVED_LINES_ONLY_IN_CLASSIFICATION_SCOPE'] = all(x.startswith(allowed_removed) for x in removed)
checks['REMOVED_LINE_COUNT'] = len(removed)
checks['ADDED_LINE_COUNT'] = len(added)
checks['UNCHANGED_KEY_LINES'] = all(l in l1 for l in l0 if l.startswith(('$RunsDir =', '$ExpectedPackageSha =', '$ExpectedPythonSha =', '$SupervisorSha =', '$ReviewSha =', '$PackageName =', '$Python =')))
checks['FILTER_MARKERS_UNCHANGED'] = t1.count("IndexOf('PRE_G06_CAMPAIGN', [StringComparison]::OrdinalIgnoreCase)") == 1 and t1.count("IndexOf('CDT21_G5_V00', [StringComparison]::OrdinalIgnoreCase)") == 1
checks['BLOCK_MESSAGE_UNCHANGED'] = t1.count("throw 'LIVE_G5_CAMPAIGN_PROCESS: outra campanha G5 esta ativa; aguarde o termino dela'") == 1
ok = (checks['PARENT_SHA256_IS_V004_LAUNCHER'] and checks['ASCII_ONLY'] and checks['CRLF_ONLY'] and checks['PARSE_ERRORS'] == 0 and not checks['PS7_ONLY_TOKENS']
      and all(checks[k] for k in checks if k.endswith(('_IDENTICAL_TO_V004_LAUNCHER', '_DECODES_TO_PINNED_SHA')))
      and checks['DESTRUCTIVE_CMDLETS_ABSENT'] and checks['NO_RESUME_ARGUMENTS'] and checks['REMOVED_LINES_ONLY_IN_CLASSIFICATION_SCOPE']
      and checks['UNCHANGED_KEY_LINES'] and checks['FILTER_MARKERS_UNCHANGED'] and checks['BLOCK_MESSAGE_UNCHANGED'])
doc = {'schema': 'CDT21_G5_V004_R1_STATIC_CHECK_V001', 'status': 'PASS' if ok else 'FAIL', 'checks': checks, 'diff': hunks}
Path(out).write_text(json.dumps(doc, indent=1), encoding='utf-8')
print(doc['status'], json.dumps({k: v for k, v in checks.items()}))
