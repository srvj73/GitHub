# Linux stand-in for Get-CimInstance Win32_Process (qualification only; never shipped in the launcher).
# Same shape as the CIM object the launcher reads: ProcessId, ParentProcessId, Name, CommandLine, CreationDate.
# CreationDate = boot time + /proc/<pid>/stat starttime (field 22), i.e. the kernel's creation instant of the process.
$script:ClkTck = 100
function Get-LinuxProcSnapshot {
    $btime = 0L
    foreach ($line in [IO.File]::ReadAllLines('/proc/stat')) { if ($line.StartsWith('btime ')) { $btime = [long]$line.Split(' ')[1] } }
    if ($btime -le 0) { throw 'MOCK_NO_BTIME' }
    $epoch = New-Object DateTime 1970, 1, 1, 0, 0, 0, ([DateTimeKind]::Utc)
    $list = New-Object System.Collections.ArrayList
    foreach ($d in [IO.Directory]::GetDirectories('/proc')) {
        $name = [IO.Path]::GetFileName($d)
        if ($name -notmatch '^[0-9]+$') { continue }
        try {
            $stat = [IO.File]::ReadAllText($d + '/stat')
            $l = $stat.IndexOf('('); $r = $stat.LastIndexOf(')')
            $f = $stat.Substring($r + 2).Split(' ')
            $cmd = [IO.File]::ReadAllText($d + '/cmdline').TrimEnd([char]0).Replace([char]0, ' ')
            if (-not $cmd) { $cmd = $null }
            [void]$list.Add([pscustomobject]@{
                ProcessId = [uint32]$name; ParentProcessId = [uint32]$f[1]; Name = $stat.Substring($l + 1, $r - $l - 1)
                CommandLine = $cmd; CreationDate = $epoch.AddSeconds($btime).AddTicks([long]$f[19] * (10000000 / $script:ClkTck)) })
        } catch { }
    }
    return $list.ToArray()
}
function Get-CimInstance {
    [CmdletBinding()]
    param([Parameter(Position = 0)][string]$ClassName, [string]$Filter)
    if ($ClassName -ne 'Win32_Process') { throw ('MOCK_UNEXPECTED_CLASS=' + $ClassName) }
    $snap = Get-LinuxProcSnapshot
    if ($Filter) {
        if ($Filter -notmatch '^ProcessId = ([0-9]+)$') { throw ('MOCK_UNEXPECTED_FILTER=' + $Filter) }
        $id = [int]$Matches[1]
        return @($snap | Where-Object { [int]$_.ProcessId -eq $id })
    }
    return $snap
}
