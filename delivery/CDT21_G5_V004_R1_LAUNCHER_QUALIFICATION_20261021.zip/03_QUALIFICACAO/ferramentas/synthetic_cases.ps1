# Windows-shaped snapshots against the launcher's verbatim fragments (OLD = V004 54C5ED19, NEW = R1).
# Get-CimInstance returns the case snapshot; the fragments run unmodified, with $PID = this process.
param([string]$NewDir, [string]$OldDir, [string]$OutJson)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$NewScan = [IO.File]::ReadAllText((Join-Path $NewDir 'FRAG_SCAN.ps1'))
$OldScan = [IO.File]::ReadAllText((Join-Path $OldDir 'FRAG_SCAN.ps1'))
$NewParentId = [IO.File]::ReadAllText((Join-Path $NewDir 'FRAG_PARENT_ID.ps1'))
$NewSi = [IO.File]::ReadAllText((Join-Path $NewDir 'FRAG_SI.ps1'))
. ([scriptblock]::Create([IO.File]::ReadAllText((Join-Path $NewDir 'FRAG_FUNCS.ps1'))))

$script:CurrentSnap = @()
$script:Logged = New-Object System.Collections.ArrayList
function Get-CimInstance {
    [CmdletBinding()]
    param([Parameter(Position = 0)][string]$ClassName, [string]$Filter)
    if ($ClassName -ne 'Win32_Process') { throw 'MOCK_CLASS' }
    if ($Filter) {
        if ($Filter -notmatch '^ProcessId = ([0-9]+)$') { throw 'MOCK_FILTER' }
        $id = [int]$Matches[1]
        return @($script:CurrentSnap | Where-Object { [int]$_.ProcessId -eq $id })
    }
    return $script:CurrentSnap
}
function Log([string]$Line) { [void]$script:Logged.Add($Line) }

function Invoke-Scan([string]$Code, $Snap, [bool]$Child, [int]$PPid, [string]$PCreation) {
    $script:CurrentSnap = $Snap
    $script:Logged.Clear()
    $ElevatedChild = [Management.Automation.SwitchParameter]$Child
    $LauncherParentPid = $PPid
    $LauncherParentCreation = $PCreation
    try {
        . ([scriptblock]::Create($Code))
        $own = ''; if (Test-Path variable:scan) { $own = $scan.Own }
        return @{ outcome = 'PASS'; reason = ''; own = $own; live = @() }
    } catch {
        $livePids = @(); if (Test-Path variable:live) { $livePids = @($live | ForEach-Object { [int]$_.ProcessId } | Sort-Object) }
        return @{ outcome = 'BLOCKED'; reason = $_.Exception.Message; own = ''; live = $livePids }
    }
}

$T0 = New-Object DateTime 2026, 10, 21, 14, 0, 0, ([DateTimeKind]::Local)
function P([int]$Id, [int]$PPid, [string]$Name, $Cmd, $Sec) {
    $cd = $null
    if ($null -ne $Sec) { $cd = $T0.AddSeconds($Sec).AddTicks(123450) }
    return [pscustomobject]@{ ProcessId = [uint32]$Id; ParentProcessId = [uint32]$PPid; Name = $Name; CommandLine = $Cmd; CreationDate = $cd }
}
$PS = '"C:\WINDOWS\System32\WindowsPowerShell\v1.0\powershell.exe"'
$NewFile = 'C:\Users\silvi\Downloads\RUN_CDT21_G5_V004_R1_20261021.ps1'
$OldFile = 'C:\Users\silvi\Downloads\RUN_CDT21_G5_V004_20261021.ps1'
$Me = $PID
$Par = 5100
if (@(4, 900, 1200, 1300, 5100, 5150, 6100, 7100, 7200, 7300, 7400, 7500, 7600, 7700) -contains $Me) { throw 'HARNESS_PID_COLLIDES' }
$LogDirW = 'C:\Users\silvi\Downloads\CDT21_G5_V004_RUNS\G5V4_20261021_140000_000_5100'

function Base([string]$File, [bool]$WithParentKey) {
    # explorer -> interactive shell -> launcher parent (documented command) -> UAC child (this process); conhost; protected process.
    $parent = P $Par 1200 'powershell.exe' ($PS + ' -NoProfile -ExecutionPolicy Bypass -File "' + $File + '" -AutorizoLabD') 10
    $key = CreationKey $parent
    $childCmd = $PS + ' -NoProfile -ExecutionPolicy Bypass -File "' + $File + '" -AutorizoLabD -ElevatedChild -SharedLogDir "' + $LogDirW + '"'
    if ($WithParentKey) { $childCmd += ' -LauncherParentPid ' + $Par + ' -LauncherParentCreation ' + $key }
    return @{ key = $key; snap = @(
        (P 4 0 'System' $null 0),
        (P 900 800 'explorer.exe' 'C:\WINDOWS\Explorer.EXE' 1),
        (P 1200 900 'powershell.exe' $PS 5),
        $parent,
        (P 5150 5100 'conhost.exe' '\??\C:\WINDOWS\system32\conhost.exe 0x4' 10),
        (P $Me $Par 'powershell.exe' $childCmd 12),
        (P 6100 700 'MsMpEng.exe' $null 2)) }
}
function Concurrent([string]$File) {
    # A real concurrent campaign: another launcher parent, its UAC child, its supervisor and the frozen campaign.
    return @(
        (P 7100 1200 'powershell.exe' ($PS + ' -NoProfile -ExecutionPolicy Bypass -File "' + $File + '" -AutorizoLabD') 3),
        (P 7200 7100 'powershell.exe' ($PS + ' -NoProfile -ExecutionPolicy Bypass -File "' + $File + '" -AutorizoLabD -ElevatedChild -SharedLogDir "C:\Users\silvi\Downloads\CDT21_G5_V004_RUNS\G5V4_20261021_135959_000_7100"') 4),
        (P 7300 7200 'python.exe' '"C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe" -I -B C:\Users\silvi\AppData\Local\CDT21_G5_V004\STAGE_20261021_135959_000_7100\CDT21_G5_V004_SUPERVISOR.py --package C:\Users\silvi\Downloads\CDT21_FINAL_PACKAGE_V004_20261021.zip' 5),
        (P 7400 7300 'python.exe' '"C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe" -I -B C:\Users\silvi\AppData\Local\CDT20_R08\R08_Q1_20261021135959_0123456789ab\EXTRACTED\implementation_v001\candidate\g5proof\PRE_G06_CAMPAIGN.py' 6))
}
function DirectAdmin([string]$File) {
    # Launcher started from an elevated prompt: no UAC child; this process is the launcher itself.
    return @((P 1200 900 'powershell.exe' $PS 5), (P $Me 1200 'powershell.exe' ($PS + ' -NoProfile -ExecutionPolicy Bypass -File "' + $File + '" -AutorizoLabD') 12))
}

$cases = New-Object System.Collections.ArrayList
function Check([string]$Id, [string]$Group, [string]$Desc, $R, [string]$ExpOutcome, [string]$ExpReason, $ExpLive, [string]$ExpOwn) {
    $ok = ($R.outcome -eq $ExpOutcome) -and ($R.reason.StartsWith($ExpReason))
    if ($null -ne $ExpLive) { $ok = $ok -and ((@($R.live) -join ',') -eq (@($ExpLive | Sort-Object) -join ',')) }
    if ($ExpOwn) { $ok = $ok -and ($R.own -eq $ExpOwn) }
    [void]$cases.Add([ordered]@{ id = $Id; group = $Group; description = $Desc; expected = ($ExpOutcome + ' ' + $ExpReason).Trim();
        observed_outcome = $R.outcome; observed_reason = $R.reason; observed_live = @($R.live); observed_own = $R.own; pass = $ok })
}

# --- UAC parent/child (the defect) ---
$b = Base $OldFile $false
Check 'S01' 'UAC_PAI_FILHO' 'V004 (54C5ED19): comando documentado, filho UAC classifica o proprio pai como concorrente (defeito reproduzido)' (Invoke-Scan $OldScan $b.snap $true 0 '') 'BLOCKED' 'LIVE_G5_CAMPAIGN_PROCESS' @($Par) ''
$b = Base $NewFile $true
$ownExp = (@(([string]$Par), ([string]$Me)) | Sort-Object | ForEach-Object { if ($_ -eq [string]$Par) { $_ + '@' + $b.key } else { $_ + '@' + (CreationKey ($b.snap | Where-Object { [int]$_.ProcessId -eq $Me })) } }) -join ';'
Check 'S02' 'UAC_PAI_FILHO' 'R1: mesmo cenario; arvore propria = filho + pai validado; nenhuma campanha concorrente' (Invoke-Scan $NewScan $b.snap $true $Par $b.key) 'PASS' '' @() $ownExp
# --- true concurrent campaigns ---
$b = Base $NewFile $true
Check 'S03' 'CONCORRENTE_REAL' 'R1: outra instancia completa (pai, filho UAC, supervisor, PRE_G06_CAMPAIGN) bloqueia; o proprio pai nao e listado' (Invoke-Scan $NewScan ($b.snap + (Concurrent $NewFile)) $true $Par $b.key) 'BLOCKED' 'LIVE_G5_CAMPAIGN_PROCESS' @(7100, 7200, 7300, 7400) ''
$b = Base $OldFile $false
Check 'S04' 'CONCORRENTE_REAL' 'V004: mesma concorrencia; o antigo tambem lista o proprio pai (falso positivo somado)' (Invoke-Scan $OldScan ($b.snap + (Concurrent $OldFile)) $true 0 '') 'BLOCKED' 'LIVE_G5_CAMPAIGN_PROCESS' @($Par, 7100, 7200, 7300, 7400) ''
$b = Base $NewFile $true
Check 'S05' 'CONCORRENTE_REAL' 'R1: PRE_G06_CAMPAIGN orfao (launcher ja encerrado) bloqueia' (Invoke-Scan $NewScan ($b.snap + @(P 7400 7300 'python.exe' 'python.exe -I -B C:\x\g5proof\PRE_G06_CAMPAIGN.py' 6)) $true $Par $b.key) 'BLOCKED' 'LIVE_G5_CAMPAIGN_PROCESS' @(7400) ''
$b = Base $NewFile $true
Check 'S06' 'CONCORRENTE_REAL' 'R1: supervisor do V003 ativo bloqueia' (Invoke-Scan $NewScan ($b.snap + @(P 7500 7100 'python.exe' 'python.exe -I -B C:\x\CDT21_G5_V003_SUPERVISOR_R2.py --resume-root C:\y' 6)) $true $Par $b.key) 'BLOCKED' 'LIVE_G5_CAMPAIGN_PROCESS' @(7500) ''
$b = Base $NewFile $true
Check 'S07' 'CONCORRENTE_REAL' 'R1: comparacao sem distincao de caixa preservada (pre_g06_campaign)' (Invoke-Scan $NewScan ($b.snap + @(P 7600 1 'python.exe' 'python.exe c:\x\pre_g06_campaign.py' 6)) $true $Par $b.key) 'BLOCKED' 'LIVE_G5_CAMPAIGN_PROCESS' @(7600) ''
$b = Base $NewFile $true
Check 'S08' 'CONCORRENTE_REAL' 'R1: processo G5 sem instante de criacao legivel continua bloqueando' (Invoke-Scan $NewScan ($b.snap + @(P 7700 1 'python.exe' 'python.exe C:\x\CDT21_G5_V004_SUPERVISOR.py' $null)) $true $Par $b.key) 'BLOCKED' 'LIVE_G5_CAMPAIGN_PROCESS' @(7700) ''
# --- elevated prompt (no UAC child) ---
$selfKeyDA = CreationKey ((DirectAdmin $NewFile) | Where-Object { [int]$_.ProcessId -eq $Me })
Check 'S09' 'SEM_UAC' 'R1: prompt ja elevado, sem filho; arvore propria = este processo' (Invoke-Scan $NewScan (DirectAdmin $NewFile) $false 0 '') 'PASS' '' @() ([string]$Me + '@' + $selfKeyDA)
Check 'S10' 'SEM_UAC' 'R1: prompt ja elevado com campanha concorrente bloqueia' (Invoke-Scan $NewScan ((DirectAdmin $NewFile) + (Concurrent $NewFile)) $false 0 '') 'BLOCKED' 'LIVE_G5_CAMPAIGN_PROCESS' @(7100, 7200, 7300, 7400) ''
Check 'S11' 'SEM_UAC' 'V004: prompt ja elevado passava (o defeito era so do caminho UAC)' (Invoke-Scan $OldScan (DirectAdmin $OldFile) $false 0 '') 'PASS' '' @() ''
# --- wrong process identity ---
$b = Base $NewFile $true
Check 'S12' 'IDENTIDADE_INCORRETA' 'R1: instante de criacao informado difere do real (1 us)' (Invoke-Scan $NewScan $b.snap $true $Par ([string]([long]$b.key + 10))) 'BLOCKED' 'OWN_TREE_PARENT_CREATION_MISMATCH' @() ''
$b = Base $NewFile $true
$reuse = @($b.snap | Where-Object { [int]$_.ProcessId -ne $Par }) + @(P $Par 1 'python.exe' 'python.exe -I -B C:\x\g5proof\PRE_G06_CAMPAIGN.py' 30)
Check 'S13' 'IDENTIDADE_INCORRETA' 'R1: pai encerrado e PID reutilizado por PRE_G06_CAMPAIGN (PPID obsoleto); nao e liberado' (Invoke-Scan $NewScan $reuse $true $Par $b.key) 'BLOCKED' 'OWN_TREE_PARENT_CREATION_MISMATCH' @() ''
$forged = CreationKey ($reuse | Where-Object { [int]$_.ProcessId -eq $Par })
Check 'S14' 'IDENTIDADE_INCORRETA' 'R1: identidade forjada com o instante do processo que reutilizou o PID (mais novo que o filho)' (Invoke-Scan $NewScan $reuse $true $Par $forged) 'BLOCKED' 'OWN_TREE_PARENT_NEWER_THAN_CHILD' @() ''
$b = Base $NewFile $true
$snapC = $b.snap + (Concurrent $NewFile)
$k7100 = CreationKey ($snapC | Where-Object { [int]$_.ProcessId -eq 7100 })
Check 'S15' 'IDENTIDADE_INCORRETA' 'R1: identidade exata de um launcher concorrente real (7100) informada; o pai real e outro' (Invoke-Scan $NewScan $snapC $true 7100 $k7100) 'BLOCKED' 'OWN_TREE_PARENT_PID_MISMATCH' @() ''
$b = Base $NewFile $true
Check 'S16' 'IDENTIDADE_INCORRETA' 'R1: pai ausente do snapshot' (Invoke-Scan $NewScan @($b.snap | Where-Object { [int]$_.ProcessId -ne $Par }) $true $Par $b.key) 'BLOCKED' 'OWN_TREE_PARENT_NOT_ALIVE' @() ''
$b = Base $NewFile $true
Check 'S17' 'IDENTIDADE_INCORRETA' 'R1: PID do pai ambiguo (duas ocorrencias)' (Invoke-Scan $NewScan ($b.snap + @(P $Par 1 'x.exe' 'x' 10)) $true $Par $b.key) 'BLOCKED' 'OWN_TREE_PARENT_NOT_ALIVE' @() ''
$b = Base $NewFile $false
Check 'S18' 'IDENTIDADE_INCORRETA' 'R1: filho UAC sem identidade do pai' (Invoke-Scan $NewScan $b.snap $true 0 '') 'BLOCKED' 'OWN_TREE_PARENT_IDENTITY_MISSING' @() ''
Check 'S19' 'IDENTIDADE_INCORRETA' 'R1: instante de criacao nao numerico' (Invoke-Scan $NewScan $b.snap $true $Par 'abc') 'BLOCKED' 'OWN_TREE_PARENT_IDENTITY_MISSING' @() ''
Check 'S20' 'IDENTIDADE_INCORRETA' 'R1: identidade do pai sem -ElevatedChild' (Invoke-Scan $NewScan (DirectAdmin $NewFile) $false $Par '123') 'BLOCKED' 'OWN_TREE_PARENT_ARGS_WITHOUT_ELEVATED_CHILD' @() ''
$b = Base $NewFile $true
Check 'S21' 'IDENTIDADE_INCORRETA' 'R1: o proprio processo ausente do snapshot' (Invoke-Scan $NewScan @($b.snap | Where-Object { [int]$_.ProcessId -ne $Me }) $true $Par $b.key) 'BLOCKED' 'OWN_TREE_SELF_NOT_FOUND' @() ''
$b = Base $NewFile $true
$noSelfDate = @($b.snap | ForEach-Object { if ([int]$_.ProcessId -eq $Me) { P $Me $Par 'powershell.exe' $_.CommandLine $null } else { $_ } })
Check 'S22' 'IDENTIDADE_INCORRETA' 'R1: instante de criacao do proprio processo ilegivel' (Invoke-Scan $NewScan $noSelfDate $true $Par $b.key) 'BLOCKED' 'OWN_TREE_SELF_CREATION_MISSING' @() ''
$noParDate = @($b.snap | ForEach-Object { if ([int]$_.ProcessId -eq $Par) { P $Par 1200 'powershell.exe' $_.CommandLine $null } else { $_ } })
Check 'S23' 'IDENTIDADE_INCORRETA' 'R1: instante de criacao do pai ilegivel' (Invoke-Scan $NewScan $noParDate $true $Par $b.key) 'BLOCKED' 'OWN_TREE_PARENT_CREATION_MISMATCH' @() ''

# --- the exclusion is exactly the validated UAC parent: no ancestor or wrapper is released ---
$wrapper = 'cmd.exe /c powershell -NoProfile -ExecutionPolicy Bypass -File "' + $NewFile + '" -AutorizoLabD'
$da = @((P 1300 900 'cmd.exe' $wrapper 4), (P $Me 1300 'powershell.exe' ($PS + ' -NoProfile -ExecutionPolicy Bypass -File "' + $NewFile + '" -AutorizoLabD') 12))
Check 'S25' 'ESCOPO_DA_EXCLUSAO' 'R1: prompt ja elevado lancado por wrapper que carrega o nome do launcher: o wrapper nao e liberado (igual ao V004)' (Invoke-Scan $NewScan $da $false 0 '') 'BLOCKED' 'LIVE_G5_CAMPAIGN_PROCESS' @(1300) ''
Check 'S26' 'ESCOPO_DA_EXCLUSAO' 'V004: mesmo cenario do S25 (comportamento preservado)' (Invoke-Scan $OldScan $da $false 0 '') 'BLOCKED' 'LIVE_G5_CAMPAIGN_PROCESS' @(1300) ''
$b = Base $NewFile $true
$gw = @($b.snap | ForEach-Object { if ([int]$_.ProcessId -eq 1200) { P 1200 900 'cmd.exe' $wrapper 5 } else { $_ } })
Check 'S27' 'ESCOPO_DA_EXCLUSAO' 'R1: filho UAC cujo avo e wrapper com o nome do launcher: so o pai validado e excluido; o avo bloqueia' (Invoke-Scan $NewScan $gw $true $Par $b.key) 'BLOCKED' 'LIVE_G5_CAMPAIGN_PROCESS' @(1200) ''

# --- parent side: the identity the UAC child receives is the parent's own PID + creation (launcher lines, verbatim) ---
$selfSnap = @(P $Me 1200 'powershell.exe' ($PS + ' -NoProfile -ExecutionPolicy Bypass -File "' + $NewFile + '" -AutorizoLabD') 10)
$script:CurrentSnap = $selfSnap
$AutorizoLabD = [Management.Automation.SwitchParameter]$true
$LogDir = $LogDirW
. ([scriptblock]::Create($NewParentId + "`n" + $NewSi))
$expKey = CreationKey $selfSnap[0]
$argsOk = $si.Arguments.EndsWith(' -ElevatedChild -SharedLogDir "' + $LogDirW + '" -LauncherParentPid ' + $Me + ' -LauncherParentCreation ' + $expKey) -and $si.Arguments.Contains(' -AutorizoLabD') -and ($si.Verb -eq 'runas')
[void]$cases.Add([ordered]@{ id = 'S24'; group = 'UAC_PAI_FILHO'; description = 'R1: linhas do pai produzem os argumentos UAC com PID + instante de criacao do proprio pai';
    expected = 'ARGS_CARRY_PARENT_IDENTITY'; observed_outcome = $si.Arguments; observed_reason = ''; observed_live = @(); observed_own = ''; pass = $argsOk })

# --- property: outside the validated own parent, R1 classifies exactly like V004 ---
$rng = New-Object Random 20261021
$pool = @($null, 'svchost.exe -k netsvcs', 'python.exe C:\x\PRE_G06_CAMPAIGN.py', 'python.exe C:\x\CDT21_G5_V004_SUPERVISOR.py', 'notepad.exe C:\x\CDT21_G5_V003.txt',
          'cmd.exe /c echo pre_g06_campaign', 'powershell.exe -File C:\x\RUN_CDT21_G5_V004_R1_20261021.ps1', 'code.exe', 'python.exe C:\x\cdt21_g5_v00x.py', 'explorer.exe')
$diff = 0; $trials = 400
for ($t = 0; $t -lt $trials; $t++) {
    $uac = ($t % 2 -eq 0)
    $b = Base $NewFile $true
    $extra = @(); $used = @{}
    $n = $rng.Next(0, 12)
    for ($i = 0; $i -lt $n; $i++) {
        do { $id = $rng.Next(10000, 60000) } while ($used.ContainsKey($id) -or $id -eq $Me); $used[$id] = 1
        $sec = $null; if ($rng.Next(0, 8) -ne 0) { $sec = $rng.Next(0, 40) }
        $extra += (P $id $rng.Next(1, 60000) 'p.exe' $pool[$rng.Next(0, $pool.Count)] $sec)
    }
    if ($uac) { $snap = $b.snap + $extra; $rn = Invoke-Scan $NewScan $snap $true $Par $b.key; $ro = Invoke-Scan $OldScan $snap $true 0 ''; $expected = @($ro.live | Where-Object { $_ -ne $Par }) }
    else { $snap = (DirectAdmin $NewFile) + $extra; $rn = Invoke-Scan $NewScan $snap $false 0 ''; $ro = Invoke-Scan $OldScan $snap $false 0 ''; $expected = @($ro.live) }
    if ((@($rn.live) -join ',') -ne (@($expected) -join ',') -or (($rn.outcome -eq 'PASS') -ne ($expected.Count -eq 0))) { $diff++ }
}
[void]$cases.Add([ordered]@{ id = 'P01'; group = 'EQUIVALENCIA'; description = ('R1 = V004 menos o pai validado, em ' + $trials + ' snapshots aleatorios (metade UAC, metade sem UAC; semente 20261021)');
    expected = 'DIVERGENCIAS=0'; observed_outcome = ('DIVERGENCIAS=' + $diff); observed_reason = ''; observed_live = @(); observed_own = ''; pass = ($diff -eq 0) })

$passed = @($cases | Where-Object { $_.pass }).Count
$doc = [ordered]@{ schema = 'CDT21_G5_V004_R1_SYNTHETIC_CLASSIFICATION_V001'; harness_pid = $Me; passed = $passed; total = $cases.Count; cases = $cases }
[IO.File]::WriteAllText($OutJson, (ConvertTo-Json $doc -Depth 6))
Write-Output ('SYNTHETIC ' + $passed + '/' + $cases.Count)
foreach ($c in $cases) { if (-not $c.pass) { Write-Output ('FAIL ' + $c.id + ' ' + $c.observed_outcome + ' ' + $c.observed_reason + ' live=' + (@($c.observed_live) -join ',')) } }
