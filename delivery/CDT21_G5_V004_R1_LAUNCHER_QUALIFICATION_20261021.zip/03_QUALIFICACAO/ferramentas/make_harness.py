"""Extract the launcher fragments that classify G5 processes (verbatim) and build a Linux harness around them.

Usage: python -I make_harness.py <launcher.ps1> <OLD|NEW> <outdir>
Writes <outdir>/FRAG_*.ps1 (verbatim launcher lines), <outdir>/FRAGMENTS.json (line ranges + SHA-256, each fragment
proven to be a byte substring of the launcher) and <outdir>/RUN_CDT21_G5_V004_QUALHARNESS_<variant>.ps1.  The harness
file name contains 'CDT21_G5_V00' on purpose: its command line matches the launcher's filter, like the real launcher.
Only the transport differs from Windows: ShellExecute/runas is replaced by a plain child start of the same pwsh with
the Arguments string built by the launcher's own line; Get-CimInstance reads /proc.
"""
import hashlib
import json
import sys
from pathlib import Path

launcher, variant, outdir = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
raw = launcher.read_bytes()
lines = raw.decode('ascii').split('\r\n')


def find(prefix, start=0):
    hits = [i for i in range(start, len(lines)) if lines[i].startswith(prefix)]
    assert hits, prefix
    return hits[0]


def frag(first, last):
    text = '\r\n'.join(lines[first:last + 1])
    assert raw.count(text.encode('ascii')) == 1
    return {'first_line': first + 1, 'last_line': last + 1, 'sha256': hashlib.sha256(text.encode()).hexdigest().upper(),
            'text': text.replace('\r\n', '\n')}


F = {'PARAM': frag(find('param([switch]$AutorizoLabD'), find('param([switch]$AutorizoLabD'))}
si = find('        $si = New-Object System.Diagnostics.ProcessStartInfo')
F['SI'] = frag(si, find("        Log ('UAC_REQUEST=YES", si))
end = find("        Log 'CAMPANHAS_G5_ATIVAS=0'")
if variant == 'NEW':
    f0 = find('function CreationKey($Proc) {')
    c0 = find('function ClassifyG5Processes(')
    F['FUNCS'] = frag(f0, lines.index('}', c0))
    p0 = find('        $selfProc = @(Get-CimInstance Win32_Process -Filter')
    F['PARENT_ID'] = frag(p0, find("        if ($selfCreation -notmatch", p0))
    F['SCAN'] = frag(find('        $snapshot = @(Get-CimInstance Win32_Process'), end)
else:
    F['SCAN'] = frag(find('        $live = @(Get-CimInstance Win32_Process'), end)

outdir.mkdir(parents=True, exist_ok=True)
for k, v in F.items():
    (outdir / ('FRAG_' + k + '.ps1')).write_text(v['text'] + '\n', encoding='ascii')
meta = {'launcher': launcher.name, 'launcher_sha256': hashlib.sha256(raw).hexdigest().upper(), 'variant': variant,
        'fragments': {k: {kk: vv for kk, vv in v.items() if kk != 'text'} for k, v in F.items()}}
(outdir / 'FRAGMENTS.json').write_text(json.dumps(meta, indent=1, sort_keys=True), encoding='utf-8')

bound = '$LauncherParentPid' if variant == 'NEW' else '0'
H = [F['PARAM']['text'],
     "$ErrorActionPreference = 'Stop'",
     'Set-StrictMode -Version 2.0',
     '. $env:QUAL_MOCK',
     '$Out = $env:QUAL_OUT',
     "$Role = 'PARENT'; if ($ElevatedChild) { $Role = 'CHILD' }; if ($env:QUAL_DIRECT_ADMIN -eq '1') { $Role = 'DIRECT_ADMIN' }",
     '$LogDir = $env:QUAL_LOGDIR',
     "$Log = Join-Path $Out ('LOG_' + $Role + '_' + $PID + '.txt')",
     'function Log([string]$Line) { [IO.File]::AppendAllText($Log, $Line + "`n") }',
     'function Result($h) {',
     "    $h['role'] = $Role; $h['pid'] = $PID; $h['bound_parent_pid'] = " + bound,
     "    $me = @(Get-LinuxProcSnapshot | Where-Object { [int]$_.ProcessId -eq $PID }); $h['real_ppid'] = [int]$me[0].ParentProcessId",
     "    [IO.File]::WriteAllText((Join-Path $Out ('RESULT_' + $Role + '_' + $PID + '.json')), (ConvertTo-Json $h -Depth 6))",
     '}']
if variant == 'NEW':
    H.append(F['FUNCS']['text'])
H += ["$isAdmin = $ElevatedChild -or ($env:QUAL_DIRECT_ADMIN -eq '1')",
      'try {',
      '    if (-not $isAdmin) {']
if variant == 'NEW':
    H += [F['PARENT_ID']['text'],
          "        if ($env:QUAL_TAMPER -eq 'creation') { $selfCreation = [string]([long]$selfCreation + 1) }"]
H += [F['SI']['text'],
      '        # Linux transport of the very same Arguments string (ShellExecute/runas does not exist here).',
      '        $si.FileName = (Get-Process -Id $PID).Path',
      '        $si.WorkingDirectory = $Out',
      '        $si.UseShellExecute = $false',
      "        $si.Verb = ''",
      "        if ($env:QUAL_TAMPER -eq 'pid') { $si.Arguments = $si.Arguments -replace '-LauncherParentPid [0-9]+ -LauncherParentCreation [0-9]+$', ('-LauncherParentPid ' + $env:QUAL_FAKE_PID + ' -LauncherParentCreation ' + $env:QUAL_FAKE_CREATION) }",
      '        $child = [Diagnostics.Process]::Start($si)',
      "        Result @{ outcome = 'LAUNCHED'; arguments = $si.Arguments; child_pid = $child.Id }",
      "        if ($env:QUAL_TAMPER -eq 'parent_exits') { exit 0 }",
      '        $child.WaitForExit()',
      '        exit $child.ExitCode',
      '    }',
      '    if ($env:QUAL_CHILD_DELAY_MS) { Start-Sleep -Milliseconds ([int]$env:QUAL_CHILD_DELAY_MS) }',
      F['SCAN']['text'],
      "    $own = ''; if (Test-Path variable:scan) { $own = $scan.Own }",
      "    Result @{ outcome = 'PASS'; own = $own; live = @() }",
      '    if ($env:QUAL_HOLD_FILE) { while (-not (Test-Path -LiteralPath $env:QUAL_HOLD_FILE)) { Start-Sleep -Milliseconds 100 } }',
      '    exit 0',
      '} catch {',
      "    $own = ''; if (Test-Path variable:scan) { $own = $scan.Own }",
      '    $livePids = @(); if (Test-Path variable:live) { $livePids = @($live | ForEach-Object { [int]$_.ProcessId }) }',
      "    Result @{ outcome = 'BLOCKED'; reason = $_.Exception.Message; own = $own; live = $livePids }",
      '    exit 2',
      '}']
harness = outdir / ('RUN_CDT21_G5_V004_QUALHARNESS_' + variant + '.ps1')
harness.write_text('\n'.join(H) + '\n', encoding='ascii')
print(harness, json.dumps(meta['fragments']))
