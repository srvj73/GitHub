# Parse with the PowerShell parser; report errors and any token kind that Windows PowerShell 5.1 does not have.
param([string]$Path)
$tok = $null; $err = $null
[void][Management.Automation.Language.Parser]::ParseFile($Path, [ref]$tok, [ref]$err)
$ps7 = @('QuestionQuestion', 'QuestionQuestionEquals', 'QuestionDot', 'QuestionLBracket', 'AndAnd', 'OrOr', 'QuestionMark')
$bad = @($tok | Where-Object { $ps7 -contains [string]$_.Kind } | ForEach-Object { [string]$_.Kind + '@' + $_.Extent.StartLineNumber })
ConvertTo-Json @{ parse_errors = @($err).Count; ps7_only_tokens = $bad; tokens = @($tok).Count } -Compress
