"""Real-process qualification of the G5 classification (Linux), plus mutants of the R1 fragments.

Usage: python -I real_driver.py <out.json>
Runs the harnesses built by make_harness.py (verbatim launcher fragments) as real parent/child pwsh processes,
alongside real concurrent processes whose command lines carry the G5 markers.  The driver's own command line must not
carry the markers (it would itself be a concurrent G5 process), so every path is derived from this file's location.
"""
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

Q = Path(__file__).resolve().parent
PWSH = Q.parent.parent / 'pwsh' / 'pwsh'
H = {'OLD': Q / 'h_old' / 'RUN_CDT21_G5_V004_QUALHARNESS_OLD.ps1', 'NEW': Q / 'h_new' / 'RUN_CDT21_G5_V004_QUALHARNESS_NEW.ps1'}
RUNS = Q / 'real_runs'
MARKERS = ('PRE_G06_CAMPAIGN', 'CDT21_G5_V00')
CAMPAIGN_ARG = r'C:\Users\silvi\AppData\Local\CDT20_R08\R08_Q1_20261021140000_0123456789ab\EXTRACTED\implementation_v001\candidate\g5proof\PRE_G06_CAMPAIGN.py'
SUPERVISOR_ARG = r'C:\Users\silvi\AppData\Local\CDT21_G5_V004\STAGE_20261021_140000_000_7100\CDT21_G5_V004_SUPERVISOR.py'
BTIME = next(int(l.split()[1]) for l in open('/proc/stat') if l.startswith('btime '))
CLK = os.sysconf('SC_CLK_TCK')


def creation_key(pid):
    """Same value the launcher's CreationKey yields from the /proc stand-in: UTC ticks of the creation instant."""
    stat = open(f'/proc/{pid}/stat').read()
    start = int(stat[stat.rindex(')') + 2:].split()[19])
    return str(621355968000000000 + BTIME * 10 ** 7 + start * (10 ** 7 // CLK))


def marked_processes():
    out = []
    for d in os.listdir('/proc'):
        if d.isdigit():
            try:
                cmd = open(f'/proc/{d}/cmdline', 'rb').read().replace(b'\0', b' ').decode(errors='replace')
            except OSError:
                continue
            if any(m.lower() in cmd.lower() for m in MARKERS):
                out.append((int(d), cmd))
    return out


def dummy(arg):
    return subprocess.Popen([sys.executable, '-I', '-c', 'import time; time.sleep(600)', arg])


def start(case, variant, env_extra=None, args=('-AutorizoLabD',)):
    out = RUNS / case
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    env = dict(os.environ, QUAL_MOCK=str(Q / 'linux_cim_mock.ps1'), QUAL_OUT=str(out), QUAL_LOGDIR=str(out / 'logdir'))
    env.update(env_extra or {})
    cmd = [str(PWSH), '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(H[variant]), *args]
    return subprocess.Popen(cmd, env=env, cwd=str(out)), out


def results(out):
    r = {}
    for f in sorted(out.glob('RESULT_*.json')):
        d = json.loads(f.read_text(encoding='utf-8-sig'))
        r[d['role']] = d
    return r


def wait_for(out, role, timeout=60):
    t = time.time() + timeout
    while time.time() < t:
        if role in results(out):
            return results(out)[role]
        time.sleep(0.1)
    raise TimeoutError(role)


cases = []


def record(cid, group, desc, ok, observed):
    cases.append({'id': cid, 'group': group, 'description': desc, 'pass': bool(ok), 'observed': observed})


def own_of(*pids):
    return ';'.join(f'{p}@{creation_key(p)}' for p in sorted(map(str, pids)))


def clean():
    stray = marked_processes()
    assert not stray, ('STRAY_MARKED_PROCESSES', stray)


RUNS.mkdir(exist_ok=True)
clean()

# R01 - the defect, with real processes: documented launch, the UAC child classifies its own parent as concurrent.
p, out = start('R01_OLD_UAC', 'OLD'); rc = p.wait(60); r = results(out)
c = r.get('CHILD', {})
record('R01', 'UAC_PAI_FILHO', 'V004 (54C5ED19): pai + filho reais; o filho bloqueia listando o proprio pai (defeito reproduzido)',
       rc == 2 and c.get('outcome') == 'BLOCKED' and c.get('reason', '').startswith('LIVE_G5_CAMPAIGN_PROCESS')
       and c.get('live') == [p.pid] and c.get('real_ppid') == p.pid,
       {'parent_pid': p.pid, 'exit': rc, 'child': c})
clean()

# R02 - R1: same launch passes; own tree = child + validated parent.
hold = RUNS / 'R02_RELEASE'
p, out = start('R02_NEW_UAC', 'NEW', {'QUAL_HOLD_FILE': str(hold)})
c = wait_for(out, 'CHILD')
par_res = results(out).get('PARENT', {})
kernel_own = own_of(p.pid, c['pid'])          # independent: computed here from /proc while both are alive
kernel_parent_key = creation_key(p.pid)
hold.write_text('release'); rc = p.wait(60); hold.unlink()
record('R02', 'UAC_PAI_FILHO', 'R1: pai + filho reais; filho PASS; arvore propria = filho + pai, identica ao PID + instante de criacao do kernel',
       rc == 0 and c.get('outcome') == 'PASS' and c.get('live') == [] and c.get('real_ppid') == p.pid
       and c.get('bound_parent_pid') == p.pid and c.get('own') == kernel_own
       and par_res.get('arguments', '').endswith(f' -ElevatedChild -SharedLogDir "{out / "logdir"}" -LauncherParentPid {p.pid} -LauncherParentCreation {kernel_parent_key}')
       and f'-File "{H["NEW"]}" -AutorizoLabD' in par_res.get('arguments', ''),
       {'parent_pid': p.pid, 'exit': rc, 'parent_arguments': par_res.get('arguments'), 'kernel_own_tree': kernel_own, 'child': c})
clean()

# R03 - elevated prompt (no UAC child): own tree = self.
p, out = start('R03_NEW_DIRECT', 'NEW', {'QUAL_DIRECT_ADMIN': '1'})
d = wait_for(out, 'DIRECT_ADMIN'); key = creation_key(p.pid); rc = p.wait(60)
record('R03', 'SEM_UAC', 'R1: prompt ja elevado (sem filho); arvore propria = este processo',
       rc == 0 and d.get('outcome') == 'PASS' and d.get('own') == f'{p.pid}@{key}', {'pid': p.pid, 'exit': rc, 'result': d})
clean()

# R04/R05 - real concurrent processes carrying the markers block; the own parent is not listed.
for cid, arg, desc in (('R04', CAMPAIGN_ARG, 'R1: PRE_G06_CAMPAIGN real concorrente bloqueia; o proprio pai nao e listado'),
                       ('R05', SUPERVISOR_ARG, 'R1: supervisor G5 V004 real concorrente bloqueia; o proprio pai nao e listado')):
    dm = dummy(arg); time.sleep(0.3)
    p, out = start(cid + '_NEW_UAC_CONCURRENT', 'NEW'); rc = p.wait(60); c = results(out).get('CHILD', {})
    record(cid, 'CONCORRENTE_REAL', desc,
           rc == 2 and c.get('outcome') == 'BLOCKED' and c.get('reason', '').startswith('LIVE_G5_CAMPAIGN_PROCESS') and c.get('live') == [dm.pid],
           {'parent_pid': p.pid, 'concurrent_pid': dm.pid, 'exit': rc, 'child': c})
    dm.kill(); dm.wait()
clean()

# R06 - a second real launcher instance while the first one (parent + child) is alive.
pa, outa = start('R06A_NEW_FIRST_INSTANCE', 'NEW', {'QUAL_HOLD_FILE': str(RUNS / 'R06A_RELEASE')})
ca = wait_for(outa, 'CHILD')
pb, outb = start('R06B_NEW_SECOND_INSTANCE', 'NEW'); rcb = pb.wait(60); cb = results(outb).get('CHILD', {})
(RUNS / 'R06A_RELEASE').write_text('release')
rca = pa.wait(60); (RUNS / 'R06A_RELEASE').unlink()
record('R06', 'CONCORRENTE_REAL', 'R1: segunda instancia real do launcher com a primeira viva: o filho da segunda lista o pai e o filho da primeira, nao o proprio pai; a primeira passou',
       ca.get('outcome') == 'PASS' and rca == 0 and rcb == 2 and cb.get('outcome') == 'BLOCKED'
       and cb.get('reason', '').startswith('LIVE_G5_CAMPAIGN_PROCESS') and cb.get('live') == sorted([pa.pid, ca['pid']]) and pb.pid not in cb.get('live', []),
       {'first': {'parent_pid': pa.pid, 'child': ca, 'exit': rca}, 'second': {'parent_pid': pb.pid, 'child': cb, 'exit': rcb}})
clean()

# R07 - elevated prompt with a real concurrent campaign.
dm = dummy(CAMPAIGN_ARG); time.sleep(0.3)
p, out = start('R07_NEW_DIRECT_CONCURRENT', 'NEW', {'QUAL_DIRECT_ADMIN': '1'}); rc = p.wait(60); d = results(out).get('DIRECT_ADMIN', {})
record('R07', 'CONCORRENTE_REAL', 'R1: prompt ja elevado com PRE_G06_CAMPAIGN real concorrente bloqueia',
       rc == 2 and d.get('outcome') == 'BLOCKED' and d.get('live') == [dm.pid], {'pid': p.pid, 'concurrent_pid': dm.pid, 'exit': rc, 'result': d})
dm.kill(); dm.wait()
clean()

# R08 - wrong creation instant handed to the child.
p, out = start('R08_NEW_TAMPER_CREATION', 'NEW', {'QUAL_TAMPER': 'creation'}); rc = p.wait(60); c = results(out).get('CHILD', {})
record('R08', 'IDENTIDADE_INCORRETA', 'R1: instante de criacao do pai adulterado (+1 tick) bloqueia',
       rc == 2 and c.get('outcome') == 'BLOCKED' and c.get('reason', '').startswith('OWN_TREE_PARENT_CREATION_MISMATCH'), {'parent_pid': p.pid, 'exit': rc, 'child': c})
clean()

# R09 - the exact identity of a real concurrent campaign handed over, to try to release it.
dm = dummy(CAMPAIGN_ARG); time.sleep(0.3)
p, out = start('R09_NEW_TAMPER_PID', 'NEW', {'QUAL_TAMPER': 'pid', 'QUAL_FAKE_PID': str(dm.pid), 'QUAL_FAKE_CREATION': creation_key(dm.pid)})
rc = p.wait(60); c = results(out).get('CHILD', {})
record('R09', 'IDENTIDADE_INCORRETA', 'R1: identidade exata (PID + criacao) de um PRE_G06_CAMPAIGN real informada como pai: nao e liberado',
       rc == 2 and c.get('outcome') == 'BLOCKED' and c.get('reason', '').startswith('OWN_TREE_PARENT_PID_MISMATCH'),
       {'parent_pid': p.pid, 'concurrent_pid': dm.pid, 'exit': rc, 'child': c})
dm.kill(); dm.wait()
clean()

# R10 - the parent is gone when the child classifies.
p, out = start('R10_NEW_PARENT_EXITS', 'NEW', {'QUAL_TAMPER': 'parent_exits', 'QUAL_CHILD_DELAY_MS': '2500'})
rc = p.wait(60); c = wait_for(out, 'CHILD')
record('R10', 'IDENTIDADE_INCORRETA', 'R1: pai encerrado antes da classificacao (filho reatribuido a outro pai) bloqueia',
       c.get('outcome') == 'BLOCKED' and c.get('reason', '').split(':')[0] in ('OWN_TREE_PARENT_PID_MISMATCH', 'OWN_TREE_PARENT_NOT_ALIVE')
       and c.get('real_ppid') != p.pid, {'parent_pid': p.pid, 'parent_exit': rc, 'child': c})
time.sleep(0.5)
clean()

# R11 - child started by hand without the parent identity.
p, out = start('R11_NEW_CHILD_NO_IDENTITY', 'NEW', args=('-AutorizoLabD', '-ElevatedChild', '-SharedLogDir', 'x'))
rc = p.wait(60); c = results(out).get('CHILD', {})
record('R11', 'IDENTIDADE_INCORRETA', 'R1: -ElevatedChild sem identidade do pai bloqueia',
       rc == 2 and c.get('outcome') == 'BLOCKED' and c.get('reason', '').startswith('OWN_TREE_PARENT_IDENTITY_MISSING'), {'pid': p.pid, 'exit': rc, 'child': c})
clean()

# R12 - identity arguments without -ElevatedChild.
p, out = start('R12_NEW_ARGS_WITHOUT_CHILD', 'NEW', {'QUAL_DIRECT_ADMIN': '1'}, args=('-AutorizoLabD', '-LauncherParentPid', '1', '-LauncherParentCreation', '5'))
rc = p.wait(60); d = results(out).get('DIRECT_ADMIN', {})
record('R12', 'IDENTIDADE_INCORRETA', 'R1: identidade do pai sem -ElevatedChild bloqueia',
       rc == 2 and d.get('outcome') == 'BLOCKED' and d.get('reason', '').startswith('OWN_TREE_PARENT_ARGS_WITHOUT_ELEVATED_CHILD'), {'pid': p.pid, 'exit': rc, 'result': d})
clean()

# R13 - control: V004 from an elevated prompt passed (the defect is specific to the UAC path).
p, out = start('R13_OLD_DIRECT', 'OLD', {'QUAL_DIRECT_ADMIN': '1'}); rc = p.wait(60); d = results(out).get('DIRECT_ADMIN', {})
record('R13', 'SEM_UAC', 'V004: prompt ja elevado passava (controle)', rc == 0 and d.get('outcome') == 'PASS', {'pid': p.pid, 'exit': rc, 'result': d})
clean()

# Mutants of the R1 fragments, judged by the synthetic suite: each must be killed.
MUTANTS = {
    'M1_SEM_CHECAGEM_DO_PAI_REAL': ('FRAG_FUNCS.ps1', "        if ([int]$self[0].ParentProcessId -ne $ParentPid) {", "        if ($false) {"),
    'M2_SEM_IGUALDADE_DE_CRIACAO': ('FRAG_FUNCS.ps1', "        if ($parentKey -cne $ParentCreation) {", "        if ($false) {"),
    'M3_SEM_PAI_MAIS_ANTIGO': ('FRAG_FUNCS.ps1', "        if ([long]$parentKey -gt [long]$selfKey) {", "        if ($false) {"),
    'M4_SEM_IDENTIDADE_DE_CRIACAO': ('FRAG_FUNCS.ps1', None, None),
    'M5_COMPORTAMENTO_V004': ('FRAG_FUNCS.ps1', "        $own[[string]$ParentPid] = $parentKey", "        $null = $parentKey"),
    'M6_FILTRO_SO_POR_PID': ('FRAG_FUNCS.ps1', "              -not ($own.ContainsKey([string]$_.ProcessId) -and $own[[string]$_.ProcessId] -ceq (CreationKey $_)) })",
                             "              -not ($own.ContainsKey([string]$_.ProcessId) -or [int]$_.ProcessId -eq [int]$self[0].ParentProcessId) })"),
}
mutants = []
for name, (fname, old, new) in MUTANTS.items():
    md = RUNS / ('MUT_' + name)
    if md.exists():
        shutil.rmtree(md)
    shutil.copytree(Q / 'h_new', md)
    text = (md / fname).read_text(encoding='ascii')
    if name == 'M4_SEM_IDENTIDADE_DE_CRIACAO':
        for o in ("        if ($parentKey -cne $ParentCreation) {", "        if ([long]$parentKey -gt [long]$selfKey) {"):
            assert text.count(o) == 1
            text = text.replace(o, "        if ($false) {")
    else:
        assert text.count(old) == 1, name
        text = text.replace(old, new)
    (md / fname).write_text(text, encoding='ascii')
    outj = md / 'synthetic_result.json'
    subprocess.run([str(PWSH), '-NoProfile', '-File', str(Q / 'synthetic_cases.ps1'), '-NewDir', str(md), '-OldDir', str(Q / 'h_old'), '-OutJson', str(outj)],
                   check=False, capture_output=True, timeout=600)
    doc = json.loads(outj.read_text(encoding='utf-8-sig'))
    failed = [c for c in doc['cases'] if not c['pass']]
    released = [c['id'] for c in failed if c['observed_outcome'] == 'PASS' and c['expected'].startswith('BLOCKED')]
    mutants.append({'mutant': name, 'killed': bool(failed), 'failed_cases': [c['id'] for c in failed],
                    'cases_where_mutant_releases_a_process': released})

passed = sum(c['pass'] for c in cases)
doc = {'schema': 'CDT21_G5_V004_R1_REAL_PROCESS_QUALIFICATION_V001', 'platform': 'linux; pwsh ' + subprocess.run([str(PWSH), '--version'], capture_output=True, text=True).stdout.strip(),
       'transport_note': 'ShellExecute/runas e WMI nao existem no Linux: o filho e iniciado pela mesma linha de argumentos do launcher e o snapshot vem de /proc; os fragmentos do launcher rodam sem alteracao.',
       'passed': passed, 'total': len(cases), 'cases': cases,
       'mutants_killed': sum(m['killed'] for m in mutants), 'mutants_total': len(mutants), 'mutants': mutants}
Path(sys.argv[1]).write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding='utf-8')
print('REAL', passed, '/', len(cases), 'MUTANTS', doc['mutants_killed'], '/', len(mutants))
for c in cases:
    if not c['pass']:
        print('FAIL', c['id'], json.dumps(c['observed'])[:600])
for m in mutants:
    print(m)
