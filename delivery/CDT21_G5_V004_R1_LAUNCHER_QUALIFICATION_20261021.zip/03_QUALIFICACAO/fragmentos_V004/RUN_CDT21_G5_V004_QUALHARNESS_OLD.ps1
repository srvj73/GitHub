param([switch]$AutorizoLabD, [switch]$ElevatedChild, [string]$SharedLogDir = '')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
. $env:QUAL_MOCK
$Out = $env:QUAL_OUT
$Role = 'PARENT'; if ($ElevatedChild) { $Role = 'CHILD' }; if ($env:QUAL_DIRECT_ADMIN -eq '1') { $Role = 'DIRECT_ADMIN' }
$LogDir = $env:QUAL_LOGDIR
$Log = Join-Path $Out ('LOG_' + $Role + '_' + $PID + '.txt')
function Log([string]$Line) { [IO.File]::AppendAllText($Log, $Line + "`n") }
function Result($h) {
    $h['role'] = $Role; $h['pid'] = $PID; $h['bound_parent_pid'] = 0
    $me = @(Get-LinuxProcSnapshot | Where-Object { [int]$_.ProcessId -eq $PID }); $h['real_ppid'] = [int]$me[0].ParentProcessId
    [IO.File]::WriteAllText((Join-Path $Out ('RESULT_' + $Role + '_' + $PID + '.json')), (ConvertTo-Json $h -Depth 6))
}
$isAdmin = $ElevatedChild -or ($env:QUAL_DIRECT_ADMIN -eq '1')
try {
    if (-not $isAdmin) {
        $si = New-Object System.Diagnostics.ProcessStartInfo
        $si.FileName = Join-Path $PSHOME 'powershell.exe'
        $si.WorkingDirectory = 'C:\Users\silvi'
        $si.UseShellExecute = $true
        $si.Verb = 'runas'
        $si.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"' + $(if ($AutorizoLabD) { ' -AutorizoLabD' } else { '' }) + ' -ElevatedChild -SharedLogDir "' + $LogDir + '"'
        Log ('UAC_REQUEST=YES LOG_COMPARTILHADO=' + $LogDir)
        # Linux transport of the very same Arguments string (ShellExecute/runas does not exist here).
        $si.FileName = (Get-Process -Id $PID).Path
        $si.WorkingDirectory = $Out
        $si.UseShellExecute = $false
        $si.Verb = ''
        if ($env:QUAL_TAMPER -eq 'pid') { $si.Arguments = $si.Arguments -replace '-LauncherParentPid [0-9]+ -LauncherParentCreation [0-9]+$', ('-LauncherParentPid ' + $env:QUAL_FAKE_PID + ' -LauncherParentCreation ' + $env:QUAL_FAKE_CREATION) }
        $child = [Diagnostics.Process]::Start($si)
        Result @{ outcome = 'LAUNCHED'; arguments = $si.Arguments; child_pid = $child.Id }
        if ($env:QUAL_TAMPER -eq 'parent_exits') { exit 0 }
        $child.WaitForExit()
        exit $child.ExitCode
    }
    if ($env:QUAL_CHILD_DELAY_MS) { Start-Sleep -Milliseconds ([int]$env:QUAL_CHILD_DELAY_MS) }
        $live = @(Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -and
                  ($_.CommandLine.IndexOf('PRE_G06_CAMPAIGN', [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
                   $_.CommandLine.IndexOf('CDT21_G5_V00', [StringComparison]::OrdinalIgnoreCase) -ge 0) })
        foreach ($p in $live) { Log ('LIVE_PROCESS=' + $p.ProcessId + ' ' + $p.Name + ' ' + $p.CommandLine) }
        if ($live.Count -gt 0) { throw 'LIVE_G5_CAMPAIGN_PROCESS: outra campanha G5 esta ativa; aguarde o termino dela' }
        Log 'CAMPANHAS_G5_ATIVAS=0'
    $own = ''; if (Test-Path variable:scan) { $own = $scan.Own }
    Result @{ outcome = 'PASS'; own = $own; live = @() }
    if ($env:QUAL_HOLD_FILE) { while (-not (Test-Path -LiteralPath $env:QUAL_HOLD_FILE)) { Start-Sleep -Milliseconds 100 } }
    exit 0
} catch {
    $own = ''; if (Test-Path variable:scan) { $own = $scan.Own }
    $livePids = @(); if (Test-Path variable:live) { $livePids = @($live | ForEach-Object { [int]$_.ProcessId }) }
    Result @{ outcome = 'BLOCKED'; reason = $_.Exception.Message; own = $own; live = $livePids }
    exit 2
}
