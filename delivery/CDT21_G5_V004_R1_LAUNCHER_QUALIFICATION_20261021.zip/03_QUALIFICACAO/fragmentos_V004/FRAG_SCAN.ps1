        $live = @(Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -and
                  ($_.CommandLine.IndexOf('PRE_G06_CAMPAIGN', [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
                   $_.CommandLine.IndexOf('CDT21_G5_V00', [StringComparison]::OrdinalIgnoreCase) -ge 0) })
        foreach ($p in $live) { Log ('LIVE_PROCESS=' + $p.ProcessId + ' ' + $p.Name + ' ' + $p.CommandLine) }
        if ($live.Count -gt 0) { throw 'LIVE_G5_CAMPAIGN_PROCESS: outra campanha G5 esta ativa; aguarde o termino dela' }
        Log 'CAMPANHAS_G5_ATIVAS=0'
