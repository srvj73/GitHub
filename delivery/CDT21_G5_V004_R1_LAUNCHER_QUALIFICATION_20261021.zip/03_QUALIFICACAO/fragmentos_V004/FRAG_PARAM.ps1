param([switch]$AutorizoLabD, [switch]$ElevatedChild, [string]$SharedLogDir = '')
