param([switch]$AutorizoLabD, [switch]$ElevatedChild, [string]$SharedLogDir = '', [int]$LauncherParentPid = 0, [string]$LauncherParentCreation = '')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
. $env:QUAL_MOCK
$Out = $env:QUAL_OUT
$Role = 'PARENT'; if ($ElevatedChild) { $Role = 'CHILD' }; if ($env:QUAL_DIRECT_ADMIN -eq '1') { $Role = 'DIRECT_ADMIN' }
$LogDir = $env:QUAL_LOGDIR
$Log = Join-Path $Out ('LOG_' + $Role + '_' + $PID + '.txt')
function Log([string]$Line) { [IO.File]::AppendAllText($Log, $Line + "`n") }
function Result($h) {
    $h['role'] = $Role; $h['pid'] = $PID; $h['bound_parent_pid'] = $LauncherParentPid
    $me = @(Get-LinuxProcSnapshot | Where-Object { [int]$_.ProcessId -eq $PID }); $h['real_ppid'] = [int]$me[0].ParentProcessId
    [IO.File]::WriteAllText((Join-Path $Out ('RESULT_' + $Role + '_' + $PID + '.json')), (ConvertTo-Json $h -Depth 6))
}
function CreationKey($Proc) {
    if ($null -eq $Proc.CreationDate) { return '' }
    return [string]([DateTime]$Proc.CreationDate).ToUniversalTime().Ticks
}
function ClassifyG5Processes($Snapshot, [int]$SelfPid, [bool]$IsElevatedChild, [int]$ParentPid, [string]$ParentCreation) {
    # Arvore propria = este processo e, no filho UAC, o pai que o lancou; identidade = PID + instante de criacao.
    $self = @($Snapshot | Where-Object { [int]$_.ProcessId -eq $SelfPid })
    if ($self.Count -ne 1) { throw 'OWN_TREE_SELF_NOT_FOUND' }
    $selfKey = CreationKey $self[0]
    if ($selfKey -notmatch '^[0-9]+$') { throw 'OWN_TREE_SELF_CREATION_MISSING' }
    $own = @{}
    $own[[string]$SelfPid] = $selfKey
    if ($IsElevatedChild) {
        if ($ParentPid -le 0 -or $ParentCreation -notmatch '^[0-9]+$') { throw 'OWN_TREE_PARENT_IDENTITY_MISSING' }
        if ([int]$self[0].ParentProcessId -ne $ParentPid) { throw ('OWN_TREE_PARENT_PID_MISMATCH: pai real=' + $self[0].ParentProcessId + ' informado=' + $ParentPid) }
        $parent = @($Snapshot | Where-Object { [int]$_.ProcessId -eq $ParentPid })
        if ($parent.Count -ne 1) { throw ('OWN_TREE_PARENT_NOT_ALIVE: ocorrencias=' + $parent.Count) }
        $parentKey = CreationKey $parent[0]
        if ($parentKey -cne $ParentCreation) { throw ('OWN_TREE_PARENT_CREATION_MISMATCH: real=' + $parentKey + ' informado=' + $ParentCreation) }
        if ([long]$parentKey -gt [long]$selfKey) { throw 'OWN_TREE_PARENT_NEWER_THAN_CHILD' }
        $own[[string]$ParentPid] = $parentKey
    } elseif ($ParentPid -ne 0 -or $ParentCreation) { throw 'OWN_TREE_PARENT_ARGS_WITHOUT_ELEVATED_CHILD' }
    $live = @($Snapshot | Where-Object { $_.CommandLine -and
              ($_.CommandLine.IndexOf('PRE_G06_CAMPAIGN', [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
               $_.CommandLine.IndexOf('CDT21_G5_V00', [StringComparison]::OrdinalIgnoreCase) -ge 0) -and
              -not ($own.ContainsKey([string]$_.ProcessId) -and $own[[string]$_.ProcessId] -ceq (CreationKey $_)) })
    $desc = (@($own.Keys | Sort-Object) | ForEach-Object { $_ + '@' + $own[$_] }) -join ';'
    return New-Object PSObject -Property @{ Own = $desc; Live = $live }
}
$isAdmin = $ElevatedChild -or ($env:QUAL_DIRECT_ADMIN -eq '1')
try {
    if (-not $isAdmin) {
        $selfProc = @(Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $PID) -ErrorAction Stop)
        if ($selfProc.Count -ne 1) { throw 'OWN_TREE_SELF_NOT_FOUND' }
        $selfCreation = CreationKey $selfProc[0]
        if ($selfCreation -notmatch '^[0-9]+$') { throw 'OWN_TREE_SELF_CREATION_MISSING' }
        if ($env:QUAL_TAMPER -eq 'creation') { $selfCreation = [string]([long]$selfCreation + 1) }
        $si = New-Object System.Diagnostics.ProcessStartInfo
        $si.FileName = Join-Path $PSHOME 'powershell.exe'
        $si.WorkingDirectory = 'C:\Users\silvi'
        $si.UseShellExecute = $true
        $si.Verb = 'runas'
        $si.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"' + $(if ($AutorizoLabD) { ' -AutorizoLabD' } else { '' }) + ' -ElevatedChild -SharedLogDir "' + $LogDir + '" -LauncherParentPid ' + $PID + ' -LauncherParentCreation ' + $selfCreation
        Log ('UAC_REQUEST=YES LOG_COMPARTILHADO=' + $LogDir + ' IDENTIDADE_PAI=' + $PID + '@' + $selfCreation)
        # Linux transport of the very same Arguments string (ShellExecute/runas does not exist here).
        $si.FileName = (Get-Process -Id $PID).Path
        $si.WorkingDirectory = $Out
        $si.UseShellExecute = $false
        $si.Verb = ''
        if ($env:QUAL_TAMPER -eq 'pid') { $si.Arguments = $si.Arguments -replace '-LauncherParentPid [0-9]+ -LauncherParentCreation [0-9]+$', ('-LauncherParentPid ' + $env:QUAL_FAKE_PID + ' -LauncherParentCreation ' + $env:QUAL_FAKE_CREATION) }
        $child = [Diagnostics.Process]::Start($si)
        Result @{ outcome = 'LAUNCHED'; arguments = $si.Arguments; child_pid = $child.Id }
        if ($env:QUAL_TAMPER -eq 'parent_exits') { exit 0 }
        $child.WaitForExit()
        exit $child.ExitCode
    }
    if ($env:QUAL_CHILD_DELAY_MS) { Start-Sleep -Milliseconds ([int]$env:QUAL_CHILD_DELAY_MS) }
        $snapshot = @(Get-CimInstance Win32_Process -ErrorAction Stop)
        $scan = ClassifyG5Processes $snapshot $PID $ElevatedChild.IsPresent $LauncherParentPid $LauncherParentCreation
        Log ('ARVORE_PROPRIA=' + $scan.Own)
        $live = @($scan.Live)
        foreach ($p in $live) { Log ('LIVE_PROCESS=' + $p.ProcessId + ' ' + $p.Name + ' ' + $p.CommandLine) }
        if ($live.Count -gt 0) { throw 'LIVE_G5_CAMPAIGN_PROCESS: outra campanha G5 esta ativa; aguarde o termino dela' }
        Log 'CAMPANHAS_G5_ATIVAS=0'
    $own = ''; if (Test-Path variable:scan) { $own = $scan.Own }
    Result @{ outcome = 'PASS'; own = $own; live = @() }
    if ($env:QUAL_HOLD_FILE) { while (-not (Test-Path -LiteralPath $env:QUAL_HOLD_FILE)) { Start-Sleep -Milliseconds 100 } }
    exit 0
} catch {
    $own = ''; if (Test-Path variable:scan) { $own = $scan.Own }
    $livePids = @(); if (Test-Path variable:live) { $livePids = @($live | ForEach-Object { [int]$_.ProcessId }) }
    Result @{ outcome = 'BLOCKED'; reason = $_.Exception.Message; own = $own; live = $livePids }
    exit 2
}
