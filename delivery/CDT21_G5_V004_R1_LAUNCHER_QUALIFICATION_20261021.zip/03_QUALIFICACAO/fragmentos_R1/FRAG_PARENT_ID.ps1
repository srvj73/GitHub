        $selfProc = @(Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $PID) -ErrorAction Stop)
        if ($selfProc.Count -ne 1) { throw 'OWN_TREE_SELF_NOT_FOUND' }
        $selfCreation = CreationKey $selfProc[0]
        if ($selfCreation -notmatch '^[0-9]+$') { throw 'OWN_TREE_SELF_CREATION_MISSING' }
