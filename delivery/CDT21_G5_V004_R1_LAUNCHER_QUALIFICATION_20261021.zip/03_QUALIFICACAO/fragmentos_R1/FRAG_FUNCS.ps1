function CreationKey($Proc) {
    if ($null -eq $Proc.CreationDate) { return '' }
    return [string]([DateTime]$Proc.CreationDate).ToUniversalTime().Ticks
}
function ClassifyG5Processes($Snapshot, [int]$SelfPid, [bool]$IsElevatedChild, [int]$ParentPid, [string]$ParentCreation) {
    # Arvore propria = este processo e, no filho UAC, o pai que o lancou; identidade = PID + instante de criacao.
    $self = @($Snapshot | Where-Object { [int]$_.ProcessId -eq $SelfPid })
    if ($self.Count -ne 1) { throw 'OWN_TREE_SELF_NOT_FOUND' }
    $selfKey = CreationKey $self[0]
    if ($selfKey -notmatch '^[0-9]+$') { throw 'OWN_TREE_SELF_CREATION_MISSING' }
    $own = @{}
    $own[[string]$SelfPid] = $selfKey
    if ($IsElevatedChild) {
        if ($ParentPid -le 0 -or $ParentCreation -notmatch '^[0-9]+$') { throw 'OWN_TREE_PARENT_IDENTITY_MISSING' }
        if ([int]$self[0].ParentProcessId -ne $ParentPid) { throw ('OWN_TREE_PARENT_PID_MISMATCH: pai real=' + $self[0].ParentProcessId + ' informado=' + $ParentPid) }
        $parent = @($Snapshot | Where-Object { [int]$_.ProcessId -eq $ParentPid })
        if ($parent.Count -ne 1) { throw ('OWN_TREE_PARENT_NOT_ALIVE: ocorrencias=' + $parent.Count) }
        $parentKey = CreationKey $parent[0]
        if ($parentKey -cne $ParentCreation) { throw ('OWN_TREE_PARENT_CREATION_MISMATCH: real=' + $parentKey + ' informado=' + $ParentCreation) }
        if ([long]$parentKey -gt [long]$selfKey) { throw 'OWN_TREE_PARENT_NEWER_THAN_CHILD' }
        $own[[string]$ParentPid] = $parentKey
    } elseif ($ParentPid -ne 0 -or $ParentCreation) { throw 'OWN_TREE_PARENT_ARGS_WITHOUT_ELEVATED_CHILD' }
    $live = @($Snapshot | Where-Object { $_.CommandLine -and
              ($_.CommandLine.IndexOf('PRE_G06_CAMPAIGN', [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
               $_.CommandLine.IndexOf('CDT21_G5_V00', [StringComparison]::OrdinalIgnoreCase) -ge 0) -and
              -not ($own.ContainsKey([string]$_.ProcessId) -and $own[[string]$_.ProcessId] -ceq (CreationKey $_)) })
    $desc = (@($own.Keys | Sort-Object) | ForEach-Object { $_ + '@' + $own[$_] }) -join ';'
    return New-Object PSObject -Property @{ Own = $desc; Live = $live }
}
