        $snapshot = @(Get-CimInstance Win32_Process -ErrorAction Stop)
        $scan = ClassifyG5Processes $snapshot $PID $ElevatedChild.IsPresent $LauncherParentPid $LauncherParentCreation
        Log ('ARVORE_PROPRIA=' + $scan.Own)
        $live = @($scan.Live)
        foreach ($p in $live) { Log ('LIVE_PROCESS=' + $p.ProcessId + ' ' + $p.Name + ' ' + $p.CommandLine) }
        if ($live.Count -gt 0) { throw 'LIVE_G5_CAMPAIGN_PROCESS: outra campanha G5 esta ativa; aguarde o termino dela' }
        Log 'CAMPANHAS_G5_ATIVAS=0'
