        $si = New-Object System.Diagnostics.ProcessStartInfo
        $si.FileName = Join-Path $PSHOME 'powershell.exe'
        $si.WorkingDirectory = 'C:\Users\silvi'
        $si.UseShellExecute = $true
        $si.Verb = 'runas'
        $si.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"' + $(if ($AutorizoLabD) { ' -AutorizoLabD' } else { '' }) + ' -ElevatedChild -SharedLogDir "' + $LogDir + '" -LauncherParentPid ' + $PID + ' -LauncherParentCreation ' + $selfCreation
        Log ('UAC_REQUEST=YES LOG_COMPARTILHADO=' + $LogDir + ' IDENTIDADE_PAI=' + $PID + '@' + $selfCreation)
