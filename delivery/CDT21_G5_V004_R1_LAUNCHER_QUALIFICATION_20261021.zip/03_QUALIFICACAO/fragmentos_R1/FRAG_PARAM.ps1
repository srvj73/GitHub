param([switch]$AutorizoLabD, [switch]$ElevatedChild, [string]$SharedLogDir = '', [int]$LauncherParentPid = 0, [string]$LauncherParentCreation = '')
