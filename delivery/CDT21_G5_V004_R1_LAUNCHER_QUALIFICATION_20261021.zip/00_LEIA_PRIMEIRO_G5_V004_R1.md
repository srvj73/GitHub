# CDT21 — G5 V004 R1: correção da classificação de campanhas concorrentes no launcher

**Papel:** implementador. Este documento não é parecer B06. A custódia normativa permanece com a origem.

## Defeito (achado da origem, confirmado)

O launcher afetado é `RUN_CDT21_G5_V004_20261021.ps1` (`54C5ED1991AE3BEDAC656E96772DB4DF41E5D99A7385B22405AAB39B82393372`).

**Mecanismo:**
1. Nas linhas 798–804, a autoelevação mantém o pai vivo, aguardando o filho.
2. Nas linhas 822–826, o filho elevado exclui apenas `$PID` e procura `CDT21_G5_V00` nas linhas de comando.
3. O pai foi iniciado pelo comando documentado `-File "…\RUN_CDT21_G5_V004_20261021.ps1"`, que contém `CDT21_G5_V00`. Por isso, o filho classifica o próprio pai como campanha concorrente.

**Efeito:** `LIVE_G5_CAMPAIGN_PROCESS` é determinístico no caminho UAC.
- O bloqueio ocorre antes de qualquer efeito: exit 2, sem stage, raiz, laboratório ou escrita em D:.
- Não há risco de segurança, mas a campanha não pode ser executada.
- O caminho a partir de um prompt já elevado não era afetado.

**Causa:** a derivação foi do R2 (V003) para o V004.
- O R2 filtrava `CDT21_G5_V003_SUPERVISOR`, que não aparece no nome do launcher.
- O V004 ampliou o filtro para `CDT21_G5_V00`, que também casa com o nome do próprio launcher.

## Correção — `RUN_CDT21_G5_V004_R1_20261021.ps1` (`E3F83D0A76E4B372C02C4F7AFD28243CE7DB568A8B242810AECEE86396CED2C8`)

O R1 é derivado do launcher defeituoso por `02_DERIVACAO/build_v004_r1_ps1.py`.
- São 7 substituições contadas; o SHA do pai é conferido e a reprodução byte a byte foi verificada.
- O diff completo está em `01_LAUNCHER/V004_TO_R1.diff`: 8 linhas removidas, todas no escopo da classificação.

**Árvore própria = identidade de processo (PID + instante de criação `CreationDate` do CIM):**
- **Pai não elevado.** Antes do UAC, lê a própria identidade e a entrega ao filho em `-LauncherParentPid <PID> -LauncherParentCreation <ticks UTC>`. O log registra `IDENTIDADE_PAI=`.
- **Filho elevado.** Num único snapshot `Win32_Process`, exige quatro condições:
  - o `ParentProcessId` real do filho é igual ao PID informado;
  - o processo com esse PID existe uma única vez;
  - o instante de criação desse processo é idêntico ao informado;
  - o pai é mais antigo que o filho.
  
  Só então exclui exatamente esse par (PID, criação) e a si mesmo. O log registra `ARVORE_PROPRIA=`.
- **Qualquer divergência bloqueia** com `OWN_TREE_*`, antes de qualquer efeito.

**Sem UAC (prompt já elevado):** a árvore própria é só o próprio processo, como no V004. Argumentos de identidade sem `-ElevatedChild` são recusados.

**Inalterados:**
- os marcadores `PRE_G06_CAMPAIGN` e `CDT21_G5_V00`, sem distinção de caixa;
- a mensagem `LIVE_G5_CAMPAIGN_PROCESS`;
- as fases Q/E, os caminhos e a regra de log;
- o supervisor `273E6207…` e a revisão `E84E5C39…`, embutidos byte a byte iguais.

## Qualificação (Linux; os fragmentos do launcher rodam sem alteração)

| Bloco | Resultado |
|---|---|
| Estática | **PASS**: parser 0 erros, nenhum token exclusivo do PS 7, ASCII, CRLF, embutidos idênticos, sem cmdlets destrutivos, sem retomada, diff restrito |
| Snapshots no formato Windows | **28/28** |
| Processos reais pai/filho | **13/13** |
| Mutantes | **6/6 mortos** |

**Snapshots no formato Windows.** As linhas de comando são as reais: explorer, shell interativo, pai documentado, conhost, filho UAC e processo protegido.
- **S01:** o V004 reproduz o defeito; o filho lista o próprio pai, PID 5100.
- **S02:** o R1 passa, com a árvore própria igual a filho + pai.
- **S03–S10:** campanhas concorrentes verdadeiras continuam bloqueando: outra instância inteira, PRE_G06 órfão, supervisor do V003, caixa baixa e processo sem instante legível.
- **S12–S23:** identidade incorreta bloqueia: criação divergente, PID reutilizado, identidade forjada mais nova, identidade de um launcher concorrente real, pai ausente ou ambíguo, argumentos ausentes ou inválidos, processo próprio ausente ou sem instante.
- **S25–S27:** não se libera ancestral nem wrapper.
- **S24:** as linhas do pai produzem os argumentos com a própria identidade.
- **P01:** em 400 snapshots aleatórios, R1 = V004 menos o pai validado, com 0 divergências.

**Processos reais.** O harness é o próprio conjunto de fragmentos do launcher com nome `RUN_CDT21_G5_V004_QUALHARNESS_*`, cuja linha de comando casa com o filtro, como no Windows.
- **R01:** o V004 bloqueia listando o próprio pai.
- **R02:** o R1 passa. A árvore própria é igual ao PID e ao instante de criação calculados de forma independente a partir do kernel.
- **R04/R05/R07:** `PRE_G06_CAMPAIGN` e supervisor reais bloqueiam.
- **R06:** com uma segunda instância real e a primeira viva, a segunda lista o pai e o filho da primeira.
- **R08:** criação adulterada bloqueia.
- **R09:** a identidade exata de um `PRE_G06_CAMPAIGN` real informada como pai não o libera (`PID_MISMATCH`).
- **R10:** pai encerrado antes da classificação bloqueia.
- **R11/R12:** argumentos ausentes ou indevidos bloqueiam.
- **R03/R13:** controles sem UAC.

**Mutantes:** todo enfraquecimento da identidade é detectado. Quatro deles (M2, M3, M4, M6) produziriam PASS com um processo G5 vivo. O M1 tiraria o launcher concorrente 7100 da lista de bloqueio.

| Mutante | Enfraquecimento |
|---|---|
| M1 | sem a checagem do pai real |
| M2 | sem igualdade de criação |
| M3 | sem a exigência de pai mais antigo |
| M4 | sem identidade de criação |
| M5 | comportamento do V004 |
| M6 | exclusão só por PID |

**Transporte Linux:** ShellExecute/runas e WMI não existem fora do Windows. O filho é iniciado com a mesma string de argumentos montada pela linha do launcher, e o snapshot vem de `/proc`.

**Premissa nativa:** no Windows, o processo elevado por runas tem como `ParentProcessId` o processo que pediu a elevação. Se a premissa não valer, o filho bloqueia com `OWN_TREE_PARENT_PID_MISMATCH` antes de qualquer efeito. Nenhum concorrente é liberado.

## Preservado e não executado

| Item | Situação |
|---|---|
| V004 `AD334869…99DD` / código `D2C626FD…66FF` | intactos |
| G0 V004 nativo (bundle `1A5C8E51…`, retorno `AB710D82…`) | não repetido |
| Supervisor (validação 41/41, b2d 4/4) | não tocado |
| Campanha G5 | não executada |
| B06, B07, D4/D5, canário, FULL e produção | não iniciados |

O launcher `54C5ED19…` fica **substituído; não executar**.

RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 21
