"""CDT21 G5 V003 - minimal native supervisor for the frozen PRE_G06 campaign.

Executes only frozen V003 code, in this order:
  1. g5proof/PRE_G06_CAMPAIGN.py main()   (child process, all 38 planned units)
  2. g5proof/PRE_G06_COMPLETENESS.close() (five-part producer, after a PASS)

This supervisor provides only what the frozen campaign requires of its
launcher: an owned R08 run root, canonical TEMP, the extracted package, the
INPUTS witness, OWNER.json in both labs, and the CAMPAIGN.lock held until the
child exits. It never writes a PASS, never edits PACKAGED bytes, never reuses
or relabels V002 evidence and never touches production roots.
B06/B07/D4/D5/canary/FULL: NOT_STARTED.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import threading
import time
import traceback
import uuid
import zipfile

PACKAGE_NAME = 'CDT21_FINAL_PACKAGE_V003_20261020.zip'
PACKAGE_SHA = '69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50'
CODE_SHA = 'D59BC4EE4F0D5C689335C8F478A0342CC0146930E3B0B44C707B6B95267B3953'
MANIFEST_SHA = '5DCC431BD3C22F6DE8B0E4B88F5A1D41CA6F16FCE4B20791C1E097CE10848A51'
CAMPAIGN_REL = 'implementation_v001/candidate/g5proof/PRE_G06_CAMPAIGN.py'
CAMPAIGN_SHA = '347767D17C8526924D87732608CE2D0441E6989275B8E8E3D88E83F6A17FC79A'
COMPLETENESS_REL = 'implementation_v001/candidate/g5proof/PRE_G06_COMPLETENESS.py'
COMPLETENESS_SHA = '15B10B107DBD29FE497F24A0D5AE100EFAEBD5A183BA6E9905C4AF7D43A72068'
REVIEW_NAME = 'CDT19_IMPLEMENTER_SOURCE_REVIEW_V003.json'
WITNESS_NAME = 'CDT19_R08Q1_ENGINEERING_WITNESS.json'
RUN_PARENT = 'CDT20_R08'                       # G5_MULTIWORK_SCENARIOS lab_base
D_LABS = 'D:\\TICKSTORE_CDT19_PRE_G06_LABS'    # PRE_G06_CAMPAIGN CROSS_VOLUME_OWNED_LAB
PRODUCTION = 'D:\\Base CSV'
PLANNED_UNITS = 38
RUN_NAME = re.compile(r'R08_Q1_[0-9]{14}_[0-9a-f]{12}')
RESULT_SCHEMA = 'CDT21_G5_V003_SUPERVISOR_RESULT_V001'


class Blocked(RuntimeError):
    pass


def require(ok, why):
    if not ok:
        raise Blocked(why)


def sha_bytes(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def sha_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest().upper()


def encoded(obj):
    # Same bytes as FULL_CRASH_RECOVERY.encoded (read back by R.read).
    return (json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def write_new(path, raw):
    with open(path, 'xb') as f:
        f.write(raw); f.flush(); os.fsync(f.fileno())
    require(Path(path).read_bytes() == raw, 'READBACK:' + str(path))


def strict_json(raw):
    def pairs(items):
        out = {}
        for k, v in items:
            require(k not in out, 'JSON_DUPLICATE_KEY')
            out[k] = v
        return out
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs)


_out_lock = threading.Lock()
_console = None


def emit(line):
    text = str(line).encode('ascii', 'replace').decode('ascii')
    with _out_lock:
        print(text, flush=True)
        if _console is not None:
            _console.write((str(line) + '\n').encode('utf-8')); _console.flush()


def validate_review(raw):
    """Same binding PRE_G06_COMPLETENESS.close requires; checked before any effect."""
    review = strict_json(raw)
    require(review.get('schema') == 'CDT19_IMPLEMENTER_SOURCE_REVIEW_V001'
            and review.get('status') == 'SOURCE_REVIEW_COMPLETE_PENDING_NATIVE'
            and review.get('package_sha256') == PACKAGE_SHA
            and review.get('code_manifest_sha256') == CODE_SHA
            and review.get('known_fixable_blockers') == []
            and review.get('independent_b06_audit') is False, 'SOURCE_REVIEW_BINDING')
    return review


def extract_package(package, dest):
    """Byte-exact extraction; every member is read back against the archive."""
    dest.mkdir()
    count = 0
    with zipfile.ZipFile(package) as arc:
        require(arc.testzip() is None, 'PACKAGE_CRC')
        names = [i.filename for i in arc.infolist()]
        require(len(names) == len({n.casefold() for n in names}), 'PACKAGE_DUPLICATE_MEMBER')
        for info in arc.infolist():
            name = info.filename
            parts = PurePosixPath(name).parts
            require(name and not name.startswith('/') and '\\' not in name and ':' not in name
                    and all(p not in ('', '.', '..') for p in parts), 'PACKAGE_UNSAFE_MEMBER:' + name)
            target = dest.joinpath(*parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            write_new(target, arc.read(info))
            count += 1
    return count


def verify_extract(package, dest):
    with zipfile.ZipFile(package) as arc:
        for info in arc.infolist():
            if not info.is_dir():
                path = dest.joinpath(*PurePosixPath(info.filename).parts)
                require(path.read_bytes() == arc.read(info), 'TESTED_BYTES_NE_PACKAGED:' + info.filename)


def make_witness(run_id, manifest_sha):
    return {'schema': 'CDT19_R08Q1_ENGINEERING_WITNESS_V001', 'package_name': PACKAGE_NAME,
            'package_sha256': PACKAGE_SHA, 'manifest_sha256': manifest_sha,
            'code_manifest_sha256': CODE_SHA, 'run_id': run_id,
            'qualification_scope': 'OWNED_ISOLATED_NTFS_PRE_B06', 'production_authorized': False,
            'b06': 'NOT_STARTED', 'issued_by': 'CDT21_G5_V003_SUPERVISOR'}


def make_owner(run_id):
    return {'schema': 'CDT19_ENGINEERING_RUN_OWNER_V001', 'package_sha256': PACKAGE_SHA,
            'production_authorized': False, 'run_id': run_id}


def plain_directory(path):
    """Existing component must be a real directory, never a link or junction."""
    if os.path.lexists(path):
        require(path.is_dir() and not path.is_symlink() and not path.is_junction(), 'ALIASED_DIRECTORY:' + str(path))


def build_return(root, stage, out_zip, package_sha, native_sha):
    """Outer return. Duplicates of the V003 package and of R08_RETURN.zip are
    indexed by hash instead of being copied a second time."""
    skip = {'FINAL_G5/INPUTS/FINAL_PACKAGE.zip': package_sha, 'FINAL_G5/INPUTS/NATIVE_RETURN.zip': native_sha}
    picked, index, excluded = [], [], []
    for name in ('R08_RETURN.zip', 'R08_RETURN.sha256', 'ENGINEERING_RESULT.json', 'LIVE_STATUS.json',
                 'OWNER.json', 'RETURN_LOCK_SCOPE.json', 'CDT21_SUPERVISOR_BOOTSTRAP.json'):
        if (root / name).is_file():
            picked.append((root / name, name))
    for name in (WITNESS_NAME, 'TICKSTORE_ISOLATED_INSTALL_WITNESS.json'):
        if (root / 'INPUTS' / name).is_file():
            picked.append((root / 'INPUTS' / name, 'INPUTS/' + name))
    trees = [root / 'FINAL_G5', root / 'SOURCE_REVIEW'] + sorted(root.glob('G5_ASSEMBLY_INPUTS_*'))
    for tree in trees:
        if tree.is_dir():
            for p in sorted(tree.rglob('*')):
                if p.is_file():
                    rel = p.relative_to(root).as_posix()
                    if rel in skip:
                        actual = sha_file(p)
                        excluded.append({'member': rel, 'sha256': actual, 'bytes': p.stat().st_size,
                                         'expected_sha256': skip[rel], 'equal': actual == skip[rel]})
                    else:
                        picked.append((p, rel))
    for p, rel in ((stage / 'CDT21_G5_V003_SUPERVISOR.py', 'SUPERVISOR/CDT21_G5_V003_SUPERVISOR.py'),
                   (stage / 'SUPERVISOR_CONSOLE.log', 'SUPERVISOR/SUPERVISOR_CONSOLE.log')):
        if p.is_file():
            picked.append((p, rel))
    partial = out_zip.with_name(out_zip.name + '.partial')
    with zipfile.ZipFile(partial, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as arc:
        for p, rel in picked:
            if rel.endswith('.zip'):
                arc.write(p, rel, compress_type=zipfile.ZIP_STORED)
            else:
                arc.write(p, rel)
            index.append({'member': rel, 'sha256': sha_file(p), 'bytes': p.stat().st_size})
        arc.writestr('RETURN_INDEX.json', encoded({'schema': 'CDT21_G5_V003_RETURN_INDEX_V001',
                     'run_id': root.name, 'members': index, 'excluded_duplicates': excluded}))
    with zipfile.ZipFile(partial) as arc:
        require(arc.testzip() is None, 'RETURN_CRC')
    os.replace(partial, out_zip)
    return excluded


class SupervisorJob:
    """Kill-on-close Job that holds this supervisor and, by inheritance, the
    whole campaign tree; closing it (normal exit or crash) leaves no orphan."""
    def __init__(self):
        import ctypes
        from ctypes import wintypes as w
        self.ctypes = ctypes
        k = self.k = ctypes.WinDLL('kernel32', use_last_error=True)
        k.CreateJobObjectW.argtypes = [ctypes.c_void_p, w.LPCWSTR]; k.CreateJobObjectW.restype = w.HANDLE
        k.SetInformationJobObject.argtypes = [w.HANDLE, ctypes.c_int, ctypes.c_void_p, w.DWORD]
        k.SetInformationJobObject.restype = w.BOOL
        k.QueryInformationJobObject.argtypes = [w.HANDLE, ctypes.c_int, ctypes.c_void_p, w.DWORD, ctypes.c_void_p]
        k.QueryInformationJobObject.restype = w.BOOL
        k.AssignProcessToJobObject.argtypes = [w.HANDLE, w.HANDLE]; k.AssignProcessToJobObject.restype = w.BOOL
        k.GetCurrentProcess.restype = w.HANDLE
        k.CloseHandle.argtypes = [w.HANDLE]; k.CloseHandle.restype = w.BOOL

        class Basic(ctypes.Structure):
            _fields_ = [('PerProcessUserTimeLimit', ctypes.c_int64), ('PerJobUserTimeLimit', ctypes.c_int64),
                        ('LimitFlags', w.DWORD), ('MinimumWorkingSetSize', ctypes.c_size_t),
                        ('MaximumWorkingSetSize', ctypes.c_size_t), ('ActiveProcessLimit', w.DWORD),
                        ('Affinity', ctypes.c_size_t), ('PriorityClass', w.DWORD), ('SchedulingClass', w.DWORD)]
        class IO(ctypes.Structure):
            _fields_ = [(n, ctypes.c_uint64) for n in ('ReadOperationCount', 'WriteOperationCount',
                         'OtherOperationCount', 'ReadTransferCount', 'WriteTransferCount', 'OtherTransferCount')]
        class Extended(ctypes.Structure):
            _fields_ = [('BasicLimitInformation', Basic), ('IoInfo', IO),
                        ('ProcessMemoryLimit', ctypes.c_size_t), ('JobMemoryLimit', ctypes.c_size_t),
                        ('PeakProcessMemoryUsed', ctypes.c_size_t), ('PeakJobMemoryUsed', ctypes.c_size_t)]
        class Accounting(ctypes.Structure):
            _fields_ = [('TotalUserTime', ctypes.c_int64), ('TotalKernelTime', ctypes.c_int64),
                        ('ThisPeriodTotalUserTime', ctypes.c_int64), ('ThisPeriodTotalKernelTime', ctypes.c_int64),
                        ('TotalPageFaultCount', w.DWORD), ('TotalProcesses', w.DWORD),
                        ('ActiveProcesses', w.DWORD), ('TotalTerminatedProcesses', w.DWORD)]
        self.Accounting = Accounting
        self.handle = k.CreateJobObjectW(None, None)
        require(bool(self.handle), 'SUPERVISOR_JOB_CREATE:' + str(ctypes.get_last_error()))
        limits = Extended(); limits.BasicLimitInformation.LimitFlags = 0x2000  # KILL_ON_JOB_CLOSE
        require(bool(k.SetInformationJobObject(self.handle, 9, ctypes.byref(limits), ctypes.sizeof(limits))),
                'SUPERVISOR_JOB_LIMITS:' + str(ctypes.get_last_error()))
        require(bool(k.AssignProcessToJobObject(self.handle, k.GetCurrentProcess())),
                'SUPERVISOR_JOB_ASSIGN:' + str(ctypes.get_last_error()))

    def active(self):
        info = self.Accounting()
        ok = self.k.QueryInformationJobObject(self.handle, 1, self.ctypes.byref(info),
                                              self.ctypes.sizeof(info), None)
        return int(info.ActiveProcesses) if ok else -1


def volume_filesystem(drive_root):
    import ctypes
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    name = ctypes.create_unicode_buffer(261)
    ok = k.GetVolumeInformationW(ctypes.c_wchar_p(drive_root), None, 0, None, None, None, name, 261)
    require(bool(ok), 'VOLUME_INFORMATION:' + drive_root)
    return name.value


def main(argv=None):
    global _console
    ap = argparse.ArgumentParser(allow_abbrev=False)
    for name in ('package', 'review', 'log-dir', 'stage'):
        ap.add_argument('--' + name, required=True)
    a = ap.parse_args(argv)
    log_dir = Path(os.path.abspath(a.log_dir)); stage = Path(os.path.abspath(a.stage))
    result = {'schema': RESULT_SCHEMA, 'status': 'BLOCKED', 'exit_code': 2, 'phase': 'PREFLIGHT',
              'candidate_sha256': PACKAGE_SHA, 'code_manifest_sha256': CODE_SHA,
              'supervisor_sha256': sha_file(__file__), 'planned_units': PLANNED_UNITS,
              'v002_evidence': 'PRESERVED_NOT_REUSED_NOT_RELABELED', 'production_modified': False,
              'b06': 'NOT_STARTED', 'b07': 'NOT_STARTED', 'd4_d5': 'NOT_STARTED', 'canary': 'NOT_STARTED',
              'full': 'NOT_STARTED', 'physical_powerloss': 'NOT_TESTED_PHYSICAL_POWERLOSS',
              'g5_owner_approval': 'APPROVED_EXPLICIT_V003_BY_ORIGIN_NOT_REQUESTED_AGAIN', 'blockers': []}
    root = None; lock = None; job = None; started = time.monotonic()
    try:
        _console = open(stage / 'SUPERVISOR_CONSOLE.log', 'xb')
        emit('SUPERVISOR=' + str(Path(__file__)) + ' SHA256=' + result['supervisor_sha256'])
        # ---------------------------------------------------------------- preflight (no lab effects)
        require(os.name == 'nt', 'WINDOWS_REQUIRED')
        require(sys.version_info[:2] == (3, 14), 'PYTHON_3_14_REQUIRED:' + sys.version.split()[0])
        import ctypes
        require(bool(ctypes.WinDLL('shell32').IsUserAnAdmin()), 'ELEVATION_REQUIRED')
        package = Path(os.path.abspath(a.package))
        require(package.is_file() and sha_file(package) == PACKAGE_SHA, 'PACKAGE_SHA_MISMATCH')
        review_raw = Path(a.review).read_bytes(); validate_review(review_raw)
        result['source_review_sha256'] = sha_bytes(review_raw)
        local = os.environ.get('LOCALAPPDATA', '')
        require(local and '%' not in local and '~' not in local and Path(local).is_absolute(), 'LOCALAPPDATA_INVALID')
        require(os.path.normcase(os.path.realpath(local)) == os.path.normcase(os.path.abspath(local)),
                'LOCALAPPDATA_NOT_CANONICAL')
        run_parent = Path(local) / RUN_PARENT; d_labs = Path(D_LABS)
        require(Path('D:\\').is_dir(), 'D_VOLUME_REQUIRED')
        require(Path(local).drive.upper() != 'D:', 'RUN_ROOT_MUST_NOT_BE_ON_D')
        require(volume_filesystem(Path(local).drive + '\\') == 'NTFS', 'C_NTFS_REQUIRED')
        require(volume_filesystem('D:\\') == 'NTFS', 'D_NTFS_REQUIRED')
        require(shutil.disk_usage(Path(local).drive + '\\').free >= 4 * 1024**3, 'C_FREE_SPACE_4GIB')
        require(shutil.disk_usage('D:\\').free >= 1 * 1024**3, 'D_FREE_SPACE_1GIB')
        for p in (run_parent, d_labs):
            plain_directory(p)
        require(not Path(os.path.normcase(D_LABS)).is_relative_to(os.path.normcase(PRODUCTION)), 'PRODUCTION_ROOT')
        job = SupervisorJob()
        emit('PREFLIGHT=PASS PYTHON=' + sys.version.split()[0] + ' ELEVATED=YES C_D_NTFS=YES JOB=KILL_ON_CLOSE')
        # ---------------------------------------------------------------- owned run root (lab effects only)
        result['phase'] = 'BOOTSTRAP'
        run_id = 'R08_Q1_' + time.strftime('%Y%m%d%H%M%S') + '_' + uuid.uuid4().hex[:12]
        require(RUN_NAME.fullmatch(run_id) is not None, 'RUN_NAME')
        run_parent.mkdir(exist_ok=True); plain_directory(run_parent)
        root = run_parent / run_id; root.mkdir()
        result.update(run_id=run_id, run_root=str(root))
        emit('RUN_ROOT=' + str(root))
        (root / 'TEMP').mkdir()
        files = extract_package(package, root / 'PACKAGED')
        packaged = root / 'PACKAGED'
        manifest_sha = sha_file(packaged / 'PACKAGE_MANIFEST.json')
        require(manifest_sha == MANIFEST_SHA, 'PACKAGE_MANIFEST_SHA')
        require(sha_file(packaged / CAMPAIGN_REL) == CAMPAIGN_SHA, 'CAMPAIGN_SOURCE_SHA')
        require(sha_file(packaged / COMPLETENESS_REL) == COMPLETENESS_SHA, 'COMPLETENESS_SOURCE_SHA')
        emit('PACKAGED=' + str(packaged) + ' FILES=' + str(files) + ' BYTE_EXACT=YES')
        (root / 'INPUTS').mkdir()
        inputs_pkg = root / 'INPUTS' / PACKAGE_NAME
        shutil.copyfile(package, inputs_pkg)
        require(sha_file(inputs_pkg) == PACKAGE_SHA, 'INPUT_PACKAGE_COPY')
        witness = root / 'INPUTS' / WITNESS_NAME
        write_new(witness, encoded(make_witness(run_id, manifest_sha)))
        owner_raw = encoded(make_owner(run_id))
        write_new(root / 'OWNER.json', owner_raw)
        d_labs.mkdir(exist_ok=True); plain_directory(d_labs)
        dlab = d_labs / run_id; dlab.mkdir()
        write_new(dlab / 'OWNER.json', owner_raw)
        qual_c = root / 'QUAL_C'; qual_d = dlab / 'WRITER_EFFECTFUL'
        qual_c.mkdir(); qual_d.mkdir()
        lock = open(root / 'CAMPAIGN.lock', 'x+b')
        lock.write(encoded({'schema': 'CDT21_G5_V003_CAMPAIGN_LOCK_V001', 'run_id': run_id,
                            'supervisor_pid': os.getpid()}))
        lock.flush(); os.fsync(lock.fileno()); lock.seek(0)
        import msvcrt
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        bootstrap = {'schema': 'CDT21_G5_V003_SUPERVISOR_BOOTSTRAP_V001', 'run_id': run_id,
                     'package_sha256': PACKAGE_SHA, 'code_manifest_sha256': CODE_SHA,
                     'package_manifest_sha256': manifest_sha, 'campaign_source_sha256': CAMPAIGN_SHA,
                     'completeness_source_sha256': COMPLETENESS_SHA,
                     'supervisor_sha256': result['supervisor_sha256'],
                     'source_review_sha256': result['source_review_sha256'],
                     'python': sys.version, 'python_executable': sys.executable,
                     'python_sha256': sha_file(sys.executable), 'localappdata': local,
                     'd_parent': str(dlab), 'temp': str(root / 'TEMP'),
                     'qual_c_parent': str(qual_c), 'qual_d_parent': str(qual_d),
                     'campaign_lock': 'HELD_EXCLUSIVE_BYTE_RANGE', 'supervisor_pid': os.getpid(),
                     'v002_commits_reused': 0, 'production_authorized': False, 'b06': 'NOT_STARTED'}
        write_new(root / 'CDT21_SUPERVISOR_BOOTSTRAP.json', encoded(bootstrap))
        emit('D_LAB=' + str(dlab) + ' OWNER_IDENTICAL=YES WITNESS=' + str(witness))
        emit('SAFE_STOP=' + str(root / 'SAFE_STOP.request') + ' (crie este arquivo para parada segura)')
        # ---------------------------------------------------------------- frozen campaign (child)
        result['phase'] = 'CAMPAIGN'
        env = {k: v for k, v in os.environ.items() if not k.upper().startswith('PYTHON')}
        env.update(TEMP=str(root / 'TEMP'), TMP=str(root / 'TEMP'),
                   TICKSTORE_QUAL_C_PARENT=str(qual_c), TICKSTORE_QUAL_D_PARENT=str(qual_d))
        cmd = [sys.executable, '-I', '-B', str(packaged / CAMPAIGN_REL), '--run-root', str(root),
               '--package', str(inputs_pkg), '--witness', str(witness), '--d-parent', str(dlab)]
        import subprocess
        emit('NATIVE_BEGIN=PRE_G06_CAMPAIGN UNITS=' + str(PLANNED_UNITS) +
             ' ETA_BASE_S=712+UNKNOWN (referencia nativa V002; nao e evidencia)')
        proc = subprocess.Popen(cmd, cwd=str(root), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        def pump():
            for raw in iter(proc.stdout.readline, b''):
                emit(raw.decode('utf-8', 'replace').rstrip('\r\n'))
        reader = threading.Thread(target=pump, daemon=True); reader.start()
        last = 0.0
        while proc.poll() is None:
            try:
                now = time.monotonic()
                if now >= last:
                    commits = len(list((root / 'COMMITS').glob('*.json'))) if (root / 'COMMITS').is_dir() else 0
                    emit('SUPERVISOR_HEARTBEAT OWNED_PROCESSES=' + str(job.active() - 1) +
                         ' COMMITTED_UNIT_RECEIPTS=' + str(commits) + '/' + str(PLANNED_UNITS) +
                         ' ELAPSED_S=' + str(int(now - started)) +
                         ' AS_OF=' + time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
                    last = now + 10
                time.sleep(0.5)
            except KeyboardInterrupt:
                emit('CTRL_C: aguardando o encerramento e o selo da campanha (sem matar o filho)')
        reader.join(60)
        code = proc.returncode
        result['campaign_exit_code'] = code
        emit('NATIVE_END=PRE_G06_CAMPAIGN EXIT_CODE=' + str(code))
        native = root / 'R08_RETURN.zip'
        require(native.is_file(), 'R08_RETURN_NOT_SEALED')
        native_sha = sha_file(native)
        recorded = (root / 'R08_RETURN.sha256').read_text(encoding='ascii').split()[0]
        require(recorded == native_sha, 'R08_RETURN_SHA_FILE_MISMATCH')
        result['native_return_sha256'] = native_sha
        engineering = strict_json((root / 'ENGINEERING_RESULT.json').read_bytes())
        result['campaign_status'] = engineering.get('status')
        if code == 130 or engineering.get('status') == 'SAFE_STOP':
            result.update(status='SAFE_STOP', exit_code=130)
            raise Blocked('CAMPAIGN_SAFE_STOP')
        require(code == 0 and engineering.get('status') == 'PASS_NATIVE_INTEGRATED_PRE_B06'
                and engineering.get('final_zip_sha256') == PACKAGE_SHA
                and engineering.get('code_manifest_sha256') == CODE_SHA, 'CAMPAIGN_NOT_PASS:' +
                str(engineering.get('status')) + ':' + repr(engineering.get('blockers')))
        # ---------------------------------------------------------------- frozen five-part closure
        result['phase'] = 'FIVE_PART_CLOSE'
        verify_extract(package, packaged)
        review = root / 'SOURCE_REVIEW' / REVIEW_NAME
        review.parent.mkdir(); write_new(review, review_raw)
        os.environ.update(TEMP=str(root / 'TEMP'), TMP=str(root / 'TEMP'))
        for folder in ('full', 'control', 'adapter', 'g5proof'):  # same import roots as PRE_G06_CAMPAIGN
            sys.path.insert(0, str(packaged / 'implementation_v001/candidate' / folder))
        import PRE_G06_COMPLETENESS as completeness
        require(Path(completeness.__file__).resolve() == (packaged / COMPLETENESS_REL).resolve(), 'COMPLETENESS_IMPORT_PATH')
        closed = completeness.close(str(inputs_pkg), str(native), str(review), str(root))
        require(closed.get('engineering_five_part_completeness') == 'PASS'
                and closed.get('four_pre_b06_findings') == 'PASS_NATIVE_REGRESSION'
                and closed.get('independent_b06_audit') is False, 'FIVE_PART_NOT_PASS')
        comp_path = root / 'FINAL_G5' / 'ENGINEERING_COMPLETENESS.json'
        comp = strict_json(comp_path.read_bytes())
        require(comp.get('code_manifest_sha256') == CODE_SHA and comp.get('final_package_sha256') == PACKAGE_SHA,
                'COMPLETENESS_BINDING')
        result['five_part'] = {k: {'status': v.get('status'), 'sha256': v.get('sha256')}
                               for k, v in sorted(comp['five_part_completeness'].items())}
        result['engineering_completeness_sha256'] = sha_file(comp_path)
        result['final_engineering_status_sha256'] = sha_file(root / 'FINAL_G5' / 'FINAL_ENGINEERING_STATUS.json')
        result['four_pre_b06_findings_sha256'] = sha_file(root / 'FINAL_G5' / 'FOUR_PRE_B06_FINDINGS.json')
        result['final_engineering_status'] = closed.get('status')
        result.update(status='PASS_NATIVE_V003_G5_TECHNICAL_FIVE_PART', exit_code=0, phase='DONE')
        emit('ENGINEERING_FIVE_PART_COMPLETENESS=PASS FOUR_PRE_B06_FINDINGS=PASS_NATIVE_REGRESSION B06=NOT_STARTED')
    except BaseException as exc:
        if result['status'] != 'SAFE_STOP':
            result['exit_code'] = {'PREFLIGHT': 2, 'BOOTSTRAP': 2, 'CAMPAIGN': 3, 'FIVE_PART_CLOSE': 4}.get(result['phase'], 2)
        result['blockers'].append(type(exc).__name__ + ':' + str(exc))
        result['traceback'] = traceback.format_exc()
        if root is not None:
            result['partial_effect_scope'] = 'RUN_OWNED_LAB_ONLY'
        emit('SUPERVISOR_BLOCKED=' + result['blockers'][-1])
        emit('PRIMARY_TRACEBACK_BEGIN\n' + result['traceback'] + 'PRIMARY_TRACEBACK_END')
    finally:
        if job is not None:
            result['owned_processes_at_end'] = job.active() - 1
            if result['owned_processes_at_end'] != 0 and result['exit_code'] == 0:
                result.update(status='BLOCKED', exit_code=3)
                result['blockers'].append('SUPERVISOR_OWNED_ORPHANS:' + str(result['owned_processes_at_end']))
        if lock is not None:
            lock.close()  # releases the byte-range lock after the child exited
        result['seconds'] = round(time.monotonic() - started, 3)
        if root is not None:
            try:
                ret = log_dir / 'CDT21_G5_V003_RETURN.zip'
                excluded = build_return(root, stage, ret, PACKAGE_SHA, result.get('native_return_sha256'))
                result['return_zip'] = str(ret); result['return_sha256'] = sha_file(ret)
                result['return_excluded_duplicates'] = excluded
                if result['exit_code'] == 0:
                    require(all(e['equal'] for e in excluded) and len(excluded) == 2, 'RETURN_DUPLICATE_IDENTITY')
                emit('RETURN=' + str(ret) + ' SHA256=' + result['return_sha256'])
            except BaseException as exc:
                result['blockers'].append('RETURN_PACKAGING:' + type(exc).__name__ + ':' + str(exc))
                if result['exit_code'] == 0:
                    result.update(status='BLOCKED', exit_code=5)
                emit('RETURN_PACKAGING_FAILED=' + str(exc))
        try:
            (log_dir / 'SUPERVISOR_RESULT.json').write_bytes(
                (json.dumps(result, sort_keys=True, indent=1, ensure_ascii=True) + '\n').encode('ascii'))
            emit('SUPERVISOR_RESULT=' + str(log_dir / 'SUPERVISOR_RESULT.json') +
                 ' SHA256=' + sha_file(log_dir / 'SUPERVISOR_RESULT.json'))
        except BaseException as exc:
            emit('SUPERVISOR_RESULT_WRITE_FAILED=' + str(exc))
        emit('SUPERVISOR_STATUS=' + result['status'] + ' EXIT_CODE=' + str(result['exit_code']))
        if _console is not None:
            _console.close(); _console = None
    return result['exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
