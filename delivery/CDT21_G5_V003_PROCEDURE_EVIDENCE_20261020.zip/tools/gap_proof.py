"""Unit-gap proof for the V003 five-part G5 receipt, derived from frozen V003 code.

Usage: gap_proof.py <V003_EXTRACT> <V002_ZIP> <V002_NATIVE_EVIDENCE_DIR> <OUT_JSON>
Reads constants from the frozen modules (no hand-typed role lists) and the
preserved V002 commits; writes one canonical JSON.
"""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

ext, v2zip, v2native, out = map(Path, sys.argv[1:5])
cand = ext / 'implementation_v001' / 'candidate'
for folder in ('full', 'control', 'adapter', 'g5proof'):
    sys.path.insert(0, str(cand / folder))
import FULL_G5_COMPLETE_PROOF_GATE as gate          # noqa: E402
import PRE_G06_CAMPAIGN as campaign                 # noqa: E402
import PRE_G06_COMPLETENESS as completeness         # noqa: E402

V3_PKG = '69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50'
V3_CODE = 'D59BC4EE4F0D5C689335C8F478A0342CC0146930E3B0B44C707B6B95267B3953'
G0_UNITS = ('CDT21_F01_LEGACY_ENTRY_FENCE', 'CDT21_SUITE_adapter_tests.py', 'CDT21_SUITE_test_state_cas_recovery.py',
            'CDT21_DELTA_test_cdt19_integrated_crash_recovery.py', 'CDT21_SUITE_test_operator_entry_points.py',
            'CDT21_SUITE_test_canary_receipt_readback.py', 'CDT21_SUITE_test_stage_canary_physical_publication.py',
            'CDT21_SUITE_test_stageb_full_physical_closure.py', 'CDT21_SUITE_test_cdt17_full_composition_scope.py',
            'CDT21_SUITE_test_legacy_entry_isolation.py', 'CDT21_PRE_B06_11_CHAIN')


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


v2 = zipfile.ZipFile(v2zip)
v2_code = sha(v2.read('implementation_v001/RUNTIME_CODE_MANIFEST.json'))
v2_pkg = sha(v2zip.read_bytes())
v3_manifest = json.loads((ext / 'implementation_v001/RUNTIME_CODE_MANIFEST.json').read_bytes())
v2_manifest = json.loads(v2.read('implementation_v001/RUNTIME_CODE_MANIFEST.json'))
v3_files = {r['path']: r['sha256'] for r in v3_manifest['files']}
v2_files = {r['path']: r['sha256'] for r in v2_manifest['files']}
runtime_changed = sorted(p for p in set(v3_files) | set(v2_files) if v3_files.get(p) != v2_files.get(p))

plan = (['G5_' + n for n in ('PS51_INSTALL_MENU', 'STAGE_B_REAL_ISOLATED_PATH_NATIVE', 'D4_REAL_ISOLATED_PATH_NATIVE')] +
        ['SUITE_' + n for n in gate.SUITES if n not in campaign.STAGE_SUITES] +
        ['DELTA_' + n for n in campaign.EXTRA] + ['PRE_B06_11_CHAIN', 'G3_G6_NATIVE'])
contracted = sorted({'SUITE_' + n for n in gate.SUITES} | {'G5_' + n for n in gate.PROOFS} | {'PRE_B06_11_CHAIN'})
required_delta = ['DELTA_' + n for n in completeness.REQUIRED_DELTA]
finding_units = sorted({k for cases in completeness.FINDINGS.values() for k, _ in cases})


def producer_of(role):
    if role in ('G5_PROCESS_TREE_CRASH_CONTAINMENT', 'G5_SAFE_STOP_RESUME_ROW_GROUP', 'G5_POWERLOSS_EMULATED'):
        return 'G3_G6_NATIVE (projected by PRE_G06_PROOF_PROJECTION.produce)'
    if role.startswith('SUITE_') and role[6:] in campaign.STAGE_SUITES:
        return 'G5_STAGE_B_REAL_ISOLATED_PATH_NATIVE (SEALED_NATIVE_LOGS harvested)'
    return role


def v2_commit(key):
    p = v2native / 'COMMITS' / (key + '.json')
    if not p.is_file():
        return None
    obj = json.loads(p.read_bytes())
    return {'package_sha256': obj['package_sha256'], 'code_sha256': obj['code_sha256'],
            'status': obj['result'].get('status'), 'reusable_for_v003': False,
            'run_unit_reuse_check': 'COMMITTED_INPUT_DRIFT (package_sha256/code_sha256 != V003)'}


def g0_cover(key):
    name = 'CDT21_' + key
    return name if name in G0_UNITS else None


def test_source(key):
    name = key.split('_', 1)[1] if key.startswith(('SUITE_', 'DELTA_')) else None
    if not name:
        return None
    rel = campaign.suite_path(name).relative_to(ext).as_posix()
    v3raw = (ext / rel).read_bytes()
    try:
        v2raw = v2.read(rel)
    except KeyError:
        v2raw = None
    return {'path': rel, 'v003_sha256': sha(v3raw), 'unchanged_since_v002': v2raw is not None and sha(v2raw) == sha(v3raw)}


units = []
for key in plan:
    roles = [r for r in contracted if producer_of(r).startswith(key)] + ([key] if key in required_delta else [])
    reasons = []
    if key in contracted:
        reasons.append('FULL_G5_COMPLETE_PROOF_GATE.verify_native_campaign: tests set must equal the 31 roles, each bound to V003')
    if key == 'G5_STAGE_B_REAL_ISOLATED_PATH_NATIVE':
        reasons.append('source of 4 STAGE suite roles (logs harvested from its SEALED_NATIVE_LOGS)')
    if key == 'G3_G6_NATIVE':
        reasons.append('verify_causal_projection: WORK/G3_G6_NATIVE scenarios project 3 proof roles bound to V003 code/package')
    if key in required_delta:
        reasons.append('PRE_G06_COMPLETENESS.close REQUIRED_DELTA: COMMIT bound to V003 package/code, skipped=False')
    if key in finding_units:
        reasons.append('PRE_G06_COMPLETENESS.FINDINGS: sealed native log line bound to the result')
    mandatory = bool(reasons)
    if not mandatory:
        reasons.append('not read by gate/close; executed unconditionally by frozen PRE_G06_CAMPAIGN.main plan '
                       '(diagnostic=True); removing it requires modifying frozen code')
    units.append({'unit': key, 'contract_mandatory': mandatory, 'roles_produced': sorted(set(roles)),
                  'why': reasons, 'v002_commit': v2_commit(key), 'v003_g0_unit': g0_cover(key),
                  'test_source': test_source(key),
                  'v003_status': 'MISSING_NO_V003_BOUND_NATIVE_COMMIT'})

result = {
    'schema': 'CDT21_G5_V003_UNIT_GAP_PROOF_V001',
    'candidate_sha256': V3_PKG, 'code_manifest_sha256': V3_CODE,
    'parent_v002_sha256': v2_pkg, 'parent_v002_code_manifest_sha256': v2_code,
    'frozen_sources': {rel: sha((ext / rel).read_bytes()) for rel in (
        'implementation_v001/candidate/control/G5_FINAL_COMPLETENESS_PRODUCER.py',
        'implementation_v001/candidate/control/FULL_G5_COMPLETE_PROOF_GATE.py',
        'implementation_v001/candidate/g5proof/PRE_G06_CAMPAIGN.py',
        'implementation_v001/candidate/g5proof/PRE_G06_COMPLETENESS.py',
        'implementation_v001/candidate/g5proof/G5_PROOF_RUNNERS.py')},
    'runtime_files_changed_v002_to_v003': runtime_changed,
    'binding_granularity': 'whole RUNTIME_CODE_MANIFEST sha and whole final ZIP sha per unit, receipt and projection; '
                           'no per-file or delta-only binding exists in the frozen gate/producer/close',
    'contracted_roles': contracted, 'contracted_role_count': len(contracted),
    'required_delta': required_delta, 'finding_units': finding_units,
    'campaign_plan_units': len(plan),
    'mandatory_executed_units': sum(u['contract_mandatory'] for u in units),
    'diagnostic_units_in_frozen_plan': [u['unit'] for u in units if not u['contract_mandatory']],
    'units': units,
    'v002_commits_preserved': len(list((v2native / 'COMMITS').glob('*.json'))),
    'v003_g0': {'schema': 'CDT21_F01_F04_G0_NATIVE_QUALIFICATION_V001', 'units': list(G0_UNITS),
                'origin_verified': '11/11 units, 148/148 tests',
                'return_sha256': 'BADAF97EE6FFD7E7D3FCD812758288A4F0D3233239AED3A3969E175F61C1397C',
                'why_not_campaign_evidence': [
                    'schema is not CDT19_PRE_B06_NATIVE_ENGINEERING_V002 / status not PASS_NATIVE_INTEGRATED_PRE_B06',
                    'unit keys use the CDT21_ namespace; gate requires set(tests) == 31 exact roles',
                    'same test file as %d of %d plan units and %d of %d contracted roles; 0 G5 proof receipts; '
                    '0 G3/G6 projection; REQUIRED_DELTA covered: %d of %d, under a CDT21_ key' % (
                        sum(1 for u in units if u['v003_g0_unit']), len(plan),
                        sum(1 for r in contracted if 'CDT21_' + r in G0_UNITS), len(contracted),
                        sum(1 for r in required_delta if 'CDT21_' + r in G0_UNITS), len(required_delta)),
                    'campaign COMMITS are keyed by run root; REUSE_COMMITTED needs COMMITS/<key>.json of the same run root',
                    'G0 return bytes are held by the origin; they are preserved, not copied or renamed']},
    'delta_only_route': {
        'status': 'NOT_CONTRACT_COMPATIBLE',
        'reasons': [
            'any V002 commit fails run_unit COMMITTED_INPUT_DRIFT and gate NATIVE_G5_SOURCE_BINDING (executed negative control)',
            'relabelling V002 records to V003 hashes is fabrication and is also rejected deeper by proof/dossier bindings (executed negative control)',
            'a delta-only verifier would require changing the frozen gate/producer/close: new bytes, new freeze, contrary to NO_REPUBLISH_V003_AS_NEW_BYTES',
            'a partial plan would require a non-frozen orchestrator authoring ENGINEERING_RESULT: not qualified and equivalent to fabricating the campaign result']},
    'minimal_qualified_procedure': {
        'what': 'frozen PRE_G06_CAMPAIGN.main (38-unit plan, one run root) + frozen PRE_G06_COMPLETENESS.close',
        'supervisor': 'CDT21_G5_V003_SUPERVISOR.py (launcher obligations only; writes no PASS)',
        'native_baseline_seconds_observed_part': sum(v for k, v in campaign.UNIT_BASELINE_S.items()),
        'units_without_baseline': [k for k in plan if k not in campaign.UNIT_BASELINE_S]},
}
out.write_bytes((json.dumps(result, sort_keys=True, separators=(',', ':')) + '\n').encode('ascii'))
print('plan', len(plan), 'mandatory', result['mandatory_executed_units'], 'roles', len(contracted),
      'diag', result['diagnostic_units_in_frozen_plan'], 'changed', len(runtime_changed))
