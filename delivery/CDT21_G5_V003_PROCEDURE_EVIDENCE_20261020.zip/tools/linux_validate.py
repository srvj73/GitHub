"""Linux validation of the V003 G5 supervisor against frozen V003 code.

Usage: linux_validate.py <SUPERVISOR.py> <REVIEW.json> <V003_ZIP> <V002_NATIVE_DIR> <WORKDIR> <OUT_JSON>
Windows-only steps (Job, byte-range lock, NTFS, campaign units) are not
simulated; this proves the supervisor's inputs satisfy the frozen checks and
that the frozen gate refuses V002 evidence for V003.
"""
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import types
import zipfile
from pathlib import Path

sup_path, review_path, v3zip, v2native, work, out = map(Path, sys.argv[1:7])
checks = {}


def record(name, ok, detail=''):
    checks[name] = {'status': 'PASS' if ok else 'FAIL', 'detail': str(detail)[:600]}
    print(('PASS ' if ok else 'FAIL ') + name + ' ' + str(detail)[:200], flush=True)


def raises(fn, needle):
    try:
        fn()
    except BaseException as exc:
        return needle in (type(exc).__name__ + ':' + str(exc)), type(exc).__name__ + ':' + str(exc)
    return False, 'NO_EXCEPTION'


spec = importlib.util.spec_from_file_location('sup', sup_path)
S = importlib.util.module_from_spec(spec); spec.loader.exec_module(S)
review_raw = review_path.read_bytes()

# 1. review binding identical to PRE_G06_COMPLETENESS.close
S.validate_review(review_raw); record('review_binding_accepted', True, S.sha_bytes(review_raw))
bad = json.loads(review_raw); bad['package_sha256'] = '4942871541629C3B38F47EDA55EA2C9E310361533887CB55E577D9641542E7C5'
record('review_v002_package_rejected', *raises(lambda: S.validate_review(json.dumps(bad).encode()), 'SOURCE_REVIEW_BINDING'))

# 2. byte-exact extraction accepted by the frozen verify_package
if work.exists():
    shutil.rmtree(work)
root = work / 'CDT20_R08' / 'R08_Q1_20261020233000_0123456789ab'
root.mkdir(parents=True); (root / 'TEMP').mkdir()
n = S.extract_package(v3zip, root / 'PACKAGED')
S.verify_extract(v3zip, root / 'PACKAGED')
record('extract_byte_exact', n > 300, 'files=' + str(n))
cand = root / 'PACKAGED/implementation_v001/candidate'
for folder in ('full', 'control', 'adapter', 'g5proof'):
    sys.path.insert(0, str(cand / folder))
import PRE_G06_CAMPAIGN as C  # noqa: E402  (imported from the extraction)
import FULL_G5_COMPLETE_PROOF_GATE as gate  # noqa: E402
import G5_FINAL_COMPLETENESS_PRODUCER as producer  # noqa: E402
import FULL_CRASH_RECOVERY as R  # noqa: E402
code, members = C.verify_package(v3zip)
record('frozen_verify_package_on_supervisor_extraction', code == S.CODE_SHA, code)
record('pinned_sources', S.sha_file(root / 'PACKAGED' / S.CAMPAIGN_REL) == S.CAMPAIGN_SHA and
       S.sha_file(root / 'PACKAGED' / S.COMPLETENESS_REL) == S.COMPLETENESS_SHA and
       S.sha_file(root / 'PACKAGED/PACKAGE_MANIFEST.json') == S.MANIFEST_SHA)

# 3. INPUTS witness accepted by the frozen campaign check and by G5_PROOF_RUNNERS
(root / 'INPUTS').mkdir(); shutil.copyfile(v3zip, root / 'INPUTS' / S.PACKAGE_NAME)
witness = root / 'INPUTS' / S.WITNESS_NAME
S.write_new(witness, S.encoded(S.make_witness(root.name, S.MANIFEST_SHA)))
w = R.read(witness)[0]
record('campaign_witness_binding', w['package_sha256'] == R.sha(v3zip.read_bytes())
       and w['manifest_sha256'] == R.sha(members['PACKAGE_MANIFEST.json']))
import G5_PROOF_RUNNERS as P  # noqa: E402
ns = types.SimpleNamespace(witness=str(witness), run_root=str(root), final_zip_sha256=S.PACKAGE_SHA,
                           final_extract=str(root / 'PACKAGED'))
derived = P._isolated_install_witness(ns)
record('proof_runner_install_witness_derived', json.loads(derived.read_bytes())['package_sha256'] == S.PACKAGE_SHA,
       derived.name)

# 4. OWNER.json accepted by campaign RUN_OWNER/D_LAB_OWNER and by the G3 run-owner check
owner_raw = S.encoded(S.make_owner(root.name)); S.write_new(root / 'OWNER.json', owner_raw)
dlab = work / 'TICKSTORE_CDT19_PRE_G06_LABS' / root.name; dlab.mkdir(parents=True)
S.write_new(dlab / 'OWNER.json', owner_raw)
o = R.read(root / 'OWNER.json')[0]
record('owner_accepted', o['package_sha256'] == R.sha(v3zip.read_bytes()) and o['run_id'] == root.name
       and R.read(dlab / 'OWNER.json')[0] == o and o['schema'] == 'CDT19_ENGINEERING_RUN_OWNER_V001'
       and o['production_authorized'] is False and dlab.name == root.name
       and dlab.parent.name == 'TICKSTORE_CDT19_PRE_G06_LABS')
record('consumer_run_id_syntax', len(C.consumer_evidence_run_id(root.name)) == 32)

# 5. frozen campaign fails closed off Windows; seals a BLOCKED return with the lock excluded
lock = open(root / 'CAMPAIGN.lock', 'x+b'); lock.write(b'L'); lock.flush(); fcntl.lockf(lock, fcntl.LOCK_EX)
env = dict(os.environ, TEMP=str(root / 'TEMP'), TMP=str(root / 'TEMP'), LOCALAPPDATA=str(work))
r = subprocess.run([sys.executable, '-I', '-B', str(root / 'PACKAGED' / S.CAMPAIGN_REL), '--run-root', str(root),
                    '--package', str(root / 'INPUTS' / S.PACKAGE_NAME), '--witness', str(witness),
                    '--d-parent', str(dlab)], cwd=root, env=env, capture_output=True, text=True, timeout=600)
lock.close()
res = json.loads((root / 'ENGINEERING_RESULT.json').read_bytes())
with zipfile.ZipFile(root / 'R08_RETURN.zip') as z:
    names = z.namelist()
record('campaign_fail_closed_off_windows', r.returncode == 3 and res['status'] == 'BLOCKED'
       and 'WINDOWS_REQUIRED' in res['blockers'][0] and 'CAMPAIGN.lock' not in names
       and 'OWNER.json' in names, 'exit=%s blockers=%s' % (r.returncode, res['blockers']))
index = {x['path']: x for x in json.loads(members['implementation_v001/RUNTIME_CODE_MANIFEST.json'])['files']}
blocked_raw = (root / 'R08_RETURN.zip').read_bytes()
record('gate_rejects_blocked_campaign', *raises(lambda: gate.verify_native_campaign(
    blocked_raw, code, S.PACKAGE_SHA, index, final_members=members), 'NATIVE_G5_RUN_NOT_PASS'))

# 6. frozen close(): accepts the review, then refuses a non-PASS native return
import PRE_G06_COMPLETENESS as F  # noqa: E402
(root / 'SOURCE_REVIEW').mkdir(); rv = root / 'SOURCE_REVIEW' / S.REVIEW_NAME; S.write_new(rv, review_raw)
ok, detail = raises(lambda: F.close(str(root / 'INPUTS' / S.PACKAGE_NAME), str(root / 'R08_RETURN.zip'),
                                    str(rv), str(root)), 'NATIVE_G5_RUN_NOT_PASS')
record('close_accepts_review_then_refuses_blocked_native', ok and 'SOURCE_REVIEW' not in detail, detail)
foreign = work / 'FOREIGN_REVIEW.json'; fr = json.loads(review_raw); fr['code_manifest_sha256'] = 'F' * 64
foreign.write_bytes(R.encoded(fr))
record('close_rejects_foreign_review', *raises(lambda: F.close(str(root / 'INPUTS' / S.PACKAGE_NAME),
       str(root / 'R08_RETURN.zip'), str(foreign), str(root)), 'SOURCE_REVIEW_BINDING'))
record('no_final_g5_written_on_failure', not (root / 'FINAL_G5').exists())

# 7. V002 native evidence: frozen gate refuses it for V003 (identity binding)
v2zip = work / 'V002_NATIVE_REBUILT.zip'
with zipfile.ZipFile(v2zip, 'x', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(v2native.rglob('*')):
        rel = p.relative_to(v2native).as_posix()
        if p.is_file() and not rel.startswith(('FINAL_G5/', 'QUAL_C/')):
            z.write(p, rel)
v2raw = v2zip.read_bytes()
record('v002_native_refused_for_v003', *raises(lambda: gate.verify_native_campaign(
    v2raw, code, S.PACKAGE_SHA, index, final_members=members), 'NATIVE_G5_SOURCE_BINDING'))
if len(sys.argv) > 7:
    # Same rebuilt bytes under the V002 identity: binding and 11-chain dossier pass;
    # it stops only at the causal projection (WORK/G3_G6_NATIVE not in the handoff subset).
    v2code, v2members = producer.verify_final_zip(sys.argv[7])
    v2index = {x['path']: x for x in json.loads(v2members['implementation_v001/RUNTIME_CODE_MANIFEST.json'])['files']}
    record('v002_evidence_valid_under_v002_identity_until_causal_subset', *raises(lambda: gate.verify_native_campaign(
        v2raw, v2code, R.sha(Path(sys.argv[7]).read_bytes()), v2index, final_members=v2members),
        'NATIVE_CAUSAL_SUMMARY_MISSING'))
# Negative control only: relabelling the V002 result to V003 hashes is still refused.
relabel = work / 'V002_RELABELLED_NEGATIVE_CONTROL.zip'
with zipfile.ZipFile(v2zip) as src, zipfile.ZipFile(relabel, 'x', zipfile.ZIP_DEFLATED) as dst:
    for name in src.namelist():
        raw = src.read(name)
        if name == 'ENGINEERING_RESULT.json':
            obj = json.loads(raw); obj['code_manifest_sha256'] = code; obj['final_zip_sha256'] = S.PACKAGE_SHA
            raw = R.encoded(obj)
        dst.writestr(name, raw)
try:
    gate.verify_native_campaign(relabel.read_bytes(), code, S.PACKAGE_SHA, index, final_members=members)
    record('relabelled_v002_refused', False, 'ACCEPTED')
except BaseException as exc:
    record('relabelled_v002_refused', True, type(exc).__name__ + ':' + str(exc))
relabel.unlink()

# 8. run_unit refuses a V002 commit placed in a V003 root
(root / 'COMMITS').mkdir(exist_ok=True)
shutil.copyfile(v2native / 'COMMITS' / 'SUITE_adapter_tests.py.json', root / 'COMMITS' / 'SUITE_adapter_tests.py.json')
record('run_unit_refuses_v002_commit', *raises(lambda: C.run_unit(dict(
    root=str(root), key='SUITE_adapter_tests.py', kind='suite', name='adapter_tests.py',
    package_sha256=S.PACKAGE_SHA, code_sha256=code)), 'COMMITTED_INPUT_DRIFT'))

# 9. outer return packaging over the (blocked) Linux root
stage = work / 'STAGE'; stage.mkdir(); shutil.copyfile(sup_path, stage / 'CDT21_G5_V003_SUPERVISOR.py')
(stage / 'SUPERVISOR_CONSOLE.log').write_text('linux validation\n')
logdir = work / 'LOG'; logdir.mkdir()
S.build_return(root, stage, logdir / 'CDT21_G5_V003_RETURN.zip', S.PACKAGE_SHA, R.sha(blocked_raw))
with zipfile.ZipFile(logdir / 'CDT21_G5_V003_RETURN.zip') as z:
    idx = json.loads(z.read('RETURN_INDEX.json')); names = z.namelist()
record('return_packaging', 'R08_RETURN.zip' in names and 'SUPERVISOR/CDT21_G5_V003_SUPERVISOR.py' in names
       and 'CAMPAIGN.lock' not in names and len(idx['members']) == len(names) - 1, 'members=' + str(len(names)))

# 10. supervisor main() fails closed before any lab effect off Windows
stage2 = work / 'STAGE2'; stage2.mkdir(); shutil.copyfile(sup_path, stage2 / 'CDT21_G5_V003_SUPERVISOR.py')
rv2 = stage2 / S.REVIEW_NAME; rv2.write_bytes(review_raw)
log2 = work / 'LOG2'; log2.mkdir()
r = subprocess.run([sys.executable, '-I', '-B', str(stage2 / 'CDT21_G5_V003_SUPERVISOR.py'), '--package', str(v3zip),
                    '--review', str(rv2), '--log-dir', str(log2), '--stage', str(stage2)],
                   capture_output=True, text=True, timeout=120, env=dict(os.environ, LOCALAPPDATA=str(work / 'LA2')))
sres = json.loads((log2 / 'SUPERVISOR_RESULT.json').read_bytes())
record('supervisor_fail_closed_preflight', r.returncode == 2 and sres['status'] == 'BLOCKED'
       and sres['blockers'] == ['Blocked:WINDOWS_REQUIRED'] and 'run_root' not in sres
       and not (work / 'LA2').exists() and not (log2 / 'CDT21_G5_V003_RETURN.zip').exists(),
       'exit=%s blockers=%s' % (r.returncode, sres['blockers']))

summary = {'schema': 'CDT21_G5_V003_SUPERVISOR_LINUX_VALIDATION_V001', 'platform': sys.platform,
           'python': sys.version.split()[0], 'supervisor_sha256': S.sha_file(sup_path),
           'review_sha256': S.sha_bytes(review_raw), 'candidate_sha256': S.PACKAGE_SHA,
           'checks': checks, 'passed': sum(v['status'] == 'PASS' for v in checks.values()), 'total': len(checks),
           'windows_only_not_simulated': ['SupervisorJob (kill-on-close Job)', 'msvcrt byte-range CAMPAIGN.lock',
                                          'GetVolumeInformationW NTFS', 'IsUserAnAdmin', '38 native campaign units',
                                          'five-part producer on a PASS native return'],
           'v003_bytes_modified': False}
out.write_bytes((json.dumps(summary, sort_keys=True, indent=1) + '\n').encode('ascii'))
print('PASSED', summary['passed'], '/', summary['total'])
sys.exit(0 if summary['passed'] == summary['total'] else 1)
