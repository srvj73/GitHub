"""Generate RUN_CDT21_G5_V003_FIVE_PART_20261020.ps1 (ASCII, CRLF) embedding the
supervisor and the source review as base64, each pinned by SHA-256."""
import base64
import hashlib
import sys
from pathlib import Path

sup, review, out = map(Path, sys.argv[1:4])


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def b64_lines(raw):
    text = base64.b64encode(raw).decode('ascii')
    return '\n'.join(text[i:i + 100] for i in range(0, len(text), 100))


sup_raw, rev_raw = sup.read_bytes(), review.read_bytes()
TEMPLATE = r"""#requires -Version 5.1
# TICKSTORE CDT21 - campanha nativa integrada G5 sobre o candidato V003 congelado e recibo tecnico de cinco partes.
# Execute a partir de PS C:\Users\silvi> em PowerShell 5.1 ELEVADO:
#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\silvi\OneDrive\Downloads\RUN_CDT21_G5_V003_FIVE_PART_20261020.ps1"
# Pre-requisito: C:\Users\silvi\OneDrive\Downloads\CDT21_FINAL_PACKAGE_V003_20261020.zip (o mesmo do G0 V003).
# Log sempre em pasta absoluta fixa, nova a cada execucao, independente da pasta atual:
#   C:\Users\silvi\OneDrive\Downloads\CDT21_G5_V003_RUNS\G5_<yyyyMMdd_HHmmss_fff_PID>\RUN_LOG.txt
# Executa somente codigo congelado do V003: PRE_G06_CAMPAIGN.main (38 unidades) e PRE_G06_COMPLETENESS.close.
# Laboratorio proprio: %LOCALAPPDATA%\CDT20_R08\R08_Q1_* e D:\TICKSTORE_CDT19_PRE_G06_LABS\R08_Q1_*.
# Nenhuma raiz produtiva, nenhum B06/B07/D4/D5/canario/FULL, nenhuma rede, nenhum credito.
# Parada segura: crie o arquivo SAFE_STOP.request indicado no log (RUN_ROOT\SAFE_STOP.request).
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$Thread = 'Compress' + [char]0x00E3 + 'o De Ticks 21'
$Downloads = 'C:\Users\silvi\OneDrive\Downloads'
$PackageName = 'CDT21_FINAL_PACKAGE_V003_20261020.zip'
$ExpectedPackageSha = '69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50'
$Python = 'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe'
$ExpectedPythonSha = '4942B86A6597E5AEE0128DAA00050ED79BC21F6E709A78EB19CBFEB0C2F39AC9'
$SupervisorName = 'CDT21_G5_V003_SUPERVISOR.py'
$SupervisorSha = '@@SUP_SHA@@'
$ReviewName = 'CDT19_IMPLEMENTER_SOURCE_REVIEW_V003.json'
$ReviewSha = '@@REV_SHA@@'
$Stamp = (Get-Date).ToString('yyyyMMdd_HHmmss_fff') + '_' + $PID
$LogDir = Join-Path $Downloads ('CDT21_G5_V003_RUNS\G5_' + $Stamp)
New-Item -ItemType Directory -Path $LogDir -ErrorAction Stop | Out-Null
$Log = Join-Path $LogDir 'RUN_LOG.txt'
$Utf8 = New-Object Text.UTF8Encoding($false)

$SupervisorB64 = @'
@@SUP_B64@@
'@
$ReviewB64 = @'
@@REV_B64@@
'@

function Log([string]$Line) {
    Write-Host $Line
    [IO.File]::AppendAllText($Log, $Line + "`r`n", $Utf8)
}
function ShaBytes([byte[]]$Bytes) {
    $h = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($h.ComputeHash($Bytes)).Replace('-', '') } finally { $h.Dispose() }
}
function Sha([string]$Path) {
    $s = [IO.File]::OpenRead($Path); $h = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($h.ComputeHash($s)).Replace('-', '') } finally { $h.Dispose(); $s.Dispose() }
}
function Unpack([string]$B64, [string]$Expected, [string]$Path) {
    $bytes = [Convert]::FromBase64String(($B64 -replace '\s', ''))
    if ((ShaBytes $bytes) -cne $Expected) { throw ('EMBEDDED_SHA_MISMATCH=' + $Path) }
    [IO.File]::WriteAllBytes($Path, $bytes)
    if ((Sha $Path) -cne $Expected) { throw ('EMBEDDED_READBACK_MISMATCH=' + $Path) }
    Log ('UNPACKED=' + $Path + ' SHA256=' + $Expected)
}

$code = 2
try {
    Log ('RESULT_CONTEXT=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=' + $Thread)
    Log ('RUN_LOG=' + $Log)
    Log ('LAUNCHER=' + $PSCommandPath + ' SHA256=' + (Sha $PSCommandPath))
    Log 'ESCOPO=G5_TECNICO_V003_CAMPANHA_NATIVA_INTEGRADA; LABORATORIO_PROPRIO; PRODUCAO=NAO; B06=NOT_STARTED; B07=NOT_STARTED; D4_D5=NOT_STARTED; CANARIO=NAO; FULL=NAO'
    Log 'EVIDENCIA_V002=PRESERVADA_NAO_REUTILIZADA_NAO_REMARCADA; G0_V003=PRESERVADO (11/11, 148/148)'
    if ($PSVersionTable.PSEdition -ne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'WINDOWS_POWERSHELL_5_1_REQUIRED' }
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    if (-not (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'ELEVATION_REQUIRED (abra o PowerShell como Administrador e execute novamente)'
    }
    if (-not $env:LOCALAPPDATA) { throw 'LOCALAPPDATA_MISSING' }
    if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { throw ('PYTHON_MISSING=' + $Python) }
    if ((Sha $Python) -cne $ExpectedPythonSha) { throw 'PYTHON_SHA_MISMATCH' }
    $Package = Join-Path $Downloads $PackageName
    if (-not (Test-Path -LiteralPath $Package -PathType Leaf)) { throw ('PACKAGE_NOT_FOUND=' + $Package) }
    $packageSha = Sha $Package
    if ($packageSha -cne $ExpectedPackageSha) { throw ('PACKAGE_SHA_MISMATCH=' + $packageSha) }
    Log ('PACKAGE=' + $Package + ' SHA256_OK=' + $packageSha)

    $Stage = Join-Path $env:LOCALAPPDATA ('CDT21_G5_V003\STAGE_' + $Stamp)
    if (Test-Path -LiteralPath $Stage) { throw 'STAGE_EXISTS' }
    New-Item -ItemType Directory -Path (Join-Path $Stage 'TEMP') -ErrorAction Stop | Out-Null
    $Supervisor = Join-Path $Stage $SupervisorName
    $Review = Join-Path $Stage $ReviewName
    Unpack $SupervisorB64 $SupervisorSha $Supervisor
    Unpack $ReviewB64 $ReviewSha $Review
    Log 'ETA=cerca de 12 a 15 min (referencia nativa V002: 712 s observados em 37 unidades + 1 unidade sem base + fechamento). Heartbeats a cada 5-10 s abaixo.'

    $oldTemp = $env:TEMP; $oldTmp = $env:TMP
    $env:TEMP = Join-Path $Stage 'TEMP'; $env:TMP = $env:TEMP
    $oldPref = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $Python -I -B $Supervisor --package $Package --review $Review --log-dir $LogDir --stage $Stage 2>&1 | ForEach-Object { Log ([string]$_) }
        $code = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $oldPref
        $env:TEMP = $oldTemp; $env:TMP = $oldTmp
    }
    foreach ($name in @('SUPERVISOR_RESULT.json', 'CDT21_G5_V003_RETURN.zip')) {
        $p = Join-Path $LogDir $name
        if (Test-Path -LiteralPath $p -PathType Leaf) { Log ('COLLECTED=' + $p + ' SHA256=' + (Sha $p)) }
        else { Log ('NOT_PRODUCED=' + $name) }
    }
    if ($code -eq 0) { Log 'G5_TECNICO_V003=PASS_NATIVE_V003_G5_TECHNICAL_FIVE_PART; B06=NOT_STARTED' }
    else { Log ('G5_TECNICO_V003=NAO_CONCLUIDO (ver SUPERVISOR_RESULT.json); B06=NOT_STARTED') }
} catch {
    Log ('G5_LAUNCHER_BLOCKED=' + $_.Exception.Message)
    $code = 2
} finally {
    Log ('EXIT_CODE=' + $code)
    $Send = Join-Path $LogDir ('ENVIAR_AO_CHATGPT_CDT21_G5_V003_' + $Stamp + '.zip')
    try {
        Add-Type -AssemblyName System.IO.Compression
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip = [IO.Compression.ZipFile]::Open($Send, [IO.Compression.ZipArchiveMode]::Create)
        try {
            foreach ($name in @('RUN_LOG.txt', 'SUPERVISOR_RESULT.json', 'CDT21_G5_V003_RETURN.zip')) {
                $p = Join-Path $LogDir $name
                if (Test-Path -LiteralPath $p -PathType Leaf) {
                    $level = [IO.Compression.CompressionLevel]::Optimal
                    if ($name.EndsWith('.zip')) { $level = [IO.Compression.CompressionLevel]::NoCompression }
                    [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $p, $name, $level)
                }
            }
        } finally { $zip.Dispose() }
        Log ('ENVIE_O_RETORNO=' + $Send)
        Log ('ENVIE_O_RETORNO_SHA256=' + (Sha $Send))
    } catch {
        Log ('ENVIAR_ZIP_FALHOU=' + $_.Exception.Message + ' (envie RUN_LOG.txt, SUPERVISOR_RESULT.json e CDT21_G5_V003_RETURN.zip de ' + $LogDir + ')')
    }
    Log ('Devolva este resultado ao ChatGPT, no projeto Base de Dados CSV / Tickstore, conversa ' + $Thread + '. Anexe as evidencias existentes e cole esta resposta.')
    Log ('RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=' + $Thread)
}
exit $code
"""
text = (TEMPLATE.replace('@@SUP_SHA@@', sha(sup_raw)).replace('@@REV_SHA@@', sha(rev_raw))
        .replace('@@SUP_B64@@', b64_lines(sup_raw)).replace('@@REV_B64@@', b64_lines(rev_raw)))
assert '@@' not in text
raw = text.replace('\r\n', '\n').replace('\n', '\r\n').encode('ascii')
out.write_bytes(raw)
print(out.name, len(raw), sha(raw), 'supervisor', sha(sup_raw), 'review', sha(rev_raw))
