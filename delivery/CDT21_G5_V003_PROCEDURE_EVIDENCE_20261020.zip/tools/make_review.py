"""Write the V003 implementer source review (input of PRE_G06_COMPLETENESS.close)."""
import json
import sys
from pathlib import Path

out = Path(sys.argv[1])
review = {
    'schema': 'CDT19_IMPLEMENTER_SOURCE_REVIEW_V001',
    'status': 'SOURCE_REVIEW_COMPLETE_PENDING_NATIVE',
    'package_sha256': '69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50',
    'code_manifest_sha256': 'D59BC4EE4F0D5C689335C8F478A0342CC0146930E3B0B44C707B6B95267B3953',
    'known_fixable_blockers': [],
    'independent_b06_audit': False,
    'reviewer_role': 'IMPLEMENTER_NOT_B06',
    'candidate_name': 'CDT21_FINAL_PACKAGE_V003_20261020.zip',
    'package_manifest_sha256': '5DCC431BD3C22F6DE8B0E4B88F5A1D41CA6F16FCE4B20791C1E097CE10848A51',
    'source_manifest_sha256': '9060B6AFE191B2FAA0DAA5EBD7C1A066031842CB4885A45E157E145DD1F4172D',
    'parent_package_sha256': '4942871541629C3B38F47EDA55EA2C9E310361533887CB55E577D9641542E7C5',
    'parent_code_manifest_sha256': '3C97A2D732F4430E8C5BAB30138ED422D1070B73F43AD1DFAD5D5CB2BBDF25B5',
    'delta': {
        'patch_sha256': '7606FFD68C7FD997B5F6948DE8B9EF98010B645AB7E6B75EBA554E457890F92B',
        'delta_receipt_sha256': 'DFE97A4580A46E5352633CE289BAFF6E74D1A81401B1A4FA0C387787FFB75E18',
        'closed_in_code': [
            'F-01 legacy master orchestrator / direct frozen CLI: LEGACY_ENTRY_FENCE required by validate_d4_start, '
            'by the AdmittedStart guard and by every admitted STATE commit',
            'F-04 frozen launcher hash-then-reread window: sources pinned with CreateFileW share-read handles, '
            'hashed from the same handles and held until the child exits'],
        'frozen_successor_files_modified': 0},
    'campaign_dependency_review': {
        'G3_G6_NATIVE': 'guard_frozen_state_reads called with a STATE path (config None): fence not required',
        'G5_D4_REAL_ISOLATED_PATH_NATIVE': 'test_pre_g06_d4_real_runtime_isolated.py does not load the entry module',
        'G5_STAGE_B_REAL_ISOLATED_PATH_NATIVE': '3 of its 4 suites passed natively in the V003 G0',
        'PRE_B06_11_CHAIN': 'passed natively in the V003 G0 (CDT21 namespace, not a campaign role)',
        'other_roles': 'runtime outside the delta; Linux requalification identical to the V002 baseline'},
    'evidence_considered': {
        'linux_requalification': '75 common test files / 905 tests identical to V002 baseline; '
                                 'new suite 30 ran, 0 failures, 3 POSIX skips',
        'native_g0_v003': 'origin-verified 11/11 units, 148/148 tests',
        'native_g0_return_sha256': 'BADAF97EE6FFD7E7D3FCD812758288A4F0D3233239AED3A3969E175F61C1397C',
        'origin_g0_reconciliation_sha256': 'DC90AD4AE0B60B3B92E549EB14B3639071325634D2F00A5CB5E7A496F4554D20'},
    'non_blocking_residue': [
        'status strings written before the native campaign remain inside the frozen bytes '
        '(e.g. PRE_G06_CONSUMER_REVIEW native_status=PENDING_ACTUAL_CAMPAIGN); not runtime; '
        'changing them would require a new freeze'],
    'native_campaign': 'PENDING_V003_NATIVE_CAMPAIGN',
    'v002_evidence': 'PRESERVED_NOT_REUSED_NOT_RELABELED',
    'production_authorized': False,
    'b06': 'NOT_STARTED',
    'authored_utc': '2026-10-20T23:30:00Z',
}
raw = (json.dumps(review, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')
out.write_bytes(raw)
print(out, len(raw))
