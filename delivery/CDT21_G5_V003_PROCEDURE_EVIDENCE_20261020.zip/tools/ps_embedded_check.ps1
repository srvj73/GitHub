param([string]$Path)
$tok=$null; $err=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($Path,[ref]$tok,[ref]$err)
Write-Output ("PARSE errors=" + @($err).Count)
$assign=$ast.FindAll({param($n) $n -is [Management.Automation.Language.AssignmentStatementAst]}, $true)
$vals=@{}
foreach ($a in $assign) {
  $name=$a.Left.Extent.Text
  if ($name -in @('$SupervisorB64','$ReviewB64','$SupervisorSha','$ReviewSha')) {
    $vals[$name]=$a.Right.Expression.Value
  }
}
foreach ($pair in @(@('$SupervisorB64','$SupervisorSha'),@('$ReviewB64','$ReviewSha'))) {
  $bytes=[Convert]::FromBase64String(($vals[$pair[0]] -replace '\s',''))
  $h=[Security.Cryptography.SHA256]::Create()
  $sha=[BitConverter]::ToString($h.ComputeHash($bytes)).Replace('-','')
  Write-Output ($pair[0] + " decoded_sha=" + $sha + " pinned=" + $vals[$pair[1]] + " match=" + ($sha -ceq $vals[$pair[1]]))
}
