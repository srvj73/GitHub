"""Derive the G5 V004 supervisor R3 from R2 (2A5F4B71...) by exact, counted replacements.

Usage: python -I make_v004_r3_supervisor.py <CDT21_G5_V004_SUPERVISOR.py R2> <out.py>
Origin audit (2026-10-21): R2 removed resume entirely and refused every REUSE_COMMITTED, so units of the SAME V004
campaign that were already committed could not be preserved after SAFE_STOP or interruption, although the frozen
V004 campaign contract provides exactly that (run_unit reuses a COMMIT of the same root bound to the same package
and code, with artifacts re-hashed; test_committed_same_bytes_reused / test_cross_package_commit_cannot_be_rebound;
seal_return and PRE_G06_COMPLETENESS retain prior partial returns and assemblies).
R3 closes only that gap:
  * new run (no --resume-root): byte-for-byte the R2 behaviour, REUSE_COMMITTED still refused;
  * --resume-root: only a run root created by THIS supervisor for the V004 bytes (bootstrap, owner, D-lab owner,
    witness, input package), whose every COMMIT is closed, bound to V004, artifact-intact and recorded in this
    campaign's ledger (written by the supervisor when its own campaign child printed COMMITTED <key>);
    V003 / other-candidate / other-campaign commits are refused before any effect.
The R2 NTFS correction (handle-view digests, per-entry evidence) is untouched.
"""
import hashlib
import sys
from pathlib import Path

PARENT_SHA = '2A5F4B7138C950D320F7787540F98FF912D1AFB6C86C59E0F562887DB671029F'
src, out = Path(sys.argv[1]), Path(sys.argv[2])
raw = src.read_bytes()
assert hashlib.sha256(raw).hexdigest().upper() == PARENT_SHA, 'PARENT_SHA'
text = raw.decode('utf-8')


def sub(old, new, count=1):
    global text
    assert text.count(old) == count, ('ANCHOR', old[:100])
    text = text.replace(old, new)


# R3-1 docstring.
sub("  * removed: the resume mode.  Every run creates a NEW run root and a NEW D-lab; no root, COMMIT or\n"
    "    terminal receipt of another run (the V003 run included) is opened for writing or resumed;\n",
    "  * new run: creates a NEW run root and a NEW D-lab; no root, COMMIT or terminal receipt of another run or\n"
    "    candidate (the V003 run included) is opened for writing, resumed or reused;\n"
    "  * R3 resume, same V004 campaign only (origin audit 2026-10-21): --resume-root re-enters a run root created\n"
    "    by this exact supervisor for the V004 bytes; the frozen campaign reuses only COMMITs of that root that are\n"
    "    closed, bound to the V004 package and code, artifact-intact and recorded in this campaign's ledger;\n")

# R3-2 constants.
sub("FROZEN_LOG_ROOT = 'C:\\\\Users\\\\silvi\\\\OneDrive\\\\Downloads\\\\TICKSTORE_RUNS'  # hard-coded in frozen V004 (installer/RUN_LOG_FIXED)\n",
    "FROZEN_LOG_ROOT = 'C:\\\\Users\\\\silvi\\\\OneDrive\\\\Downloads\\\\TICKSTORE_RUNS'  # hard-coded in frozen V004 (installer/RUN_LOG_FIXED)\n"
    "MODE_NEW = 'NEW_RUN_V004'\n"
    "MODE_RESUME = 'RESUME_SAME_V004_CAMPAIGN'\n"
    "LEDGER_DIR = 'CDT21_SUPERVISOR_LEDGER'       # inside the run root: one record per COMMIT observed by the supervisor\n"
    "LEDGER_SCHEMA = 'CDT21_G5_V004_COMMIT_LEDGER_V001'\n")

# R3-3 outer return: resume receipts and the ledger travel with the return.
sub("                 'OWNER.json', 'RETURN_LOCK_SCOPE.json', 'CDT21_SUPERVISOR_BOOTSTRAP.json']:\n",
    "                 'OWNER.json', 'RETURN_LOCK_SCOPE.json', 'CDT21_SUPERVISOR_BOOTSTRAP.json'] + \\\n"
    "                sorted(p.name for p in root.glob('CDT21_SUPERVISOR_RESUME_*.json')):\n")
sub("    trees = [root / 'FINAL_G5', root / 'SOURCE_REVIEW'] + sorted(root.glob('G5_ASSEMBLY_INPUTS_*'))\n",
    "    trees = [root / 'FINAL_G5', root / 'SOURCE_REVIEW', root / LEDGER_DIR] + sorted(root.glob('G5_ASSEMBLY_INPUTS_*'))\n")

# R3-4 foreign check: on resume the resumed root and its D-lab may change, nothing else, nothing added.
sub("def foreign_checked(local, before, rows_before, run_id, result, key):\n"
    "    \"\"\"foreign_unchanged, recording result[key + '_difference'] (per entry) whenever it is going to refuse.\"\"\"\n"
    "    after = foreign_roots(local)\n"
    "    own = ('d_lab/' + run_id, 'run/' + run_id)\n"
    "    if {k: v for k, v in after.items() if k not in own} != before or not all(k in after for k in own):\n"
    "        result[key + '_difference'] = foreign_detail(local, before, after, rows_before, dict(_ROWS))\n"
    "    return foreign_unchanged(before, after, run_id)\n",
    "def foreign_checked(local, before, rows_before, run_id, result, key, resume=False):\n"
    "    \"\"\"foreign_unchanged, recording result[key + '_difference'] (per entry) whenever it is going to refuse.\"\"\"\n"
    "    after = foreign_roots(local)\n"
    "    own = ('d_lab/' + run_id, 'run/' + run_id)\n"
    "    if resume:\n"
    "        if set(after) != set(before) or any(after[k] != v for k, v in before.items() if k not in own):\n"
    "            result[key + '_difference'] = foreign_detail(local, before, after, rows_before, dict(_ROWS))\n"
    "        return foreign_unchanged_resume(before, after, run_id)\n"
    "    if {k: v for k, v in after.items() if k not in own} != before or not all(k in after for k in own):\n"
    "        result[key + '_difference'] = foreign_detail(local, before, after, rows_before, dict(_ROWS))\n"
    "    return foreign_unchanged(before, after, run_id)\n")

# R3-5 resume functions (the proven V003 R2 mechanics, bound to this campaign by bootstrap and ledger).
NEW_FUNCS = r'''

def foreign_unchanged_resume(before, after, run_id):
    own = ('d_lab/' + run_id, 'run/' + run_id)
    require(all(k in before and k in after for k in own), 'RESUME_ROOT_NOT_IN_FOREIGN_SET')
    changed = sorted(k for k in before if k not in own and after.get(k) != before[k])
    removed = sorted(k for k in before if k not in after)
    added = sorted(k for k in after if k not in before)
    require(not changed and not removed, 'FOREIGN_ROOT_CHANGED:' + ','.join(changed + removed))
    require(not added, 'FOREIGN_ROOT_ADDED:' + ','.join(added))
    return {'pre_existing': len(before), 'unchanged': len(before) - 2, 'resumed_own': list(own), 'added': []}


def frozen_dead():
    import FULL_CRASH_RECOVERY as R  # frozen V004 module, importable after plan_keys()
    return R.dead


def ledger_record(root, key, attempt, supervisor_sha, campaign_pid):
    """Record a COMMIT the supervisor saw its own campaign child publish (same-campaign proof). Written in TEMP
    (outside the frozen seal) and moved atomically, so a seal never contains half a record."""
    entry = {'schema': LEDGER_SCHEMA, 'run_id': root.name, 'key': key,
             'commit_file_sha256': sha_file(root / 'COMMITS' / (key + '.json')), 'attempt': attempt,
             'supervisor_sha256': supervisor_sha, 'campaign_pid': campaign_pid,
             'observed_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    target = root / LEDGER_DIR / (key + '.json')
    require(not target.exists(), 'LEDGER_ENTRY_EXISTS:' + key)
    temp = root / 'TEMP' / ('LEDGER_' + key + '_' + attempt + '.json')
    write_new(temp, encoded(entry))
    os.replace(temp, target)
    return entry


def ledger_bound(root, commit_sha):
    """Every COMMIT on disk was observed by a supervisor of this campaign, byte for byte, and vice versa."""
    entries = {}
    for p in sorted((root / LEDGER_DIR).glob('*.json')):
        e = strict_json(p.read_bytes())
        require(e.get('schema') == LEDGER_SCHEMA and e.get('run_id') == root.name and e.get('key') == p.stem
                and e.get('supervisor_sha256') == sha_file(__file__), 'LEDGER_ENTRY_INVALID:' + p.stem)
        entries[p.stem] = e
    for key, sha in sorted(commit_sha.items()):
        require(key in entries, 'COMMIT_NOT_LEDGERED:' + key)
        require(entries[key]['commit_file_sha256'] == sha, 'LEDGER_DRIFT:' + key)
    extra = sorted(set(entries) - set(commit_sha))
    require(not extra, 'LEDGER_WITHOUT_COMMIT:' + ','.join(extra))
    return {k: entries[k]['attempt'] for k in sorted(entries)}


def resume_precheck(root, local, plan):
    """Read-only admission of an interrupted run of THIS campaign: same root, same supervisor, same V004 bytes;
    every COMMIT closed, bound to V004, artifact-intact and in this campaign's ledger.  No effect."""
    root = Path(os.path.abspath(root))
    require(root.parent == Path(local) / RUN_PARENT and RUN_NAME.fullmatch(root.name) is not None, 'RESUME_ROOT_LOCATION')
    plain_directory(root)
    run_id = root.name; dlab = Path(D_LABS) / run_id
    boot = strict_json((root / 'CDT21_SUPERVISOR_BOOTSTRAP.json').read_bytes())
    require(boot.get('schema') == 'CDT21_G5_V004_SUPERVISOR_BOOTSTRAP_V001' and boot.get('run_id') == run_id
            and boot.get('mode') == MODE_NEW and boot.get('package_sha256') == PACKAGE_SHA
            and boot.get('code_manifest_sha256') == CODE_SHA and boot.get('package_manifest_sha256') == MANIFEST_SHA
            and boot.get('campaign_source_sha256') == CAMPAIGN_SHA and boot.get('completeness_source_sha256') == COMPLETENESS_SHA
            and boot.get('supervisor_sha256') == sha_file(__file__) and boot.get('v003_commits_reused') == 0
            and boot.get('commit_ledger') == LEDGER_DIR, 'RESUME_BOOTSTRAP_BINDING')
    owner_raw = encoded(make_owner(run_id))
    require((root / 'OWNER.json').read_bytes() == owner_raw, 'RESUME_OWNER')
    plain_directory(dlab)
    require((dlab / 'OWNER.json').read_bytes() == owner_raw, 'RESUME_D_LAB_OWNER')
    zips = sorted(p.name for p in (root / 'INPUTS').iterdir() if p.is_file() and p.suffix.lower() == '.zip')
    require(zips == [PACKAGE_NAME] and sha_file(root / 'INPUTS' / PACKAGE_NAME) == PACKAGE_SHA, 'RESUME_INPUT_PACKAGE')
    require((root / 'INPUTS' / WITNESS_NAME).read_bytes() == encoded(make_witness(run_id, MANIFEST_SHA)), 'RESUME_WITNESS')
    require((root / 'CAMPAIGN.lock').is_file() and (root / 'TEMP').is_dir() and (root / 'QUAL_C').is_dir()
            and (dlab / 'WRITER_EFFECTFUL').is_dir() and (root / LEDGER_DIR).is_dir(), 'RESUME_LAYOUT')
    prior = 'NO_TERMINAL_INTERRUPTED'
    if (root / 'ENGINEERING_RESULT.json').exists():
        eng = strict_json((root / 'ENGINEERING_RESULT.json').read_bytes())
        prior = eng.get('status')
        bound = (('run_id', run_id), ('final_zip_sha256', PACKAGE_SHA), ('code_manifest_sha256', CODE_SHA))
        # The frozen main records these bindings right after verify_package; only an early BLOCKED may lack them.
        require(eng.get('schema') == 'CDT19_PRE_B06_NATIVE_ENGINEERING_V002' and all(eng.get(k) in (None, v) for k, v in bound)
                and (prior == 'BLOCKED' or all(eng.get(k) == v for k, v in bound)), 'RESUME_ENGINEERING_BINDING')
        require(prior in ('BLOCKED', 'SAFE_STOP', 'PASS_NATIVE_INTEGRATED_PRE_B06'), 'RESUME_PRIOR_STATUS:' + str(prior))
    commit_sha = {}
    for p in sorted((root / 'COMMITS').glob('*.json')) if (root / 'COMMITS').is_dir() else []:
        require(p.stem in plan, 'RESUME_FOREIGN_COMMIT:' + p.stem)
        obj = strict_json(p.read_bytes())
        require(obj.get('package_sha256') != V003_PACKAGE_SHA and obj.get('code_sha256') != V003_CODE_SHA,
                'RESUME_COMMIT_BOUND_TO_V003:' + p.stem)
        require(obj.get('schema') == 'CDT19_NATIVE_UNIT_COMMIT_V001' and obj.get('package_sha256') == PACKAGE_SHA
                and obj.get('code_sha256') == CODE_SHA and obj.get('result', {}).get('status') == 'PASS'
                and obj['result'].get('exit_code') == 0 and obj.get('own_descendants_final') == []
                and isinstance(obj.get('artifacts'), list) and bool(obj['artifacts']), 'RESUME_COMMIT_NOT_BOUND_TO_V004:' + p.stem)
        for ref in obj['artifacts']:
            member = PurePosixPath(ref['member'])
            require(not member.is_absolute() and '..' not in member.parts, 'RESUME_COMMIT_ARTIFACT_ESCAPE:' + p.stem)
            target = root.joinpath(*member.parts)
            require(target.is_file() and target.stat().st_size == ref['bytes'] and sha_file(target) == ref['sha256'],
                    'RESUME_COMMIT_ARTIFACT_DRIFT:' + p.stem + ':' + ref['member'])
        commit_sha[p.stem] = sha_file(p)
    attempts = ledger_bound(root, commit_sha)
    return {'run_id': run_id, 'run_root': str(root), 'd_lab': str(dlab), 'prior_status': prior,
            'committed_before': [k for k in plan if k in commit_sha], 'commit_file_sha256': commit_sha,
            'ledger_attempts': attempts, 'pending': [k for k in plan if k not in commit_sha],
            'safe_stop_request_present': (root / 'SAFE_STOP.request').exists(),
            'prior_closure_present': (root / 'FINAL_G5').exists()}


def prior_processes_dead(root, dead):
    """Every process identity recorded by the prior attempt is dead or its PID reused (frozen R.dead)."""
    ids = {}
    for p in sorted((root / 'COMMITS').glob('*.json')):
        obj = strict_json(p.read_bytes())
        for ident in list(obj.get('owner') or []) + list(obj.get('observed_processes') or []):
            if isinstance(ident, dict) and type(ident.get('pid')) is int and type(ident.get('creation_filetime')) is int:
                ids[(ident['pid'], ident['creation_filetime'])] = {'pid': ident['pid'], 'creation_filetime': ident['creation_filetime']}
    for p in sorted((root / 'UNITS').glob('*/RESULT.json')):
        proc = strict_json(p.read_bytes()).get('process')
        if isinstance(proc, dict) and type(proc.get('pid')) is int and type(proc.get('creation_filetime')) is int:
            ids[(proc['pid'], proc['creation_filetime'])] = {'pid': proc['pid'], 'creation_filetime': proc['creation_filetime']}
    return [dict(dead(i), checked=True) for i in ids.values()]


def lock_probe(lock_path):
    """Read-only handle: the prior supervisor lock must be acquirable (then released at once)."""
    import msvcrt
    f = open(lock_path, 'rb')
    try:
        try:
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            return 'HELD_BY_ANOTHER_PROCESS'
        f.seek(0); msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        return 'ACQUIRED_AND_RELEASED'
    finally:
        f.close()


def preserve_prior_terminal(root, stage, stamp):
    """Copy (never move) the prior terminal receipts that the frozen campaign will overwrite; the consumed
    SAFE_STOP.request (which would stop the resumed campaign at once) is moved into the same folder."""
    keep = root / 'INTERRUPTED_ATTEMPTS' / ('PRIOR_TERMINAL_' + stamp)
    keep.mkdir(parents=True)
    copied = {}
    for name in ('ENGINEERING_RESULT.json', 'LIVE_STATUS.json', 'R08_RETURN.sha256', 'RETURN_LOCK_SCOPE.json'):
        if (root / name).is_file():
            raw = (root / name).read_bytes(); write_new(keep / name, raw); copied[name] = sha_bytes(raw)
    prior = {'schema': 'CDT21_G5_V004_PRIOR_TERMINAL_PRESERVATION_V001', 'run_id': root.name, 'copied': copied,
             'status': 'COPIED_NO_DELETE'}
    if (root / 'R08_RETURN.zip').is_file():
        z = root / 'R08_RETURN.zip'; copy = stage / ('PRIOR_R08_RETURN_' + root.name + '_' + stamp + '.zip')
        prior.update(prior_r08_return_sha256=sha_file(z), prior_r08_return_bytes=z.stat().st_size, prior_r08_return_copy=str(copy))
        shutil.copyfile(z, copy)
        require(sha_file(copy) == prior['prior_r08_return_sha256'], 'PRIOR_RETURN_COPY')
    stop = root / 'SAFE_STOP.request'
    if os.path.lexists(stop):
        require(stop.is_file() and not stop.is_symlink(), 'SAFE_STOP_REQUEST_TYPE')
        prior['safe_stop_request_sha256'] = sha_file(stop)
        os.replace(stop, keep / 'SAFE_STOP.request')
        prior['safe_stop_request_moved_to'] = (keep / 'SAFE_STOP.request').relative_to(root).as_posix()
    write_new(keep / 'PRESERVATION.json', encoded(prior))
    return prior


def qualify_main(a):'''
sub("\n\ndef qualify_main(a):", NEW_FUNCS)

# R3-6 qualification (Q): records the mode and, for a resume, the read-only admission of the root.
sub("         'code_manifest_sha256': CODE_SHA, 'log_dir': str(log_dir), 'mode': 'NEW_RUN_V004', 'checks': {}, 'blockers': [],\n",
    "         'code_manifest_sha256': CODE_SHA, 'log_dir': str(log_dir), 'mode': MODE_RESUME if a.resume_root else MODE_NEW,\n"
    "         'resume_root': os.path.abspath(a.resume_root) if a.resume_root else '', 'checks': {}, 'blockers': [],\n")
sub("        ok('frozen_verify_package_fixed_layout', code_sha == CODE_SHA, str(ext))\n"
    "        roots = {'run_parent': (Path(local) / RUN_PARENT, True), 'd_labs': (Path(D_LABS), True), 'extract_home': (home, True),\n"
    "                 'stage': (stage, True), 'log_dir': (log_dir, True), 'frozen_log_root': (Path(FROZEN_LOG_ROOT), False)}\n",
    "        ok('frozen_verify_package_fixed_layout', code_sha == CODE_SHA, str(ext))\n"
    "        roots = {'run_parent': (Path(local) / RUN_PARENT, True), 'd_labs': (Path(D_LABS), True), 'extract_home': (home, True),\n"
    "                 'stage': (stage, True), 'log_dir': (log_dir, True), 'frozen_log_root': (Path(FROZEN_LOG_ROOT), False)}\n"
    "        if a.resume_root:\n"
    "            pre = resume_precheck(a.resume_root, local, plan); q['resume'] = pre\n"
    "            ok('resume_precheck_same_v004_campaign', True, {'committed': len(pre['committed_before']),\n"
    "               'pending': len(pre['pending']), 'prior_status': pre['prior_status']})\n"
    "            q['prior_processes'] = prior_processes_dead(Path(pre['run_root']), frozen_dead())\n"
    "            ok('prior_processes_dead', True, len(q['prior_processes']))\n"
    "            q['campaign_lock'] = lock_probe(Path(pre['run_root']) / 'CAMPAIGN.lock')\n"
    "            ok('campaign_lock_free', q['campaign_lock'] == 'ACQUIRED_AND_RELEASED', q['campaign_lock'])\n"
    "            roots.update(resume_root=(Path(pre['run_root']), True), resume_d_lab=(Path(pre['d_lab']), True))\n")
sub("def require_qualification(path, log_dir):\n"
    "    \"\"\"A new run is admitted only after a PASS native qualification of these exact bytes and this log dir.\"\"\"\n",
    "def require_qualification(path, log_dir, resume_root=''):\n"
    "    \"\"\"E is admitted only after a PASS native qualification of these exact bytes, this log dir, this mode and root.\"\"\"\n")
sub("    require(q.get('log_dir') == str(log_dir) and q.get('mode') == 'NEW_RUN_V004', 'QUALIFICATION_OTHER_RUN')\n",
    "    require(q.get('log_dir') == str(log_dir) and q.get('mode') == (MODE_RESUME if resume_root else MODE_NEW)\n"
    "            and q.get('resume_root', '') == resume_root, 'QUALIFICATION_OTHER_RUN')\n")
sub("            'foreign_roots': q['foreign_roots']}\n",
    "            'foreign_roots': q['foreign_roots'], 'resume': q.get('resume')}\n")

# R3-7 main (E).
sub("    ap.add_argument('--qualify-only', action='store_true')\n    ap.add_argument('--require-qualification', default='')\n    a = ap.parse_args(argv)\n",
    "    ap.add_argument('--qualify-only', action='store_true')\n    ap.add_argument('--require-qualification', default='')\n"
    "    ap.add_argument('--resume-root', default='')\n    a = ap.parse_args(argv)\n")
sub("    log_dir = Path(os.path.abspath(a.log_dir)); stage = Path(os.path.abspath(a.stage))\n"
    "    result = {'schema': RESULT_SCHEMA,",
    "    log_dir = Path(os.path.abspath(a.log_dir)); stage = Path(os.path.abspath(a.stage))\n"
    "    resume_root = os.path.abspath(a.resume_root) if a.resume_root else ''\n"
    "    result = {'schema': RESULT_SCHEMA,")
sub("              'supervisor_sha256': sha_file(__file__), 'planned_units': PLANNED_UNITS, 'mode': 'NEW_RUN_V004',\n",
    "              'supervisor_sha256': sha_file(__file__), 'planned_units': PLANNED_UNITS,\n"
    "              'mode': MODE_RESUME if resume_root else MODE_NEW, 'other_campaign_commits_reused': 0,\n")
sub("        result['qualification'] = require_qualification(a.require_qualification, log_dir)\n",
    "        result['qualification'] = require_qualification(a.require_qualification, log_dir, resume_root)\n")

# bootstrap: the R2 new-run block is kept verbatim, indented under 'else:'; the resume block precedes it.
start = text.index("        run_id = 'R08_Q1_' + time.strftime('%Y%m%d%H%M%S') + '_' + uuid.uuid4().hex[:12]\n")
end_anchor = "        write_new(root / 'CDT21_SUPERVISOR_BOOTSTRAP.json', encoded(bootstrap))\n"
end = text.index(end_anchor) + len(end_anchor)
assert text.count(end_anchor) == 1
block = text[start:end]
block = block.replace("        (root / 'TEMP').mkdir()\n", "        (root / 'TEMP').mkdir()\n        (root / LEDGER_DIR).mkdir()\n")
block = block.replace("                     'mode': 'NEW_RUN_V004', 'v003_commits_reused': 0, 'pre_existing_roots_read_only': len(foreign_before),\n",
                      "                     'mode': 'NEW_RUN_V004', 'v003_commits_reused': 0, 'pre_existing_roots_read_only': len(foreign_before),\n"
                      "                     'commit_ledger': LEDGER_DIR,\n")
assert block.count('LEDGER_DIR') == 2
indented = ''.join(('    ' + l if l.strip() else l) for l in block.splitlines(True))
RESUME_BLOCK = r'''        if resume_root:
            pre = resume_precheck(resume_root, local, plan)
            qres = result['qualification']['resume'] or {}
            require(pre['committed_before'] == qres.get('committed_before')
                    and pre['commit_file_sha256'] == qres.get('commit_file_sha256'), 'RESUME_STATE_CHANGED_SINCE_QUALIFICATION')
            result['resume'] = pre
            run_id = pre['run_id']; root = Path(pre['run_root']); dlab = Path(pre['d_lab'])
            result.update(run_id=run_id, run_root=str(root))
            emit('RESUME_ROOT=' + str(root) + ' PRIOR_STATUS=' + str(pre['prior_status']) + ' (mesma campanha V004, mesmos bytes)')
            emit('COMMITTED_BEFORE=' + str(len(pre['committed_before'])) + ' ' + ','.join(pre['committed_before']))
            emit('PENDING=' + str(len(pre['pending'])))
            lock = open(root / 'CAMPAIGN.lock', 'r+b')
            try:
                msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                raise Blocked('CAMPAIGN_LOCK_HELD_BY_ANOTHER_PROCESS')
            result['prior_processes'] = prior_processes_dead(root, frozen_dead())
            inputs_pkg = root / 'INPUTS' / PACKAGE_NAME
            witness = root / 'INPUTS' / WITNESS_NAME
            qual_c = root / 'QUAL_C'; qual_d = dlab / 'WRITER_EFFECTFUL'
            result['prior_terminal'] = preserve_prior_terminal(root, stage, stamp)
            resume = {'schema': 'CDT21_G5_V004_SUPERVISOR_RESUME_V001', 'run_id': run_id, 'stamp': stamp, 'mode': MODE_RESUME,
                      'package_sha256': PACKAGE_SHA, 'code_manifest_sha256': CODE_SHA,
                      'supervisor_sha256': result['supervisor_sha256'],
                      'qualification_sha256': result['qualification']['qualification_sha256'], 'extracted': str(packaged),
                      'prior_status': pre['prior_status'], 'committed_before': pre['committed_before'],
                      'commit_file_sha256': pre['commit_file_sha256'], 'ledger_attempts': pre['ledger_attempts'],
                      'pending': pre['pending'], 'prior_terminal': result['prior_terminal'],
                      'python_sha256': sha_file(sys.executable), 'supervisor_pid': os.getpid(),
                      'campaign_lock': 'HELD_EXCLUSIVE_BYTE_RANGE', 'v003_commits_reused': 0,
                      'other_campaign_commits_reused': 0, 'production_authorized': False, 'b06': 'NOT_STARTED'}
            write_new(root / ('CDT21_SUPERVISOR_RESUME_' + stamp + '.json'), encoded(resume))
        else:
'''
text = text[:start] + RESUME_BLOCK + indented + text[end:]

# pump: the ledger records each COMMIT the supervisor's own campaign child publishes.
sub("        reused, committed_now = [], []\n",
    "        reused, committed_now, ledger_errors = [], [], []\n")
sub("                elif line.startswith('COMMITTED '):\n"
    "                    committed_now.append(line.split(' ', 1)[1])\n",
    "                elif line.startswith('COMMITTED '):\n"
    "                    committed_now.append(line.split(' ', 1)[1])\n"
    "                    try:\n"
    "                        ledger_record(root, committed_now[-1], stamp, result['supervisor_sha256'], proc.pid)\n"
    "                    except BaseException as exc:\n"
    "                        ledger_errors.append(committed_now[-1] + ':' + type(exc).__name__ + ':' + str(exc))\n")
# after the child: reuse only of what Q and E admitted for this root; never in a new run.
sub("        result['foreign_roots'] = foreign_checked(local, foreign_before, rows_e, run_id, result, 'foreign_roots')\n"
    "        require(not reused, 'NEW_RUN_REUSED_A_COMMIT:' + ','.join(sorted(reused)))\n",
    "        result['foreign_roots'] = foreign_checked(local, foreign_before, rows_e, run_id, result, 'foreign_roots',\n"
    "                                                  bool(resume_root))\n"
    "        require(not ledger_errors, 'LEDGER_WRITE:' + ';'.join(ledger_errors))\n"
    "        if resume_root:\n"
    "            before_set = set(result['resume']['committed_before'])\n"
    "            require(set(reused) <= before_set, 'RESUME_REUSED_OUTSIDE_ADMISSION:' + ','.join(sorted(set(reused) - before_set)))\n"
    "            require(not set(committed_now) & before_set, 'RESUME_RECOMMITTED:' + ','.join(sorted(set(committed_now) & before_set)))\n"
    "        else:\n"
    "            require(not reused, 'NEW_RUN_REUSED_A_COMMIT:' + ','.join(sorted(reused)))\n")
sub("        require(sorted(committed_now) == sorted(plan), 'COMMITTED_NOW_NE_PLAN:' + str(len(committed_now)))\n"
    "        result['commit_file_sha256'] = commits_bound(root, plan)\n",
    "        if resume_root:\n"
    "            require(sorted(committed_now + reused) == sorted(plan)\n"
    "                    and sorted(reused) == sorted(result['resume']['committed_before']),\n"
    "                    'RESUMED_UNITS_NE_PLAN:' + str(len(committed_now)) + '+' + str(len(reused)))\n"
    "        else:\n"
    "            require(sorted(committed_now) == sorted(plan), 'COMMITTED_NOW_NE_PLAN:' + str(len(committed_now)))\n"
    "        result['commit_file_sha256'] = commits_bound(root, plan)\n"
    "        result['ledger_attempts'] = ledger_bound(root, result['commit_file_sha256'])\n")
# closure: a resumed campaign whose prior attempt reached the closure already holds the same review bytes.
sub("        review.parent.mkdir()\n        write_new(review, review_raw)\n",
    "        if review.exists():\n"
    "            require(bool(resume_root) and review.read_bytes() == review_raw, 'SOURCE_REVIEW_DRIFT')\n"
    "        else:\n"
    "            review.parent.mkdir(exist_ok=bool(resume_root))\n"
    "            write_new(review, review_raw)\n")
sub("        result['foreign_roots_after_close'] = foreign_checked(local, foreign_before, rows_e, run_id, result,\n"
    "                                                              'foreign_roots_after_close')\n",
    "        result['foreign_roots_after_close'] = foreign_checked(local, foreign_before, rows_e, run_id, result,\n"
    "                                                              'foreign_roots_after_close', bool(resume_root))\n")
sub("        emit('SUPERVISOR_BLOCKED=' + result['blockers'][-1])\n",
    "        emit('SUPERVISOR_BLOCKED=' + result['blockers'][-1])\n"
    "        if root is not None and result['phase'] in ('CAMPAIGN', 'FIVE_PART_CLOSE'):\n"
    "            emit('RETOMADA_DA_MESMA_CAMPANHA: -RetomarRaiz \"' + str(root) + '\" (a Fase Q decide a admissao)')\n")

data = text.encode('utf-8')
out.write_bytes(data)
print(out.name, hashlib.sha256(data).hexdigest().upper(), len(data), len(text.split('\n')))
