"""Qualification of the R3 launcher's new PowerShell lines (verbatim fragments, pwsh on Linux).

Usage: python -I test_r3_launcher.py <RUN_CDT21_G5_V004_R3_20261021.ps1> <pwsh> <work> <out.json>
Fragments taken byte-for-byte from the launcher: the param line, the -RetomarRaiz validation block, the UAC Arguments
line and the Q / E python invocation lines.  The UAC transport is a plain pwsh -File start with the very Arguments string
(runas does not exist here); python is a probe that prints the argv it received.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

launcher, pwsh, work, out = map(Path, sys.argv[1:5])
work = work.resolve()
raw = launcher.read_bytes(); lines = raw.decode('ascii').split('\r\n')


def one(prefix):
    hits = [l for l in lines if l.startswith(prefix)]
    assert len(hits) == 1, prefix
    return hits[0]


def block(first, last_prefix):
    i = lines.index(first); j = next(k for k in range(i, len(lines)) if lines[k].startswith(last_prefix))
    j = next(k for k in range(j, len(lines)) if lines[k] == '    }')
    return '\n'.join(lines[i:j + 1])


PARAM = one('param([switch]$AutorizoLabD')
VALID = block('    $ResumeArgs = @()', "        Log ('RETOMADA_SOLICITADA=")
ARGS = one('        $si.Arguments = ')
QLINE = one('            & $Python -I -B $Supervisor --qualify-only')
ELINE = one('                & $Python -I -B $Supervisor --package $Package')
frags = {'param': PARAM, 'validation': VALID, 'uac_args': ARGS, 'q_call': QLINE, 'e_call': ELINE}
for k, v in frags.items():
    assert raw.count(v.replace('\n', '\r\n').encode()) == 1, k

if work.exists():
    shutil.rmtree(work)
work.mkdir(parents=True)
probe = work / 'argv_probe.py'
probe.write_text('import json, sys\nprint("ARGV=" + json.dumps(sys.argv[1:]))\n')
harness = work / 'harness_launcher_r3.ps1'
harness.write_text('\n'.join([
    PARAM,
    "$ErrorActionPreference = 'Stop'",
    'Set-StrictMode -Version 2.0',
    '$Out = $env:QUAL_OUT',
    "$Role = 'PARENT'; if ($ElevatedChild) { $Role = 'CHILD' }",
    "function Log([string]$Line) { [IO.File]::AppendAllText((Join-Path $Out ('LOG_' + $Role + '.txt')), $Line + \"`n\") }",
    '$res = @{}',
    'try {',
    VALID,
    "    $res['ok'] = $true; $res['retomar'] = $RetomarRaiz; $res['resume_args'] = @($ResumeArgs)",
    "    $LogDir = Join-Path $Out 'G5V4_X'; $selfCreation = '638900000000000000'; $AutorizoLabD = [switch]$true",
    '    $si = New-Object System.Diagnostics.ProcessStartInfo',
    ARGS,
    "    $res['uac_args'] = $si.Arguments",
    "    $Python = $env:QUAL_PY; $Supervisor = $env:QUAL_PROBE; $Package = 'PKG'; $Review = 'REV'; $Stage = 'STG'; $qfile = 'QF'",
    QLINE,
    ELINE,
    '} catch {',
    "    $res['ok'] = $false; $res['error'] = $_.Exception.Message",
    '}',
    "[IO.File]::WriteAllText((Join-Path $Out ('RESULT_' + $Role + '.json')), (ConvertTo-Json $res -Depth 4))",
]) + '\n')
results = []


def check(name, ok, detail=''):
    results.append({'case': name, 'pass': bool(ok), 'detail': detail})


def run(tag, local, args, child=False):
    o = work / tag; o.mkdir(exist_ok=True)
    env = dict(os.environ, QUAL_OUT=str(o), QUAL_PY=sys.executable, QUAL_PROBE=str(probe))
    if local is None:
        env.pop('LOCALAPPDATA', None)
    else:
        env['LOCALAPPDATA'] = str(local)
    role = 'CHILD' if child else 'PARENT'
    subprocess.run([str(pwsh), '-NoProfile', '-File', str(harness)] + args, env=env, timeout=60, capture_output=True)
    res = json.loads((o / ('RESULT_' + role + '.json')).read_text(encoding='utf-8-sig'))
    log = (o / ('LOG_' + role + '.txt')).read_text() if (o / ('LOG_' + role + '.txt')).exists() else ''
    argv = [json.loads(l.split('ARGV=', 1)[1]) for l in log.splitlines() if 'ARGV=' in l]
    return res, argv


local = work / 'AppData Local With Space'
root = local / 'CDT20_R08' / 'R08_Q1_20261021213805_ab22c361e562'; root.mkdir(parents=True)
(local / 'CDT20_R08' / 'R08_Q1_20261021213805_AB22C361E562').mkdir()
(work / 'ELSEWHERE' / 'R08_Q1_20261021213805_ab22c361e562').mkdir(parents=True)

res, argv = run('L1_new', local, ['-AutorizoLabD'])
check('L1_without_retomar_no_resume_args', res['ok'] and res['resume_args'] == [] and len(argv) == 2
      and all('--resume-root' not in a for a in argv) and '-RetomarRaiz' not in res['uac_args'], {'argv': argv})
res, argv = run('L2_resume', local, ['-AutorizoLabD', '-RetomarRaiz', str(root)])
check('L2_valid_root_resume_args_to_q_and_e', res['ok'] and res['resume_args'] == ['--resume-root', str(root)]
      and all(a[-2:] == ['--resume-root', str(root)] for a in argv) and len(argv) == 2
      and ('-RetomarRaiz "' + str(root) + '"') in res['uac_args'], {'argv': argv, 'uac': res.get('uac_args')})
uac = res['uac_args']
for tag, bad in (('L3_elsewhere', work / 'ELSEWHERE' / 'R08_Q1_20261021213805_ab22c361e562'),
                 ('L4_uppercase_hex', local / 'CDT20_R08' / 'R08_Q1_20261021213805_AB22C361E562'),
                 ('L5_missing', local / 'CDT20_R08' / 'R08_Q1_20261021213805_000000000000'),
                 ('L6_not_a_run_name', local / 'CDT20_R08')):
    r, argv = run(tag, local, ['-AutorizoLabD', '-RetomarRaiz', str(bad)])
    check(tag + '_refused_before_any_call', not r['ok'] and r['error'].startswith('RETOMAR_RAIZ_INVALIDA=') and argv == [], r.get('error'))
r, argv = run('L7_no_localappdata', None, ['-AutorizoLabD', '-RetomarRaiz', str(root)])
check('L7_no_localappdata_refused', not r['ok'] and r['error'].startswith('RETOMAR_RAIZ_INVALIDA=') and argv == [], r.get('error'))
# L8: the UAC child receives -RetomarRaiz intact (path with spaces) through the launcher's own Arguments string.
o = work / 'L8_child'; o.mkdir()
env = dict(os.environ, QUAL_OUT=str(o), QUAL_PY=sys.executable, QUAL_PROBE=str(probe), LOCALAPPDATA=str(local))
import shlex
argv_child = shlex.split(uac)   # the launcher's Arguments string, split as a command line (quoted path with spaces)
cp = subprocess.run([str(pwsh)] + argv_child, env=env, timeout=60, capture_output=True, text=True)
cres = json.loads((o / 'RESULT_CHILD.json').read_text(encoding='utf-8-sig'))
clog = (o / 'LOG_CHILD.txt').read_text()
cargv = [json.loads(l.split('ARGV=', 1)[1]) for l in clog.splitlines() if 'ARGV=' in l]
check('L8_uac_child_receives_same_root_and_forwards_it', cres['ok'] and cres['retomar'] == str(root)
      and all(a[-2:] == ['--resume-root', str(root)] for a in cargv) and len(cargv) == 2, {'child': cres, 'argv': cargv})
doc = {'schema': 'CDT21_G5_V004_R3_LAUNCHER_QUALIFICATION_V001', 'launcher_sha256': hashlib.sha256(raw).hexdigest().upper(),
       'fragments_sha256': {k: hashlib.sha256(v.encode()).hexdigest().upper() for k, v in frags.items()},
       'passed': sum(c['pass'] for c in results), 'total': len(results), 'cases': results}
Path(out).write_text(json.dumps(doc, indent=1), encoding='utf-8')
print('R3_LAUNCHER', doc['passed'], '/', doc['total'], [c['case'] for c in results if not c['pass']])
