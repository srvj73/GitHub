"""Contract-faithful stand-in for PRE_G06_CAMPAIGN.main on Linux (qualification of the supervisor only).

The REAL frozen V004 module supplies: the plan constants, verify_package, the reuse path of run_unit (REUSE_COMMITTED,
COMMITTED_INPUT_DRIFT, artifact re-hash), physical(), write_terminal() and seal_return().  Only the execution of a NEW
unit (Windows-only: spawned child under a Job) is simulated, publishing a COMMIT in the frozen format and printing
'COMMITTED <key>' exactly like run_unit.  Interrupted bytes of an unfinished unit are archived exactly like run_unit.
Controls (environment): STUB_STOP_AFTER=n   operator SAFE_STOP after n new commits
                        STUB_KILL_AFTER=n   abrupt death inside the unit after n new commits (no terminal, no seal)
                        STUB_FAKE_REUSE=1   prints a REUSE_COMMITTED line in a run (negative control)
"""
import argparse
import os
import shutil
import sys
import uuid
from pathlib import Path

real = Path(os.environ['STUB_REAL_CAMPAIGN'])
cand = real.parents[1]
for f in ('full', 'control', 'adapter', 'g5proof'):
    sys.path.insert(0, str(cand / f))
import PRE_G06_CAMPAIGN as C          # noqa: E402  frozen V004 bytes
import FULL_CRASH_RECOVERY as R       # noqa: E402
import FULL_G5_COMPLETE_PROOF_GATE as gate  # noqa: E402

ap = argparse.ArgumentParser(allow_abbrev=False)
for name in ('run-root', 'package', 'witness', 'd-parent'):
    ap.add_argument('--' + name, required=True)
a = ap.parse_args()
root = Path(a.run_root)
result = {'schema': 'CDT19_PRE_B06_NATIVE_ENGINEERING_V002', 'status': 'BLOCKED', 'tests': {}, 'additional_tests': {},
          'production_modified': False, 'full_started': False, 'b06': 'NOT_STARTED', 'g5_final': 'NOT_ISSUED', 'blockers': []}
stop_after = int(os.environ.get('STUB_STOP_AFTER', '0')); kill_after = int(os.environ.get('STUB_KILL_AFTER', '0'))
code = 2; new_commits = 0
try:
    C.require(Path(os.environ['TEMP']) == root / 'TEMP', 'CANONICAL_TEMP_REQUIRED')
    code_sha, members = C.verify_package(Path(a.package)); pack = R.sha(Path(a.package).read_bytes())
    witness = R.read(a.witness)[0]
    C.require(witness['package_sha256'] == pack and witness['manifest_sha256'] == R.sha(members['PACKAGE_MANIFEST.json']), 'WITNESS_BINDING')
    owner = R.read(root / 'OWNER.json')[0]
    C.require(owner['package_sha256'] == pack and owner['run_id'] == root.name, 'RUN_OWNER')
    C.require(R.read(Path(a.d_parent) / 'OWNER.json')[0] == owner, 'D_LAB_OWNER')
    for name in ('LOGS', 'UNITS', 'COMMITS', 'EVIDENCE', 'WORK'):
        (root / name).mkdir(exist_ok=True)
    result.update(code_manifest_sha256=code_sha, final_zip_sha256=pack, run_id=root.name)
    plan = (['G5_' + n for n in ('PS51_INSTALL_MENU', 'STAGE_B_REAL_ISOLATED_PATH_NATIVE', 'D4_REAL_ISOLATED_PATH_NATIVE')] +
            ['SUITE_' + n for n in gate.SUITES if n not in C.STAGE_SUITES] + ['DELTA_' + n for n in C.EXTRA] +
            ['PRE_B06_11_CHAIN', 'G3_G6_NATIVE'])
    if os.environ.get('STUB_FAKE_REUSE') == '1':
        print('REUSE_COMMITTED ' + plan[0], flush=True)
    for key in plan:
        C.require(not (root / 'SAFE_STOP.request').exists(), 'SAFE_STOP_REQUESTED')
        commit = root / 'COMMITS' / (key + '.json')
        if commit.exists():
            C.run_unit(dict(root=str(root), key=key, package_sha256=pack, code_sha256=code_sha))  # frozen reuse path
        else:
            stale = [p for p in (root / 'UNITS' / key, root / 'WORK' / key, root / 'LOGS' / (key + '.log')) if p.exists()]
            if stale:  # same as run_unit: interrupted bytes retained, never overwritten
                archive = root / 'INTERRUPTED_ATTEMPTS' / (key + '_' + uuid.uuid4().hex); archive.mkdir(parents=True)
                for n, p in enumerate(stale):
                    shutil.move(str(p), str(archive / (str(n) + '_' + p.name)))
            (root / 'UNITS' / key).mkdir()
            log = root / 'LOGS' / (key + '.log'); log.write_bytes(b'Ran 1 test in 0.001s\n\nOK\n')
            res = {'status': 'PASS', 'exit_code': 0, 'unit': key, 'test_count': 1,
                   'process': {'pid': os.getpid(), 'creation_filetime': 132000000000000000 + os.getpid()}}
            R.publish(root / 'UNITS' / key / 'RESULT.json', res)
            if kill_after and new_commits == kill_after:
                os._exit(9)  # abrupt death inside a unit: no commit, no terminal, no seal
            R.publish(commit, dict(schema='CDT19_NATIVE_UNIT_COMMIT_V001', package_sha256=pack, code_sha256=code_sha,
                                   result=res, artifacts=[C.physical(root / 'UNITS' / key / 'RESULT.json', root), C.physical(log, root)],
                                   owner=[res['process']], own_descendants_final=[], observed_processes=[], seconds=0.0))
            print('COMMITTED ' + key, flush=True)
            new_commits += 1
            if stop_after and new_commits == stop_after:
                (root / 'SAFE_STOP.request').write_text('operator')
        result['tests'][key] = {'status': 'PASS_NATIVE_SCOPED', 'exit_code': 0}
    result['status'] = 'PASS_NATIVE_INTEGRATED_PRE_B06'; code = 0
except BaseException as exc:
    stopped = 'SAFE_STOP_REQUESTED' in str(exc)
    code = 130 if stopped else 3
    result.update(status='SAFE_STOP' if stopped else 'BLOCKED', blockers=[type(exc).__name__ + ':' + str(exc)])
    print(result['blockers'][0], flush=True)
finally:
    C.write_terminal(root, result)
    z = C.seal_return(root, 'R08_RETURN.zip', excluded=('R08_RETURN.zip', 'R08_RETURN.sha256'))
    (root / 'R08_RETURN.sha256').write_text(R.sha(z.read_bytes()) + '  R08_RETURN.zip\n', encoding='ascii')
sys.exit(code)
