"""Derive RUN_CDT21_G5_V004_R3_20261021.ps1 from the R2 launcher (8CC1ACB6...): resume of the same V004 campaign.

Usage: python -I build_v004_r3_launcher.py <RUN_CDT21_G5_V004_R2_20261021.ps1> <supervisor R3.py> <out.ps1>
Adds -RetomarRaiz <root> (validated: LOCALAPPDATA\\CDT20_R08\\R08_Q1_<14 digits>_<12 hex>, existing directory),
forwards it to the UAC child and passes --resume-root to phases Q and E; embeds the R3 supervisor.  Without
-RetomarRaiz the launcher behaves exactly as R2 (new campaign).  R1 classification, review payload, paths, log rule and
return packaging are unchanged.
"""
import base64
import hashlib
import sys
from pathlib import Path

R2_SHA = '8CC1ACB6B093020D4CFC94B3EB618A624243A3F8B3E9E1E991EA7B9E9C1B8DA2'
OLD_SUP = '2A5F4B7138C950D320F7787540F98FF912D1AFB6C86C59E0F562887DB671029F'
r2, sup, out = map(Path, sys.argv[1:4])
raw = r2.read_bytes()
assert hashlib.sha256(raw).hexdigest().upper() == R2_SHA, 'R2_SHA'
text = raw.decode('ascii').replace('\r\n', '\n')
sup_raw = sup.read_bytes(); new_sup = hashlib.sha256(sup_raw).hexdigest().upper()
b64 = base64.b64encode(sup_raw).decode()
start = text.index("$SupervisorB64 = @'\n") + len("$SupervisorB64 = @'\n")
end = text.index("\n'@", start)
assert hashlib.sha256(base64.b64decode(text[start:end].replace('\n', ''))).hexdigest().upper() == OLD_SUP
text = text[:start] + '\n'.join(b64[i:i + 100] for i in range(0, len(b64), 100)) + text[end:]

EDITS = [
    ("# TICKSTORE CDT21 - LAUNCHER G5 V004 R2: campanha G5 nativa NOVA vinculada ao manifesto completo do V004 (decisao da origem 21/10).\n",
     "# TICKSTORE CDT21 - LAUNCHER G5 V004 R3: campanha G5 nativa vinculada ao manifesto completo do V004 (decisao da origem 21/10).\n"
     "# R3 (auditoria da origem): retomada deterministica SOMENTE da mesma campanha V004 (-RetomarRaiz). A raiz precisa ter sido criada\n"
     "# por este supervisor para os bytes do V004; reutilizam-se apenas COMMITs integros, vinculados ao V004 e registrados no livro-razao\n"
     "# do supervisor dessa raiz. COMMITs do V003, de outro candidato ou de outra campanha sao recusados antes de qualquer efeito.\n"),
    ("# byte a byte, mesmo Job kill-on-close, impressao digital de D:\\Base CSV pela vista da entrada (R2); sem modo de retomada.\n",
     "# byte a byte, mesmo Job kill-on-close, impressao digital de D:\\Base CSV pela vista da entrada (R2); retomada so da mesma campanha (R3).\n"),
    ("# cinco partes; recusa qualquer REUSE_COMMITTED, exige 38 COMMITs vinculados ao V004 e raizes preexistentes inalteradas.\n",
     "# cinco partes; numa campanha nova recusa qualquer REUSE_COMMITTED; exige 38 COMMITs vinculados ao V004 e raizes preexistentes\n"
     "# inalteradas. Na retomada, so a raiz retomada e seu laboratorio mudam; nenhuma raiz nova e criada.\n"),
    ('#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\\Users\\silvi\\Downloads\\RUN_CDT21_G5_V004_R2_20261021.ps1" -AutorizoLabD\n',
     '#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\\Users\\silvi\\Downloads\\RUN_CDT21_G5_V004_R3_20261021.ps1" -AutorizoLabD\n'
     '# Retomada da mesma campanha apos SAFE_STOP ou interrupcao (raiz informada pelo supervisor em RETOMADA_DA_MESMA_CAMPANHA):\n'
     '#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\\Users\\silvi\\Downloads\\RUN_CDT21_G5_V004_R3_20261021.ps1" -AutorizoLabD -RetomarRaiz "<raiz>"\n'),
    ("param([switch]$AutorizoLabD, [switch]$ElevatedChild, [string]$SharedLogDir = '', [int]$LauncherParentPid = 0, [string]$LauncherParentCreation = '')\n",
     "param([switch]$AutorizoLabD, [switch]$ElevatedChild, [string]$SharedLogDir = '', [int]$LauncherParentPid = 0, [string]$LauncherParentCreation = '', [string]$RetomarRaiz = '')\n"),
    ("    Log ('MODO=G5_V004_NOVA_CAMPANHA FASE_Q=SEMPRE FASE_E=' + $(if ($AutorizoLabD) { 'AUTORIZADA' } else { 'NAO_AUTORIZADA' }) + ' RAIZ=NOVA (gerada pelo supervisor)')\n",
     "    Log ('MODO=G5_V004_' + $(if ($RetomarRaiz) { 'RETOMADA_MESMA_CAMPANHA' } else { 'NOVA_CAMPANHA' }) + ' FASE_Q=SEMPRE FASE_E=' + $(if ($AutorizoLabD) { 'AUTORIZADA' } else { 'NAO_AUTORIZADA' }) + $(if ($RetomarRaiz) { ' RAIZ=' + $RetomarRaiz } else { ' RAIZ=NOVA (gerada pelo supervisor)' }))\n"),
    ("    Log 'ESCOPO=G5_TECNICO_V004; LABORATORIO_PROPRIO; PRODUCAO=NAO; COMMITS_V003=NAO_REUTILIZADOS; B06=NOT_STARTED; B07=NOT_STARTED; D4_D5=NOT_STARTED; CANARIO=NAO; FULL=NAO'\n",
     "    Log 'ESCOPO=G5_TECNICO_V004; LABORATORIO_PROPRIO; PRODUCAO=NAO; COMMITS_V003=NAO_REUTILIZADOS; COMMITS_DE_OUTRA_CAMPANHA=NAO_REUTILIZADOS; RETOMADA=SO_MESMA_CAMPANHA_V004; B06=NOT_STARTED; B07=NOT_STARTED; D4_D5=NOT_STARTED; CANARIO=NAO; FULL=NAO'\n"),
    ("{ throw 'WINDOWS_POWERSHELL_5_1_REQUIRED' }\n",
     "{ throw 'WINDOWS_POWERSHELL_5_1_REQUIRED' }\n"
     "    $ResumeArgs = @()\n"
     "    if ($RetomarRaiz) {\n"
     "        $rr = [IO.Path]::GetFullPath($RetomarRaiz)\n"
     "        if (-not $env:LOCALAPPDATA -or [IO.Path]::GetDirectoryName($rr) -ine (Join-Path $env:LOCALAPPDATA 'CDT20_R08') -or\n"
     "            [IO.Path]::GetFileName($rr) -cnotmatch '^R08_Q1_[0-9]{14}_[0-9a-f]{12}$' -or -not (Test-Path -LiteralPath $rr -PathType Container)) {\n"
     "            throw ('RETOMAR_RAIZ_INVALIDA=' + $RetomarRaiz)\n"
     "        }\n"
     "        $RetomarRaiz = $rr\n"
     "        $ResumeArgs = @('--resume-root', $rr)\n"
     "        Log ('RETOMADA_SOLICITADA=' + $rr + ' (admissao decidida pela Fase Q: mesma campanha, mesmos bytes, livro-razao)')\n"
     "    }\n"),
    ("$(if ($AutorizoLabD) { ' -AutorizoLabD' } else { '' }) + ' -ElevatedChild -SharedLogDir \"' + $LogDir + '\" -LauncherParentPid ' + $PID + ' -LauncherParentCreation ' + $selfCreation\n",
     "$(if ($AutorizoLabD) { ' -AutorizoLabD' } else { '' }) + $(if ($RetomarRaiz) { ' -RetomarRaiz \"' + $RetomarRaiz + '\"' } else { '' }) + ' -ElevatedChild -SharedLogDir \"' + $LogDir + '\" -LauncherParentPid ' + $PID + ' -LauncherParentCreation ' + $selfCreation\n"),
    ("--qualify-only --package $Package --review $Review --log-dir $LogDir --stage $Stage 2>&1 |",
     "--qualify-only --package $Package --review $Review --log-dir $LogDir --stage $Stage @ResumeArgs 2>&1 |"),
    ("--stage $Stage --require-qualification $qfile 2>&1 |",
     "--stage $Stage --require-qualification $qfile @ResumeArgs 2>&1 |"),
    ("$SupervisorSha = '" + OLD_SUP + "'\n", "$SupervisorSha = '" + new_sup + "'\n"),
]
for old, new in EDITS:
    assert text.count(old) == 1, ('ANCHOR', old[:90])
    text = text.replace(old, new)
data = text.replace('\n', '\r\n').encode('ascii')
out.write_bytes(data)
print(out.name, hashlib.sha256(data).hexdigest().upper(), len(data), 'SUPERVISOR', new_sup)
