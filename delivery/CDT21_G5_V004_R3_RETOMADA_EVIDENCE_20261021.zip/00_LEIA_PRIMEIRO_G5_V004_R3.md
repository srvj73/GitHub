# CDT21 — G5 V004 R3: retomada determinística da mesma campanha V004

**Papel:** implementador. Este documento não é parecer B06.

## Pendência da origem e contrato aplicável

O R2 removeu a retomada e recusava **qualquer** `REUSE_COMMITTED`. Com isso, uma campanha V004 interrompida por SAFE_STOP, por queda ou durante o fechamento teria de recomeçar do zero.

O **contrato congelado do próprio V004** prevê o oposto:
- `PRE_G06_CAMPAIGN.run_unit` reutiliza um COMMIT da mesma raiz desde que ele esteja fechado (PASS, exit 0, sem descendentes) e vinculado aos mesmos `package_sha256` e `code_sha256`, com todos os artefatos re-hasheados. Caso contrário, recusa com `COMMITTED_INPUT_DRIFT`, `COMMITTED_UNIT_NOT_CLOSED` ou `PHYSICAL_REF_DRIFT`.
- `test_cdt19_native_campaign_contract` tem dois testes que fixam essa regra: `test_committed_same_bytes_reused` e `test_cross_package_commit_cannot_be_rebound`.
- `seal_return` e `preserve_prior_partial` tratam explicitamente a “retomada no mesmo pacote”.
- `PRE_G06_COMPLETENESS` preserva uma montagem `FINAL_G5` anterior, completa ou interrompida, sem reexecutar testes nativos.

**A retomada da mesma campanha, portanto, é aplicável e necessária.** A reutilização de COMMITs de outro candidato (V003) ou de outra campanha continua proibida.

## Supervisor R3 — `CDT21_G5_V004_SUPERVISOR.py` (`2765FAAAC4725F5925921E25B93E145D3719EFC686BDFD7511A110440B0A1DAD`)

O R3 é derivado do R2 (`2A5F4B71…`) por substituições contadas. O diff que ignora espaços em branco tem 16 linhas removidas, todas assinaturas ou textos substituídos.

**Campanha nova (sem `--resume-root`):** idêntica ao R2.
- Raiz e laboratório são novos, criados com `mkdir` sem `exist_ok`.
- `NEW_RUN_REUSED_A_COMMIT` e `COMMITTED_NOW_NE_PLAN` continuam literalmente no código.
- A correção NTFS do R2 está intacta.
- **Acréscimo:** o livro-razão `CDT21_SUPERVISOR_LEDGER/<chave>.json`. Quando o próprio filho de campanha do supervisor imprime `COMMITTED <chave>`, o supervisor registra o SHA do arquivo de COMMIT. O registro é gravado em `TEMP`, que fica fora do selo congelado, e depois movido atomicamente.

**Retomada (`--resume-root <raiz>`): a Fase Q, somente leitura, admite a raiz apenas se:**
1. A raiz estiver em `LOCALAPPDATA\CDT20_R08\R08_Q1_<14>_<12 hex>`, sem link nem junction.
2. O `CDT21_SUPERVISOR_BOOTSTRAP.json` tiver sido escrito **por este mesmo supervisor** (SHA igual), em modo `NEW_RUN_V004`, com os bytes do V004 (pacote, código, manifesto, campanha e fechamento), `v003_commits_reused = 0` e livro-razão declarado.
3. `OWNER.json` da raiz e do laboratório D:, testemunha e pacote de `INPUTS` forem exatamente os do V004.
4. Cada COMMIT:
   - pertencer ao plano;
   - **não** estiver vinculado ao V003;
   - estiver fechado e vinculado ao pacote e ao código do V004;
   - tiver todos os artefatos re-hasheados, sem escapar da raiz;
   - **constar no livro-razão desta campanha com o mesmo SHA.**

   Não pode haver registro no livro-razão sem o COMMIT correspondente.
5. O estado anterior for `SAFE_STOP`, `BLOCKED`, `PASS` do `main` congelado (fechamento interrompido) ou ausente (queda abrupta). Vínculos presentes têm de coincidir; só um `BLOCKED` precoce pode não tê-los.
6. Os processos da tentativa anterior estiverem mortos (`R.dead` congelado) e o `CAMPAIGN.lock` estiver livre.

**A fase E repete a admissão e acrescenta:**
- exige o mesmo conjunto de COMMITs admitido na Q;
- adquire o lock e preserva o terminal anterior (copiado; o `SAFE_STOP.request` é movido para `INTERRUPTED_ATTEMPTS/PRIOR_TERMINAL_<stamp>`);
- grava `CDT21_SUPERVISOR_RESUME_<stamp>.json`;
- executa a campanha congelada, que reutiliza o que for íntegro;
- depois exige:
  - reutilizadas ⊆ admitidas;
  - nenhuma recomitida;
  - reutilizadas + novas = plano de 38;
  - 38 COMMITs vinculados ao V004 e todos no livro-razão;
  - só a raiz retomada e seu laboratório mudaram e nenhuma raiz nova surgiu.

## Launcher único — `RUN_CDT21_G5_V004_R3_20261021.ps1` (`B68494D29563702592C867051FC94BDCE72A7A496AF006A691AC8CFB522D6E39`)

| Item | Comportamento |
|---|---|
| `-RetomarRaiz <raiz>` | validado (pai `LOCALAPPDATA\CDT20_R08`, nome `R08_Q1_…` com hex minúsculo, diretório existente), repassado ao filho UAC e entregue como `--resume-root` às fases Q e E |
| Sem `-RetomarRaiz` | idêntico ao R2 |
| Inalterados | classificação R1, revisão `E84E5C39…`, caminhos, log e retorno |
| Checagem estática | parser 0 erros, ASCII, CRLF |

## Qualificação (Linux)

**Retomada ponta a ponta — 28/28.** Roda o `main()` real do R3 (Q e E). A reutilização passa pelo `run_unit` congelado real, com `write_terminal` e `seal_return` congelados.

| Grupo | Casos |
|---|---|
| Campanha nova | 38 novas, 0 reutilizadas, 38 registros no livro-razão |
| SAFE_STOP → retomada | 5 reutilizadas e 33 novas, PASS; terminal preservado e pedido consumido; retorno com recibo e livro-razão |
| Queda abrupta → retomada | sem terminal; 3 reutilizadas e 35 novas; unidade interrompida preservada |
| Duas interrupções | 3 tentativas, PASS |
| Fechamento interrompido → retomada | 38 reutilizadas, fechamento refeito, `FINAL_G5` anterior preservado |
| Recusas | COMMIT do V003; de outro candidato; **de outra campanha V004 com os mesmos bytes** (`COMMIT_NOT_LEDGERED`); livro-razão adulterado; artefato adulterado; registro sem COMMIT; chave fora do plano; raiz de outro supervisor; raiz do V003; raiz fora de `CDT20_R08`; lock em uso; processo anterior vivo; Q de outro modo ou de outra raiz; raiz alterada entre Q e E; campanha nova com `REUSE_COMMITTED`; outra raiz alterada durante a retomada |

**Mutantes:** ver `03_QUALIFICACAO/mutantes`. Cada enfraquecimento da admissão é morto.

**Launcher: 8/8,** com fragmentos verbatim:
- sem retomada, não há argumentos de retomada;
- com raiz válida, `--resume-root` chega às fases Q e E;
- recusas antes de qualquer chamada: fora de `CDT20_R08`, hex maiúsculo, raiz inexistente, nome inválido, sem `LOCALAPPDATA`;
- o filho UAC recebe a raiz intacta, mesmo com espaços.

**Regressões sobre o R3:**
- Digest R2 (correção NTFS): todos os casos de comportamento (E2–E7) passam. C1 e C2 mudam por construção.
- Validação V004: 37/41. As 4 diferenças são checagens da decisão anterior “sem retomada”, invertidas pela auditoria. Os comportamentos protetores equivalentes da R3 estão provados em N09, N13 e N15.

## Resíduos declarados (falha fechada)

- **COMMIT publicado e não registrado:** se o COMMIT for publicado e a máquina cair nos milissegundos antes do registro no livro-razão, a retomada dessa raiz é recusada (`COMMIT_NOT_LEDGERED`) e é preciso campanha nova. Nenhum COMMIT sem prova de origem é reutilizado.
- **Mesmo supervisor:** a retomada exige os mesmos bytes do supervisor que criou a raiz. Se o supervisor for revisado, é necessária campanha nova.

RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 21
