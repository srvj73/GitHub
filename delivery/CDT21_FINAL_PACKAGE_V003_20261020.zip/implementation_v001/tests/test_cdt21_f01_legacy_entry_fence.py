"""CDT21 F-01 / F-04: legacy V004R1 entry closed by the legacy entry fence; frozen launcher pinned.

The frozen bytes are executed, not re-implemented: recovery/modules/orchestrator.py (V002
3C16FC13...) runs as its own CLI, `python -I -S -B orchestrator.py <command> --package <lab>
--python <exe>`, which is exactly the command line of recovery/TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1,
against an owned lab control root built from a copy of the sealed configuration.  Production
roots are never named: every absolute path of the lab configuration points into the lab.
Windows-only behaviour (PS 5.1 master launcher, share-mode pins) runs natively in the G0 runner.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import unittest
import zipfile

R = Path(__file__).resolve().parents[1]
C = R / 'candidate'
ORCH = C / 'recovery/modules/orchestrator.py'
MASTER = C / 'recovery/TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1'
LAUNCH = C / 'recovery/modules/Launch-TickstoreBundle.ps1'
LOADER = C / 'recovery/loader/INLINE_ROOT_LOADER_V004_R1R1.ps1'
CONFIG = C / 'recovery/config/STAGE_A_SEALED_VALUES_V001.json'
FENCE_TOOL = C / 'control/LEGACY_ENTRY_FENCE.py'
FROZEN = {
    'recovery/modules/orchestrator.py': '3C16FC13DBB2C1903DBA4D1463E1249C19086743723E72138F9EDF9A83F741A0',
    'recovery/TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1': '18900BCC198347A5912AA4CEC23F4D9E7A2513FC41EBE393BFD8151F9EEF259A',
    'recovery/modules/Launch-TickstoreBundle.ps1': '56B7F4FDF1978AB96B23A143907F697C7E89FD6DBCB272CFF9E0C9F4E7D6AB02',
    'recovery/loader/INLINE_ROOT_LOADER_V004_R1R1.ps1': '74FE55D8FC43A5C1CEDE22887C60624DC454D3E52E26E1C3AA108072451F1597',
    'recovery/engine/tickstore_publisher_recovery_v004_release.py': '4BB92D88DB728F4BAE3C207C4627F6FDA4D2FAB593E785E7311A90D3CC9F11E7',
    'recovery/engine/tickstore_publisher_recovery_v004_candidate.py': '53F72DAE59A2663018A4C0FE6BCBB5B1338F56115826C4265EC74D73ED275FE7',
    'recovery/config/STAGE_A_SEALED_VALUES_V001.json': '07DD406B9AD03EE12FAEB7E6CCD46A1C8BB04E14DE1538E7C673704641A87D60',
    'recovery/CODE_MANIFEST.json': 'DE46741A211DBEE4318CB0FCA93435B9D8BAD0E0E390597923978482E809D1F5',
    'recovery/99_MANIFEST_SHA256.json': '934723BA1D215907A21218631D1CFBAE6B044B245DCA7150BE9EEDE4A59DBAAA',
}
COMMANDS = ('plan', 'status', 'stop', 'run', 'resume', 'reconcile', 'confirm-stale-lock', 'ingest-stage-b', 'postfull', 'attach')
PINNED_PYTHON = Path(r'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe')
LAUNCHER_HOME = Path(r'C:\Users\silvi')
NATIVE = os.name == 'nt'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


E = load('cdt21_f01_entry', C / 'adapter/runtime_locator_orchestrator_entry.py')
A = load('cdt21_f01_adapter', C / 'adapter/runtime_locator_adapter.py')


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def snapshot(root):
    """Every entry under root: directories as DIR, files as (sha, size, inode, mtime_ns)."""
    out = {}
    for d, dirs, files in os.walk(root):
        for n in dirs:
            out[os.path.relpath(os.path.join(d, n), root)] = 'DIR'
        for n in files:
            p = os.path.join(d, n)
            st = os.lstat(p)
            with open(p, 'rb') as f:
                out[os.path.relpath(p, root)] = (sha(f.read()), st.st_size, st.st_ino, st.st_mtime_ns)
    return out


def labify(value, lab):
    if isinstance(value, str) and re.match(r'^[A-Za-z]:\\', value):
        return str(lab / 'foreign' / re.sub(r'[^A-Za-z0-9_.-]+', '_', value))
    if isinstance(value, list):
        return [labify(v, lab) for v in value]
    return value


class Lab:
    """Owned lab: frozen orchestrator + master launcher copies, and a sealed-config copy pointing into the lab."""

    def __init__(self, td):
        self.root = Path(td)
        self.pkg = self.root / 'pkg'
        self.control = self.root / 'control'
        (self.pkg / 'modules').mkdir(parents=True)
        (self.pkg / 'config').mkdir()
        shutil.copyfile(ORCH, self.pkg / 'modules/orchestrator.py')
        shutil.copyfile(MASTER, self.pkg / MASTER.name)
        cfg = {k: labify(v, self.root) for k, v in json.loads(CONFIG.read_bytes()).items()}
        cfg['control_root'] = str(self.control)
        cfg['python_exe_sha256'] = sha(Path(sys.executable).read_bytes())
        self.config_path = self.pkg / 'config/STAGE_A_SEALED_VALUES_V001.json'
        self.config_path.write_bytes((json.dumps(cfg, indent=1, sort_keys=True) + '\n').encode('ascii'))
        self.sd = self.control / 'state'
        self.sp = self.sd / 'STATE.json'
        self.jp = self.sd / 'STATE_JOURNAL.jsonl'
        self.fence = self.sd / 'STATE.json.partial'

    def layout(self):
        for n in ('state', 'runs', 'inbox', 'packs', 'evidence'):
            (self.control / n).mkdir(parents=True, exist_ok=True)

    def d4_state(self):
        obj = {'schema': 'TICKSTORE_ORCH_STATE_V001', 'next_node': 'D4', 'status': 'FAIL',
               'completed': ['A0', 'A1', 'A2', 'A3', 'B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B8', 'B6X', 'B9',
                             'C1', 'C2', 'C3', 'D1', 'D2', 'D3'], 'engine': None}
        # Deliberately non-canonical bytes: a frozen rewrite would be visible.
        self.sp.write_bytes((json.dumps(obj, indent=3) + '\n').encode('ascii'))
        line = json.dumps({'ts': 'lab', 'node': 'D4', 'phase': 'FINISHED', 'prev_line_sha256': '', 'status': 'FAIL'},
                          sort_keys=True, separators=(',', ':')).encode('ascii')
        self.jp.write_bytes(line + b'\n')

    def frozen(self, command):
        args = [sys.executable, '-I', '-S', '-B', str(self.pkg / 'modules/orchestrator.py'), command,
                '--package', str(self.pkg), '--python', sys.executable]
        if command == 'confirm-stale-lock':
            args += ['--lock-sha', 'A' * 64]
        return subprocess.run(args, capture_output=True, text=True, timeout=180, cwd=str(self.root))

    def tool(self, *extra):
        p = subprocess.run([sys.executable, '-B', '-I', str(FENCE_TOOL), '--state', str(self.sp),
                            '--adapter-dir', str(C / 'adapter'), *extra],
                           capture_output=True, text=True, timeout=120, cwd=str(self.root))
        return p.returncode, json.loads(p.stdout)


class Base(unittest.TestCase):
    def setUp(self):
        for rel, digest in FROZEN.items():
            self.assertEqual(sha((C / rel).read_bytes()), digest, 'frozen successor bytes changed: ' + rel)
        t = tempfile.TemporaryDirectory(prefix='cdt21_f01_')
        self.addCleanup(t.cleanup)
        self.lab = Lab(t.name)


class F01FrozenLegacyRoute(Base):
    def test_01_master_launcher_is_exactly_the_frozen_cli_and_writes_nothing_itself(self):
        text = MASTER.read_text(encoding='utf-8-sig')
        self.assertIn("$M=[IO.Path]::Combine($PSScriptRoot,'modules','orchestrator.py')", text)
        self.assertIn("$A=@('-I','-S','-B',$M,$Command,'--package',$PSScriptRoot,'--python',$Python)", text)
        self.assertIn('& $Python @A', text)
        commands = re.search(r"ValidateSet\(([^)]*)\)", text).group(1)
        self.assertEqual(set(re.findall(r"'([a-z-]+)'", commands)), set(COMMANDS))
        for token in ('Set-Content', 'Add-Content', 'Out-File', 'New-Item', 'Remove-Item', 'Copy-Item', 'Move-Item',
                      'Rename-Item', 'WriteAll', 'Start-Process', 'Invoke-Expression', 'Launch-TickstoreBundle'):
            self.assertNotIn(token, text)

    def test_02_v002_defect_reproduced_without_fence(self):
        # Discriminating control: without the fence the frozen CLI creates and rewrites STATE.
        self.lab.layout()
        r = self.lab.frozen('status')
        self.assertEqual(r.returncode, 0, r.stderr)
        created = json.loads(self.lab.sp.read_bytes())
        self.assertEqual((created['next_node'], created['status']), ('A0', 'NEW'))
        self.lab.d4_state()
        before = self.lab.sp.read_bytes()
        self.assertEqual(self.lab.frozen('plan').returncode, 0)
        self.assertNotEqual(self.lab.sp.read_bytes(), before)

    def _assert_every_command_blocked_without_effect(self):
        before = snapshot(self.lab.control)
        for command in COMMANDS:
            r = self.lab.frozen(command)
            self.assertNotEqual(r.returncode, 0, command)
            self.assertIn('STATE.json.partial', r.stderr, command)
            self.assertEqual(snapshot(self.lab.control), before, command)

    def test_03_fence_missing_state_never_created(self):
        self.lab.layout()
        self.assertEqual(self.lab.tool('--apply')[0], 0)
        self._assert_every_command_blocked_without_effect()
        self.assertFalse(self.lab.sp.exists())

    def test_04_fence_existing_state_never_rewritten(self):
        self.lab.layout()
        self.lab.d4_state()
        self.assertEqual(self.lab.tool('--apply')[0], 0)
        self._assert_every_command_blocked_without_effect()

    def test_05_fence_orphan_journal_never_reinitialized(self):
        self.lab.layout()
        self.lab.d4_state()
        self.lab.sp.unlink()
        self.assertEqual(self.lab.tool('--apply')[0], 0)
        self._assert_every_command_blocked_without_effect()
        self.assertFalse(self.lab.sp.exists())

    def test_06_no_run_directory_or_inbox_token_on_effectful_commands(self):
        self.lab.layout()
        self.lab.d4_state()
        self.assertEqual(self.lab.tool('--apply')[0], 0)
        for command in ('run', 'resume', 'postfull', 'confirm-stale-lock', 'reconcile'):
            self.assertNotEqual(self.lab.frozen(command).returncode, 0)
        self.assertEqual(list((self.lab.control / 'runs').iterdir()), [])
        self.assertEqual(list((self.lab.control / 'inbox').iterdir()), [])

    @unittest.skipUnless(NATIVE and PINNED_PYTHON.is_file() and LAUNCHER_HOME.is_dir(), 'Windows PS 5.1 master launcher (G0)')
    def test_07_native_master_launcher_blocked_without_effect(self):
        self.lab.layout()
        self.lab.d4_state()
        self.assertEqual(self.lab.tool('--apply')[0], 0)
        before = snapshot(self.lab.control)
        ps = Path(os.environ['SystemRoot']) / 'System32/WindowsPowerShell/v1.0/powershell.exe'
        for command in COMMANDS:
            args = [str(ps), '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File',
                    str(self.lab.pkg / MASTER.name), command]
            if command == 'confirm-stale-lock':
                args += ['-LockSha', 'A' * 64]
            r = subprocess.run(args, capture_output=True, text=True, timeout=300, cwd=str(LAUNCHER_HOME))
            out = r.stdout + r.stderr
            self.assertIn('TARGET_SHELL_PARSE=PASS', out, command)  # the launcher reached the frozen CLI
            self.assertNotEqual(r.returncode, 0, command)
            self.assertIn('STATE.json.partial', out, command)
            self.assertEqual(snapshot(self.lab.control), before, command)


class F01FenceTool(Base):
    def test_10_diagnose_is_read_only(self):
        self.lab.layout()
        self.lab.d4_state()
        before = snapshot(self.lab.control)
        code, rep = self.lab.tool()
        self.assertEqual((code, rep['decision']), (2, 'FENCE_ABSENT_INSTALLABLE'))
        self.assertEqual(snapshot(self.lab.control), before)

    def test_11_apply_installs_verifies_and_is_idempotent(self):
        self.lab.layout()
        self.lab.d4_state()
        state_before = (self.lab.sp.read_bytes(), self.lab.jp.read_bytes())
        code, rep = self.lab.tool('--apply')
        self.assertEqual((code, rep['decision'], rep['applied'], rep['frozen_write_denied']), (0, 'FENCE_PRESENT', True, True))
        self.assertEqual((self.lab.sp.read_bytes(), self.lab.jp.read_bytes()), state_before)
        E.require_legacy_entry_fence(self.lab.sp)
        between = snapshot(self.lab.control)
        code, rep = self.lab.tool('--apply')
        self.assertEqual((code, rep['decision']), (0, 'FENCE_PRESENT'))
        self.assertNotIn('applied', rep)
        self.assertEqual(snapshot(self.lab.control), between)

    def test_12_interrupted_frozen_write_debris_blocks_and_is_preserved(self):
        self.lab.layout()
        self.lab.d4_state()
        self.lab.fence.write_bytes(b'{"half":')
        before = snapshot(self.lab.control)
        code, rep = self.lab.tool('--apply')
        self.assertEqual((code, rep['decision']), (2, 'BLOCKED_MANUAL'))
        self.assertIn('LEGACY_PARTIAL_DEBRIS_PRESENT', rep['reasons'])
        self.assertEqual(snapshot(self.lab.control), before)

    def test_13_fence_without_valid_marker_blocks(self):
        self.lab.layout()
        self.lab.fence.mkdir()
        code, rep = self.lab.tool('--apply')
        self.assertEqual((code, rep['decision']), (2, 'BLOCKED_MANUAL'))
        self.assertTrue(any('LEGACY_ENTRY_FENCE_MARKER' in r for r in rep['reasons']))
        (self.lab.fence / E.LEGACY_ENTRY_FENCE_MARKER).write_text(json.dumps({'schema': 'WRONG'}))
        code, rep = self.lab.tool('--apply')
        self.assertEqual((code, rep['decision']), (2, 'BLOCKED_MANUAL'))
        self.assertIn('LEGACY_ENTRY_FENCE_MARKER_CONTENT', rep['reasons'])

    def test_14_link_at_fence_name_blocks(self):
        self.lab.layout()
        target = self.lab.root / 'elsewhere'
        target.mkdir()
        try:
            if NATIVE:
                cmd = Path(os.environ['SystemRoot']) / 'System32/cmd.exe'
                subprocess.run([str(cmd), '/d', '/c', 'mklink', '/J', str(self.lab.fence), str(target)], check=True,
                               capture_output=True, timeout=30)
            else:
                os.symlink(target, self.lab.fence, target_is_directory=True)
        except (OSError, subprocess.CalledProcessError):
            self.skipTest('cannot create a link here')
        code, rep = self.lab.tool('--apply')
        self.assertEqual((code, rep['decision']), (2, 'BLOCKED_MANUAL'))
        self.assertTrue(any('LINK_OR_REPARSE' in r for r in rep['reasons']), rep['reasons'])
        self.assertEqual(list(target.iterdir()), [])

    def test_15_missing_state_directory_blocks_and_creates_nothing(self):
        code, rep = self.lab.tool('--apply')
        self.assertEqual((code, rep['decision']), (2, 'BLOCKED_MANUAL'))
        self.assertFalse(self.lab.control.exists())

    def test_16_live_state_boundary_blocks_install(self):
        self.lab.layout()
        self.lab.d4_state()
        release = E.acquire_state_boundary(self.lab.sp)
        try:
            code, rep = self.lab.tool('--apply')
        finally:
            release()
        self.assertEqual((code, rep['decision']), (2, 'BLOCKED_MANUAL'))
        self.assertTrue(any('BOUNDARY' in r for r in rep['reasons']), rep['reasons'])
        self.assertFalse(os.path.lexists(self.lab.fence))


class F01AdmittedEntryRequiresFence(Base):
    def admitted(self):
        self.lab.layout()
        self.lab.d4_state()
        cfg_raw = self.lab.config_path.read_bytes()
        return {'config_path': str(self.lab.config_path), 'config_sha256': sha(cfg_raw)}

    def frozen_namespace(self):
        ns = {'__name__': 'cdt21_frozen_orchestrator_library', '__file__': str(ORCH)}
        exec(compile(ORCH.read_bytes(), str(ORCH), 'exec'), ns, ns)
        return ns

    def admitted_start(self):
        cfg_raw = self.lab.config_path.read_bytes()
        raw, ident = E.read_pinned_regular(self.lab.sp, 'TEST_STATE')
        return E.AdmittedStart(self.lab.sp, self.lab.control, self.lab.config_path, cfg_raw, sha(cfg_raw),
                               E._ident(os.lstat(self.lab.config_path)), raw, ident)

    def valid(self, obj):
        self.assertEqual(obj.get('schema'), 'TICKSTORE_ORCH_STATE_V001')

    def test_20_validate_d4_start_requires_fence_read_only(self):
        authority = self.admitted()
        before = snapshot(self.lab.control)
        with self.assertRaisesRegex(RuntimeError, 'LEGACY_ENTRY_FENCE_MISSING'):
            E.validate_d4_start(self.lab.pkg, sys.executable, authority)
        self.assertEqual(snapshot(self.lab.control), before)
        self.assertEqual(self.lab.tool('--apply')[0], 0)
        admitted = E.validate_d4_start(self.lab.pkg, sys.executable, authority)
        self.assertEqual(admitted.state_raw, self.lab.sp.read_bytes())

    def test_21_admitted_guard_refuses_without_fence_before_patching(self):
        self.admitted()
        ns = self.frozen_namespace()
        frozen_state, frozen_atomj = ns['State'], ns['atomj']
        with self.assertRaisesRegex(RuntimeError, 'LEGACY_ENTRY_FENCE_MISSING'):
            E.guard_frozen_state_reads(ns, self.admitted_start(), state_validator=self.valid)
        self.assertIs(ns['State'], frozen_state)
        self.assertIs(ns['atomj'], frozen_atomj)

    def test_22_admitted_commit_works_with_fence_and_legacy_stays_blocked(self):
        self.admitted()
        self.assertEqual(self.lab.tool('--apply')[0], 0)
        marker = (self.lab.fence / E.LEGACY_ENTRY_FENCE_MARKER).read_bytes()
        ns = self.frozen_namespace()
        E.guard_frozen_state_reads(ns, self.admitted_start(), state_validator=self.valid)
        try:
            st = ns['State'](self.lab.control)
            st.d['engineering_checkpoint'] = 1
            ns['atomj'](st.sp, st.d)
            self.assertEqual(self.lab.sp.read_bytes(), ns['jb'](st.d))
            after_commit = self.lab.sp.read_bytes()
            r = self.lab.frozen('status')
            self.assertNotEqual(r.returncode, 0)
            self.assertEqual(self.lab.sp.read_bytes(), after_commit)
        finally:
            ns['_TICKSTORE_D4_ENTRY_RELEASE_STATE_BOUNDARY']()
        self.assertEqual((self.lab.fence / E.LEGACY_ENTRY_FENCE_MARKER).read_bytes(), marker)
        self.assertEqual(sorted(n for n in os.listdir(self.lab.sd) if '.cas-' in n), [])

    def test_23_commit_refused_when_fence_removed_mid_run(self):
        self.admitted()
        self.assertEqual(self.lab.tool('--apply')[0], 0)
        ns = self.frozen_namespace()
        E.guard_frozen_state_reads(ns, self.admitted_start(), state_validator=self.valid)
        try:
            st = ns['State'](self.lab.control)
            before = self.lab.sp.read_bytes()
            (self.lab.fence / E.LEGACY_ENTRY_FENCE_MARKER).unlink()
            st.d['engineering_checkpoint'] = 2
            with self.assertRaisesRegex(RuntimeError, 'LEGACY_ENTRY_FENCE_MARKER_MISSING'):
                ns['atomj'](st.sp, st.d)
            self.assertEqual(self.lab.sp.read_bytes(), before)
            self.assertEqual(sorted(n for n in os.listdir(self.lab.sd) if '.cas-' in n), [])
        finally:
            ns['_TICKSTORE_D4_ENTRY_RELEASE_STATE_BOUNDARY']()

    def test_24_tampered_fence_variants_block(self):
        self.admitted()
        self.assertEqual(self.lab.tool('--apply')[0], 0)
        m = self.lab.fence / E.LEGACY_ENTRY_FENCE_MARKER
        good = m.read_bytes()
        m.write_bytes(b'not json')
        with self.assertRaisesRegex(RuntimeError, 'LEGACY_ENTRY_FENCE_MARKER_JSON'):
            E.require_legacy_entry_fence(self.lab.sp)
        obj = json.loads(good)
        obj['state_name'] = 'OTHER.json'
        m.write_text(json.dumps(obj))
        with self.assertRaisesRegex(RuntimeError, 'LEGACY_ENTRY_FENCE_MARKER_CONTENT'):
            E.require_legacy_entry_fence(self.lab.sp)
        m.unlink()
        self.lab.fence.rmdir()
        self.lab.fence.write_bytes(b'x')
        with self.assertRaisesRegex(RuntimeError, 'LEGACY_ENTRY_FENCE_NOT_DIRECTORY'):
            E.require_legacy_entry_fence(self.lab.sp)

    def test_25_state_only_callers_unchanged(self):
        # Path-mode guard (G3/G6 scenarios, PRE-B06 consumer fixture) keeps its V002 behaviour.
        self.lab.layout()
        self.lab.d4_state()
        ns = self.frozen_namespace()
        E.guard_frozen_state_reads(ns, self.lab.sp, state_validator=self.valid)
        try:
            st = ns['State'](self.lab.control)
            st.d['engineering_checkpoint'] = 3
            ns['atomj'](st.sp, st.d)
            self.assertEqual(self.lab.sp.read_bytes(), ns['jb'](st.d))
        finally:
            ns['_TICKSTORE_D4_ENTRY_RELEASE_STATE_BOUNDARY']()
        self.assertFalse(os.path.lexists(self.lab.fence))

    def test_26_official_admissions_use_the_fenced_functions(self):
        cont = (C / 'control/FULL_STAGE_CONTINUATION.py').read_text(encoding='utf-8')
        self.assertIn('admitted = entry.AdmittedStart(', cont)
        self.assertIn('entry.guard_frozen_state_reads(ns, admitted,', cont)
        boot = (C / 'control/D4_FIRST_ADMISSION_BOOTSTRAP.py').read_text(encoding='utf-8')
        self.assertIn('entry.validate_d4_start(', boot)
        src = (C / 'adapter/runtime_locator_orchestrator_entry.py').read_text(encoding='utf-8')
        main = src[src.index('def main() -> int:'):]
        self.assertIn('admitted = validate_d4_start(package, args.python, identity.ra)', main)
        self.assertIn('guard_frozen_state_reads(orch_ns, admitted)', main)


class F04FrozenLaunchPinned(Base):
    def successor(self):
        root = self.lab.root / 'SUCCESSOR_PACKAGE'
        (root / 'modules').mkdir(parents=True)
        (root / 'loader').mkdir()
        shutil.copyfile(LAUNCH, root / 'modules/Launch-TickstoreBundle.ps1')
        shutil.copyfile(LOADER, root / 'loader/INLINE_ROOT_LOADER_V004_R1R1.ps1')
        return root

    def adapted(self, pkg, launch):
        adapter_dir = self.lab.root / 'adapter'
        adapter_dir.mkdir()
        for name in ('runtime_locator_adapter.py', 'runtime_locator_inline_entry.py', 'Launch-TickstoreBundle-Adapter.ps1',
                     'RUNTIME_LOCATOR_ADAPTER_BINDING.json'):
            shutil.copyfile(C / 'adapter' / name, adapter_dir / name)
        binding = json.loads((C / 'adapter/RUNTIME_LOCATOR_ADAPTER_BINDING.json').read_bytes())
        receipt = adapter_dir / 'receipt.json'
        receipt.write_text('{}')

        class O:
            def __init__(self):
                self.pkg = pkg

            def n_d4(self):
                return 'frozen'

            def bundle(self, *a, **k):
                return 'bundle'

            def launch(self, *a, **k):
                return launch(*a, **k)

        ns = {'O': O, 'atomj': lambda *a, **k: None, 'shab': sha, 'subprocess': subprocess}
        A.install_orchestrator_namespace(ns, binding, adapter_dir, receipt)
        bundle = self.lab.root / 'non_target.zip'
        with zipfile.ZipFile(bundle, 'w') as z:
            z.writestr('tickstore_publisher_recovery_v004.py', b'# not a target bundle')
        return O(), bundle

    def test_30_pin_verifies_frozen_bytes_and_release_is_idempotent(self):
        release = A.pin_frozen_launch_sources(self.successor())
        release()
        release()

    def test_31_tampered_or_missing_frozen_source_blocks(self):
        for rel in ('loader/INLINE_ROOT_LOADER_V004_R1R1.ps1', 'modules/Launch-TickstoreBundle.ps1'):
            root = self.successor()
            with open(root / rel, 'ab') as f:
                f.write(b'\r\n# tamper\r\n')
            with self.assertRaisesRegex(A.AdapterBlocked, 'ADAPTER_FROZEN_LAUNCH_SOURCE_SHA:' + re.escape(rel)):
                A.pin_frozen_launch_sources(root)
            shutil.rmtree(root)
        root = self.successor()
        (root / 'loader/INLINE_ROOT_LOADER_V004_R1R1.ps1').unlink()
        with self.assertRaises(OSError):
            A.pin_frozen_launch_sources(root)

    def test_32_fallback_launch_runs_only_with_verified_pinned_sources(self):
        pkg = self.successor()
        calls = []

        def launch(*a, **k):
            if NATIVE:  # the pin is held while the frozen launcher runs
                with self.assertRaises(PermissionError):
                    open(pkg / 'loader/INLINE_ROOT_LOADER_V004_R1R1.ps1', 'r+b')
            calls.append(a)
            return 0, 'so', 'se'

        o, bundle = self.adapted(pkg, launch)
        os.environ.pop('TICKSTORE_D4_RESUME_ENABLE', None)
        self.assertEqual(o.launch(bundle, bundle, 'FULL_G3'), (0, 'so', 'se'))
        self.assertEqual(len(calls), 1)
        with open(pkg / 'loader/INLINE_ROOT_LOADER_V004_R1R1.ps1', 'ab') as f:
            f.write(b'\r\n# swapped after first launch\r\n')
        with self.assertRaisesRegex(A.AdapterBlocked, 'ADAPTER_FROZEN_LAUNCH_SOURCE_SHA'):
            o.launch(bundle, bundle, 'FULL_G3')
        self.assertEqual(len(calls), 1)

    def test_33_async_fallback_releases_only_after_child_exit(self):
        pkg = self.successor()
        released = threading.Event()
        exited = threading.Event()
        real = A.pin_frozen_launch_sources

        def recording(root):
            inner = real(root)

            def release():
                inner()
                released.set()
            return release

        class Child:
            def wait(self):
                exited.wait(30)
                return 0

        A.pin_frozen_launch_sources = recording
        try:
            o, bundle = self.adapted(pkg, lambda *a, **k: (Child(), None, None, 'so', 'se'))
            os.environ.pop('TICKSTORE_D4_RESUME_ENABLE', None)
            result = o.launch(bundle, bundle, 'FULL_G3', async_=True)
            self.assertIsInstance(result[0], Child)
            self.assertFalse(released.wait(0.5))
            exited.set()
            self.assertTrue(released.wait(10))
        finally:
            A.pin_frozen_launch_sources = real

    @unittest.skipUnless(NATIVE, 'Windows share-mode pin (G0)')
    def test_34_native_pin_denies_write_rename_delete(self):
        pkg = self.successor()
        loader = pkg / 'loader/INLINE_ROOT_LOADER_V004_R1R1.ps1'
        other = pkg / 'other.ps1'
        other.write_bytes(b'# other')
        release = A.pin_frozen_launch_sources(pkg)
        try:
            with self.assertRaises(PermissionError):
                open(loader, 'r+b')
            with self.assertRaises(PermissionError):
                os.replace(other, loader)
            with self.assertRaises(PermissionError):
                os.remove(loader)
        finally:
            release()
        with open(loader, 'r+b'):
            pass

    @unittest.skipUnless(NATIVE, 'Windows PS 5.1 frozen launcher (G0)')
    def test_35_native_frozen_launcher_hashes_and_executes_loader_under_pin(self):
        pkg = self.successor()
        anchor = self.lab.root / 'anchor.json'
        anchor.write_text('{}')
        bundle = self.lab.root / 'bundle.zip'
        bundle.write_bytes(b'')
        ps = Path(os.environ['SystemRoot']) / 'System32/WindowsPowerShell/v1.0/powershell.exe'
        release = A.pin_frozen_launch_sources(pkg)
        try:
            r = subprocess.run([str(ps), '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File',
                                str(pkg / 'modules/Launch-TickstoreBundle.ps1'), '-PackageRoot', str(pkg),
                                '-BundlePath', str(bundle), '-AnchorPath', str(anchor), '-PythonPath', sys.executable],
                               capture_output=True, text=True, timeout=300)
        finally:
            release()
        out = r.stdout + r.stderr
        self.assertNotEqual(r.returncode, 0)
        self.assertIn('ANCHOR_HASH_REQUIRED', out)  # loader hashed, re-read and executed while pinned
        self.assertNotIn('ROOT_LOADER_HASH_MISMATCH', out)
        self.assertNotIn('being used by another process', out)


class F01DeclarationsBound(unittest.TestCase):
    def test_40_consumer_review_truthful_and_bound(self):
        catalog = json.loads((C / 'g5proof/PRE_G06_CONSUMER_REVIEW.json').read_bytes())
        self.assertEqual(len(catalog['consumers']), 11)
        for rel, row in catalog['consumers'].items():
            self.assertEqual(row['source_sha256'], sha((C / rel).read_bytes()), rel)
        orch = catalog['consumers']['recovery/modules/orchestrator.py']
        self.assertNotIn('no production execute/main invocation', json.dumps(orch))
        self.assertIn('LEGACY_ENTRY_FENCE', orch['negative_guard'])

    def test_41_bindings_match_bytes(self):
        binding = json.loads((C / 'adapter/RUNTIME_LOCATOR_ADAPTER_BINDING.json').read_bytes())
        for key, name in (('adapter_sha256', 'runtime_locator_adapter.py'), ('orchestrator_entry_sha256', 'runtime_locator_orchestrator_entry.py'),
                          ('inline_entry_sha256', 'runtime_locator_inline_entry.py'),
                          ('adapted_loader_sha256', 'INLINE_ROOT_LOADER_V004_R1R1_ADAPTER.ps1'),
                          ('adapted_launch_sha256', 'Launch-TickstoreBundle-Adapter.ps1')):
            self.assertEqual(binding[key], sha((C / 'adapter' / name).read_bytes()), key)
        first = json.loads((C / 'control/FIRST_ADMISSION_BINDING.json').read_bytes())
        self.assertEqual(first['adapter_sha256'], binding['adapter_sha256'])
        self.assertEqual(first['runtime_binding_sha256'], sha((C / 'adapter/RUNTIME_LOCATOR_ADAPTER_BINDING.json').read_bytes()))
        for key, rel in (('bootstrap_sha256', 'control/D4_FIRST_ADMISSION_BOOTSTRAP.py'), ('transaction_sha256', 'control/D4_FIRST_ADMISSION_TRANSACTION.py'),
                         ('preparation_sha256', 'control/D4_FIRST_ADMISSION_PREP.py'), ('wrapper_sha256', 'control/60_EFFECTFUL_WRAPPER_RELEASE.ps1')):
            self.assertEqual(first[key], sha((C / rel).read_bytes()), key)

    def test_42_frozen_successor_package_untouched_and_self_consistent(self):
        for rel, digest in FROZEN.items():
            self.assertEqual(sha((C / rel).read_bytes()), digest, rel)
        cfg = json.loads(CONFIG.read_bytes())
        self.assertEqual(cfg['master_ps1_sha256'], FROZEN['recovery/TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1'])
        self.assertEqual(cfg['launch_tickstore_bundle_sha256'], FROZEN['recovery/modules/Launch-TickstoreBundle.ps1'])
        self.assertEqual(cfg['orchestrator_py_sha256'], FROZEN['recovery/modules/orchestrator.py'])
        self.assertEqual(dict(A.FROZEN_LAUNCH_SOURCES), {
            'modules/Launch-TickstoreBundle.ps1': FROZEN['recovery/modules/Launch-TickstoreBundle.ps1'],
            'loader/INLINE_ROOT_LOADER_V004_R1R1.ps1': FROZEN['recovery/loader/INLINE_ROOT_LOADER_V004_R1R1.ps1']})


if __name__ == '__main__':
    unittest.main(verbosity=2)
