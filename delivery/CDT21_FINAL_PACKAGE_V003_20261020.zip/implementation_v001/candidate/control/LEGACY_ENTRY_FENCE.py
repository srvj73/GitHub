"""TICKSTORE CDT21 F-01 - legacy entry fence for the frozen V004R1 orchestrator.

Explicit tool, never invoked by the frozen code.  Default is a read-only DIAGNOSE;
--apply installs the fence under the same process-lifetime boundary that a D4
entry holds (so no live entry can race) and never removes it.

Why it closes the legacy route: the frozen orchestrator (recovery/modules/orchestrator.py,
any deployed copy, started by TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1 or by
`python orchestrator.py <command>`) builds State(control_root) before anything else,
and the frozen State.__init__ always publishes STATE through atom(): it opens
"STATE.json.partial" for writing and then os.replace()s it onto STATE.json.  A
directory at that exact name makes that first write raise before any byte of
STATE, journal, inbox or runs changes: STATE is neither created (missing),
rewritten (present) nor reset (orphan journal), and plan/status/run/resume/stop/
reconcile/confirm-stale-lock/ingest-stage-b/postfull/attach all stop there.
Admitted writers never use that name (their STATE commits are the CAS of
runtime_locator_orchestrator_entry), which require this fence before admission
(require_legacy_entry_fence).

Decision table:
  F0 fence present and valid                       -> FENCE_PRESENT (nothing written)
  F1 nothing at the fence name, sound state dir    -> FENCE_ABSENT_INSTALLABLE; --apply: mkdir fence,
                                                      create-new marker, fsync file+dirs, verify
  F2 anything else (a regular file at that name = an interrupted frozen write, a directory
     without a valid marker, links/reparse points, missing state dir) -> BLOCKED_MANUAL (no write)
STATE and STATE_JOURNAL.jsonl are only read; their versions are compared before and after.

Usage: python -B -I LEGACY_ENTRY_FENCE.py --state <...\\state\\STATE.json> [--adapter-dir <adapter dir>] [--apply]
Exit code: 0 when the fence is present (or was just installed and verified), 2 otherwise.
"""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys

SCHEMA = "TICKSTORE_LEGACY_ENTRY_FENCE_REPORT_V001"
RULE = ("frozen State.__init__ -> atom(STATE.json) -> open(STATE.json.partial, 'wb') is denied by this "
        "directory; admitted CAS commits never use this name")


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def load_entry(adapter_dir):
    p = Path(adapter_dir) / "runtime_locator_orchestrator_entry.py"
    spec = importlib.util.spec_from_file_location("tickstore_legacy_fence_entry", p)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _version(path):
    """Identity and digest of a regular file, or None when absent; links and reparse points refused."""
    try:
        before = os.lstat(path)
    except FileNotFoundError:
        return None
    if not stat.S_ISREG(before.st_mode) or getattr(before, "st_file_attributes", 0) & 0x400:
        raise RuntimeError("LEGACY_FENCE_NOT_REGULAR:" + Path(path).name)
    with open(path, "rb") as f:
        raw = f.read()
        opened = os.fstat(f.fileno())
    after = os.lstat(path)
    ident = [after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns]
    if [opened.st_dev, opened.st_ino, opened.st_size, opened.st_mtime_ns] != ident or len(raw) != after.st_size:
        raise RuntimeError("LEGACY_FENCE_EVIDENCE_CHANGED")
    return {"identity": ident, "sha256": sha(raw), "bytes": len(raw)}


def diagnose(state_path: Path, entry):
    state_path = Path(state_path)
    fence = entry.legacy_entry_fence_path(state_path)
    rep = {"schema": SCHEMA, "state": str(state_path), "fence": str(fence), "decision": "BLOCKED_MANUAL", "reasons": []}
    try:
        entry.require_no_link_chain(state_path.parent, "LEGACY_FENCE_STATE_DIR")
        if not stat.S_ISDIR(os.lstat(state_path.parent).st_mode):
            raise RuntimeError("LEGACY_FENCE_STATE_DIR_NOT_DIRECTORY")
        rep["state_version"] = _version(state_path)
        rep["journal_version"] = _version(state_path.with_name("STATE_JOURNAL.jsonl"))
        if not os.path.lexists(fence):
            rep["decision"] = "FENCE_ABSENT_INSTALLABLE"
            return rep
        st = os.lstat(fence)
        if stat.S_ISREG(st.st_mode) and not getattr(st, "st_file_attributes", 0) & 0x400:
            rep["reasons"].append("LEGACY_PARTIAL_DEBRIS_PRESENT")
            rep["partial_debris"] = _version(fence)
            return rep
        entry.require_legacy_entry_fence(state_path)
        rep["decision"] = "FENCE_PRESENT"
        return rep
    except (OSError, RuntimeError) as exc:
        rep["reasons"].append(str(exc))
        return rep


def _comparable(rep):
    return {k: v for k, v in rep.items() if k != "applied_utc"}


def apply(state_path: Path, rep, entry, tool_raw, entry_raw):
    if rep.get("decision") != "FENCE_ABSENT_INSTALLABLE":
        return rep
    state_path = Path(state_path)
    fence = entry.legacy_entry_fence_path(state_path)
    release = entry.acquire_state_boundary(state_path)  # no live D4 entry may hold this STATE
    try:
        again = diagnose(state_path, entry)
        if _comparable(again) != _comparable(rep):
            raise RuntimeError("LEGACY_FENCE_EVIDENCE_CHANGED")
        os.mkdir(fence)  # never exist_ok: a concurrent creation is not adopted
        marker = {"schema": entry.LEGACY_ENTRY_FENCE_SCHEMA, "state_name": state_path.name, "fence_name": fence.name,
                  "rule": RULE, "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  "tool_sha256": sha(tool_raw), "entry_sha256": sha(entry_raw),
                  "state_version_at_install": rep["state_version"], "journal_version_at_install": rep["journal_version"]}
        with open(fence / entry.LEGACY_ENTRY_FENCE_MARKER, "xb") as f:
            f.write((json.dumps(marker, indent=1, sort_keys=True) + "\n").encode("ascii"))
            f.flush()
            os.fsync(f.fileno())
        entry._fsync_directory(fence)
        entry._fsync_directory(state_path.parent)
        entry.require_legacy_entry_fence(state_path)
        try:
            with open(fence, "wb"):
                pass
            frozen_write_denied = False
        except OSError:
            frozen_write_denied = True
        if not frozen_write_denied:
            raise RuntimeError("LEGACY_FENCE_DOES_NOT_DENY_FROZEN_WRITE")
        after = diagnose(state_path, entry)
        if (after["decision"] != "FENCE_PRESENT" or after.get("state_version") != rep["state_version"]
                or after.get("journal_version") != rep["journal_version"]):
            raise RuntimeError("LEGACY_FENCE_STATE_OR_JOURNAL_CHANGED")
        result = dict(after)
        result.update(applied=True, applied_utc=marker["created_utc"], frozen_write_denied=True,
                      marker_sha256=sha((fence / entry.LEGACY_ENTRY_FENCE_MARKER).read_bytes()))
        return result
    finally:
        release()


def main(argv=None):
    ap = argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument("--state", required=True)
    ap.add_argument("--adapter-dir", default=str(Path(__file__).resolve().parent.parent / "adapter"))
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args(argv)
    entry_path = Path(a.adapter_dir) / "runtime_locator_orchestrator_entry.py"
    entry = load_entry(a.adapter_dir)
    state_path = Path(a.state)
    rep = diagnose(state_path, entry)
    if a.apply:
        try:
            rep = apply(state_path, rep, entry, Path(__file__).read_bytes(), entry_path.read_bytes())
        except (OSError, RuntimeError) as exc:
            rep = {"schema": SCHEMA, "state": str(state_path), "decision": "BLOCKED_MANUAL", "reasons": [str(exc)]}
    print(json.dumps(rep, indent=2, sort_keys=True, default=str))
    return 0 if rep.get("decision") == "FENCE_PRESENT" else 2


if __name__ == "__main__":
    raise SystemExit(main())
