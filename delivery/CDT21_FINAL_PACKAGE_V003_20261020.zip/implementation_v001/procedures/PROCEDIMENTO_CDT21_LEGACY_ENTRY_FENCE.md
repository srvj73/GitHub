# Procedimento CDT21 — cerca de entrada legada (F-01)

**Status:** não executado. Requer autorização expressa da origem, porque escreve um diretório e um arquivo no `control_root` produtivo. Não altera STATE nem journal.

## Quando

Uma única vez, antes da primeira admissão D4 ou de qualquer continuação oficial com o candidato V003. Sem a cerca, a cadeia oficial falha fechada com `LEGACY_ENTRY_FENCE_MISSING`.

## Como

Em PowerShell 5.1 **elevado**, a partir de `C:\Users\silvi`, com o Python fixado e o diretório `adapter` instalado do V003:

```
& 'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe' -I -B <V003>\implementation_v001\candidate\control\LEGACY_ENTRY_FENCE.py --state 'D:\Base CSV\Scripts\TICKSTORE_R9_DEV\WORK_R9_PUBLISHER_RECOVERY_V004R1R1\ORCHESTRATOR_V001R9R1_B6_R8_PROVENANCE_VSS_SCOPE_FIX\state\STATE.json' --adapter-dir <V003>\implementation_v001\candidate\adapter
```

1. Execute primeiro **sem** `--apply` (diagnóstico somente leitura).
   - Esperado: `FENCE_ABSENT_INSTALLABLE`, exit 2.
2. Execute novamente **com** `--apply`.
   - Esperado: `FENCE_PRESENT`, `applied=true`, `frozen_write_denied=true`, exit 0.
   - `state_version` e `journal_version` devem ser idênticos antes e depois.
3. Guarde a saída JSON e o arquivo `state\STATE.json.partial\LEGACY_ENTRY_FENCE.json` como recibo.

## Bloqueios previstos (nenhuma escrita)

| Resultado | Situação |
|---|---|
| `LEGACY_PARTIAL_DEBRIS_PRESENT` | Existe um arquivo `STATE.json.partial`, isto é, uma escrita congelada interrompida. Exige diagnóstico manual. |
| `LINK_OR_REPARSE` | Há link ou reparse na cadeia de diretórios. |
| `ADAPTER_ENTRY_STATE_BOUNDARY_BUSY` | Há uma entrada D4 viva segurando a fronteira de STATE. |
| Marcador inválido | Diretório `STATE.json.partial` sem marcador válido. |

## Efeito comprovado

Com a cerca instalada, qualquer invocação do orquestrador congelado sai com código diferente de zero e não altera nada em `control_root`. Isso vale para o PS1 legado, para `python orchestrator.py` direto e para qualquer cópia ou comando. Comprovação: suíte `tests/test_cdt21_f01_legacy_entry_fence.py`.

A cerca nunca é removida pela ferramenta. Removê-la reabre a rota legada e faz a cadeia oficial falhar fechada.
