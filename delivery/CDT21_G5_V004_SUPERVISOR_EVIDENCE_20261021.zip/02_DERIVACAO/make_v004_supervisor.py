"""Compose the G5 V004 supervisor from the proven R2 (99704BA5...) + reviewable new sections.

Usage: python -I make_v004_supervisor.py <R2.py> <out.py>
Verbatim R2 blocks (byte-identical): Blocked..plain_directory (except make_witness issued_by), SupervisorJob,
fixture_extract_dir, check_fixture_contract, plan_keys, tree_digest, production_fingerprint, reparse_free,
path_isolation, native_b2d, volume_filesystem.  Removed: the resume mode (resume_precheck,
preserve_prior_terminal, checkpoint_consistency, prior_processes_dead, lock_probe).  New: constants for V004,
foreign_roots, commits_bound, final_checkpoints, qualify_main, require_qualification, main.
"""
import hashlib
import sys
from pathlib import Path

R2_SHA = '99704BA5965294204D6FE1BBD348C423EA70204B5C104D4D19C5150217F1C0CC'
src, out = Path(sys.argv[1]), Path(sys.argv[2])
raw = src.read_bytes()
assert hashlib.sha256(raw).hexdigest().upper() == R2_SHA, 'R2_SHA'
L = raw.decode('utf-8').split('\n')


def block(first, last):
    """R2 lines first..last (1-based, inclusive), verbatim."""
    return '\n'.join(L[first - 1:last])


def expect(first, text):
    assert L[first - 1].startswith(text), (first, L[first - 1], text)


expect(24, 'from __future__ import annotations'); expect(37, 'import zipfile')
expect(65, 'class Blocked'); expect(170, 'def make_owner'); expect(175, 'def plain_directory')
expect(162, 'def make_witness'); expect(181, 'def build_return'); expect(227, 'class SupervisorJob')
expect(291, 'def plan_keys'); expect(371, 'def tree_digest'); expect(414, 'def path_isolation')
expect(476, 'def native_b2d'); expect(584, 'def volume_filesystem'); expect(876, "if __name__ == '__main__':")

HEADER = '''"""CDT21 G5 V004 - native supervisor for a NEW frozen PRE_G06 campaign bound to the V004 manifest.

Origin decision (2026-10-21): the G5 of V003 stays valid for the V003 bytes only; its 38 COMMITs cannot
take the V004 identity.  This supervisor is the proven R2 (99704BA5...) adapted to V004:
  * kept byte-identical from R2: byte-exact extraction into the layout required by the frozen b2d fixture
    (%LOCALAPPDATA%/CDT21_G5_V004/CURRENT_G5_DELTA_<stamp>/EXTRACTED), the fixture contract check, the
    38-unit plan read from frozen constants, the kill-on-close Job, the read-only tree digest and
    production fingerprint of D:\\\\Base CSV, write-root isolation, the native b2d runner;
  * removed: the resume mode.  Every run creates a NEW run root and a NEW D-lab; no root, COMMIT or
    terminal receipt of another run (the V003 run included) is opened for writing or resumed;
  * added: a native qualification (Q) for a new run, required by the effectful phase (E);
    a digest of every pre-existing run root and D-lab (unchanged from Q to the end of E); refusal of any
    REUSE_COMMITTED line; the 38 COMMITs must equal the plan and be bound to the V004 package and code;
    LIVE_STATUS and R08_RETURN checkpoints consistent with them.

Executes only frozen V004 code, in this order:
  1. g5proof/PRE_G06_CAMPAIGN.py main()   (child process, all 38 planned units)
  2. g5proof/PRE_G06_COMPLETENESS.close() (five-part producer, after a PASS)
It never writes a PASS, never edits extracted bytes, never touches D:\\\\Base CSV.
B06/B07/D4/D5/canary/FULL/production: NOT_STARTED.
"""'''

CONSTANTS = '''
PACKAGE_NAME = 'CDT21_FINAL_PACKAGE_V004_20261021.zip'
PACKAGE_SHA = 'AD33486954F1248AF28A78677377E83AB979AB86EDD5F71F5B7D108CBA8F99DD'
CODE_SHA = 'D2C626FD2819B86D472433CB2B26C6688B1688E5E5474402162B67C5048666FF'
MANIFEST_SHA = 'F6225EA6720FCA558F8BBAD70B3ED46687103374873439E0FADDB4FEA9D3A813'
V003_PACKAGE_SHA = '69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50'  # never accepted
V003_CODE_SHA = 'D59BC4EE4F0D5C689335C8F478A0342CC0146930E3B0B44C707B6B95267B3953'     # never accepted
CAMPAIGN_REL = 'implementation_v001/candidate/g5proof/PRE_G06_CAMPAIGN.py'
CAMPAIGN_SHA = '347767D17C8526924D87732608CE2D0441E6989275B8E8E3D88E83F6A17FC79A'
COMPLETENESS_REL = 'implementation_v001/candidate/g5proof/PRE_G06_COMPLETENESS.py'
COMPLETENESS_SHA = '15B10B107DBD29FE497F24A0D5AE100EFAEBD5A183BA6E9905C4AF7D43A72068'
REVIEW_NAME = 'CDT19_IMPLEMENTER_SOURCE_REVIEW_V004.json'
WITNESS_NAME = 'CDT19_R08Q1_ENGINEERING_WITNESS.json'
RUN_PARENT = 'CDT20_R08'                       # G5_MULTIWORK_SCENARIOS lab_base
D_LABS = 'D:\\\\TICKSTORE_CDT19_PRE_G06_LABS'    # PRE_G06_CAMPAIGN CROSS_VOLUME_OWNED_LAB
PRODUCTION = 'D:\\\\Base CSV'
PLANNED_UNITS = 38
RUN_NAME = re.compile(r'R08_Q1_[0-9]{14}_[0-9a-f]{12}')
RESULT_SCHEMA = 'CDT21_G5_V004_SUPERVISOR_RESULT_V001'
B2D_TEST_REL = 'implementation_v001/tests/test_b2d_origin_decision_binder.py'
B2D_TEST_SHA = 'D19EF3BA870D4065CFDF6C39B35EEB8D24CE9FAEF171E2C6806D9C4E7708DAA0'
EXTRACT_HOME = 'CDT21_G5_V004'
DELTA_PREFIX = 'CURRENT_G5_DELTA_'
D_LABS_NAME = 'TICKSTORE_CDT19_PRE_G06_LABS'
QUAL_SCHEMA = 'CDT21_G5_V004_WINDOWS_QUALIFICATION_V001'
QUAL_MAX_AGE_S = 7200
SUPERVISOR_NAME = 'CDT21_G5_V004_SUPERVISOR.py'
FROZEN_LOG_ROOT = 'C:\\\\Users\\\\silvi\\\\OneDrive\\\\Downloads\\\\TICKSTORE_RUNS'  # hard-coded in frozen V004 (installer/RUN_LOG_FIXED)
'''

witness = block(162, 169)
assert witness.count("'issued_by': 'CDT21_G5_V003_SUPERVISOR'") == 1
witness = witness.replace("'issued_by': 'CDT21_G5_V003_SUPERVISOR'", "'issued_by': 'CDT21_G5_V004_SUPERVISOR'")

ret = block(181, 226)
for old, new in (("    \"\"\"Outer return. Duplicates of the V003 package and of R08_RETURN.zip are\n",
                  "    \"\"\"Outer return. Duplicates of the V004 package and of R08_RETURN.zip are\n"),
                 ("                 'OWNER.json', 'RETURN_LOCK_SCOPE.json', 'CDT21_SUPERVISOR_BOOTSTRAP.json'] + \\\n"
                  "                sorted(p.name for p in root.glob('CDT21_SUPERVISOR_RESUME_*.json')):\n",
                  "                 'OWNER.json', 'RETURN_LOCK_SCOPE.json', 'CDT21_SUPERVISOR_BOOTSTRAP.json']:\n"),
                 ("    for p, rel in ((stage / 'CDT21_G5_V003_SUPERVISOR_R2.py', 'SUPERVISOR/CDT21_G5_V003_SUPERVISOR_R2.py'),\n",
                  "    for p, rel in ((stage / SUPERVISOR_NAME, 'SUPERVISOR/' + SUPERVISOR_NAME),\n"),
                 ("        arc.writestr('RETURN_INDEX.json', encoded({'schema': 'CDT21_G5_V003_RETURN_INDEX_V001',\n",
                  "        arc.writestr('RETURN_INDEX.json', encoded({'schema': 'CDT21_G5_V004_RETURN_INDEX_V001',\n")):
    assert ret.count(old) == 1, old
    ret = ret.replace(old, new)

NEW = Path(__file__).with_name('v004_new_sections.py').read_text(encoding='utf-8')

parts = [HEADER, block(24, 37), CONSTANTS, '', block(65, 161), witness, '', block(170, 180), ret,
         block(227, 307), block(371, 430), block(476, 492), block(584, 592), '', NEW.rstrip('\n'), '', '', block(876, 878)]
text = '\n'.join(parts)
out.write_bytes(text.encode('utf-8'))
print(out, hashlib.sha256(text.encode('utf-8')).hexdigest().upper(), len(text.split('\n')))
