def owner_binding(path):
    """Read-only label of a pre-existing run root or D-lab from its OWNER.json (never opened for writing)."""
    try:
        sha = strict_json((Path(path) / 'OWNER.json').read_bytes()).get('package_sha256')
    except (OSError, ValueError, Blocked):
        return 'NO_READABLE_OWNER'
    return {PACKAGE_SHA: 'V004', V003_PACKAGE_SHA: 'V003'}.get(sha, 'OTHER')


def link_safe_digest(base):
    """Read-only digest of a foreign tree that never follows a symlink, junction or other reparse point and
    records unreadable directories by name (a leftover link or ACL of another run can neither loop nor block)."""
    base = Path(base)
    rows, stack, links, unreadable = [], [base], 0, 0
    while stack:
        d = stack.pop()
        try:
            with os.scandir(d) as it:
                entries = list(it)
        except OSError:
            rows.append((d.relative_to(base).as_posix(), -3, 0)); unreadable += 1
            continue
        for e in entries:
            rel = Path(e.path).relative_to(base).as_posix()
            try:
                st = e.stat(follow_symlinks=False)
            except OSError:
                rows.append((rel, -4, 0)); unreadable += 1
                continue
            link = e.is_symlink() or e.is_junction() or bool(getattr(st, 'st_file_attributes', 0) & 0x400)
            if link:
                rows.append((rel, -2, st.st_mtime_ns)); links += 1
            elif e.is_dir(follow_symlinks=False):
                rows.append((rel, -1, st.st_mtime_ns)); stack.append(Path(e.path))
            else:
                rows.append((rel, st.st_size, st.st_mtime_ns))
    rows.sort()
    return {'exists': True, 'entries': len(rows), 'links_not_followed': links, 'unreadable_dirs': unreadable,
            'sha256': sha_bytes(json.dumps(rows).encode())}


def foreign_roots(local):
    """Read-only digest of every pre-existing run root and D-lab (the V003 runs included).

    A new campaign may add exactly its own run root and D-lab; nothing that existed before Q may change."""
    out = {}
    for label, parent in (('run', Path(local) / RUN_PARENT), ('d_lab', Path(D_LABS))):
        if os.path.lexists(parent):
            plain_directory(parent)
            with os.scandir(parent) as it:
                entries = sorted(it, key=lambda x: x.name)
            for e in entries:
                if e.is_dir(follow_symlinks=False) and not e.is_symlink() and not e.is_junction():
                    out[label + '/' + e.name] = dict(link_safe_digest(Path(e.path)), owner=owner_binding(e.path))
                else:
                    out[label + '/' + e.name] = {'not_a_directory': True, 'size': e.stat(follow_symlinks=False).st_size}
    return out


def foreign_unchanged(before, after, run_id):
    changed = sorted(k for k in before if after.get(k) != before[k])
    added = sorted(k for k in after if k not in before)
    require(not changed, 'FOREIGN_ROOT_CHANGED:' + ','.join(changed))
    require(added == ['d_lab/' + run_id, 'run/' + run_id], 'FOREIGN_ROOT_ADDED:' + ','.join(added))
    return {'pre_existing': len(before), 'unchanged': len(before), 'added': added}


def commits_bound(root, plan):
    """The COMMITs of the new run: exactly the 38 planned keys, closed, bound to the V004 package and code."""
    keys = sorted(p.stem for p in (root / 'COMMITS').glob('*.json'))
    require(keys == sorted(plan), 'COMMIT_SET_NE_PLAN:' + str(len(keys)))
    shas = {}
    for key in keys:
        p = root / 'COMMITS' / (key + '.json')
        obj = strict_json(p.read_bytes())
        require(obj.get('package_sha256') != V003_PACKAGE_SHA and obj.get('code_sha256') != V003_CODE_SHA,
                'COMMIT_BOUND_TO_V003:' + key)
        require(obj.get('schema') == 'CDT19_NATIVE_UNIT_COMMIT_V001' and obj.get('package_sha256') == PACKAGE_SHA
                and obj.get('code_sha256') == CODE_SHA and obj.get('result', {}).get('status') == 'PASS'
                and obj['result'].get('exit_code') == 0 and obj.get('own_descendants_final') == []
                and isinstance(obj.get('artifacts'), list) and bool(obj['artifacts']), 'COMMIT_NOT_BOUND_TO_V004:' + key)
        for ref in obj['artifacts']:
            target = root.joinpath(*PurePosixPath(ref['member']).parts)
            require(target.is_file() and target.stat().st_size == ref['bytes'] and sha_file(target) == ref['sha256'],
                    'COMMIT_ARTIFACT_DRIFT:' + key + ':' + ref['member'])
        shas[key] = sha_file(p)
    return shas


def final_checkpoints(root, plan):
    """Terminal receipts of the new run agree with its COMMITs (read-only)."""
    live = strict_json((root / 'LIVE_STATUS.json').read_bytes())
    require(sorted(live.get('commit_receipt_keys', [])) == sorted(plan), 'LIVE_STATUS_COMMIT_KEYS')
    require(live.get('status') == 'PASS_NATIVE_INTEGRATED_PRE_B06', 'LIVE_STATUS_NOT_PASS')
    recorded = (root / 'R08_RETURN.sha256').read_text(encoding='ascii').split()[0]
    require(recorded == sha_file(root / 'R08_RETURN.zip'), 'R08_RETURN_SHA_FILE')
    require(strict_json((root / 'RETURN_LOCK_SCOPE.json').read_bytes()).get('run_id') == root.name, 'RETURN_LOCK_SCOPE_RUN')
    require(not (root / 'R08_RETURN.zip.partial').exists(), 'R08_RETURN_PARTIAL_LEFT')
    ia = root / 'INTERRUPTED_ATTEMPTS'
    return {'live_status_keys_equal_plan': True, 'r08_return_sha256': recorded,
            'interrupted_attempts': sorted(p.name for p in ia.iterdir()) if ia.is_dir() else []}


def qualify_main(a):
    """Native Windows qualification before any effect: no run root and no D-lab are created here."""
    global _console
    log_dir = Path(os.path.abspath(a.log_dir)); stage = Path(os.path.abspath(a.stage))
    started = time.time()
    q = {'schema': QUAL_SCHEMA, 'status': 'BLOCKED', 'supervisor_sha256': sha_file(__file__), 'candidate_sha256': PACKAGE_SHA,
         'code_manifest_sha256': CODE_SHA, 'log_dir': str(log_dir), 'mode': 'NEW_RUN_V004', 'checks': {}, 'blockers': [],
         'effects': 'EXTRACT_HOME_QUALIFICATION_COPIES_AND_LOG_DIR_ONLY', 'b06': 'NOT_STARTED'}
    def ok(k, v, d=''):
        q['checks'][k] = {'status': 'PASS' if v else 'FAIL', 'detail': d}
        require(v, 'QUAL_' + k + ':' + str(d)[:200])
    code = 2
    try:
        _console = open(stage / 'SUPERVISOR_CONSOLE_QUALIFY.log', 'xb')
        emit('QUALIFY SUPERVISOR=' + str(Path(__file__)) + ' SHA256=' + q['supervisor_sha256'])
        ok('windows_python_admin', os.name == 'nt' and sys.version_info[:2] == (3, 14), sys.version.split()[0])
        import ctypes
        ok('elevated', bool(ctypes.WinDLL('shell32').IsUserAnAdmin()))
        package = Path(os.path.abspath(a.package))
        ok('package_sha_v004', package.is_file() and sha_file(package) == PACKAGE_SHA and PACKAGE_SHA != V003_PACKAGE_SHA)
        review_raw = Path(a.review).read_bytes(); validate_review(review_raw); ok('source_review_binding', True, sha_bytes(review_raw))
        local = os.environ.get('LOCALAPPDATA', '')
        ok('localappdata_canonical', bool(local) and '%' not in local and '~' not in local
           and os.path.normcase(os.path.realpath(local)) == os.path.normcase(os.path.abspath(local)), local)
        ok('run_root_not_on_d', Path(local).drive.upper() != 'D:', local)
        ok('volumes_ntfs', volume_filesystem(Path(local).drive + '\\') == 'NTFS' and volume_filesystem('D:\\') == 'NTFS')
        ok('free_space', shutil.disk_usage(Path(local).drive + '\\').free >= 4 * 1024**3 and shutil.disk_usage('D:\\').free >= 1024**3)
        job = SupervisorJob(); ok('job_kill_on_close_nested', job.active() >= 1, job.active())
        prod_before = production_fingerprint(); q['production_fingerprint'] = prod_before
        foreign = foreign_roots(local); q['foreign_roots'] = foreign
        q['foreign_roots_by_owner'] = {k: v.get('owner') for k, v in foreign.items()}
        ok('foreign_roots_recorded_read_only', True, len(foreign))
        stamp = time.strftime('%Y%m%d%H%M%S') + '_' + uuid.uuid4().hex[:6]; q['stamp'] = stamp
        home = Path(local) / EXTRACT_HOME
        home.mkdir(exist_ok=True); plain_directory(home)
        ext = home / (DELTA_PREFIX + 'QUAL_' + stamp) / 'EXTRACTED'
        ext.parent.mkdir()
        extract_package(package, ext); check_fixture_contract(ext)
        ok('package_manifest_and_frozen_sources', sha_file(ext / 'PACKAGE_MANIFEST.json') == MANIFEST_SHA
           and sha_file(ext / CAMPAIGN_REL) == CAMPAIGN_SHA and sha_file(ext / COMPLETENESS_REL) == COMPLETENESS_SHA)
        plan = plan_keys(ext); q['plan'] = plan
        ok('plan_38_from_frozen_constants', len(plan) == PLANNED_UNITS and len(set(plan)) == PLANNED_UNITS, len(plan))
        import PRE_G06_CAMPAIGN as campaign
        code_sha, _ = campaign.verify_package(package)
        ok('frozen_verify_package_fixed_layout', code_sha == CODE_SHA, str(ext))
        roots = {'run_parent': (Path(local) / RUN_PARENT, True), 'd_labs': (Path(D_LABS), True), 'extract_home': (home, True),
                 'stage': (stage, True), 'log_dir': (log_dir, True), 'frozen_log_root': (Path(FROZEN_LOG_ROOT), False)}
        q['write_roots'] = path_isolation(roots)
        ok('write_roots_isolated', all(r['status'] != 'FAIL' for r in q['write_roots'].values()),
           [k for k, r in q['write_roots'].items() if r['status'] == 'FAIL'])
        qtemp = ext.parent / 'QTEMP'; qtemp.mkdir()
        q['b2d_native_positive'] = native_b2d(ext, qtemp, log_dir / 'B2D_NATIVE_FIXED_LAYOUT.log')
        p = q['b2d_native_positive']
        ok('b2d_native_fixed_layout_29_ok', p['exit'] == 0 and p['ran'] == 29 and p['ok'] and p['contract_not_met'] == 0, p)
        neg = home / ('QUAL_NEG_' + stamp) / 'R08_Q1_00000000000000_000000000000' / 'PACKAGED'
        neg.parent.mkdir(parents=True); extract_package(package, neg)
        ntemp = neg.parent / 'QTEMP'; ntemp.mkdir()
        q['b2d_native_negative_r1_layout'] = native_b2d(neg, ntemp, log_dir / 'B2D_NATIVE_R1_LAYOUT.log')
        n = q['b2d_native_negative_r1_layout']
        ok('b2d_native_r1_layout_reproduces_failure', n['exit'] != 0 and n['ran'] == 29 and n['contract_not_met'] >= 29, n)
        ok('q_no_effect_on_foreign_roots', foreign_roots(local) == foreign)
        ok('production_unchanged_during_q', production_fingerprint() == prod_before)
        q['status'] = 'PASS_WINDOWS_QUALIFICATION'; code = 0
        emit('WINDOWS_QUALIFICATION=PASS CHECKS=' + str(len(q['checks'])) + ' FOREIGN_ROOTS=' + str(len(foreign)))
    except BaseException as exc:
        q['blockers'].append(type(exc).__name__ + ':' + str(exc)); q['traceback'] = traceback.format_exc()
        emit('WINDOWS_QUALIFICATION_BLOCKED=' + q['blockers'][-1])
    finally:
        q['finished_epoch'] = time.time(); q['seconds'] = round(time.time() - started, 3)
        (log_dir / 'QUALIFICATION_RESULT.json').write_bytes(
            (json.dumps(q, sort_keys=True, indent=1, ensure_ascii=True) + '\n').encode('ascii'))
        emit('QUALIFICATION_RESULT=' + str(log_dir / 'QUALIFICATION_RESULT.json') + ' SHA256=' +
             sha_file(log_dir / 'QUALIFICATION_RESULT.json') + ' EXIT_CODE=' + str(code))
        if _console is not None:
            _console.close(); _console = None
    return code


def require_qualification(path, log_dir):
    """A new run is admitted only after a PASS native qualification of these exact bytes and this log dir."""
    q = strict_json(Path(path).read_bytes())
    require(q.get('schema') == QUAL_SCHEMA and q.get('status') == 'PASS_WINDOWS_QUALIFICATION', 'QUALIFICATION_NOT_PASS')
    require(q.get('supervisor_sha256') == sha_file(__file__), 'QUALIFICATION_OTHER_SUPERVISOR')
    require(q.get('log_dir') == str(log_dir) and q.get('mode') == 'NEW_RUN_V004', 'QUALIFICATION_OTHER_RUN')
    require(0 <= time.time() - float(q.get('finished_epoch', 0)) <= QUAL_MAX_AGE_S, 'QUALIFICATION_STALE')
    return {'qualification_sha256': sha_file(path), 'checks': len(q['checks']), 'production_fingerprint': q['production_fingerprint'],
            'foreign_roots': q['foreign_roots']}


def main(argv=None):
    global _console
    ap = argparse.ArgumentParser(allow_abbrev=False)
    for name in ('package', 'review', 'log-dir', 'stage'):
        ap.add_argument('--' + name, required=True)
    ap.add_argument('--qualify-only', action='store_true')
    ap.add_argument('--require-qualification', default='')
    a = ap.parse_args(argv)
    if a.qualify_only:
        return qualify_main(a)
    log_dir = Path(os.path.abspath(a.log_dir)); stage = Path(os.path.abspath(a.stage))
    result = {'schema': RESULT_SCHEMA, 'status': 'BLOCKED', 'exit_code': 2, 'phase': 'PREFLIGHT',
              'candidate_sha256': PACKAGE_SHA, 'code_manifest_sha256': CODE_SHA,
              'supervisor_sha256': sha_file(__file__), 'planned_units': PLANNED_UNITS, 'mode': 'NEW_RUN_V004',
              'v003_evidence': 'PRESERVED_NOT_REUSED_NOT_RELABELED', 'v003_commits_reused': 0, 'production_modified': False,
              'b06': 'NOT_STARTED', 'b07': 'NOT_STARTED', 'd4_d5': 'NOT_STARTED', 'canary': 'NOT_STARTED',
              'full': 'NOT_STARTED', 'physical_powerloss': 'NOT_TESTED_PHYSICAL_POWERLOSS',
              'g5_decision': 'NEW_NATIVE_G5_REQUIRED_BY_ORIGIN_FOR_V004_20261021', 'blockers': []}
    stamp = time.strftime('%Y%m%d%H%M%S') + '_' + uuid.uuid4().hex[:6]
    root = None; lock = None; job = None; started = time.monotonic(); local = ''
    try:
        _console = open(stage / 'SUPERVISOR_CONSOLE.log', 'xb')
        emit('SUPERVISOR=' + str(Path(__file__)) + ' SHA256=' + result['supervisor_sha256'])
        # ---------------------------------------------------------------- preflight (no lab effects)
        require(bool(a.require_qualification), 'NEW_RUN_REQUIRES_WINDOWS_QUALIFICATION')
        require(os.name == 'nt', 'WINDOWS_REQUIRED')
        require(sys.version_info[:2] == (3, 14), 'PYTHON_3_14_REQUIRED:' + sys.version.split()[0])
        import ctypes
        require(bool(ctypes.WinDLL('shell32').IsUserAnAdmin()), 'ELEVATION_REQUIRED')
        package = Path(os.path.abspath(a.package))
        require(package.is_file() and sha_file(package) == PACKAGE_SHA, 'PACKAGE_SHA_MISMATCH')
        review_raw = Path(a.review).read_bytes(); validate_review(review_raw)
        result['source_review_sha256'] = sha_bytes(review_raw)
        local = os.environ.get('LOCALAPPDATA', '')
        require(local and '%' not in local and '~' not in local and Path(local).is_absolute(), 'LOCALAPPDATA_INVALID')
        require(os.path.normcase(os.path.realpath(local)) == os.path.normcase(os.path.abspath(local)),
                'LOCALAPPDATA_NOT_CANONICAL')
        run_parent = Path(local) / RUN_PARENT; d_labs = Path(D_LABS)
        require(Path('D:\\').is_dir(), 'D_VOLUME_REQUIRED')
        require(Path(local).drive.upper() != 'D:', 'RUN_ROOT_MUST_NOT_BE_ON_D')
        require(volume_filesystem(Path(local).drive + '\\') == 'NTFS', 'C_NTFS_REQUIRED')
        require(volume_filesystem('D:\\') == 'NTFS', 'D_NTFS_REQUIRED')
        require(shutil.disk_usage(Path(local).drive + '\\').free >= 4 * 1024**3, 'C_FREE_SPACE_4GIB')
        require(shutil.disk_usage('D:\\').free >= 1 * 1024**3, 'D_FREE_SPACE_1GIB')
        for p in (run_parent, d_labs):
            plain_directory(p)
        require(not Path(os.path.normcase(D_LABS)).is_relative_to(os.path.normcase(PRODUCTION)), 'PRODUCTION_ROOT')
        result['qualification'] = require_qualification(a.require_qualification, log_dir)
        foreign_before = foreign_roots(local)
        require(foreign_before == result['qualification']['foreign_roots'], 'FOREIGN_ROOTS_CHANGED_SINCE_QUALIFICATION')
        result['foreign_roots_before'] = len(foreign_before)
        job = SupervisorJob()
        emit('PREFLIGHT=PASS PYTHON=' + sys.version.split()[0] + ' ELEVATED=YES C_D_NTFS=YES JOB=KILL_ON_CLOSE QUALIFICATION=PASS'
             ' PRE_EXISTING_ROOTS=' + str(len(foreign_before)) + ' (somente leitura; nenhuma retomada)')
        # ---------------------------------------------------------------- owned NEW run root (lab effects only)
        result['phase'] = 'BOOTSTRAP'
        packaged = fixture_extract_dir(local, stamp)
        (packaged.parent.parent).mkdir(exist_ok=True); plain_directory(packaged.parent.parent)
        packaged.parent.mkdir()
        files = extract_package(package, packaged)
        check_fixture_contract(packaged)
        manifest_sha = sha_file(packaged / 'PACKAGE_MANIFEST.json')
        require(manifest_sha == MANIFEST_SHA, 'PACKAGE_MANIFEST_SHA')
        require(sha_file(packaged / CAMPAIGN_REL) == CAMPAIGN_SHA, 'CAMPAIGN_SOURCE_SHA')
        require(sha_file(packaged / COMPLETENESS_REL) == COMPLETENESS_SHA, 'COMPLETENESS_SOURCE_SHA')
        plan = plan_keys(packaged)
        result['extracted'] = str(packaged)
        emit('EXTRACTED=' + str(packaged) + ' FILES=' + str(files) + ' BYTE_EXACT=YES FIXTURE_LAYOUT=CURRENT_G5_DELTA_EXTRACTED')
        import msvcrt
        run_id = 'R08_Q1_' + time.strftime('%Y%m%d%H%M%S') + '_' + uuid.uuid4().hex[:12]
        require(RUN_NAME.fullmatch(run_id) is not None, 'RUN_NAME')
        require('run/' + run_id not in foreign_before and 'd_lab/' + run_id not in foreign_before, 'RUN_ID_COLLISION')
        run_parent.mkdir(exist_ok=True); plain_directory(run_parent)
        root = run_parent / run_id; root.mkdir()  # never exist_ok: no root is ever reused
        result.update(run_id=run_id, run_root=str(root))
        emit('RUN_ROOT=' + str(root) + ' (nova; nenhum COMMIT de outra execucao e reutilizado)')
        (root / 'TEMP').mkdir()
        (root / 'INPUTS').mkdir()
        inputs_pkg = root / 'INPUTS' / PACKAGE_NAME
        shutil.copyfile(package, inputs_pkg)
        require(sha_file(inputs_pkg) == PACKAGE_SHA, 'INPUT_PACKAGE_COPY')
        witness = root / 'INPUTS' / WITNESS_NAME
        write_new(witness, encoded(make_witness(run_id, manifest_sha)))
        owner_raw = encoded(make_owner(run_id))
        write_new(root / 'OWNER.json', owner_raw)
        d_labs.mkdir(exist_ok=True); plain_directory(d_labs)
        dlab = d_labs / run_id; dlab.mkdir()
        write_new(dlab / 'OWNER.json', owner_raw)
        qual_c = root / 'QUAL_C'; qual_d = dlab / 'WRITER_EFFECTFUL'
        qual_c.mkdir(); qual_d.mkdir()
        lock = open(root / 'CAMPAIGN.lock', 'x+b')
        lock.write(encoded({'schema': 'CDT21_G5_V004_CAMPAIGN_LOCK_V001', 'run_id': run_id, 'supervisor_pid': os.getpid()}))
        lock.flush(); os.fsync(lock.fileno()); lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        require(not (root / 'COMMITS').exists(), 'NEW_ROOT_HAS_COMMITS')
        bootstrap = {'schema': 'CDT21_G5_V004_SUPERVISOR_BOOTSTRAP_V001', 'run_id': run_id,
                     'package_sha256': PACKAGE_SHA, 'code_manifest_sha256': CODE_SHA,
                     'package_manifest_sha256': manifest_sha, 'campaign_source_sha256': CAMPAIGN_SHA,
                     'completeness_source_sha256': COMPLETENESS_SHA,
                     'supervisor_sha256': result['supervisor_sha256'],
                     'source_review_sha256': result['source_review_sha256'],
                     'qualification_sha256': result['qualification']['qualification_sha256'],
                     'python': sys.version, 'python_executable': sys.executable,
                     'python_sha256': sha_file(sys.executable), 'localappdata': local,
                     'd_parent': str(dlab), 'temp': str(root / 'TEMP'), 'extracted': str(packaged),
                     'qual_c_parent': str(qual_c), 'qual_d_parent': str(qual_d),
                     'campaign_lock': 'HELD_EXCLUSIVE_BYTE_RANGE', 'supervisor_pid': os.getpid(),
                     'mode': 'NEW_RUN_V004', 'v003_commits_reused': 0, 'pre_existing_roots_read_only': len(foreign_before),
                     'production_authorized': False, 'b06': 'NOT_STARTED'}
        write_new(root / 'CDT21_SUPERVISOR_BOOTSTRAP.json', encoded(bootstrap))
        result['production_fingerprint_before'] = production_fingerprint()
        require(result['production_fingerprint_before'] == result['qualification']['production_fingerprint'],
                'PRODUCTION_CHANGED_SINCE_QUALIFICATION')
        emit('D_LAB=' + str(dlab) + ' OWNER_IDENTICAL=YES WITNESS=' + str(witness))
        emit('SAFE_STOP=' + str(root / 'SAFE_STOP.request') + ' (crie este arquivo para parada segura)')
        # ---------------------------------------------------------------- frozen campaign (child)
        result['phase'] = 'CAMPAIGN'
        env = {k: v for k, v in os.environ.items() if not k.upper().startswith('PYTHON')}
        env.update(TEMP=str(root / 'TEMP'), TMP=str(root / 'TEMP'),
                   TICKSTORE_QUAL_C_PARENT=str(qual_c), TICKSTORE_QUAL_D_PARENT=str(qual_d))
        cmd = [sys.executable, '-I', '-B', str(packaged / CAMPAIGN_REL), '--run-root', str(root),
               '--package', str(inputs_pkg), '--witness', str(witness), '--d-parent', str(dlab)]
        import subprocess
        emit('NATIVE_BEGIN=PRE_G06_CAMPAIGN UNITS=' + str(PLANNED_UNITS) +
             ' ETA_BASE_S=~700-1500 (referencia nativa V003: 653 s para 33 unidades + 5 reutilizadas; nao e evidencia)')
        proc = subprocess.Popen(cmd, cwd=str(root), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        reused, committed_now = [], []
        def pump():
            for raw in iter(proc.stdout.readline, b''):
                line = raw.decode('utf-8', 'replace').rstrip('\r\n')
                if line.startswith('REUSE_COMMITTED '):
                    reused.append(line.split(' ', 1)[1])
                elif line.startswith('COMMITTED '):
                    committed_now.append(line.split(' ', 1)[1])
                emit(line)
        reader = threading.Thread(target=pump, daemon=True); reader.start()
        last = 0.0
        while proc.poll() is None:
            try:
                now = time.monotonic()
                if now >= last:
                    commits = len(list((root / 'COMMITS').glob('*.json'))) if (root / 'COMMITS').is_dir() else 0
                    emit('SUPERVISOR_HEARTBEAT OWNED_PROCESSES=' + str(job.active() - 1) +
                         ' COMMITTED_UNIT_RECEIPTS=' + str(commits) + '/' + str(PLANNED_UNITS) +
                         ' ELAPSED_S=' + str(int(now - started)) +
                         ' AS_OF=' + time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
                    last = now + 10
                time.sleep(0.5)
            except KeyboardInterrupt:
                emit('CTRL_C: aguardando o encerramento e o selo da campanha (sem matar o filho)')
        reader.join(60)
        code = proc.returncode
        result['campaign_exit_code'] = code
        result['reused_committed_units'] = sorted(reused)
        result['newly_committed_units'] = committed_now
        emit('NATIVE_END=PRE_G06_CAMPAIGN EXIT_CODE=' + str(code))
        result['production_fingerprint_after'] = production_fingerprint()
        require(result['production_fingerprint_after'] == result['production_fingerprint_before'], 'PRODUCTION_FINGERPRINT_CHANGED')
        result['foreign_roots'] = foreign_unchanged(foreign_before, foreign_roots(local), run_id)
        require(not reused, 'NEW_RUN_REUSED_A_COMMIT:' + ','.join(sorted(reused)))
        native = root / 'R08_RETURN.zip'
        require(native.is_file(), 'R08_RETURN_NOT_SEALED')
        native_sha = sha_file(native)
        recorded = (root / 'R08_RETURN.sha256').read_text(encoding='ascii').split()[0]
        require(recorded == native_sha, 'R08_RETURN_SHA_FILE_MISMATCH')
        result['native_return_sha256'] = native_sha
        engineering = strict_json((root / 'ENGINEERING_RESULT.json').read_bytes())
        result['campaign_status'] = engineering.get('status')
        if code == 130 or engineering.get('status') == 'SAFE_STOP':
            result.update(status='SAFE_STOP', exit_code=130)
            raise Blocked('CAMPAIGN_SAFE_STOP')
        require(code == 0 and engineering.get('status') == 'PASS_NATIVE_INTEGRATED_PRE_B06'
                and engineering.get('final_zip_sha256') == PACKAGE_SHA
                and engineering.get('code_manifest_sha256') == CODE_SHA, 'CAMPAIGN_NOT_PASS:' +
                str(engineering.get('status')) + ':' + repr(engineering.get('blockers')))
        require(sorted(committed_now) == sorted(plan), 'COMMITTED_NOW_NE_PLAN:' + str(len(committed_now)))
        result['commit_file_sha256'] = commits_bound(root, plan)
        result['checkpoints'] = final_checkpoints(root, plan)
        # ---------------------------------------------------------------- frozen five-part closure
        result['phase'] = 'FIVE_PART_CLOSE'
        verify_extract(package, packaged)
        review = root / 'SOURCE_REVIEW' / REVIEW_NAME
        review.parent.mkdir()
        write_new(review, review_raw)
        os.environ.update(TEMP=str(root / 'TEMP'), TMP=str(root / 'TEMP'))
        for folder in ('full', 'control', 'adapter', 'g5proof'):  # same import roots as PRE_G06_CAMPAIGN
            p = str(packaged / 'implementation_v001/candidate' / folder)
            if p not in sys.path:
                sys.path.insert(0, p)
        import PRE_G06_COMPLETENESS as completeness
        require(Path(completeness.__file__).resolve() == (packaged / COMPLETENESS_REL).resolve(), 'COMPLETENESS_IMPORT_PATH')
        closed = completeness.close(str(inputs_pkg), str(native), str(review), str(root))
        require(closed.get('engineering_five_part_completeness') == 'PASS'
                and closed.get('four_pre_b06_findings') == 'PASS_NATIVE_REGRESSION'
                and closed.get('independent_b06_audit') is False, 'FIVE_PART_NOT_PASS')
        comp_path = root / 'FINAL_G5' / 'ENGINEERING_COMPLETENESS.json'
        comp = strict_json(comp_path.read_bytes())
        require(comp.get('code_manifest_sha256') == CODE_SHA and comp.get('final_package_sha256') == PACKAGE_SHA,
                'COMPLETENESS_BINDING')
        result['five_part'] = {k: {'status': v.get('status'), 'sha256': v.get('sha256')}
                               for k, v in sorted(comp['five_part_completeness'].items())}
        result['engineering_completeness_sha256'] = sha_file(comp_path)
        result['final_engineering_status_sha256'] = sha_file(root / 'FINAL_G5' / 'FINAL_ENGINEERING_STATUS.json')
        result['four_pre_b06_findings_sha256'] = sha_file(root / 'FINAL_G5' / 'FOUR_PRE_B06_FINDINGS.json')
        result['final_engineering_status'] = closed.get('status')
        result['foreign_roots_after_close'] = foreign_unchanged(foreign_before, foreign_roots(local), run_id)
        result['production_fingerprint_after_close'] = production_fingerprint()
        require(result['production_fingerprint_after_close'] == result['production_fingerprint_before'],
                'PRODUCTION_FINGERPRINT_CHANGED_AT_CLOSE')
        result.update(status='PASS_NATIVE_V004_G5_TECHNICAL_FIVE_PART', exit_code=0, phase='DONE')
        emit('ENGINEERING_FIVE_PART_COMPLETENESS=PASS FOUR_PRE_B06_FINDINGS=PASS_NATIVE_REGRESSION B06=NOT_STARTED')
    except BaseException as exc:
        if result['status'] != 'SAFE_STOP':
            result['exit_code'] = {'PREFLIGHT': 2, 'BOOTSTRAP': 2, 'CAMPAIGN': 3, 'FIVE_PART_CLOSE': 4}.get(result['phase'], 2)
        result['blockers'].append(type(exc).__name__ + ':' + str(exc))
        result['traceback'] = traceback.format_exc()
        if root is not None:
            result['partial_effect_scope'] = 'RUN_OWNED_LAB_ONLY'
        emit('SUPERVISOR_BLOCKED=' + result['blockers'][-1])
        emit('PRIMARY_TRACEBACK_BEGIN\n' + result['traceback'] + 'PRIMARY_TRACEBACK_END')
    finally:
        if job is not None:
            result['owned_processes_at_end'] = job.active() - 1
            if result['owned_processes_at_end'] != 0 and result['exit_code'] == 0:
                result.update(status='BLOCKED', exit_code=3)
                result['blockers'].append('SUPERVISOR_OWNED_ORPHANS:' + str(result['owned_processes_at_end']))
        if lock is not None:
            lock.close()  # releases the byte-range lock after the child exited
        result['seconds'] = round(time.monotonic() - started, 3)
        if root is not None:
            try:
                ret = log_dir / 'CDT21_G5_V004_RETURN.zip'
                excluded = build_return(root, stage, ret, PACKAGE_SHA, result.get('native_return_sha256'))
                result['return_zip'] = str(ret); result['return_sha256'] = sha_file(ret)
                result['return_excluded_duplicates'] = excluded
                if result['exit_code'] == 0:
                    require(all(e['equal'] for e in excluded) and len(excluded) == 2, 'RETURN_DUPLICATE_IDENTITY')
                emit('RETURN=' + str(ret) + ' SHA256=' + result['return_sha256'])
            except BaseException as exc:
                result['blockers'].append('RETURN_PACKAGING:' + type(exc).__name__ + ':' + str(exc))
                if result['exit_code'] == 0:
                    result.update(status='BLOCKED', exit_code=5)
                emit('RETURN_PACKAGING_FAILED=' + str(exc))
        try:
            (log_dir / 'SUPERVISOR_RESULT.json').write_bytes(
                (json.dumps(result, sort_keys=True, indent=1, ensure_ascii=True) + '\n').encode('ascii'))
            emit('SUPERVISOR_RESULT=' + str(log_dir / 'SUPERVISOR_RESULT.json') +
                 ' SHA256=' + sha_file(log_dir / 'SUPERVISOR_RESULT.json'))
        except BaseException as exc:
            emit('SUPERVISOR_RESULT_WRITE_FAILED=' + str(exc))
        emit('SUPERVISOR_STATUS=' + result['status'] + ' EXIT_CODE=' + str(result['exit_code']))
        if _console is not None:
            _console.close(); _console = None
    return result['exit_code']
