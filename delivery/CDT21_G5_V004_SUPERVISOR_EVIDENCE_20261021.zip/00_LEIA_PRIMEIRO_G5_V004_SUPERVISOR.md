# CDT21 — G5 V004: supervisor qualificado e launcher final (campanha nativa nova)

**Papel:** implementador. Não é parecer B06.

**Decisão da origem (21/10):** uma nova campanha G5 nativa, vinculada ao manifesto completo do V004. Os 38 COMMITs do V003 continuam válidos só para os bytes do V003 e **não** recebem a identidade do V004.

| Item | Identidade |
|---|---|
| Candidato | V004 `AD33486954F1248AF28A78677377E83AB979AB86EDD5F71F5B7D108CBA8F99DD`, código `D2C626FD…66FF`, inalterado |
| Plano | 38 unidades lidas das constantes congeladas; mesmas chaves do V003 |
| Máquina G5 | `PRE_G06_CAMPAIGN` `347767D1`, `PRE_G06_COMPLETENESS` `15B10B10`, gate `EC6D9B2D`, producer `34CA561C`, suíte b2d `D19EF3BA`. Byte a byte iguais às do V003. |

## Supervisor `CDT21_G5_V004_SUPERVISOR.py` (`273E620746FD5293D87858847CEBE035328B2A354F4371BBB18D82195A410126`)

Derivado do R2 comprovado (`99704BA5…C0CC`) por `02_DERIVACAO/make_v004_supervisor.py`. O diff completo está em `R2_TO_V004.diff`.

**Preservado byte a byte do R2 (23 funções):**
- extração byte a byte no layout `CURRENT_G5_DELTA_*\EXTRACTED` exigido pela suíte b2d congelada;
- verificação desse contrato;
- plano;
- Job kill-on-close;
- impressão digital somente leitura de `D:\Base CSV`;
- isolamento das raízes de escrita;
- b2d nativo;
- `verify_extract` e `validate_review`.

**Removido:** o modo de retomada (`resume_precheck`, `preserve_prior_terminal`, `checkpoint_consistency`, `prior_processes_dead`, `lock_probe`). O argumento `--resume-root` passa a ser recusado antes de qualquer efeito.

**Acrescentado:**
- **Fase Q nativa para campanha nova.** Não cria raiz nem laboratório. Verifica pacote, revisão, elevação, NTFS, espaço, Job, plano de 38 unidades, `verify_package` congelado e isolamento de escrita. Roda o b2d nativo no layout corrigido (29/29) e no layout R1 (falha reproduzida). Registra **somente leitura** todas as raízes e laboratórios preexistentes, com o dono de cada um (os do V003 incluídos).
- **Fase E admitida só com Q=PASS** do mesmo supervisor e da mesma pasta de log, com menos de 2 h.
  - Cria raiz e laboratório **novos**, via `mkdir` sem `exist_ok`.
  - Recusa qualquer `REUSE_COMMITTED`.
  - Exige exatamente os 38 COMMITs do plano, vinculados ao pacote e ao código do V004, com artefatos re-hasheados e sem órfãos.
  - Exige `LIVE_STATUS`, `R08_RETURN` e `RETURN_LOCK_SCOPE` consistentes.
  - Exige raízes preexistentes inalteradas: só podem surgir a própria raiz e o próprio laboratório.
  - Exige `D:\Base CSV` idêntico em Q, antes, depois e no fechamento.
- **Digest das raízes estrangeiras.** Nunca segue symlink, junction ou reparse point, e registra diretórios ilegíveis pelo nome. Um link remanescente de outra execução não causa laço nem bloqueio.

**Revisão de fonte do V004:** `CDT19_IMPLEMENTER_SOURCE_REVIEW_V004.json` (`E84E5C39…C802`). É a entrada exigida pelo `PRE_G06_COMPLETENESS.close`, vinculada ao pacote e ao código do V004. A revisão do V003 é recusada.

## Qualificação Linux (não basta para executar; a Fase Q nativa é obrigatória)

**Validação do supervisor: 41/41.** Os casos rodam sobre a raiz V003 real coletada, cujos COMMITs reais estão vinculados ao V003.

| Grupo | Casos |
|---|---|
| Composição | as 23 funções do R2 são idênticas; retomada removida; `main` sem retomada e com a guarda `require(not reused …)` |
| Identidade | constantes do V004; layout corrigido aceito; layout R1 recusado; fontes congeladas fixadas; plano 38; `verify_package` congelado devolve o código do V004 |
| Revisão | revisão V004 aceita, revisão V003 recusada; testemunha e dono vinculados ao V004 |
| Raízes estrangeiras | registradas com dono V003; só a raiz própria é admitida; tocar a raiz V003 → `FOREIGN_ROOT_CHANGED`; irmão inesperado → `FOREIGN_ROOT_ADDED`; laço e link para fora não seguidos |
| `run_unit` congelado | **recusa um COMMIT do V003 sob a identidade V004** (`COMMITTED_INPUT_DRIFT`), sem `REUSE_COMMITTED` e sem executar nada |
| COMMITs | 38 vinculados ao V004 aceitos; COMMIT V003, COMMIT ausente, artefato adulterado e órfão recusados |
| Checkpoints | consistentes aceitos; chaves do `LIVE_STATUS` e SHA do `R08_RETURN` divergentes recusados |
| Qualificação | Q PASS admite a fase E; Q bloqueada, de outro supervisor, do R2, de outra pasta de log, de outro modo ou vencida é recusada |
| Mecânica | b2d no layout V004 (29 OK); retorno com nomes V004 e duplicatas indexadas por hash |
| Falha fechada sem efeito | `--qualify-only`, E sem Q e E fora do Windows |

**Controles de layout b2d sobre os bytes do V004: 4/4.**
- Layout R1: 29 `CONTRACT_NOT_MET`.
- Layout corrigido: 29/29 OK.
- Sem prefixo: recusado.
- Alias: recusado.

**Somente no Windows (Fase Q nativa):** elevação, NTFS, Job aninhado, lock `msvcrt`, b2d negativo nativo, campanha de 38 unidades e `close()` sobre o retorno nativo.

## Launcher `RUN_CDT21_G5_V004_20261021.ps1` (`54C5ED1991AE3BEDAC656E96772DB4DF41E5D99A7385B22405AAB39B82393372`)

- PowerShell 5.1, só ASCII, CRLF, sem erros de parser.
- Supervisor e revisão embutidos com SHA fixado; o launcher confere os bytes ao desembrulhar e de novo na releitura.
- Autoeleva por UAC; pai e filho escrevem na mesma pasta de log.
- Recusa iniciar se houver outra campanha G5 ativa.
- Sem cmdlets destrutivos e sem argumentos de retomada.
- **Log:** `C:\Users\silvi\Downloads\CDT21_G5_V004_RUNS\G5V4_<carimbo>\`.
- **Modos:** sem `-AutorizoLabD`, só a Fase Q (código 10); com `-AutorizoLabD`, Q e depois E.

## Após o retorno nativo

O implementador verifica os 38 recibos, as cinco provas, os quatro achados pré-B06 e o vínculo físico ao V004. Isso inclui o gate congelado e a reexecução independente de `PRE_G06_COMPLETENESS.close`. Em seguida, monta o fechamento integrado para a admissão B06 independente.

**Não iniciados:** B06, B07, D4/D5, canário, FULL e produção.

RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 21
