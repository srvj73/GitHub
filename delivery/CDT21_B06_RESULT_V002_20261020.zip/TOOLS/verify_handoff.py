import hashlib, json, os, sys
root = sys.argv[1]
m = json.load(open(os.path.join(root, 'TRANSPORT_MANIFEST.json'), encoding='utf-8'))
keys = [k for k,v in m.items() if isinstance(v, list)]
print('list keys:', keys)
files = m.get('files', [])
ok = bad = missing = 0
listed = set()
for f in files:
    p = os.path.join(root, f['path']); listed.add(os.path.normpath(f['path']))
    if not os.path.isfile(p):
        missing += 1; print('MISSING', f['path']); continue
    b = open(p, 'rb').read()
    h = hashlib.sha256(b).hexdigest().upper()
    if h == f['sha256'].upper() and len(b) == f['bytes']: ok += 1
    else: bad += 1; print('MISMATCH', f['path'], len(b), f['bytes'], h, f['sha256'])
present = set()
for d, _, fs in os.walk(root):
    for n in fs: present.add(os.path.normpath(os.path.relpath(os.path.join(d, n), root)))
extra = sorted(present - listed)
print(f'listed={len(files)} ok={ok} mismatch={bad} missing={missing} present={len(present)} unlisted={len(extra)}')
for e in extra: print('UNLISTED', e)
for k in m:
    if k not in ('files',): 
        v = m[k]
        if not isinstance(v, (list, dict)): print(k, '=', v)
