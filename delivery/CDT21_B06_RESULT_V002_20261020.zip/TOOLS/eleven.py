import hashlib, json, os, sys
SP=sys.argv[1]; E=f'{SP}/handoff/NATIVE_EVIDENCE/EVIDENCE/PRE_B06'
idx=json.load(open(f'{SP}/out/sha_index.json'))
rt={f['path']:f['sha256'].upper() for f in json.load(open(f'{SP}/cand/implementation_v001/RUNTIME_CODE_MANIFEST.json'))['files']}
def H(b): return hashlib.sha256(b).hexdigest().upper()
def ref(r):
    p=os.path.join(E,r['member']); b=open(p,'rb').read()
    assert H(b)==r['sha256'].upper() and len(b)==r['bytes'], ('REF_MISMATCH',r)
    return b
j=json.load(open(f'{E}/ELEVEN_CONSUMERS.json'))
problems=[]
for i,c in enumerate(j['consumers'],1):
    sp=c['source_path']; row={'n':i,'src':sp,'role':c['role']}
    row['src_eq_runtime']= rt.get(sp)==c['source_sha256'].upper()
    row['runner_in_candidate']= any('cand/' in l for l in idx.get(c['runner_source']['sha256'].upper(),[]))
    ex=json.loads(ref(c['execution_witness'])); ctl=json.loads(ref(c['negative_controls'])); it=json.loads(ref(c['internal_branch_execution'])); rv=json.loads(ref(c['code_path_review'])); ref(c['runner_source'])
    pb=ref(ctl['protected_inventory_before']); pa=ref(ctl['protected_inventory_after'])
    row['protected_unchanged']= pb==pa and ctl['before_protected_roots_sha256']==ctl['after_protected_roots_sha256']
    row['foreign_rej']=ctl.get('foreign_owner_rejected'); row['reparse_rej']=ctl.get('reparse_rejected')
    tr=it.get('isolated_transitions',[])
    row['transitions']=len(tr); row['transition_changes']= all(ref(t['before'])!=ref(t['after']) for t in tr) if tr else None
    row['internal_exit']=it.get('exit_code'); row['entry_reached']=it.get('source_entrypoint_reached')
    row['exec_exit']=ex.get('exit_code'); row['fail_before_protected']=ex.get('failure_before_protected_effect'); row['prot_eff']=ex.get('protected_effects'); row['iso_eff']=len(ex.get('isolated_effects',[]))
    for k,v in ex.get("observation",{}).items():
        if isinstance(v,dict) and "member" in v: ref(v)
        else: row.setdefault("obs_inline",[]).append(k)
    for k,v in ex.items():
        if isinstance(v,dict) and 'member' in v: ref(v)
    row['same_src_all']= len({c['source_sha256'],ex['source_sha256'],it['source_sha256'],rv['source_sha256']})==1
    row['run_ids']= ex.get('run_id')==it.get('run_id')==j['run_id']
    row['remaining_blockers']=rv.get('remaining_implementation_blockers')
    print(row)
