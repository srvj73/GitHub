import hashlib, io, json, os, sys, zipfile
roots = sys.argv[1:-1]; out = sys.argv[-1]
idx = {}
def add(h, where):
    idx.setdefault(h, []).append(where)
def walk_zip(data, label, depth):
    try: z = zipfile.ZipFile(io.BytesIO(data))
    except Exception: return
    for n in z.namelist():
        if n.endswith('/'): continue
        b = z.read(n); h = hashlib.sha256(b).hexdigest().upper()
        add(h, f'{label}!{n}')
        if depth < 3 and n.lower().endswith('.zip'): walk_zip(b, f'{label}!{n}', depth+1)
for r in roots:
    for d,_,fs in os.walk(r):
        for n in fs:
            p = os.path.join(d,n); b = open(p,'rb').read()
            h = hashlib.sha256(b).hexdigest().upper(); add(h, p)
            if n.lower().endswith('.zip'): walk_zip(b, p, 1)
json.dump(idx, open(out,'w'))
print('unique hashes', len(idx), 'locations', sum(len(v) for v in idx.values()))
