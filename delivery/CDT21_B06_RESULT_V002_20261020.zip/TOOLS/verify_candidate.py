import hashlib, json, os, sys, zipfile
zpath, root = sys.argv[1], sys.argv[2]
impl = os.path.join(root, 'implementation_v001')
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest().upper()
def check(manifest, base, label):
    m = json.load(open(manifest, encoding='utf-8'))
    ok=bad=miss=0; listed=set()
    for f in m['files']:
        p = os.path.join(base, f['path']); listed.add(os.path.normpath(f['path']))
        if not os.path.isfile(p): miss+=1; print(label,'MISSING',f['path']); continue
        if sha(p)==f['sha256'].upper() and os.path.getsize(p)==f['bytes']: ok+=1
        else: bad+=1; print(label,'MISMATCH',f['path'])
    dup = len(m['files'])-len(listed)
    print(f'{label}: listed={len(m["files"])} ok={ok} mismatch={bad} missing={miss} duplicates={dup}')
    return listed
# ZIP structural checks
z = zipfile.ZipFile(zpath)
names = z.namelist()
print('zip entries', len(names), 'dirs', sum(n.endswith('/') for n in names), 'dupnames', len(names)-len(set(names)))
bad_names=[n for n in names if n.startswith('/') or '..' in n.split('/') or '\\' in n]
print('unsafe names', bad_names)
print('testzip', z.testzip())
pk = check(os.path.join(root,'PACKAGE_MANIFEST.json'), root, 'PACKAGE')
filenames = set(os.path.normpath(n) for n in names if not n.endswith('/'))
print('zip files not in PACKAGE manifest:', sorted(filenames - pk))
print('PACKAGE entries not in zip:', sorted(pk - filenames))
sm = check(os.path.join(impl,'SOURCE_MANIFEST.json'), impl, 'SOURCE')
impl_files=set()
for d,_,fs in os.walk(impl):
    for n in fs: impl_files.add(os.path.normpath(os.path.relpath(os.path.join(d,n),impl)))
print('impl files not in SOURCE manifest:', sorted(impl_files - sm))
rm = check(os.path.join(impl,'RUNTIME_CODE_MANIFEST.json'), os.path.join(impl,'candidate'), 'RUNTIME')
cand_files=set()
for d,_,fs in os.walk(os.path.join(impl,'candidate')):
    for n in fs: cand_files.add(os.path.normpath(os.path.relpath(os.path.join(d,n),os.path.join(impl,'candidate'))))
print('candidate/ files not in RUNTIME manifest:', len(cand_files - rm))
for x in sorted(cand_files - rm): print('  RT-UNLISTED', x)
print('RUNTIME_CODE_MANIFEST sha', sha(os.path.join(impl,'RUNTIME_CODE_MANIFEST.json')))
print('SOURCE_MANIFEST sha', sha(os.path.join(impl,'SOURCE_MANIFEST.json')))
print('PACKAGE_MANIFEST sha', sha(os.path.join(root,'PACKAGE_MANIFEST.json')))
