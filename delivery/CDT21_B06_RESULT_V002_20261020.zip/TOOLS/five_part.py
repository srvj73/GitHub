import json, os, sys, hashlib
H = sys.argv[1]; idx = json.load(open(sys.argv[2]))
fp = os.path.join(H, 'NATIVE_EVIDENCE/FINAL_G5/FIVE_PART_PROOFS')
ec = json.load(open(os.path.join(H,'NATIVE_EVIDENCE/FINAL_G5/ENGINEERING_COMPLETENESS.json')))
tot = res = 0
for name in sorted(os.listdir(fp)):
    p = os.path.join(fp, name); b = open(p,'rb').read(); h = hashlib.sha256(b).hexdigest().upper()
    j = json.loads(b); part = name[:-5]
    claimed = ec['five_part_completeness'][part]['sha256']
    print(f'== {part} status={j["status"]} file_sha_matches_EC={h==claimed} code_manifest={j["code_manifest_sha256"][:12]} instance={j["instance_sha256"][:12]}')
    for e in j['evidence']:
        tot += 1; locs = idx.get(e['sha256'].upper(), [])
        res += bool(locs)
        print(f'   {"OK " if locs else "ABSENT"} {e["role"]:<45} {e["sha256"][:16]} -> {(locs[0].split("scratchpad/")[-1] if locs else "-")[:110]}')
print(f'bindings total={tot} resolved_by_bytes={res}')
