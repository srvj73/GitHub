import json, os, sys, hashlib
H = sys.argv[1]; idx = json.load(open(sys.argv[2]))
cd = os.path.join(H,'NATIVE_EVIDENCE/COMMITS')
tot=res=bypath=0; per={}
absent=[]
for n in sorted(os.listdir(cd)):
    j = json.load(open(os.path.join(cd,n)))
    a = j.get('artifacts',[]); r=0
    for x in a:
        tot+=1; locs = idx.get(x['sha256'].upper(),[])
        p = os.path.join(H,'NATIVE_EVIDENCE',x['member'])
        if os.path.isfile(p) and hashlib.sha256(open(p,'rb').read()).hexdigest().upper()==x['sha256'].upper(): bypath+=1
        if locs: r+=1
        else: absent.append((n,x['member']))
    res+=r
    rs = j.get('result',{})
    per[n]=(len(a),r,rs.get('status'),rs.get('exit_code'),rs.get('test_count'),rs.get('failures'),rs.get('errors'),rs.get('skipped'),j.get('code_sha256','')[:8],j.get('package_sha256','')[:8])
for n,v in per.items(): print(f'{n:<62} links={v[0]:>3} resolved={v[1]:>3} status={v[2]} exit={v[3]} tests={v[4]} fail={v[5]} err={v[6]} skip={v[7]} code={v[8]} pkg={v[9]}')
print(f'COMMITS={len(per)} links_total={tot} resolved_by_content={res} resolved_by_member_path={bypath} absent={len(absent)}')
from collections import Counter
print(Counter(a[0] for a in absent))
print('sample absent:', absent[:5])
