"""Reproduce the native b2d failure and qualify the layout fix, using frozen V003 bytes only.

The frozen suite only checks its run-root contract when os.name == 'nt'. This harness
loads the unmodified test module from each extraction layout and gives that module
an os proxy whose .name is 'nt' (every other attribute is the real os), so the
Windows branch of setUp() runs verbatim on Linux.

Usage: b2d_layout_controls.py <V003_ZIP> <WORKDIR> <OUT_JSON>
"""
import hashlib, importlib.util, io, json, os, shutil, sys, unittest, zipfile
from pathlib import Path

pkg, work, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
TEST_REL = 'implementation_v001/tests/test_b2d_origin_decision_binder.py'
TEST_SHA = 'D19EF3BA870D4065CFDF6C39B35EEB8D24CE9FAEF171E2C6806D9C4E7708DAA0'


class NtOs:
    name = 'nt'
    def __getattr__(self, item):
        return getattr(os, item)


def extract(dest):
    dest.mkdir(parents=True)
    with zipfile.ZipFile(pkg) as z:
        z.extractall(dest)
    raw = (dest / TEST_REL).read_bytes()
    assert hashlib.sha256(raw).hexdigest().upper() == TEST_SHA
    return dest / TEST_REL


def run(test_path, tag):
    for m in ('G5_C6_FORMAL_CONTRACT', 'G5_C6_B1_FORMAL_CONSUMER'):
        sys.modules.pop(m, None)
    spec = importlib.util.spec_from_file_location('b2d_' + tag, test_path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    mod.os = NtOs()
    suite = unittest.defaultTestLoader.loadTestsFromModule(mod)
    stream = io.StringIO()
    res = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    text = stream.getvalue()
    return {'ran': res.testsRun, 'errors': len(res.errors), 'failures': len(res.failures), 'skipped': len(res.skipped),
            'ok': res.wasSuccessful(), 'contract_not_met': text.count('G5_FIXTURE_RUNROOT_CONTRACT_NOT_MET'),
            'alias_not_canonical': text.count('G5_FIXTURE_RUNROOT_ALIAS_NOT_CANONICAL'), 'tail': text.strip().splitlines()[-1]}


shutil.rmtree(work, ignore_errors=True); work.mkdir(parents=True)
cases = {}
# A. Layout used by supervisor 7B482A4B (failing native run): <run_root>/PACKAGED
cases['A_supervisor_r1_PACKAGED'] = run(extract(work / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791' / 'PACKAGED'), 'A')
# B. Fixed layout: <...>/CURRENT_G5_DELTA_<id>/EXTRACTED
cases['B_fixed_CURRENT_G5_DELTA_EXTRACTED'] = run(extract(work / 'CDT21_G5_V003' / 'CURRENT_G5_DELTA_20261021120000_abcdef' / 'EXTRACTED'), 'B')
# C. Negative: EXTRACTED under a parent without the prefix
cases['C_neg_parent_without_prefix'] = run(extract(work / 'OTHER' / 'EXTRACTED'), 'C')
# D. Negative: correct names reached through a symlink alias of the parent
real = work / 'REAL_PARENT'
extract(real / 'EXTRACTED')
alias = work / 'CURRENT_G5_DELTA_ALIAS'
os.symlink(real, alias, target_is_directory=True)
cases['D_neg_alias_parent'] = run(alias / 'EXTRACTED' / TEST_REL, 'D')

checks = {
    'A_reproduces_native_failure': cases['A_supervisor_r1_PACKAGED']['ran'] == 29 and cases['A_supervisor_r1_PACKAGED']['errors'] == 29
                                   and cases['A_supervisor_r1_PACKAGED']['contract_not_met'] >= 29,
    'B_fixed_layout_29_of_29_ok': cases['B_fixed_CURRENT_G5_DELTA_EXTRACTED']['ran'] == 29 and cases['B_fixed_CURRENT_G5_DELTA_EXTRACTED']['ok']
                                  and cases['B_fixed_CURRENT_G5_DELTA_EXTRACTED']['skipped'] == 0,
    'C_prefix_required': cases['C_neg_parent_without_prefix']['errors'] == 29 and cases['C_neg_parent_without_prefix']['contract_not_met'] >= 29,
    # resolve() dereferences the alias first, so the fixture refuses it as CONTRACT_NOT_MET (or ALIAS_NOT_CANONICAL).
    'D_alias_refused': cases['D_neg_alias_parent']['errors'] == 29
                       and cases['D_neg_alias_parent']['contract_not_met'] + cases['D_neg_alias_parent']['alias_not_canonical'] >= 29,
}
summary = {'schema': 'CDT21_G5_V003_B2D_LAYOUT_CONTROLS_V001', 'test_source_sha256': TEST_SHA,
           'package_sha256': hashlib.sha256(pkg.read_bytes()).hexdigest().upper(), 'v003_bytes_modified': False,
           'method': 'frozen test module loaded per layout; module-level os proxy with name=nt (all other os attributes real)',
           'cases': cases, 'checks': {k: 'PASS' if v else 'FAIL' for k, v in checks.items()}}
out.write_text(json.dumps(summary, indent=1, sort_keys=True) + '\n')
for k, v in cases.items():
    print(k, v['ran'], 'errors', v['errors'], 'ok', v['ok'], v['tail'])
print(summary['checks'])
sys.exit(0 if all(checks.values()) else 1)
