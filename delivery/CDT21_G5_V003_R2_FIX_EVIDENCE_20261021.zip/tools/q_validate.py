"""Linux validation of the R2 native-qualification functions (Windows-only parts are not simulated).

Usage: q_validate.py <SUP_R2.py> <REVIEW.json> <V003_ZIP> <COLLECTED_FILES_DIR> <WORKDIR> <OUT_JSON>
"""
import importlib.util, json, os, shutil, subprocess, sys, time
from pathlib import Path

sup, review, v3zip, files, work, out = map(Path, sys.argv[1:7])
checks = {}


def rec(name, ok, detail=''):
    checks[name] = {'status': 'PASS' if ok else 'FAIL', 'detail': str(detail)[:400]}
    print(('PASS ' if ok else 'FAIL ') + name + ' ' + str(detail)[:150], flush=True)


def raises(fn, needle):
    try:
        fn()
    except BaseException as exc:
        m = type(exc).__name__ + ':' + str(exc)
        return needle in m, m
    return False, 'NO_EXCEPTION'


spec = importlib.util.spec_from_file_location('sup_r2q', sup)
S = importlib.util.module_from_spec(spec); spec.loader.exec_module(S)
shutil.rmtree(work, ignore_errors=True); work.mkdir(parents=True)
RUN = 'R08_Q1_20261020210605_856fea523791'
local = work / 'Local'
root = local / 'CDT20_R08' / RUN
shutil.copytree(files / 'ROOT_1', root)
(root / 'TEMP').mkdir(); (root / 'TEMP' / 'G0_HANDLE_IDENTITY.json').write_text('{"identity":"canonical native handle readback"}')
(root / 'QUAL_C').mkdir()
shutil.copyfile(v3zip, root / 'INPUTS' / S.PACKAGE_NAME)
dlab = work / 'D' / S.D_LABS_NAME / RUN; dlab.mkdir(parents=True); (dlab / 'WRITER_EFFECTFUL').mkdir()
shutil.copyfile(root / 'OWNER.json', dlab / 'OWNER.json')
ext = S.fixture_extract_dir(local, 'Q_TEST'); ext.parent.mkdir(parents=True); S.extract_package(v3zip, ext)
plan = S.plan_keys(ext)
import FULL_CRASH_RECOVERY as R  # noqa: E402 (frozen, from the extraction)

# 1. Tree digest: stable when untouched, sensitive to content, mtime and new entries.
d0 = S.tree_digest(root); d1 = S.tree_digest(root)
probe = root / 'LOGS' / 'G5_PS51_INSTALL_MENU.log'; st = probe.stat()
os.utime(probe, ns=(st.st_atime_ns, st.st_mtime_ns + 1000)); d2 = S.tree_digest(root); os.utime(probe, ns=(st.st_atime_ns, st.st_mtime_ns))
(root / 'NEWFILE').write_text('x'); d3 = S.tree_digest(root); (root / 'NEWFILE').unlink(); d4 = S.tree_digest(root)
rec('tree_digest_stable_and_sensitive', d0 == d1 == d4 and d2 != d0 and d3 != d0, (d0['entries'], d3['entries']))

# 2. Production fingerprint (fixture production base).
prod = work / 'PROD'; (prod / 'Scripts' / 'Biblioteca').mkdir(parents=True)
(prod / 'Scripts' / 'Biblioteca' / 'MENU.py').write_text('menu'); (prod / 'Manuten\u00e7\u00e3o Base de Dados.bat').write_text('bat')
S.PRODUCTION = str(prod)
f0 = S.production_fingerprint(); f1 = S.production_fingerprint()
(prod / 'DATA.csv').write_text('1'); f2 = S.production_fingerprint()
rec('production_fingerprint_stable_and_detects_change', f0 == f1 and f2 != f0 and f0['menu'] != 'ABSENT' and f0['bat'] != 'ABSENT')
S.PRODUCTION = 'D:\\Base CSV'

# 3. Path isolation: reparse component and production paths are refused.
link = work / 'LINKED'; os.symlink(work / 'D', link, target_is_directory=True)
iso = S.path_isolation({'ok': (root, True), 'via_link': (link / 'x', True), 'report_only_link': (link / 'y', False)})
rec('path_isolation_rejects_reparse', iso['ok']['status'] == 'PASS' and iso['via_link']['status'] == 'FAIL'
    and iso['report_only_link']['status'] == 'REPORT_ONLY', {k: v['status'] for k, v in iso.items()})
S.PRODUCTION = str(work / 'PROD')
iso2 = S.path_isolation({'inside_prod': (work / 'PROD' / 'sub', True)})
rec('path_isolation_rejects_production', iso2['inside_prod']['outside_production'] is False and iso2['inside_prod']['status'] == 'FAIL')
S.PRODUCTION = 'D:\\Base CSV'

# 4. Checkpoint consistency on the real collected root, with negative controls.
pre = S.resume_precheck(root, dlab, local, plan)
cc = S.checkpoint_consistency(root, pre['committed_before'])
rec('checkpoint_consistency_real_root', cc['prior_r08_return_sha256'] == '5835A84122E0CC455C4217FB85A6D96E11F4CB0A6D7F33FFAC35B9CC357502EF'
    and cc['r08_partial_present'] is False, cc)
rec('neg_checkpoint_commit_keys', *raises(lambda: S.checkpoint_consistency(root, pre['committed_before'][:4]), 'LIVE_STATUS_COMMIT_KEYS'))
shaf = root / 'R08_RETURN.sha256'; good = shaf.read_bytes(); shaf.write_text('0' * 64 + '  R08_RETURN.zip\n')
rec('neg_checkpoint_r08_sha_file', *raises(lambda: S.checkpoint_consistency(root, pre['committed_before']), 'PRIOR_R08_RETURN_SHA_FILE'))
shaf.write_bytes(good)

# 5. Prior processes through the frozen R.dead with an injected census.
absent = lambda pid: {'pid': pid, 'state': 'ABSENT'}
ids = S.prior_processes_dead(root, lambda i: R.dead(i, probe=absent))
rec('prior_processes_identities_found_and_dead', len(ids) >= 6 and all(x['observation'] == 'ABSENT' for x in ids), len(ids))
first = ids[0]
live = lambda pid: {'pid': pid, 'state': 'LIVE', 'creation_filetime': first['creation_filetime']}
rec('neg_prior_process_live', *raises(lambda: S.prior_processes_dead(root, lambda i: R.dead(i, probe=live)), 'OWNER_OR_CHILD_LIVE'))

# 6. Native b2d runner mechanics (Linux skips the nt contract; Windows is where the negative applies).
qt = work / 'QT'; qt.mkdir()
b = S.native_b2d(ext, qt, work / 'b2d.log')
rec('native_b2d_runner_mechanics', b['exit'] == 0 and b['ran'] == 29 and b['ok'] and b['contract_not_met'] == 0, b)

# 7. Resume admission requires a fresh PASS qualification of the same bytes, run root and log dir.
logd = work / 'LOG'; logd.mkdir()
def qual(**kw):
    q = {'schema': S.QUAL_SCHEMA, 'status': 'PASS_WINDOWS_QUALIFICATION', 'supervisor_sha256': S.sha_file(sup),
         'run_root': str(root), 'log_dir': str(logd), 'finished_epoch': time.time(), 'checks': {'a': {}},
         'production_fingerprint': {'x': 1}}
    q.update(kw); p = work / ('Q_%d.json' % len(list(work.glob('Q_*.json')))); p.write_text(json.dumps(q)); return p
S.__file__ = str(sup)
rec('qualification_admits_resume', S.require_qualification(qual(), logd, root)['checks'] == 1)
for tag, kw, needle in (('blocked', {'status': 'BLOCKED'}, 'QUALIFICATION_NOT_PASS'),
                        ('other_supervisor', {'supervisor_sha256': 'F' * 64}, 'QUALIFICATION_OTHER_SUPERVISOR'),
                        ('other_root', {'run_root': str(root) + 'X'}, 'QUALIFICATION_OTHER_RUN'),
                        ('other_log_dir', {'log_dir': str(logd) + 'X'}, 'QUALIFICATION_OTHER_RUN'),
                        ('stale', {'finished_epoch': time.time() - 3 * 3600}, 'QUALIFICATION_STALE')):
    rec('neg_qualification_' + tag, *raises(lambda: S.require_qualification(qual(**kw), logd, root), needle))

# 8. Fail-closed entry points off Windows: --qualify-only and resume without qualification; no effects.
for tag, extra, needle, result_name in (
        ('qualify_only', ['--qualify-only', '--resume-root', str(root), '--d-lab', str(dlab)], 'QUAL_windows_python_admin', 'QUALIFICATION_RESULT.json'),
        ('resume_without_qualification', ['--resume-root', str(root), '--d-lab', str(dlab)], 'RESUME_REQUIRES_WINDOWS_QUALIFICATION', 'SUPERVISOR_RESULT.json')):
    st = work / ('ST_' + tag); st.mkdir(); shutil.copyfile(sup, st / 'CDT21_G5_V003_SUPERVISOR_R2.py')
    rv = st / S.REVIEW_NAME; rv.write_bytes(review.read_bytes()); lg = work / ('LG_' + tag); lg.mkdir()
    rb, db = S.tree_digest(root), S.tree_digest(dlab)
    r = subprocess.run([sys.executable, '-I', '-B', str(st / 'CDT21_G5_V003_SUPERVISOR_R2.py'), '--package', str(v3zip),
                        '--review', str(rv), '--log-dir', str(lg), '--stage', str(st)] + extra,
                       capture_output=True, text=True, timeout=120, env=dict(os.environ, LOCALAPPDATA=str(local)))
    res = json.loads((lg / result_name).read_bytes())
    rec('fail_closed_' + tag, r.returncode == 2 and any(needle in b for b in res['blockers'])
        and S.tree_digest(root) == rb and S.tree_digest(dlab) == db, res['blockers'])

summary = {'schema': 'CDT21_G5_V003_SUPERVISOR_R2_QUALIFY_PHASE_LINUX_VALIDATION_V001', 'supervisor_r2_sha256': S.sha_file(sup),
           'checks': checks, 'passed': sum(v['status'] == 'PASS' for v in checks.values()), 'total': len(checks),
           'windows_runtime_only': ['IsUserAnAdmin', 'GetVolumeInformationW', 'Job object nesting', 'msvcrt lock probe on the real CAMPAIGN.lock',
                                    'native b2d negative on the R1 layout (contract branch only on os.name==nt)', 'R.native_process census'],
           'decision': 'R2 is NOT ready by Linux tests alone; the launcher runs the native qualification (Q) and resume requires its PASS'}
out.write_text(json.dumps(summary, indent=1, sort_keys=True) + '\n')
print('PASSED', summary['passed'], '/', summary['total'])
sys.exit(0 if summary['passed'] == summary['total'] else 1)
