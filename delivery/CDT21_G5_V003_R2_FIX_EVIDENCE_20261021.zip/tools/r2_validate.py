"""Linux qualification of supervisor R2 against frozen V003 code and the real collected run root.

Usage: r2_validate.py <SUP_R2.py> <REVIEW.json> <V003_ZIP> <COLLECTED_FILES_DIR> <COLLECT_MANIFEST.json>
                      <V002_NATIVE_DIR> <WORKDIR> <OUT_JSON>
"""
import importlib.util, io, json, os, shutil, subprocess, sys, types, zipfile
from contextlib import redirect_stdout
from pathlib import Path

sup, review, v3zip, files, cman, v2native, work, out = map(Path, sys.argv[1:9])
checks = {}


def rec(name, ok, detail=''):
    checks[name] = {'status': 'PASS' if ok else 'FAIL', 'detail': str(detail)[:500]}
    print(('PASS ' if ok else 'FAIL ') + name + ' ' + str(detail)[:170], flush=True)


def raises(fn, needle):
    try:
        fn()
    except BaseException as exc:
        msg = type(exc).__name__ + ':' + str(exc)
        return needle in msg, msg
    return False, 'NO_EXCEPTION'


spec = importlib.util.spec_from_file_location('sup_r2', sup)
S = importlib.util.module_from_spec(spec); spec.loader.exec_module(S)
review_raw = review.read_bytes()
shutil.rmtree(work, ignore_errors=True); work.mkdir(parents=True)
local = work / 'Local'
RUN = 'R08_Q1_20261020210605_856fea523791'

# 1. Fixture layout: fixed extraction satisfies the b2d contract; R1 layout does not.
ext = S.fixture_extract_dir(local, '20261021120000_abcdef')
ext.parent.mkdir(parents=True)
n = S.extract_package(v3zip, ext); S.verify_extract(v3zip, ext); S.check_fixture_contract(ext)
rec('fixed_layout_contract_and_byte_exact', n == 312 and ext.parent.name.startswith('CURRENT_G5_DELTA_'), str(ext))
old = work / 'CDT20_R08_OLD' / RUN / 'PACKAGED'; old.parent.mkdir(parents=True)
S.extract_package(v3zip, old)
rec('r1_layout_refused_by_contract_check', *raises(lambda: S.check_fixture_contract(old), 'FIXTURE_LAYOUT'))

# 2. Plan from frozen constants; frozen verify_package accepts the fixed extraction.
plan = S.plan_keys(ext)
import PRE_G06_CAMPAIGN as C  # noqa: E402  (imported by plan_keys from the fixed extraction)
import FULL_CRASH_RECOVERY as R  # noqa: E402
code, members = C.verify_package(v3zip)
rec('plan_38_from_frozen_constants', len(plan) == 38 and plan[0] == 'G5_PS51_INSTALL_MENU' and plan[-1] == 'G3_G6_NATIVE', len(plan))
rec('frozen_verify_package_on_fixed_layout', code == S.CODE_SHA and Path(C.__file__).resolve() == (ext / S.CAMPAIGN_REL).resolve(), code)


# 3. Rebuild the real interrupted run root from the 59 collected files.
def rebuild(dst_local, name=RUN):
    root = dst_local / 'CDT20_R08' / name
    shutil.copytree(files / 'ROOT_1', root)
    (root / 'TEMP').mkdir(exist_ok=True); (root / 'QUAL_C').mkdir(exist_ok=True)
    (root / 'WORK' / 'SUITE_test_b2d_origin_decision_binder.py').mkdir(parents=True, exist_ok=True)
    shutil.copyfile(v3zip, root / 'INPUTS' / S.PACKAGE_NAME)
    dlab = dst_local.parent / 'D' / S.D_LABS_NAME / name
    dlab.mkdir(parents=True); (dlab / 'WRITER_EFFECTFUL').mkdir()
    shutil.copyfile(root / 'OWNER.json', dlab / 'OWNER.json')
    return root, dlab


m = json.loads(cman.read_bytes().decode('utf-8-sig'))
inp = [e for e in m['entries'] if e['kind'] == 'HASH_ONLY_INPUT']
rec('collected_input_package_is_v003', len(inp) == 1 and inp[0]['sha256'] == S.PACKAGE_SHA, inp[0]['sha256'] if inp else None)
root, dlab = rebuild(local)
pre = S.resume_precheck(root, dlab, local, plan)
expected5 = ['G5_D4_REAL_ISOLATED_PATH_NATIVE', 'G5_PS51_INSTALL_MENU', 'G5_STAGE_B_REAL_ISOLATED_PATH_NATIVE',
             'SUITE_test_cdt17_final_g5_complete_proof_gate.py', 'SUITE_test_cdt18_stage_proof_integrated_reconcile.py']
rec('resume_precheck_real_root', pre['committed_before'] == expected5 and len(pre['pending']) == 33
    and pre['prior_status'] == 'BLOCKED' and 'SUITE_test_b2d_origin_decision_binder.py' in pre['pending'], pre['committed_before'])
rec('r1_witness_deterministic', (root / 'INPUTS' / S.WITNESS_NAME).read_bytes() == S.encoded(S.make_witness(RUN, S.MANIFEST_SHA)))

# 4. Frozen run_unit reuses each of the 5 native commits (no rerun) from the fixed extraction.
reuse_ok = []
for key in expected5:
    buf = io.StringIO()
    with redirect_stdout(buf):
        res = C.run_unit(dict(root=str(root), key=key, kind='suite', name='x', package_sha256=S.PACKAGE_SHA, code_sha256=S.CODE_SHA))
    reuse_ok.append(buf.getvalue().strip() == 'REUSE_COMMITTED ' + key and res.get('status') == 'PASS')
rec('frozen_run_unit_reuses_all_5_native_commits', all(reuse_ok), reuse_ok)

# 5. Frozen run_unit preserves the failed b2d attempt (moves stale, never deletes) before running it.
before = sorted(p.relative_to(root).as_posix() for p in (root / 'UNITS' / 'SUITE_test_b2d_origin_decision_binder.py').rglob('*')) + \
         ['LOGS/SUITE_test_b2d_origin_decision_binder.py.log']
b2d_log_sha = R.sha((root / 'LOGS' / 'SUITE_test_b2d_origin_decision_binder.py.log').read_bytes())
ok, detail = raises(lambda: C.run_unit(dict(root=str(root), key='SUITE_test_b2d_origin_decision_binder.py', kind='suite',
                                             name='test_b2d_origin_decision_binder.py', package_sha256=S.PACKAGE_SHA,
                                             code_sha256=S.CODE_SHA)), '')
moved = list((root / 'INTERRUPTED_ATTEMPTS').glob('SUITE_test_b2d_origin_decision_binder.py_*'))
kept = moved and any(R.sha(p.read_bytes()) == b2d_log_sha for p in moved[0].rglob('*.log'))
rec('frozen_stale_b2d_attempt_preserved', bool(kept) and not (root / 'LOGS' / 'SUITE_test_b2d_origin_decision_binder.py.log').exists(),
    'linux stops at Windows-only ProcessJob after the move: ' + detail[:80])

# 6. Prior terminal receipts are copied, not moved; prior R08_RETURN.zip copied byte-exact to the stage.
root2, dlab2 = rebuild(work / 'L2' / 'Local')
stage = work / 'STAGE'; stage.mkdir()
shutil.copyfile(files / 'ROOT_1' / 'R08_RETURN.zip', root2 / 'R08_RETURN.zip') if (files / 'ROOT_1' / 'R08_RETURN.zip').exists() else None
orig = {n: R.sha((root2 / n).read_bytes()) for n in ('ENGINEERING_RESULT.json', 'LIVE_STATUS.json', 'R08_RETURN.sha256', 'R08_RETURN.zip')}
prior = S.preserve_prior_terminal(root2, stage, 'T1')
keep = root2 / 'INTERRUPTED_ATTEMPTS' / 'PRIOR_TERMINAL_T1'
rec('prior_terminal_copied_not_moved', all(R.sha((root2 / n).read_bytes()) == h for n, h in orig.items())
    and all(R.sha((keep / n).read_bytes()) == orig[n] for n in ('ENGINEERING_RESULT.json', 'LIVE_STATUS.json', 'R08_RETURN.sha256'))
    and prior['prior_r08_return_sha256'] == '5835A84122E0CC455C4217FB85A6D96E11F4CB0A6D7F33FFAC35B9CC357502EF'
    and R.sha((stage / ('PRIOR_R08_RETURN_' + RUN + '.zip')).read_bytes()) == prior['prior_r08_return_sha256'], prior.get('prior_r08_return_sha256'))


# 7. Negative controls of the resume precheck (each on a fresh copy of the real root).
def neg(name, mutate, needle):
    base = work / ('NEG_' + name) / 'Local'
    r, d = rebuild(base)
    loc = base
    res = mutate(r, d)
    args = res if isinstance(res, tuple) else (r, d, loc)
    rec('neg_' + name, *raises(lambda: S.resume_precheck(args[0], args[1], args[2], plan), needle))


def tamper_log(r, d):
    p = r / 'LOGS' / 'SUITE_test_cdt17_final_g5_complete_proof_gate.py.log'; b = bytearray(p.read_bytes()); b[0] ^= 1; p.write_bytes(bytes(b))
neg('artifact_tamper', tamper_log, 'RESUME_COMMIT_ARTIFACT_DRIFT')
neg('v002_commit', lambda r, d: shutil.copyfile(v2native / 'COMMITS' / 'SUITE_adapter_tests.py.json', r / 'COMMITS' / 'SUITE_adapter_tests.py.json'),
    'RESUME_COMMIT_NOT_CLOSED:SUITE_adapter_tests.py')
neg('foreign_commit_key', lambda r, d: (r / 'COMMITS' / 'NOT_IN_PLAN.json').write_text('{}'), 'RESUME_FOREIGN_COMMIT')
neg('safe_stop_request', lambda r, d: (r / 'SAFE_STOP.request').write_text('x'), 'RESUME_SAFE_STOP_REQUEST_PRESENT')
neg('d_lab_owner_differs', lambda r, d: (d / 'OWNER.json').write_text('{}'), 'RESUME_D_LAB_OWNER')
neg('extra_zip_in_inputs', lambda r, d: (r / 'INPUTS' / 'OTHER.zip').write_bytes(b'x'), 'RESUME_INPUT_PACKAGE')
neg('witness_changed', lambda r, d: (r / 'INPUTS' / S.WITNESS_NAME).write_text('{}'), 'RESUME_WITNESS')


def pass_result(r, d):
    e = json.loads((r / 'ENGINEERING_RESULT.json').read_bytes()); e['status'] = 'PASS_NATIVE_INTEGRATED_PRE_B06'
    (r / 'ENGINEERING_RESULT.json').write_bytes(R.encoded(e))
neg('already_pass_not_resumed', pass_result, 'RESUME_ENGINEERING_RESULT')


def wrong_location(r, d):
    other = r.parent.parent / 'ELSEWHERE' / r.name; other.parent.mkdir(); shutil.move(str(r), str(other))
    return other, d, r.parent.parent.parent / 'Local'
neg('root_outside_cdt20_r08', wrong_location, 'RESUME_ROOT_LOCATION')

# 8. R2 fails closed before any lab effect off Windows, and pairs resume arguments.
for tag, extra, needle in (('preflight', [], 'Blocked:WINDOWS_REQUIRED'),
                           ('resume_args_pair', ['--resume-root', str(root)], 'Blocked:RESUME_ARGS_PAIR')):
    st = work / ('ST_' + tag); st.mkdir(); shutil.copyfile(sup, st / 'CDT21_G5_V003_SUPERVISOR_R2.py')
    rv = st / S.REVIEW_NAME; rv.write_bytes(review_raw); lg = work / ('LG_' + tag); lg.mkdir()
    snapshot = sorted(str(p) for p in work.rglob('*') if 'ST_' not in str(p) and 'LG_' not in str(p))
    r = subprocess.run([sys.executable, '-I', '-B', str(st / 'CDT21_G5_V003_SUPERVISOR_R2.py'), '--package', str(v3zip),
                        '--review', str(rv), '--log-dir', str(lg), '--stage', str(st)] + extra,
                       capture_output=True, text=True, timeout=120, env=dict(os.environ, LOCALAPPDATA=str(local)))
    res = json.loads((lg / 'SUPERVISOR_RESULT.json').read_bytes())
    after = sorted(str(p) for p in work.rglob('*') if 'ST_' not in str(p) and 'LG_' not in str(p))
    rec('fail_closed_' + tag, r.returncode == 2 and res['blockers'] == [needle] and snapshot == after
        and not (lg / 'CDT21_G5_V003_RETURN.zip').exists(), res['blockers'])

summary = {'schema': 'CDT21_G5_V003_SUPERVISOR_R2_LINUX_VALIDATION_V001', 'supervisor_r2_sha256': S.sha_file(sup),
           'review_sha256': S.sha_bytes(review_raw), 'candidate_sha256': S.PACKAGE_SHA, 'v003_bytes_modified': False,
           'collected_root_source': 'FILES/ROOT_1 of collector COLLECT_20261021_063800_267_29732 (59/59 SHA verified)',
           'checks': checks, 'passed': sum(v['status'] == 'PASS' for v in checks.values()), 'total': len(checks),
           'windows_only_not_simulated': ['msvcrt lock on existing CAMPAIGN.lock', 'Job object', 'NTFS/elevation preflight',
                                          '33 pending native units', 'five-part close on a PASS native return']}
out.write_text(json.dumps(summary, indent=1, sort_keys=True) + '\n')
print('PASSED', summary['passed'], '/', summary['total'])
sys.exit(0 if summary['passed'] == summary['total'] else 1)
