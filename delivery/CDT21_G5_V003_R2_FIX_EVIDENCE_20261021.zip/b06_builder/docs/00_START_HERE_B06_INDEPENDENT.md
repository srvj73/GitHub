# 00 START HERE — Auditoria B06 independente do TICKSTORE CDT21 V003

**Destinatário:** auditor B06 **genuinamente independente**, admitido pela conversa de origem (ChatGPT, projeto Base de Dados CSV / Tickstore, conversa Compressão De Ticks 21).

**Quem não pode auditar:**
- a conversa Opus que implementou o V003;
- qualquer agente que tenha participado da engenharia F-01/F-04 ou dos supervisores G5.

**Despacho:** só a origem despacha este pacote. Ela antes revalida a política vigente (custódia exclusiva dela) e emite o recibo `INDEPENDENCE_PRE_DISPATCH`. O modelo do recibo segue anexo.

## 1. Objeto exato

| Item | Identidade |
|---|---|
| Candidato | `01_CANDIDATE_V003/CDT21_FINAL_PACKAGE_V003_20261020.zip`, SHA-256 `69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50` |
| Manifesto de código runtime | `D59BC4EE4F0D5C689335C8F478A0342CC0146930E3B0B44C707B6B95267B3953` |
| Parent histórico (não auditável como V003) | V002 `4942871541629C3B38F47EDA55EA2C9E310361533887CB55E577D9641542E7C5` |

Todo membro deste pacote está em `DISPATCH_MANIFEST.json`, com SHA-256, tamanho e papel. A testemunha externa (`WITNESS_…json`) fixa o SHA do ZIP do pacote.

## 2. O que o implementador entrega, sem valor de veredito

Pastas do pacote:
- **`02_G0_NATIVE_V003`:** qualificação nativa do delta F-01/F-04 (11/11 unidades, 148/148 testes) e reconciliação da origem.
- **`03_G5_NATIVE_V003`:** retorno nativo integral da campanha G5 V003. Contém:
  - os logs do pai e do filho elevado;
  - o `SUPERVISOR_RESULT.json`;
  - o `CDT21_G5_V003_RETURN.zip`, com `R08_RETURN.zip`, `FINAL_G5`, `SOURCE_REVIEW` e os recibos de retomada.
- **`04_OWNER_G5_APPROVAL_V003`:** decisão G5 do titular para os bytes exatos do V003.
- **`05_ENGINEERING_EVIDENCE`:** evidências de engenharia do implementador:
  - delta F-01/F-04;
  - procedimento G5;
  - reconciliação da execução interrompida;
  - correção R2 do supervisor externo;
  - controles positivos e negativos.
- **`06_HISTORICAL_V002_REFERENCE_ONLY`:** evidência primária V002. É **somente histórica**: nunca prova nada do V003.

Arquivos de apoio na raiz:
- **`CDT21_G5_V003_FINAL_ENGINEERING_RECEIPT.json`, `FIVE_PART_CHECKLIST.json`, `B06_DISPATCH_ADMISSION_MATRIX.json`:** verificações do montador.
  - O código congelado do V003 foi executado sobre o retorno nativo, incluindo a reexecução independente de `PRE_G06_COMPLETENESS.close` no Linux, comparada com o resultado do Windows.
  - São recibos de engenharia, **não** parecer B06.
- **`ADVERSARIAL_FALSE_COMPLETENESS_REVIEW_IMPLEMENTER.md`, `NEGATIVE_CONTROLS_INDEX.json`:** revisão adversarial do implementador. Trate-a como alegação a verificar.

## 3. Roteiro mínimo de auditoria (o mérito é do auditor)

1. **Identidade.** Confira o SHA do ZIP, o `DISPATCH_MANIFEST` e o candidato. Recalcule `PACKAGE_MANIFEST`, `SOURCE_MANIFEST` e `RUNTIME_CODE_MANIFEST`.
2. **Código testado igual ao empacotado.** Em cada unidade nativa, o `verify_package` congelado compara os bytes testados com o ZIP. Confira nos logs e nos COMMITs.
3. **Campanha G5 nativa.** Verifique offline, com o próprio código do candidato:
   - `FULL_G5_COMPLETE_PROOF_GATE.verify_native_campaign(R08_RETURN.zip, D59BC4EE…, 69DA2D59…, index, final_members=...)`;
   - os 31 papéis, os 9 `REQUIRED_DELTA` e os quatro achados pré-B06.
4. **Retomada.** A campanha foi retomada na mesma raiz após uma parada causada pelo supervisor externo R1. Confira:
   - que as 5 unidades COMMITTED antes da parada foram **reutilizadas** (`REUSE_COMMITTED`) e não reexecutadas;
   - que a tentativa interrompida da suíte b2d está preservada em `INTERRUPTED_ATTEMPTS`;
   - que os terminais anteriores foram preservados (`PRIOR_TERMINAL_*`).
5. **Cinco partes.** Confira `FINAL_G5/ENGINEERING_COMPLETENESS.json`, `FIVE_PART_PROOFS/*` e as referências físicas.
6. **Mérito técnico.**
   - delta F-01 (cerca da entrada legada) e F-04 (pin dos fontes do launcher congelado);
   - 11 consumidores effectful;
   - STATE/CAS/checkpoints, TOCTOU e corrida de recibos;
   - G3/G6, SAFE_STOP e crash/resume;
   - falsa completude.

   Use a evidência fornecida. Repita testes apenas diante de achado material.

## 4. Proibições ao auditor

- Não executar nada no computador do titular nem em produção.
- Não executar B07, D4/D5, canário ou FULL.
- Não ler, baixar, comparar, autenticar nem validar a política MASTER/HEAD, a SPEC ou a captura normativa. A custódia é exclusiva da origem.
- Não usar crédito pago.
- Não reutilizar evidência V002 como prova do V003.

## 5. Limites conhecidos, declarados

- `physical_powerloss = NOT_TESTED_PHYSICAL_POWERLOSS`. O corte físico de energia foi dispensado; a recuperação após falha abrupta de processo é provada nativamente.
- A cerca de entrada legada (F-01) **não** está instalada em produção. A instalação é um passo operacional futuro e exige autorização da origem.
- A aprovação G5 do titular não é parecer B06.

## 6. Resultado esperado

Veredito B06 (`PASS`, `FAIL` ou `BLOCKED`), com achados classificados por severidade, devolvido à origem: ChatGPT, projeto Base de Dados CSV / Tickstore, conversa Compressão De Ticks 21.
