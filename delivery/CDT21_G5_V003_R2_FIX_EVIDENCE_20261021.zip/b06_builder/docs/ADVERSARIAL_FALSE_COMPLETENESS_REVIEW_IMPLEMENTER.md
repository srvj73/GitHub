# Revisão adversarial de falsa completude — implementador (não é B06)

**Autor:** implementador Opus 5.5. **Valor:** alegações a verificar pelo auditor independente.

Cada vetor abaixo aponta onde está a evidência física dentro deste pacote. Os valores numéricos estão em `CDT21_G5_V003_FINAL_ENGINEERING_RECEIPT.json` e `FIVE_PART_CHECKLIST.json`.

| Vetor de falsa completude | Como a evidência o fecha | Onde verificar |
|---|---|---|
| PASS do V002 transferido ao V003 | Commits, recibos e projeções exigem os SHA do código e do ZIP do V003. Controles negativos mostram que a evidência V002 é recusada (`SOURCE_BINDING`, `PRE_B06_CODE_BINDING`, `COMMITTED_INPUT_DRIFT`). | `05_ENGINEERING_EVIDENCE` (procedimento G5, validação Linux) |
| Rótulo PASS do supervisor sem prova | O montador ignora o rótulo e reexecuta o gate congelado e `close()` sobre o `R08_RETURN` | receipt final, `linux_recomputation_equal` |
| Unidades COMMITTED reexecutadas ou reaproveitadas de outra raiz | O `run_unit` congelado só reutiliza `COMMITS` da mesma raiz, com o mesmo pacote e código. O supervisor R2 registra `REUSE_COMMITTED` = os 5 COMMITs pré-existentes. | `SUPERVISOR_RESULT.json` (`resume`, `reused_committed_units`) |
| Tentativa falha apagada ou mascarada | A tentativa b2d é movida (não apagada) para `INTERRUPTED_ATTEMPTS`; os terminais anteriores são copiados para `PRIOR_TERMINAL_*`; o `R08_RETURN` anterior tem SHA registrado | `R08_RETURN.zip`, recibo `CDT21_SUPERVISOR_RESUME_*` |
| Código testado diferente do empacotado | `verify_package` congelado antes de cada unidade; F-04 fixa os fontes do launcher congelado | logs da campanha, `RUNTIME_CODE_MANIFEST` |
| Rota legada (F-01) contornando guards | Cerca exigida por `validate_d4_start`, pela guarda `AdmittedStart` e por cada commit de STATE admitido; testes `test_cdt21_f01_legacy_entry_fence.py` | candidato e evidência F-01/F-04 |
| TOCTOU, corrida de recibos e checkpoint | Quatro achados pré-B06 presos a linhas `... ok` de logs nativos selados | `FINAL_G5/FOUR_PRE_B06_FINDINGS.json` |
| 11 consumidores apenas declarados | Papel `PRE_B06_11_CHAIN` verificado por `verify_pre_b06_v002` (dossiê e evidência física) | `R08_RETURN.zip`, `EVIDENCE/PRE_B06` |
| G3/G6 sem causalidade | `verify_causal_projection` exige cenários `WORK/G3_G6_NATIVE` vinculados ao código e ao pacote | `R08_RETURN.zip` |
| Corte físico de energia alegado | Declarado `NOT_TESTED_PHYSICAL_POWERLOSS`; `POWERLOSS_EMULATED` com `counts_as=NOT_CHECKPOINT_POWERLOSS_RECOVERY` | recibos de prova |

**Limite desta revisão:** o autor é o implementador. A independência e o mérito cabem exclusivamente ao auditor B06 admitido pela origem.
