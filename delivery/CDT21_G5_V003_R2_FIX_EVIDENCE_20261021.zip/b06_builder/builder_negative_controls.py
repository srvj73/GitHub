"""Negative controls of the B06 dispatch builder using the REAL blocked native return.

Usage: builder_negative_controls.py <builder.py> <collected_G5RUN_2_dir> <base_config.json> <work> <out_json>
"""
import hashlib, io, json, shutil, subprocess, sys, zipfile
from pathlib import Path

builder, run2, base_cfg, work, out = map(Path, sys.argv[1:6])
H = lambda b: hashlib.sha256(b).hexdigest().upper()
cfg0 = json.loads(base_cfg.read_text())
shutil.rmtree(work, ignore_errors=True); work.mkdir(parents=True)
results = {}


def mkzip(path, members):
    with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED) as z:
        for n, b in members.items():
            z.writestr(n, b)


def run(tag, enviar, expect_substr, test_assembly=False):
    cfg = dict(cfg0, enviar=str(enviar), out_dir=str(work / ('OUT_' + tag)), test_assembly_only=test_assembly)
    cp = work / ('cfg_' + tag + '.json'); cp.write_text(json.dumps(cfg))
    r = subprocess.run([sys.executable, '-I', '-B', str(builder), str(cp)], capture_output=True, text=True, timeout=1200)
    blocked = Path(cfg['out_dir']) / 'NOT_READY_SINGLE_BLOCKER.json'
    reason = json.loads(blocked.read_text())['BLOCKER'] if blocked.exists() else (r.stdout.strip() + r.stderr.strip()[-300:])
    ready = (Path(cfg['out_dir']) / 'CDT21_V003_B06_INDEPENDENT_DISPATCH_READY.zip').exists()
    ok = (expect_substr in reason) and not ready
    results[tag] = {'status': 'PASS' if ok else 'FAIL', 'exit': r.returncode, 'reason': reason[:400], 'ready_zip_created': ready}
    print(('PASS ' if ok else 'FAIL ') + tag + ' exit=' + str(r.returncode) + ' ' + reason[:150], flush=True)
    return cfg


sr_raw = (run2 / 'SUPERVISOR_RESULT.json').read_bytes(); ret_raw = (run2 / 'CDT21_G5_V003_RETURN.zip').read_bytes()
log_raw = (run2 / 'RUN_LOG.txt').read_bytes()

# A. Genuine BLOCKED return from the 21:06 native run.
genuine = work / 'ENVIAR_GENUINE_BLOCKED.zip'
mkzip(genuine, {'RUN_LOG.txt': log_raw, 'SUPERVISOR_RESULT.json': sr_raw, 'CDT21_G5_V003_RETURN.zip': ret_raw})
run('A_genuine_blocked_return', genuine, 'supervisor_identity_r2')

# B. Forged PASS label over the same blocked evidence (supervisor fields only).
sr = json.loads(sr_raw)
sr.update(supervisor_sha256=cfg0['supervisor_r2_sha256'], status='PASS_NATIVE_V003_G5_TECHNICAL_FIVE_PART', exit_code=0,
          mode='RESUME', resume_reuse_exact=True, resume={'committed_before': [
              'G5_D4_REAL_ISOLATED_PATH_NATIVE', 'G5_PS51_INSTALL_MENU', 'G5_STAGE_B_REAL_ISOLATED_PATH_NATIVE',
              'SUITE_test_cdt17_final_g5_complete_proof_gate.py', 'SUITE_test_cdt18_stage_proof_integrated_reconcile.py']},
          reused_committed_units=['G5_D4_REAL_ISOLATED_PATH_NATIVE', 'G5_PS51_INSTALL_MENU', 'G5_STAGE_B_REAL_ISOLATED_PATH_NATIVE',
                                  'SUITE_test_cdt17_final_g5_complete_proof_gate.py', 'SUITE_test_cdt18_stage_proof_integrated_reconcile.py'],
          newly_committed_units=[], blockers=[])
forged_b = work / 'ENVIAR_FORGED_LABEL.zip'
mkzip(forged_b, {'SUPERVISOR_RESULT.json': json.dumps(sr).encode(), 'CDT21_G5_V003_RETURN.zip': ret_raw})
run('B_forged_pass_label', forged_b, 'excluded_duplicates_identity')

# C. Forged label AND forged return index: only the frozen gate stands between the label and READY.
with zipfile.ZipFile(io.BytesIO(ret_raw)) as z:
    members = {n: z.read(n) for n in z.namelist()}
idx = json.loads(members['RETURN_INDEX.json'])
idx['excluded_duplicates'] = [{'member': 'FINAL_G5/INPUTS/FINAL_PACKAGE.zip', 'sha256': cfg0['candidate_sha256']},
                              {'member': 'FINAL_G5/INPUTS/NATIVE_RETURN.zip', 'sha256': H(members['R08_RETURN.zip'])}]
members['RETURN_INDEX.json'] = json.dumps(idx).encode()
buf = io.BytesIO()
with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
    for n, b in members.items():
        z.writestr(n, b)
ret2 = buf.getvalue()
sr2 = dict(sr, return_sha256=H(ret2))
forged_c = work / 'ENVIAR_FORGED_LABEL_AND_INDEX.zip'
mkzip(forged_c, {'SUPERVISOR_RESULT.json': json.dumps(sr2).encode(), 'CDT21_G5_V003_RETURN.zip': ret2})
run('C_forged_label_and_index_stopped_by_frozen_gate', forged_c, 'NATIVE_G5_RUN_NOT_PASS')

# D. Test-only assembly mechanics (never READY, never delivered).
cfgd = run('D_test_assembly_only_not_ready', genuine, 'TEST_ASSEMBLY_ONLY_NOT_FOR_DISPATCH', test_assembly=True)
tz = Path(cfgd['out_dir']) / 'TEST_ASSEMBLY_ONLY_NOT_FOR_DISPATCH.zip'
if tz.exists():
    with zipfile.ZipFile(tz) as z:
        names = z.namelist(); man = json.loads(z.read('DISPATCH_MANIFEST.json'))
        okd = z.testzip() is None and man['status'] == 'TEST_ASSEMBLY_ONLY_NOT_FOR_DISPATCH' and all(
            H(z.read(m['path'])) == m['sha256'] for m in man['members'])
    results['D_test_assembly_only_not_ready'] = {'status': 'PASS' if okd else 'FAIL', 'members': len(names),
                                                 'manifest_status': man['status']}
    print(('PASS ' if okd else 'FAIL ') + 'D_assembly_manifest_hashes members=' + str(len(names)))

summary = {'schema': 'CDT21_B06_BUILDER_NEGATIVE_CONTROLS_V001', 'builder_sha256': H(builder.read_bytes()),
           'source_native_return_sha256': '5835A84122E0CC455C4217FB85A6D96E11F4CB0A6D7F33FFAC35B9CC357502EF',
           'results': results, 'passed': sum(v['status'] == 'PASS' for v in results.values()), 'total': len(results)}
out.write_text(json.dumps(summary, indent=1, sort_keys=True) + '\n')
print('PASSED', summary['passed'], '/', summary['total'])
sys.exit(0 if summary['passed'] == summary['total'] else 1)
