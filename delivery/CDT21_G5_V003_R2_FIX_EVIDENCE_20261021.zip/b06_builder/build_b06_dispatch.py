"""Fail-closed builder of the CDT21 V003 B06 independent-audit dispatch package.

Verifies the native G5 return with FROZEN V003 code (gate + a full re-execution of
PRE_G06_COMPLETENESS.close on the same native return), and only then assembles
READY_FOR_ORIGIN_B06_DISPATCH. It never writes a PASS of its own: every PASS it
reports is the output of frozen V003 functions or a byte/hash comparison.

Usage: build_b06_dispatch.py <config.json>
config keys: enviar, v003, g0_return, g0_origin_receipt, owner_preflight_zip, attachments{name:path},
             v002_reference, docs_dir, out_dir, [test_assembly_only]
"""
import hashlib, io, json, os, shutil, sys, tempfile, zipfile
from pathlib import Path, PurePosixPath

PKG = '69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50'
CODE = 'D59BC4EE4F0D5C689335C8F478A0342CC0146930E3B0B44C707B6B95267B3953'
G0 = 'BADAF97EE6FFD7E7D3FCD812758288A4F0D3233239AED3A3969E175F61C1397C'
OWNER_PREFLIGHT_ZIP = '2A927C6C0F5F8F44BBCF36295A968BC1C2A04781C4E8E2FCEF1A695F14E8931D'
SUP_R2 = None  # filled from config (supervisor_r2_sha256)
COMMITTED_BEFORE = ['G5_D4_REAL_ISOLATED_PATH_NATIVE', 'G5_PS51_INSTALL_MENU', 'G5_STAGE_B_REAL_ISOLATED_PATH_NATIVE',
                    'SUITE_test_cdt17_final_g5_complete_proof_gate.py', 'SUITE_test_cdt18_stage_proof_integrated_reconcile.py']
H = lambda b: hashlib.sha256(b).hexdigest().upper()
CANON = lambda o: (json.dumps(o, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n').encode('utf-8')


class NotReady(RuntimeError):
    pass


def need(ok, why):
    if not ok:
        raise NotReady(why)


def zmembers(raw, label):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        need(z.testzip() is None, label + '_CRC')
        names = z.namelist()
        need(len(names) == len({n.casefold() for n in names}), label + '_DUPLICATE')
        for n in names:
            p = PurePosixPath(n)
            need(not p.is_absolute() and '..' not in p.parts and '\\' not in n and ':' not in n, label + '_UNSAFE:' + n)
        return {n: z.read(n) for n in names if not n.endswith('/')}


def verify(cfg, work):
    rep = {'checks': {}}
    def ok(k, v=True, d=''):
        rep['checks'][k] = {'status': 'PASS' if v else 'FAIL', 'detail': str(d)[:300]}
        need(v, k + ':' + str(d)[:200])
    v3 = Path(cfg['v003']).read_bytes(); ok('candidate_sha', H(v3) == PKG, H(v3))
    g0 = Path(cfg['g0_return']).read_bytes(); ok('g0_return_sha', H(g0) == G0, H(g0))
    g0r = json.loads(zmembers(g0, 'G0')['G0_RESULT.json'])
    ok('g0_result_bound_pass', g0r.get('status') == 'PASS_CDT21_F01_F04_G0_NATIVE' and g0r.get('final_zip_sha256') == PKG
       and g0r.get('code_manifest_sha256') == CODE)
    ok('owner_preflight_zip_sha', H(Path(cfg['owner_preflight_zip']).read_bytes()) == OWNER_PREFLIGHT_ZIP)
    own = json.loads(zmembers(Path(cfg['owner_preflight_zip']).read_bytes(), 'OWNER')['CDT21_G5_OWNER_APPROVAL_V003.json'])
    ok('owner_g5_approval_v003', own.get('decision') == 'APPROVED' and own.get('candidate_sha256') == PKG
       and own.get('runtime_code_manifest_sha256') == CODE)
    env = zmembers(Path(cfg['enviar']).read_bytes(), 'ENVIAR')
    ok('enviar_members', {'SUPERVISOR_RESULT.json', 'CDT21_G5_V003_RETURN.zip'} <= set(env), sorted(env))
    sr = json.loads(env['SUPERVISOR_RESULT.json'])
    rep['supervisor_result'] = {k: sr.get(k) for k in ('status', 'exit_code', 'phase', 'mode', 'run_id', 'campaign_status',
                                                        'owned_processes_at_end', 'resume_reuse_exact', 'supervisor_sha256',
                                                        'native_return_sha256', 'return_sha256', 'blockers')}
    ok('supervisor_identity_r2', sr.get('supervisor_sha256') == cfg['supervisor_r2_sha256'], sr.get('supervisor_sha256'))
    ok('supervisor_status_pass', sr.get('status') == 'PASS_NATIVE_V003_G5_TECHNICAL_FIVE_PART' and sr.get('exit_code') == 0,
       str(sr.get('status')) + ' ' + str(sr.get('blockers')))
    ok('supervisor_binding', sr.get('candidate_sha256') == PKG and sr.get('code_manifest_sha256') == CODE)
    ok('no_owned_orphans', sr.get('owned_processes_at_end') == 0)
    ok('resume_reused_5_committed_no_rerun', sr.get('mode') == 'RESUME' and sr.get('resume_reuse_exact') is True
       and sr.get('resume', {}).get('committed_before') == COMMITTED_BEFORE
       and sorted(sr.get('reused_committed_units', [])) == sorted(COMMITTED_BEFORE)
       and not set(sr.get('newly_committed_units', [])) & set(COMMITTED_BEFORE))
    ret_raw = env['CDT21_G5_V003_RETURN.zip']
    ok('return_zip_sha_matches_supervisor', H(ret_raw) == sr.get('return_sha256'))
    ret = zmembers(ret_raw, 'RETURN')
    idx = json.loads(ret['RETURN_INDEX.json'])
    ok('return_index_members', all(m['member'] in ret and H(ret[m['member']]) == m['sha256'] for m in idx['members']))
    ex = {e['member']: e for e in idx['excluded_duplicates']}
    native = ret['R08_RETURN.zip']
    ok('native_return_sha', H(native) == sr.get('native_return_sha256'))
    ok('excluded_duplicates_identity', ex.get('FINAL_G5/INPUTS/FINAL_PACKAGE.zip', {}).get('sha256') == PKG
       and ex.get('FINAL_G5/INPUTS/NATIVE_RETURN.zip', {}).get('sha256') == H(native))
    # Frozen V003 code, extracted fresh from the candidate bytes.
    ext = work / 'V003'; ext.mkdir()
    with zipfile.ZipFile(io.BytesIO(v3)) as z:
        z.extractall(ext)
    cand = ext / 'implementation_v001' / 'candidate'
    for f in ('full', 'control', 'adapter', 'g5proof'):
        sys.path.insert(0, str(cand / f))
    import FULL_G5_COMPLETE_PROOF_GATE as gate
    import G5_FINAL_COMPLETENESS_PRODUCER as producer
    import PRE_G06_COMPLETENESS as completeness
    need(Path(gate.__file__).resolve().is_relative_to(ext.resolve()), 'FROZEN_IMPORT_PATH')
    code, members = producer.verify_final_zip(cfg['v003']); ok('frozen_verify_final_zip', code == CODE)
    index = {r['path']: r for r in json.loads(members['implementation_v001/RUNTIME_CODE_MANIFEST.json'])['files']}
    result, units, nm = gate.verify_native_campaign(native, CODE, PKG, index, final_members=members)
    ok('frozen_verify_native_campaign', result.get('status') == 'PASS_NATIVE_INTEGRATED_PRE_B06' and len(result['tests']) == 31,
       result.get('status'))
    live = json.loads(nm['LIVE_STATUS.json'])
    rep['native'] = {'run_id': result.get('run_id'), 'roles': len(result['tests']), 'additional_tests': sorted(result['additional_tests']),
                     'live_committed_units': live.get('committed_units'), 'native_members': len(nm)}
    # Physical readback of the Windows FINAL_G5 inside the return.
    comp = json.loads(ret['FINAL_G5/ENGINEERING_COMPLETENESS.json'])
    ok('windows_completeness_binding', comp.get('status') == 'COMPLETE' and comp.get('code_manifest_sha256') == CODE
       and comp.get('final_package_sha256') == PKG and comp.get('native_g5_return_sha256') == H(native)
       and comp.get('known_blockers') == [] and comp.get('formal_audit_started') is False)
    by_sha = {}
    for n, b in ret.items():
        by_sha.setdefault(H(b), n)
    parts = {}
    for part, e in comp['five_part_completeness'].items():
        member = 'FINAL_G5/FIVE_PART_PROOFS/' + part + '.json'
        need(member in ret and H(ret[member]) == e['sha256'] and e['status'] == 'PASS', 'FIVE_PART_READBACK:' + part)
        proof = json.loads(ret[member])
        refs = {}
        for r in proof['evidence']:
            found = by_sha.get(r['sha256']) or ('EXCLUDED_DUPLICATE:FINAL_PACKAGE.zip' if r['sha256'] == PKG else None)
            need(found is not None, 'FIVE_PART_REFERENCE_NOT_IN_RETURN:' + part + ':' + r['role'])
            refs[r['role']] = {'sha256': r['sha256'], 'member': found}
        parts[part] = {'status': proof['status'], 'proof_sha256': e['sha256'], 'evidence': refs}
    ok('five_parts_pass_and_physically_present', len(parts) == 5 and all(p['status'] == 'PASS' for p in parts.values()))
    fs = json.loads(ret['FINAL_G5/FINAL_ENGINEERING_STATUS.json'])
    ok('final_engineering_status', fs.get('engineering_five_part_completeness') == 'PASS'
       and fs.get('four_pre_b06_findings') == 'PASS_NATIVE_REGRESSION' and fs.get('independent_b06_audit') is False
       and fs.get('g5') == 'NOT_ISSUED' and fs.get('b06') == 'NOT_STARTED')
    four = json.loads(ret['FINAL_G5/FOUR_PRE_B06_FINDINGS.json'])
    ok('four_findings_pass', set(four['findings']) == set(completeness.FINDINGS)
       and all(v['status'] == 'PASS_NATIVE_REGRESSION' for v in four['findings'].values()))
    # Independent re-execution of the frozen close() on the same native return (Linux).
    rev = [n for n in ret if n.startswith('SOURCE_REVIEW/')]
    need(len(rev) == 1, 'SOURCE_REVIEW_MEMBER')
    lroot = work / 'RECOMPUTE' / result['run_id']; lroot.mkdir(parents=True)
    (work / 'native.zip').write_bytes(native); (work / 'review.json').write_bytes(ret[rev[0]])
    closed = completeness.close(cfg['v003'], str(work / 'native.zip'), str(work / 'review.json'), str(lroot))
    ok('linux_recomputed_close_pass', closed.get('engineering_five_part_completeness') == 'PASS'
       and closed.get('four_pre_b06_findings') == 'PASS_NATIVE_REGRESSION')
    same = {}
    for name in ('G5_EVIDENCE_PACK.json', 'G5_STAGE_COMPLETENESS.json', 'G5_INTEGRATION_MANIFEST.json', 'G5_INTEGRATION_SOURCE.py',
                 'FOUR_PRE_B06_FINDINGS.json', 'INPUTS/ADVERSARIAL.json'):
        same[name] = (lroot / 'FINAL_G5' / name).read_bytes() == ret['FINAL_G5/' + name]
    lcomp = json.loads((lroot / 'FINAL_G5' / 'ENGINEERING_COMPLETENESS.json').read_bytes())
    for part in parts:
        lp = json.loads(Path(lcomp['five_part_completeness'][part]['path']).read_bytes())
        lroles = {r['role']: r['sha256'] for r in lp['evidence'] if r['role'] != 'ADVERSARIAL_CLOSURE'}
        wroles = {k: v['sha256'] for k, v in parts[part]['evidence'].items() if k != 'ADVERSARIAL_CLOSURE'}
        same['five_part:' + part] = lroles == wroles and lp['status'] == 'PASS'
    rep['linux_recomputation_equal'] = same
    ok('linux_recomputation_matches_windows', all(same.values()), [k for k, v in same.items() if not v])
    rep['five_parts'] = parts
    return rep, sr, ret, env


def assemble(cfg, rep, sr, ret, env, out, ready):
    pkg_dir = out / 'CDT21_V003_B06_INDEPENDENT_DISPATCH_READY'
    pkg_dir.mkdir(parents=True)
    rows = []
    def put(rel, raw, role):
        p = pkg_dir / rel; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(raw)
        rows.append({'path': rel, 'sha256': H(raw), 'bytes': len(raw), 'role': role})
    put('01_CANDIDATE_V003/CDT21_FINAL_PACKAGE_V003_20261020.zip', Path(cfg['v003']).read_bytes(), 'CANDIDATE_EXACT_BYTES')
    put('02_G0_NATIVE_V003/CDT21_F01_G0_RETURN.zip', Path(cfg['g0_return']).read_bytes(), 'G0_NATIVE_PRIMARY')
    put('02_G0_NATIVE_V003/CDT21_ORIGEM_RECIBO_G0_V003_RECONCILIADO_20261020.json', Path(cfg['g0_origin_receipt']).read_bytes(), 'G0_ORIGIN_RECONCILIATION')
    for n, b in sorted(env.items()):
        put('03_G5_NATIVE_V003/' + n, b, 'G5_NATIVE_PRIMARY')
    put('04_OWNER_G5_APPROVAL_V003/' + Path(cfg['owner_preflight_zip']).name, Path(cfg['owner_preflight_zip']).read_bytes(), 'OWNER_G5_APPROVAL')
    for name, path in sorted(cfg['attachments'].items()):
        put('05_ENGINEERING_EVIDENCE/' + name, Path(path).read_bytes(), 'IMPLEMENTER_ENGINEERING_EVIDENCE')
    put('06_HISTORICAL_V002_REFERENCE_ONLY/' + Path(cfg['v002_reference']).name, Path(cfg['v002_reference']).read_bytes(),
        'HISTORICAL_V002_NOT_V003_EVIDENCE')
    for p in sorted(Path(cfg['docs_dir']).iterdir()):
        put(p.name, p.read_bytes(), 'DISPATCH_INSTRUCTION_OR_TEMPLATE')
    status = 'READY_FOR_ORIGIN_B06_DISPATCH' if ready else 'TEST_ASSEMBLY_ONLY_NOT_FOR_DISPATCH'
    receipt = {'schema': 'CDT21_G5_V003_FINAL_ENGINEERING_RECEIPT_V002', 'status': 'PASS_NATIVE_V003_G5_TECHNICAL_FIVE_PART' if ready else status,
               'candidate_sha256': PKG, 'code_manifest_sha256': CODE, 'candidate_completeness': 'PASS' if ready else 'NOT_EVALUATED',
               'verification': rep, 'tested_code_equals_packaged_code': 'PASS (frozen verify_package in every unit + verify_final_zip)' if ready else None,
               'physical_powerloss': 'NOT_TESTED_PHYSICAL_POWERLOSS', 'independent_b06_audit': False, 'b06': 'NOT_STARTED',
               'b07': 'NOT_STARTED', 'd4_d5': 'NOT_STARTED', 'canary': 'NOT_STARTED', 'full': 'NOT_STARTED',
               'issuer': 'IMPLEMENTER_ENGINEERING_RECEIPT_NOT_AUDIT'}
    put('CDT21_G5_V003_FINAL_ENGINEERING_RECEIPT.json', CANON(receipt), 'ENGINEERING_RECEIPT')
    checks = rep.get('checks', {})
    matrix = {'schema': 'CDT21_B06_DISPATCH_ADMISSION_MATRIX_V002', 'candidate_sha256': PKG, 'self_approval': False,
              'overall': 'READY_FOR_ORIGIN_B06_DISPATCH' if ready else 'TEST_ASSEMBLY_ONLY_NOT_FOR_DISPATCH',
              'items': [{'item': k, 'status': v['status'] if isinstance(v, dict) else str(v), 'basis': 'builder verification (frozen V003 code / hash)'}
                        for k, v in sorted(checks.items())] +
                       [{'item': 'policy_custody_and_live_revalidation', 'status': 'ORIGIN_ONLY', 'basis': 'not read by implementer or auditor'},
                        {'item': 'auditor_independence', 'status': 'ORIGIN_TO_ADMIT', 'basis': 'INDEPENDENCE_PRE_DISPATCH issued by origin'},
                        {'item': 'formal_audit_dispatch', 'status': 'ORIGIN_DECISION', 'basis': 'implementer cannot dispatch or audit'},
                        {'item': 'physical_powerloss', 'status': 'NOT_TESTED_PHYSICAL_POWERLOSS', 'basis': 'dispensed; process-crash recovery native'}],
              'b06': 'NOT_STARTED'}
    put('B06_DISPATCH_ADMISSION_MATRIX.json', CANON(matrix), 'ADMISSION_MATRIX')
    put('FIVE_PART_CHECKLIST.json', CANON({'schema': 'CDT21_V003_FIVE_PART_CHECKLIST_V001', 'parts': rep.get('five_parts'),
                                           'linux_recomputation_equal': rep.get('linux_recomputation_equal')}), 'FIVE_PART_CHECKLIST')
    manifest = {'schema': 'CDT21_V003_B06_DISPATCH_MANIFEST_V001', 'status': status, 'candidate_sha256': PKG,
                'code_manifest_sha256': CODE, 'members': rows, 'b06': 'NOT_STARTED',
                'dispatch_decision': 'ORIGIN_ONLY', 'auditor_independence': 'TO_BE_PROVEN_BY_AUDITOR_AND_ADMITTED_BY_ORIGIN'}
    (pkg_dir / 'DISPATCH_MANIFEST.json').write_bytes(CANON(manifest))
    zpath = out / ('CDT21_V003_B06_INDEPENDENT_DISPATCH_READY.zip' if ready else 'TEST_ASSEMBLY_ONLY_NOT_FOR_DISPATCH.zip')
    with zipfile.ZipFile(zpath, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(pkg_dir.rglob('*')):
            if p.is_file():
                rel = p.relative_to(pkg_dir).as_posix()
                zi = zipfile.ZipInfo(rel, (2026, 10, 21, 12, 0, 0)); zi.external_attr = 0o644 << 16
                zi.compress_type = zipfile.ZIP_STORED if rel.endswith('.zip') else zipfile.ZIP_DEFLATED
                z.writestr(zi, p.read_bytes())
    with zipfile.ZipFile(zpath) as z:
        need(z.testzip() is None, 'DISPATCH_ZIP_CRC')
    raw = zpath.read_bytes()
    witness = {'schema': 'CDT21_V003_B06_DISPATCH_WITNESS_V001', 'status': status, 'archive': zpath.name,
               'archive_sha256': H(raw), 'archive_bytes': len(raw), 'manifest_sha256': H(CANON(manifest)),
               'candidate_sha256': PKG, 'members': len(rows) + 1,
               'result_return_to': 'ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 21'}
    (out / ('WITNESS_' + zpath.stem + '.json')).write_bytes(CANON(witness))
    return zpath, witness


def main():
    cfg = json.loads(Path(sys.argv[1]).read_text())
    out = Path(cfg['out_dir']); need(not out.exists(), 'OUT_EXISTS'); out.mkdir(parents=True)
    with tempfile.TemporaryDirectory() as td:
        work = Path(td)
        try:
            rep, sr, ret, env = verify(cfg, work)
            ready = True
        except NotReady as exc:
            if not cfg.get('test_assembly_only'):
                blocked = {'schema': 'CDT21_NOT_READY_SINGLE_BLOCKER_V002', 'status': 'NOT_READY_FOR_ORIGIN_B06_DISPATCH',
                           'BLOCKER': str(exc), 'b06': 'NOT_STARTED', 'candidate_sha256': PKG}
                (out / 'NOT_READY_SINGLE_BLOCKER.json').write_bytes(CANON(blocked))
                print('NOT_READY', exc); return 1
            rep, sr, ret, env, ready = {'checks': {'verification': 'SKIPPED_TEST_ASSEMBLY_ONLY:' + str(exc)}}, {}, {}, \
                zmembers(Path(cfg['enviar']).read_bytes(), 'ENVIAR'), False
        zpath, w = assemble(cfg, rep, sr, ret, env, out, ready)
        print(w['status'], zpath.name, w['archive_sha256'], w['archive_bytes'])
    return 0 if ready else 3


if __name__ == '__main__':
    sys.exit(main())
