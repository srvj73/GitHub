"""Generate RUN_CDT21_G5_V003_RESUME_R2_20261021.ps1 (ASCII, CRLF) with SHA-pinned embedded payloads."""
import base64, hashlib, sys
from pathlib import Path

sup, review, out = map(Path, sys.argv[1:4])
H = lambda b: hashlib.sha256(b).hexdigest().upper()
B = lambda b: '\n'.join(base64.b64encode(b).decode()[i:i + 100] for i in range(0, len(base64.b64encode(b)), 100))
sup_raw, rev_raw = sup.read_bytes(), review.read_bytes()
T = r"""#requires -Version 5.1
# TICKSTORE CDT21 - RETOMADA R2 da campanha nativa G5 do V003 na MESMA raiz (preserva as 5 unidades COMMITTED).
# Causa da parada anterior: o supervisor R1 extraiu o pacote em <raiz>\PACKAGED; a suite congelada
# test_b2d_origin_decision_binder.py exige ...\CURRENT_G5_DELTA_*\EXTRACTED\implementation_v001 no Windows.
# O supervisor R2 (embutido, SHA fixado) corrige somente esse layout; o V003 nao e alterado.
# Execute a partir de PS C:\Users\silvi> em PowerShell 5.1 (autoeleva por UAC quando necessario):
#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\silvi\Downloads\RUN_CDT21_G5_V003_RESUME_R2_20261021.ps1" -AutorizoLabD
# Pre-requisito: C:\Users\silvi\Downloads\CDT21_FINAL_PACKAGE_V003_20261020.zip
# Log sempre em pasta absoluta fixa, nova a cada execucao, independente da pasta atual:
#   C:\Users\silvi\Downloads\CDT21_G5_V003_RUNS\G5R2_<yyyyMMdd_HHmmss_fff_PID>\RUN_LOG.txt (pai) e RUN_LOG_ELEVATED.txt (filho)
# Efeitos: somente laboratorio proprio (C:\Users\silvi\AppData\Local\CDT20_R08\<raiz>, C:\Users\silvi\AppData\Local\CDT21_G5_V003,
# D:\TICKSTORE_CDT19_PRE_G06_LABS\<raiz>\WRITER_EFFECTFUL). Nenhuma escrita em D:\Base CSV. Sem B06/B07/D4/D5/canario/FULL.
# Parada segura: crie C:\Users\silvi\AppData\Local\CDT20_R08\R08_Q1_20261020210605_856fea523791\SAFE_STOP.request
[CmdletBinding()]
param([switch]$AutorizoLabD, [switch]$ElevatedChild, [string]$SharedLogDir = '')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$Thread = 'Compress' + [char]0x00E3 + 'o De Ticks 21'
$Downloads = 'C:\Users\silvi\Downloads'
$RunsDir = 'C:\Users\silvi\Downloads\CDT21_G5_V003_RUNS'
$PackageName = 'CDT21_FINAL_PACKAGE_V003_20261020.zip'
$ExpectedPackageSha = '69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50'
$Python = 'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe'
$ExpectedPythonSha = '4942B86A6597E5AEE0128DAA00050ED79BC21F6E709A78EB19CBFEB0C2F39AC9'
$RunId = 'R08_Q1_20261020210605_856fea523791'
$ResumeRoot = 'C:\Users\silvi\AppData\Local\CDT20_R08\' + $RunId
$DLab = 'D:\TICKSTORE_CDT19_PRE_G06_LABS\' + $RunId
$SupervisorName = 'CDT21_G5_V003_SUPERVISOR_R2.py'
$SupervisorSha = '@@SUP_SHA@@'
$ReviewName = 'CDT19_IMPLEMENTER_SOURCE_REVIEW_V003.json'
$ReviewSha = '@@REV_SHA@@'
$Stamp = (Get-Date).ToString('yyyyMMdd_HHmmss_fff') + '_' + $PID
$Utf8 = New-Object Text.UTF8Encoding($false)
if ($ElevatedChild) {
    $full = [IO.Path]::GetFullPath($SharedLogDir)
    if (-not $SharedLogDir -or -not $full.StartsWith($RunsDir + '\G5R2_', [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $full -PathType Container)) {
        throw ('SHARED_LOG_DIR_INVALID=' + $SharedLogDir)
    }
    $LogDir = $full
    $Log = Join-Path $LogDir 'RUN_LOG_ELEVATED.txt'
} else {
    $LogDir = Join-Path $RunsDir ('G5R2_' + $Stamp)
    New-Item -ItemType Directory -Path $LogDir -ErrorAction Stop | Out-Null
    $Log = Join-Path $LogDir 'RUN_LOG.txt'
}

$SupervisorB64 = @'
@@SUP_B64@@
'@
$ReviewB64 = @'
@@REV_B64@@
'@

function Log([string]$Line) {
    Write-Host $Line
    [IO.File]::AppendAllText($Log, $Line + "`r`n", $Utf8)
}
function ShaBytes([byte[]]$Bytes) {
    $h = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($h.ComputeHash($Bytes)).Replace('-', '') } finally { $h.Dispose() }
}
function Sha([string]$Path) {
    $s = [IO.File]::OpenRead($Path); $h = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($h.ComputeHash($s)).Replace('-', '') } finally { $h.Dispose(); $s.Dispose() }
}
function Unpack([string]$B64, [string]$Expected, [string]$Path) {
    $bytes = [Convert]::FromBase64String(($B64 -replace '\s', ''))
    if ((ShaBytes $bytes) -cne $Expected) { throw ('EMBEDDED_SHA_MISMATCH=' + $Path) }
    [IO.File]::WriteAllBytes($Path, $bytes)
    if ((Sha $Path) -cne $Expected) { throw ('EMBEDDED_READBACK_MISMATCH=' + $Path) }
    Log ('UNPACKED=' + $Path + ' SHA256=' + $Expected)
}

$code = 2
try {
    Log ('RESULT_CONTEXT=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=' + $Thread)
    Log ('RUN_LOG=' + $Log)
    Log ('LAUNCHER=' + $PSCommandPath + ' SHA256=' + (Sha $PSCommandPath))
    Log ('MODO=RETOMADA_R2_MESMA_RAIZ RAIZ=' + $ResumeRoot + ' COMMITTED_PRESERVADAS=5 (reuso pelo run_unit congelado)')
    Log 'ESCOPO=G5_TECNICO_V003; LABORATORIO_PROPRIO; PRODUCAO=NAO; B06=NOT_STARTED; B07=NOT_STARTED; D4_D5=NOT_STARTED; CANARIO=NAO; FULL=NAO'
    if ($PSVersionTable.PSEdition -ne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'WINDOWS_POWERSHELL_5_1_REQUIRED' }
    if (-not $AutorizoLabD) {
        throw ('AUTORIZACAO_LAB_D_AUSENTE: a retomada grava arquivos pequenos (ordem de centenas de KB) em ' + $DLab +
               '\WRITER_EFFECTFUL. Ha um incidente de perda de dados no D: ainda em diagnostico; execute de novo com -AutorizoLabD somente se aceitar essas gravacoes.')
    }
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($id)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        if ($ElevatedChild) { throw 'ELEVATION_REENTRY_GUARD: rights missing after RunAs' }
        $si = New-Object System.Diagnostics.ProcessStartInfo
        $si.FileName = Join-Path $PSHOME 'powershell.exe'
        $si.WorkingDirectory = 'C:\Users\silvi'
        $si.UseShellExecute = $true
        $si.Verb = 'runas'
        $si.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -AutorizoLabD -ElevatedChild -SharedLogDir "' + $LogDir + '"'
        Log ('UAC_REQUEST=YES LOG_COMPARTILHADO=' + $LogDir)
        $child = [System.Diagnostics.Process]::Start($si)
        if ($null -eq $child) { throw 'UAC_NO_CHILD_PROCESS' }
        try {
            Log ('ELEVATED_CHILD_PID=' + $child.Id + ' (log do filho: ' + (Join-Path $LogDir 'RUN_LOG_ELEVATED.txt') + ')')
            $deadline = [DateTime]::UtcNow.AddHours(4); $n = 0
            while (-not $child.WaitForExit(5000)) {
                $n++; if ($n % 6 -eq 0) { Log ('ELEVATED_CHILD_ACTIVE=YES PID=' + $child.Id) }
                if ([DateTime]::UtcNow -ge $deadline) { throw 'ELEVATED_CHILD_WAIT_TIMEOUT: sem encerramento automatico; inspecione o filho e os logs' }
            }
            $child.WaitForExit(); $child.Refresh()
            $code = [int]$child.ExitCode
            Log ('ELEVATED_CHILD_EXIT_CODE=' + $code)
        } finally { $child.Dispose() }
    } else {
        if (-not $env:LOCALAPPDATA) { throw 'LOCALAPPDATA_MISSING' }
        if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { throw ('PYTHON_MISSING=' + $Python) }
        if ((Sha $Python) -cne $ExpectedPythonSha) { throw 'PYTHON_SHA_MISMATCH' }
        $Package = Join-Path $Downloads $PackageName
        if (-not (Test-Path -LiteralPath $Package -PathType Leaf)) { throw ('PACKAGE_NOT_FOUND=' + $Package) }
        $packageSha = Sha $Package
        if ($packageSha -cne $ExpectedPackageSha) { throw ('PACKAGE_SHA_MISMATCH=' + $packageSha) }
        Log ('PACKAGE=' + $Package + ' SHA256_OK=' + $packageSha)
        if (-not (Test-Path -LiteralPath $ResumeRoot -PathType Container)) { throw ('RESUME_ROOT_NOT_FOUND=' + $ResumeRoot) }
        if (-not (Test-Path -LiteralPath $DLab -PathType Container)) { throw ('D_LAB_NOT_FOUND=' + $DLab) }
        $live = @(Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -and
                  ($_.CommandLine.IndexOf($RunId, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
                   $_.CommandLine.IndexOf('CDT21_G5_V003_SUPERVISOR', [StringComparison]::OrdinalIgnoreCase) -ge 0) })
        foreach ($p in $live) { Log ('LIVE_PROCESS=' + $p.ProcessId + ' ' + $p.Name + ' ' + $p.CommandLine) }
        if ($live.Count -gt 0) { throw 'LIVE_PROCESS_ON_RUN_ROOT: encerre a execucao anterior antes da retomada' }
        Log 'PROCESSOS_DA_EXECUCAO_ANTERIOR=0'
        $Stage = Join-Path $env:LOCALAPPDATA ('CDT21_G5_V003\STAGE_R2_' + $Stamp)
        if (Test-Path -LiteralPath $Stage) { throw 'STAGE_EXISTS' }
        New-Item -ItemType Directory -Path (Join-Path $Stage 'TEMP') -ErrorAction Stop | Out-Null
        $Supervisor = Join-Path $Stage $SupervisorName
        $Review = Join-Path $Stage $ReviewName
        Unpack $SupervisorB64 $SupervisorSha $Supervisor
        Unpack $ReviewB64 $ReviewSha $Review
        Log 'ETA=cerca de 12 a 14 min (33 unidades pendentes; base nativa V002 ~689 s + 1 unidade sem base + fechamento). Heartbeats abaixo.'
        $oldTemp = $env:TEMP; $oldTmp = $env:TMP
        $env:TEMP = Join-Path $Stage 'TEMP'; $env:TMP = $env:TEMP
        $oldPref = $ErrorActionPreference
        try {
            $ErrorActionPreference = 'Continue'
            & $Python -I -B $Supervisor --package $Package --review $Review --log-dir $LogDir --stage $Stage --resume-root $ResumeRoot --d-lab $DLab 2>&1 | ForEach-Object { Log ([string]$_) }
            $code = $LASTEXITCODE
        } finally {
            $ErrorActionPreference = $oldPref
            $env:TEMP = $oldTemp; $env:TMP = $oldTmp
        }
        foreach ($name in @('SUPERVISOR_RESULT.json', 'CDT21_G5_V003_RETURN.zip')) {
            $p = Join-Path $LogDir $name
            if (Test-Path -LiteralPath $p -PathType Leaf) { Log ('COLLECTED=' + $p + ' SHA256=' + (Sha $p)) } else { Log ('NOT_PRODUCED=' + $name) }
        }
        if ($code -eq 0) { Log 'G5_TECNICO_V003=PASS_NATIVE_V003_G5_TECHNICAL_FIVE_PART; B06=NOT_STARTED' }
        else { Log 'G5_TECNICO_V003=NAO_CONCLUIDO (ver SUPERVISOR_RESULT.json); B06=NOT_STARTED' }
    }
} catch {
    Log ('G5_R2_BLOCKED=' + $_.Exception.Message)
    $code = 2
} finally {
    Log ('EXIT_CODE=' + $code)
    if ($ElevatedChild) {
        Log 'FILHO_ELEVADO_CONCLUIDO (o processo pai empacota o retorno unico)'
    } else {
        $Send = Join-Path $LogDir ('ENVIAR_AO_OPUS_CDT21_G5_V003_R2_' + $Stamp + '.zip')
        try {
            Add-Type -AssemblyName System.IO.Compression
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            $zip = [IO.Compression.ZipFile]::Open($Send, [IO.Compression.ZipArchiveMode]::Create)
            try {
                foreach ($name in @('RUN_LOG.txt', 'RUN_LOG_ELEVATED.txt', 'SUPERVISOR_RESULT.json', 'CDT21_G5_V003_RETURN.zip')) {
                    $p = Join-Path $LogDir $name
                    if (Test-Path -LiteralPath $p -PathType Leaf) {
                        $level = [IO.Compression.CompressionLevel]::Optimal
                        if ($name.EndsWith('.zip')) { $level = [IO.Compression.CompressionLevel]::NoCompression }
                        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $p, $name, $level)
                    }
                }
            } finally { $zip.Dispose() }
            Log ('ENVIE_O_RETORNO=' + $Send)
            Log ('ENVIE_O_RETORNO_SHA256=' + (Sha $Send))
        } catch {
            Log ('ENVIAR_ZIP_FALHOU=' + $_.Exception.Message + ' (envie o conteudo de ' + $LogDir + ')')
        }
        Log ('Devolva este resultado ao Opus/ChatGPT, projeto Base de Dados CSV / Tickstore, conversa ' + $Thread + '. Anexe as evidencias e cole esta resposta.')
        Log ('RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=' + $Thread)
    }
}
exit $code
"""
text = (T.replace('@@SUP_SHA@@', H(sup_raw)).replace('@@REV_SHA@@', H(rev_raw))
        .replace('@@SUP_B64@@', B(sup_raw)).replace('@@REV_B64@@', B(rev_raw)))
assert '@@' not in text
raw = text.replace('\r\n', '\n').replace('\n', '\r\n').encode('ascii')
out.write_bytes(raw)
print(out.name, len(raw), H(raw), 'supervisor', H(sup_raw), 'review', H(rev_raw))
