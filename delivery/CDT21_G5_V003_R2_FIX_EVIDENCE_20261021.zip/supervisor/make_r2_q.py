"""Add the native Windows qualification phase (--qualify-only) to supervisor R2.

Applied after make_r2.py. Q performs no write in the run root or the D-lab; resume
(--resume-root) refuses to start without a PASS QUALIFICATION_RESULT of the same
supervisor bytes, run root and log directory.
"""
import sys
from pathlib import Path

src, dst = Path(sys.argv[1]), Path(sys.argv[2])
s = src.read_text(encoding='ascii')


def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (s.count(old), old[:90])
    s = s.replace(old, new)


rep('''D_LABS_NAME = 'TICKSTORE_CDT19_PRE_G06_LABS'
''', '''D_LABS_NAME = 'TICKSTORE_CDT19_PRE_G06_LABS'
QUAL_SCHEMA = 'CDT21_G5_V003_WINDOWS_QUALIFICATION_V001'
QUAL_MAX_AGE_S = 7200
FROZEN_LOG_ROOT = 'C:\\\\Users\\\\silvi\\\\OneDrive\\\\Downloads\\\\TICKSTORE_RUNS'  # hard-coded in frozen V003 (installer/RUN_LOG_FIXED)
''')

rep('''def volume_filesystem(drive_root):''', '''def tree_digest(base):
    """Read-only fingerprint of a tree: sorted (relpath, size, mtime_ns) of every entry, links not followed."""
    base = Path(base)
    if not base.exists():
        return {'exists': False}
    rows = []
    stack = [base]
    while stack:
        d = stack.pop()
        with os.scandir(d) as it:
            for e in it:
                st = e.stat(follow_symlinks=False)
                rel = Path(e.path).relative_to(base).as_posix()
                rows.append((rel, st.st_size if e.is_file(follow_symlinks=False) else -1, st.st_mtime_ns))
                if e.is_dir(follow_symlinks=False):
                    stack.append(Path(e.path))
    rows.sort()
    return {'exists': True, 'entries': len(rows), 'sha256': sha_bytes(json.dumps(rows).encode())}


def production_fingerprint():
    """Read-only: production base must be identical before and after any effect."""
    base = Path(PRODUCTION)
    fp = {'path': PRODUCTION, 'tree': tree_digest(base)}
    for key, parts in (('menu', ('Scripts', 'Biblioteca', 'MENU.py')), ('bat', ('Manuten\\u00e7\\u00e3o Base de Dados.bat',))):
        p = base.joinpath(*parts)
        fp[key] = sha_file(p) if p.is_file() else 'ABSENT'
    return fp


def reparse_free(path):
    """Every existing component of path must be a plain entry (no symlink, junction or reparse point)."""
    p = Path(os.path.abspath(path)); cur = Path(p.anchor)
    for part in p.parts[1:]:
        cur = cur / part
        if not os.path.lexists(cur):
            break
        st = os.lstat(cur)
        if os.path.islink(cur) or (getattr(st, 'st_file_attributes', 0) & 0x400):
            return False, str(cur)
    return True, ''


def path_isolation(roots):
    """Every planned write root: canonical, reparse-free, outside the production base."""
    rows = {}
    for label, (path, enforce) in roots.items():
        p = Path(os.path.abspath(path))
        anc = p
        while not anc.exists() and anc != anc.parent:
            anc = anc.parent
        canonical = os.path.normcase(os.path.realpath(str(anc))) == os.path.normcase(str(anc))
        free, where = reparse_free(p)
        outside = not os.path.normcase(str(p)).startswith(os.path.normcase(PRODUCTION))
        ok = canonical and free and outside
        rows[label] = {'path': str(p), 'canonical': canonical, 'reparse_free': free, 'reparse_at': where,
                       'outside_production': outside, 'enforced': enforce, 'status': 'PASS' if ok else ('FAIL' if enforce else 'REPORT_ONLY')}
    return rows


def checkpoint_consistency(root, committed):
    """Prior terminal receipts agree with the commits on disk (read-only)."""
    live = strict_json((root / 'LIVE_STATUS.json').read_bytes())
    require(sorted(live.get('commit_receipt_keys', [])) == sorted(committed), 'LIVE_STATUS_COMMIT_KEYS')
    require((root / 'R08_RETURN.zip').is_file(), 'PRIOR_R08_RETURN_MISSING')
    recorded = (root / 'R08_RETURN.sha256').read_text(encoding='ascii').split()[0]
    require(recorded == sha_file(root / 'R08_RETURN.zip'), 'PRIOR_R08_RETURN_SHA_FILE')
    require(strict_json((root / 'RETURN_LOCK_SCOPE.json').read_bytes()).get('run_id') == root.name, 'RETURN_LOCK_SCOPE_RUN')
    require((root / 'TEMP' / 'G0_HANDLE_IDENTITY.json').is_file(), 'TEMP_HANDLE_PROBE_MISSING')
    ia = root / 'INTERRUPTED_ATTEMPTS'
    return {'live_status_keys_equal_commits': True, 'prior_r08_return_sha256': recorded,
            'r08_partial_present': (root / 'R08_RETURN.zip.partial').exists(),
            'interrupted_attempts': sorted(p.name for p in ia.iterdir()) if ia.is_dir() else []}


def prior_processes_dead(root, dead):
    """Every process identity recorded by the prior run is dead or its PID reused (frozen R.dead)."""
    ids = {}
    for p in sorted((root / 'COMMITS').glob('*.json')):
        obj = strict_json(p.read_bytes())
        for ident in list(obj.get('owner') or []) + list(obj.get('observed_processes') or []):
            if isinstance(ident, dict) and type(ident.get('pid')) is int and type(ident.get('creation_filetime')) is int:
                ids[(ident['pid'], ident['creation_filetime'])] = {'pid': ident['pid'], 'creation_filetime': ident['creation_filetime']}
    for p in sorted((root / 'UNITS').glob('*/RESULT.json')):
        proc = strict_json(p.read_bytes()).get('process')
        if isinstance(proc, dict) and type(proc.get('pid')) is int and type(proc.get('creation_filetime')) is int:
            ids[(proc['pid'], proc['creation_filetime'])] = {'pid': proc['pid'], 'creation_filetime': proc['creation_filetime']}
    return [dict(dead(i), checked=True) for i in ids.values()]


def lock_probe(lock_path):
    """Read-only handle: the prior supervisor lock must be acquirable (then released at once)."""
    import msvcrt
    f = open(lock_path, 'rb')
    try:
        try:
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            return 'HELD_BY_ANOTHER_PROCESS'
        f.seek(0); msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        return 'ACQUIRED_AND_RELEASED'
    finally:
        f.close()


def native_b2d(extracted, temp, log_path):
    """Run the frozen b2d suite natively from one extraction layout (no edits)."""
    import subprocess
    tests = extracted / 'implementation_v001' / 'tests'
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith('PYTHON')}
    env.update(TEMP=str(temp), TMP=str(temp))
    r = subprocess.run([sys.executable, '-I', '-B', '-m', 'unittest', 'discover', '-s', str(tests),
                        '-p', 'test_b2d_origin_decision_binder.py', '-t', str(tests), '-v'],
                       cwd=str(temp), env=env, capture_output=True, text=True, timeout=900)
    out = (r.stdout or '') + (r.stderr or '')
    Path(log_path).write_text(out, encoding='utf-8')
    ran = re.findall(r'(?m)^Ran (\\d+) tests?', out)
    return {'exit': r.returncode, 'ran': int(ran[-1]) if ran else 0, 'ok': re.search(r'(?m)^OK\\s*$', out) is not None,
            'contract_not_met': out.count('G5_FIXTURE_RUNROOT_CONTRACT_NOT_MET'), 'log': str(log_path),
            'log_sha256': sha_file(log_path)}


def qualify_main(a):
    """Native Windows qualification of R2 before any effect on the run root or the D-lab."""
    global _console
    log_dir = Path(os.path.abspath(a.log_dir)); stage = Path(os.path.abspath(a.stage))
    started = time.time()
    q = {'schema': QUAL_SCHEMA, 'status': 'BLOCKED', 'supervisor_sha256': sha_file(__file__), 'candidate_sha256': PACKAGE_SHA,
         'code_manifest_sha256': CODE_SHA, 'log_dir': str(log_dir), 'checks': {}, 'blockers': [],
         'effects_on_run_root_or_d_lab': 'NONE_BY_DESIGN', 'b06': 'NOT_STARTED'}
    def ok(k, v, d=''):
        q['checks'][k] = {'status': 'PASS' if v else 'FAIL', 'detail': d}
        require(v, 'QUAL_' + k + ':' + str(d)[:200])
    code = 2
    try:
        _console = open(stage / 'SUPERVISOR_CONSOLE_QUALIFY.log', 'xb')
        emit('QUALIFY SUPERVISOR=' + str(Path(__file__)) + ' SHA256=' + q['supervisor_sha256'])
        ok('windows_python_admin', os.name == 'nt' and sys.version_info[:2] == (3, 14), sys.version.split()[0])
        import ctypes
        ok('elevated', bool(ctypes.WinDLL('shell32').IsUserAnAdmin()))
        package = Path(os.path.abspath(a.package))
        ok('package_sha', package.is_file() and sha_file(package) == PACKAGE_SHA)
        review_raw = Path(a.review).read_bytes(); validate_review(review_raw); ok('source_review_binding', True, sha_bytes(review_raw))
        local = os.environ.get('LOCALAPPDATA', '')
        ok('localappdata_canonical', bool(local) and '%' not in local and '~' not in local
           and os.path.normcase(os.path.realpath(local)) == os.path.normcase(os.path.abspath(local)), local)
        ok('volumes_ntfs', volume_filesystem(Path(local).drive + '\\\\') == 'NTFS' and volume_filesystem('D:\\\\') == 'NTFS')
        job = SupervisorJob(); ok('job_kill_on_close_nested', job.active() >= 1, job.active())
        root = Path(os.path.abspath(a.resume_root)); dlab = Path(os.path.abspath(a.d_lab))
        q.update(run_id=root.name, run_root=str(root), d_lab=str(dlab))
        before_root, before_dlab = tree_digest(root), tree_digest(dlab)
        prod_before = production_fingerprint(); q['production_fingerprint'] = prod_before
        stamp = time.strftime('%Y%m%d%H%M%S') + '_' + uuid.uuid4().hex[:6]; q['stamp'] = stamp
        ext = Path(local) / EXTRACT_HOME / (DELTA_PREFIX + 'QUAL_' + stamp) / 'EXTRACTED'
        ext.parent.parent.mkdir(exist_ok=True); ext.parent.mkdir()
        extract_package(package, ext); check_fixture_contract(ext)
        plan = plan_keys(ext)
        import PRE_G06_CAMPAIGN as campaign
        import FULL_CRASH_RECOVERY as R
        code_sha, _ = campaign.verify_package(package)
        ok('frozen_verify_package_fixed_layout', code_sha == CODE_SHA, str(ext))
        pre = resume_precheck(root, dlab, local, plan); q['resume'] = pre
        ok('resume_precheck_same_root', len(pre['committed_before']) == 5 and len(pre['pending']) == PLANNED_UNITS - 5,
           ','.join(pre['committed_before']))
        q['checkpoints'] = checkpoint_consistency(root, pre['committed_before']); ok('checkpoints_consistent', True)
        q['prior_processes'] = prior_processes_dead(root, R.dead); ok('prior_processes_dead', True, len(q['prior_processes']))
        q['campaign_lock'] = lock_probe(root / 'CAMPAIGN.lock')
        ok('campaign_lock_free', q['campaign_lock'] == 'ACQUIRED_AND_RELEASED', q['campaign_lock'])
        roots = {'run_root': (root, True), 'd_lab': (dlab, True), 'extract_home': (Path(local) / EXTRACT_HOME, True),
                 'stage': (stage, True), 'log_dir': (log_dir, True), 'run_temp': (root / 'TEMP', True),
                 'frozen_v003_log_root': (Path(FROZEN_LOG_ROOT), False)}
        q['write_roots'] = path_isolation(roots)
        ok('write_roots_isolated', all(r['status'] != 'FAIL' for r in q['write_roots'].values()),
           [k for k, r in q['write_roots'].items() if r['status'] == 'FAIL'])
        qtemp = ext.parent / 'QTEMP'; qtemp.mkdir()
        q['b2d_native_positive'] = native_b2d(ext, qtemp, log_dir / 'B2D_NATIVE_FIXED_LAYOUT.log')
        p = q['b2d_native_positive']
        ok('b2d_native_fixed_layout_29_ok', p['exit'] == 0 and p['ran'] == 29 and p['ok'] and p['contract_not_met'] == 0, p)
        neg = Path(local) / EXTRACT_HOME / ('QUAL_NEG_' + stamp) / root.name / 'PACKAGED'
        neg.parent.mkdir(parents=True); extract_package(package, neg)
        ntemp = neg.parent / 'QTEMP'; ntemp.mkdir()
        q['b2d_native_negative_r1_layout'] = native_b2d(neg, ntemp, log_dir / 'B2D_NATIVE_R1_LAYOUT.log')
        n = q['b2d_native_negative_r1_layout']
        ok('b2d_native_r1_layout_reproduces_failure', n['exit'] != 0 and n['ran'] == 29 and n['contract_not_met'] >= 29, n)
        ok('q_no_effect_on_run_root', tree_digest(root) == before_root)
        ok('q_no_effect_on_d_lab', tree_digest(dlab) == before_dlab)
        ok('production_unchanged_during_q', production_fingerprint() == prod_before)
        q['status'] = 'PASS_WINDOWS_QUALIFICATION'; code = 0
        emit('WINDOWS_QUALIFICATION=PASS CHECKS=' + str(len(q['checks'])))
    except BaseException as exc:
        q['blockers'].append(type(exc).__name__ + ':' + str(exc)); q['traceback'] = traceback.format_exc()
        emit('WINDOWS_QUALIFICATION_BLOCKED=' + q['blockers'][-1])
    finally:
        q['finished_epoch'] = time.time(); q['seconds'] = round(time.time() - started, 3)
        (log_dir / 'QUALIFICATION_RESULT.json').write_bytes(
            (json.dumps(q, sort_keys=True, indent=1, ensure_ascii=True) + '\\n').encode('ascii'))
        emit('QUALIFICATION_RESULT=' + str(log_dir / 'QUALIFICATION_RESULT.json') + ' SHA256=' +
             sha_file(log_dir / 'QUALIFICATION_RESULT.json') + ' EXIT_CODE=' + str(code))
        if _console is not None:
            _console.close(); _console = None
    return code


def require_qualification(path, log_dir, root):
    """Resume is admitted only after a PASS native qualification of these exact bytes, root and run."""
    q = strict_json(Path(path).read_bytes())
    require(q.get('schema') == QUAL_SCHEMA and q.get('status') == 'PASS_WINDOWS_QUALIFICATION', 'QUALIFICATION_NOT_PASS')
    require(q.get('supervisor_sha256') == sha_file(__file__), 'QUALIFICATION_OTHER_SUPERVISOR')
    require(q.get('run_root') == str(root) and q.get('log_dir') == str(log_dir), 'QUALIFICATION_OTHER_RUN')
    require(0 <= time.time() - float(q.get('finished_epoch', 0)) <= QUAL_MAX_AGE_S, 'QUALIFICATION_STALE')
    return {'qualification_sha256': sha_file(path), 'checks': len(q['checks']), 'production_fingerprint': q['production_fingerprint']}


def volume_filesystem(drive_root):''')

# arguments
rep('''    ap.add_argument('--resume-root', default='')
    ap.add_argument('--d-lab', default='')
    a = ap.parse_args(argv)''', '''    ap.add_argument('--resume-root', default='')
    ap.add_argument('--d-lab', default='')
    ap.add_argument('--qualify-only', action='store_true')
    ap.add_argument('--require-qualification', default='')
    a = ap.parse_args(argv)
    if a.qualify_only:
        return qualify_main(a)''')
rep('''        require(bool(a.resume_root) == bool(a.d_lab), 'RESUME_ARGS_PAIR')''',
    '''        require(bool(a.resume_root) == bool(a.d_lab), 'RESUME_ARGS_PAIR')
        require(not a.resume_root or bool(a.require_qualification), 'RESUME_REQUIRES_WINDOWS_QUALIFICATION')''')
# resume: verify the qualification and take the production fingerprint before any effect
rep('''            pre = resume_precheck(root, dlab, local, plan)
            result['resume'] = pre''', '''            result['qualification'] = require_qualification(a.require_qualification, log_dir, root)
            pre = resume_precheck(root, dlab, local, plan)
            result['resume'] = pre''')
rep('''        emit('D_LAB=' + str(dlab) + ' OWNER_IDENTICAL=YES WITNESS=' + str(witness))''',
    '''        result['production_fingerprint_before'] = production_fingerprint()
        if a.resume_root:
            require(result['production_fingerprint_before'] == result['qualification']['production_fingerprint'],
                    'PRODUCTION_CHANGED_SINCE_QUALIFICATION')
        emit('D_LAB=' + str(dlab) + ' OWNER_IDENTICAL=YES WITNESS=' + str(witness))''')
rep('''        native = root / 'R08_RETURN.zip'
        require(native.is_file(), 'R08_RETURN_NOT_SEALED')''', '''        result['production_fingerprint_after'] = production_fingerprint()
        require(result['production_fingerprint_after'] == result['production_fingerprint_before'], 'PRODUCTION_FINGERPRINT_CHANGED')
        native = root / 'R08_RETURN.zip'
        require(native.is_file(), 'R08_RETURN_NOT_SEALED')''')
# return also carries the qualification console
rep('''                   (stage / 'SUPERVISOR_CONSOLE.log', 'SUPERVISOR/SUPERVISOR_CONSOLE.log')):''',
    '''                   (stage / 'SUPERVISOR_CONSOLE.log', 'SUPERVISOR/SUPERVISOR_CONSOLE.log'),
                   (stage / 'SUPERVISOR_CONSOLE_QUALIFY.log', 'SUPERVISOR/SUPERVISOR_CONSOLE_QUALIFY.log')):''')
dst.write_text(s, encoding='ascii', newline='\n')
print('R2+Q written', len(s))
