"""Derive CDT21_G5_V003_SUPERVISOR_R2.py from the qualified R1 by exact, reviewable replacements."""
import sys
from pathlib import Path

src, dst = Path(sys.argv[1]), Path(sys.argv[2])
s = src.read_text(encoding='ascii')


def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (s.count(old), old[:80])
    s = s.replace(old, new)


rep('''"""CDT21 G5 V003 - minimal native supervisor for the frozen PRE_G06 campaign.
''', '''"""CDT21 G5 V003 - minimal native supervisor for the frozen PRE_G06 campaign (R2).

R2 (2026-10-21) corrects one launcher obligation missed by R1 (7B482A4B):
the frozen suite tests/test_b2d_origin_decision_binder.py (D19EF3BA) requires,
on Windows, that the tested code be extracted at
<...>/CURRENT_G5_DELTA_<id>/EXTRACTED/implementation_v001. R1 extracted into
<run_root>/PACKAGED and the native run stopped with 29 x
G5_FIXTURE_RUNROOT_CONTRACT_NOT_MET. R2 extracts to
%LOCALAPPDATA%/CDT21_G5_V003/CURRENT_G5_DELTA_<stamp>/EXTRACTED and adds
--resume-root: the same run root is resumed so the frozen run_unit reuses its
COMMITTED units (REUSE_COMMITTED) and preserves interrupted ones.
''')
rep('''RESULT_SCHEMA = 'CDT21_G5_V003_SUPERVISOR_RESULT_V001'
''', '''RESULT_SCHEMA = 'CDT21_G5_V003_SUPERVISOR_RESULT_V002'
B2D_TEST_REL = 'implementation_v001/tests/test_b2d_origin_decision_binder.py'
B2D_TEST_SHA = 'D19EF3BA870D4065CFDF6C39B35EEB8D24CE9FAEF171E2C6806D9C4E7708DAA0'
EXTRACT_HOME = 'CDT21_G5_V003'
DELTA_PREFIX = 'CURRENT_G5_DELTA_'
D_LABS_NAME = 'TICKSTORE_CDT19_PRE_G06_LABS'
''')

# ------------------------------------------------------------------ new helpers (before volume_filesystem)
rep('''def volume_filesystem(drive_root):''', '''def fixture_extract_dir(local, stamp):
    """Layout required by the frozen b2d fixture: <...>/CURRENT_G5_DELTA_<id>/EXTRACTED."""
    return Path(local) / EXTRACT_HOME / (DELTA_PREFIX + stamp) / 'EXTRACTED'


def check_fixture_contract(extracted):
    # Same predicate as test_b2d_origin_decision_binder.setUp (Windows branch).
    impl = extracted / 'implementation_v001'
    parent = impl.parent.parent
    require(impl.parent.name == 'EXTRACTED' and parent.name.startswith(DELTA_PREFIX), 'FIXTURE_LAYOUT')
    require(os.path.normcase(os.path.realpath(str(parent))) == os.path.normcase(str(parent)), 'FIXTURE_LAYOUT_ALIAS')
    require(sha_file(extracted / B2D_TEST_REL) == B2D_TEST_SHA, 'B2D_TEST_SOURCE_SHA')


def plan_keys(extracted):
    """The 38 keys of the frozen PRE_G06_CAMPAIGN.main plan, read from frozen constants."""
    cand = extracted / 'implementation_v001' / 'candidate'
    for folder in ('full', 'control', 'adapter', 'g5proof'):
        p = str(cand / folder)
        if p not in sys.path:
            sys.path.insert(0, p)
    import FULL_G5_COMPLETE_PROOF_GATE as gate
    import PRE_G06_CAMPAIGN as campaign
    require(Path(campaign.__file__).resolve() == (extracted / CAMPAIGN_REL).resolve(), 'CAMPAIGN_IMPORT_PATH')
    plan = (['G5_' + n for n in ('PS51_INSTALL_MENU', 'STAGE_B_REAL_ISOLATED_PATH_NATIVE', 'D4_REAL_ISOLATED_PATH_NATIVE')] +
            ['SUITE_' + n for n in gate.SUITES if n not in campaign.STAGE_SUITES] +
            ['DELTA_' + n for n in campaign.EXTRA] + ['PRE_B06_11_CHAIN', 'G3_G6_NATIVE'])
    require(len(plan) == PLANNED_UNITS and len(set(plan)) == PLANNED_UNITS, 'PLAN_SHAPE')
    return plan


def resume_precheck(root, dlab, local, plan):
    """Read-only reconciliation of an interrupted V003 run root before resuming it."""
    root = Path(root); dlab = Path(dlab)
    require(root.is_dir() and not root.is_symlink() and not root.is_junction(), 'RESUME_ROOT_MISSING_OR_ALIAS')
    require(root.parent == Path(local) / RUN_PARENT and RUN_NAME.fullmatch(root.name) is not None, 'RESUME_ROOT_LOCATION')
    run_id = root.name
    boot = strict_json((root / 'CDT21_SUPERVISOR_BOOTSTRAP.json').read_bytes())
    require(boot.get('run_id') == run_id and boot.get('package_sha256') == PACKAGE_SHA
            and boot.get('code_manifest_sha256') == CODE_SHA, 'RESUME_BOOTSTRAP_BINDING')
    owner_raw = encoded(make_owner(run_id))
    require((root / 'OWNER.json').read_bytes() == owner_raw, 'RESUME_OWNER')
    require(dlab.name == run_id and dlab.parent.name == D_LABS_NAME and dlab.is_dir()
            and not dlab.is_symlink() and not dlab.is_junction(), 'RESUME_D_LAB')
    require((dlab / 'OWNER.json').read_bytes() == owner_raw, 'RESUME_D_LAB_OWNER')
    zips = sorted(p.name for p in (root / 'INPUTS').iterdir() if p.is_file() and p.suffix.lower() == '.zip')
    require(zips == [PACKAGE_NAME] and sha_file(root / 'INPUTS' / PACKAGE_NAME) == PACKAGE_SHA, 'RESUME_INPUT_PACKAGE')
    require((root / 'INPUTS' / WITNESS_NAME).read_bytes() == encoded(make_witness(run_id, MANIFEST_SHA)), 'RESUME_WITNESS')
    eng = strict_json((root / 'ENGINEERING_RESULT.json').read_bytes())
    require(eng.get('schema') == 'CDT19_PRE_B06_NATIVE_ENGINEERING_V002' and eng.get('run_id') == run_id
            and eng.get('status') in ('BLOCKED', 'SAFE_STOP') and eng.get('final_zip_sha256') == PACKAGE_SHA
            and eng.get('code_manifest_sha256') == CODE_SHA, 'RESUME_ENGINEERING_RESULT')
    require(not (root / 'SAFE_STOP.request').exists(), 'RESUME_SAFE_STOP_REQUEST_PRESENT')
    require((root / 'CAMPAIGN.lock').is_file() and (root / 'QUAL_C').is_dir() and (dlab / 'WRITER_EFFECTFUL').is_dir(),
            'RESUME_LAYOUT')
    committed, commit_sha = [], {}
    for p in sorted((root / 'COMMITS').glob('*.json')):
        obj = strict_json(p.read_bytes())
        require(p.stem in plan, 'RESUME_FOREIGN_COMMIT:' + p.stem)
        require(obj.get('schema') == 'CDT19_NATIVE_UNIT_COMMIT_V001' and obj.get('package_sha256') == PACKAGE_SHA
                and obj.get('code_sha256') == CODE_SHA and obj.get('result', {}).get('status') == 'PASS'
                and obj['result'].get('exit_code') == 0 and obj.get('own_descendants_final') == []
                and isinstance(obj.get('artifacts'), list) and bool(obj['artifacts']), 'RESUME_COMMIT_NOT_CLOSED:' + p.stem)
        for ref in obj['artifacts']:
            target = root.joinpath(*PurePosixPath(ref['member']).parts)
            require(target.is_file() and target.stat().st_size == ref['bytes'] and sha_file(target) == ref['sha256'],
                    'RESUME_COMMIT_ARTIFACT_DRIFT:' + p.stem + ':' + ref['member'])
        committed.append(p.stem); commit_sha[p.stem] = sha_file(p)
    pending = [k for k in plan if k not in committed]
    return {'run_id': run_id, 'prior_status': eng.get('status'), 'prior_blockers': eng.get('blockers'),
            'committed_before': committed, 'commit_file_sha256': commit_sha, 'pending': pending}


def preserve_prior_terminal(root, stage, stamp):
    """Copy (never move) the prior terminal receipts that the frozen campaign will overwrite."""
    keep = root / 'INTERRUPTED_ATTEMPTS' / ('PRIOR_TERMINAL_' + stamp)
    keep.mkdir(parents=True)
    copied = {}
    for name in ('ENGINEERING_RESULT.json', 'LIVE_STATUS.json', 'R08_RETURN.sha256', 'RETURN_LOCK_SCOPE.json'):
        if (root / name).is_file():
            raw = (root / name).read_bytes(); write_new(keep / name, raw); copied[name] = sha_bytes(raw)
    prior = {'schema': 'CDT21_PRIOR_TERMINAL_PRESERVATION_V001', 'run_id': root.name, 'copied': copied,
             'status': 'COPIED_NO_DELETE'}
    if (root / 'R08_RETURN.zip').is_file():
        z = root / 'R08_RETURN.zip'
        prior.update(prior_r08_return_sha256=sha_file(z), prior_r08_return_bytes=z.stat().st_size,
                     prior_r08_return_copy=str(stage / ('PRIOR_R08_RETURN_' + root.name + '.zip')))
        shutil.copyfile(z, stage / ('PRIOR_R08_RETURN_' + root.name + '.zip'))
        require(sha_file(stage / ('PRIOR_R08_RETURN_' + root.name + '.zip')) == prior['prior_r08_return_sha256'],
                'PRIOR_RETURN_COPY')
    write_new(keep / 'PRESERVATION.json', encoded(prior))
    return prior


def volume_filesystem(drive_root):''')

# ------------------------------------------------------------------ arguments and result fields
rep('''    for name in ('package', 'review', 'log-dir', 'stage'):
        ap.add_argument('--' + name, required=True)
    a = ap.parse_args(argv)''', '''    for name in ('package', 'review', 'log-dir', 'stage'):
        ap.add_argument('--' + name, required=True)
    ap.add_argument('--resume-root', default='')
    ap.add_argument('--d-lab', default='')
    a = ap.parse_args(argv)''')
rep('''        require(os.name == 'nt', 'WINDOWS_REQUIRED')
        require(sys.version_info[:2] == (3, 14)''', '''        require(bool(a.resume_root) == bool(a.d_lab), 'RESUME_ARGS_PAIR')
        require(os.name == 'nt', 'WINDOWS_REQUIRED')
        require(sys.version_info[:2] == (3, 14)''')
rep('''              'g5_owner_approval': 'APPROVED_EXPLICIT_V003_BY_ORIGIN_NOT_REQUESTED_AGAIN', 'blockers': []}''',
    '''              'g5_owner_approval': 'APPROVED_EXPLICIT_V003_BY_ORIGIN_NOT_REQUESTED_AGAIN', 'blockers': [],
              'mode': 'RESUME' if a.resume_root else 'NEW_RUN'}
    stamp = time.strftime('%Y%m%d%H%M%S') + '_' + uuid.uuid4().hex[:6]''')

# ------------------------------------------------------------------ bootstrap: fixture layout + resume branch
old_boot_start = '''        result['phase'] = 'BOOTSTRAP'
        run_id = 'R08_Q1_' + time.strftime('%Y%m%d%H%M%S') + '_' + uuid.uuid4().hex[:12]'''
i = s.index(old_boot_start); j = s.index('''        # ---------------------------------------------------------------- frozen campaign (child)''')
new_boot = '''        result['phase'] = 'BOOTSTRAP'
        packaged = fixture_extract_dir(local, stamp)
        (packaged.parent.parent).mkdir(exist_ok=True); plain_directory(packaged.parent.parent)
        packaged.parent.mkdir()
        files = extract_package(package, packaged)
        check_fixture_contract(packaged)
        manifest_sha = sha_file(packaged / 'PACKAGE_MANIFEST.json')
        require(manifest_sha == MANIFEST_SHA, 'PACKAGE_MANIFEST_SHA')
        require(sha_file(packaged / CAMPAIGN_REL) == CAMPAIGN_SHA, 'CAMPAIGN_SOURCE_SHA')
        require(sha_file(packaged / COMPLETENESS_REL) == COMPLETENESS_SHA, 'COMPLETENESS_SOURCE_SHA')
        plan = plan_keys(packaged)
        result['extracted'] = str(packaged)
        emit('EXTRACTED=' + str(packaged) + ' FILES=' + str(files) + ' BYTE_EXACT=YES FIXTURE_LAYOUT=CURRENT_G5_DELTA_EXTRACTED')
        import msvcrt
        if a.resume_root:
            root = Path(os.path.abspath(a.resume_root)); dlab = Path(os.path.abspath(a.d_lab))
            result.update(run_id=root.name, run_root=str(root))
            pre = resume_precheck(root, dlab, local, plan)
            result['resume'] = pre
            emit('RESUME_ROOT=' + str(root) + ' PRIOR_STATUS=' + str(pre['prior_status']))
            emit('COMMITTED_BEFORE=' + str(len(pre['committed_before'])) + ' ' + ','.join(pre['committed_before']))
            emit('PENDING=' + str(len(pre['pending'])))
            lock = open(root / 'CAMPAIGN.lock', 'r+b')
            try:
                msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                raise Blocked('CAMPAIGN_LOCK_HELD_BY_ANOTHER_PROCESS')
            run_id = root.name
            inputs_pkg = root / 'INPUTS' / PACKAGE_NAME
            witness = root / 'INPUTS' / WITNESS_NAME
            qual_c = root / 'QUAL_C'; qual_d = dlab / 'WRITER_EFFECTFUL'
            result['prior_terminal'] = preserve_prior_terminal(root, stage, stamp)
            resume = {'schema': 'CDT21_G5_V003_SUPERVISOR_RESUME_V001', 'run_id': run_id, 'stamp': stamp,
                      'package_sha256': PACKAGE_SHA, 'code_manifest_sha256': CODE_SHA,
                      'supervisor_sha256': result['supervisor_sha256'], 'extracted': str(packaged),
                      'fixture_layout': 'CURRENT_G5_DELTA_EXTRACTED', 'b2d_test_source_sha256': B2D_TEST_SHA,
                      'root_cause_of_prior_stop': 'R1 extracted to <run_root>/PACKAGED; frozen b2d fixture requires '
                                                  'CURRENT_G5_DELTA_*/EXTRACTED (29 x G5_FIXTURE_RUNROOT_CONTRACT_NOT_MET)',
                      'committed_before': pre['committed_before'], 'commit_file_sha256': pre['commit_file_sha256'],
                      'pending': pre['pending'], 'prior_terminal': result['prior_terminal'],
                      'python_sha256': sha_file(sys.executable), 'supervisor_pid': os.getpid(),
                      'campaign_lock': 'HELD_EXCLUSIVE_BYTE_RANGE', 'production_authorized': False, 'b06': 'NOT_STARTED'}
            write_new(root / ('CDT21_SUPERVISOR_RESUME_' + stamp + '.json'), encoded(resume))
        else:
            run_id = 'R08_Q1_' + time.strftime('%Y%m%d%H%M%S') + '_' + uuid.uuid4().hex[:12]
            require(RUN_NAME.fullmatch(run_id) is not None, 'RUN_NAME')
            run_parent.mkdir(exist_ok=True); plain_directory(run_parent)
            root = run_parent / run_id; root.mkdir()
            result.update(run_id=run_id, run_root=str(root))
            emit('RUN_ROOT=' + str(root))
            (root / 'TEMP').mkdir()
            (root / 'INPUTS').mkdir()
            inputs_pkg = root / 'INPUTS' / PACKAGE_NAME
            shutil.copyfile(package, inputs_pkg)
            require(sha_file(inputs_pkg) == PACKAGE_SHA, 'INPUT_PACKAGE_COPY')
            witness = root / 'INPUTS' / WITNESS_NAME
            write_new(witness, encoded(make_witness(run_id, manifest_sha)))
            owner_raw = encoded(make_owner(run_id))
            write_new(root / 'OWNER.json', owner_raw)
            d_labs.mkdir(exist_ok=True); plain_directory(d_labs)
            dlab = d_labs / run_id; dlab.mkdir()
            write_new(dlab / 'OWNER.json', owner_raw)
            qual_c = root / 'QUAL_C'; qual_d = dlab / 'WRITER_EFFECTFUL'
            qual_c.mkdir(); qual_d.mkdir()
            lock = open(root / 'CAMPAIGN.lock', 'x+b')
            lock.write(encoded({'schema': 'CDT21_G5_V003_CAMPAIGN_LOCK_V001', 'run_id': run_id,
                                'supervisor_pid': os.getpid()}))
            lock.flush(); os.fsync(lock.fileno()); lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            bootstrap = {'schema': 'CDT21_G5_V003_SUPERVISOR_BOOTSTRAP_V001', 'run_id': run_id,
                         'package_sha256': PACKAGE_SHA, 'code_manifest_sha256': CODE_SHA,
                         'package_manifest_sha256': manifest_sha, 'campaign_source_sha256': CAMPAIGN_SHA,
                         'completeness_source_sha256': COMPLETENESS_SHA,
                         'supervisor_sha256': result['supervisor_sha256'],
                         'source_review_sha256': result['source_review_sha256'],
                         'python': sys.version, 'python_executable': sys.executable,
                         'python_sha256': sha_file(sys.executable), 'localappdata': local,
                         'd_parent': str(dlab), 'temp': str(root / 'TEMP'), 'extracted': str(packaged),
                         'qual_c_parent': str(qual_c), 'qual_d_parent': str(qual_d),
                         'campaign_lock': 'HELD_EXCLUSIVE_BYTE_RANGE', 'supervisor_pid': os.getpid(),
                         'v002_commits_reused': 0, 'production_authorized': False, 'b06': 'NOT_STARTED'}
            write_new(root / 'CDT21_SUPERVISOR_BOOTSTRAP.json', encoded(bootstrap))
        emit('D_LAB=' + str(dlab) + ' OWNER_IDENTICAL=YES WITNESS=' + str(witness))
        emit('SAFE_STOP=' + str(root / 'SAFE_STOP.request') + ' (crie este arquivo para parada segura)')
'''
s = s[:i] + new_boot + s[j:]

# ------------------------------------------------------------------ campaign output: record reuse / commits
rep('''        def pump():
            for raw in iter(proc.stdout.readline, b''):
                emit(raw.decode('utf-8', 'replace').rstrip('\\r\\n'))''', '''        reused, committed_now = [], []
        def pump():
            for raw in iter(proc.stdout.readline, b''):
                line = raw.decode('utf-8', 'replace').rstrip('\\r\\n')
                if line.startswith('REUSE_COMMITTED '):
                    reused.append(line.split(' ', 1)[1])
                elif line.startswith('COMMITTED '):
                    committed_now.append(line.split(' ', 1)[1])
                emit(line)''')
rep('''        code = proc.returncode
        result['campaign_exit_code'] = code''', '''        code = proc.returncode
        result['campaign_exit_code'] = code
        result['reused_committed_units'] = sorted(reused)
        result['newly_committed_units'] = committed_now
        if a.resume_root:
            # The frozen run_unit reuses every closed commit; anything else would be a rerun.
            result['resume_reuse_exact'] = sorted(set(reused) & set(result['resume']['committed_before'])) == sorted(result['resume']['committed_before']) \\
                and not (set(committed_now) & set(result['resume']['committed_before']))''')
rep('''        require(code == 0 and engineering.get('status') == 'PASS_NATIVE_INTEGRATED_PRE_B06\'''',
    '''        require(not a.resume_root or result['resume_reuse_exact'], 'RESUME_COMMITTED_UNIT_NOT_REUSED')
        require(code == 0 and engineering.get('status') == 'PASS_NATIVE_INTEGRATED_PRE_B06\'''')

# ------------------------------------------------------------------ close: idempotent review copy
rep('''        review = root / 'SOURCE_REVIEW' / REVIEW_NAME
        review.parent.mkdir(); write_new(review, review_raw)''', '''        review = root / 'SOURCE_REVIEW' / REVIEW_NAME
        review.parent.mkdir(exist_ok=True)
        if review.exists():
            require(review.read_bytes() == review_raw, 'SOURCE_REVIEW_DRIFT')
        else:
            write_new(review, review_raw)''')
rep('''        for folder in ('full', 'control', 'adapter', 'g5proof'):  # same import roots as PRE_G06_CAMPAIGN
            sys.path.insert(0, str(packaged / 'implementation_v001/candidate' / folder))
''', '''        for folder in ('full', 'control', 'adapter', 'g5proof'):  # same import roots as PRE_G06_CAMPAIGN
            p = str(packaged / 'implementation_v001/candidate' / folder)
            if p not in sys.path:
                sys.path.insert(0, p)
''')

# ------------------------------------------------------------------ return: include resume receipts
rep('''    for name in ('R08_RETURN.zip', 'R08_RETURN.sha256', 'ENGINEERING_RESULT.json', 'LIVE_STATUS.json',
                 'OWNER.json', 'RETURN_LOCK_SCOPE.json', 'CDT21_SUPERVISOR_BOOTSTRAP.json'):
        if (root / name).is_file():
            picked.append((root / name, name))''', '''    for name in ['R08_RETURN.zip', 'R08_RETURN.sha256', 'ENGINEERING_RESULT.json', 'LIVE_STATUS.json',
                 'OWNER.json', 'RETURN_LOCK_SCOPE.json', 'CDT21_SUPERVISOR_BOOTSTRAP.json'] + \\
                sorted(p.name for p in root.glob('CDT21_SUPERVISOR_RESUME_*.json')):
        if (root / name).is_file():
            picked.append((root / name, name))''')
rep('''    for p, rel in ((stage / 'CDT21_G5_V003_SUPERVISOR.py', 'SUPERVISOR/CDT21_G5_V003_SUPERVISOR.py'),''',
    '''    for p, rel in ((stage / 'CDT21_G5_V003_SUPERVISOR_R2.py', 'SUPERVISOR/CDT21_G5_V003_SUPERVISOR_R2.py'),''')
dst.write_text(s, encoding='ascii', newline='\n')
print('R2 written', len(s))
