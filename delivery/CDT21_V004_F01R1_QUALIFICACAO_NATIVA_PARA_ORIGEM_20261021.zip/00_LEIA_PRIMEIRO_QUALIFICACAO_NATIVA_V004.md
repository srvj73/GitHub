# CDT21 V004 (F-01R1) — qualificação nativa Windows concluída

**Papel:** implementador. Este documento **não** é parecer B06 nem admissão. A custódia normativa permanece com a origem.

**Candidato:** V004 `AD33486954F1248AF28A78677377E83AB979AB86EDD5F71F5B7D108CBA8F99DD`, código `D2C626FD…66FF`.

**Parent congelado:** V003 `69DA2D59…7E50`, preservado.

## Execução nativa (titular, 21/10/2026, 11:57–11:59, horário local)

- **Runner:** `RUN_CDT21_F01R1_G0_V004_20261021.ps1` (`6A0F8A38…8B60`), PowerShell 5.1, autoelevado por UAC, CPython 3.14.7 fixado, NTFS.
- **Raiz própria:** `R08_Q1_20261021115755_fe67eb109c66`.
- **Pacote:** SHA conferido.
- **Contraste V003:** presente e com SHA conferido.

| Item | Valor |
|---|---|
| Retorno `ENVIAR_AO_OPUS_…115752_612_7352.zip` | `AB710D823DF0A2E755D1102AB5E56572828B2941D483DE02A4423E76D579ECA8` |
| `CDT21_F01R1_G0_RETURN.zip` | `789C6ACE4ABED4E33C4D146EEB5D254CDF5FC1864A2F5812206870ACE4D14E61` |
| `G0_RESULT.json` | `AA4F0A98C4FE32C9DBF9F4BCCDB34BD589DF097B95227AE331BF6F5986AB0ECF` |
| Status | `PASS_CDT21_F01R1_V004_G0_NATIVE`, exit 0 |

## Verificação independente (somente leitura; nada do retorno foi executado)

`02_VERIFICACAO/VERIFICAR_RETORNO_G0_V004.py` → `PASS_NATIVE_V004_G0_VERIFIED`, **39/39** checagens.

**Unidades.** São 12: as 11 do G0 do V003 e a suíte F-01R1. Somam **164 testes nativos**, com 0 pulos, 0 falhas e 0 órfãos. Cada commit está vinculado ao pacote e ao código do V004, e cada artefato teve o hash conferido.
- Rodaram nativamente o test_80, o test_07, o test_34 e o test_35.
- O test_80 cobre a ACE explícita de negação, o escritor admitido por backup semantics e a ausência de token de impersonação residual.
- O test_07 cobre o lançador mestre congelado em PS 5.1, bloqueado sem efeito.

**Mutações nativas.** Baseline PASS e **8/8 mortas**.
- **M2** recria o comportamento do V003. No Windows, o legado antigo voltou a acrescentar ao journal (`OK LOG`): o sintoma da B06 reaparece quando o corte é removido.
- **M5** mostra que até o processo admitido elevado recebe `PermissionError` com o `open` congelado: a ACE vale para administradores.
- **M3** foi morta pela asserção de motivo. O resultado mutado ainda bloqueou, porque a leitura de verificação também nega compartilhamento de escrita (defesa em profundidade).

**Cenário da origem nos fontes do V004, nativo:**

| Cenário | Decisão | Legado antigo | Journal e STATE | Nova instância | Diagnóstico após o fim do processo |
|---|---|---|---|---|---|
| A (reproducer verbatim) | `FENCE_PRESENT` | `PermissionError` em `STATE_JOURNAL.jsonl` | inalterados | bloqueada | — |
| B (nó em andamento) | `CUT_PRESENT_LEGACY_RUN_NOT_DRAINED` (exit 2) | `PermissionError` | inalterados | bloqueada | `FENCE_PRESENT` |

**Contraste V003, nativo.** Nos cenários A e B, `F01_LEGACY_ALREADY_INITIALIZED_NOT_STOPPED_BY_FENCE`: o journal mudou depois da cerca. No B, o legado gravou `FINISHED` antes de falhar no STATE.

**Controles negativos do verificador.**
- Um byte alterado no retorno: recusado (CRC).
- Retorno reempacotado com a M2 marcada como `SURVIVED`: recusado (`enviar_sha`, `mutations_native`, `return_sha_logged`).

## Conclusão de engenharia

| Item | Resultado |
|---|---|
| `F01R1_WINDOWS_QUALIFICATION_V004` | **PASS** |
| `TESTED_CODE_EQUALS_PACKAGED_CODE` | **PASS** (`verify_package` nativo, antes de cada unidade) |
| Recibo | de engenharia, não de auditoria |

**Os bytes do V004 não mudam.** O `CDT21_V004_ENGINEERING_COMPLETENESS.json` dentro do pacote continua dizendo "Windows pendente", porque foi congelado antes da execução. O PASS nativo fica registrado fora do pacote, neste documento e no retorno.

## Não alegado / próximos passos da origem

- **G5 de 38 unidades para o V004:** não executado. As 38/38 provam o V003, e o contrato congelado vincula o manifesto de código inteiro. A decisão de uma campanha G5 V004, ou de um escopo delimitado, é da origem.
- **B06, B07, D4/D5, canário, FULL e corte em produção:** não iniciados. A produção requer autorização expressa; ver `procedures/PROCEDIMENTO_CDT21_LEGACY_ENTRY_FENCE.md`.
- **Queda física de energia:** `NOT_TESTED_PHYSICAL_POWERLOSS`.
- **Admissão do V004 e despacho ao auditor independente:** cabem exclusivamente à origem.

RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 21
