"""CDT21 F-01R1 - independent read-only check of the native V004 qualification return.

Usage: python -I -B VERIFICAR_RETORNO_G0_V004.py <ENVIAR_AO_OPUS_CDT21_F01R1_G0_V004_*.zip>
Reads only; nothing from the return is executed.  Prints one JSON object; exit 0 only if every check passes.
"""
import hashlib
import io
import json
import re
import sys
import zipfile

ENVIAR_SHA = 'AB710D823DF0A2E755D1102AB5E56572828B2941D483DE02A4423E76D579ECA8'
PKG = 'AD33486954F1248AF28A78677377E83AB979AB86EDD5F71F5B7D108CBA8F99DD'
CODE = 'D2C626FD2819B86D472433CB2B26C6688B1688E5E5474402162B67C5048666FF'
V003 = '69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50'
LAUNCHER = '6A0F8A3801E70C15D99CAD6486D667A2C0874BD3C4738BBDB39583A6C28D8B60'
UNITS = {'CDT21R1_F01R1_PREEXISTING_LEGACY_CUT': 16, 'CDT21R1_F01_LEGACY_ENTRY_FENCE': 30, 'CDT21R1_SUITE_adapter_tests.py': 29,
         'CDT21R1_SUITE_test_state_cas_recovery.py': 11, 'CDT21R1_DELTA_test_cdt19_integrated_crash_recovery.py': 11,
         'CDT21R1_SUITE_test_operator_entry_points.py': 11, 'CDT21R1_SUITE_test_canary_receipt_readback.py': 13,
         'CDT21R1_SUITE_test_stage_canary_physical_publication.py': 7, 'CDT21R1_SUITE_test_stageb_full_physical_closure.py': 12,
         'CDT21R1_SUITE_test_cdt17_full_composition_scope.py': 15, 'CDT21R1_SUITE_test_legacy_entry_isolation.py': 9}
NATIVE_ONLY = ('test_80_native_deny_ace_backup_writer_and_no_lingering_privilege', 'test_07_native_master_launcher_blocked_without_effect',
               'test_34_native_pin_denies_write_rename_delete', 'test_35_native_frozen_launcher_hashes_and_executes_loader_under_pin')
H = lambda b: hashlib.sha256(b).hexdigest().upper()


def main(path):
    raw = open(path, 'rb').read()
    checks = {}
    c = lambda k, v: checks.__setitem__(k, bool(v))
    c('enviar_sha', H(raw) == ENVIAR_SHA)
    outer = zipfile.ZipFile(io.BytesIO(raw))
    c('enviar_crc', outer.testzip() is None)
    ret_raw = outer.read('CDT21_F01R1_G0_RETURN.zip')
    collected = outer.read('G0_RESULT.json')
    log = outer.read('RUN_LOG_ELEVATED.txt').decode('utf-8', 'replace')
    c('launcher_sha_logged', 'SHA256=' + LAUNCHER in log)
    c('package_sha_logged', 'SHA256_OK=' + PKG in log)
    c('return_sha_logged', 'CDT21_F01R1_G0_RETURN.zip SHA256=' + H(ret_raw) in log)
    c('exit_code_0_logged', 'CDT21_F01R1_G0=PASS_CDT21_F01R1_V004_G0_NATIVE EXIT_CODE=0' in log)
    inner = zipfile.ZipFile(io.BytesIO(ret_raw))
    c('return_crc', inner.testzip() is None)
    names = set(inner.namelist())
    res = json.loads(inner.read('G0_RESULT.json'))
    c('g0_result_equals_collected', inner.read('G0_RESULT.json') == collected)
    c('status_pass', res['status'] == 'PASS_CDT21_F01R1_V004_G0_NATIVE')
    c('bound_package_and_code', res['final_zip_sha256'] == PKG and res['code_manifest_sha256'] == CODE)
    c('scope_bounds', res['g5_38_units'] == 'NOT_RUN' and res['b06'] == 'NOT_STARTED' and res['production_modified'] is False
      and res['full_started'] is False)
    tests = 0
    for key, count in sorted(list(UNITS.items()) + [('CDT21R1_PRE_B06_11_CHAIN', None)]):
        o = json.loads(inner.read('COMMITS/' + key + '.json'))
        ok = (o['schema'] == 'CDT19_NATIVE_UNIT_COMMIT_V001' and o['package_sha256'] == PKG and o['code_sha256'] == CODE
              and o['result']['status'] == 'PASS' and o['result']['exit_code'] == 0 and o['result'].get('native_windows') is True
              and o['own_descendants_final'] == [])
        for ref in o['artifacts']:
            ok = ok and ref['member'] in names and H(inner.read(ref['member'])) == ref['sha256']
        if count is not None:
            text = inner.read('LOGS/' + key + '.log').decode('utf-8', 'replace')
            ran = re.findall(r'(?m)^Ran (\d+) tests? in', text)
            ok = (ok and ran == [str(count)] and re.search(r'(?m)^OK\s*$', text) is not None
                  and '... skipped' not in text and re.search(r'(?m)^(FAIL|ERROR):', text) is None)
            tests += count
        c('unit:' + key, ok)
    logs = inner.read('LOGS/CDT21R1_F01R1_PREEXISTING_LEGACY_CUT.log').decode() + inner.read('LOGS/CDT21R1_F01_LEGACY_ENTRY_FENCE.log').decode()
    for t in NATIVE_ONLY:
        c('native_test_ran:' + t[:7], re.search(r'(?m)^' + t + r' \(.*\) \.\.\. ok\s*$', logs) is not None)
    m = json.loads(inner.read('EVIDENCE/MUTATION_CONTROLS.json'))
    c('mutations_native', m['platform'] == 'win32' and m['status'] == 'PASS' and m['baseline']['status'] == 'PASS'
      and m['killed'] == m['total'] == 8 and all(v['status'] == 'KILLED' for v in m['mutations'].values()))
    for v in m['mutations'].values():
        c('mutation_log_hash:' + v['log'][:12], H(inner.read('EVIDENCE/MUTATION_' + v['log'])) == v['log_sha256'])
    m2 = inner.read('EVIDENCE/MUTATION_M2_V003_BEHAVIOUR_FENCE_ONLY_JOURNAL_WRITABLE.log').decode('utf-8', 'replace')
    c('m2_reproduces_b06_symptom_natively', 'AssertionError: False is not true : OK LOG' in m2)
    s4 = json.loads(inner.read('EVIDENCE/ORIGIN_SCENARIO_V004.json'))
    a, b = s4['scenarios']['A_ORIGIN_REPRODUCER'], s4['scenarios']['B_LEGACY_NODE_IN_FLIGHT']
    common = lambda s: (s['old_legacy_child_append_after_fence'] is False and s['journal_unchanged_after_fence'] is True
                        and s['state_unchanged_after_fence'] is True and s['new_legacy_state_after_fence_blocked'] is True
                        and 'PermissionError' in s['old_legacy_child_error'] and 'STATE_JOURNAL.jsonl' in s['old_legacy_child_error']
                        and s['cut_record_present'] is True and s['diagnose_after_old_legacy_exit'] == 'FENCE_PRESENT')
    c('scenario_v004_native', s4['model'] == 'WINDOWS_NATIVE' and s4['package_sha256'] == PKG and common(a) and common(b)
      and (a['fence_install_decision'], a['fence_install_exit']) == ('FENCE_PRESENT', 0)
      and (b['fence_install_decision'], b['fence_install_exit']) == ('CUT_PRESENT_LEGACY_RUN_NOT_DRAINED', 2))
    s3 = json.loads(inner.read('EVIDENCE/ORIGIN_SCENARIO_V003_CONTRAST.json'))
    c('scenario_v003_contrast_reproduces_defect_natively', s3['model'] == 'WINDOWS_NATIVE' and s3['package_sha256'] == V003 and all(
        v['primary_assertion'] == 'F01_LEGACY_ALREADY_INITIALIZED_NOT_STOPPED_BY_FENCE' and v['journal_unchanged_after_fence'] is False
        and v['fence_install_decision'] == 'FENCE_PRESENT' for v in s3['scenarios'].values()))
    out = {'schema': 'CDT21_F01R1_V004_G0_NATIVE_RETURN_CHECK_V001', 'enviar_sha256': H(raw), 'return_sha256': H(ret_raw),
           'g0_result_sha256': H(collected), 'native_tests': tests, 'units': len(UNITS) + 1, 'checks': checks,
           'passed': sum(checks.values()), 'total': len(checks),
           'verdict': 'PASS_NATIVE_V004_G0_VERIFIED' if all(checks.values()) else 'FAIL'}
    print(json.dumps(out, indent=1, sort_keys=True))
    return 0 if all(checks.values()) else 1


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1]))
