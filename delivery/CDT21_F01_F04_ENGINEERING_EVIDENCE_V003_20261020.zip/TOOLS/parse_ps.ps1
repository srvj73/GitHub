param([string[]]$Paths)
foreach ($p in $Paths) {
  $tok=$null; $err=$null
  [void][Management.Automation.Language.Parser]::ParseFile($p,[ref]$tok,[ref]$err)
  Write-Output ("PARSE " + [IO.Path]::GetFileName($p) + " errors=" + @($err).Count)
  foreach ($e in @($err)) { Write-Output ("  " + $e.Extent.StartLineNumber + ": " + $e.Message) }
}
