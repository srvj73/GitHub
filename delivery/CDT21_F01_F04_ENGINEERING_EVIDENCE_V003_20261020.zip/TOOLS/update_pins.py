"""CDT21 F-01/F-04: transitive pins and truthful consumer declarations for the successor bytes.

Usage: python -I update_pins.py <implementation_v001 root after apply_delta.py>
Each JSON is first proven to round-trip byte-exactly with the canonical dump, then edited.
"""
import hashlib
import json
import sys
from pathlib import Path

C = Path(sys.argv[1]) / 'candidate'


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def dump(obj):
    return (json.dumps(obj, indent=2, sort_keys=True) + '\n').encode('ascii')


def edit(rel, change):
    path = C / rel
    raw = path.read_bytes()
    obj = json.loads(raw)
    assert dump(obj) == raw, 'ROUND_TRIP:' + rel
    change(obj)
    new = dump(obj)
    path.write_bytes(new)
    print(rel, sha(raw), '->', sha(new))
    return new


entry_sha = sha((C / 'adapter/runtime_locator_orchestrator_entry.py').read_bytes())
adapter_sha = sha((C / 'adapter/runtime_locator_adapter.py').read_bytes())


def binding(o):
    assert o['orchestrator_entry_sha256'] == '5BFECEA38C55061CD0370D8A9BF0E517115B4932611A58001B8D4704681321A0'
    assert o['adapter_sha256'] == 'D50AB3CE03EA54F767508765CB6326CB77C4297E6C4633534CD3D305FB826BA2'
    o['orchestrator_entry_sha256'] = entry_sha
    o['adapter_sha256'] = adapter_sha


binding_raw = edit('adapter/RUNTIME_LOCATOR_ADAPTER_BINDING.json', binding)


def first(o):
    assert o['runtime_binding_sha256'] == 'C8F675D70053139E99052E8472F83141FB4D0832B30C7AFB9E93CBFDFA02FC85'
    o['adapter_sha256'] = adapter_sha
    o['runtime_binding_sha256'] = sha(binding_raw)


edit('control/FIRST_ADMISSION_BINDING.json', first)

TEST = 'test_cdt21_f01_legacy_entry_fence.py'


def review(o):
    c = o['consumers']
    a = c['adapter/runtime_locator_adapter.py']
    a['source_sha256'] = adapter_sha
    a['negative_guard'] = ('RECEIPT_ALREADY_EXISTS; concurrent winner is never replaced; CDT21 F-04: the frozen-route '
                           'fallback launches only after the frozen launcher and loader are verified from pinned handles '
                           '(ADAPTER_FROZEN_LAUNCH_SOURCE_SHA), held until the child exits')
    a['related_tests'] += '; ' + TEST
    e = c['adapter/runtime_locator_orchestrator_entry.py']
    e['source_sha256'] = entry_sha
    e['negative_guard'] = ('parse_d4_arguments rejects G3 outside D4 boundary; CDT21 F-01: validate_d4_start, the admitted '
                           'guard and every admitted STATE commit require the legacy entry fence (LEGACY_ENTRY_FENCE_MISSING)')
    e['related_tests'] += '; ' + TEST
    r = c['recovery/modules/orchestrator.py']
    assert r['negative_guard'] == 'file cannot be an orchestration root; no production execute/main invocation'
    r['negative_guard'] = ('CDT21 F-01: the frozen CLI (main/execute) IS a legacy root, reachable through '
                           'TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1 or `python orchestrator.py` from any deployed copy; '
                           'the LEGACY_ENTRY_FENCE directory at STATE.json.partial makes its first State write fail before '
                           'any STATE/journal/inbox/runs change, and admitted routes refuse to run without that fence; '
                           'the pre-B06 fixture additionally shows that a file cannot be an orchestration root')
    r['related_tests'] += '; ' + TEST
    for rel, row in c.items():
        assert row['source_sha256'] == sha((C / rel).read_bytes()), 'SOURCE_NOT_BOUND:' + rel


edit('g5proof/PRE_G06_CONSUMER_REVIEW.json', review)
