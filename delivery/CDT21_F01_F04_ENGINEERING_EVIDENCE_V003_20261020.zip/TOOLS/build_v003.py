"""CDT21: freeze the V003 successor from the edited tree; never touches the V002 parent.

Usage: python -I build_v003.py <work root> <V002 zip> <output zip>
Writes the delta patch, delta receipt and engineering completeness record into the tree,
regenerates RUNTIME_CODE_MANIFEST, SOURCE_MANIFEST and PACKAGE_MANIFEST, writes a deterministic
ZIP and verifies it with the project's own verify_final_zip.
"""
import difflib
import hashlib
import importlib.util
import io
import json
import sys
import zipfile
from pathlib import Path

WORK, PARENT_ZIP, OUT = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
IMPL = WORK / 'implementation_v001'
CAND = IMPL / 'candidate'
PARENT_SHA = '4942871541629C3B38F47EDA55EA2C9E310361533887CB55E577D9641542E7C5'
STAMP = (2026, 10, 20, 23, 0, 0)


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def compact(obj):
    return (json.dumps(obj, sort_keys=True, separators=(',', ':')) + '\n').encode('ascii')


parent_raw = PARENT_ZIP.read_bytes()
assert sha(parent_raw) == PARENT_SHA, 'PARENT_SHA'
parent = zipfile.ZipFile(io.BytesIO(parent_raw))
pmembers = {n: parent.read(n) for n in parent.namelist() if not n.endswith('/')}

GENERATED = {'PACKAGE_MANIFEST.json', 'implementation_v001/SOURCE_MANIFEST.json', 'implementation_v001/RUNTIME_CODE_MANIFEST.json',
             'implementation_v001/CDT21_F01_F04_DELTA.patch', 'implementation_v001/CDT21_V003_DELTA_RECEIPT.json',
             'implementation_v001/CDT21_V003_ENGINEERING_COMPLETENESS.json'}


def tree():
    out = {}
    for p in sorted(WORK.rglob('*')):
        if p.is_file():
            rel = p.relative_to(WORK).as_posix()
            assert '__pycache__' not in rel and not rel.endswith('.pyc'), rel
            if rel not in GENERATED:
                out[rel] = p.read_bytes()
    return out


cur = tree()
modified = sorted(n for n in cur if n in pmembers and cur[n] != pmembers[n])
added = sorted(n for n in cur if n not in pmembers)
removed = sorted(n for n in pmembers if n not in cur and n not in GENERATED)
assert not removed, removed
EXPECTED_MODIFIED = ['implementation_v001/candidate/adapter/RUNTIME_LOCATOR_ADAPTER_BINDING.json',
                     'implementation_v001/candidate/adapter/runtime_locator_adapter.py',
                     'implementation_v001/candidate/adapter/runtime_locator_orchestrator_entry.py',
                     'implementation_v001/candidate/control/FIRST_ADMISSION_BINDING.json',
                     'implementation_v001/candidate/g5proof/PRE_G06_CONSUMER_REVIEW.json']
assert modified == EXPECTED_MODIFIED, modified

patch = []
for n in modified:
    a = pmembers[n].decode('utf-8').splitlines(keepends=True)
    b = cur[n].decode('utf-8').splitlines(keepends=True)
    patch.extend(difflib.unified_diff(a, b, 'a/' + n, 'b/' + n))
patch_raw = ''.join(patch).encode('utf-8')
(IMPL / 'CDT21_F01_F04_DELTA.patch').write_bytes(patch_raw)

# Runtime manifest: closed physical set of candidate/ (the D4 bootstrap requires equality).
runtime_rows = [{'bytes': len(raw), 'path': n.removeprefix('implementation_v001/candidate/'), 'sha256': sha(raw)}
                for n, raw in sorted(cur.items()) if n.startswith('implementation_v001/candidate/')]
runtime_raw = compact({'engineering_status': 'CDT21_V003_F01_F04_DELTA_INTEGRATED_LINUX_QUALIFIED_WINDOWS_G0_TARGET_RUNTIME_PENDING',
                       'files': runtime_rows, 'schema': 'TICKSTORE_FINAL_RUNTIME_CODE_MANIFEST_V001'})
(IMPL / 'RUNTIME_CODE_MANIFEST.json').write_bytes(runtime_raw)
code_sha = sha(runtime_raw)
parent_code_sha = sha(pmembers['implementation_v001/RUNTIME_CODE_MANIFEST.json'])

frozen_successor = ['recovery/TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1', 'recovery/modules/orchestrator.py',
                    'recovery/modules/Launch-TickstoreBundle.ps1', 'recovery/loader/INLINE_ROOT_LOADER_V004_R1R1.ps1',
                    'recovery/engine/tickstore_publisher_recovery_v004_release.py',
                    'recovery/engine/tickstore_publisher_recovery_v004_candidate.py',
                    'recovery/config/STAGE_A_SEALED_VALUES_V001.json', 'recovery/CODE_MANIFEST.json',
                    'recovery/99_MANIFEST_SHA256.json', 'control/FULL_STAGE_CONTINUATION.py',
                    'control/D4_FIRST_ADMISSION_BOOTSTRAP.py', 'control/60_EFFECTFUL_WRAPPER_RELEASE.ps1',
                    'control/QUALIFICATION_CONTRACT.json']
receipt = {
    'schema': 'TICKSTORE_CDT21_V003_DELTA_RECEIPT_V001',
    'successor_label': 'V003', 'parent_label': 'V002', 'parent_final_package_sha256': PARENT_SHA,
    'parent_runtime_code_manifest_sha256': parent_code_sha, 'runtime_code_manifest_sha256': code_sha,
    'findings_closed_in_code': ['F-01', 'F-04'],
    'modified': [{'path': n, 'pre_sha256': sha(pmembers[n]), 'post_sha256': sha(cur[n]),
                  'pre_bytes': len(pmembers[n]), 'post_bytes': len(cur[n])} for n in modified],
    'added': [{'path': n, 'sha256': sha(cur[n]), 'bytes': len(cur[n])} for n in added],
    'generated': sorted(GENERATED - {'PACKAGE_MANIFEST.json'}),
    'patch': {'path': 'implementation_v001/CDT21_F01_F04_DELTA.patch', 'sha256': sha(patch_raw)},
    'frozen_successor_files_unchanged': {p: sha(cur['implementation_v001/candidate/' + p]) for p in frozen_successor},
    'g5_owner_decision': 'BOUND_TO_V002_ONLY_NOT_TRANSFERRED',
    'b06': 'NOT_STARTED', 'b07': 'NOT_STARTED', 'd4_d5': 'NOT_STARTED', 'canary': 'NOT_STARTED', 'full': 'NOT_STARTED',
    'production_effects': 'NONE', 'paid_credit': 'NOT_USED',
    'operational_prerequisite': 'LEGACY_ENTRY_FENCE install on the productive control_root (origin authorization; '
                                'procedures/PROCEDIMENTO_CDT21_LEGACY_ENTRY_FENCE.md)',
}
for p in frozen_successor:
    assert cur['implementation_v001/candidate/' + p] == pmembers['implementation_v001/candidate/' + p], p
receipt_raw = (json.dumps(receipt, indent=1, sort_keys=True) + '\n').encode('ascii')
(IMPL / 'CDT21_V003_DELTA_RECEIPT.json').write_bytes(receipt_raw)

completeness = {
    'schema': 'TICKSTORE_CDT21_V003_ENGINEERING_COMPLETENESS_V001',
    'runtime_code_manifest_sha256': code_sha, 'parent_final_package_sha256': PARENT_SHA,
    'status': 'ENGINEERING_DELTA_COMPLETE__WINDOWS_NATIVE_TARGET_RUNTIME_PENDING',
    'five_part_completeness': {
        'all_implementations_integrated': {
            'status': 'PASS_SOURCE_AND_LINUX',
            'basis': 'fence required by validate_d4_start (first admission, D4 entry), by the admitted guard (D4 entry, '
                     'FULL_STAGE_CONTINUATION) and by every admitted STATE commit; F-04 pin in the only official '
                     'route to the frozen launcher (adapted_launch fallback)'},
        'all_known_fixable_blockers_closed': {
            'status': 'PASS_IN_CODE_F01_F04__NATIVE_PROOF_PENDING',
            'closed': ['F-01 legacy master orchestrator / direct frozen CLI', 'F-04 frozen launcher hash->reread window'],
            'outside_this_delta': ['F-02 primary evidence: closed by origin (479/479)',
                                   'F-03 offline-only control: runs and passes off Windows (Linux requalification)']},
        'tested_equals_packaged_new_final_code': {
            'status': 'LINUX_PASS__WINDOWS_TARGET_RUNTIME_PENDING',
            'basis': 'requalification runs on the extracted final ZIP; G0 verify_package binds tested==packaged natively'},
        'frozen_for_independent_audit': {
            'status': 'FROZEN_SUCCESSOR_BYTES__B06_NOT_STARTED',
            'requires': ['native G0 PASS', 'origin G5 decision for V003', 'independent B06 auditor not involved in V003']},
        'adversarial_false_completeness_check': {
            'status': 'PASS_STATEMENTS_BOUNDED',
            'not_claimed': ['Windows native PASS', 'G5 of V002 transferred to V003', 'B06/B07/D4/D5/canary/FULL',
                            'producer five-part receipt for V003 (needs full native campaign under the new code manifest)',
                            'G3/G6 re-run (scenarios use unchanged path-mode guard; no adapter launch fallback)',
                            'physical power loss (NOT_TESTED_PHYSICAL_POWERLOSS)',
                            'fence installed in production (operational step not executed)']},
    },
    'producer_five_part_receipt_v003': 'NOT_ISSUED_REQUIRES_FULL_NATIVE_CAMPAIGN_OR_ORIGIN_SCOPED_DECISION',
    'physical_powerloss': 'NOT_TESTED_PHYSICAL_POWERLOSS',
}
(IMPL / 'CDT21_V003_ENGINEERING_COMPLETENESS.json').write_bytes((json.dumps(completeness, indent=1, sort_keys=True) + '\n').encode('ascii'))

cur = tree()
cur.update({n: (WORK / n).read_bytes() for n in ('implementation_v001/CDT21_F01_F04_DELTA.patch',
                                                 'implementation_v001/CDT21_V003_DELTA_RECEIPT.json',
                                                 'implementation_v001/CDT21_V003_ENGINEERING_COMPLETENESS.json',
                                                 'implementation_v001/RUNTIME_CODE_MANIFEST.json')})
source_rows = [{'bytes': len(raw), 'path': n.removeprefix('implementation_v001/'), 'sha256': sha(raw)}
               for n, raw in sorted(cur.items()) if n.startswith('implementation_v001/')
               and n not in ('implementation_v001/SOURCE_MANIFEST.json', 'implementation_v001/RUNTIME_CODE_MANIFEST.json')]
source_raw = compact({'file_count': len(source_rows), 'files': source_rows})
(IMPL / 'SOURCE_MANIFEST.json').write_bytes(source_raw)
cur['implementation_v001/SOURCE_MANIFEST.json'] = source_raw
package_rows = [{'bytes': len(raw), 'path': n, 'sha256': sha(raw)} for n, raw in sorted(cur.items())]
package_raw = compact({'files': package_rows, 'schema': 'TICKSTORE_FINAL_PACKAGE_MANIFEST_V001'})
(WORK / 'PACKAGE_MANIFEST.json').write_bytes(package_raw)

assert not OUT.exists(), 'OUTPUT_EXISTS'
with zipfile.ZipFile(OUT, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in [('PACKAGE_MANIFEST.json', package_raw)] + sorted(cur.items()):
        info = zipfile.ZipInfo(name, STAMP)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.create_system = 3
        info.external_attr = 0o644 << 16
        z.writestr(info, raw)
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(set(names)) == len(cur) + 1

spec = importlib.util.spec_from_file_location('cdt21_producer', CAND / 'control/G5_FINAL_COMPLETENESS_PRODUCER.py')
sys.path.insert(0, str(CAND / 'control'))
prod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prod)
vcode, vmembers = prod.verify_final_zip(OUT)
assert vcode == code_sha
print(json.dumps({'final_zip': str(OUT), 'final_zip_sha256': sha(OUT.read_bytes()), 'bytes': OUT.stat().st_size,
                  'members': len(names), 'runtime_code_manifest_sha256': code_sha, 'runtime_files': len(runtime_rows),
                  'source_manifest_sha256': sha(source_raw), 'source_files': len(source_rows),
                  'package_manifest_sha256': sha(package_raw), 'patch_sha256': sha(patch_raw),
                  'delta_receipt_sha256': sha(receipt_raw), 'modified': len(modified), 'added': len(added)}, indent=1))
