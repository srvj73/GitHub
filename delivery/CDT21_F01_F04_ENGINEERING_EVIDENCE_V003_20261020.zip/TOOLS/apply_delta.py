"""CDT21 F-01/F-04 delta: exact, single-occurrence edits on the V002 bytes (CRLF preserved).

Usage: python -I apply_delta.py <implementation_v001 root of a fresh V002 copy>
Every edited file must start from its exact V002 SHA-256; every anchor must occur once.
"""
import hashlib
import sys
from pathlib import Path

ROOT = Path(sys.argv[1])
ENTRY = 'candidate/adapter/runtime_locator_orchestrator_entry.py'
ADAPTER = 'candidate/adapter/runtime_locator_adapter.py'
BASE = {ENTRY: '5BFECEA38C55061CD0370D8A9BF0E517115B4932611A58001B8D4704681321A0',
        ADAPTER: 'D50AB3CE03EA54F767508765CB6326CB77C4297E6C4633534CD3D305FB826BA2'}


def crlf(text):
    return text.replace('\r\n', '\n').replace('\n', '\r\n').encode('utf-8')


ENTRY_FENCE = '''

# CDT21 F-01: legacy entry fence.  Every frozen orchestrator route (the V004R1 master
# launcher, `python orchestrator.py <command>`, any deployed copy) constructs State(control_root)
# first, and the frozen State.__init__ always publishes STATE through atom(): it opens
# "STATE.json.partial" for writing and then os.replace()s it.  A directory at that exact name
# makes that first write fail before any byte of STATE, journal, inbox or runs changes.  Admitted
# writers never use that name (their STATE commits are the CAS above), so the fence is invisible
# to them and is required before a writer is admitted.  control/LEGACY_ENTRY_FENCE.py installs it.
LEGACY_ENTRY_FENCE_SCHEMA = "TICKSTORE_LEGACY_ENTRY_FENCE_V001"
LEGACY_ENTRY_FENCE_MARKER = "LEGACY_ENTRY_FENCE.json"


def legacy_entry_fence_path(state_path) -> pathlib.Path:
    state_path = pathlib.Path(state_path)
    return state_path.with_name(state_path.name + ".partial")


def require_legacy_entry_fence(state_path) -> None:
    """CDT21 F-01: fail closed unless the legacy entry fence of this STATE is in place."""
    import stat
    state_path = pathlib.Path(state_path)
    fence = legacy_entry_fence_path(state_path)
    require_no_link_chain(fence, "LEGACY_ENTRY_FENCE")
    if not stat.S_ISDIR(os.lstat(fence).st_mode):
        raise RuntimeError("LEGACY_ENTRY_FENCE_NOT_DIRECTORY")
    raw, _ = read_pinned_regular(fence / LEGACY_ENTRY_FENCE_MARKER, "LEGACY_ENTRY_FENCE_MARKER")
    try:
        marker = json.loads(raw.decode("utf-8"))
    except ValueError:
        raise RuntimeError("LEGACY_ENTRY_FENCE_MARKER_JSON") from None
    if (not isinstance(marker, dict) or marker.get("schema") != LEGACY_ENTRY_FENCE_SCHEMA
            or marker.get("state_name") != state_path.name or marker.get("fence_name") != fence.name):
        raise RuntimeError("LEGACY_ENTRY_FENCE_MARKER_CONTENT")


def validate_d4_start('''

ENTRY_EDITS = [
    ('\n\ndef validate_d4_start(', ENTRY_FENCE),
    ('    require_no_cas_debris(state_path)\n    state_raw, state_ident = read_pinned_regular(state_path, "ADAPTER_ENTRY_STATE")\n',
     '    require_no_cas_debris(state_path)\n    require_legacy_entry_fence(state_path)\n'
     '    state_raw, state_ident = read_pinned_regular(state_path, "ADAPTER_ENTRY_STATE")\n'),
    ('        raise RuntimeError("ADAPTER_ENTRY_ADMITTED_ROOT_MISMATCH")\n',
     '        raise RuntimeError("ADAPTER_ENTRY_ADMITTED_ROOT_MISMATCH")\n'
     '    if config is not None:\n'
     '        # CDT21 F-01: an admitted writer (D4 entry, stage continuation) requires the legacy entry fence.\n'
     '        require_legacy_entry_fence(state_path)\n'),
    ('        data = namespace["jb"](obj)\n        previous_raw = verify_pin("COMMIT")\n',
     '        data = namespace["jb"](obj)\n'
     '        if config is not None:\n'
     '            require_legacy_entry_fence(state_path)  # CDT21 F-01: no admitted commit while the legacy route is open\n'
     '        previous_raw = verify_pin("COMMIT")\n'),
]

ADAPTER_PIN = '''

# CDT21 F-04: the frozen V004R1 launcher (modules/Launch-TickstoreBundle.ps1) hashes its loader
# with Get-FileHash and then re-reads it with ReadAllBytes.  When the official chain falls back
# to that frozen route (bundles outside the runtime-locator target generation), both files are
# opened here first, hashed from the opened handles and kept open without write/delete sharing
# (Windows) until the launched process has exited, so the bytes that launcher hashes and executes
# are the bytes verified here.
FROZEN_LAUNCH_SOURCES = (
    ("modules/Launch-TickstoreBundle.ps1", "56B7F4FDF1978AB96B23A143907F697C7E89FD6DBCB272CFF9E0C9F4E7D6AB02"),
    ("loader/INLINE_ROOT_LOADER_V004_R1R1.ps1", "74FE55D8FC43A5C1CEDE22887C60624DC454D3E52E26E1C3AA108072451F1597"),
)


def _open_pinned_source(path: pathlib.Path) -> tuple:
    """Open read-only without following links; on Windows deny write and delete sharing."""
    import stat as _stat
    for part in (path, *path.parents):
        require(not _is_link_or_reparse(os.lstat(part)), "ADAPTER_FROZEN_LAUNCH_SOURCE_REPARSE:" + path.name)
    if os.name == "nt":
        import ctypes
        import ctypes.wintypes as w
        import msvcrt
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.CreateFileW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD, ctypes.c_void_p, w.DWORD, w.DWORD, w.HANDLE]
        k.CreateFileW.restype = w.HANDLE
        k.CloseHandle.argtypes = [w.HANDLE]
        k.CloseHandle.restype = w.BOOL
        # GENERIC_READ, FILE_SHARE_READ only, OPEN_EXISTING, FILE_FLAG_OPEN_REPARSE_POINT
        handle = k.CreateFileW(str(path), 0x80000000, 0x00000001, None, 3, 0x00200000, None)
        require(handle != ctypes.c_void_p(-1).value,
                "ADAPTER_FROZEN_LAUNCH_SOURCE_OPEN:" + path.name + ":" + str(ctypes.get_last_error()))
        try:
            fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
        except BaseException:
            k.CloseHandle(handle)
            raise
    else:
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    try:
        st = os.fstat(fd)
        require(_stat.S_ISREG(st.st_mode) and not _is_link_or_reparse(st),
                "ADAPTER_FROZEN_LAUNCH_SOURCE_NOT_REGULAR:" + path.name)
        chunks = []
        while True:
            chunk = os.read(fd, 1 << 20)
            if not chunk:
                break
            chunks.append(chunk)
        raw = b"".join(chunks)
        require(len(raw) == st.st_size, "ADAPTER_FROZEN_LAUNCH_SOURCE_SHORT_READ:" + path.name)
        return fd, raw
    except BaseException:
        os.close(fd)
        raise


def pin_frozen_launch_sources(package_root: os.PathLike[str] | str):
    """Verify the frozen launcher and loader from pinned handles; return the callable that unpins them."""
    fds = []
    try:
        for rel, digest in FROZEN_LAUNCH_SOURCES:
            fd, raw = _open_pinned_source(pathlib.Path(package_root).joinpath(*rel.split("/")))
            fds.append(fd)
            require(sha256_bytes(raw) == digest, "ADAPTER_FROZEN_LAUNCH_SOURCE_SHA:" + rel)
    except BaseException:
        for fd in fds:
            os.close(fd)
        raise
    released = []

    def release() -> None:
        if not released:
            released.append(True)
            for fd in fds:
                try:
                    os.close(fd)
                except OSError:
                    pass
    return release


def make_no_clobber_receipt_writer(fail):'''

ADAPTER_EDITS = [
    ('\n\ndef make_no_clobber_receipt_writer(fail):', ADAPTER_PIN),
    ('            require(os.environ.get("TICKSTORE_D4_RESUME_ENABLE") != "1", "ADAPTER_D4_RESUME_NON_TARGET_LAUNCH_FORBIDDEN")\n'
     '            return original_launch(self, bundle_path, anchor_path, label, async_=async_)\n',
     '            require(os.environ.get("TICKSTORE_D4_RESUME_ENABLE") != "1", "ADAPTER_D4_RESUME_NON_TARGET_LAUNCH_FORBIDDEN")\n'
     '            # CDT21 F-04: the frozen launcher and loader stay pinned (verified from the pinned handles)\n'
     '            # for the whole child lifetime, so they cannot change between its hash and its re-read.\n'
     '            release = pin_frozen_launch_sources(self.pkg)\n'
     '            try:\n'
     '                launched = original_launch(self, bundle_path, anchor_path, label, async_=async_)\n'
     '            except BaseException:\n'
     '                release()\n'
     '                raise\n'
     '            if not async_:\n'
     '                release()\n'
     '                return launched\n'
     '            import threading\n'
     '            process = launched[0]\n'
     '\n'
     '            def hold_until_exit():\n'
     '                try:\n'
     '                    process.wait()\n'
     '                finally:\n'
     '                    release()\n'
     '            threading.Thread(target=hold_until_exit, daemon=True, name="TICKSTORE_FROZEN_LAUNCH_PIN").start()\n'
     '            return launched\n'),
]


def apply(rel, edits):
    path = ROOT / rel
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest().upper() == BASE[rel], 'BASELINE_SHA:' + rel
    for old, new in edits:
        o, n = crlf(old), crlf(new)
        assert raw.count(o) == 1, ('ANCHOR_NOT_UNIQUE', rel, old[:60], raw.count(o))
        raw = raw.replace(o, n)
    assert b'\r\r' not in raw and raw.count(b'\n') == raw.count(b'\r\n'), 'CRLF:' + rel
    path.write_bytes(raw)
    print(rel, hashlib.sha256(raw).hexdigest().upper())


apply(ENTRY, ENTRY_EDITS)
apply(ADAPTER, ADAPTER_EDITS)
