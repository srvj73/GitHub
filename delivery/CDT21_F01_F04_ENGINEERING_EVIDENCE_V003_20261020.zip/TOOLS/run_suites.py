"""Run selected unittest files of an extracted package copy; one subprocess per file; JSON summary."""
import json, os, re, subprocess, sys, time
py, root, out = sys.argv[1], sys.argv[2], sys.argv[3]
files = sys.argv[4:]
res = []
for rel in files:
    path = os.path.join(root, rel); d, f = os.path.split(path)
    t0 = time.time()
    p = subprocess.run([py, '-I', '-B', '-m', 'unittest', 'discover', '-v', '-s', d, '-t', d, '-p', f],
                       capture_output=True, text=True, timeout=900)
    log = p.stdout + p.stderr
    m = re.search(r'Ran (\d+) tests? in', log); ran = int(m.group(1)) if m else 0
    tail = log.strip().splitlines()[-1] if log.strip() else ''
    fails = len(re.findall(r'^(FAIL|ERROR): ', log, re.M)); skips = len(re.findall(r'\.\.\. skipped', log))
    res.append({'file': rel, 'exit': p.returncode, 'ran': ran, 'fail_or_error': fails, 'skipped': skips, 'tail': tail, 'seconds': round(time.time()-t0, 1)})
    with open(os.path.join(out, f + '.log'), 'w') as fh: fh.write(log)
    print(f"{rel:<70} exit={p.returncode} ran={ran} fail/err={fails} skip={skips} | {tail[:80]}", flush=True)
json.dump(res, open(os.path.join(out, 'SUMMARY.json'), 'w'), indent=1)
