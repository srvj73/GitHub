#requires -Version 5.1
# TICKSTORE CDT21 - PREPARO DO D4 SOBRE O V005 CONGELADO (GAP-05 e autoextracao segura do instalador; 22/10).
# Launcher unico, autoextraivel: o produtor da observacao nativa do predecessor D4 vem embutido (SHA fixado); o codigo
# congelado que ele usa (motor, D4_ROOTS_EVIDENCE, reconciliacao, bootstrap, preparo, binding, configuracao selada,
# wrapper) e o instalador congelado sao extraidos do CDT21_FINAL_PACKAGE_V005_20261022.zip (SHA fixado), cada membro
# conferido contra o RUNTIME_CODE_MANIFEST do proprio pacote e contra o pin deste launcher. O V005 nao e alterado.
# Etapas (execute a partir de PS C:\Users\silvi>, PowerShell 5.1):
#   Qualificar (padrao): laboratorio proprio em %LOCALAPPDATA%\CDT21_PREPARO_D4_V005; NAO le nem escreve producao.
#     Prova nativa do produtor: 1 observacao positiva admitida pelos consumidores congelados (reconcile e
#     fresh_predecessor do bootstrap, com leitura Win32 e checagem real do mutex) e 4 recusas nativas (lock presente,
#     outro processo Python, processo com marcador, identidade de raiz trocada). Tambem verifica a autoextracao do
#     instalador congelado (sem instalar).
#       powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\silvi\Downloads\RUN_CDT21_V005_PREPARO_D4_20261022.ps1"
#   Observar (somente no momento operacional do D4, depois da B07, menos de 5 minutos antes da admissao):
#     le a producao SOMENTE PARA LEITURA e grava as 3 evidencias em -EvidenceDir (= PredecessorEvidenceDir da INSTANCE).
#       powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\silvi\Downloads\RUN_CDT21_V005_PREPARO_D4_20261022.ps1" -Etapa Observar -EvidenceDir "<pasta>" -AutorizoLeituraProducao
#   Instalar: extrai com seguranca o INSTALL_TICKSTORE_FULL.ps1 congelado e o executa com -WitnessPath (sem extracao manual).
#       powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\silvi\Downloads\RUN_CDT21_V005_PREPARO_D4_20261022.ps1" -Etapa Instalar
# Pre-requisitos em C:\Users\silvi\Downloads: CDT21_FINAL_PACKAGE_V005_20261022.zip (e, para Instalar,
# WITNESS_TICKSTORE_FULL_FINAL_V005_20261022.json). Feche programas Python e janelas que citem TICKSTORE antes de
# Qualificar/Observar: o censo congelado recusa outro Python e qualquer linha de comando com o marcador.
# Log sempre em pasta absoluta fixa, nova a cada execucao, independente da pasta atual:
#   C:\Users\silvi\Downloads\CDT21_PREPARO_D4_V005_RUNS\<ETAPA>_<yyyyMMdd_HHmmss_fff_PID>\RUN_LOG.txt
# Retorno: ENVIAR_AO_OPUS_CDT21_PREPARO_D4_V005_<stamp>.zip vai DIRETAMENTE ao Opus.
[CmdletBinding()]
param(
    [ValidateSet('Qualificar', 'Observar', 'Instalar')][string]$Etapa = 'Qualificar',
    [string]$EvidenceDir = '',
    [switch]$AutorizoLeituraProducao,
    [switch]$ElevatedChild,
    [string]$SharedLogDir = '',
    [int]$LauncherParentPid = 0,
    [string]$LauncherParentCreation = ''
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$Thread = 'Compress' + [char]0x00E3 + 'o De Ticks 21'
$Downloads = 'C:\Users\silvi\Downloads'
$RunsDir = 'C:\Users\silvi\Downloads\CDT21_PREPARO_D4_V005_RUNS'
$PackageName = 'CDT21_FINAL_PACKAGE_V005_20261022.zip'
$ExpectedPackageSha = 'E3F1F4790D6AE6E5639F137FAEE3E91B2B8E6FFB51A95F18078DF734553CB145'
$ExpectedRuntimeManifestSha = '63CBA7065A719CBCF58F1EB1F088D090B87AE7ABBAF37BE03856619CE1D0D74E'
$WitnessName = 'WITNESS_TICKSTORE_FULL_FINAL_V005_20261022.json'
$ExpectedWitnessSha = 'A3A616DAD36E16D77FD8FB78DAF7E4C8F5992D133F68D445813F4E6D041B9C41'
$Python = 'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe'
$ExpectedPythonSha = '4942B86A6597E5AEE0128DAA00050ED79BC21F6E709A78EB19CBFEB0C2F39AC9'
$ObserverName = 'CDT21_D4_PREDECESSOR_OBSERVER.py'
$ObserverSha = '@@OBSERVER_SHA@@'
$InstallerRel = 'control/INSTALL_TICKSTORE_FULL.ps1'
$InstallerSha = 'BB245FCF2530534BAF7E5CD4984DE791CC522F6B3B8C9D02B3B9BBF061E03C43'
$Frozen = [ordered]@{
@@FROZEN_TABLE@@
}
$WorkRoot = Join-Path $env:LOCALAPPDATA 'CDT21_PREPARO_D4_V005'
$Stamp = (Get-Date).ToString('yyyyMMdd_HHmmss_fff') + '_' + $PID
$Utf8 = New-Object Text.UTF8Encoding($false)
$Prefix = $Etapa.ToUpperInvariant() + '_'
if ($ElevatedChild) {
    $full = [IO.Path]::GetFullPath($SharedLogDir)
    if (-not $SharedLogDir -or -not $full.StartsWith($RunsDir + '\' + $Prefix, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $full -PathType Container)) {
        throw ('SHARED_LOG_DIR_INVALID=' + $SharedLogDir)
    }
    $LogDir = $full
    $Log = Join-Path $LogDir 'RUN_LOG_ELEVATED.txt'
} else {
    if (-not (Test-Path -LiteralPath $RunsDir -PathType Container)) { New-Item -ItemType Directory -Path $RunsDir -ErrorAction Stop | Out-Null }
    $LogDir = Join-Path $RunsDir ($Prefix + $Stamp)
    New-Item -ItemType Directory -Path $LogDir -ErrorAction Stop | Out-Null
    $Log = Join-Path $LogDir 'RUN_LOG.txt'
}

$ObserverB64 = @'
@@OBSERVER_B64@@
'@

function Log([string]$Line) {
    Write-Host $Line
    [IO.File]::AppendAllText($Log, $Line + "`r`n", $Utf8)
}
function ShaBytes([byte[]]$Bytes) {
    $h = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($h.ComputeHash($Bytes)).Replace('-', '') } finally { $h.Dispose() }
}
function Sha([string]$Path) {
    $s = [IO.File]::OpenRead($Path); $h = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($h.ComputeHash($s)).Replace('-', '') } finally { $h.Dispose(); $s.Dispose() }
}
function CreationKey($Proc) {
    if ($null -eq $Proc.CreationDate) { return '' }
    return [string]([DateTime]$Proc.CreationDate).ToUniversalTime().Ticks
}
function NewStage() {
    $stage = Join-Path $WorkRoot ('STAGE_' + $Stamp)
    if (Test-Path -LiteralPath $stage) { throw 'STAGE_EXISTS' }
    New-Item -ItemType Directory -Path (Join-Path $stage 'TEMP') -ErrorAction Stop | Out-Null
    return $stage
}
function CheckPackage() {
    $pkg = Join-Path $Downloads $PackageName
    if (-not (Test-Path -LiteralPath $pkg -PathType Leaf)) { throw ('PACKAGE_NOT_FOUND=' + $pkg) }
    $s = Sha $pkg
    if ($s -cne $ExpectedPackageSha) { throw ('PACKAGE_SHA_MISMATCH=' + $s) }
    Log ('PACKAGE=' + $pkg + ' SHA256_OK=' + $s)
    return $pkg
}
function ExtractFrozen([string]$Pkg, [string]$Dest, $Members) {
    # Autoextracao segura: cada membro conferido contra o RUNTIME_CODE_MANIFEST do pacote E contra o pin deste launcher;
    # criacao exclusiva (nunca sobrescreve); releitura do arquivo gravado.
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [IO.Compression.ZipFile]::OpenRead($Pkg)
    try {
        $me = $zip.GetEntry('implementation_v001/RUNTIME_CODE_MANIFEST.json')
        if ($null -eq $me) { throw 'RUNTIME_MANIFEST_ABSENT' }
        $ms = $me.Open(); $buf = New-Object IO.MemoryStream
        try { $ms.CopyTo($buf) } finally { $ms.Dispose() }
        $mraw = $buf.ToArray()
        if ((ShaBytes $mraw) -cne $ExpectedRuntimeManifestSha) { throw 'RUNTIME_MANIFEST_SHA' }
        $manifest = $Utf8.GetString($mraw) | ConvertFrom-Json
        $rows = @{}
        foreach ($r in $manifest.files) { $rows[[string]$r.path] = ([string]$r.sha256).ToUpperInvariant() }
        foreach ($rel in $Members.Keys) {
            $pin = [string]$Members[$rel]
            if (-not $rows.ContainsKey($rel) -or $rows[$rel] -cne $pin) { throw ('MANIFEST_PIN_DIVERGES=' + $rel) }
            $entry = $zip.GetEntry('implementation_v001/candidate/' + $rel)
            if ($null -eq $entry) { throw ('MEMBER_ABSENT=' + $rel) }
            $target = Join-Path $Dest ($rel -replace '/', '\')
            New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($target)) -Force | Out-Null
            [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $target, $false)
            if ((Sha $target) -cne $pin) { throw ('EXTRACTED_SHA_MISMATCH=' + $rel) }
            Log ('EXTRAIDO=' + $rel + ' SHA256=' + $pin)
        }
    } finally { $zip.Dispose() }
}
function Unpack([string]$B64, [string]$Expected, [string]$Path) {
    $bytes = [Convert]::FromBase64String(($B64 -replace '\s', ''))
    if ((ShaBytes $bytes) -cne $Expected) { throw ('EMBEDDED_SHA_MISMATCH=' + $Path) }
    [IO.File]::WriteAllBytes($Path, $bytes)
    if ((Sha $Path) -cne $Expected) { throw ('EMBEDDED_READBACK_MISMATCH=' + $Path) }
    Log ('UNPACKED=' + $Path + ' SHA256=' + $Expected)
}
function CheckEvidenceDir([string]$Dir) {
    if (-not $Dir) { throw 'EVIDENCE_DIR_REQUIRED (= INSTANCE d4_parameters.PredecessorEvidenceDir)' }
    if (-not [IO.Path]::IsPathRooted($Dir)) { throw 'EVIDENCE_DIR_MUST_BE_ABSOLUTE' }
    $full = [IO.Path]::GetFullPath($Dir)
    if ($full.IndexOf('tickstore', [StringComparison]::OrdinalIgnoreCase) -ge 0) { throw 'EVIDENCE_DIR_CONTAINS_MARKER: o censo congelado recusaria a propria linha de comando; use uma pasta sem a palavra TICKSTORE' }
    if ($full.StartsWith('D:\Base CSV', [StringComparison]::OrdinalIgnoreCase)) { throw 'EVIDENCE_DIR_IN_PRODUCTION_TREE' }
    return $full
}

$code = 2
$Receipt = ''
try {
    Log ('RESULT_CONTEXT=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=' + $Thread)
    Log ('RUN_LOG=' + $Log)
    Log ('LAUNCHER=' + $PSCommandPath + ' SHA256=' + (Sha $PSCommandPath))
    Log ('ETAPA=' + $Etapa + ' V005=CONGELADO_NAO_ALTERADO B06=NAO_EXECUTADA_PELO_IMPLEMENTADOR B07_D4_D5_CANARIO_FULL=NAO_EXECUTADOS')
    if ($PSVersionTable.PSEdition -ne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'WINDOWS_POWERSHELL_5_1_REQUIRED' }
    if (-not $env:LOCALAPPDATA) { throw 'LOCALAPPDATA_MISSING' }
    if ($Etapa -eq 'Observar') {
        if (-not $AutorizoLeituraProducao) { throw 'OBSERVAR_EXIGE_-AutorizoLeituraProducao (somente no momento operacional do D4, depois da B07)' }
        $EvidenceDir = CheckEvidenceDir $EvidenceDir
        Log ('EVIDENCE_DIR=' + $EvidenceDir + ' (leitura de producao somente leitura; escrita somente nesta pasta)')
    } elseif ($EvidenceDir -or $AutorizoLeituraProducao) { throw 'EvidenceDir_E_AutorizoLeituraProducao_SO_NA_ETAPA_Observar' }
    if ($Etapa -eq 'Instalar') {
        $pkg = CheckPackage
        $witness = Join-Path $Downloads $WitnessName
        if (-not (Test-Path -LiteralPath $witness -PathType Leaf) -or (Sha $witness) -cne $ExpectedWitnessSha) { throw ('WITNESS_MISSING_OR_SHA=' + $witness) }
        Log ('WITNESS=' + $witness + ' SHA256_OK=' + $ExpectedWitnessSha)
        $stage = NewStage
        ExtractFrozen $pkg (Join-Path $stage 'frozen') ([ordered]@{ $InstallerRel = $InstallerSha })
        $installer = Join-Path $stage ('frozen\' + ($InstallerRel -replace '/', '\'))
        Log ('INSTALADOR_CONGELADO=' + $installer + ' (executado com -WitnessPath; log proprio em OneDrive\Downloads\TICKSTORE_RUNS)')
        $oldPref = $ErrorActionPreference
        try {
            $ErrorActionPreference = 'Continue'
            & (Join-Path $PSHOME 'powershell.exe') -NoProfile -ExecutionPolicy Bypass -File $installer -WitnessPath $witness 2>&1 | ForEach-Object { Log ([string]$_) }
            $code = $LASTEXITCODE
        } finally { $ErrorActionPreference = $oldPref }
        Log ('INSTALADOR_EXIT_CODE=' + $code)
    } else {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($id)
        if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
            if ($ElevatedChild) { throw 'ELEVATION_REENTRY_GUARD: rights missing after RunAs' }
            $selfProc = @(Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $PID) -ErrorAction Stop)
            if ($selfProc.Count -ne 1) { throw 'OWN_TREE_SELF_NOT_FOUND' }
            $selfCreation = CreationKey $selfProc[0]
            $si = New-Object System.Diagnostics.ProcessStartInfo
            $si.FileName = Join-Path $PSHOME 'powershell.exe'
            $si.WorkingDirectory = 'C:\Users\silvi'
            $si.UseShellExecute = $true
            $si.Verb = 'runas'
            $si.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -Etapa ' + $Etapa + $(if ($Etapa -eq 'Observar') { ' -EvidenceDir "' + $EvidenceDir + '" -AutorizoLeituraProducao' } else { '' }) + ' -ElevatedChild -SharedLogDir "' + $LogDir + '" -LauncherParentPid ' + $PID + ' -LauncherParentCreation ' + $selfCreation
            Log ('UAC_REQUEST=YES LOG_COMPARTILHADO=' + $LogDir + ' IDENTIDADE_PAI=' + $PID + '@' + $selfCreation)
            $child = [System.Diagnostics.Process]::Start($si)
            if ($null -eq $child) { throw 'UAC_NO_CHILD_PROCESS' }
            try {
                Log ('ELEVATED_CHILD_PID=' + $child.Id + ' (log do filho: ' + (Join-Path $LogDir 'RUN_LOG_ELEVATED.txt') + ')')
                $deadline = [DateTime]::UtcNow.AddHours(1)
                while (-not $child.WaitForExit(5000)) {
                    if ([DateTime]::UtcNow -ge $deadline) { throw 'ELEVATED_CHILD_WAIT_TIMEOUT' }
                }
                $child.WaitForExit(); $child.Refresh()
                $code = [int]$child.ExitCode
                Log ('ELEVATED_CHILD_EXIT_CODE=' + $code)
            } finally { $child.Dispose() }
        } else {
            if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { throw ('PYTHON_MISSING=' + $Python) }
            if ((Sha $Python) -cne $ExpectedPythonSha) { throw 'PYTHON_SHA_MISMATCH' }
            $pkg = CheckPackage
            $stage = NewStage
            $frozenDir = Join-Path $stage 'frozen'
            $members = [ordered]@{}
            foreach ($k in $Frozen.Keys) { $members[$k] = $Frozen[$k] }
            if ($Etapa -eq 'Qualificar') { $members[$InstallerRel] = $InstallerSha }
            ExtractFrozen $pkg $frozenDir $members
            if ($Etapa -eq 'Qualificar') { Log 'AUTOEXTRACAO_INSTALADOR=PASS (membro congelado conferido; nao instalado nesta etapa)' }
            $observer = Join-Path $stage $ObserverName
            Unpack $ObserverB64 $ObserverSha $observer
            $Receipt = Join-Path $LogDir $(if ($Etapa -eq 'Qualificar') { 'LAB_QUALIFICATION_RECEIPT.json' } else { 'OBSERVER_RECEIPT.json' })
            $req = [ordered]@{ mode = $(if ($Etapa -eq 'Qualificar') { 'QUALIFY_LAB' } else { 'OBSERVE' }); frozen_dir = $frozenDir;
                               evidence_dir = $(if ($Etapa -eq 'Qualificar') { Join-Path $WorkRoot ('LAB_' + $Stamp + '\EVIDENCE') } else { $EvidenceDir });
                               lab_root = (Join-Path $WorkRoot ('LAB_' + $Stamp + '\TREES')); out_receipt = $Receipt }
            $reqPath = Join-Path $stage 'REQUEST.json'
            [IO.File]::WriteAllText($reqPath, ($req | ConvertTo-Json), $Utf8)
            $oldTemp = $env:TEMP; $oldTmp = $env:TMP; $oldPref = $ErrorActionPreference
            $env:TEMP = Join-Path $stage 'TEMP'; $env:TMP = $env:TEMP
            try {
                $ErrorActionPreference = 'Continue'
                Log ('PRODUTOR=INICIO MODO=' + $req.mode + $(if ($Etapa -eq 'Qualificar') { ' (laboratorio proprio; producao nao lida)' } else { ' (producao somente leitura)' }))
                & $Python -I -B $observer --request $reqPath 2>&1 | ForEach-Object { Log ([string]$_) }
                $code = $LASTEXITCODE
            } finally {
                $ErrorActionPreference = $oldPref; $env:TEMP = $oldTemp; $env:TMP = $oldTmp
            }
            if (Test-Path -LiteralPath $Receipt -PathType Leaf) { Log ('RECIBO=' + $Receipt + ' SHA256=' + (Sha $Receipt)) } else { Log 'RECIBO_NAO_PRODUZIDO' }
            if ($Etapa -eq 'Qualificar') {
                $ev = Join-Path $WorkRoot ('LAB_' + $Stamp + '\EVIDENCE\Q1_POSITIVE_NATIVE')
                foreach ($rel in @('predecessor_observer\predecessor_evidence\OBSERVATION.json', 'predecessor_observer\PREDECESSOR_SYSTEM.json', 'D4_ROOTS_REPORT.json')) {
                    $p = Join-Path $ev $rel
                    if (Test-Path -LiteralPath $p -PathType Leaf) { Copy-Item -LiteralPath $p -Destination (Join-Path $LogDir ('Q1_' + [IO.Path]::GetFileName($p))) }
                }
            } else {
                foreach ($rel in @('predecessor_observer\predecessor_evidence\OBSERVATION.json', 'predecessor_observer\PREDECESSOR_SYSTEM.json', 'D4_ROOTS_REPORT.json')) {
                    $p = Join-Path $EvidenceDir $rel
                    if (Test-Path -LiteralPath $p -PathType Leaf) { Copy-Item -LiteralPath $p -Destination (Join-Path $LogDir ('EVIDENCIA_' + [IO.Path]::GetFileName($p))) }
                }
            }
        }
    }
} catch {
    Log ('PREPARO_D4_BLOCKED=' + $_.Exception.Message)
    $code = 2
} finally {
    Log ('EXIT_CODE=' + $code)
    if ($ElevatedChild) {
        Log 'FILHO_ELEVADO_CONCLUIDO (o processo pai empacota o retorno unico)'
    } else {
        $Send = Join-Path $LogDir ('ENVIAR_AO_OPUS_CDT21_PREPARO_D4_V005_' + $Stamp + '.zip')
        try {
            Add-Type -AssemblyName System.IO.Compression
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            $zip = [IO.Compression.ZipFile]::Open($Send, [IO.Compression.ZipArchiveMode]::Create)
            try {
                foreach ($f in @(Get-ChildItem -LiteralPath $LogDir -File | Where-Object { $_.Name -notlike 'ENVIAR_AO_OPUS_*' })) {
                    [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $f.FullName, $f.Name, [IO.Compression.CompressionLevel]::Optimal)
                }
            } finally { $zip.Dispose() }
            Log ('ENVIE_O_RETORNO=' + $Send)
            Log ('ENVIE_O_RETORNO_SHA256=' + (Sha $Send))
        } catch {
            Log ('ENVIAR_ZIP_FALHOU=' + $_.Exception.Message + ' (envie o conteudo de ' + $LogDir + ')')
        }
        Log 'Devolva este retorno DIRETAMENTE ao Opus (Claude Code), na mesma conversa de engenharia CDT21: anexe o arquivo ENVIE_O_RETORNO acima e cole este log.'
        Log ('RESULT_RETURN_TO=Opus | ORIGIN=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=' + $Thread)
    }
}
exit $code
