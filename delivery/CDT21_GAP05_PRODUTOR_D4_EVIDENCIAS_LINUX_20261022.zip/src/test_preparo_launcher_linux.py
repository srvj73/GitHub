"""Linux functional test of RUN_CDT21_V005_PREPARO_D4 with pwsh 7: a copy with declared platform substitutions only
(paths, PS edition check, interpreter pin, admin check, Windows path separator), then 6 scenarios.

Usage: python -I test_preparo_launcher_linux.py <pwsh> <launcher.ps1> <V005.zip> <python> <work> <out.json> <installer witness>
"""
import hashlib, json, os, shutil, subprocess, sys, zipfile
from pathlib import Path

pwsh, launcher, v005, py, work, out = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3]), sys.argv[4], Path(sys.argv[5]), Path(sys.argv[6])
H = lambda b: hashlib.sha256(b).hexdigest().upper()
if work.exists():
    shutil.rmtree(work)
dl, runs, local = work / 'Downloads', work / 'RUNS', work / 'LOCAL'
for d in (dl, runs, local):
    d.mkdir(parents=True)
shutil.copyfile(v005, dl / v005.name)
text = launcher.read_bytes().decode('ascii')
SUBS = [("$Downloads = 'C:\\Users\\silvi\\Downloads'", "$Downloads = '%s'" % dl),
        ("$RunsDir = 'C:\\Users\\silvi\\Downloads\\CDT21_PREPARO_D4_V005_RUNS'", "$RunsDir = '%s'" % runs),
        ("$Python = 'C:\\Users\\silvi\\AppData\\Local\\Python\\pythoncore-3.14-64\\python.exe'", "$Python = '%s'" % py),
        ("$ExpectedPythonSha = '4942B86A6597E5AEE0128DAA00050ED79BC21F6E709A78EB19CBFEB0C2F39AC9'", "$ExpectedPythonSha = '%s'" % H(Path(py).read_bytes())),
        ("    if ($PSVersionTable.PSEdition -ne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'WINDOWS_POWERSHELL_5_1_REQUIRED' }\r\n", ""),
        ("        $id = [Security.Principal.WindowsIdentity]::GetCurrent()\r\n        $principal = New-Object Security.Principal.WindowsPrincipal($id)\r\n        if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {",
         "        if ($false) {"),
        ("            $target = Join-Path $Dest ($rel -replace '/', '\\')", "            $target = Join-Path $Dest $rel"),
        ("        $installer = Join-Path $stage ('frozen\\' + ($InstallerRel -replace '/', '\\'))", "        $installer = Join-Path $stage ('frozen/' + $InstallerRel)")]
for a, b in SUBS:
    assert text.count(a) == 1, a[:80]
    text = text.replace(a, b)
copy = work / 'LAUNCHER_LINUX_COPY.ps1'; copy.write_bytes(text.encode('ascii'))


def run(*args, env_extra=None):
    env = dict(os.environ, LOCALAPPDATA=str(local))
    cp = subprocess.run([pwsh, '-NoProfile', '-File', str(copy)] + list(args), capture_output=True, text=True, timeout=600, env=env)
    return cp.returncode, cp.stdout + cp.stderr


res = []
def case(name, ok, detail):
    res.append({'case': name, 'pass': bool(ok), 'detail': detail})

# T1 Qualificar: package verified, 9 frozen members extracted (manifest + pin), observer unpacked, request, python run,
# receipt collected, return zip produced.  On Linux the observer itself refuses the non-sealed interpreter: expected.
c, o = run()
extr = [l for l in o.splitlines() if l.startswith('EXTRAIDO=')]
rcpt = list(runs.glob('QUALIFICAR_*/LAB_QUALIFICATION_RECEIPT.json'))
send = list(runs.glob('QUALIFICAR_*/ENVIAR_AO_OPUS_CDT21_PREPARO_D4_V005_*.zip'))
r = json.loads(rcpt[0].read_bytes()) if rcpt else {}
case('T1_qualificar_autoextracao_e_execucao', c == 2 and len(extr) == 9 and 'AUTOEXTRACAO_INSTALADOR=PASS' in o and 'UNPACKED=' in o
     and r.get('reason') == 'Blocked:PYTHON_SHA_NOT_SEALED_INTERPRETER' and len(send) == 1 and 'RECIBO=' in o,
     {'exit': c, 'extracted': len(extr), 'receipt_reason': r.get('reason'), 'return_zip': len(send)})
# T2 tampered package refused before any extraction.
good = (dl / v005.name).read_bytes(); bad = bytearray(good); bad[100] ^= 1; (dl / v005.name).write_bytes(bytes(bad))
c, o = run()
case('T2_pacote_adulterado_recusado', c == 2 and 'PREPARO_D4_BLOCKED=PACKAGE_SHA_MISMATCH' in o and 'EXTRAIDO=' not in o, {'exit': c})
(dl / v005.name).write_bytes(good)
# T3 Observar without authorization, then with a marker path.
c, o = run('-Etapa', 'Observar', '-EvidenceDir', str(work / 'ev'))
case('T3a_observar_sem_autorizacao_recusado', c == 2 and 'OBSERVAR_EXIGE_-AutorizoLeituraProducao' in o, {'exit': c})
c, o = run('-Etapa', 'Observar', '-EvidenceDir', str(work / 'TICKSTORE_ev'), '-AutorizoLeituraProducao')
case('T3b_pasta_de_evidencia_com_marcador_recusada', c == 2 and 'EVIDENCE_DIR_CONTAINS_MARKER' in o, {'exit': c})
# T4 Instalar without witness, then with witness (extraction of the frozen installer verified; powershell.exe absent on Linux).
c, o = run('-Etapa', 'Instalar')
case('T4a_instalar_sem_testemunha_recusado', c == 2 and 'WITNESS_MISSING_OR_SHA' in o, {'exit': c})
(dl / 'WITNESS_TICKSTORE_FULL_FINAL_V005_20261022.json').write_bytes(Path(sys.argv[7]).read_bytes())
c, o = run('-Etapa', 'Instalar')
inst = [l for l in o.splitlines() if l.startswith('EXTRAIDO=control/INSTALL_TICKSTORE_FULL.ps1')]
case('T4b_instalar_autoextrai_instalador_congelado', 'WITNESS=' in o and len(inst) == 1
     and 'SHA256=BB245FCF2530534BAF7E5CD4984DE791CC522F6B3B8C9D02B3B9BBF061E03C43' in inst[0] and 'INSTALADOR_CONGELADO=' in o,
     {'exit': c, 'note': 'powershell.exe (Windows PowerShell 5.1) nao existe no Linux: a execucao do instalador congelado e nativa'})
# T5 a launcher pin that diverges from the package RUNTIME_CODE_MANIFEST is refused before extraction of that member.
t5 = text.replace("'control/D4_ROOTS_EVIDENCE.py' = '048190A53BF432D4F7341D3FA2DAEFC192E680EC189AEBAF4C65BBF1B7A7729F'",
                  "'control/D4_ROOTS_EVIDENCE.py' = '048190A53BF432D4F7341D3FA2DAEFC192E680EC189AEBAF4C65BBF1B7A7729E'")
assert t5 != text
copy.write_bytes(t5.encode('ascii'))
c, o = run()
case('T5_pin_divergente_do_manifesto_recusado', c == 2 and 'MANIFEST_PIN_DIVERGES=control/D4_ROOTS_EVIDENCE.py' in o, {'exit': c})
copy.write_bytes(text.encode('ascii'))
# T6 embedded observer payload altered: refused at unpack (pin of the payload).
i = text.index("$ObserverB64 = @'\r\n") + len("$ObserverB64 = @'\r\n")
t6 = text[:i] + ('J' if text[i] != 'J' else 'K') + text[i + 1:]  # a valid base64 character: same length, other bytes
assert t6 != text
copy.write_bytes(t6.encode('ascii'))
c, o = run()
case('T6_payload_embutido_alterado_recusado', c == 2 and 'EMBEDDED_SHA_MISMATCH' in o, {'exit': c})
copy.write_bytes(text.encode('ascii'))
doc = {'schema': 'CDT21_PREPARO_D4_LAUNCHER_LINUX_FUNCTIONAL_V001', 'launcher_sha256': H(launcher.read_bytes()),
       'substitutions_declared': [a[:90] for a, b in SUBS], 'results': res, 'passed': sum(x['pass'] for x in res), 'total': len(res)}
out.write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding='utf-8')
print('LAUNCHER_LINUX', doc['passed'], '/', doc['total'], [x['case'] for x in res if not x['pass']])
for x in res: print(' ', x['pass'], x['case'], x['detail'])
