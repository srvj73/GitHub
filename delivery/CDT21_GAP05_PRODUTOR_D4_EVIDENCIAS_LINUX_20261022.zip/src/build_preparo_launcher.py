"""Build RUN_CDT21_V005_PREPARO_D4_20261022.ps1 from launcher_template.ps1: embeds the observer (base64, SHA pinned) and the
frozen pin table taken from the observer's FROZEN map; ASCII-only, CRLF.

Usage: python -I build_preparo_launcher.py <launcher_template.ps1> <CDT21_D4_PREDECESSOR_OBSERVER.py> <out.ps1>
"""
import base64, hashlib, importlib.util, sys
from pathlib import Path

tpl, obs, out = map(Path, sys.argv[1:4])
H = lambda b: hashlib.sha256(b).hexdigest().upper()
spec = importlib.util.spec_from_file_location('o', str(obs)); o = importlib.util.module_from_spec(spec); spec.loader.exec_module(o)
raw = obs.read_bytes()
b64 = base64.b64encode(raw).decode()
table = '\n'.join("    '%s' = '%s'" % (k, v) for k, v in o.FROZEN.items())
text = tpl.read_text(encoding='ascii').replace('\r\n', '\n')
for k, v in (('@@OBSERVER_SHA@@', H(raw)), ('@@FROZEN_TABLE@@', table), ('@@OBSERVER_B64@@', '\n'.join(b64[i:i + 100] for i in range(0, len(b64), 100)))):
    assert text.count(k) == 1, k
    text = text.replace(k, v)
assert '@@' not in text and text.isascii()
data = text.replace('\n', '\r\n').encode('ascii')
out.write_bytes(data)
print(out.name, H(data), len(data), 'OBSERVER', H(raw))
