"""Mutants of CDT21_D4_PREDECESSOR_OBSERVER.py: each must be killed by the Linux qualification (passed < total).

Usage: python -I run_observer_mutants.py <python> <observer.py> <test.py> <frozen_dir> <work_dir> <out.json>
"""
import concurrent.futures, json, subprocess, sys
from pathlib import Path

py, obs, test, frozen, work, out = sys.argv[1], Path(sys.argv[2]), sys.argv[3], sys.argv[4], Path(sys.argv[5]), Path(sys.argv[6])
src = obs.read_text(encoding='utf-8')
MUTANTS = {
 'M01_OTHER_PYTHON_HIDDEN': ("        is_obs = r['pid'] == own_pid and r['creation_time'] == own_creation\n",
                             "        is_obs = r['pid'] == own_pid and r['creation_time'] == own_creation\n        if base in ('python.exe', 'pythonw.exe') and not is_obs:\n            continue\n"),
 'M02_MARKER_DISABLED': ("        marker = MARKER in text.lower()\n", "        marker = False\n"),
 'M03_UNREADABLE_INTERPRETER_HIDDEN': ("        if not readable and not interp:\n", "        if not readable:\n"),
 'M04_ADMIN_FORCED': ("'admin': bool(native.is_admin())", "'admin': True"),
 'M05_BOOT_IS_NOW': ("    boot, uptime_ms = native.boot_utc()\n", "    boot, uptime_ms = native.boot_utc(); boot = utc_now() - dt.timedelta(seconds=1)\n"),
 'M06_LOCKS_ALWAYS_ABSENT': ("'present': before['locks'].get(ck) is not False}", "'present': False}"),
 'M07_MUTEX_IGNORED': ("    mutex = native.mutex_probe()\n", "    mutex = dict(native.mutex_probe(), present=False, error=2)\n"),
 'M08_HISTORICAL_FROM_ACTUAL': ("        historical = (gate.get('root_bindings') or {}).get(key) or {}\n",
                                "        historical = actual if isinstance(actual, dict) else {}\n"),
 'M09_RECOVERY_ENTRIES_EMPTY': ("    recovery_entries = before['recovery'] if before['recovery'] is not None else ['<RECOVERY_ROOT_ABSENT_OR_NOT_DIRECTORY>']\n",
                                "    recovery_entries = []\n"),
 'M10_FIRST_STARTED_NOT_LAST': ("    last = d4[-1] if d4 else {}\n", "    last = next((e for e in d4 if e.get('phase') == 'STARTED'), {})\n"),
 'M11_STABILITY_FORCED': ("'inputs_unchanged': bool(unchanged)", "'inputs_unchanged': True"),
 'M12_BINDING_FORCED': ("'bundle_binding_verified': bool(binding['verified'])", "'bundle_binding_verified': True"),
 'M13_GATE_MODE_FORCED': ("'gate_mode': gate.get('mode')", "'gate_mode': GATE_MODE"),
 'M14_PUBLISH_DELETES_PREVIOUS': ("            os.replace(ed / t, hist / t)\n",
                                  "            shutil.rmtree(ed / t) if (ed / t).is_dir() else os.remove(ed / t)\n"),
 'M15_NO_FROZEN_PIN_CHECK': ("        require(sha_file(root / rel) == digest, 'FROZEN_SHA:' + rel)\n", "        pass\n"),
}
work.mkdir(parents=True)


def run(item):
    name, (old, new) = item
    assert src.count(old) == 1, name
    d = work / name; d.mkdir()
    m = d / obs.name; m.write_text(src.replace(old, new), encoding='utf-8')
    cp = subprocess.run([py, '-I', '-B', test, str(m), frozen, str(d / 'w'), str(d / 'q.json')], capture_output=True, text=True, timeout=1800, cwd=str(d))
    q = json.loads((d / 'q.json').read_text(encoding='utf-8')) if (d / 'q.json').exists() else {'passed': -1, 'total': 0, 'results': []}
    failing = [r['case'] for r in q['results'] if not r['pass']]
    return {'mutant': name, 'killed': q['passed'] < q['total'] or q['total'] == 0, 'passed': q['passed'], 'total': q['total'], 'killed_by': failing}


with concurrent.futures.ThreadPoolExecutor(4) as ex:
    res = list(ex.map(run, sorted(MUTANTS.items())))
doc = {'schema': 'CDT21_D4_PREDECESSOR_OBSERVER_MUTANTS_V001', 'mutants': res, 'killed': sum(r['killed'] for r in res), 'total': len(res)}
out.write_text(json.dumps(doc, indent=1), encoding='utf-8')
print('OBSERVER_MUTANTS', doc['killed'], '/', doc['total'])
for r in res:
    print(' ', r['mutant'], 'KILLED' if r['killed'] else 'SURVIVED', r['passed'], '/', r['total'], r['killed_by'][:4])
