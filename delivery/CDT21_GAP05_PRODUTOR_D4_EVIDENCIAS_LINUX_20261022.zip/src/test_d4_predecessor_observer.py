"""Linux qualification of CDT21_D4_PREDECESSOR_OBSERVER.py against the FROZEN V005 consumers.

Usage: python -I -B test_d4_predecessor_observer.py <observer.py> <frozen_dir> <work_dir> <out.json>
Every verdict comes from frozen code: D4_PREDECESSOR_RECONCILIATION.reconcile and D4_FIRST_ADMISSION_BOOTSTRAP.
fresh_predecessor (with prep.Reads on POSIX).  Declared stand-ins (Linux has no Win32): FakeNative replaces the
Windows primitives (directory identity from os.stat, process snapshot, boot time, admin flag, mutex probe) and the
bootstrap's check_native_process_boundary is replaced by an equivalent that consults the fake mutex.  The native
primitives themselves are qualified on Windows by the lab procedure (RUN_CDT21_V005_PREPARO_D4 -Etapa Qualificar).
"""
import datetime as dt
import hashlib
import importlib.util
import json
import os
import shutil
import sys
import traceback
import zipfile
from pathlib import Path

OBS_PATH, FROZEN_DIR, WORK, OUT = sys.argv[1], sys.argv[2], Path(sys.argv[3]), Path(sys.argv[4])
spec = importlib.util.spec_from_file_location('observer_under_test', OBS_PATH)
O = importlib.util.module_from_spec(spec); spec.loader.exec_module(O)
F = O.load_frozen(FROZEN_DIR)
H = lambda b: hashlib.sha256(b).hexdigest().upper()
NOW = O.utc_now
OWN_CREATION = 133000000000000000


class FakeNative:
    def __init__(self, boot=None, admin=True, mutex=False, extra=(), hook=None):
        self.boot = boot or (NOW() - dt.timedelta(hours=2))
        self.admin, self.mutex, self.extra, self.hook = admin, mutex, list(extra), hook

    def dir_identity(self, p):
        st = os.stat(p)
        return {'volume': int(st.st_dev), 'file_id': '%032X' % st.st_ino, 'bytes': 0, 'links': st.st_nlink, 'path': O.norm(p)}

    def mutex_probe(self):
        return {'operation': 'OpenMutexW_ONLY', 'name': F.engine.PROCESS_CENSUS_MUTEX, 'present': self.mutex, 'error': 0 if self.mutex else 2}

    def is_admin(self):
        return self.admin

    def boot_utc(self):
        if self.hook:
            self.hook()
        return self.boot, int((NOW() - self.boot).total_seconds() * 1000)

    def processes(self):
        base = [{'pid': 4, 'parent_pid': 0, 'exe': 'System', 'image': None, 'creation_time': None, 'command_line': None, 'exited': False},
                {'pid': 900, 'parent_pid': 4, 'exe': 'csrss.exe', 'image': None, 'creation_time': 1, 'command_line': None, 'exited': False},
                {'pid': 1200, 'parent_pid': 1000, 'exe': 'explorer.exe', 'image': r'C:\Windows\explorer.exe', 'creation_time': 2,
                 'command_line': r'C:\Windows\explorer.exe', 'exited': False},
                {'pid': 2000, 'parent_pid': 1200, 'exe': 'powershell.exe', 'image': r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                 'creation_time': 3, 'command_line': r'powershell -NoProfile -File C:\Users\silvi\Downloads\RUN_CDT21_V005_PREPARO_D4_20261022.ps1',
                 'exited': False},
                {'pid': os.getpid(), 'parent_pid': 2000, 'exe': 'python.exe', 'image': r'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe',
                 'creation_time': OWN_CREATION, 'command_line': 'python.exe -I -B CDT21_D4_PREDECESSOR_OBSERVER.py --request REQ.json', 'exited': False}]
        return base + self.extra

    def self_identity(self):
        return os.getpid(), OWN_CREATION

    def spawn_probe(self, kind):
        p = {'pid': 5000 + len(self.extra), 'parent_pid': os.getpid(), 'exe': 'python.exe' if kind == 'PYTHON' else 'powershell.exe',
             'image': 'C:\\P\\python.exe' if kind == 'PYTHON' else 'C:\\W\\powershell.exe', 'creation_time': 7,
             'command_line': 'python -c sleep' if kind == 'PYTHON' else 'powershell Start-Sleep # tickstore-marker-lab-probe', 'exited': False}
        self.extra.append(p); return p

    def stop_probe(self, p):
        self.extra.remove(p)


def boundary_for(native):
    def check():
        if native.mutex:
            raise RuntimeError('RECOVERY_PROCESS_LEASE_PRESENT_OR_UNKNOWN')
    return check


def lab(name, started=None):
    root = WORK / name
    if root.exists():
        shutil.rmtree(root)
    return O.build_lab(root / 'lab', FakeNative(), F.engine, started or (NOW() - dt.timedelta(hours=3))), root


def observe(name, native=None, mutate=None, started=None):
    info, root = lab(name, started)
    if mutate:
        mutate(info)
    native = native or FakeNative()
    rec = O.run_observation(F, native, info['control_root'], info['resume_root'], root / 'evidence', native_boundary=boundary_for(native))
    return rec, info, root


def reasons(rec):
    return set(rec['self_check']['reconcile']['reasons'])


def obs_of(root):
    return json.loads((root / 'evidence/predecessor_observer/predecessor_evidence/OBSERVATION.json').read_bytes())


def tree_fp(p):
    out = []
    for q in sorted(Path(p).rglob('*')):
        st = os.lstat(q)
        out.append((str(q), st.st_size, st.st_mtime_ns, H(q.read_bytes()) if q.is_file() else None))
    return out


def rewrite_journal(info, fn):
    jp = Path(info['control_root']) / 'state/STATE_JOURNAL.jsonl'
    recs = [json.loads(l) for l in jp.read_bytes().splitlines()]
    recs = fn(recs)
    lines, prev = [], ''
    for r in recs:
        r = dict(r); r['prev_line_sha256'] = prev
        raw = F.engine.json_bytes(r).rstrip(b'\n'); lines.append(raw); prev = H(raw)
    jp.write_bytes(b'\n'.join(lines) + b'\n')


def rebuild_bundle(info, gate_update):
    rd = Path(info['bundle']).parent; bp = Path(info['bundle']); ap = bp.with_name(bp.stem + '.anchor.json')
    with zipfile.ZipFile(bp) as z:
        mem = {n: z.read(n) for n in z.namelist()}
    gate = F.engine.parse(mem['OWNER_GATE.json']); gate.update(gate_update)
    mem['OWNER_GATE.json'] = F.engine.json_bytes(gate)
    del mem['RELEASE_MANIFEST.json']
    man = {'schema': 'RELEASE_MANIFEST_V004', 'members': {n: {'sha256': H(b), 'bytes': len(b)} for n, b in sorted(mem.items())}}
    mem['RELEASE_MANIFEST.json'] = F.engine.json_bytes(man)
    with zipfile.ZipFile(bp, 'w', compression=zipfile.ZIP_STORED) as z:
        for n, b in sorted(mem.items()):
            zi = zipfile.ZipInfo(n, (1980, 1, 1, 0, 0, 0)); z.writestr(zi, b)
    anchor = F.engine.parse(ap.read_bytes())
    anchor.update(release_bundle_sha256=H(bp.read_bytes()), owner_gate_sha256=H(mem['OWNER_GATE.json']),
                  release_manifest_sha256=H(mem['RELEASE_MANIFEST.json']))
    ap.write_bytes(F.engine.json_bytes(anchor))


CASES = []


def case(fn):
    CASES.append(fn); return fn


@case
def P1_positive_fresh_evidence_admitted_by_frozen_consumers():
    rec, info, root = observe('P1')
    assert rec['status'] == 'PASS_FRESH_PREDECESSOR_EVIDENCE', rec['self_check']
    assert rec['self_check']['reconcile']['classification'] == 'PREDECESSOR_TERMINATED_COMPLETION_UNPROVEN'
    assert rec['self_check']['fresh_predecessor'] == 'PASS' and rec['self_check']['state_first_admission_shape'] == 'PASS'
    o = obs_of(root)
    assert o['schema'] == 'TICKSTORE_D4_PREDECESSOR_OBSERVATION_V001' and o['run'] == info['run'] and o['gate_mode'] == 'CERTIFY_SCRATCH'
    assert rec['roots_classification'] == 'FIRST_ADMISSION_NO_CHECKPOINT' and rec['production_writes'] is False
    return {'run': o['run'], 'processes': rec['processes_listed'], 'unreadable_non_interpreter': rec['unreadable_non_interpreter']}


@case
def P2_rerun_archives_previous_evidence_never_deletes():
    rec, info, root = observe('P2')
    first = {p.name: H(p.read_bytes()) for p in (root / 'evidence').rglob('*.json')}
    native = FakeNative()
    rec2 = O.run_observation(F, native, info['control_root'], info['resume_root'], root / 'evidence', native_boundary=boundary_for(native))
    hist = list((root / 'evidence/HISTORICO_OBSERVACOES').iterdir())
    assert rec2['status'] == 'PASS_FRESH_PREDECESSOR_EVIDENCE' and len(hist) == 1
    kept = {p.name: H(p.read_bytes()) for p in hist[0].rglob('*.json')}
    assert kept == first and set(rec2['archived_previous']) == {'predecessor_observer', 'D4_ROOTS_REPORT.json', 'CDT21_D4_PREDECESSOR_OBSERVER_RECEIPT.json'}
    return {'archived': sorted(kept)}


@case
def P3_read_only_on_control_resume_and_canary_trees():
    info, root = lab('P3')
    lab_root = Path(info['control_root']).parent
    before = tree_fp(lab_root)
    native = FakeNative()
    rec = O.run_observation(F, native, info['control_root'], info['resume_root'], root / 'evidence', native_boundary=boundary_for(native))
    assert rec['status'] == 'PASS_FRESH_PREDECESSOR_EVIDENCE' and tree_fp(lab_root) == before
    return {'files_compared': len(before)}


def refused(name, expect, **kw):
    rec, info, root = observe(name, **kw)
    assert rec['status'] == 'BLOCKED' and not rec['self_check']['pass'], rec['status']
    got = reasons(rec)
    assert expect <= got, (expect, got)
    return rec, info, root, got


@case
def N01_other_python_process_refused():
    extra = [{'pid': 3333, 'parent_pid': 1200, 'exe': 'python.exe', 'image': r'C:\Python\python.exe', 'creation_time': 9,
              'command_line': 'python.exe tool.py', 'exited': False}]
    return sorted(refused('N01', {'UNCLASSIFIED_PYTHON_PROCESS'}, native=FakeNative(extra=extra))[3])


@case
def N02_tickstore_marker_process_refused():
    extra = [{'pid': 3334, 'parent_pid': 1200, 'exe': 'powershell.exe', 'image': r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
              'creation_time': 9, 'command_line': r'powershell -File D:\X\TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1', 'exited': False}]
    rec, info, root, got = refused('N02', {'RECOVERY_PROCESS_OBSERVED'}, native=FakeNative(extra=extra))
    hit = [p for p in json.loads((root / 'evidence/predecessor_observer/PREDECESSOR_SYSTEM.json').read_bytes())['processes'] if p['pid'] == 3334]
    assert hit and hit[0]['tickstore_marker'] is True and 'command_line' in hit[0]
    return sorted(got)


@case
def N03_unreadable_interpreter_listed_and_refused():
    extra = [{'pid': 3335, 'parent_pid': 1200, 'exe': 'powershell.exe', 'image': None, 'creation_time': None, 'command_line': None, 'exited': False}]
    return sorted(refused('N03', {'PROCESS_IDENTITY_INCOMPLETE'}, native=FakeNative(extra=extra))[3])


@case
def N04_not_elevated_refused():
    return sorted(refused('N04', {'NATIVE_CENSUS_NOT_QUALIFIED'}, native=FakeNative(admin=False))[3])


@case
def N05_no_boot_after_predecessor_start_refused():
    return sorted(refused('N05', {'LATER_BOOT_NOT_PROVEN'}, native=FakeNative(boot=NOW() - dt.timedelta(days=2)))[3])


@case
def N06_writer_lock_present_refused():
    rec, info, root, got = refused('N06', {'WRITER_LOCK_ABSENCE_NOT_PROVEN'},
                                   mutate=lambda i: (Path(i['canary']['dest']) / 'TICKSTORE_WRITER.lock').write_bytes(b'{}'))
    assert [l for l in obs_of(root)['locks'] if l['root'] == 'dest'][0]['present'] is True
    return sorted(got)


@case
def N07_census_mutex_present_refused():
    rec, info, root, got = refused('N07', {'LEASE_ABSENCE_NOT_PROVEN'}, native=FakeNative(mutex=True))
    assert rec['self_check']['fresh_predecessor'].startswith('BLOCKED')
    return sorted(got)


@case
def N08_root_identity_drift_refused():
    def drift(i):
        p = Path(i['canary']['scratch']); p.rename(p.with_name('scratch_previous_identity')); p.mkdir()
    rec, info, root, got = refused('N08', {'ROOT_IDENTITY'}, mutate=drift)
    r = obs_of(root)['roots']['scratch_root']
    assert r['same_identity'] is False and r['historical']['file_id'] != r['actual']['file_id']
    return sorted(got)


@case
def N09_recovery_root_not_empty_refused():
    rec, info, root, got = refused('N09', {'RECOVERY_OUTPUT_PRESENT_OR_UNKNOWN'},
                                   mutate=lambda i: (Path(i['canary']['recovery']) / 'certify_scratch.X.json').write_bytes(b'{}'))
    assert obs_of(root)['recovery_entries'] == ['certify_scratch.X.json']
    return sorted(got)


@case
def N10_predecessor_finished_after_start_refused():
    def fin(i):
        rewrite_journal(i, lambda r: r + [{'ts': O.utc_now().astimezone().isoformat(timespec='milliseconds'), 'node': 'D4',
                                           'phase': 'FINISHED', 'status': 'FAIL', 'primary_error': 'X'}])
    rec, info, root, got = refused('N10', {'PREDECESSOR_NOT_IDENTIFIED'}, mutate=fin)
    assert obs_of(root)['run'] is None
    return sorted(got)


@case
def N11_journal_chain_broken_refused():
    def brk(i):
        jp = Path(i['control_root']) / 'state/STATE_JOURNAL.jsonl'
        ls = jp.read_bytes().splitlines(); r = json.loads(ls[1]); r['primary_error'] = 'TAMPERED'
        ls[1] = F.engine.json_bytes(r).rstrip(b'\n'); jp.write_bytes(b'\n'.join(ls) + b'\n')
    # The frozen reconcile notes JOURNAL_CHAIN and then raises AttributeError on roots.journal.last == None
    # (D4_ROOTS_EVIDENCE.journal_facts sets it to None for a broken chain): fail-closed by exception, recorded.
    rec, info, root, got = refused('N11', {'FROZEN_RECONCILE_EXCEPTION:AttributeError'}, mutate=brk)
    assert obs_of(root)['journal_chain_intact'] is False and rec['self_check']['fresh_predecessor'].startswith('BLOCKED')
    return sorted(got)


@case
def N12_bundle_bytes_not_bound_to_anchor_refused():
    def flip(i):
        p = Path(i['bundle']); b = bytearray(p.read_bytes()); b[-30] ^= 1; p.write_bytes(bytes(b))
    rec, info, root, got = refused('N12', {'BUNDLE_IDENTITY_NOT_BOUND'}, mutate=flip)
    assert obs_of(root)['bundle_binding_verified'] is False
    return sorted(got)


@case
def N13_predecessor_gate_mode_not_certify_scratch_refused():
    rec, info, root, got = refused('N13', {'PREDECESSOR_EFFECT_SCOPE'}, mutate=lambda i: rebuild_bundle(i, {'mode': 'CERTIFY_CANONICAL'}))
    assert obs_of(root)['bundle_binding_verified'] is True and obs_of(root)['gate_mode'] == 'CERTIFY_CANONICAL'
    return sorted(got)


@case
def N14_state_changed_after_observation_refused_by_bootstrap():
    rec, info, root = observe('N14')
    assert rec['status'] == 'PASS_FRESH_PREDECESSOR_EVIDENCE'
    sp = Path(info['control_root']) / 'state/STATE.json'; sp.write_bytes(sp.read_bytes() + b' ')
    jr = (Path(info['control_root']) / 'state/STATE_JOURNAL.jsonl').read_bytes()
    chk = O.self_check(root / 'evidence', F, sp.read_bytes(), jr, native_boundary=boundary_for(FakeNative()))
    assert chk['fresh_predecessor'] == 'BLOCKED:PREDECESSOR_CURRENT_STATE_JOURNAL', chk
    return chk['fresh_predecessor']


@case
def N15_observation_older_than_300s_refused_by_bootstrap():
    rec, info, root = observe('N15')
    sp = root / 'evidence/predecessor_observer/PREDECESSOR_SYSTEM.json'
    s = json.loads(sp.read_bytes()); s['observed_utc'] = O.zulu(O.utc_now() - dt.timedelta(seconds=301)); sp.write_bytes(json.dumps(s).encode())
    cr = Path(info['control_root'])
    chk = O.self_check(root / 'evidence', F, (cr / 'state/STATE.json').read_bytes(), (cr / 'state/STATE_JOURNAL.jsonl').read_bytes(),
                       native_boundary=boundary_for(FakeNative()))
    assert chk['fresh_predecessor'] == 'BLOCKED:PREDECESSOR_OBSERVATION_NOT_FRESH_300S', chk
    return chk['fresh_predecessor']


@case
def N16_input_changed_during_observation_refused():
    holder = {}
    def mutate(i):
        holder['state'] = Path(i['control_root']) / 'state/STATE.json'
    def hook():
        p = holder['state']; p.write_bytes(p.read_bytes() + b' ')
    rec, info, root, got = refused('N16', {'OBSERVATION_STABILITY'}, native=FakeNative(hook=hook), mutate=mutate)
    assert obs_of(root)['inputs_unchanged'] is False
    return sorted(got)


@case
def N17_two_bundles_for_the_predecessor_refused():
    def dup(i):
        p = Path(i['bundle']); q = p.with_name(p.stem[:-8] + 'ABCDEF12.zip'); shutil.copyfile(p, q)
    rec, info, root, got = refused('N17', {'BUNDLE_IDENTITY_NOT_BOUND'}, mutate=dup)
    assert obs_of(root)['bundle']['reason'] == 'BUNDLE_CARDINALITY:2'
    return sorted(got)


@case
def N18_existing_run_authority_not_first_admission_refused():
    def ra(i):
        d = Path(i['resume_root']) / 'authority'; d.mkdir()
        (d / 'RUN_AUTHORITY.json').write_text(json.dumps({'schema': 'TICKSTORE_D4_RUN_AUTHORITY_V005', 'run_id': 'X'}))
    rec, info, root, got = refused('N18', {'FIRST_ADMISSION_SCOPE_NOT_PROVEN'}, mutate=ra)
    assert rec['roots_classification'] != 'FIRST_ADMISSION_NO_CHECKPOINT'
    return sorted(got)


@case
def N19_frozen_consumer_bytes_drift_refused_at_load():
    bad = WORK / 'N19_frozen'
    if bad.exists():
        shutil.rmtree(bad)
    shutil.copytree(FROZEN_DIR, bad)
    p = bad / 'control/D4_PREDECESSOR_RECONCILIATION.py'; p.write_bytes(p.read_bytes() + b'\n')
    try:
        O.load_frozen(bad)
    except O.Blocked as exc:
        assert str(exc) == 'FROZEN_SHA:control/D4_PREDECESSOR_RECONCILIATION.py'
        return str(exc)
    raise AssertionError('drifted frozen consumer accepted')


@case
def L1_lab_qualification_sequence_positive_and_four_refusals():
    root = WORK / 'L1'
    if root.exists():
        shutil.rmtree(root)
    native = FakeNative()
    q = O.qualify_lab(F, native, root / 'lab', root / 'evidence', native_boundary=boundary_for(native))
    assert q['status'] == 'PASS_NATIVE_LAB_QUALIFICATION', q['cases']
    assert [c['case'] for c in q['cases']] == ['Q1_POSITIVE_NATIVE', 'Q2_WRITER_LOCK_PRESENT', 'Q3_OTHER_PYTHON_PROCESS', 'Q4_MARKER_PROCESS',
                                              'Q5_ROOT_IDENTITY_CHANGED'] and native.extra == []
    assert not (Path(q['positive_receipt']['evidence_dir']).parent.parent / 'lab/A/canary/dest' / 'TICKSTORE_WRITER.lock').exists()
    return [(c['case'], c['status']) for c in q['cases']]


results = []
for fn in CASES:
    try:
        detail = fn(); results.append({'case': fn.__name__, 'pass': True, 'detail': detail})
    except Exception as exc:
        results.append({'case': fn.__name__, 'pass': False, 'detail': type(exc).__name__ + ':' + str(exc)[:400],
                        'trace': traceback.format_exc()[-1500:]})
doc = {'schema': 'CDT21_D4_PREDECESSOR_OBSERVER_LINUX_QUALIFICATION_V001', 'observer_sha256': H(Path(OBS_PATH).read_bytes()),
       'frozen_pins': O.FROZEN, 'python': sys.version.split()[0], 'stand_ins': ['FakeNative (Win32 primitives)', 'check_native_process_boundary (fake mutex)'],
       'results': results, 'passed': sum(r['pass'] for r in results), 'total': len(results)}
OUT.write_text(json.dumps(doc, indent=1, ensure_ascii=False, default=str), encoding='utf-8')
print('OBSERVER_QUALIFICATION', doc['passed'], '/', doc['total'], [r['case'] for r in results if not r['pass']])
