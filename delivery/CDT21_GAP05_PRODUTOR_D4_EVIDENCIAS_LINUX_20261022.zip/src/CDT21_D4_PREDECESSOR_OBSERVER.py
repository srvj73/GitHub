"""CDT21 V005 (GAP-05) - producer of the fresh native D4 predecessor evidence, external to the frozen V005 candidate.

Consumers (frozen V005, unchanged):
  * D4_FIRST_ADMISSION_BOOTSTRAP.fresh_predecessor reads, inside --predecessor-evidence (= instance
    d4_parameters.PredecessorEvidenceDir):
      predecessor_observer/predecessor_evidence/OBSERVATION.json  (TICKSTORE_D4_PREDECESSOR_OBSERVATION_V001)
      predecessor_observer/PREDECESSOR_SYSTEM.json                (TICKSTORE_D4_PREDECESSOR_SYSTEM_OBSERVATION_V001)
      D4_ROOTS_REPORT.json                                        (TICKSTORE_D4_ROOTS_EVIDENCE_V001)
    then requires D4_PREDECESSOR_RECONCILIATION.reconcile(...) == PREDECESSOR_TERMINATED_COMPLETION_UNPROVEN, the
    observed STATE/journal digests equal to the bytes it reads, an observation at most 300 s old (checked twice:
    before materialization and in revalidate()) and the census mutex absent.
This producer only composes frozen code: D4_ROOTS_EVIDENCE.main/journal_facts (roots report and D4 journal entries),
the frozen engine's Win32Store (root identities, the same call as orchestrator.O.bind that wrote the predecessor's
OWNER_GATE root_bindings) and PROCESS_CENSUS_MUTEX, and D4_FIRST_ADMISSION_PREP.strict_json/validate_journal.  After
writing, it runs the frozen consumers themselves (reconcile and fresh_predecessor) as a self-check.

Read-only on production: it never writes outside the evidence directory, never opens anything for writing in the
control/resume/canary roots and never creates the census mutex.  Previous evidence files are moved (never deleted)
to <evidence>/HISTORICO_OBSERVACOES/<stamp>/.

Usage (always through RUN_CDT21_V005_PREPARO_D4_*.ps1):  python -I -B CDT21_D4_PREDECESSOR_OBSERVER.py --request <request.json>
Request keys: mode (OBSERVE | QUALIFY_LAB), frozen_dir, evidence_dir, out_receipt, [lab_root].  Paths never go on the
command line (the census refuses any process whose command line carries the 'tickstore' marker).
"""
from __future__ import annotations

import argparse
import ctypes
import datetime as dt
import hashlib
import importlib.util
import io
import json
import os
import shutil
import sys
import types
import uuid
import zipfile
from pathlib import Path

SCHEMA_RECEIPT = 'CDT21_D4_PREDECESSOR_OBSERVER_RECEIPT_V001'
OBS_SCHEMA = 'TICKSTORE_D4_PREDECESSOR_OBSERVATION_V001'
SYS_SCHEMA = 'TICKSTORE_D4_PREDECESSOR_SYSTEM_OBSERVATION_V001'
# Frozen V005 bytes this producer composes (equal to the V005 RUNTIME_CODE_MANIFEST and to FIRST_ADMISSION_BINDING).
FROZEN = {
    'recovery/engine/tickstore_publisher_recovery_v004_release.py': '4BB92D88DB728F4BAE3C207C4627F6FDA4D2FAB593E785E7311A90D3CC9F11E7',
    'control/D4_ROOTS_EVIDENCE.py': '048190A53BF432D4F7341D3FA2DAEFC192E680EC189AEBAF4C65BBF1B7A7729F',
    'control/D4_PREDECESSOR_RECONCILIATION.py': '2F96470E336CBDFB88A92C7BF4494DA99C9BCEFF5EA3635805F460515A11FD97',
    'control/D4_FIRST_ADMISSION_BOOTSTRAP.py': 'E15FD508F2E2AD69A8892BE3EF797BD2CD47636030FCAC879B07E80BB61957A6',
    'control/D4_FIRST_ADMISSION_PREP.py': '9F611EF8DC50768C81E27A6604D028600653AD2C8E0E8CE72B0F536043B015A1',
    'control/FIRST_ADMISSION_BINDING.json': '7CF7D5BB3E47AD1B98BEF2F2329ACFD69FF31FB42B89DE7B311D2B11547625F6',
    'recovery/config/STAGE_A_SEALED_VALUES_V001.json': '07DD406B9AD03EE12FAEB7E6CCD46A1C8BB04E14DE1538E7C673704641A87D60',
    'control/60_EFFECTFUL_WRAPPER_RELEASE.ps1': 'B8FC4099F1F6AA87CFA627ACC893247874FE1A3E6CCBF4F5D4C64FC4C2C0485B',
}
# The sealed wrapper's literals (60_EFFECTFUL_WRAPPER_RELEASE.ps1 $ResumeRoot / $ControlRoot); checked at load time.
RESUME_ROOT = r'D:\Base CSV\Scripts\TICKSTORE_R9_DEV\TICKSTORE_D4_RESUMABLE_V002R22'
ROOT_KEYS = (('dest_root', 'dest'), ('scratch_root', 'scratch'), ('recovery_root', 'recovery'))
LOCK_NAME = 'TICKSTORE_WRITER.lock'
GATE_MODE = 'CERTIFY_SCRATCH'
MARKER = 'tickstore'
INTERPRETERS = {'python.exe', 'pythonw.exe', 'py.exe', 'pyw.exe', 'powershell.exe', 'pwsh.exe', 'cmd.exe', 'wscript.exe', 'cscript.exe'}
FRESH_SECONDS = 300


class Blocked(RuntimeError):
    pass


def require(ok, why):
    if not ok:
        raise Blocked(why)


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def sha_file(p):
    return sha(Path(p).read_bytes())


def utc_now():
    return dt.datetime.now(dt.timezone.utc)


def zulu(t):
    return t.astimezone(dt.timezone.utc).isoformat(timespec='microseconds').replace('+00:00', 'Z')


def norm(p):
    return os.path.normcase(os.path.abspath(str(p))).rstrip('\\/')


# ---------------------------------------------------------------------------------------------------- frozen code
def _module(path, name):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def load_frozen(frozen_dir):
    """Load the exact V005 bytes (pinned); the producer never carries its own copy of consumer logic."""
    root = Path(frozen_dir)
    for rel, digest in FROZEN.items():
        require(sha_file(root / rel) == digest, 'FROZEN_SHA:' + rel)
    binding = json.loads((root / 'control/FIRST_ADMISSION_BINDING.json').read_bytes())
    require(binding['predecessor_reconciliation_sha256'] == FROZEN['control/D4_PREDECESSOR_RECONCILIATION.py']
            and binding['preparation_sha256'] == FROZEN['control/D4_FIRST_ADMISSION_PREP.py']
            and binding['bootstrap_sha256'] == FROZEN['control/D4_FIRST_ADMISSION_BOOTSTRAP.py'], 'FROZEN_BINDING_PINS')
    cfg = json.loads((root / 'recovery/config/STAGE_A_SEALED_VALUES_V001.json').read_bytes())
    wrapper = (root / 'control/60_EFFECTFUL_WRAPPER_RELEASE.ps1').read_text(encoding='utf-8-sig')
    require("$ResumeRoot = '" + RESUME_ROOT + "'" in wrapper and "$ControlRoot = '" + cfg['control_root'] + "'" in wrapper,
            'WRAPPER_ROOT_LITERALS')
    ns = types.SimpleNamespace(cfg=cfg, binding=binding)
    eraw = (root / 'recovery/engine/tickstore_publisher_recovery_v004_release.py').read_bytes()
    eng = {'__name__': 'cdt21_observer_frozen_engine', '__file__': '<frozen_engine>'}
    exec(compile(eraw, eng['__file__'], 'exec'), eng)
    ns.engine = types.SimpleNamespace(**eng)
    ns.roots = _module(root / 'control/D4_ROOTS_EVIDENCE.py', 'cdt21_observer_frozen_roots')
    ns.reconcile = _module(root / 'control/D4_PREDECESSOR_RECONCILIATION.py', 'cdt21_observer_frozen_reconcile')
    ns.prep = _module(root / 'control/D4_FIRST_ADMISSION_PREP.py', 'cdt21_observer_frozen_prep')
    ns.bootstrap = _module(root / 'control/D4_FIRST_ADMISSION_BOOTSTRAP.py', 'cdt21_observer_frozen_bootstrap')
    return ns


# ---------------------------------------------------------------------------------------------------- native (Windows)
class WindowsNative:
    """Native primitives.  Root identity = frozen engine Win32Store (the call orchestrator.O.bind used); the census
    mutex probe is the exact call of D4_FIRST_ADMISSION_BOOTSTRAP.check_native_process_boundary."""

    def __init__(self, frozen):
        require(os.name == 'nt', 'NATIVE_WINDOWS_REQUIRED')
        from ctypes import wintypes as w
        self.w = w
        self.frozen = frozen
        self.store = frozen.engine.Win32Store()
        self.k = ctypes.WinDLL('kernel32', use_last_error=True)
        self.nt = ctypes.WinDLL('ntdll')
        k = self.k
        k.OpenMutexW.argtypes = [w.DWORD, w.BOOL, w.LPCWSTR]; k.OpenMutexW.restype = w.HANDLE
        k.CloseHandle.argtypes = [w.HANDLE]; k.CloseHandle.restype = w.BOOL
        k.GetTickCount64.restype = ctypes.c_ulonglong
        k.OpenProcess.restype = w.HANDLE; k.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
        k.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, ctypes.POINTER(w.DWORD)]
        k.GetProcessTimes.argtypes = [w.HANDLE] + [ctypes.POINTER(ctypes.c_ulonglong)] * 4
        k.CreateToolhelp32Snapshot.restype = w.HANDLE; k.CreateToolhelp32Snapshot.argtypes = [w.DWORD, w.DWORD]
        P = frozen.engine.PROCESSENTRY32W
        k.Process32FirstW.argtypes = [w.HANDLE, ctypes.POINTER(P)]; k.Process32NextW.argtypes = [w.HANDLE, ctypes.POINTER(P)]
        self.nt.NtQueryInformationProcess.argtypes = [w.HANDLE, ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong)]
        self.nt.NtQueryInformationProcess.restype = ctypes.c_long

    def dir_identity(self, path):
        with self.store.open(Path(path), directory=True) as f:
            return f.info()

    def mutex_probe(self):
        ctypes.set_last_error(0)
        h = self.k.OpenMutexW(0x100000, False, self.frozen.engine.PROCESS_CENSUS_MUTEX)
        error = ctypes.get_last_error()
        if h:
            self.k.CloseHandle(h)
        return {'operation': 'OpenMutexW_ONLY', 'name': self.frozen.engine.PROCESS_CENSUS_MUTEX, 'present': bool(h), 'error': int(error)}

    def is_admin(self):
        return bool(ctypes.WinDLL('shell32').IsUserAnAdmin())

    def boot_utc(self):
        ms = int(self.k.GetTickCount64())
        return utc_now() - dt.timedelta(milliseconds=ms), ms

    def _creation(self, h):
        v = [ctypes.c_ulonglong() for _ in range(4)]
        return int(v[0].value) if self.k.GetProcessTimes(h, *(ctypes.byref(x) for x in v)) else None

    def _image(self, h):
        cap = self.w.DWORD(32768); buf = ctypes.create_unicode_buffer(cap.value)
        return buf.value if self.k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(cap)) else None

    def _command_line(self, h):
        need = ctypes.c_ulong(0)
        self.nt.NtQueryInformationProcess(h, 60, None, 0, ctypes.byref(need))  # ProcessCommandLineInformation
        if need.value == 0 or need.value > 1 << 20:
            return None
        buf = ctypes.create_string_buffer(need.value)
        if self.nt.NtQueryInformationProcess(h, 60, buf, need, ctypes.byref(need)) != 0:
            return None

        class US(ctypes.Structure):
            _fields_ = [('Length', ctypes.c_ushort), ('MaximumLength', ctypes.c_ushort), ('Buffer', ctypes.c_void_p)]
        us = US.from_buffer(buf)
        return ctypes.wstring_at(us.Buffer, us.Length // 2) if us.Buffer else ''

    def processes(self):
        """Raw snapshot: [{pid, parent_pid, exe, image, creation_time, command_line}] (None = unreadable)."""
        P = self.frozen.engine.PROCESSENTRY32W
        snap = self.k.CreateToolhelp32Snapshot(0x2, 0)
        require(snap and snap != ctypes.c_void_p(-1).value, 'CENSUS_SNAPSHOT')
        out = []
        try:
            e = P(); e.dwSize = ctypes.sizeof(P)
            ok = self.k.Process32FirstW(snap, ctypes.byref(e))
            while ok:
                pid = int(e.th32ProcessID); rec = {'pid': pid, 'parent_pid': int(e.th32ParentProcessID), 'exe': str(e.szExeFile),
                                                   'image': None, 'creation_time': None, 'command_line': None, 'exited': False}
                if pid not in (0, 4):
                    h = self.k.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
                    if h:
                        try:
                            rec.update(image=self._image(h), creation_time=self._creation(h), command_line=self._command_line(h))
                        finally:
                            self.k.CloseHandle(h)
                    elif ctypes.get_last_error() == 87:
                        rec['exited'] = True
                out.append(rec)
                ok = self.k.Process32NextW(snap, ctypes.byref(e))
        finally:
            self.k.CloseHandle(snap)
        return out

    def spawn_probe(self, kind):
        import subprocess
        if kind == 'PYTHON':
            cmd = [sys.executable, '-I', '-S', '-c', 'import time; time.sleep(120)']
        else:  # MARKER: an interpreter whose command line carries the marker
            cmd = [os.path.join(os.environ['SystemRoot'], 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe'),
                   '-NoProfile', '-Command', 'Start-Sleep -Seconds 120 # tickstore-marker-lab-probe']
        p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=0x08000000)
        import time
        time.sleep(2)
        return p

    def stop_probe(self, p):
        p.kill(); p.wait(timeout=30)

    def self_identity(self):
        h = self.k.OpenProcess(0x1000, False, os.getpid())
        try:
            return os.getpid(), self._creation(h)
        finally:
            self.k.CloseHandle(h)


# ---------------------------------------------------------------------------------------------------- census
def census(native):
    """Every process whose command line is readable is listed; every interpreter or shell is listed even when
    unreadable (command_available False -> the frozen reconcile refuses).  Unreadable non-interpreter processes
    (kernel/protected) are reported apart, never hidden.  Command lines are kept only for interpreters/shells and
    marker hits; the rest is reduced to SHA-256 and length."""
    own_pid, own_creation = native.self_identity()
    listed, apart, exited = [], [], []
    for r in native.processes():
        if r['exited']:
            exited.append({'pid': r['pid'], 'exe': r['exe']}); continue
        base = (r['image'] or r['exe'] or '').replace('/', '\\').rsplit('\\', 1)[-1].lower()
        interp = base in INTERPRETERS or (r['exe'] or '').lower() in INTERPRETERS
        readable = r['command_line'] is not None and r['image'] is not None
        if not readable and not interp:
            apart.append({'pid': r['pid'], 'exe': r['exe']}); continue
        text = (r['command_line'] or '') + '\n' + (r['image'] or '')
        marker = MARKER in text.lower()
        is_obs = r['pid'] == own_pid and r['creation_time'] == own_creation
        item = {'pid': r['pid'], 'parent_pid': r['parent_pid'], 'exe': base or (r['exe'] or ''), 'image': r['image'],
                'creation_time': r['creation_time'],
                'command_available': readable, 'tickstore_marker': marker, 'is_observer': is_obs,
                'command_line_sha256': sha((r['command_line'] or '').encode('utf-16-le')) if readable else None,
                'command_line_chars': len(r['command_line']) if readable else None}
        if interp or marker:
            item['command_line'] = r['command_line']
        listed.append(item)
    require(any(p['is_observer'] for p in listed), 'CENSUS_OBSERVER_NOT_FOUND')
    return listed, apart, exited


# ---------------------------------------------------------------------------------------------------- predecessor bundle
def bundle_binding(control_root, run, engine):
    """The predecessor's CERTIFY_SCRATCH bundle in <control_root>/runs/<run> (orchestrator.O.cert/bundle): exactly one
    bundle + anchor; anchor bound to the bundle bytes, to OWNER_GATE.json and to the release manifest."""
    rec = {'verified': False, 'gate': None, 'reason': None}
    if not run:
        rec['reason'] = 'NO_PREDECESSOR_RUN'; return rec
    rd = Path(control_root) / 'runs' / run
    if not rd.is_dir():
        rec['reason'] = 'RUN_DIRECTORY_ABSENT'; return rec
    zips = sorted(p for p in rd.iterdir() if p.is_file() and p.name.startswith(GATE_MODE + '_' + run + '_') and p.suffix == '.zip')
    rec['bundles'] = [p.name for p in zips]
    if len(zips) != 1:
        rec['reason'] = 'BUNDLE_CARDINALITY:%d' % len(zips); return rec
    bp = zips[0]; ap = bp.with_name(bp.stem + '.anchor.json')
    if not ap.is_file():
        rec['reason'] = 'ANCHOR_ABSENT'; return rec
    braw, araw = bp.read_bytes(), ap.read_bytes()
    rec.update(bundle={'path': str(bp), 'sha256': sha(braw)}, anchor={'path': str(ap), 'sha256': sha(araw)})
    try:
        anchor = engine.parse(araw)
        with zipfile.ZipFile(io.BytesIO(braw)) as z:
            require(z.testzip() is None, 'BUNDLE_CRC')
            mem = {n: z.read(n) for n in z.namelist()}
        man = engine.parse(mem['RELEASE_MANIFEST.json'])
        require(man.get('schema') == 'RELEASE_MANIFEST_V004' and set(man['members']) | {'RELEASE_MANIFEST.json'} == set(mem), 'BUNDLE_MANIFEST_SET')
        require(all(sha(mem[n]) == v['sha256'] and len(mem[n]) == v['bytes'] for n, v in man['members'].items()), 'BUNDLE_MANIFEST_MEMBER')
        gate = engine.parse(mem['OWNER_GATE.json'])
        require(anchor.get('release_bundle_sha256') == sha(braw), 'ANCHOR_BUNDLE_SHA')
        require(anchor.get('owner_gate_sha256') == sha(mem['OWNER_GATE.json']), 'ANCHOR_OWNER_GATE_SHA')
        require(anchor.get('release_manifest_sha256') == sha(mem['RELEASE_MANIFEST.json']), 'ANCHOR_RELEASE_MANIFEST_SHA')
        require(anchor.get('release_id') == gate.get('release_id') == bp.stem, 'RELEASE_ID')
        require(gate.get('schema') == 'RECOVERY_OWNER_GATE_V004' and isinstance(gate.get('root_bindings'), dict), 'OWNER_GATE_SCHEMA')
        require(anchor.get('recovery_source_sha256') == gate.get('recovery_source_sha256'), 'ANCHOR_RECOVERY_SOURCE')
        rec.update(verified=True, gate={k: gate.get(k) for k in ('mode', 'release_id', 'dest_root', 'scratch_root', 'recovery_root',
                                                                'root_bindings', 'recovery_source_sha256')})
    except (Blocked, KeyError, ValueError, TypeError, zipfile.BadZipFile) as exc:
        rec['reason'] = type(exc).__name__ + ':' + str(exc)
    return rec


# ---------------------------------------------------------------------------------------------------- observation
def snapshot(control_root, run, canary, native):
    """Everything the observation relies on; equal before and after => inputs_unchanged."""
    cr = Path(control_root)
    def f(p):
        p = Path(p)
        return sha_file(p) if p.is_file() else None
    rd = cr / 'runs' / run if run else None
    runs = {p.name: f(p) for p in sorted(rd.iterdir()) if p.is_file()} if rd and rd.is_dir() else None
    ids, locks, rec = {}, {}, None
    for _key, ck in ROOT_KEYS:
        p = canary.get(ck)
        try:
            ids[ck] = native.dir_identity(p) if p else None
        except Exception as exc:  # identity failure is recorded, never ignored
            ids[ck] = 'ERROR:' + type(exc).__name__
        locks[ck] = os.path.lexists(Path(p) / LOCK_NAME) if p else None
    if canary.get('recovery') and Path(canary['recovery']).is_dir():
        rec = sorted(os.listdir(canary['recovery']))
    return {'state': f(cr / 'state/STATE.json'), 'journal': f(cr / 'state/STATE_JOURNAL.jsonl'), 'run_dir': runs,
            'roots': ids, 'locks': locks, 'recovery': rec}


def observe(control_root, resume_root, out_dir, native, frozen):
    """Produce the three evidence files in out_dir (a fresh staging directory) and return (obs, system, roots)."""
    cr, rr, od = Path(control_root), Path(resume_root), Path(out_dir)
    state_path, journal_path = cr / 'state/STATE.json', cr / 'state/STATE_JOURNAL.jsonl'
    state_raw0 = state_path.read_bytes(); state0 = frozen.prep.strict_json(state_raw0)
    canary = {k: (state0.get('canary') or {}).get(k) for k in ('dest', 'scratch', 'recovery')}
    jf0 = frozen.roots.journal_facts(journal_path)
    d4 = jf0.get('d4_entries') or []
    last = d4[-1] if d4 else {}
    run = last.get('run_id') if last.get('phase') == 'STARTED' else None
    before = snapshot(cr, run, canary, native)
    # 1. Roots report: the frozen producer itself (no RUN_LOG wrapper; output inside the staging directory).
    roots_path = od / 'D4_ROOTS_REPORT.json'
    frozen.roots.main(['--resume-root', str(rr), '--control-root', str(cr), '--out', str(roots_path)])
    roots_rep = json.loads(roots_path.read_bytes())
    # 2. Predecessor facts from the same bytes.
    state_raw, journal_raw = state_path.read_bytes(), journal_path.read_bytes()
    jf = frozen.roots.journal_facts(journal_path)
    try:
        strict = frozen.prep.validate_journal(journal_raw); strict_ok = True
    except Exception as exc:
        strict, strict_ok = {'error': str(exc)}, False
    binding = bundle_binding(cr, run, frozen.engine)
    gate = binding.get('gate') or {}
    roots_obs = {}
    for key, ck in ROOT_KEYS:
        actual = before['roots'].get(ck)
        historical = (gate.get('root_bindings') or {}).get(key) or {}
        same = (isinstance(actual, dict) and bool(actual.get('file_id')) and bool(gate.get(key)) and canary.get(ck) is not None
                and norm(gate[key]) == norm(canary[ck]) and actual.get('volume') == historical.get('volume')
                and actual.get('file_id') == historical.get('file_id'))
        roots_obs[key] = {'path': canary.get(ck), 'historical': historical, 'actual': actual if isinstance(actual, dict) else {'error': actual},
                          'same_identity': bool(same)}
    locks = [{'root': ck, 'path': str(Path(canary[ck]) / LOCK_NAME) if canary.get(ck) else None,
              'present': before['locks'].get(ck) is not False} for _key, ck in ROOT_KEYS]
    recovery_entries = before['recovery'] if before['recovery'] is not None else ['<RECOVERY_ROOT_ABSENT_OR_NOT_DIRECTORY>']
    mutex = native.mutex_probe()
    # 3. Native system observation, sampled last.
    boot, uptime_ms = native.boot_utc()
    processes, apart, exited = census(native)
    sampled = utc_now()
    after = snapshot(cr, run, canary, native)
    unchanged = (before == after and sha(state_raw) == before['state'] == roots_rep.get('state', {}).get('sha256')
                 and sha(journal_raw) == before['journal'] == jf['sha256'] == roots_rep.get('journal', {}).get('sha256')
                 and jf == jf0 and roots_rep.get('scope_fingerprint', {}).get('unchanged') is True)
    obs = {'schema': OBS_SCHEMA, 'producer': 'CDT21_D4_PREDECESSOR_OBSERVER', 'read_only': True, 'inputs_unchanged': bool(unchanged),
           'control_root': str(cr), 'resume_root': str(rr), 'run': run,
           'state': {'path': str(state_path), 'sha256': sha(state_raw), 'status': state0.get('status'), 'next_node': state0.get('next_node')},
           'journal': {'path': str(journal_path), 'sha256': sha(journal_raw), 'lines': jf.get('lines'), 'strict_chain': strict},
           'journal_chain_intact': bool(jf.get('chain_intact') and strict_ok), 'd4_entries': d4,
           'bundle_binding_verified': bool(binding['verified']), 'bundle': {k: v for k, v in binding.items() if k != 'gate'},
           'gate_mode': gate.get('mode'), 'roots': roots_obs, 'locks': locks, 'recovery_entries': recovery_entries, 'mutex': mutex,
           'observed_utc': zulu(sampled)}
    system = {'schema': SYS_SCHEMA, 'producer': 'CDT21_D4_PREDECESSOR_OBSERVER', 'observed_utc': zulu(sampled),
              'last_boot_utc': zulu(boot), 'uptime_ms': uptime_ms, 'admin': bool(native.is_admin()), 'processes': processes,
              'census_scope': 'ALL_PROCESSES_WITH_READABLE_COMMAND_LINE + EVERY_INTERPRETER_OR_SHELL (unreadable => command_available False)',
              'not_listed_unreadable_non_interpreter': apart, 'exited_during_census': exited, 'marker': MARKER}
    pd = od / 'predecessor_observer'
    (pd / 'predecessor_evidence').mkdir(parents=True)
    (pd / 'predecessor_evidence' / 'OBSERVATION.json').write_bytes(json.dumps(obs, indent=1, sort_keys=True).encode('utf-8'))
    (pd / 'PREDECESSOR_SYSTEM.json').write_bytes(json.dumps(system, indent=1, sort_keys=True).encode('utf-8'))
    return obs, system, roots_rep, state_raw, journal_raw


def self_check(evidence_dir, frozen, state_raw, journal_raw, native_boundary=None):
    """Run the frozen consumers on the published files: reconcile, then the bootstrap's own fresh_predecessor."""
    out = {}
    reads_cls = frozen.prep.Reads
    obs = json.loads((Path(evidence_dir) / 'predecessor_observer/predecessor_evidence/OBSERVATION.json').read_bytes())
    system = json.loads((Path(evidence_dir) / 'predecessor_observer/PREDECESSOR_SYSTEM.json').read_bytes())
    roots = json.loads((Path(evidence_dir) / 'D4_ROOTS_REPORT.json').read_bytes())
    try:
        out['reconcile'] = frozen.reconcile.reconcile(obs, system, roots)
    except Exception as exc:  # the frozen reconcile fails closed by exception on some inputs (e.g. a broken journal)
        out['reconcile'] = {'classification': 'FROZEN_RECONCILE_EXCEPTION', 'reasons': ['FROZEN_RECONCILE_EXCEPTION:' + type(exc).__name__]}
    saved = frozen.bootstrap.check_native_process_boundary
    if native_boundary is not None:  # Linux qualification only: the Win32 mutex call is replaced and declared
        frozen.bootstrap.check_native_process_boundary = native_boundary
    try:
        store = frozen.engine.Win32Store() if os.name == 'nt' else None
        with reads_cls(store) as reads:
            frozen.bootstrap.fresh_predecessor(reads, evidence_dir, frozen.prep, frozen.reconcile, state_raw, journal_raw)
        out['fresh_predecessor'] = 'PASS'
    except Exception as exc:
        out['fresh_predecessor'] = 'BLOCKED:' + str(exc)
    finally:
        frozen.bootstrap.check_native_process_boundary = saved
    try:
        frozen.prep.validate_state(frozen.prep.strict_json(state_raw)); out['state_first_admission_shape'] = 'PASS'
    except Exception as exc:
        out['state_first_admission_shape'] = 'BLOCKED:' + str(exc)
    out['pass'] = (out['reconcile']['classification'] == 'PREDECESSOR_TERMINATED_COMPLETION_UNPROVEN' and out['fresh_predecessor'] == 'PASS')
    return out


def publish(staging, evidence_dir, stamp):
    """Move previous evidence aside (never deleted), then move the new set into place."""
    ed = Path(evidence_dir); ed.mkdir(parents=True, exist_ok=True)
    targets = ['predecessor_observer', 'D4_ROOTS_REPORT.json', 'CDT21_D4_PREDECESSOR_OBSERVER_RECEIPT.json']
    old = [t for t in targets if os.path.lexists(ed / t)]
    if old:
        hist = ed / 'HISTORICO_OBSERVACOES' / stamp
        hist.mkdir(parents=True)
        for t in old:
            os.replace(ed / t, hist / t)
    for t in ('predecessor_observer', 'D4_ROOTS_REPORT.json'):
        os.replace(Path(staging) / t, ed / t)
    return old


def run_observation(frozen, native, control_root, resume_root, evidence_dir, native_boundary=None):
    stamp = utc_now().strftime('%Y%m%d_%H%M%S_%f') + '_' + str(os.getpid())
    ed = Path(evidence_dir); ed.mkdir(parents=True, exist_ok=True)
    staging = ed / ('.STAGING_' + stamp); staging.mkdir()
    obs, system, roots, state_raw, journal_raw = observe(control_root, resume_root, staging, native, frozen)
    archived = publish(staging, ed, stamp)
    staging.rmdir()
    check = self_check(ed, frozen, state_raw, journal_raw, native_boundary)
    files = {rel: sha_file(ed / rel) for rel in ('predecessor_observer/predecessor_evidence/OBSERVATION.json',
                                                 'predecessor_observer/PREDECESSOR_SYSTEM.json', 'D4_ROOTS_REPORT.json')}
    sampled = dt.datetime.fromisoformat(system['observed_utc'].replace('Z', '+00:00'))
    receipt = {'schema': SCHEMA_RECEIPT, 'status': 'PASS_FRESH_PREDECESSOR_EVIDENCE' if check['pass'] else 'BLOCKED',
               'observer_sha256': sha_file(__file__), 'frozen_pins': FROZEN, 'evidence_dir': str(ed), 'files': files,
               'observed_utc': system['observed_utc'], 'valid_until_utc': zulu(sampled + dt.timedelta(seconds=FRESH_SECONDS)),
               'run': obs['run'], 'gate_mode': obs['gate_mode'], 'bundle_binding_verified': obs['bundle_binding_verified'],
               'inputs_unchanged': obs['inputs_unchanged'], 'mutex': obs['mutex'], 'last_boot_utc': system['last_boot_utc'],
               'processes_listed': len(system['processes']), 'unreadable_non_interpreter': len(system['not_listed_unreadable_non_interpreter']),
               'roots_classification': roots.get('classification'), 'self_check': check, 'archived_previous': archived,
               'native_boundary_stand_in': native_boundary is not None, 'production_writes': False}
    (ed / 'CDT21_D4_PREDECESSOR_OBSERVER_RECEIPT.json').write_bytes(json.dumps(receipt, indent=1, sort_keys=True).encode('utf-8'))
    return receipt


# ---------------------------------------------------------------------------------------------------- lab (qualification)
def build_lab(lab_root, native, engine, started_utc, run='20261001_120000_000_4242'):
    """Synthetic predecessor in an owned lab (never production): STATE FAIL/D4, a journal ending in D4 STARTED for
    `run`, and the CERTIFY_SCRATCH bundle + anchor exactly as orchestrator.O.cert/bundle write them, with
    root_bindings taken by the same native call (orchestrator.O.bind = Win32Store.open(dir).info())."""
    lab = Path(lab_root); require(not lab.exists(), 'LAB_EXISTS')
    cr, rr = lab / 'control', lab / 'resume'
    canary = {k: lab / 'canary' / k for k in ('dest', 'scratch', 'recovery')}
    for p in [cr / 'state', cr / 'runs', cr / 'inbox', cr / 'evidence', rr] + list(canary.values()):
        p.mkdir(parents=True)
    state = {'schema': 'TICKSTORE_ORCH_STATE_V001', 'status': 'FAIL', 'next_node': 'D4', 'completed': ['D1', 'D2', 'D3'],
             'canary_scratch_cert': None, 'G_CA': {'snapshot_id': 'LAB'}, 'cprof': {'volume_identity': 0},
             'canary': {k: str(v) for k, v in canary.items()}}
    (cr / 'state/STATE.json').write_bytes(engine.json_bytes(state))
    lines, prev = [], ''
    def log(ts, node, phase, **x):
        nonlocal prev
        raw = engine.json_bytes(dict({'ts': ts, 'node': node, 'phase': phase, 'prev_line_sha256': prev}, **x)).rstrip(b'\n')
        lines.append(raw); prev = sha(raw)
    t = started_utc.astimezone()
    log((t - dt.timedelta(minutes=30)).isoformat(timespec='milliseconds'), 'D4', 'STARTED', run_id='20260930_090000_000_1111')
    log((t - dt.timedelta(minutes=20)).isoformat(timespec='milliseconds'), 'D4', 'FINISHED', status='FAIL', result_sha256=None,
        primary_error='LAB_PRIOR_ATTEMPT')
    log(t.isoformat(timespec='milliseconds'), 'D4', 'STARTED', run_id=run)
    (cr / 'state/STATE_JOURNAL.jsonl').write_bytes(b'\n'.join(lines) + b'\n')
    rd = cr / 'runs' / run; rd.mkdir()
    rid = GATE_MODE + '_' + run + '_' + uuid.uuid4().hex[:8].upper()
    gate = {'schema': 'RECOVERY_OWNER_GATE_V004', 'authorized': True, 'mode': GATE_MODE, 'release_id': rid,
            'recovery_source_sha256': 'LAB' * 21 + 'L', 'dest_root': str(canary['dest']), 'scratch_root': str(canary['scratch']),
            'recovery_root': str(canary['recovery']),
            'root_bindings': {key: native.dir_identity(canary[ck]) for key, ck in ROOT_KEYS}}
    mem = {'tickstore_publisher_recovery_v004.py': b'# lab placeholder\n', 'OWNER_GATE.json': engine.json_bytes(gate)}
    man = {'schema': 'RELEASE_MANIFEST_V004', 'members': {n: {'sha256': sha(b), 'bytes': len(b)} for n, b in sorted(mem.items())}}
    mem['RELEASE_MANIFEST.json'] = engine.json_bytes(man)
    bp = rd / (rid + '.zip')
    with zipfile.ZipFile(bp, 'w', compression=zipfile.ZIP_STORED) as z:
        for n, b in sorted(mem.items()):
            zi = zipfile.ZipInfo(n, (1980, 1, 1, 0, 0, 0)); zi.compress_type = zipfile.ZIP_STORED; z.writestr(zi, b)
    anchor = {'release_id': rid, 'release_bundle_sha256': sha_file(bp), 'release_manifest_sha256': sha(mem['RELEASE_MANIFEST.json']),
              'recovery_source_sha256': gate['recovery_source_sha256'], 'owner_gate_sha256': sha(mem['OWNER_GATE.json'])}
    (rd / (rid + '.anchor.json')).write_bytes(engine.json_bytes(anchor))
    return {'control_root': str(cr), 'resume_root': str(rr), 'canary': {k: str(v) for k, v in canary.items()}, 'run': run,
            'bundle': str(bp)}


def qualify_lab(frozen, native, lab_root, evidence_root, native_boundary=None):
    """Owned-lab qualification of the native primitives (never production): one positive observation admitted by the
    frozen consumers (on Windows with the real Win32 reads and the real census-mutex check), then native refusals."""
    lab_root, evidence_root = Path(lab_root), Path(evidence_root)
    boot, _ = native.boot_utc()
    started = boot - dt.timedelta(hours=1)
    cases = []

    def run(name, info, expect):
        rec = run_observation(frozen, native, info['control_root'], info['resume_root'], evidence_root / name, native_boundary)
        got = sorted(rec['self_check']['reconcile'].get('reasons', []))
        ok = rec['status'] == 'PASS_FRESH_PREDECESSOR_EVIDENCE' if expect is None else (rec['status'] == 'BLOCKED' and expect in got)
        cases.append({'case': name, 'expected': expect or 'PASS_FRESH_PREDECESSOR_EVIDENCE', 'status': rec['status'], 'reasons': got,
                      'fresh_predecessor': rec['self_check']['fresh_predecessor'], 'processes_listed': rec['processes_listed'], 'pass': ok})
        return rec

    a = build_lab(lab_root / 'A', native, frozen.engine, started)
    positive = run('Q1_POSITIVE_NATIVE', a, None)
    lock = Path(a['canary']['dest']) / LOCK_NAME
    lock.write_bytes(b'{}')
    try:
        run('Q2_WRITER_LOCK_PRESENT', a, 'WRITER_LOCK_ABSENCE_NOT_PROVEN')
    finally:
        lock.unlink()
    for kind, name, expect in (('PYTHON', 'Q3_OTHER_PYTHON_PROCESS', 'UNCLASSIFIED_PYTHON_PROCESS'),
                               ('MARKER', 'Q4_MARKER_PROCESS', 'RECOVERY_PROCESS_OBSERVED')):
        probe = native.spawn_probe(kind)
        try:
            run(name, a, expect)
        finally:
            native.stop_probe(probe)
    b = build_lab(lab_root / 'B', native, frozen.engine, started)
    s = Path(b['canary']['scratch']); s.rename(s.with_name('scratch_previous_identity')); s.mkdir()
    run('Q5_ROOT_IDENTITY_CHANGED', b, 'ROOT_IDENTITY')
    return {'schema': 'CDT21_D4_PREDECESSOR_OBSERVER_LAB_QUALIFICATION_V001',
            'status': 'PASS_NATIVE_LAB_QUALIFICATION' if all(c['pass'] for c in cases) else 'BLOCKED',
            'observer_sha256': sha_file(__file__), 'frozen_pins': FROZEN, 'cases': cases, 'positive_receipt': positive,
            'native_boundary_stand_in': native_boundary is not None, 'production_reads': False, 'production_writes': False,
            'lab_root': str(lab_root)}


# ---------------------------------------------------------------------------------------------------- CLI
def main(argv=None):
    ap = argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument('--request', required=True)
    a = ap.parse_args(argv)
    req = json.loads(Path(a.request).read_bytes())
    out = Path(req['out_receipt'])
    try:
        frozen = load_frozen(req['frozen_dir'])
        require(sha_file(sys.executable) == frozen.cfg['python_exe_sha256'], 'PYTHON_SHA_NOT_SEALED_INTERPRETER')
        native = WindowsNative(frozen)
        require(native.is_admin(), 'NATIVE_ELEVATION_REQUIRED')
        if req['mode'] == 'OBSERVE':
            receipt = run_observation(frozen, native, frozen.cfg['control_root'], RESUME_ROOT, req['evidence_dir'])
        elif req['mode'] == 'QUALIFY_LAB':
            receipt = qualify_lab(frozen, native, req['lab_root'], req['evidence_dir'])
        else:
            raise Blocked('MODE')
    except Exception as exc:
        receipt = {'schema': SCHEMA_RECEIPT, 'status': 'BLOCKED', 'reason': type(exc).__name__ + ':' + str(exc), 'production_writes': False}
    out.write_bytes(json.dumps(receipt, indent=1, sort_keys=True, default=str).encode('utf-8'))
    for c in receipt.get('cases', []):
        print('LAB_CASE=' + c['case'] + ' ESPERADO=' + c['expected'] + ' STATUS=' + c['status'] + ' MOTIVOS=' + ','.join(c['reasons'])
              + ' FRESH=' + c['fresh_predecessor'] + ' OK=' + str(c['pass']))
    print('OBSERVER_STATUS=' + receipt['status'] + ('' if receipt['status'] != 'BLOCKED' else ' REASON=' + str(receipt.get('reason') or receipt.get('self_check'))))
    return 0 if receipt['status'] in ('PASS_FRESH_PREDECESSOR_EVIDENCE', 'PASS_NATIVE_LAB_QUALIFICATION') else 2


if __name__ == '__main__':
    raise SystemExit(main())
