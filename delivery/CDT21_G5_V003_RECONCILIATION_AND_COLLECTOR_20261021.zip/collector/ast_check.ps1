param([string]$Path)
# Static no-execution / no-mutation check of the collector via the PowerShell AST.
$tok = $null; $err = $null
$ast = [Management.Automation.Language.Parser]::ParseFile($Path, [ref]$tok, [ref]$err)
$allowed = @('Write-Host', 'ConvertFrom-Json', 'ConvertTo-Json', 'Where-Object', 'Sort-Object', 'Select-Object',
             'Add-Type', 'New-Object', 'Get-Date', 'Log', 'J', 'HashStream', 'HashFile', 'Add-Entry', 'Under',
             'Is-Reparse', 'Rel', 'Walk', 'Copy-One', 'Hash-One', 'List-Only', 'Make-Alias', 'Dirs', 'Prop', 'Set-StrictMode')
$cmds = $ast.FindAll({ param($n) $n -is [Management.Automation.Language.CommandAst] }, $true)
$bad = @(); $ops = @()
foreach ($c in $cmds) {
    $name = $c.GetCommandName()
    if ($c.InvocationOperator -ne [Management.Automation.Language.TokenKind]::Unknown) { $ops += $c.Extent.Text }
    if (-not $name -or $allowed -notcontains $name) { $bad += ('' + $name + ' @ ' + $c.Extent.StartLineNumber) }
}
$members = $ast.FindAll({ param($n) $n -is [Management.Automation.Language.InvokeMemberExpressionAst] }, $true)
$danger = @('Delete', 'Move', 'MoveTo', 'CopyTo', 'Start', 'Kill', 'Copy', 'Encrypt', 'SetAttributes', 'SetLastWriteTime',
            'SetCreationTime', 'SetAccessControl', 'Invoke', 'InvokeScript', 'WriteAllBytes', 'CreateText', 'AppendText', 'Truncate')
$writes = @()
foreach ($m in $members) {
    $mn = $m.Member.Extent.Text.Trim("'", '"')
    $target = $m.Expression.Extent.Text
    if ($danger -contains $mn) { $bad += ('member ' + $mn + ' @ ' + $m.Extent.StartLineNumber) }
    if ($mn -eq 'Create' -and $target -ne '[Security.Cryptography.SHA256]') { $bad += ('member Create on ' + $target + ' @ ' + $m.Extent.StartLineNumber) }
    if ($mn -eq 'Replace' -and $target.StartsWith('[IO.')) { $bad += ('member Replace on ' + $target + ' @ ' + $m.Extent.StartLineNumber) }
    if (@('Open', 'WriteAllText', 'AppendAllText', 'CreateDirectory') -contains $mn) { $writes += ($mn + ' @ ' + $m.Extent.StartLineNumber + ': ' + $m.Extent.Text) }
}
"PARSE_ERRORS=" + @($err).Count
"COMMANDS=" + (@($cmds | ForEach-Object { $_.GetCommandName() } | Sort-Object -Unique) -join ',')
"INVOCATION_OPERATOR_USES=" + $ops.Count
"DISALLOWED=" + $bad.Count
foreach ($b in $bad) { '  ' + $b }
"WRITE_SITES=" + $writes.Count
foreach ($w in $writes) { '  ' + $w }
