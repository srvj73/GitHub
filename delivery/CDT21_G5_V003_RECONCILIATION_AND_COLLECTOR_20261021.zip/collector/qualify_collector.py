"""Runtime qualification of the read-only collector with pwsh -TestRoot fixtures (cases 0/1/N).

Usage: qualify_collector.py <pwsh> <collector.ps1> <workdir> <out_json>
"""
import hashlib, json, os, shutil, subprocess, sys, time, zipfile
from pathlib import Path

pwsh, collector, work, out = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
checks = {}
MARK = 'EXECUTED_MARKER'


def rec(name, ok, detail=''):
    checks[name] = {'status': 'PASS' if ok else 'FAIL', 'detail': str(detail)[:400]}
    print(('PASS ' if ok else 'FAIL ') + name + ' ' + str(detail)[:160], flush=True)


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()


def put(p, data=b'x', mtime=None):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data if isinstance(data, bytes) else data.encode())
    if mtime is not None:
        os.utime(p, (mtime, mtime))
    return p


def evil(d, marker_dir):
    # Would create a marker if anything executed them.
    m = str(Path(marker_dir) / MARK)
    put(d / 'evil.ps1', "Set-Content -Path '%s' -Value ran\n" % m)
    put(d / 'evil.py', "open(r'%s','w').write('ran')\n" % m)
    put(d / 'evil.bat', 'echo ran > "%s"\r\n' % m)
    put(d / 'evil.cmd', 'echo ran > "%s"\r\n' % m)


def mkzip(p, members):
    p.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(p, 'w') as z:
        for k, v in members.items():
            z.writestr(k, v)


def fixture_run(profile, child, root_name, with_bootstrap=True, extra_logs=0):
    dl = profile / 'Downloads'; local = profile / 'AppData' / 'Local'
    runs = dl / 'CDT21_G5_V003_RUNS'
    root = local / 'CDT20_R08' / root_name
    put(runs / ('G5_' + child) / 'RUN_LOG.txt', 'child log\nSUPERVISOR_BLOCKED=fixture\n')
    put(runs / ('G5_' + child) / 'SUPERVISOR_RESULT.json', json.dumps({
        'status': 'BLOCKED', 'phase': 'CAMPAIGN', 'exit_code': 3, 'campaign_exit_code': 3,
        'campaign_status': 'BLOCKED', 'run_root': str(root), 'owned_processes_at_end': 0,
        'blockers': ['Blocked:CAMPAIGN_NOT_PASS:BLOCKED:fixture']}))
    mkzip(runs / ('G5_' + child) / 'CDT21_G5_V003_RETURN.zip', {'R08_RETURN.zip': 'z'})
    mkzip(runs / ('G5_' + child) / ('ENVIAR_AO_CHATGPT_CDT21_G5_V003_' + child + '.zip'), {'RUN_LOG.txt': 'x'})
    evil(runs / ('G5_' + child), profile)
    st = local / 'CDT21_G5_V003' / ('STAGE_' + child)
    put(st / 'CDT21_G5_V003_SUPERVISOR.py', "open(r'%s','w')\n" % (profile / MARK))
    put(st / 'CDT19_IMPLEMENTER_SOURCE_REVIEW_V003.json', '{}')
    put(st / 'SUPERVISOR_CONSOLE.log', 'console\n')
    put(st / 'TEMP' / 't.tmp', 't')
    if with_bootstrap:
        put(root / 'CDT21_SUPERVISOR_BOOTSTRAP.json', '{"run_id":"%s"}' % root_name)
    put(root / 'ENGINEERING_RESULT.json', json.dumps({'status': 'BLOCKED', 'blockers': ['RuntimeError:fixture'], 'tests': {'G5_PS51_INSTALL_MENU': {}}}))
    for n in ('LIVE_STATUS.json', 'OWNER.json', 'RETURN_LOCK_SCOPE.json', 'CAMPAIGN.lock', 'R08_RETURN.sha256'):
        put(root / n, '{}')
    mkzip(root / 'R08_RETURN.zip', {'ENGINEERING_RESULT.json': '{}'})
    put(root / 'R08_RETURN.zip.partial', 'partial')
    put(root / 'COMMITS' / 'G5_PS51_INSTALL_MENU.json', '{"schema":"CDT19_NATIVE_UNIT_COMMIT_V001"}')
    put(root / 'LOGS' / 'G5_PS51_INSTALL_MENU.log', 'log\n')
    for i in range(extra_logs):
        put(root / 'LOGS' / ('SUITE_%d.log' % i), 'L' * 3000)
    evil(root / 'LOGS', profile)
    put(root / 'UNITS' / 'G5_PS51_INSTALL_MENU' / 'RESULT.json', '{}')
    put(root / 'EVIDENCE' / 'PROOFS' / 'PS51_INSTALL_MENU' / 'PROOF_RECEIPT.json', '{}')
    put(root / 'WORK' / 'G5_X' / 'PROOF_WORK' / 'a' / 'b.txt', 'w')
    put(root / 'PACKAGED' / 'implementation_v001' / 'x.py', "open(r'%s','w')\n" % (profile / MARK))
    put(root / 'TEMP' / 'tmp.txt', 't')
    put(root / 'INPUTS' / 'CDT21_FINAL_PACKAGE_V003_20261020.zip', 'pkg')
    put(root / 'INPUTS' / 'CDT19_R08Q1_ENGINEERING_WITNESS.json', '{}')
    put(root / 'QUAL_C' / 'q.txt', 'q')
    return root


def snapshot(base):
    snap = {}
    for p in sorted(Path(base).rglob('*')):
        if p.is_symlink():
            snap[str(p)] = ('LINK', os.readlink(p))
        elif p.is_file():
            st = p.stat(); snap[str(p)] = (sha(p), st.st_mtime_ns, st.st_size)
    return snap


def run_case(name, profile, *extra):
    before = snapshot(profile)
    r = subprocess.run([pwsh, '-NoProfile', '-File', str(collector), '-TestRoot', str(profile)] + list(extra),
                       capture_output=True, text=True, timeout=300)
    after = snapshot(profile)
    outs = sorted((profile / 'Downloads' / 'CDT21_G5_V003_COLLECT_RUNS').glob('COLLECT_*'))
    new = {k for k in after if k not in before}
    changed = [k for k in before if after.get(k) != before[k]]
    od = outs[-1] if outs else None
    rec(name + '_source_unchanged', not changed, changed[:3])
    rec(name + '_writes_only_in_collect_dir', od is not None and all(Path(k).is_relative_to(od) for k in new), len(new))
    rec(name + '_no_execution_marker', not any(p.name == MARK for p in profile.rglob('*')) and not (work / MARK).exists())
    man = json.loads((od / 'COLLECT_MANIFEST.json').read_bytes().decode('utf-8-sig')) if od else {}
    zips = list(od.glob('ENVIAR_AO_OPUS_CDT21_G5_V003_COLLECT_*.zip')) if od else []
    zok = False
    if zips:
        with zipfile.ZipFile(zips[0]) as z:
            names = z.namelist()
            zok = z.testzip() is None and 'COLLECT_MANIFEST.json' in names and 'RUN_LOG.txt' in names and \
                sum(1 for n in names if n.startswith('FILES/')) == sum(1 for e in man.get('entries', []) if e['kind'] == 'COLLECTED')
    rec(name + '_return_zip_crc_and_complete', zok, zips[0].name if zips else 'NO_ZIP')
    bad = []
    for e in man.get('entries', []):
        if e['kind'] == 'COLLECTED':
            dest = od / 'FILES' / e['alias'] / e['rel']
            if not dest.is_file() or sha(dest) != e['sha256'] or sha(e['source']) != e['sha256']:
                bad.append(e['rel'])
    rec(name + '_collected_hashes_match_source', not bad, bad[:3])
    return r, man, od


shutil.rmtree(work, ignore_errors=True); work.mkdir(parents=True)

# Case 0: nothing to collect.
p0 = work / 'case0'; (p0 / 'Downloads').mkdir(parents=True)
r, man, od = run_case('case0', p0)
rec('case0_exit_1_nothing_found', r.returncode == 1 and man.get('exit_code') == 1, r.returncode)

# Case 1: parent + child dir, one stage, one V003 root, one V002 root, TICKSTORE_RUNS in/out of window.
p1 = work / 'case1'
put(p1 / 'Downloads' / 'CDT21_G5_V003_RUNS' / 'G5_20261020_210602_767_19736' / 'RUN_LOG.txt', 'parent\nELEVATED_CHILD_EXIT_CODE=3\n')
root1 = fixture_run(p1, '20261020_210605_565_5076', 'R08_Q1_20261020210605_856fea523791')
v002 = p1 / 'AppData' / 'Local' / 'CDT20_R08' / 'R08_Q1_20261020164323_d44d45d0dfaa'
put(v002 / 'ENGINEERING_RESULT.json', '{"status":"PASS_NATIVE_INTEGRATED_PRE_B06"}')
tick = p1 / 'OneDrive' / 'Downloads' / 'TICKSTORE_RUNS'
put(tick / 'INSTALL_20261020_210608_286_22580' / 'RUN_LOG.txt', 'install')
put(tick / 'OLD_20261001' / 'RUN_LOG.txt', 'old'); os.utime(tick / 'OLD_20261001', (time.time() - 30 * 86400,) * 2)
r, man, od = run_case('case1', p1)
aliases = {a['alias']: a['source'] for a in man['aliases']}
kinds = {}
for e in man['entries']:
    kinds.setdefault(e['kind'], []).append(e)
rec('case1_exit_0', r.returncode == 0, r.returncode)
rec('case1_selection', sum(a.startswith('G5RUN') for a in aliases) == 2 and sum(a.startswith('STAGE') for a in aliases) == 1
    and [s for a, s in aliases.items() if a.startswith('ROOT')] == [str(root1)]
    and not any('d44d45d0dfaa' in s for s in aliases.values()), aliases)
rec('case1_tick_window', any('INSTALL_20261020_210608' in s for s in aliases.values()) and not any('OLD_20261001' in s for s in aliases.values()))
col = {(e['alias'], e['rel'].replace('\\', '/')) for e in kinds.get('COLLECTED', [])}
rec('case1_primary_collected', all(any(rel == x for _, rel in col) for x in (
    'SUPERVISOR_RESULT.json', 'RUN_LOG.txt', 'ENGINEERING_RESULT.json', 'R08_RETURN.zip', 'COMMITS/G5_PS51_INSTALL_MENU.json',
    'LOGS/G5_PS51_INSTALL_MENU.log', 'UNITS/G5_PS51_INSTALL_MENU/RESULT.json', 'SUPERVISOR_CONSOLE.log',
    'EVIDENCE/PROOFS/PS51_INSTALL_MENU/PROOF_RECEIPT.json', 'INPUTS/CDT19_R08Q1_ENGINEERING_WITNESS.json')), sorted(col)[:6])
rec('case1_hash_only_and_listed', any(e['rel'].endswith('.zip') and 'ENVIAR' in e['rel'] for e in kinds.get('HASH_ONLY_DUPLICATE_BUNDLE', []))
    and any(e['rel'].endswith('.partial') for e in kinds.get('HASH_ONLY_PARTIAL', []))
    and any('CDT21_FINAL_PACKAGE' in e['rel'] for e in kinds.get('HASH_ONLY_INPUT', []))
    and any(e['rel'].replace('\\', '/').startswith('PACKAGED/') for e in kinds.get('LISTED_ONLY', []))
    and not any(rel.startswith(('PACKAGED/', 'WORK/', 'TEMP/', 'QUAL_C/')) for _, rel in col))
log = (od / 'RUN_LOG.txt').read_text(encoding='utf-8')
rec('case1_log_summary', 'phase=CAMPAIGN' in log and 'blocker=Blocked:CAMPAIGN_NOT_PASS' in log
    and 'ENGINEERING_RESULT.blocker=RuntimeError:fixture' in log and 'COMMITS_JSON=1' in log)

# Case N: 3 run dirs, 2 stages, 2 V003 roots, size cap, total cap, links not followed.
pn = work / 'caseN'
outside = pn / 'OUTSIDE_TARGET'; put(outside / 'SECRET_NOT_TO_COLLECT.txt', 'secret')
ra = fixture_run(pn, '20261020_210605_565_5076', 'R08_Q1_20261020210605_856fea523791', extra_logs=3)
rb = fixture_run(pn, '20261021_090000_000_1111', 'R08_Q1_20261021120000_aaaaaaaaaaaa')
put(pn / 'Downloads' / 'CDT21_G5_V003_RUNS' / 'G5_20261020_210602_767_19736' / 'RUN_LOG.txt', 'parent')
put(ra / 'LOGS' / 'BIG.log', 'B' * 6000)
os.symlink(outside / 'SECRET_NOT_TO_COLLECT.txt', ra / 'LOGS' / 'link_file.log')
os.symlink(outside, ra / 'EVIDENCE' / 'link_dir', target_is_directory=True)
r, man, od = run_case('caseN', pn, '-MaxFileBytes', '5000')
kinds = {}
for e in man['entries']:
    kinds.setdefault(e['kind'], []).append(e)
aliases = {a['alias']: a['source'] for a in man['aliases']}
rec('caseN_exit_0_multi', r.returncode == 0 and sum(a.startswith('G5RUN') for a in aliases) == 3
    and sum(a.startswith('STAGE') for a in aliases) == 2 and sum(a.startswith('ROOT') for a in aliases) == 2, aliases)
rec('caseN_size_cap_hash_only', any(e['rel'].endswith('BIG.log') and e['sha256'] for e in kinds.get('HASH_ONLY_SIZE_CAP', [])))
rec('caseN_links_not_followed', len(kinds.get('SKIPPED_REPARSE', [])) == 2
    and not any('SECRET_NOT_TO_COLLECT' in (e['source'] or '') for e in man['entries'] if e['kind'] != 'SKIPPED_REPARSE'))
pt = work / 'caseT'
fixture_run(pt, '20261020_210605_565_5076', 'R08_Q1_20261020210605_856fea523791', extra_logs=8)
r, man, od = run_case('caseT', pt, '-MaxTotalBytes', '12000')
rec('caseT_total_cap', r.returncode == 0 and any(e['kind'] == 'HASH_ONLY_TOTAL_CAP' for e in man['entries'])
    and man['collected_bytes'] <= 12000, man.get('collected_bytes'))

summary = {'schema': 'CDT21_G5_V003_COLLECTOR_QUALIFICATION_V001', 'collector_sha256': sha(collector),
           'pwsh': subprocess.run([pwsh, '--version'], capture_output=True, text=True).stdout.strip(),
           'checks': checks, 'passed': sum(v['status'] == 'PASS' for v in checks.values()), 'total': len(checks),
           'not_covered_on_linux': ['Windows ACLs of files created by the elevated child', 'Windows PowerShell 5.1 runtime (parse only via pwsh 7)',
                                    'NTFS junctions (Unix symlinks exercised as reparse points)']}
out.write_text(json.dumps(summary, indent=1, sort_keys=True) + '\n')
print('PASSED', summary['passed'], '/', summary['total'])
sys.exit(0 if summary['passed'] == summary['total'] else 1)
