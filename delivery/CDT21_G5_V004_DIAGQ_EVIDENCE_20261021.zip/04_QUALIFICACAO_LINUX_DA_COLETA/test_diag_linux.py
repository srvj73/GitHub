"""Linux qualification of CDT21_G5_V004_DIAG_RAIZES.py (logic only; Windows APIs replaced by a wire-format fake).

Usage: python -I test_diag_linux.py <diag.py> <supervisor.py> <qual_result.json> <v003_root_src> <work> <out.json>
The diag source is executed with exactly three substitutions, all recorded: the two platform guards (nt, admin)
and nothing else; kernel32 / WinDLL / get_last_error are injected as fakes that speak the real USN V2 record
layout, so parsing, FRN classification, window logic and synthesis run unmodified.
"""
import ctypes
import hashlib
import json
import os
import shutil
import struct
import sys
import threading
import time
import types
from pathlib import Path

diag_src, sup, qual, v003, work, out = map(Path, sys.argv[1:7])
work = work.resolve()
results = []


def check(name, ok, detail=''):
    results.append({'case': name, 'pass': bool(ok), 'detail': detail})


def make_env(tag):
    w = work / tag
    if w.exists():
        shutil.rmtree(w)
    local = w / 'LOCAL'; (local / 'CDT20_R08').mkdir(parents=True)
    shutil.copytree(v003, local / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791', symlinks=True)
    (local / 'CDT20_R08' / 'CURRENT_09AA56B867476005.json').write_text('x' * 179)
    dl = w / 'D:\\TICKSTORE_CDT19_PRE_G06_LABS' / 'R08_Q1_20261020210605_856fea523791'
    shutil.copytree(v003 / 'COMMITS', dl / 'WRITER_EFFECTFUL')
    prod = w / 'D:\\Base CSV'; (prod / 'Scripts').mkdir(parents=True); (prod / 'a.csv').write_text('1')
    ctl = local / 'CDT21_F01R1_G0' / 'R08_Q1_20261021115755_fe67eb109c66'; ctl.mkdir(parents=True); (ctl / 'f.txt').write_text('c')
    logd = w / 'LOG'; logd.mkdir()
    return w, local, logd


class FakeK32:
    """Speaks FSCTL_QUERY/READ_USN_JOURNAL with real USN_RECORD_V2 bytes for volume C:; D: journal inactive."""
    def __init__(self, records):
        self.records = records; self.handles = {}; self.last = 0

    def CreateFileW(self, name, *a):
        h = len(self.handles) + 100; self.handles[h] = name; return h

    def CloseHandle(self, h):
        return 1

    def DeviceIoControl(self, h, code, inp, inlen, outb, outlen, retp, ov):
        vol = self.handles.get(h, '')
        if 'D:' in vol:
            self.last = 1179; return 0                      # ERROR_JOURNAL_NOT_ACTIVE
        if code == 0x000900F4:
            first = self.records[0]['usn'] if self.records else 0
            nxt = self.records[-1]['usn'] + 1 if self.records else 0
            raw = struct.pack('<QqqqqQQ', 77, first, nxt, first, 1 << 40, 1 << 25, 1 << 20)
            ctypes.memmove(outb, raw, len(raw)); retp._obj.value = len(raw); return 1
        start = struct.unpack_from('<q', inp, 0)[0]
        recs = [r for r in self.records if r['usn'] >= start][:3]   # small batches: exercise the loop
        body = b''
        for r in recs:
            name = r['name'].encode('utf-16-le')
            rec = struct.pack('<IHHQQqqIIIIHH', 60 + len(name) + (-(60 + len(name)) % 8), 2, 0, r['frn'], r['parent_frn'], r['usn'],
                              int((r['time'] + 11644473600) * 1e7), r['reason'], 0, 0, 0x20, len(name), 60) + name
            body += rec + b'\0' * (-len(rec) % 8)
        nxt = (recs[-1]['usn'] + 1) if recs else start
        raw = struct.pack('<q', nxt) + body
        ctypes.memmove(outb, raw, len(raw)); retp._obj.value = len(raw); return 1

    def OpenFileById(self, *a):
        return 555

    def GetFinalPathNameByHandleW(self, h, buf, n, f):
        buf.value = '\\\\?\\D:\\RESOLVED'; return len(buf.value)


def run_diag(tag, q_override=None, records_fn=None, during=None, observe=4, interval=2, patch=None):
    w, local, logd = make_env(tag)
    os.chdir(w)
    os.environ['LOCALAPPDATA'] = str(local)
    src = diag_src.read_text(encoding='utf-8')
    subs = [("        assert os.name == 'nt', 'WINDOWS_REQUIRED'\n", "        pass  # TEST: platform guard\n"),
            ("        assert ctypes.WinDLL('shell32').IsUserAnAdmin(), 'ELEVATION_REQUIRED'\n", "        pass  # TEST: admin guard\n")]
    for o, n in subs:
        assert src.count(o) == 1, o
        src = src.replace(o, n)
    qual_path = qual
    if q_override is not None:
        q = json.loads(qual.read_bytes()); q_override(q, local, w)
        qual_path = w / 'QUAL.json'; qual_path.write_bytes(json.dumps(q).encode())
    mod = types.ModuleType('diag_under_test'); mod.__file__ = str(diag_src)
    sys.modules['diag_under_test'] = mod
    exec(compile(src, str(diag_src), 'exec'), mod.__dict__)
    if q_override is not None:
        mod.QUAL_SHA = hashlib.sha256(qual_path.read_bytes()).hexdigest().upper()
    fake = FakeK32(records_fn(local, w) if records_fn else [])
    mod.k32 = fake
    mod.ctypes = types.SimpleNamespace(**{k: getattr(ctypes, k) for k in dir(ctypes) if not k.startswith('__')})
    mod.ctypes.get_last_error = lambda: fake.last
    if patch:
        patch(mod)
    if during:
        threading.Timer(1.0, during, args=(local, w)).start()
    argv = sys.argv
    sys.argv = ['diag', '--supervisor', str(sup), '--qual-result', str(qual_path), '--log-dir', str(logd),
                '--observe-seconds', str(observe), '--observe-interval', str(interval)]
    try:
        rc = mod.main()
    finally:
        sys.argv = argv
    return rc, json.loads((logd / 'DIAG_RESULT.json').read_text()), local, w


def same_as_now(q, local, w):
    """Q 'before' = the current state (as if nothing changed), window = 30 s ago."""
    spec = __import__('importlib.util').util.spec_from_file_location('s', sup); s = __import__('importlib.util').util.module_from_spec(spec)
    spec.loader.exec_module(s)
    os.chdir(w); q['foreign_roots'] = s.foreign_roots(str(local)); q['production_fingerprint'] = s.production_fingerprint()
    q['finished_epoch'] = time.time() - 30; q['seconds'] = 15.5


# 1. Real Q result (Windows keys): everything differs from a Linux tree -> diff reported, no crash, D: inactive handled.
rc, r, local, w = run_diag('T1_REAL_Q')
check('T1_real_q_result_pinned_and_parsed', rc == 0 and r['status'] == 'DIAG_COMPLETE' and r['q_window_utc'][0].startswith('2026-10-21T18:39'),
      r.get('q_window_utc'))
qb = r['q_before_vs_now']
check('T1_q_before_vs_now_reports_per_key', r['q_before_vs_now_summary'] == {'added': 0, 'changed': 2, 'removed': 23}
      and sorted(qb['changed']) == ['d_lab/R08_Q1_20261020210605_856fea523791', 'run/R08_Q1_20261020210605_856fea523791']
      and qb['changed']['run/R08_Q1_20261020210605_856fea523791']['before']['entries'] == 3116
      and 'run/CURRENT_09AA56B867476005.json' not in qb['changed'], r['q_before_vs_now_summary'])
check('T1_rows_equal_supervisor_digest', all(r['rows_consistent_with_supervisor_digest'].values()) and len(r['rows_consistent_with_supervisor_digest']) == 2,
      r['rows_consistent_with_supervisor_digest'])
check('T1_d_journal_inactive_reported', r['usn']['D:']['journal']['active'] is False, r['usn']['D:'])
check('T1_production_compared', r['production_equal_to_q_before'] is False)
check('T1_control_tree_probe_ran', r['control_trees_not_walked_by_q']['CDT21_F01R1_G0']['exists'] and
      r['control_trees_not_walked_by_q']['CDT21_F01R1_G0']['digest_first_eq_second'], r['control_trees_not_walked_by_q'])

# 2. Unchanged state, journal empty -> NO_PERSISTENT_DIFFERENCE; observation stable; read-only (tree digest of LOCAL unchanged).
rc, r, local, w = run_diag('T2_STABLE', q_override=same_as_now)
check('T2_no_persistent_difference', r['preliminary_classification'] == 'NO_PERSISTENT_DIFFERENCE_TRANSIENT_DURING_Q'
      and r['immediate_repeat_equal'] and r['observation']['all_equal'], r['facts'])

# 3. A writer touches a foreign file during the observation -> captured per entry.
def toucher(local, w):
    p = local / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791' / 'LIVE_STATUS.json'
    p.write_bytes(p.read_bytes() + b' ')
rc, r, local, w = run_diag('T3_WRITER', q_override=same_as_now, during=toucher, observe=5, interval=2)
moved = [s for s in r['observation']['samples'] if not s['equal_to_previous']]
rows = moved[0]['rows']['run/R08_Q1_20261020210605_856fea523791']['changed'] if moved else []
check('T3_observation_catches_writer_per_entry', not r['observation']['all_equal'] and rows and rows[0][0][0] == 'LIVE_STATUS.json'
      and r['preliminary_classification'] == 'DIGEST_MOVES_WITHOUT_CAMPAIGN_ACTIVITY', rows[:1])

# 4. USN records under a foreign directory inside the Q window -> FILESYSTEM_MODIFICATION..., with reasons and path.
def q_300s_ago(q, local, w):
    same_as_now(q, local, w); q['finished_epoch'] = time.time() - 300


def usn_records(local, w):
    root = local / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791'
    t = time.time() - 300 - 10                                 # inside [q_start, q_end] of q_300s_ago
    own = os.lstat(root / 'UNITS').st_ino
    return [{'usn': 10, 'time': time.time() - 3600, 'frn': 1, 'parent_frn': 2, 'name': 'old.txt', 'reason': 0x100},
            {'usn': 11, 'time': t, 'frn': 3, 'parent_frn': own, 'name': 'INTRUSO.tmp', 'reason': 0x100 | 0x80000000},
            {'usn': 12, 'time': t + 1, 'frn': 3, 'parent_frn': own, 'name': 'INTRUSO.tmp', 'reason': 0x200 | 0x80000000},
            {'usn': 13, 'time': t + 2, 'frn': 9, 'parent_frn': 424242, 'name': 'elsewhere.txt', 'reason': 0x2},
            {'usn': 14, 'time': time.time() - 5, 'frn': 4, 'parent_frn': own, 'name': 'LATER.tmp', 'reason': 0x100}]
rc, r, local, w = run_diag('T4_USN', q_override=q_300s_ago, records_fn=usn_records)
hits = r['usn']['C:']['hits_foreign']
check('T4_usn_v2_parsed_and_classified', r['preliminary_classification'] == 'FILESYSTEM_MODIFICATION_IN_FOREIGN_ROOTS_DURING_Q'
      and [h['name'] for h in hits if h['in_q_window']] == ['INTRUSO.tmp', 'INTRUSO.tmp']
      and [h['reasons'] for h in hits if h['in_q_window']] == ['FILE_CREATE|CLOSE', 'FILE_DELETE|CLOSE']
      and [h['name'] for h in hits if not h['in_q_window']] == ['LATER.tmp']
      and hits[0]['parent_path'].endswith('UNITS') and r['usn']['C:']['covers_q_window']
      and r['usn']['C:']['counts'].get('other|Q_WINDOW') == 1, hits)

# 5. Diag is read-only on everything it inspects (foreign, production, control): byte-and-mtime digest unchanged.
def snap(base):
    rows = []
    for dp, dn, fn in os.walk(base):
        for n in dn + fn:
            p = os.path.join(dp, n); st = os.lstat(p)
            rows.append((os.path.relpath(p, base), st.st_size, st.st_mtime_ns,
                         hashlib.sha256(open(p, 'rb').read()).hexdigest() if os.path.isfile(p) else ''))
    return sorted(rows)
w, local, logd = make_env('T5_READONLY')
before = {k: snap(p) for k, p in (('local_minus_log', local), ('dlabs', w / 'D:\\TICKSTORE_CDT19_PRE_G06_LABS'), ('prod', w / 'D:\\Base CSV'))}
shutil.rmtree(w)
# rerun with the same construction and compare after the diag
def keep_q(q, local, w):
    same_as_now(q, local, w)
rc, r, local, w = run_diag('T5_READONLY', q_override=keep_q)
after = {k: snap(p) for k, p in (('local_minus_log', local), ('dlabs', w / 'D:\\TICKSTORE_CDT19_PRE_G06_LABS'), ('prod', w / 'D:\\Base CSV'))}
same = all([(a[0], a[1], a[3]) for a in before[k]] == [(a[0], a[1], a[3]) for a in after[k]] for k in before)
written = sorted(str(p.relative_to(w)) for p in w.rglob('*') if p.is_file() and 'LOG' not in p.relative_to(w).parts[:1]
                 and p.stat().st_mtime > r['started_epoch'])
check('T5_read_only_outside_log_dir', same and written == [], written)

# 6. Stale index view on a control tree (NTFS duplicated-information lag modelled): first walk stale, handle and
#    second walk current -> control 'moved' and, with a persistent difference and no journaled write, the
#    preliminary class is INDEX_VIEW_REFRESHED_BY_READING_NO_MODIFICATION.
def stale_first_walk(mod):
    real, seen = mod.rows_like_supervisor, set()
    def rows(base):
        r = real(base)
        if Path(base).name == 'CDT21_F01R1_G0' and 'x' not in seen:
            seen.add('x'); return [(a, b, c - 10_000_000) if b == -1 else (a, b, c) for a, b, c in r]
        return r
    mod.rows_like_supervisor = rows
rc, r, local, w = run_diag('T6_STALE_INDEX', patch=stale_first_walk)
c6 = r['control_trees_not_walked_by_q']['CDT21_F01R1_G0']
check('T6_stale_index_view_detected_and_classified', c6['index_first_ne_handle'] >= 1 and c6['index_second_eq_handle_for_those'] == c6['index_first_ne_handle']
      and not c6['digest_first_eq_second'] and r['preliminary_classification'] == 'INDEX_VIEW_REFRESHED_BY_READING_NO_MODIFICATION', c6)

doc = {'schema': 'CDT21_G5_V004_DIAG_LINUX_QUALIFICATION_V001', 'diag_sha256': hashlib.sha256(diag_src.read_bytes()).hexdigest().upper(),
       'substitutions': ['platform guard (nt)', 'admin guard'], 'passed': sum(c['pass'] for c in results), 'total': len(results), 'cases': results}
Path(out).write_text(json.dumps(doc, indent=1, default=str), encoding='utf-8')
print('DIAG_LINUX', doc['passed'], '/', doc['total'])
for c in results:
    if not c['pass']:
        print('FAIL', c['case'], json.dumps(c['detail'], default=str)[:800])
