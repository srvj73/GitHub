# CDT21 — G5 V004: investigação física de `QUAL_q_no_effect_on_foreign_roots`

**Papel:** implementador. Este documento não é parecer B06.

## 1. Retorno analisado (somente leitura)

**Retorno:** `289A064EA65235CEA2EF8EB1E80970C5415C2022C26D78781F8EF8CFBE4A7EC2`, com 5 membros cujo hash confere. `QUALIFICATION_RESULT.json` = `966F33CD…`, igual ao SHA registrado no log.

- **Launcher:** R1 `E3F83D0A…`. A premissa nativa do R1 está confirmada: `IDENTIDADE_PAI=23632@639282047947866900` aparece em `ARVORE_PROPRIA` com o mesmo instante de criação; `CAMPANHAS_G5_ATIVAS=0`.
- **Resultado da Q:** 16 de 17 verificações PASS. A falha é `q_no_effect_on_foreign_roots`, sem detalhe registrado.
  - `production_unchanged_during_q` **não chegou a ser avaliada**, porque a Q parou antes.
- **Janela da Q:** 18:39:59–18:40:14 UTC (15,53 s).
- **Raízes preexistentes:** 26 entradas.

| Dono | Entradas |
|---|---|
| V003 | 2 (raiz e laboratório) |
| outros | 20 |
| arquivos `CURRENT_*.json` | 4 |

Nenhuma raiz foi criada e a campanha não foi iniciada.

## 2. O que já está descartado (Linux, sem repetir testes nativos)

**`02_REPLAY_LINUX/q_replay_audit.py`** executa, sob auditoria de escrita (`sys.addaudithook` no supervisor e nos filhos b2d), exatamente os passos que a Q faz entre os dois digests:
- extração;
- contrato do layout;
- importação do plano;
- `verify_package` congelado;
- b2d positivo e b2d no layout R1.

As raízes estrangeiras são cópias reais da raiz V003 coletada.

**Resultado:**
- **0 escritas** nas raízes estrangeiras;
- digest e linhas por entrada iguais antes e depois;
- plano 38, código `D2C626FD…`, b2d 29/29.

**Verificação estática** dos 17 módulos que a Q importa: **nenhuma E/S na importação**.

**Conclusão:** o código que a Q executa não escreve nas raízes preexistentes.

**Restam três classes de causa:**

| Classe | Causa possível |
|---|---|
| (a) | escritor externo nas raízes durante a janela |
| (b) | instabilidade da vista usada pelo digest. O supervisor usa os dados do índice de diretório (FindFirstFile), que a Microsoft documenta como possivelmente desatualizados em NTFS; a primeira enumeração pode atualizá-los, sem nenhuma escrita de conteúdo |
| (c) | falha transitória de leitura (`owner_binding` ou `scandir`) |

## 3. Coleta nativa somente leitura

**Arquivos:**
- launcher `RUN_CDT21_G5_V004_DIAG_RAIZES_READONLY_20261021.ps1` (`DE3938EFBD45014A7F53BEBB0818878E2845ABEC6743CA093DDF61F8B71B8D3A`);
- script embutido `CDT21_G5_V004_DIAG_RAIZES.py` (`42166FA72DB4FD2A0C51EA58D6B04CDCDCC9C62B24A529381335ED578E7B0FC3`);
- supervisor `273E6207…`, embutido apenas para reutilizar `foreign_roots` e `production_fingerprint` byte a byte. O `main` não é executado.

**Passos da coleta:**
1. Digest atual com as funções exatas do supervisor, comparado **raiz a raiz e campo a campo** com o “antes” da Q (`966F33CD…`). Inclui as linhas por entrada atuais e as entradas modificadas desde 10 min antes da Q.
2. Vista do índice x vista do handle (GetFileInformationByHandle) para cada entrada das raízes.
3. Controle em árvores que a Q nunca percorreu (`CDT21_F01R1_G0`, `CDT21_F01_G0`, `CDT21_G5_V003`): índice, depois handle, depois índice de novo. Isso mostra se a simples leitura move o digest nesta máquina.
4. Digest repetido imediatamente e observação de 2 min sem nenhuma atividade da campanha. Se algo mudar, registra a diferença por entrada.
5. `D:\Base CSV` comparado com o “antes” da Q.
6. **Diário USN de C: e D:**, apenas leitura, sem criar nem alterar diário. Registros da janela da Q e posteriores, restritos aos diretórios das raízes, de `D:\Base CSV` e da própria Q (controle de cobertura). Também todos os registros do D: na janela.
7. Processos vivos, detecções e eventos do Defender na janela, e estado do `disablelastaccess`.

**Garantias:**
- Grava **somente** na pasta de log.
- Não executa campanha, b2d, supervisor nem código congelado.
- O volume é aberto com `GENERIC_READ` e usa apenas `FSCTL_QUERY_USN_JOURNAL` e `FSCTL_READ_USN_JOURNAL`.

**Qualificação Linux do diagnóstico: 11/11.** Os testes usam um kernel32 falso que produz registros USN V2 no formato real.

| Cobertura | Caso |
|---|---|
| Uso do retorno real | resultado real fixado e lido; comparação por raiz |
| Consistência | linhas iguais ao digest do supervisor |
| Diário | D: inativo tratado; parse e classificação USN V2 com janela e “depois” |
| Detecção de causa | escritor real detectado por entrada; índice desatualizado classificado |
| Controles | estado estável; somente leitura comprovado fora da pasta de log |

## 4. Próximo passo

O titular executa a coleta (3 a 6 min) e devolve o ZIP diretamente a esta conversa.

| Resultado da coleta | Conclusão | Ação do implementador |
|---|---|---|
| (a) registros USN nas raízes | escritor externo; o supervisor está correto e a proteção cumpriu seu papel | identificar o escritor e propor a contenção operacional |
| (b) leitura move o digest sem registro USN | defeito material do supervisor | correção mínima: digest pela vista do handle e detalhe por entrada na falha, sem enfraquecer a proteção. Qualificar e entregar só o launcher afetado |
| (c) nenhuma diferença persistente | causa transitória | mesma correção de observabilidade e nova Q |

RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 21
