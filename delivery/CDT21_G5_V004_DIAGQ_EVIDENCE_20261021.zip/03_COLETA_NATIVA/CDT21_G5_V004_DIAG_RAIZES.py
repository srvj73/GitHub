"""CDT21 G5 V004 - read-only physical diagnosis of QUAL_q_no_effect_on_foreign_roots (Q of 2026-10-21 15:40).

Never writes outside --log-dir; never opens a foreign root, a D-lab or D:\\Base CSV for writing; never runs the
campaign, the b2d suite or any frozen code.  It imports the exact supervisor bytes (SHA-pinned) only to reuse
foreign_roots / production_fingerprint byte-identically, and answers:
  1. which pre-existing entries differ now from the Q 'before' snapshot (per root, per field);
  2. what changed physically: NTFS USN change journal of C: and D: for the Q window and until now, restricted to
     the directories of the foreign roots, of D:\\Base CSV and of Q's own directories (coverage control);
  3. whether the digest itself moves without any write: two consecutive digests, a timed observation and a
     comparison of the directory-index view (FindFirstFile) against the handle view (GetFileInformationByHandle);
  4. whether D:\\Base CSV is still the Q 'before' fingerprint (Q stopped before checking it).
"""
from __future__ import annotations

import argparse
import ctypes
import ctypes.wintypes as wt
import hashlib
import importlib.util
import json
import os
import struct
import sys
import time
import traceback
from pathlib import Path

SUPERVISOR_SHA = '273E620746FD5293D87858847CEBE035328B2A354F4371BBB18D82195A410126'
QUAL_SHA = '966F33CD4DEDF449B7C52833702F3C9AD8ED1BA3BEF7112E57AE96C50712DC68'
SCHEMA = 'CDT21_G5_V004_FOREIGN_ROOTS_DIAG_V001'
REASONS = [(0x1, 'DATA_OVERWRITE'), (0x2, 'DATA_EXTEND'), (0x4, 'DATA_TRUNCATION'), (0x10, 'NAMED_DATA_OVERWRITE'),
           (0x20, 'NAMED_DATA_EXTEND'), (0x40, 'NAMED_DATA_TRUNCATION'), (0x100, 'FILE_CREATE'), (0x200, 'FILE_DELETE'),
           (0x400, 'EA_CHANGE'), (0x800, 'SECURITY_CHANGE'), (0x1000, 'RENAME_OLD_NAME'), (0x2000, 'RENAME_NEW_NAME'),
           (0x4000, 'INDEXABLE_CHANGE'), (0x8000, 'BASIC_INFO_CHANGE'), (0x10000, 'HARD_LINK_CHANGE'),
           (0x20000, 'COMPRESSION_CHANGE'), (0x40000, 'ENCRYPTION_CHANGE'), (0x80000, 'OBJECT_ID_CHANGE'),
           (0x100000, 'REPARSE_POINT_CHANGE'), (0x200000, 'STREAM_CHANGE'), (0x400000, 'TRANSACTED_CHANGE'),
           (0x800000, 'INTEGRITY_CHANGE'), (0x80000000, 'CLOSE')]
MASK64 = (1 << 64) - 1


def sha_file(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest().upper()


def emit(line):
    print(line, flush=True)


def rows_like_supervisor(base):
    """Same walk as supervisor.link_safe_digest, returning the rows (directory-index view)."""
    base = Path(base)
    rows, stack = [], [base]
    while stack:
        d = stack.pop()
        try:
            with os.scandir(d) as it:
                entries = list(it)
        except OSError:
            rows.append((d.relative_to(base).as_posix(), -3, 0)); continue
        for e in entries:
            rel = Path(e.path).relative_to(base).as_posix()
            try:
                st = e.stat(follow_symlinks=False)
            except OSError:
                rows.append((rel, -4, 0)); continue
            link = e.is_symlink() or e.is_junction() or bool(getattr(st, 'st_file_attributes', 0) & 0x400)
            if link:
                rows.append((rel, -2, st.st_mtime_ns))
            elif e.is_dir(follow_symlinks=False):
                rows.append((rel, -1, st.st_mtime_ns)); stack.append(Path(e.path))
            else:
                rows.append((rel, st.st_size, st.st_mtime_ns))
    rows.sort()
    return rows


def key_path(local, key, sup):
    label, name = key.split('/', 1)
    return (Path(local) / sup.RUN_PARENT / name) if label == 'run' else (Path(sup.D_LABS) / name)


def diff_snap(a, b):
    changed = {k: {'before': a[k], 'after': b[k]} for k in sorted(a) if k in b and a[k] != b[k]}
    return {'changed': changed, 'added': {k: b[k] for k in sorted(b) if k not in a}, 'removed': {k: a[k] for k in sorted(a) if k not in b}}


def diff_rows(r1, r2):
    d1, d2 = {r[0]: r for r in r1}, {r[0]: r for r in r2}
    return {'changed': [[d1[k], d2[k]] for k in sorted(d1) if k in d2 and d1[k] != d2[k]][:500],
            'added': [d2[k] for k in sorted(d2) if k not in d1][:500], 'removed': [d1[k] for k in sorted(d1) if k not in d2][:500]}


# ---------------------------------------------------------------- USN change journal (read-only)
k32 = ctypes.WinDLL('kernel32', use_last_error=True) if os.name == 'nt' else None
if k32 is not None:
    k32.CreateFileW.restype = wt.HANDLE
    k32.CreateFileW.argtypes = [wt.LPCWSTR, wt.DWORD, wt.DWORD, ctypes.c_void_p, wt.DWORD, wt.DWORD, wt.HANDLE]
    k32.DeviceIoControl.argtypes = [wt.HANDLE, wt.DWORD, ctypes.c_void_p, wt.DWORD, ctypes.c_void_p, wt.DWORD,
                                    ctypes.POINTER(wt.DWORD), ctypes.c_void_p]
    k32.OpenFileById.restype = wt.HANDLE
    k32.OpenFileById.argtypes = [wt.HANDLE, ctypes.c_void_p, wt.DWORD, wt.DWORD, ctypes.c_void_p, wt.DWORD]
    k32.GetFinalPathNameByHandleW.argtypes = [wt.HANDLE, wt.LPWSTR, wt.DWORD, wt.DWORD]
    k32.CloseHandle.argtypes = [wt.HANDLE]
INVALID = ctypes.c_void_p(-1).value
GENERIC_READ, SHARE_ALL, OPEN_EXISTING, BACKUP = 0x80000000, 0x7, 3, 0x02000000
FSCTL_QUERY_USN_JOURNAL, FSCTL_READ_USN_JOURNAL = 0x000900F4, 0x000900BB


def ft_to_epoch(ft):
    return ft / 1e7 - 11644473600.0


class Volume:
    def __init__(self, letter):
        self.letter = letter
        self.h = k32.CreateFileW('\\\\.\\' + letter, GENERIC_READ, SHARE_ALL, None, OPEN_EXISTING, 0, None)
        if self.h in (None, INVALID):
            raise OSError(ctypes.get_last_error(), 'OPEN_VOLUME_' + letter)
        self.root = k32.CreateFileW(letter + '\\', 0x80, SHARE_ALL, None, OPEN_EXISTING, BACKUP, None)
        self.cache = {}

    def close(self):
        for h in (self.h, self.root):
            if h not in (None, INVALID):
                k32.CloseHandle(h)

    def query(self):
        out = ctypes.create_string_buffer(80); ret = wt.DWORD()
        if not k32.DeviceIoControl(self.h, FSCTL_QUERY_USN_JOURNAL, None, 0, out, 80, ctypes.byref(ret), None):
            return {'active': False, 'error': ctypes.get_last_error()}
        jid, first, nxt, lowest, mx, size, delta = struct.unpack_from('<QqqqqQQ', out.raw, 0)
        return {'active': True, 'journal_id': jid, 'first_usn': first, 'next_usn': nxt, 'lowest_valid_usn': lowest,
                'maximum_size': size}

    def records(self, info):
        """Every record from the oldest retained USN up to the snapshot NextUsn (no wait)."""
        start, end, jid = max(info['first_usn'], info['lowest_valid_usn']), info['next_usn'], info['journal_id']
        buf = ctypes.create_string_buffer(1 << 20); ret = wt.DWORD()
        while start < end:
            inp = struct.pack('<qIIQQQ', start, 0xFFFFFFFF, 0, 0, 0, jid)
            if not k32.DeviceIoControl(self.h, FSCTL_READ_USN_JOURNAL, inp, len(inp), buf, len(buf), ctypes.byref(ret), None):
                raise OSError(ctypes.get_last_error(), 'READ_USN_JOURNAL')
            n = ret.value
            if n <= 8:
                break
            nxt = struct.unpack_from('<q', buf.raw, 0)[0]
            off = 8
            raw = buf.raw[:n]
            while off < n:
                rl, maj = struct.unpack_from('<IH', raw, off)
                if rl == 0:
                    break
                if maj == 2:
                    frn, pfrn, usn, ts, reason, src, sec, attrs, fl, fo = struct.unpack_from('<QQqqIIIIHH', raw, off + 8)
                elif maj == 3:
                    frn = int.from_bytes(raw[off + 8:off + 24], 'little') & MASK64
                    pfrn = int.from_bytes(raw[off + 24:off + 40], 'little') & MASK64
                    usn, ts, reason, src, sec, attrs, fl, fo = struct.unpack_from('<qqIIIIHH', raw, off + 40)
                else:
                    off += rl; continue
                name = raw[off + fo:off + fo + fl].decode('utf-16-le', 'replace')
                yield {'usn': usn, 'time': ft_to_epoch(ts), 'frn': frn, 'parent_frn': pfrn, 'name': name,
                       'reason': reason, 'source_info': src, 'attributes': attrs}
                off += rl
            if nxt <= start:
                break
            start = nxt

    def path_of(self, frn):
        if frn in self.cache:
            return self.cache[frn]
        desc = struct.pack('<IIq8x', 24, 0, frn & 0x7FFFFFFFFFFFFFFF if frn < (1 << 63) else frn - (1 << 64))
        h = k32.OpenFileById(self.root, desc, 0x80, SHARE_ALL, None, BACKUP)
        path = None
        if h not in (None, INVALID):
            b = ctypes.create_unicode_buffer(2048)
            n = k32.GetFinalPathNameByHandleW(h, b, 2048, 0)
            path = b.value[4:] if n and b.value.startswith('\\\\?\\') else (b.value or None)
            k32.CloseHandle(h)
        self.cache[frn] = path
        return path


def reasons(mask):
    return '|'.join(n for b, n in REASONS if mask & b)


def dir_frns(base):
    """FRNs of base and of every directory below it (handle view, links not followed)."""
    out = {}
    stack = [Path(base)]
    while stack:
        d = stack.pop()
        try:
            out[os.lstat(d).st_ino & MASK64] = str(d)
            with os.scandir(d) as it:
                for e in it:
                    if e.is_dir(follow_symlinks=False) and not e.is_symlink() and not e.is_junction():
                        stack.append(Path(e.path))
        except OSError:
            continue
    return out


def main():
    ap = argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument('--supervisor', required=True); ap.add_argument('--qual-result', required=True)
    ap.add_argument('--log-dir', required=True); ap.add_argument('--observe-seconds', type=int, default=120)
    ap.add_argument('--observe-interval', type=int, default=30)
    a = ap.parse_args()
    log_dir = Path(a.log_dir)
    res = {'schema': SCHEMA, 'status': 'BLOCKED', 'read_only': True, 'started_epoch': time.time(), 'notes': []}
    code = 2
    try:
        assert os.name == 'nt', 'WINDOWS_REQUIRED'
        assert ctypes.WinDLL('shell32').IsUserAnAdmin(), 'ELEVATION_REQUIRED'
        assert sha_file(a.supervisor) == SUPERVISOR_SHA, 'SUPERVISOR_SHA'
        assert sha_file(a.qual_result) == QUAL_SHA, 'QUAL_RESULT_SHA'
        spec = importlib.util.spec_from_file_location('g5v4_supervisor_readonly', a.supervisor)
        sup = importlib.util.module_from_spec(spec); spec.loader.exec_module(sup)
        q = json.loads(Path(a.qual_result).read_bytes())
        local = os.environ['LOCALAPPDATA']
        q_end = float(q['finished_epoch']); q_start = q_end - float(q['seconds'])
        res['q_window_epoch'] = [q_start, q_end]
        res['q_window_utc'] = [time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(x)) for x in (q_start, q_end)]
        before = q['foreign_roots']

        emit('DIAG 1/6 digest atual com as funcoes exatas do supervisor')
        now1 = sup.foreign_roots(local)
        rows1 = {k: rows_like_supervisor(key_path(local, k, sup)) for k, v in now1.items() if not v.get('not_a_directory')}
        res['rows_consistent_with_supervisor_digest'] = {
            k: hashlib.sha256(json.dumps(rows1[k]).encode()).hexdigest().upper() == now1[k]['sha256'] for k in rows1}
        res['q_before_vs_now'] = diff_snap(before, now1)
        res['q_before_vs_now_summary'] = {k: len(v) for k, v in res['q_before_vs_now'].items()}
        recent_cut = (q_start - 600) * 1e9
        res['entries_modified_since_q_minus_10min'] = {
            k: [r for r in rows1[k] if r[2] >= recent_cut][:300] for k in rows1 if any(r[2] >= recent_cut for r in rows1[k])}
        top = {}
        for k in now1:
            p = key_path(local, k, sup)
            try:
                st = os.lstat(p)
                top[k] = {'birth_epoch': getattr(st, 'st_birthtime', None), 'mtime_epoch': st.st_mtime}
            except OSError as exc:
                top[k] = {'error': str(exc)}
        res['top_level_times'] = top
        (log_dir / 'ROWS_NOW.json').write_text(json.dumps(rows1), encoding='utf-8')

        emit('DIAG 2/6 vista do indice de diretorio x vista do handle (mesmas entradas, somente leitura)')
        di, ino = [], {}
        for k, rows in rows1.items():
            base = key_path(local, k, sup)
            for rel, size, mt in rows:
                if size in (-3, -4):
                    continue
                p = base / rel
                try:
                    st = os.lstat(p)
                except OSError as exc:
                    di.append([k, rel, 'LSTAT_ERROR', str(exc)]); continue
                hsize = -1 if size in (-1, -2) else st.st_size
                if st.st_mtime_ns != mt or hsize != size:
                    di.append([k, rel, [size, mt], [hsize, st.st_mtime_ns]])
        res['index_view_vs_handle_view_discrepancies'] = {'count': len(di), 'first': di[:300]}

        emit('DIAG 2b/6 controle em arvores que a Q nunca percorreu: indice, handle, indice de novo')
        ctrl = {}
        for name in ('CDT21_F01R1_G0', 'CDT21_F01_G0', 'CDT21_G5_V003'):
            base = Path(local) / name
            if not base.is_dir():
                ctrl[name] = {'exists': False}; continue
            first = rows_like_supervisor(base)
            hv = {}
            for rel, size, mt in first:
                if size in (-3, -4):
                    continue
                try:
                    st = os.lstat(base / rel)
                    hv[rel] = (-1 if size in (-1, -2) else st.st_size, st.st_mtime_ns)
                except OSError:
                    pass
            second = rows_like_supervisor(base)
            s1, s2 = {r[0]: r for r in first}, {r[0]: r for r in second}
            stale = [rel for rel, (sz, mt) in hv.items() if (s1[rel][1], s1[rel][2]) != (sz, mt)]
            ctrl[name] = {'exists': True, 'entries': len(first),
                          'index_first_ne_handle': len(stale),
                          'index_second_eq_handle_for_those': sum(1 for rel in stale if rel in s2 and (s2[rel][1], s2[rel][2]) == hv[rel]),
                          'index_first_ne_index_second': sum(1 for rel in s1 if rel in s2 and s1[rel] != s2[rel]),
                          'digest_first_eq_second': first == second,
                          'examples': [[rel, list(s1[rel][1:]), list(hv[rel]), list(s2[rel][1:]) if rel in s2 else None] for rel in stale[:50]]}
        res['control_trees_not_walked_by_q'] = ctrl

        emit('DIAG 3/6 segundo digest imediato e observacao temporizada (nenhuma atividade da campanha)')
        now2 = sup.foreign_roots(local)
        res['immediate_repeat_equal'] = now2 == now1
        if now2 != now1:
            d = diff_snap(now1, now2); res['immediate_repeat_diff'] = d
            res['immediate_repeat_rows'] = {k: diff_rows(rows1[k], rows_like_supervisor(key_path(local, k, sup)))
                                            for k in d['changed']}
        obs, prev, prev_rows = [], now2, rows1
        t_end = time.time() + a.observe_seconds
        while time.time() < t_end:
            time.sleep(max(1, min(a.observe_interval, t_end - time.time())))
            cur = sup.foreign_roots(local)
            item = {'epoch': time.time(), 'equal_to_previous': cur == prev}
            if cur != prev:
                d = diff_snap(prev, cur); item['diff'] = d
                new_rows = {k: rows_like_supervisor(key_path(local, k, sup)) for k in d['changed']}
                item['rows'] = {k: diff_rows(prev_rows.get(k, []), new_rows[k]) for k in new_rows}
                prev_rows = dict(prev_rows, **new_rows)
            obs.append(item); prev = cur
        res['observation'] = {'seconds': a.observe_seconds, 'samples': obs, 'all_equal': all(o['equal_to_previous'] for o in obs)}

        emit('DIAG 4/6 D:\\Base CSV contra a impressao digital "antes" da Q')
        prod = sup.production_fingerprint()
        res['production_equal_to_q_before'] = prod == q['production_fingerprint']
        res['production_now'] = prod

        emit('DIAG 5/6 diario USN de C: e D: (janela da Q e ate agora)')
        sets = {'foreign': {}, 'production': {}, 'q_own': {}}
        for k in now1:
            if not now1[k].get('not_a_directory'):
                sets['foreign'].update(dir_frns(key_path(local, k, sup)))
        for parent in (Path(local) / sup.RUN_PARENT, Path(sup.D_LABS)):
            if parent.exists():
                sets['foreign'][os.lstat(parent).st_ino & MASK64] = str(parent)
        sets['production'].update(dir_frns(Path(sup.PRODUCTION)))
        own_home = Path(local) / sup.EXTRACT_HOME
        for name in ('CURRENT_G5_DELTA_QUAL_' + q['stamp'], 'QUAL_NEG_' + q['stamp']):
            if (own_home / name).exists():
                sets['q_own'].update(dir_frns(own_home / name))
        if own_home.exists():
            sets['q_own'][os.lstat(own_home).st_ino & MASK64] = str(own_home)
        if Path(q['log_dir']).exists():
            sets['q_own'][os.lstat(q['log_dir']).st_ino & MASK64] = q['log_dir']
        res['frn_set_sizes'] = {k: len(v) for k, v in sets.items()}
        usn = {}
        lo, hi = q_start - 60, q_end + 60
        for letter in ('C:', 'D:'):
            v = {'letter': letter}
            try:
                vol = Volume(letter)
            except OSError as exc:
                usn[letter] = {'error': str(exc)}; continue
            try:
                info = vol.query(); v['journal'] = info
                if not info.get('active'):
                    usn[letter] = v; continue
                oldest, counts, hits, dwin, n = None, {}, [], [], 0
                for r in vol.records(info):
                    n += 1
                    if oldest is None:
                        oldest = r['time']
                    if r['time'] < lo:
                        continue
                    in_window = r['time'] <= hi
                    cls = next((c for c in ('foreign', 'production', 'q_own')
                                if r['parent_frn'] in sets[c] or r['frn'] in sets[c]), None)
                    if cls:
                        counts[(cls, in_window)] = counts.get((cls, in_window), 0) + 1
                        if cls != 'q_own' or len(hits) < 4000:
                            hits.append(dict(r, cls=cls, in_q_window=in_window, reasons=reasons(r['reason']),
                                             parent_path=sets[cls].get(r['parent_frn']) or vol.path_of(r['parent_frn'])))
                    elif letter == 'D:' and in_window and len(dwin) < 5000:
                        dwin.append(dict(r, reasons=reasons(r['reason']), parent_path=vol.path_of(r['parent_frn'])))
                    elif in_window:
                        counts[('other', True)] = counts.get(('other', True), 0) + 1
                v.update(records_read=n, oldest_record_epoch=oldest,
                         covers_q_window=oldest is not None and oldest <= q_start,
                         counts={'%s|%s' % (c, 'Q_WINDOW' if w else 'AFTER_Q'): m for (c, w), m in sorted(counts.items())},
                         hits_foreign=[h for h in hits if h['cls'] == 'foreign'][:5000],
                         hits_production=[h for h in hits if h['cls'] == 'production'][:5000],
                         hits_q_own_in_window=[h for h in hits if h['cls'] == 'q_own' and h['in_q_window']][:300],
                         d_other_in_q_window=dwin)
            except OSError as exc:
                v['error'] = str(exc)
            finally:
                vol.close()
            usn[letter] = v
        res['usn'] = usn

        emit('DIAG 6/6 sintese')
        f_win = sum(len([h for h in usn.get(l, {}).get('hits_foreign', []) if h['in_q_window']]) for l in usn)
        f_after = sum(len([h for h in usn.get(l, {}).get('hits_foreign', []) if not h['in_q_window']]) for l in usn)
        covered = all(usn.get(l, {}).get('covers_q_window') for l in ('C:', 'D:'))
        own_seen = sum(len(usn.get(l, {}).get('hits_q_own_in_window', [])) for l in usn)
        changed = res['q_before_vs_now_summary']
        persistent = any(changed.values())
        res['facts'] = {'foreign_changed_vs_q_before': changed, 'usn_foreign_records_in_q_window': f_win,
                        'usn_foreign_records_after_q': f_after, 'usn_covers_q_window_on_c_and_d': covered,
                        'usn_q_own_records_in_window': own_seen, 'immediate_repeat_equal': res['immediate_repeat_equal'],
                        'observation_all_equal': res['observation']['all_equal'],
                        'index_vs_handle_discrepancies': len(di), 'production_equal_to_q_before': res['production_equal_to_q_before'],
                        'control_trees_read_only_digest_moved': {k: (not v['digest_first_eq_second']) for k, v in ctrl.items() if v.get('exists')}}
        ctrl_moved = any(res['facts']['control_trees_read_only_digest_moved'].values())
        if f_win:
            cls = 'FILESYSTEM_MODIFICATION_IN_FOREIGN_ROOTS_DURING_Q'
        elif ctrl_moved and persistent:
            cls = 'INDEX_VIEW_REFRESHED_BY_READING_NO_MODIFICATION'
        elif not res['immediate_repeat_equal'] or not res['observation']['all_equal']:
            cls = 'DIGEST_MOVES_WITHOUT_CAMPAIGN_ACTIVITY'
        elif persistent and covered and own_seen and not f_win:
            cls = 'DIGEST_CHANGED_WITHOUT_ANY_JOURNALED_MODIFICATION'
        elif not persistent:
            cls = 'NO_PERSISTENT_DIFFERENCE_TRANSIENT_DURING_Q'
        else:
            cls = 'UNDETERMINED_JOURNAL_NOT_COVERING_WINDOW'
        res['preliminary_classification'] = cls
        res['status'] = 'DIAG_COMPLETE'; code = 0
        emit('DIAG_CLASSIFICACAO_PRELIMINAR=' + cls)
        emit('DIAG_FATOS=' + json.dumps(res['facts'], sort_keys=True))
    except BaseException as exc:
        res['error'] = type(exc).__name__ + ':' + str(exc); res['traceback'] = traceback.format_exc()
        emit('DIAG_BLOCKED=' + res['error'])
    finally:
        res['finished_epoch'] = time.time()
        (log_dir / 'DIAG_RESULT.json').write_text(json.dumps(res, indent=1, sort_keys=True, default=str), encoding='utf-8')
        emit('DIAG_RESULT=' + str(log_dir / 'DIAG_RESULT.json') + ' SHA256=' + sha_file(log_dir / 'DIAG_RESULT.json') + ' EXIT_CODE=' + str(code))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
