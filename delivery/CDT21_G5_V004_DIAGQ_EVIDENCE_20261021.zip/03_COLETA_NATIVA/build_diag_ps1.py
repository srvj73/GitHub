"""Generate RUN_CDT21_G5_V004_DIAG_RAIZES_READONLY_20261021.ps1 (ASCII, CRLF) with SHA-pinned embedded payloads."""
import base64
import hashlib
import sys
from pathlib import Path

sup, diag, out = map(Path, sys.argv[1:4])
H = lambda b: hashlib.sha256(b).hexdigest().upper()
B = lambda b: '\n'.join(base64.b64encode(b).decode()[i:i + 100] for i in range(0, len(base64.b64encode(b)), 100))
sup_raw, diag_raw = sup.read_bytes(), diag.read_bytes()
assert H(sup_raw) == '273E620746FD5293D87858847CEBE035328B2A354F4371BBB18D82195A410126'
T = r"""#requires -Version 5.1
# TICKSTORE CDT21 - DIAGNOSTICO SOMENTE LEITURA da Fase Q G5 V004 bloqueada por QUAL_q_no_effect_on_foreign_roots
# (retorno 289A064E..., Q de 21/10 15:40, QUALIFICATION_RESULT 966F33CD...). Nao executa campanha, b2d, supervisor
# (main) nem codigo congelado; nao grava em raizes preexistentes, laboratorios do D:, D:\Base CSV ou qualquer outro lugar
# alem da pasta de log abaixo. Coleta: digest atual com as funcoes exatas do supervisor (273E6207...), comparacao por raiz
# com o "antes" da Q, vista do indice x vista do handle, controle em arvores que a Q nunca percorreu, observacao de 2 min,
# diario USN de C: e D: (janela da Q e ate agora), impressao digital de D:\Base CSV, processos e eventos do Defender.
# Execute a partir de PS C:\Users\silvi> em PowerShell 5.1 (autoeleva por UAC; a leitura do diario USN exige administrador):
#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\silvi\Downloads\RUN_CDT21_G5_V004_DIAG_RAIZES_READONLY_20261021.ps1"
# Pre-requisito: a pasta da Q bloqueada continua em C:\Users\silvi\Downloads\CDT21_G5_V004_RUNS\G5V4_20261021_153955_137_23632
# Log sempre em pasta absoluta fixa, nova a cada execucao, independente da pasta atual:
#   C:\Users\silvi\Downloads\CDT21_G5_V004_RUNS\DIAGQ_<yyyyMMdd_HHmmss_fff_PID>\RUN_LOG.txt (pai) e RUN_LOG_ELEVATED.txt (filho)
# Duracao esperada: 3 a 6 minutos. Retorno: ENVIAR_AO_OPUS_CDT21_G5_V004_DIAGQ_<carimbo>.zip na mesma pasta.
[CmdletBinding()]
param([switch]$ElevatedChild, [string]$SharedLogDir = '')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$Thread = 'Compress' + [char]0x00E3 + 'o De Ticks 21'
$RunsDir = 'C:\Users\silvi\Downloads\CDT21_G5_V004_RUNS'
$QualResult = 'C:\Users\silvi\Downloads\CDT21_G5_V004_RUNS\G5V4_20261021_153955_137_23632\QUALIFICATION_RESULT.json'
$QualSha = '966F33CD4DEDF449B7C52833702F3C9AD8ED1BA3BEF7112E57AE96C50712DC68'
$Python = 'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe'
$ExpectedPythonSha = '4942B86A6597E5AEE0128DAA00050ED79BC21F6E709A78EB19CBFEB0C2F39AC9'
$SupervisorName = 'CDT21_G5_V004_SUPERVISOR.py'
$SupervisorSha = '@@SUP_SHA@@'
$DiagName = 'CDT21_G5_V004_DIAG_RAIZES.py'
$DiagSha = '@@DIAG_SHA@@'
$Stamp = (Get-Date).ToString('yyyyMMdd_HHmmss_fff') + '_' + $PID
$Utf8 = New-Object Text.UTF8Encoding($false)
if ($ElevatedChild) {
    $full = [IO.Path]::GetFullPath($SharedLogDir)
    if (-not $SharedLogDir -or -not $full.StartsWith($RunsDir + '\DIAGQ_', [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $full -PathType Container)) {
        throw ('SHARED_LOG_DIR_INVALID=' + $SharedLogDir)
    }
    $LogDir = $full
    $Log = Join-Path $LogDir 'RUN_LOG_ELEVATED.txt'
} else {
    if (-not (Test-Path -LiteralPath $RunsDir -PathType Container)) { New-Item -ItemType Directory -Path $RunsDir -ErrorAction Stop | Out-Null }
    $LogDir = Join-Path $RunsDir ('DIAGQ_' + $Stamp)
    New-Item -ItemType Directory -Path $LogDir -ErrorAction Stop | Out-Null
    $Log = Join-Path $LogDir 'RUN_LOG.txt'
}

$SupervisorB64 = @'
@@SUP_B64@@
'@

$DiagB64 = @'
@@DIAG_B64@@
'@

function Log([string]$Line) {
    Write-Host $Line
    [IO.File]::AppendAllText($Log, $Line + "`r`n", $Utf8)
}
function ShaBytes([byte[]]$Bytes) {
    $h = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($h.ComputeHash($Bytes)).Replace('-', '') } finally { $h.Dispose() }
}
function Sha([string]$Path) {
    $s = [IO.File]::OpenRead($Path); $h = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($h.ComputeHash($s)).Replace('-', '') } finally { $h.Dispose(); $s.Dispose() }
}
function Unpack([string]$B64, [string]$Expected, [string]$Path) {
    $bytes = [Convert]::FromBase64String(($B64 -replace '\s', ''))
    if ((ShaBytes $bytes) -cne $Expected) { throw ('EMBEDDED_SHA_MISMATCH=' + $Path) }
    [IO.File]::WriteAllBytes($Path, $bytes)
    if ((Sha $Path) -cne $Expected) { throw ('EMBEDDED_READBACK_MISMATCH=' + $Path) }
    Log ('UNPACKED=' + $Path + ' SHA256=' + $Expected)
}
function SaveJson([string]$Name, $Object) {
    $p = Join-Path $LogDir $Name
    [IO.File]::WriteAllText($p, (ConvertTo-Json -InputObject $Object -Depth 4), $Utf8)
    Log ('COLLECTED=' + $p + ' SHA256=' + (Sha $p))
}

$code = 2
try {
    Log ('RESULT_CONTEXT=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=' + $Thread)
    Log ('RUN_LOG=' + $Log)
    Log ('DIAGNOSTICO=' + $PSCommandPath + ' SHA256=' + (Sha $PSCommandPath))
    Log 'MODO=SOMENTE_LEITURA; CAMPANHA=NAO; B2D=NAO; SUPERVISOR_MAIN=NAO; ESCRITA=SO_NESTA_PASTA_DE_LOG; PRODUCAO=NAO; B06=NOT_STARTED'
    if ($PSVersionTable.PSEdition -ne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'WINDOWS_POWERSHELL_5_1_REQUIRED' }
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($id)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        if ($ElevatedChild) { throw 'ELEVATION_REENTRY_GUARD: rights missing after RunAs' }
        $si = New-Object System.Diagnostics.ProcessStartInfo
        $si.FileName = Join-Path $PSHOME 'powershell.exe'
        $si.WorkingDirectory = 'C:\Users\silvi'
        $si.UseShellExecute = $true
        $si.Verb = 'runas'
        $si.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -ElevatedChild -SharedLogDir "' + $LogDir + '"'
        Log ('UAC_REQUEST=YES LOG_COMPARTILHADO=' + $LogDir)
        $child = [System.Diagnostics.Process]::Start($si)
        if ($null -eq $child) { throw 'UAC_NO_CHILD_PROCESS' }
        try {
            Log ('ELEVATED_CHILD_PID=' + $child.Id)
            $deadline = [DateTime]::UtcNow.AddHours(1)
            while (-not $child.WaitForExit(5000)) {
                if ([DateTime]::UtcNow -ge $deadline) { throw 'ELEVATED_CHILD_WAIT_TIMEOUT' }
            }
            $child.WaitForExit(); $child.Refresh()
            $code = [int]$child.ExitCode
            Log ('ELEVATED_CHILD_EXIT_CODE=' + $code)
        } finally { $child.Dispose() }
    } else {
        if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { throw ('PYTHON_MISSING=' + $Python) }
        if ((Sha $Python) -cne $ExpectedPythonSha) { throw 'PYTHON_SHA_MISMATCH' }
        if (-not (Test-Path -LiteralPath $QualResult -PathType Leaf)) { throw ('Q_RESULT_MISSING=' + $QualResult) }
        if ((Sha $QualResult) -cne $QualSha) { throw 'Q_RESULT_SHA_MISMATCH' }
        Log ('Q_RESULT=' + $QualResult + ' SHA256_OK=' + $QualSha)
        $Bin = Join-Path $LogDir 'BIN'
        New-Item -ItemType Directory -Path $Bin -ErrorAction Stop | Out-Null
        $Supervisor = Join-Path $Bin $SupervisorName
        $Diag = Join-Path $Bin $DiagName
        Unpack $SupervisorB64 $SupervisorSha $Supervisor
        Unpack $DiagB64 $DiagSha $Diag
        $procs = @(Get-CimInstance Win32_Process -ErrorAction Stop | ForEach-Object {
            $cd = ''; if ($null -ne $_.CreationDate) { $cd = ([DateTime]$_.CreationDate).ToUniversalTime().ToString('o') }
            New-Object PSObject -Property ([ordered]@{ pid = [int]$_.ProcessId; ppid = [int]$_.ParentProcessId; name = [string]$_.Name;
                created_utc = $cd; path = [string]$_.ExecutablePath; command_line = [string]$_.CommandLine }) })
        SaveJson 'PROCESSES.json' $procs
        try { Log ('DISABLELASTACCESS=' + ((& fsutil behavior query disablelastaccess 2>&1 | Out-String).Trim())) } catch { Log ('DISABLELASTACCESS_ERRO=' + $_.Exception.Message) }
        try {
            $det = @(Get-MpThreatDetection -ErrorAction Stop | ForEach-Object { New-Object PSObject -Property ([ordered]@{
                detected_utc = ([DateTime]$_.InitialDetectionTime).ToUniversalTime().ToString('o'); threat_id = [string]$_.ThreatID;
                action_success = [string]$_.ActionSuccess; resources = @($_.Resources | ForEach-Object { [string]$_ }); process = [string]$_.ProcessName }) })
            SaveJson 'DEFENDER_DETECTIONS.json' $det
        } catch { Log ('DEFENDER_DETECTIONS_INDISPONIVEL=' + $_.Exception.Message) }
        try {
            $ev = @(Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-Windows Defender/Operational'; StartTime = (Get-Date '2026-10-21 15:25:00'); EndTime = (Get-Date '2026-10-21 16:05:00') } -ErrorAction Stop |
                ForEach-Object { New-Object PSObject -Property ([ordered]@{ time_utc = $_.TimeCreated.ToUniversalTime().ToString('o'); id = [int]$_.Id; message = [string]$_.Message }) })
            SaveJson 'DEFENDER_EVENTS_Q_WINDOW.json' $ev
        } catch { Log ('DEFENDER_EVENTS_Q_WINDOW=NENHUM_OU_INDISPONIVEL (' + $_.Exception.Message + ')') }
        $oldPref = $ErrorActionPreference
        try {
            $ErrorActionPreference = 'Continue'
            Log 'DIAG=INICIO (somente leitura; ~3 a 6 min, inclui 2 min de observacao sem nenhuma atividade da campanha)'
            & $Python -I -B $Diag --supervisor $Supervisor --qual-result $QualResult --log-dir $LogDir --observe-seconds 120 --observe-interval 30 2>&1 | ForEach-Object { Log ([string]$_) }
            $code = $LASTEXITCODE
        } finally { $ErrorActionPreference = $oldPref }
        foreach ($name in @('DIAG_RESULT.json', 'ROWS_NOW.json')) {
            $p = Join-Path $LogDir $name
            if (Test-Path -LiteralPath $p -PathType Leaf) { Log ('COLLECTED=' + $p + ' SHA256=' + (Sha $p)) } else { Log ('NOT_PRODUCED=' + $name) }
        }
    }
} catch {
    Log ('DIAG_BLOCKED=' + $_.Exception.Message)
    $code = 2
} finally {
    Log ('EXIT_CODE=' + $code)
    if ($ElevatedChild) {
        Log 'FILHO_ELEVADO_CONCLUIDO (o processo pai empacota o retorno unico)'
    } else {
        $Send = Join-Path $LogDir ('ENVIAR_AO_OPUS_CDT21_G5_V004_DIAGQ_' + $Stamp + '.zip')
        try {
            Add-Type -AssemblyName System.IO.Compression
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            $files = @(Get-ChildItem -LiteralPath $LogDir -File -Recurse | Where-Object { $_.FullName -ne $Send })
            $zip = [IO.Compression.ZipFile]::Open($Send, [IO.Compression.ZipArchiveMode]::Create)
            try {
                foreach ($f in $files) {
                    $rel = $f.FullName.Substring($LogDir.Length + 1).Replace('\', '/')
                    [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $f.FullName, $rel, [IO.Compression.CompressionLevel]::Optimal)
                }
            } finally { $zip.Dispose() }
            Log ('ENVIE_O_RETORNO=' + $Send)
            Log ('ENVIE_O_RETORNO_SHA256=' + (Sha $Send))
        } catch {
            Log ('ENVIAR_ZIP_FALHOU=' + $_.Exception.Message + ' (envie o conteudo de ' + $LogDir + ')')
        }
        Log ('Devolva este resultado diretamente ao Opus, conversa ' + $Thread + '. Anexe o ZIP e cole o RUN_LOG.')
        Log ('RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=' + $Thread)
    }
}
exit $code
"""
text = (T.replace('@@SUP_SHA@@', H(sup_raw)).replace('@@DIAG_SHA@@', H(diag_raw))
         .replace('@@SUP_B64@@', B(sup_raw)).replace('@@DIAG_B64@@', B(diag_raw)))
assert '@@' not in text
data = text.replace('\r\n', '\n').replace('\n', '\r\n').encode('ascii')
out.write_bytes(data)
print(out.name, H(data), len(data), 'DIAG', H(diag_raw))
