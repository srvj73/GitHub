"""Linux replay of the effectful steps of qualify_main with a write-audit on every process involved.

Usage: python -I q_replay_audit.py <supervisor.py> <V004.zip> <v003_root_copy_src> <workdir> <out.json>
Question answered: do the steps that Q performs between the two foreign_roots() snapshots (extraction, fixture contract,
plan import, frozen verify_package, b2d native positive and R1-layout negative) write anything outside Q's own
directories?  Every open-for-write / mkdir / rename / remove / chmod / utime of the supervisor process and of the b2d
child processes is recorded through sys.addaudithook.  The foreign roots are a copy of the real V003 run root and
a D-lab, so the digest runs over real collected bytes.
"""
import importlib.util
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

sup_path, package, v003_src, work, out = map(Path, sys.argv[1:6])
work = work.resolve()
if work.exists():
    shutil.rmtree(work)
local = work / 'LOCAL'
(local / 'CDT20_R08').mkdir(parents=True)
shutil.copytree(v003_src, local / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791', symlinks=True)
(local / 'CDT20_R08' / 'CURRENT_09AA56B867476005.json').write_text('{"x": 1}')
dlabs = work / 'D:\\TICKSTORE_CDT19_PRE_G06_LABS'          # what the Windows constant resolves to under POSIX
shutil.copytree(v003_src / 'COMMITS', dlabs / 'R08_Q1_20261020210605_856fea523791' / 'WRITER_EFFECTFUL', symlinks=True)
stage = work / 'STAGE'; stage.mkdir(); logd = work / 'LOG'; logd.mkdir()
os.chdir(work)
os.environ['LOCALAPPDATA'] = str(local)

WRAPPER = work / 'audit_wrapper.py'
WRAPPER.write_text(r'''
import json, os, runpy, sys
LOG = sys.argv[1]; sys.argv = [sys.argv[2]] + sys.argv[3:]
FD = os.open(LOG + '.raw', os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)   # opened before the hook exists
EV = {'os.mkdir', 'os.rename', 'os.replace', 'os.remove', 'os.rmdir', 'os.chmod', 'os.utime', 'os.symlink', 'os.link',
      'os.truncate', 'shutil.rmtree', 'shutil.move', 'shutil.copyfile', 'shutil.copytree'}
def hook(ev, args):
    if ev == 'open' and args and isinstance(args[0], (str, bytes, os.PathLike)):
        mode, flags = (args[1] if len(args) > 1 else 'r'), (args[2] if len(args) > 2 else 0)
        if (isinstance(mode, str) and any(c in mode for c in 'wax+')) or (isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT)):
            rec = ('open', os.fsdecode(args[0]) if not isinstance(args[0], int) else str(args[0]))
        else:
            return
    elif ev in EV:
        rec = (ev, ' | '.join(os.fsdecode(a) for a in args if isinstance(a, (str, bytes, os.PathLike))))
    else:
        return
    os.write(FD, (json.dumps(rec) + '\n').encode())   # os.write raises no audit event: no recursion
sys.addaudithook(hook)
runpy.run_module(sys.argv[0], run_name='__main__', alter_sys=True)
''')
AUDIT = work / 'AUDIT'
real_run = subprocess.run
counter = [0]


def audited_run(cmd, *a, **kw):
    # native_b2d runs: [python, -I, -B, -m, unittest, ...]; run the same command under the audit wrapper.
    if isinstance(cmd, list) and cmd[:5] == [sys.executable, '-I', '-B', '-m', 'unittest']:
        counter[0] += 1
        cmd = [sys.executable, '-I', '-B', str(WRAPPER), str(AUDIT) + '_child%d' % counter[0], 'unittest'] + cmd[5:]
    return real_run(cmd, *a, **kw)


subprocess.run = audited_run
spec = importlib.util.spec_from_file_location('g5v4_supervisor', sup_path)
sup = importlib.util.module_from_spec(spec); spec.loader.exec_module(sup)

events = []
EVS = {'os.mkdir', 'os.rename', 'os.replace', 'os.remove', 'os.rmdir', 'os.chmod', 'os.utime', 'os.symlink', 'os.link',
       'os.truncate', 'shutil.rmtree', 'shutil.move', 'shutil.copyfile', 'shutil.copytree'}


def hook(ev, args):
    if ev == 'open' and args and isinstance(args[0], (str, bytes, os.PathLike)):
        mode, flags = (args[1] if len(args) > 1 else 'r'), (args[2] if len(args) > 2 else 0)
        if (isinstance(mode, str) and any(c in mode for c in 'wax+')) or (isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT)):
            events.append(('open', os.fsdecode(args[0])))
    elif ev in EVS:
        events.append((ev, ' | '.join(os.fsdecode(a) for a in args if isinstance(a, (str, bytes, os.PathLike)))))


def rows_of(base):
    rows = []
    for dp, dns, fns in os.walk(base, followlinks=False):
        for n in dns + fns:
            p = os.path.join(dp, n); st = os.lstat(p)
            rows.append((os.path.relpath(p, base), st.st_size if not os.path.isdir(p) else -1, st.st_mtime_ns))
    return sorted(rows)


foreign = sup.foreign_roots(str(local))
rows_before = {k: rows_of(local / 'CDT20_R08' / k.split('/', 1)[1]) if k.startswith('run/') else rows_of(dlabs / k.split('/', 1)[1])
               for k, v in foreign.items() if not v.get('not_a_directory')}
sys.addaudithook(hook)
stamp = 'REPLAY_000000'
home = local / sup.EXTRACT_HOME; home.mkdir(exist_ok=True); sup.plain_directory(home)
ext = home / (sup.DELTA_PREFIX + 'QUAL_' + stamp) / 'EXTRACTED'; ext.parent.mkdir()
sup.extract_package(package, ext); sup.check_fixture_contract(ext)
plan = sup.plan_keys(ext)
import PRE_G06_CAMPAIGN as campaign  # noqa: E402  (same import the supervisor performs)
code_sha, _ = campaign.verify_package(package)
qtemp = ext.parent / 'QTEMP'; qtemp.mkdir()
pos = sup.native_b2d(ext, qtemp, logd / 'B2D_NATIVE_FIXED_LAYOUT.log')
neg = home / ('QUAL_NEG_' + stamp) / 'R08_Q1_00000000000000_000000000000' / 'PACKAGED'
neg.parent.mkdir(parents=True); sup.extract_package(package, neg)
ntemp = neg.parent / 'QTEMP'; ntemp.mkdir()
negr = sup.native_b2d(neg, ntemp, logd / 'B2D_NATIVE_R1_LAYOUT.log')
after = sup.foreign_roots(str(local))
for i in range(1, counter[0] + 1):
    raw = Path(str(AUDIT) + '_child%d.raw' % i)
    if raw.exists():
        events += [tuple(json.loads(l)) for l in raw.read_text().splitlines()]

own = [str(home), str(stage), str(logd), str(work / 'AUDIT')]
foreign_dirs = [str(local / 'CDT20_R08'), str(dlabs)]
outside = sorted({e for e in events if not any(e[1].startswith(o) for o in own)})
in_foreign = sorted({e for e in events if any(f in e[1] for f in foreign_dirs)})
rows_after = {k: rows_of(local / 'CDT20_R08' / k.split('/', 1)[1]) if k.startswith('run/') else rows_of(dlabs / k.split('/', 1)[1])
              for k, v in after.items() if not v.get('not_a_directory')}
doc = {'schema': 'CDT21_G5_V004_Q_REPLAY_WRITE_AUDIT_V001', 'platform': sys.platform, 'python': sys.version.split()[0],
       'supervisor': str(sup_path.name), 'plan_units': len(plan), 'code_sha': code_sha,
       'b2d_positive': {k: pos[k] for k in ('exit', 'ran', 'ok', 'contract_not_met')},
       'b2d_negative_r1_layout': {k: negr[k] for k in ('exit', 'ran', 'ok', 'contract_not_met')},
       'foreign_keys': sorted(foreign), 'foreign_unchanged_by_supervisor_predicate': after == foreign,
       'foreign_rows_unchanged': rows_after == rows_before, 'write_events_total': len(events),
       'write_events_in_foreign_roots': in_foreign, 'write_events_outside_q_dirs': outside}
Path(out).write_text(json.dumps(doc, indent=1), encoding='utf-8')
print(json.dumps({k: v for k, v in doc.items() if k not in ('foreign_keys',)}, indent=1)[:3000])
