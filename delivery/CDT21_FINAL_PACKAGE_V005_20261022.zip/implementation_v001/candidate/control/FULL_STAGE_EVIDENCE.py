"""Physical, immutable evidence bridging the existing stage implementations.

This module cannot approve B06 or admit an instance. Its caller must hold the
release chain and STATE boundary. Mutable STATE/checkpoint bytes are snapshotted;
later stages never retain a write-denying handle on their predecessors' STATE.
"""
from pathlib import Path
import re
import time

from D4_FIRST_ADMISSION_PREP import Reads, canonical, require, sha, strict_json, validate_journal
from FULL_RELEASE_CHAIN import REQUIRED_CHECKS


def closed_results(journal_raw, nodes, runs, read):
    validate_journal(journal_raw)
    latest = {}
    for line in journal_raw.splitlines():
        item = strict_json(line); node = item.get('node')
        if node not in nodes:
            continue
        if item.get('phase') == 'STARTED':
            run = item.get('run_id')
            require(isinstance(run, str) and re.fullmatch(r'[A-Za-z0-9_-]+', run), 'STAGE_RESULT_RUN_ID')
            latest[node] = {'run': run, 'finished': None}
        elif item.get('phase') == 'FINISHED':
            require(node in latest and latest[node]['finished'] is None, 'STAGE_UNPAIRED_FINISH:' + node)
            require(item.get('run_id', latest[node]['run']) == latest[node]['run'], 'STAGE_FINISH_RUN_MISMATCH:' + node)
            latest[node]['finished'] = item
    results, evidence = {}, []
    for node in nodes:
        attempt = latest.get(node, {})
        finish = attempt.get('finished')
        require(isinstance(finish, dict) and finish.get('status') == 'PASS', 'STAGE_UNCLOSED_OR_FAILED:' + node)
        path = Path(runs)/attempt['run']/('RESULT_' + node + '.json')
        raw = read(path, finish.get('result_sha256'))
        # The explicit comparison also protects callers with a simple fixture reader.
        require(sha(raw) == finish.get('result_sha256'), 'STAGE_RESULT_JOURNAL_HASH:' + node)
        results[node] = strict_json(raw)
        evidence.append({'path': str(path), 'sha256': sha(raw)})
    return results, evidence


# Physical semantic witness bindings for existing native stage result chain.
# These labels do NOT authorize B06/B07, and do not waive per-stage checks.
STAGE_CHECK_WITNESSES = {
    'D5': {
        'canonical_certification': 'D5', 'checkpoint_readback': 'D5',
        'journal_closed': 'D5'},
    'CANARY': {
        'readback': 'E1', 'safe_stop_resume': 'D8',
        'no_duplicate_ticks': 'D9', 'failure_recovery': 'D10',
        'source_reconciliation': 'E1', 'process_tree_cleanup': 'D11'},
    'FULL_PREP': {
        'production_certificates': 'E3', 'manifest_rederivation': 'E4',
        'live_equality': 'E5', 'admission_simulation': 'E7',
        'stage_b_evidence_pack': 'E9'},
    'FULL_ADMISSION': {
        'fresh_instance': 'G1', 'source_plan': 'F3',
        'resource_limits': 'G2', 'locks_and_leases': 'G1',
        'vss_identity': 'G1', 'root_identities': 'G1',
        'stage_b_review': 'F1', 'production_freeze': 'F2'},
}


def checks_from_closed_results(stage, nodes, results, evidence, *, read):
    """Bind each asserted check to a distinct physically read node result.

    This is only a traceable stage witness. The caller must *also* perform its
    material semantic gates (cert, STATE, journal, Stage B, resources, etc.).
    A typed digest/actual result is required; fabricated booleans cannot qualify.
    """
    require(stage in STAGE_CHECK_WITNESSES and
            set(STAGE_CHECK_WITNESSES[stage]) == set(REQUIRED_CHECKS[stage]),
            'STAGE_CHECK_BINDING_SET:' + str(stage))
    require(len(nodes) == len(evidence) and len(set(nodes)) == len(nodes),
            'STAGE_NODE_EVIDENCE_CARDINALITY')
    refs = {}
    for node, item in zip(nodes, evidence):
        require(isinstance(item, dict) and
                {'path','sha256'} <= set(item), 'STAGE_NODE_WITNESS_FIELDS')
        raw = read(item['path'], item['sha256'])
        require(sha(raw) == item['sha256'] and
                isinstance(results.get(node), dict) and
                strict_json(raw) == results[node], 'STAGE_NODE_WITNESS_MISMATCH:' + node)
        refs[node] = {'path': item['path'], 'sha256': item['sha256']}
    checks, proof_refs = {}, {}
    for check, node in STAGE_CHECK_WITNESSES[stage].items():
        require(node in refs, 'STAGE_CHECK_NODE_NOT_CLOSED:' + check + ':' + node)
        checks[check] = True
        proof_refs[check] = {'node': node, **refs[node]}
    require(set(checks) == set(REQUIRED_CHECKS[stage]) and
            set(proof_refs) == set(REQUIRED_CHECKS[stage]), 'STAGE_CHECK_WITNESS_MISSING')
    return checks, proof_refs


def publish(stage, admission, output, writer, snapshots, evidence, *, checks, check_proofs=None, extra=None):
    require(set(checks) == set(REQUIRED_CHECKS[stage]) and all(v is True for v in checks.values()),
            'STAGE_PHYSICAL_CHECKS_INCOMPLETE')
    if stage in STAGE_CHECK_WITNESSES:
        require(isinstance(check_proofs, dict) and set(check_proofs) == set(checks),
                'STAGE_CHECK_PROOF_EXACT_SET')
    else:
        # CDT21 V005 (GAP-01): exactly the stages FULL_RELEASE_CHAIN.validate_chain binds to node witnesses carry
        # them.  D4 has no orchestrator node witness: FULL_D4_CLOSURE proves its three checks physically (signed
        # checkpoint, canary scratch certificate, closed journal) before publishing; none is invented or accepted.
        require(stage == 'D4' and check_proofs is None, 'STAGE_CHECK_PROOF_EXACT_SET')
        check_proofs = {}
    for key, witness in check_proofs.items():
        require(isinstance(witness, dict) and set(witness) == {'node','path','sha256'},
                'STAGE_CHECK_PROOF_FORMAT:' + key)
        require(STAGE_CHECK_WITNESSES[stage][key] == witness['node'],
                'STAGE_CHECK_PROOF_NODE:' + key)
        require(witness['path'] and re.fullmatch(r'[0-9A-F]{64}', witness['sha256']),
                'STAGE_CHECK_PROOF_DIGEST:' + key)
    require(stage not in admission.descriptor['receipts'], 'STAGE_ALREADY_PUBLISHED')
    admission.revalidate()
    evidence = list(evidence)
    # Immutable inputs are pinned on the chain through the publication commit.
    # Mutable STATE/journal enter only through the snapshots supplied by caller.
    for item in evidence:
        admission.read(item['path'], item['sha256'])
    witness_set = {(e['path'], e['sha256']) for e in evidence}
    for name, row in check_proofs.items():
        require((row['path'], row['sha256']) in witness_set,
                'STAGE_CHECK_PROOF_NOT_EVIDENCE:' + name)
        admission.read(row['path'], row['sha256'])
    for name, raw in snapshots.items():
        require(Path(name).name == name and name not in ('.', '..'), 'STAGE_SNAPSHOT_NAME')
        path = Path(output)/name; writer(path, raw)
        admission.read(path, sha(raw))
        evidence.append({'path': str(path), 'sha256': sha(raw)})
    receipt = dict(schema='TICKSTORE_STAGE_RECEIPT_V001', stage=stage, status='PASS',
                   environment='WINDOWS_PRODUCTION',
                   code_manifest_sha256=admission.descriptor['code_manifest_sha256'],
                   instance_sha256=admission.descriptor['instance_sha256'],
                   previous_receipt_sha256=admission.receipt_sha, blockers=[], checks=checks,
                   check_proofs=check_proofs, evidence=evidence, created_unix_ns=time.time_ns())
    extra = extra or {}
    require(not set(extra) & set(receipt), 'STAGE_RESERVED_FIELD')
    receipt.update(extra)
    receipt_path = Path(output)/('STAGE_' + stage + '.json')
    admission.revalidate()
    raw = canonical(receipt); writer(receipt_path, raw)
    admission.read(receipt_path, sha(raw))
    descriptor = dict(admission.descriptor, receipts=dict(admission.descriptor['receipts']))
    require(stage not in descriptor['receipts'], 'STAGE_ALREADY_PUBLISHED')
    descriptor['receipts'][stage] = {'path': str(receipt_path), 'sha256': sha(raw)}
    admission.revalidate()
    path = Path(output)/'EXECUTION_CHAIN.json'; raw = canonical(descriptor); writer(path, raw)
    admission.read(path, sha(raw)); admission.revalidate()
    print('NEXT_CHAIN_FILE=' + str(path) + '\nNEXT_CHAIN_SHA256=' + sha(raw), flush=True)
    return path, sha(raw)
