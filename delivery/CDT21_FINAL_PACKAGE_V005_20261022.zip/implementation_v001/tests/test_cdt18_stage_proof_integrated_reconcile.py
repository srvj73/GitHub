"""CDT18 integration anti-false-pass deltas: physical witnesses and G5 gates.
These tests never issue a production release or a B06 verdict.
"""
import hashlib,json,pathlib,sys,tempfile,unittest
R=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'candidate/control'))
from D4_FIRST_ADMISSION_PREP import canonical,sha,Blocked
from FULL_STAGE_EVIDENCE import checks_from_closed_results, STAGE_CHECK_WITNESSES
from FULL_RELEASE_CHAIN import REQUIRED_CHECKS,validate_chain
from G5_FINAL_COMPLETENESS_PRODUCER import verified_native

class Witness(unittest.TestCase):
    def test_01_all_stage_check_contracts_exhaustive(self):
        for stage in STAGE_CHECK_WITNESSES:
            self.assertEqual(set(STAGE_CHECK_WITNESSES[stage]),set(REQUIRED_CHECKS[stage]))
    def test_02_real_hash_bound_result_referenced_for_every_check(self):
        with tempfile.TemporaryDirectory() as d:
            base=pathlib.Path(d); stage='FULL_PREP';nodes=list(dict.fromkeys(STAGE_CHECK_WITNESSES[stage].values()))
            results={};evidence=[]
            for n in nodes:
                obj={'schema':'TEST_RESULT','node':n,'status':'PASS','observed':True}
                p=base/(n+'.json');p.write_bytes(canonical(obj));results[n]=obj
                evidence.append({'path':str(p),'sha256':sha(p.read_bytes())})
            def pinned(path,expected):
                raw=pathlib.Path(path).read_bytes()
                if sha(raw)!=expected:raise Blocked('MISMATCH')
                return raw
            checks,proofs=checks_from_closed_results(stage,nodes,results,evidence,read=pinned)
            self.assertTrue(all(checks.values()))
            self.assertEqual(len(proofs),len(REQUIRED_CHECKS[stage]))
            self.assertTrue(all(proofs[c]['sha256'] in {e['sha256'] for e in evidence} for c in proofs))
    def test_03_missing_node_evidence_blocks(self):
        with self.assertRaisesRegex(RuntimeError,'STAGE_CHECK_NODE_NOT_CLOSED|STAGE_NODE_EVIDENCE_CARDINALITY'):
            checks_from_closed_results('D5',[],{},[],read=lambda p,h:b'')
    def test_04_corrupted_witness_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'D5.json';p.write_bytes(canonical({'node':'D5'}))
            with self.assertRaisesRegex(RuntimeError,'STAGE_NODE_WITNESS_MISMATCH'):
                checks_from_closed_results('D5',['D5'],{'node':'D5'},
                    [{'path':str(p),'sha256':sha(p.read_bytes())}],read=lambda p,h:pathlib.Path(p).read_bytes())
    def test_05_stage_without_semantic_proofs_cannot_admit(self):
        stages=('G5','B06','B07','D4','D5')
        rows={}; hashes={};prev=None
        for stage in stages:
            ob={'schema':'TICKSTORE_STAGE_RECEIPT_V001','stage':stage,'status':'PASS',
               'environment':'WINDOWS_PRODUCTION','code_manifest_sha256':'A'*64,
               'instance_sha256':'B'*64,'previous_receipt_sha256':prev,'blockers':[],
               'checks':{k:True for k in REQUIRED_CHECKS[stage]},
               'evidence':[{'path':'x','sha256':'E'*64}]}
            if stage=='G5':ob['full_candidate_completeness']='PASS'
            if stage=='B06':ob.update(reviewer='independent',implementation_participant=False)
            rows[stage]=ob;hashes[stage]='C'*64;prev='C'*64
        with self.assertRaisesRegex(RuntimeError,'D5_CHECK_PROOF_SET'):
            validate_chain(rows,hashes,code_sha='A'*64,instance_sha='B'*64,b06_sha='C'*64,until='D5')


    # CDT21 V005 (GAP-01): the D4 stage receipt is publishable, carries no node witness, and the chain admits it.
    def _d4_fixture(self, d):
        base = pathlib.Path(d); out = base / 'out'; out.mkdir()
        evidence = []
        for name in ('CHECKPOINT.json', 'SCRATCH_CERT.json', 'RUN_AUTHORITY.json'):
            p = base / name; p.write_bytes(canonical({'fixture': name})); evidence.append({'path': str(p), 'sha256': sha(p.read_bytes())})
        def read(path, expected):
            raw = pathlib.Path(path).read_bytes()
            if sha(raw) != expected: raise Blocked('MISMATCH')
            return raw
        def writer(path, raw):
            with open(path, 'xb') as f: f.write(raw); f.flush()
        from types import SimpleNamespace
        admission = SimpleNamespace(descriptor={'code_manifest_sha256': 'A' * 64, 'instance_sha256': 'B' * 64,
                                                'receipts': {s: {'path': s, 'sha256': 'C' * 64} for s in ('G5', 'B06', 'B07')}},
                                    receipt_sha='C' * 64, read=read, revalidate=lambda: None)
        return out, evidence, admission, writer

    def test_06_d4_receipt_publishes_without_node_witness_and_chain_admits_it(self):
        from FULL_STAGE_EVIDENCE import publish
        with tempfile.TemporaryDirectory() as d:
            out, evidence, admission, writer = self._d4_fixture(d)
            chain_path, chain_sha = publish('D4', admission, out, writer, {'STATE_AFTER.json': b'{}\n'}, evidence,
                                            checks={k: True for k in REQUIRED_CHECKS['D4']}, extra={'state_after_sha256': sha(b'{}\n')})
            raw = (out / 'STAGE_D4.json').read_bytes(); receipt = json.loads(raw)
            self.assertEqual(receipt['check_proofs'], {})
            self.assertEqual(json.loads(chain_path.read_bytes())['receipts']['D4']['sha256'], sha(raw))
            rows, hashes, prev = {}, {}, None
            for stage in ('G5', 'B06', 'B07'):
                ob = {'schema': 'TICKSTORE_STAGE_RECEIPT_V001', 'stage': stage, 'status': 'PASS', 'environment': 'WINDOWS_PRODUCTION',
                      'code_manifest_sha256': 'A' * 64, 'instance_sha256': 'B' * 64, 'previous_receipt_sha256': prev, 'blockers': [],
                      'checks': {k: True for k in REQUIRED_CHECKS[stage]}, 'evidence': [{'path': 'x', 'sha256': 'E' * 64}]}
                if stage == 'G5': ob['full_candidate_completeness'] = 'PASS'
                if stage == 'B06': ob.update(reviewer='independent', implementation_participant=False)
                rows[stage] = ob; hashes[stage] = 'C' * 64; prev = 'C' * 64
            rows['D4'] = receipt; hashes['D4'] = sha(raw)
            self.assertEqual(validate_chain(rows, hashes, code_sha='A' * 64, instance_sha='B' * 64, b06_sha='C' * 64, until='D4'), sha(raw))

    def test_07_d4_refuses_invented_witnesses_and_d5_still_requires_them(self):
        from FULL_STAGE_EVIDENCE import publish
        with tempfile.TemporaryDirectory() as d:
            out, evidence, admission, writer = self._d4_fixture(d)
            invented = {k: {'node': 'D4', 'path': evidence[0]['path'], 'sha256': evidence[0]['sha256']} for k in REQUIRED_CHECKS['D4']}
            with self.assertRaisesRegex(RuntimeError, 'STAGE_CHECK_PROOF_EXACT_SET'):
                publish('D4', admission, out, writer, {}, evidence, checks={k: True for k in REQUIRED_CHECKS['D4']}, check_proofs=invented)
            with self.assertRaisesRegex(RuntimeError, 'STAGE_CHECK_PROOF_EXACT_SET'):
                publish('D5', admission, out, writer, {}, evidence, checks={k: True for k in REQUIRED_CHECKS['D5']})
            self.assertEqual(list(out.iterdir()), [])

if __name__=='__main__':unittest.main(verbosity=2)
