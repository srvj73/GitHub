# TICKSTORE CDT15 — Retorno do engenheiro (Opus 5.5) à origem: R43 / B1

Papel: ENGINEER_ONLY. Não é B06, B07, G5 PASS nem autorização de produção.
`G4=INCOMPLETE; G5=NOT_PROVEN; B06=NOT_STARTED; B07=NOT_STARTED; FULL_STARTED=NO; PRODUCTION_MODIFIED=NO`

## 1. Árvores-fonte testadas (para conferência byte a byte com os recibos)
`FINAL_PACKAGES/` contém os pacotes FINAL exatos (reconstruídos de forma determinística a partir dos commits), cada um com sua testemunha:

| Revisão | Pacote FINAL SHA-256 | Recibo nativo que o testou |
|---|---|---|
| R41 (R41R3) | `14C9A90BA2EE0CB86AC09E5FDFFE72AB0EE15C9FB5E90829375A86E139F4A4C4` | R41 RETURN `EDBA8882…7915` |
| R42 | `46B446A61EB4D2BF20A0686F60DE6B60189091245956F4C80C80E9C23065C861` | R42 RETURN `8EDDE588…FEEF` |
| R43 | `2D332928BFE7E907DB85252F6A40558549DDA2D379E3F95D8A70E27FB276ABCF` | R43 RETURN `6B7DA7E2…D38C` (incluído em `RETURNS/`) |

Cada ZIP contém `PACKAGE_MANIFEST.json` (lista fechada com bytes/SHA de cada membro) e `implementation_v001/` com a árvore completa (`candidate/`, testes, `RUNTIME_CODE_MANIFEST.json`, `SOURCE_MANIFEST.json`).

**Defeito de processo declarado (R42):** o commit `abda066` difere dos bytes testados em um único arquivo de documentação (`R41_BLOCKER_LEDGER.json`), atualizado depois do build. O pacote acima é o byte-exato testado (= `abda066` com o registro na versão `727a675`); hipótese verificada por reconstrução. Correção: o registro saiu da árvore empacotada (agora `BLOCKER_LEDGER.json` fora de `source/`).

## 2. B1A — bytes concretos da fixture autorizada
`B1A/`: pai R3 `tests_full_lifecycle.R3_PARENT.py` SHA `EE30AA9325EE79A1F5FF4876DF72EC0A596AC351E9708447337841E9B43E592D`; derivado `tests_full_lifecycle.py` SHA `29981D1535AC295D6465E2734234DF834B31B58CD4A03F2414D6CFE43A2D0286`; patch `R43_B1A_tests_full_lifecycle.patch` SHA `3F9074926021F219BE459D3DB9C9B65145FFC64BBDE6D39252BB324D87943E1C`.
Escopo: 2 trechos — dados de fixture (rec/h2 com 1550 / 7049522162 / 3101, schema do verificador independente, manifest idêntico) e o estímulo de `test_h2_counts_mismatch_blocks_h3` (`reconciliation.rows = certificado − 1`). Nenhuma asserção, nome, ID ou mensagem alterados. Microprobes (a)–(e): **PASS 5/5 nativo** no R43.

## 3. Resultado nativo R43 (126 IDs sobre os bytes atuais)
**122/126 PASS**, `tested_code_unchanged=true`. Não-PASS:
- **R43-B1B (falha prevista, confirmada):** `tests_delta.InstallerAndLauncherTests.test_native_ps51_extract_readback_and_collision_preserved` e `...test_file_hash_mismatch_preserves_partial_no_deployment` — o instalador exige `MENU.py` no manifesto desde R40 (`INSTALL_INTENT_MENU_MANIFEST_CARDINALITY`); a fixture R3 empacota só o lançador.
- **R43-E1 (ambiental):** `test_first_admission_transaction...test_reparse_resume_root_rejected` e `tests_native_delta...test_heartbeat_reparse_destination_cannot_modify_target` — `WinError 1314` ao criar o link simbólico da fixture (PowerShell não elevado). O código testado não foi exercitado; o V38 histórico registrou `ok`. Remédio: próxima execução elevada; sem alteração de código/teste.

## 4. Decisão solicitada: R43-B1B
`B1B_PROPOSAL/`: pai `tests_delta.R3_PARENT.py` SHA `67B41A04787A2BEB3CB1CA7AE1CF79286E034F81B50ADEAC4C536956972FAD1D`; derivado proposto SHA `2E95CADE28AA14A51D9DD30ECD78C045D717906AAE6AD6E2091C188ADC985089`; patch SHA `84E32FA3BA669288D16B7FF9C833A9E4A01C2D53758BD9DCDB79775FCCDAFA48`.
Escopo: somente `InstallerAndLauncherTests.package()` — adiciona o membro `implementation_v001/candidate/menu/MENU.py` (payload, registro no manifesto e entrada no ZIP). CRLF preservado; nenhuma asserção/ID/estímulo alterado; produto intocado. Os testes de path-escape e hash do ZIP continuam bloqueando antes da checagem do MENU. **Não aplicado.**

Se autorizado: R44 executa os 126 IDs (com B1A + B1B) elevado no Windows do titular; resultado esperado 126/126.

## 5. Outros fatos desde a R42
- R43-F2: regressão do engenheiro (R41) no AUTOCPU corrigida (`min(os.cpu_count, process_cpu_count)`); `test_auto_cpu_zero_one_n_and_invalid_request` PASS nativo no R43.
- R42-F1: correção de produto em `_finalize_coordinator_resources` (publisher `None`), com teste de regressão.

`RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 15`
