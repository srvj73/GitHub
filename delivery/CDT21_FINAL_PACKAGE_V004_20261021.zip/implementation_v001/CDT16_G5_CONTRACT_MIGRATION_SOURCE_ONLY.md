# TICKSTORE CDT16 G5 — proposta de migração do contrato (SOURCE_ONLY)

STATUS=PENDING_RELEASE_AUTHORITY; G5_PASS=NO; B06=NOT_STARTED; FULL_STARTED=NO.

Parente imutável: FULL C3 SHA256 431B5E4EC2011C192D28EB17D9848A42CB467F3124A6FBE644D3611195C77554.

A mudança mantém seis recibos distintos tipados e requer POWERLOSS_EMULATED no lugar da exigência
CHECKPOINT_POWERLOSS_RECOVERY. O recibo de morte de processo preserva status EMULATED_PASS,
counts_as NOT_CHECKPOINT_POWERLOSS_RECOVERY e a observação not_physical_power_loss=true.
Rejeita provas ausentes, adulteradas, sem ligação hash à execução, reutilizadas, com status indevido,
ou que não demonstrem recuperação idêntica à referência.

Esta mudança altera o código hash-bound; o RETURN G4 anterior permanece histórico válido para
seus bytes originais, NÃO qualifica por si a nova identidade. Não reiniciar produtivo.
A origem deve promover a decisão normativa e qualificar delta no Windows em ambiente isolado.
FULL tem gates posteriores independentes, incluindo B06/B07, D4/D5, canário, FULL admission.
