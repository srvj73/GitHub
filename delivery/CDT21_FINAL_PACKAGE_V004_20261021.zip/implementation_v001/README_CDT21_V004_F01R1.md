# CDT21 V004 — F-01R1: corte do legado já inicializado

**Parent congelado:** V003 `69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50`. Preservado; os bytes do V003 não foram alterados.

**Achado:** B06 do V003, reproduzido pela origem sobre os bytes congelados. `LEGACY_ENTRY_FENCE --apply` retornava `FENCE_PRESENT` enquanto um processo legado, que construíra `State` antes da cerca, seguia acrescentando ao `STATE_JOURNAL.jsonl`.

**Causa:** o `State.log` congelado abre o journal em `"ab"` pelo nome a cada chamada e não mantém handle, lock nem mutex entre as escritas. A cerca do V003 (diretório `STATE.json.partial`) nega apenas a construção seguinte de `State`. O mutex do instalador só é tomado pelos consumidores admitidos.

## Correção (sem tocar o código legado congelado)

1. **Corte do journal pelo nome.** ACE explícita de negação para Todos (`FILE_WRITE_DATA|FILE_APPEND_DATA`), verificada pelo kernel a cada abertura. O `open("ab")` congelado falha para qualquer processo, iniciado antes ou depois.
2. **Instante do corte provado.** O journal é aberto sem compartilhamento de escrita, o que prova que nenhum handle de escrita anterior à ACE sobrevive. Os bytes do journal nesse instante são registrados em `LEGACY_JOURNAL_CUT.json`. Isso elimina a janela TOCTOU: a prova vem depois do fechamento, não antes.
3. **Drenagem sem censo de processos.** O `execute()` congelado registra `STARTED(run_id=<carimbo>_<pid>)` antes de qualquer efeito de nó. Por isso, o journal do corte nomeia toda execução legada que pode estar dentro de um nó.
   - `FENCE_PRESENT` exige que cada uma dessas identidades de processo tenha deixado de existir.
   - Senão, a decisão é `CUT_PRESENT_LEGACY_RUN_NOT_DRAINED` e a admissão é recusada.
4. **Escritor admitido.** A entrada D4 e a continuação FULL, ambas elevadas, acrescentam a mesma linha congelada com backup semantics.
   - `SeRestorePrivilege` fica habilitado só no token da thread, só para essa abertura.
   - Admissão, cada commit de STATE e cada append exigem o corte completo e drenado.

## Arquivos

| Tipo | Arquivos |
|---|---|
| Alterados | `candidate/adapter/runtime_locator_orchestrator_entry.py`, `candidate/control/LEGACY_ENTRY_FENCE.py`, pins (`RUNTIME_LOCATOR_ADAPTER_BINDING.json`, `FIRST_ADMISSION_BINDING.json`, `PRE_G06_CONSUMER_REVIEW.json`), `tests/test_cdt21_f01_legacy_entry_fence.py`, `procedures/PROCEDIMENTO_CDT21_LEGACY_ENTRY_FENCE.md` |
| Novos | `tests/test_cdt21_f01r1_preexisting_legacy_cut.py`, `qual/CDT21_F01R1_G0_QUALIFICATION.py`, `qual/CDT21_F01R1_MUTATION_CONTROLS.py`, `qual/CDT21_F01R1_ORIGIN_SCENARIO.py` |

Recibos: `CDT21_V004_DELTA_RECEIPT.json`, `CDT21_F01R1_DELTA.patch`, `CDT21_V004_ENGINEERING_COMPLETENESS.json`.

## Não alegado

- PASS nativo Windows antes do retorno da qualificação.
- G5 de 38 unidades para o V004. A evidência G5 prova os bytes do V003; o contrato G5 congelado vincula o manifesto de código inteiro.
- B06, B07, D4/D5, canário e FULL.
- Corte instalado em produção.
- Queda física de energia.
