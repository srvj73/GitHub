# TICKSTORE CDT21 — candidato sucessor V003 (fechamento F-01 / F-04)

Parent imutável: `FINAL_PACKAGE_V002.zip`, SHA-256 `4942871541629C3B38F47EDA55EA2C9E310361533887CB55E577D9641542E7C5`.
A aprovação G5 formal do titular vincula **somente** os bytes V002. Este sucessor exige nova decisão de origem.

## F-01 — entrada legada `recovery/TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1`

Diagnóstico confirmado sobre os bytes congelados:

- O PS1 legado (SHA `18900BCC…`) executa `python -I -S -B modules/orchestrator.py <comando> --package <raiz>`.
- O orquestrador congelado (SHA `3C16FC13…`) constrói `State(control_root)` antes de qualquer outra coisa. Na construção, sempre publica STATE via `atom()`, que abre `STATE.json.partial` para escrita e faz `os.replace`. Disso resultam três efeitos:
  - cria STATE em `A0/NEW` quando ausente;
  - regrava STATE quando presente;
  - reinicia o estado com o journal órfão.
- `O.gate()` emite `OWNER_GATE` com `authorized: True` por conta própria.
- Qualquer cópia implantada, e também `python orchestrator.py` direto, segue a mesma rota.

Correção mínima, sem alterar nenhum byte do pacote sucessor congelado (motor, orquestrador, launchers, config, manifestos R24):

1. **Cerca de entrada legada** (`control/LEGACY_ENTRY_FENCE.py`, novo).
   - Cria o diretório `state/STATE.json.partial`, contendo o marcador `LEGACY_ENTRY_FENCE.json`.
   - A primeira escrita do `State` congelado falha (`open(..., "wb")` sobre diretório) antes de qualquer alteração em STATE, journal, inbox ou runs.
   - Isso vale para todos os comandos (`plan`, `status`, `stop`, `run`, `resume`, `reconcile`, `confirm-stale-lock`, `ingest-stage-b`, `postfull`, `attach`), para qualquer cópia do launcher e para `python orchestrator.py` direto.
   - A ferramenta funciona em modo diagnóstico por padrão. `--apply` instala a cerca sob a mesma fronteira de processo da entrada D4, re-diagnostica e nunca apaga nada. Bloqueia (`BLOCKED_MANUAL`) quando encontra detrito `.partial` de escrita interrompida, link/reparse ou marcador inválido.
2. **Integração na cadeia oficial** (`adapter/runtime_locator_orchestrator_entry.py`).
   - `validate_d4_start` (primeira admissão e entrada D4) exige a cerca.
   - `guard_frozen_state_reads` com `AdmittedStart` (entrada D4 e `FULL_STAGE_CONTINUATION`) exige a cerca.
   - Todo commit CAS admitido de STATE também exige a cerca.
   - Os commits CAS admitidos nunca usam o nome `.partial`, por isso a cerca é transparente para eles.

## F-04 — `recovery/modules/Launch-TickstoreBundle.ps1`

O launcher congelado calcula `Get-FileHash` do loader e depois relê o arquivo com `ReadAllBytes`. Esse launcher integra a rota oficial pós-D4 (fallback de `adapted_launch` para bundles fora da geração-alvo).

Em `adapter/runtime_locator_adapter.py`, o fallback agora:

- abre o launcher e o loader congelados;
- verifica o SHA a partir dos handles abertos (`56B7F4FD…`, `74FE55D8…`);
- mantém esses handles abertos, sem compartilhamento de escrita ou exclusão no Windows, até o processo filho terminar.

Os bytes que o launcher hasheia e executa são, portanto, os bytes verificados. Adulteração bloqueia antes do lançamento (`ADAPTER_FROZEN_LAUNCH_SOURCE_SHA`).

## Pins e declarações atualizados

- `adapter/RUNTIME_LOCATOR_ADAPTER_BINDING.json`: `adapter_sha256` e `orchestrator_entry_sha256`.
- `control/FIRST_ADMISSION_BINDING.json`: `adapter_sha256` e `runtime_binding_sha256`. O SHA deste arquivo continua sendo fornecido externamente ao bootstrap.
- `g5proof/PRE_G06_CONSUMER_REVIEW.json`: fontes dos 2 consumidores alterados e declaração verdadeira para `orchestrator.py`. A afirmação anterior "no production execute/main invocation" foi retirada, porque o código físico a contradizia.
- `RUNTIME_CODE_MANIFEST.json`, `SOURCE_MANIFEST.json` e `PACKAGE_MANIFEST.json` foram regenerados.
- Não alterados, por decisão:
  - pacote sucessor R24 e configuração selada, que dependem do ZIP R24 e do review pack externos;
  - `QUALIFICATION_CONTRACT.json` e B07, cujo escopo é de decisão de origem;
  - `FULL_STAGE_CONTINUATION.py`, já que o enforcement ocorre no guard;
  - `README_FIRST.txt` histórico.

## Qualificação

- **Linux, CPython 3.14.6:**
  - a nova suíte `tests/test_cdt21_f01_legacy_entry_fence.py` executa os bytes congelados reais e inclui um controle que reproduz o defeito V002 sem a cerca;
  - as suítes afetadas foram requalificadas;
  - a varredura dos 75 arquivos de teste apresenta resultados idênticos aos da linha de base V002, salvo o guarda de conjunto fechado, que só passa após a regeneração dos manifestos.
- **Windows nativo:** `TARGET_RUNTIME_PENDING`. O runner G0 executa, em raiz própria da execução, as unidades afetadas e os 11 consumidores, por meio de `qual/CDT21_F01_G0_QUALIFICATION.py`.
- **Recibo de cinco partes do produtor G5 para o V003:** não emitido. Ele exige retorno nativo da campanha completa sob o novo manifesto de código; a autorização cabe à origem.

## Passo operacional (não executado; requer autorização da origem)

Antes de qualquer D4 ou continuação oficial, a cerca deve existir no `control_root` produtivo. Ver `procedures/PROCEDIMENTO_CDT21_LEGACY_ENTRY_FENCE.md`.

`B06=NOT_STARTED`; B07, D4/D5, canário e FULL: não executados.
