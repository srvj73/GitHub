"""Scoped SOURCE_ONLY qualification: no FULL, B06, G5 issuance or production effects."""
from pathlib import Path
import sys,os,hashlib,json,subprocess,re,zipfile,argparse
ROOT=Path(__file__).resolve().parent
SHA=lambda raw:hashlib.sha256(raw).hexdigest().upper()
EXPECTED_RUNTIME_MANIFEST_SHA='0C419C01AE6480542F3696329866BEA3FF400669756478200CDF6609E154067B'
EXPECTED_TEST_COUNT=29
EXPECTED_REFERENCE_SHA='3C5A99EF3F3714FDEF4DC1B8FD264736DE3E63122B0016F68827FAC6E8DA6D49'
EXPECTED_LEGACY_SHA='2CA9DF4D851C1F9991E299A49D527E95E765B4852F75CE4F53C033D08D8E2158'
def assert_gate(cond,cause):
 if not cond:raise ValueError(cause)
def verify():
 obj=json.loads((ROOT/'SOURCE_MANIFEST.json').read_bytes())
 exp={row['path']:row for row in obj['files']}
 files={str(f.relative_to(ROOT)).replace('\\','/'):f for f in ROOT.rglob('*') if f.is_file()}
 files.pop('SOURCE_MANIFEST.json',None)
 assert_gate(len(exp)==obj['file_count'] and set(exp)==set(files),'SOURCE_MANIFEST_EXACT_SET')
 for name,f in files.items():
  b=f.read_bytes(); row=exp[name]
  assert_gate(row['bytes']==len(b) and row['sha256']==SHA(b),'SOURCE_SHA:'+name)
 assert_gate(SHA((ROOT/'RUNTIME_CODE_MANIFEST.json').read_bytes())==EXPECTED_RUNTIME_MANIFEST_SHA,'RUNTIME_MANIFEST_SHA')
 rows=json.loads((ROOT/'RUNTIME_CODE_MANIFEST.json').read_bytes())['files']
 names=[r['path'] for r in rows]
 assert_gate(len(names)==len(set(names)),'RUNTIME_DUPLICATE')
 real={p.relative_to(ROOT/'candidate').as_posix():p for p in (ROOT/'candidate').rglob('*') if p.is_file()}
 assert_gate(set(names)==set(real),'RUNTIME_MANIFEST_EXACT_SET')
 for r in rows:
  b=real[r['path']].read_bytes()
  assert_gate(len(b)==r['bytes'] and SHA(b)==r['sha256'],'RUNTIME_CODE_SHA:'+r['path'])
 assert_gate(SHA((ROOT/'tests/fixtures/CDT17_G5_OWNER_R2_SCOPED_IMMUTABLE_REFERENCE.zip').read_bytes())==EXPECTED_REFERENCE_SHA,'R2_FIXTURE_IDENTITY')
 assert_gate(SHA((ROOT/'tests/legacy/test_b2d_origin_decision_binder_R45_SUPERSEDED.py.txt').read_bytes())==EXPECTED_LEGACY_SHA,'LEGACY_ORIGINAL_IMMUTABLE')
 return len(files),len(real)
def run(out):
 out.mkdir(parents=True,exist_ok=False)
 receipt={'schema':'CDT17_CURRENT_G5_COMPATIBILITY_QUAL_V001','mission':'SOURCE_ONLY_TARGETED_CURRENT_G5_TESTS',
    'project':'Base de Dados CSV / Tickstore','thread':'Compressão de Ticks 17',
    'runtime_code_manifest_sha256':EXPECTED_RUNTIME_MANIFEST_SHA,'full_started':False,'b06':'NOT_STARTED',
    'g5_new_final_owner_decision_issued':False,'production_modified':False}
 rc=2
 try:
  a,b=verify();receipt.update({'source_files_verified':a,'runtime_code_members_unchanged_verified':b,'integrity':'PASS'})
  env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
  test=ROOT/'tests/test_b2d_origin_decision_binder.py'
  proc=subprocess.run([sys.executable,'-B','-I',str(test),'-v'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                      env=env,timeout=240,check=False)
  (out/'TEST_STDOUT.txt').write_bytes(proc.stdout)
  (out/'TEST_STDERR.txt').write_bytes(proc.stderr)
  err=proc.stderr.decode('utf-8',errors='replace')
  counts=re.findall(r'Ran (\d+) tests? in ',err)
  test_count=int(counts[-1]) if len(counts)==1 else -1
  ok=proc.returncode==0 and test_count==EXPECTED_TEST_COUNT and err.rstrip().endswith('OK')
  receipt.update({'test_exit':proc.returncode,'test_count':test_count,'test_result':'PASS_SCOPED' if ok else 'FAIL',
    'stderr_sha256':SHA(proc.stderr),'stdout_sha256':SHA(proc.stdout),
    'G5_OWNER_SCOPE':'PASS_PRIOR_UNCHANGED_CODE_ONLY',
    'G5_FINAL_COMPOSITE_BINDING':'NOT_PROVEN', 'FULL_CANDIDATE_COMPLETENESS':'NOT_PROVEN',
    'FORMAL_AUDIT_DISPATCH':'BLOCKED_INCOMPLETE_CANDIDATE'})
  rc=0 if ok else 2
 except Exception as e:
  receipt['blocker']=type(e).__name__+':'+str(e)
  receipt['test_result']='BLOCKED'
  rc=2
 (out/'RESULT.json').write_bytes((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False)+'\n').encode('utf-8'))
 entries=[]
 for f in sorted(out.iterdir()):
  if f.is_file():entries.append({'path':f.name,'bytes':f.stat().st_size,'sha256':SHA(f.read_bytes())})
 man={'schema':'CDT17_CURRENT_G5_RETURN_MANIFEST_V001','files':entries}
 (out/'RETURN_MANIFEST.json').write_bytes((json.dumps(man,sort_keys=True,indent=2)+'\n').encode())
 archive=out.parent/'CORRECTIVE_DELTA_RETURN.zip'
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for f in sorted(out.iterdir()):z.write(f,f.name)
 print('DELTA_QUAL='+receipt['test_result']+' TEST_COUNT='+str(receipt.get('test_count','UNKNOWN'))+
       ' RUNTIME_CODE_CHANGED=NO FULL_STARTED=NO B06=NOT_STARTED')
 print('RETURN_ZIP='+str(archive))
 print('RETURN_SHA256='+SHA(archive.read_bytes()))
 return rc
if __name__=='__main__':
 parser=argparse.ArgumentParser(allow_abbrev=False);parser.add_argument('--out',required=True)
 args=parser.parse_args();sys.exit(run(Path(args.out)))
