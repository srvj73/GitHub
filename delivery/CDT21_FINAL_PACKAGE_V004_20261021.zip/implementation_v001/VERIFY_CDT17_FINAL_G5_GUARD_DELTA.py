"""SOURCE_ONLY scoped G5 false-completeness guard qualifier. No B06, D4, production.
The codebase is a source candidate, not executable delivery ready.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import os
import pathlib
import sys
import unittest
import zipfile
import traceback

ROOT=pathlib.Path(__file__).resolve().parent
H=lambda data: hashlib.sha256(data).hexdigest().upper()
CODE_SHA='921FEB2834A67CBD1D7E4112D601324A99628EF11DBCF027C569CAF3492E0C8E'
ARCHIVES={
 'WIN_G5_CURRENT_29_RETURN.zip':'115BDB6239FA45FBC773B9D58B87513E6074953C02671ADEC5EC1D868CB59036',
 'WIN_CRITICAL_9_RETURN.zip':'C2B87023D111CBBCF4D367BC6AA12E4799633E73747031DB50D6F5C3C487EB35',
 'WIN_FULL_FUSION_R0_RETURN.zip':'6843AA054D50E2631A4D3334F1F7178C70714822B047E4918EBDF8C0750F3098',
}
TEST_MODULES=('tests.test_cdt17_full_composition_scope',
              'tests.test_cdt17_final_g5_complete_proof_gate',
              'tests.test_gate_chain_procedures')
EXPECTED_TESTS=36

def require(x,reason):
    if not x:raise ValueError(reason)

def check():
    src=json.loads((ROOT/'SOURCE_MANIFEST.json').read_bytes())
    listed={v['path']:v for v in src['files']}
    actual={p.relative_to(ROOT).as_posix():p for p in ROOT.rglob('*') if p.is_file()}
    actual.pop('SOURCE_MANIFEST.json',None)
    require(len(actual)==src['file_count'] and set(actual)==set(listed),'SOURCE_EXACT_SET')
    for n,p in actual.items():
        raw=p.read_bytes();v=listed[n]
        require(len(raw)==v['bytes'] and H(raw)==v['sha256'],'SOURCE_IDENTITY:'+n)
    code=(ROOT/'RUNTIME_CODE_MANIFEST.json').read_bytes()
    require(H(code)==CODE_SHA,'RUNTIME_MANIFEST_HASH')
    entries=json.loads(code)['files'];actual_code={p.relative_to(ROOT/'candidate').as_posix():p for p in (ROOT/'candidate').rglob('*') if p.is_file()}
    require(len(entries)==147 and {v['path'] for v in entries}==set(actual_code),'RUNTIME_CODE_SET')
    for v in entries:
        raw=actual_code[v['path']].read_bytes()
        require(H(raw)==v['sha256'] and len(raw)==v['bytes'],'RUNTIME_CODE_SHA:'+v['path'])
    for fn,d in ARCHIVES.items():
        data=(ROOT/'NATIVE_EVIDENCE_IMMUTABLE'/fn).read_bytes()
        require(H(data)==d,'NATIVE_RETURN_SHA:'+fn)
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            require(z.testzip() is None,'NATIVE_RETURN_CRC:'+fn)
    return len(actual),len(actual_code)

def write_new(path,body):
    with pathlib.Path(path).open('xb') as fh:fh.write(body);fh.flush();os.fsync(fh.fileno())

def run(out):
    out=pathlib.Path(out);out.mkdir(parents=True,exist_ok=False)
    rc=2
    result={'schema':'TICKSTORE_CDT17_FINAL_G5_GUARD_DELTA_QUAL_V001',
       'project':'Base de Dados CSV / Tickstore','thread':'Compressão de Ticks 17',
       'source_only':True,'runtime_code_manifest_sha256':CODE_SHA,
       'full_candidate_completeness':'NOT_PROVEN','formal_audit_dispatch':'BLOCKED_INCOMPLETE_CANDIDATE',
       'production_modified':False,'full_started':False,'b06':'NOT_STARTED',
       'G5_PRIOR_OWNER_BINDING':'SCOPED_PRIOR_HASH_ONLY'}
    try:
        sources,codes=check()
        result['source_count']=sources;result['runtime_members_count']=codes
        sys.path.insert(0,str(ROOT))
        test=unittest.defaultTestLoader.loadTestsFromNames(TEST_MODULES)
        stream=io.StringIO()
        run=unittest.TextTestRunner(stream=stream,verbosity=2).run(test)
        log=stream.getvalue().encode('utf-8')
        write_new(out/'TESTS_LOG.txt',log)
        ok=run.wasSuccessful() and run.testsRun==EXPECTED_TESTS
        result.update({'test_count':run.testsRun,'errors':len(run.errors),'failures':len(run.failures),
         'test_log_sha256':H(log),'status':'PASS_SCOPED_SOURCE_ONLY' if ok else 'FAIL_TESTS',
         'target_os_name':os.name,'new_candidate_code_win_tested':'NO_UNLESS_TARGET_REPORT'});
        rc=0 if ok else 2
    except BaseException as exc:
        result['status']='BLOCKED';result['cause']=type(exc).__name__+':'+str(exc)
        write_new(out/'ERROR_TRACE.txt',traceback.format_exc().encode())
    write_new(out/'RESULT.json',(json.dumps(result,indent=2,sort_keys=True,ensure_ascii=False)+'\n').encode())
    rows=[{'path':p.name,'bytes':len(p.read_bytes()),'sha256':H(p.read_bytes())} for p in sorted(out.iterdir()) if p.is_file()]
    write_new(out/'RETURN_MANIFEST.json',(json.dumps({'schema':'TICKSTORE_CDT17_FINAL_G5_GUARD_RETURN_MANIFEST_V001','files':rows},indent=2,sort_keys=True)+'\n').encode())
    dest=out.parent/'FINAL_G5_GUARD_DELTA_RETURN.zip'
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.iterdir()):z.write(p,p.name)
    print('G5_FINAL_GUARD_QUAL='+result['status']+' TEST_COUNT='+str(result.get('test_count','UNKNOWN')))
    print('FINAL_G5_BINDING=NOT_PROVEN CANDIDATE_COMPLETENESS=NOT_PROVEN')
    print('RETURN_ZIP='+str(dest));print('RETURN_SHA256='+H(dest.read_bytes()))
    return rc

if __name__=='__main__':
    ap=argparse.ArgumentParser(allow_abbrev=False);ap.add_argument('--out',required=True);a=ap.parse_args()
    raise SystemExit(run(a.out))
