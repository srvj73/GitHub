"""CDT21 F-01R1 (V004) - negative controls by mutation: every protection of the cut must be load-bearing.

A mirror of candidate/ and tests/ is made under --work (owned directory, created here).  For each
mutation one protection is removed by an exact, single-occurrence source replacement; the named tests
of test_cdt21_f01r1_preexisting_legacy_cut.py must then FAIL, and the unmutated mirror must PASS them
first.  M2 re-creates the V003 behaviour (fence directory only, journal still writable): the suite must
see the frozen legacy process append after the cut, which is the B06 finding.  Nothing outside --work
is written; the packaged files are only read.

Usage: python -I -B CDT21_F01R1_MUTATION_CONTROLS.py --work <new dir> --out <result.json>
Exit 0 only when the baseline passes and every mutation is killed by its tests.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
IMPLEMENTATION = HERE.parent
SUITE = 'test_cdt21_f01r1_preexisting_legacy_cut.py'
ENTRY = 'candidate/adapter/runtime_locator_orchestrator_entry.py'
TOOL = 'candidate/control/LEGACY_ENTRY_FENCE.py'
NT = os.name == 'nt'

MUTATIONS = (
    ('M1_JOURNAL_DENY_SKIPPED', ENTRY,
     ((('        _win_deny_journal_writes(journal)\n    else:\n        os.chmod(journal, 0o444)\n'),
       '        pass\n    else:\n        pass\n'),),
     ('test_50_',)),
    ('M2_V003_BEHAVIOUR_FENCE_ONLY_JOURNAL_WRITABLE', ENTRY,
     ((('        _win_deny_journal_writes(journal)\n    else:\n        os.chmod(journal, 0o444)\n'),
       '        pass\n    else:\n        pass\n'),
      ('    if not evidence["denied"]:\n        raise RuntimeError("LEGACY_JOURNAL_CUT_NOT_ENFORCED")\n', '    pass\n')),
     ('test_50_',)),
    ('M3_PROBE_IGNORES_OPEN_WRITE_HANDLES', ENTRY,
     # Windows: read with full sharing instead of denying write sharing; POSIX: no read lease.
     ((('            raw, ident = read_pinned_regular(journal, "LEGACY_JOURNAL_CUT_PROBE")  # GENERIC_READ, FILE_SHARE_READ\n',
        '            raw = journal.read_bytes(); st = os.lstat(journal); ident = [st.st_dev, st.st_ino]\n'),) if NT else
      (('            fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_RDLCK)\n        except OSError as exc:',
        '            pass\n        except OSError as exc:'),
       ('            fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)\n', '            pass\n'))),
     ('test_52_',)),
    ('M4_DRAIN_ALWAYS_DRAINED', ENTRY,
     (('    return {"status": "NOT_DRAINED" if open_runs else "DRAINED", "runs": runs,',
       '    return {"status": "DRAINED", "runs": runs,'),),
     ('test_51_',)),
    ('M5_ADMITTED_APPEND_THROUGH_FROZEN_OPEN_WITHOUT_CUT_CHECK', ENTRY,
     (('            if config is None:\n                return frozen_state.log(self, node, phase, **x)\n',
       '            if True:\n                return frozen_state.log(self, node, phase, **x)\n'),),
     ('test_61_',) + (('test_60_', 'test_62_') if NT else ())),
    ('M6_LIVE_IDENTITY_TREATED_AS_GONE', ENTRY,
     (('        if created_ns > run["first_started_ns"] + LEGACY_DRAIN_CLOCK_MARGIN_NS:', '        if True:'),),
     ('test_51_', 'test_72_')),
    ('M7_ACTIVITY_DURING_CUT_NOT_REPORTED', TOOL,
     (('        if changed:\n            result["decision"] = "CUT_PRESENT_LEGACY_ACTIVITY_DURING_CUT"',
       '        if False:\n            result["decision"] = "CUT_PRESENT_LEGACY_ACTIVITY_DURING_CUT"'),),
     ('test_53_',)),
    ('M8_ADMISSION_WITHOUT_CUT_RECORD', ENTRY,
     (('    _, prefix = require_legacy_journal_cut(state_path, marker_raw)\n    drain = legacy_drain(prefix)\n',
       '    prefix = b""\n    drain = legacy_drain(prefix)\n'),),
     ('test_57_', 'test_61_')),
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def run_tests(mirror, prefixes, log):
    cmd = [sys.executable, '-I', '-B', '-m', 'unittest', 'discover', '-s', str(mirror / 'tests'), '-t', str(mirror / 'tests'),
           '-p', SUITE, '-v']
    for p in prefixes:
        cmd += ['-k', p]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800, cwd=str(mirror), env=env)
    out = r.stdout + r.stderr
    log.write_text(out, encoding='utf-8')
    ran = re.findall(r'(?m)^(test_\d+_\w+) \(', out)
    bad = sorted(set(re.findall(r'(?m)^(?:FAIL|ERROR): (test_\d+_\w+)', out)))
    skipped = sorted(set(re.findall(r'(?m)^(test_\d+_\w+) \(.*\.\.\. skipped', out)))
    return {'exit_code': r.returncode, 'ran': sorted(set(ran)), 'failed': bad, 'skipped': skipped,
            'log': log.name, 'log_sha256': sha(log.read_bytes())}


def main(argv=None):
    ap = argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument('--work', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args(argv)
    work = Path(a.work)
    work.mkdir(parents=True)  # never reuse
    mirror = work / 'implementation_v001'
    for part in ('candidate', 'tests'):
        shutil.copytree(IMPLEMENTATION / part, mirror / part, ignore=shutil.ignore_patterns('__pycache__'))
    result = {'schema': 'CDT21_F01R1_MUTATION_CONTROLS_V001', 'platform': sys.platform,
              'entry_sha256': sha((IMPLEMENTATION / ENTRY).read_bytes()), 'tool_sha256': sha((IMPLEMENTATION / TOOL).read_bytes()),
              'suite_sha256': sha((IMPLEMENTATION / 'tests' / SUITE).read_bytes()), 'mutations': {}, 'status': 'FAIL'}
    killers = sorted({k for _, _, _, kills in MUTATIONS for k in kills})
    base = run_tests(mirror, killers, work / 'BASELINE.log')
    base['status'] = 'PASS' if base['exit_code'] == 0 and not base['failed'] and not base['skipped'] and all(
        any(t.startswith(k) for t in base['ran']) for k in killers) else 'FAIL'
    result['baseline'] = base
    ok = base['status'] == 'PASS'
    for name, rel, edits, kills in MUTATIONS:
        target = mirror / rel
        original = target.read_bytes()
        text = original.decode('utf-8')
        eol = '\r\n' if '\r\n' in text else '\n'  # the entry module keeps its CRLF bytes
        for old, new in ((o.replace('\n', eol), n.replace('\n', eol)) for o, n in edits):
            if text.count(old) != 1:
                raise SystemExit('MUTATION_ANCHOR_NOT_UNIQUE:' + name)
            text = text.replace(old, new)
        target.write_bytes(text.encode('utf-8'))
        try:
            got = run_tests(mirror, kills, work / (name + '.log'))
        finally:
            target.write_bytes(original)
        if sha(target.read_bytes()) != sha(original):
            raise SystemExit('MUTATION_NOT_RESTORED:' + name)
        killed = all(any(f.startswith(k) for f in got['failed']) for k in kills)
        got.update(file=rel, mutated_sha256=sha(text.encode('utf-8')), must_fail=list(kills),
                   status='KILLED' if killed and got['exit_code'] != 0 else 'SURVIVED')
        result['mutations'][name] = got
        ok = ok and got['status'] == 'KILLED'
    result['status'] = 'PASS' if ok else 'FAIL'
    result['killed'] = sum(v['status'] == 'KILLED' for v in result['mutations'].values())
    result['total'] = len(MUTATIONS)
    Path(a.out).write_text(json.dumps(result, indent=1, sort_keys=True) + '\n', encoding='ascii')
    print('CDT21_F01R1_MUTATION_CONTROLS=' + result['status'] + ' KILLED=' + str(result['killed']) + '/' + str(result['total'])
          + ' BASELINE=' + base['status'], flush=True)
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
