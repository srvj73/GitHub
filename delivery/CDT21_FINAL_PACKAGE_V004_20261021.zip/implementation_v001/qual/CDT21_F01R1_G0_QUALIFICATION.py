"""CDT21 F-01R1 - native qualification of the V004 delta (Windows PS 5.1, CPython 3.14.7, NTFS, elevated).

The V004 delta changes the legacy cut (candidate/control/LEGACY_ENTRY_FENCE.py) and the admitted entry
(candidate/adapter/runtime_locator_orchestrator_entry.py).  This driver re-runs, through the campaign's
own unit machinery (g5proof/PRE_G06_CAMPAIGN.run_unit: one Windows Job per unit, owned-process census,
commit records bound to the package and code manifest digests), exactly the units whose executed code
contains those two files, i.e. the V003 G0 set, plus the new suite:
  * tests/test_cdt21_f01r1_preexisting_legacy_cut.py - frozen legacy processes alive across the cut,
    write handle open at the cut, activity between diagnosis and cut, concurrent installs, admission
    order, admitted backup-semantics writer, DACL/thread-token evidence;
  * the V003 F-01 suite (frozen CLI and PS 5.1 master launcher behind the cut) and the consumers of the
    admitted entry, the eleven pre-B06 consumers (verified by PRE_B06_ENGINEERING_GATE).
Then, outside the units: qual/CDT21_F01R1_MUTATION_CONTROLS.py (every protection load-bearing, natively)
and qual/CDT21_F01R1_ORIGIN_SCENARIO.py (the origin's reproduction on the V004 sources; optionally the
V003 package as contrast).  No production root is named; nothing outside the run-owned root is written.
G5 (38 units) is NOT run.  Exit 0 only when every unit, every mutation and the origin scenario PASS.

Usage (elevated; called by RUN_CDT21_F01R1_G0_V004_20261021.ps1):
  python -I -B CDT21_F01R1_G0_QUALIFICATION.py --run-root <LOCALAPPDATA\\CDT21_F01R1_G0\\R08_Q1_...> --package <V004 zip>
         [--contrast-package <V003 zip>]
"""
import argparse
import ctypes
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import traceback
import zipfile

HERE = Path(__file__).resolve().parent
IMPLEMENTATION = HERE.parent
CANDIDATE = IMPLEMENTATION / 'candidate'
sys.path.insert(0, str(CANDIDATE / 'g5proof'))
import PRE_G06_CAMPAIGN as campaign  # noqa: E402  (puts full/control/adapter/g5proof on sys.path)

R = campaign.R
require = campaign.require
SUITES = (
    ('CDT21R1_F01R1_PREEXISTING_LEGACY_CUT', 'test_cdt21_f01r1_preexisting_legacy_cut.py'),
    ('CDT21R1_F01_LEGACY_ENTRY_FENCE', 'test_cdt21_f01_legacy_entry_fence.py'),
    ('CDT21R1_SUITE_adapter_tests.py', 'adapter_tests.py'),
    ('CDT21R1_SUITE_test_state_cas_recovery.py', 'test_state_cas_recovery.py'),
    ('CDT21R1_DELTA_test_cdt19_integrated_crash_recovery.py', 'test_cdt19_integrated_crash_recovery.py'),
    ('CDT21R1_SUITE_test_operator_entry_points.py', 'test_operator_entry_points.py'),
    ('CDT21R1_SUITE_test_canary_receipt_readback.py', 'test_canary_receipt_readback.py'),
    ('CDT21R1_SUITE_test_stage_canary_physical_publication.py', 'test_stage_canary_physical_publication.py'),
    ('CDT21R1_SUITE_test_stageb_full_physical_closure.py', 'test_stageb_full_physical_closure.py'),
    ('CDT21R1_SUITE_test_cdt17_full_composition_scope.py', 'test_cdt17_full_composition_scope.py'),
    ('CDT21R1_SUITE_test_legacy_entry_isolation.py', 'test_legacy_entry_isolation.py'),
)
CONSUMERS = 'CDT21R1_PRE_B06_11_CHAIN'
RETURN = 'CDT21_F01R1_G0_RETURN.zip'
V003_SHA = '69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50'


def seal(root):
    target = root / RETURN
    require(not target.exists(), 'RETURN_EXISTS')
    files = sorted(p for p in root.rglob('*') if p.is_file()
                   and p.relative_to(root).parts[0] not in ('TEMP', 'PACKAGED', 'SCRATCH'))
    with zipfile.ZipFile(root / (RETURN + '.partial'), 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in files:
            R.core.assert_no_link_chain(p)
            z.write(p, p.relative_to(root).as_posix())
    with zipfile.ZipFile(root / (RETURN + '.partial')) as z:
        require(z.testzip() is None, 'RETURN_CRC')
    os.replace(root / (RETURN + '.partial'), target)
    return target


def tool(root, script, args, log_name, timeout):
    log = root / 'LOGS' / log_name
    r = subprocess.run([sys.executable, '-I', '-B', str(HERE / script)] + [str(a) for a in args],
                       capture_output=True, text=True, timeout=timeout, cwd=str(root / 'SCRATCH'))
    log.write_text(r.stdout + r.stderr, encoding='utf-8')
    print(r.stdout.strip()[-2000:], flush=True)
    return r.returncode


def v004_scenario_verdict(obj):
    a = obj['scenarios']['A_ORIGIN_REPRODUCER']
    b = obj['scenarios']['B_LEGACY_NODE_IN_FLIGHT']
    common = lambda s: (s.get('legacy_child_initialized_before_fence') is True and s.get('new_legacy_state_after_fence_blocked') is True
                        and s.get('old_legacy_child_append_after_fence') is False and s.get('journal_unchanged_after_fence') is True
                        and s.get('state_unchanged_after_fence') is True and 'PermissionError' in s.get('old_legacy_child_error', '')
                        and s.get('cut_record_present') is True and s.get('diagnose_after_old_legacy_exit') == 'FENCE_PRESENT')
    checks = {'A_cut_present_old_append_denied': common(a) and a.get('fence_install_decision') == 'FENCE_PRESENT'
              and a.get('fence_install_exit') == 0,
              'B_in_flight_refused_old_append_denied': common(b)
              and b.get('fence_install_decision') == 'CUT_PRESENT_LEGACY_RUN_NOT_DRAINED' and b.get('fence_install_exit') == 2,
              'model_native': obj.get('model') == 'WINDOWS_NATIVE'}
    return checks, all(checks.values())


def main(argv=None):
    ap = argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument('--run-root', required=True)
    ap.add_argument('--package', required=True)
    ap.add_argument('--contrast-package')
    a = ap.parse_args(argv)
    root = campaign.no_alias(a.run_root)
    result = {'schema': 'CDT21_F01R1_V004_G0_NATIVE_QUALIFICATION_V001', 'status': 'BLOCKED', 'units': {},
              'production_modified': False, 'g5_38_units': 'NOT_RUN', 'b06': 'NOT_STARTED', 'b07': 'NOT_STARTED',
              'd4_d5': 'NOT_STARTED', 'canary': 'NOT_STARTED', 'full_started': False,
              'physical_powerloss': 'NOT_TESTED_PHYSICAL_POWERLOSS', 'scope': 'V004_DELTA_AFFECTED_UNITS_ONLY_RUN_OWNED_NTFS'}
    code = 2
    try:
        require(os.name == 'nt', 'WINDOWS_REQUIRED')
        require(sys.version_info[:3] == (3, 14, 7), 'PYTHON_3_14_7_REQUIRED')
        require(ctypes.WinDLL('shell32').IsUserAnAdmin(), 'ELEVATION_REQUIRED')
        require(root.is_relative_to(campaign.no_alias(os.environ['LOCALAPPDATA'])), 'LOCALAPPDATA_OWNED_RUN')
        require(re.fullmatch(r'R08_Q1_[0-9]{14}_[0-9a-f]{12}', root.name) is not None, 'RUN_NAME')
        require(Path(os.environ['TEMP']) == root / 'TEMP' and '%' not in str(root), 'CANONICAL_TEMP_REQUIRED')
        require(R.core.windows_volume_identity(root)['filesystem'] == 'NTFS', 'NTFS_REQUIRED')
        package = Path(a.package)
        code_sha, members = campaign.verify_package(package)  # tested bytes == packaged bytes
        pack_sha = R.sha(package.read_bytes())
        require(pack_sha != V003_SHA, 'PACKAGE_IS_THE_V003_PARENT')
        result.update(code_manifest_sha256=code_sha, final_zip_sha256=pack_sha, run_id=root.name)
        for name in ('LOGS', 'UNITS', 'COMMITS', 'EVIDENCE', 'WORK', 'SCRATCH'):
            (root / name).mkdir(exist_ok=True)
        R.core.require_windows_pilot_runtime()
        base = dict(root=str(root), run_id=root.name, package_sha256=pack_sha, code_sha256=code_sha)
        plan = [k for k, _ in SUITES] + [CONSUMERS]
        for i, (key, name) in enumerate(SUITES):
            campaign.verify_package(package)
            test = campaign.run_unit(dict(base, kind='suite', key=key, name=name, progress=str(i) + '/' + str(len(plan)),
                                          remaining=tuple(plan[i + 1:])))
            result['units'][key] = campaign.suite_record(root, key, test)
        campaign.verify_package(package)
        campaign.run_unit(dict(base, kind='consumers', key=CONSUMERS, progress=str(len(SUITES)) + '/' + str(len(plan)),
                               remaining=()))
        ref = campaign.project_consumer_refs(root)
        import PRE_B06_ENGINEERING_GATE as consumer_gate
        checked = consumer_gate.verify_dossier(R.read(root / ref['member'])[0], CANDIDATE, root / 'EVIDENCE/PRE_B06',
                                               native_required=True)
        result['units'][CONSUMERS] = {'status': 'PASS_PRE_B06_ENGINEERING', 'exit_code': 0, 'receipt': ref,
                                      'gate': checked if isinstance(checked, (dict, list, str)) else str(checked)}
        # Negative controls by mutation, natively (Windows-only branches included).
        campaign.verify_package(package)
        mutation_out = root / 'EVIDENCE' / 'MUTATION_CONTROLS.json'
        rc = tool(root, 'CDT21_F01R1_MUTATION_CONTROLS.py', ['--work', root / 'SCRATCH' / 'MUTATION', '--out', mutation_out],
                  'MUTATION_CONTROLS.log', 3600)
        for log in sorted((root / 'SCRATCH' / 'MUTATION').glob('*.log')):
            shutil.copyfile(log, root / 'EVIDENCE' / ('MUTATION_' + log.name))
        mutation = json.loads(mutation_out.read_text(encoding='ascii'))
        result['mutation_controls'] = {k: mutation[k] for k in ('status', 'killed', 'total')}
        result['mutation_controls']['baseline'] = mutation['baseline']['status']
        result['mutation_controls']['by_mutation'] = {k: v['status'] for k, v in mutation['mutations'].items()}
        require(rc == 0 and mutation['status'] == 'PASS', 'MUTATION_CONTROLS_NOT_PASS')
        # The origin's reproduction on the exact V004 sources (and, if supplied, on V003 as contrast).
        scenario_out = root / 'EVIDENCE' / 'ORIGIN_SCENARIO_V004.json'
        rc = tool(root, 'CDT21_F01R1_ORIGIN_SCENARIO.py', ['--package', package, '--work', root / 'SCRATCH' / 'SCENARIO_V004',
                                                           '--out', scenario_out], 'ORIGIN_SCENARIO_V004.log', 1800)
        scenario = json.loads(scenario_out.read_text(encoding='ascii'))
        require(rc == 0 and scenario['package_sha256'] == pack_sha, 'ORIGIN_SCENARIO_V004_NOT_RUN')
        checks, ok = v004_scenario_verdict(scenario)
        result['origin_scenario_v004'] = {'checks': checks, 'status': 'PASS' if ok else 'FAIL',
                                          'primary_assertions': {k: v.get('primary_assertion') for k, v in scenario['scenarios'].items()}}
        if a.contrast_package:
            contrast_out = root / 'EVIDENCE' / 'ORIGIN_SCENARIO_V003_CONTRAST.json'
            rc3 = tool(root, 'CDT21_F01R1_ORIGIN_SCENARIO.py', ['--package', a.contrast_package, '--work',
                                                                root / 'SCRATCH' / 'SCENARIO_V003', '--out', contrast_out],
                       'ORIGIN_SCENARIO_V003_CONTRAST.log', 1800)
            contrast = json.loads(contrast_out.read_text(encoding='ascii'))
            reproduced = rc3 == 0 and contrast['package_sha256'] == V003_SHA and all(
                v.get('primary_assertion') == 'F01_LEGACY_ALREADY_INITIALIZED_NOT_STOPPED_BY_FENCE' for v in contrast['scenarios'].values())
            result['origin_scenario_v003_contrast'] = {'status': 'V003_DEFECT_REPRODUCED_NATIVE' if reproduced else 'NOT_REPRODUCED',
                                                       'primary_assertions': {k: v.get('primary_assertion')
                                                                              for k, v in contrast['scenarios'].items()}}
        else:
            result['origin_scenario_v003_contrast'] = {'status': 'NOT_RUN_V003_PACKAGE_NOT_SUPPLIED'}
        require(ok, 'ORIGIN_SCENARIO_V004_NOT_PASS')
        result['status'] = 'PASS_CDT21_F01R1_V004_G0_NATIVE'
        code = 0
    except BaseException as exc:
        result.update(error=type(exc).__name__ + ':' + str(exc), traceback=traceback.format_exc())
        traceback.print_exc()
    finally:
        try:
            R.publish(root / 'G0_RESULT.json', result)
            target = seal(root)
            print('G0_RETURN=' + str(target) + ' SHA256=' + R.sha(target.read_bytes()), flush=True)
        except BaseException as exc:
            print('G0_RETURN_SEAL_FAILED=' + type(exc).__name__ + ':' + str(exc), flush=True)
            code = 2
    print('CDT21_F01R1_G0=' + result['status'] + ' EXIT_CODE=' + str(code), flush=True)
    return code


if __name__ == '__main__':
    raise SystemExit(main())
