"""CDT21 F-01/F-04 - native G0 qualification of the V003 delta (Windows PS 5.1, CPython 3.14.7, NTFS).

Runs only the units whose executed code contains the delta, through the campaign's own unit
machinery (g5proof/PRE_G06_CAMPAIGN.run_unit: one Windows Job per unit, owned-process census,
commit records bound to the package and code manifest digests):
  * tests/test_cdt21_f01_legacy_entry_fence.py   - frozen V004R1 master launcher under PS 5.1, frozen CLI,
                                                   fence tool, admitted entry, junction, share-mode pins;
  * the suites that load the changed adapter modules or FULL_STAGE_CONTINUATION, the closed runtime
    file set and legacy entry isolation;
  * the eleven pre-B06 consumers (two of them changed), verified by PRE_B06_ENGINEERING_GATE.
Every other historical unit keeps its V002 result only for its identical bytes; G3/G6 is not re-run
because its scenarios use the path-mode guard and never reach the adapter launch fallback (both
unchanged, tests 25 and 26 of the F-01 suite).  No production root is named and nothing outside
the run-owned root is written.  Exit 0 only when every unit PASSES.

Usage (elevated; called by RUN_CDT21_F01_G0_V003_20261020.ps1):
  python -I -B CDT21_F01_G0_QUALIFICATION.py --run-root <LOCALAPPDATA\\CDT21_F01_G0\\R08_Q1_...> --package <V003 zip>
"""
import argparse
import ctypes
import json
import os
from pathlib import Path
import re
import sys
import traceback
import zipfile

HERE = Path(__file__).resolve().parent
IMPLEMENTATION = HERE.parent
CANDIDATE = IMPLEMENTATION / 'candidate'
sys.path.insert(0, str(CANDIDATE / 'g5proof'))
import PRE_G06_CAMPAIGN as campaign  # noqa: E402  (puts full/control/adapter/g5proof on sys.path)

R = campaign.R
require = campaign.require
SUITES = (
    ('CDT21_F01_LEGACY_ENTRY_FENCE', 'test_cdt21_f01_legacy_entry_fence.py'),
    ('CDT21_SUITE_adapter_tests.py', 'adapter_tests.py'),
    ('CDT21_SUITE_test_state_cas_recovery.py', 'test_state_cas_recovery.py'),
    ('CDT21_DELTA_test_cdt19_integrated_crash_recovery.py', 'test_cdt19_integrated_crash_recovery.py'),
    ('CDT21_SUITE_test_operator_entry_points.py', 'test_operator_entry_points.py'),
    ('CDT21_SUITE_test_canary_receipt_readback.py', 'test_canary_receipt_readback.py'),
    ('CDT21_SUITE_test_stage_canary_physical_publication.py', 'test_stage_canary_physical_publication.py'),
    ('CDT21_SUITE_test_stageb_full_physical_closure.py', 'test_stageb_full_physical_closure.py'),
    ('CDT21_SUITE_test_cdt17_full_composition_scope.py', 'test_cdt17_full_composition_scope.py'),
    ('CDT21_SUITE_test_legacy_entry_isolation.py', 'test_legacy_entry_isolation.py'),
)
CONSUMERS = 'CDT21_PRE_B06_11_CHAIN'
RETURN = 'CDT21_F01_G0_RETURN.zip'


def seal(root):
    target = root / RETURN
    require(not target.exists(), 'RETURN_EXISTS')
    files = sorted(p for p in root.rglob('*') if p.is_file() and p.relative_to(root).parts[0] not in ('TEMP', 'PACKAGED'))
    with zipfile.ZipFile(root / (RETURN + '.partial'), 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in files:
            R.core.assert_no_link_chain(p)
            z.write(p, p.relative_to(root).as_posix())
    with zipfile.ZipFile(root / (RETURN + '.partial')) as z:
        require(z.testzip() is None, 'RETURN_CRC')
    os.replace(root / (RETURN + '.partial'), target)
    return target


def main(argv=None):
    ap = argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument('--run-root', required=True)
    ap.add_argument('--package', required=True)
    a = ap.parse_args(argv)
    root = campaign.no_alias(a.run_root)
    result = {'schema': 'CDT21_F01_F04_G0_NATIVE_QUALIFICATION_V001', 'status': 'BLOCKED', 'units': {},
              'production_modified': False, 'b06': 'NOT_STARTED', 'b07': 'NOT_STARTED', 'd4_d5': 'NOT_STARTED',
              'full_started': False, 'physical_powerloss': 'NOT_TESTED_PHYSICAL_POWERLOSS',
              'scope': 'V003_DELTA_AFFECTED_UNITS_ONLY_RUN_OWNED_NTFS'}
    code = 2
    try:
        require(os.name == 'nt', 'WINDOWS_REQUIRED')
        require(sys.version_info[:3] == (3, 14, 7), 'PYTHON_3_14_7_REQUIRED')
        require(ctypes.WinDLL('shell32').IsUserAnAdmin(), 'ELEVATION_REQUIRED')
        require(root.is_relative_to(campaign.no_alias(os.environ['LOCALAPPDATA'])), 'LOCALAPPDATA_OWNED_RUN')
        require(re.fullmatch(r'R08_Q1_[0-9]{14}_[0-9a-f]{12}', root.name) is not None, 'RUN_NAME')
        require(Path(os.environ['TEMP']) == root / 'TEMP' and '%' not in str(root), 'CANONICAL_TEMP_REQUIRED')
        require(R.core.windows_volume_identity(root)['filesystem'] == 'NTFS', 'NTFS_REQUIRED')
        package = Path(a.package)
        code_sha, members = campaign.verify_package(package)  # tested bytes == packaged bytes
        pack_sha = R.sha(package.read_bytes())
        result.update(code_manifest_sha256=code_sha, final_zip_sha256=pack_sha, run_id=root.name)
        for name in ('LOGS', 'UNITS', 'COMMITS', 'EVIDENCE', 'WORK'):
            (root / name).mkdir(exist_ok=True)
        R.core.require_windows_pilot_runtime()
        base = dict(root=str(root), run_id=root.name, package_sha256=pack_sha, code_sha256=code_sha)
        plan = [k for k, _ in SUITES] + [CONSUMERS]
        for i, (key, name) in enumerate(SUITES):
            campaign.verify_package(package)
            test = campaign.run_unit(dict(base, kind='suite', key=key, name=name, progress=str(i) + '/' + str(len(plan)),
                                          remaining=tuple(plan[i + 1:])))
            result['units'][key] = campaign.suite_record(root, key, test)
        campaign.verify_package(package)
        campaign.run_unit(dict(base, kind='consumers', key=CONSUMERS, progress=str(len(SUITES)) + '/' + str(len(plan)),
                               remaining=()))
        ref = campaign.project_consumer_refs(root)
        import PRE_B06_ENGINEERING_GATE as consumer_gate
        checked = consumer_gate.verify_dossier(R.read(root / ref['member'])[0], CANDIDATE, root / 'EVIDENCE/PRE_B06',
                                               native_required=True)
        result['units'][CONSUMERS] = {'status': 'PASS_PRE_B06_ENGINEERING', 'exit_code': 0, 'receipt': ref,
                                      'gate': checked if isinstance(checked, (dict, list, str)) else str(checked)}
        result['status'] = 'PASS_CDT21_F01_F04_G0_NATIVE'
        code = 0
    except BaseException as exc:
        result.update(error=type(exc).__name__ + ':' + str(exc), traceback=traceback.format_exc())
        traceback.print_exc()
    finally:
        try:
            R.publish(root / 'G0_RESULT.json', result)
            target = seal(root)
            print('G0_RETURN=' + str(target) + ' SHA256=' + R.sha(target.read_bytes()), flush=True)
        except BaseException as exc:
            print('G0_RETURN_SEAL_FAILED=' + type(exc).__name__ + ':' + str(exc), flush=True)
            code = 2
    print('CDT21_F01_G0=' + result['status'] + ' EXIT_CODE=' + str(code), flush=True)
    return code


if __name__ == '__main__':
    raise SystemExit(main())
