"""One-pass B1 formal native Windows qualification for the existing Opus FULL.

SOURCE_ONLY: not a certified executable release until qualification on target.
Effect frontier: exclusively NEW run-owned evidence directory; no Tickstore/STATE
writes; never starts D4/D5/G5, B06, CANARY or productive FULL.

Example after the full source ZIP has been safely unpacked and inputs collected:
 python B1_NATIVE_FINAL_QUALIFICATION.py --final <FULL_SOURCE_ZIP> --inputs <DIR> --policy <DIR> --output <NEW_DIR>

B1 native proof is specific to EXACT final package bytes. It does not
recount historical tests or independently validate the external auditor.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import threading
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile

CONTEXT = 'ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão de Ticks 17'
INPUT_NAMES = (
 'B1_126_PROVENANCE_MAP.json',
 'CDT16_C5R44_B1_126_EVIDENCE_CONSOLIDATED_20261015.zip',
 'TICKSTORE_CDT16_C5R44_B1_DELTA_SOURCE_ONLY.zip',
 'TICKSTORE_CDT16_FULL_C5R44_G5_CONTRACT_REBASED_SOURCE_ONLY_20261015.zip',
)
EXPECTED_INPUT_HASHES = (
 'F1B1D49440A168863932BD9E5D1414ABD48CF9B727639D02DA3EA7440F9E69EF',
 '2D9DBA00D3282E2899672722DE9E6B856F0BC8E9F29657FFC24F1149FB4E0CAC',
 '0B7FC2ACAA59A4D11C8B43B4EAB8FAEE9FC067C3D7F7591524811D01FF0CCDFA',
 'C9C4F01F0EF2E2748A4063617E7896DDE767F9C5147644DB1C4D77DC78AC167F',
)
FINAL_ISSUER_MEMBER = 'implementation_v001/candidate/control/B1_FORMAL_ADMISSION.py'
FINAL_PRODUCER_MEMBER = 'implementation_v001/qual/B1_NATIVE_FINAL_QUALIFICATION.py'
RETURN_CONTEXT = 'Devolva este resultado ao ChatGPT, no projeto \'Base de Dados CSV / Tickstore\', conversa \'Compressão de Ticks 17\'. Anexe as evidências existentes e cole esta resposta.'


def digest(b):
 return hashlib.sha256(b).hexdigest().upper()

def ensure(ok, label):
 if not ok:
  raise ValueError(label)


def canonical(obj):
 return (json.dumps(obj,indent=2,ensure_ascii=False,sort_keys=True)+'\n').encode('utf-8')


def read_inputs(path):
 b = tuple((path / s).read_bytes() for s in INPUT_NAMES)
 for name,body,expected in zip(INPUT_NAMES,b,EXPECTED_INPUT_HASHES):
  if digest(body)!=expected:
   raise ValueError('B1_INPUT_HASH_MISMATCH:'+name)
 return b


def attach_imports(control):
 # Source-only qualifier: import from an extracted *version-pinned candidate*;
 # the caller separately compares every imported file with the FINAL ZIP.
 if str(control) not in sys.path:
  sys.path.insert(0,str(control))
 import B1_FORMAL_ADMISSION as formal
 import B1_DISTRIBUTED_CONTRACT_CONSUMER as distributed
 if Path(formal.__file__).resolve()!=(control/'B1_FORMAL_ADMISSION.py').resolve():
  raise ValueError('IMPORTED_ISSUER_WRONG_SOURCE')
 if Path(distributed.__file__).resolve()!=(control/'B1_DISTRIBUTED_CONTRACT_CONSUMER.py').resolve():
  raise ValueError('IMPORTED_DISTRIBUTED_WRONG_SOURCE')
 return formal,distributed


def mk_return(formal,receipt,tests,log):
 members = {'QUAL_RECEIPT.json':canonical(receipt),'TESTS.json':canonical(tests),
            'TESTS.log':log.encode('utf-8')}
 members['RETURN_MANIFEST.json']=canonical({'schema':formal.NATIVE_RETURN_SCHEMA,
                                              'files':{n:digest(v) for n,v in members.items()}})
 mem=io.BytesIO()
 with zipfile.ZipFile(mem,'w',compression=zipfile.ZIP_DEFLATED) as z:
  for n in ('QUAL_RECEIPT.json','TESTS.json','TESTS.log','RETURN_MANIFEST.json'):
   z.writestr(n,members[n])
 return mem.getvalue()


def require_blocked(fn,needle):
 try:
  fn()
 except ValueError as ex:
  if needle not in str(ex):
   raise AssertionError('WRONG_NEGATIVE_CAUSE:'+str(ex)) from ex
  return
 raise AssertionError(needle+':UNEXPECTED_ACCEPTANCE')


def native_suite(final_raw,policy_master,policy_head,inputs,producer_file,control):
 formal,distributed = attach_imports(control)
 issuer=(control/'B1_FORMAL_ADMISSION.py').read_bytes()
 z=zipfile.ZipFile(io.BytesIO(final_raw))
 if z.read(FINAL_PRODUCER_MEMBER)!=producer_file.read_bytes():
  raise ValueError('PRODUCER_TESTED_NOT_PACKAGED')
 if z.read(FINAL_ISSUER_MEMBER)!=issuer:
  raise ValueError('ISSUER_TESTED_NOT_PACKAGED')
 # Qualifier must not import stale control from another checkout.
 for name in ('B1_DISTRIBUTED_CONTRACT_CONSUMER.py','B1_DISTRIBUTED_PROVENANCE_BRIDGE.py',
              'B1_DISTRIBUTED_EVIDENCE_ADMISSION.py','B1_DISTRIBUTED_ADMISSION_CONTRACT_V003.json'):
  if z.read('implementation_v001/candidate/control/'+name)!=(control/name).read_bytes():
   raise ValueError('CONSUMER_TESTED_NOT_PACKAGED:'+name)
 results=[]
 def record(testid,op):
  op()
  results.append({'id':testid,'status':'PASS'})

 def source_126():
  outcome=distributed.evaluate(*inputs)
  ensure(outcome['status']=='PASS_DISTRIBUTED_EVIDENCE_ONLY', 'DISTRIBUTED_STATUS')
  ensure(outcome['verified_test_ids']==126 and outcome['remediations']==7, 'DISTRIBUTED_TOTALS')
  ensure(outcome['b1_formal_gate']=='NOT_ISSUED' and outcome['g5_formal_gate']=='NOT_ISSUED', 'DISTRIBUTED_SCOPE')
 record('formal.source_126',source_126)
 record('formal.policy_r45',lambda:formal.verify_policy(policy_master,policy_head))
 def closed_set():
  ensure(bool(formal.verify_final_package(final_raw,issuer)), 'FINAL_MANIFEST_RESULT')
 record('formal.package_closed_set',closed_set)
 def native_bound():
  ensure(digest(z.read(FINAL_PRODUCER_MEMBER))==digest(producer_file.read_bytes()), 'PRODUCER_BINDING')
  ensure(z.read(FINAL_ISSUER_MEMBER)==issuer, 'ISSUER_BINDING')
 record('formal.native_bound_final_code',native_bound)
 record('negative.missing_source',lambda:require_blocked(lambda: distributed.evaluate(inputs[0],b'',inputs[2],inputs[3]),'B1_SOURCE_IDENTITY'))
 record('negative.mismatched_policy',lambda:require_blocked(lambda:formal.verify_policy(policy_master+b'X',policy_head),'POLICY_PHYSICAL_HASH'))
 def changed_final():
  buf=io.BytesIO()
  with zipfile.ZipFile(buf,'w',compression=zipfile.ZIP_DEFLATED) as out:
   for n in z.namelist():
    data=z.read(n)
    if n==FINAL_ISSUER_MEMBER:data+=b'CHANGED'
    out.writestr(n,data)
  require_blocked(lambda:formal.verify_final_package(buf.getvalue(),issuer),'FINAL:BYTES:')
 record('negative.changed_final_package',changed_final)
 def incomplete():
  raw=io.BytesIO()
  with zipfile.ZipFile(raw,'w') as out:out.writestr('QUAL_RECEIPT.json',b'{}')
  require_blocked(lambda:formal.verify_native_return(raw.getvalue(),final_sha=digest(final_raw),
                        runtime_manifest_sha='A'*64,issuer_sha=digest(issuer)),'NATIVE:MISSING_MANIFEST')
 record('negative.incomplete_native_return',incomplete)
 base_receipt={'schema':formal.SCHEMA,'status':'PASS_NATIVE_INTEGRATED','platform':'win32',
   'powershell_major':5,'final_zip_sha256':digest(final_raw),
   'runtime_manifest_sha256':digest(z.read('implementation_v001/RUNTIME_CODE_MANIFEST.json')),
   'b1_formal_source_sha256':digest(issuer),'policy_master_sha256':formal.EXPECTED_MASTER_SHA,
   'policy_head_sha256':formal.EXPECTED_HEAD_SHA,'policy_revision_id':formal.EXPECTED_REV,
   'tested_code_equals_packaged_code':'PASS','production_execution':False,
   'result_return_to':formal.CONTEXT,'tests_run':10,'failures':0,'errors':0,'skips':0}
 def reject_native(mutator,label):
  fake=[{'id':i,'status':'PASS'} for i in formal.REQUIRED_NEW_TESTS]
  receipt=dict(base_receipt)
  mutator(receipt,fake)
  b=mk_return(formal,receipt,fake,'Ran 10 tests\nOK\n')
  require_blocked(lambda:formal.verify_native_return(b,final_sha=digest(final_raw),
       runtime_manifest_sha=base_receipt['runtime_manifest_sha256'],issuer_sha=digest(issuer)),label)
 record('negative.duplicate_test_id',lambda:reject_native(lambda q,t:t[1].update({'id':t[0]['id']}),'NATIVE:TEST_SET'))
 record('negative.terminal_status_not_pass',lambda:reject_native(lambda q,t:q.update({'status':'FAIL'}),'NATIVE:QUAL_RECEIPT_BINDINGS'))
 ensure([x['id'] for x in results]==list(formal.REQUIRED_NEW_TESTS), 'TEST_SET_BINDING')
 return formal,distributed,issuer,results


def require_native_windows():
 if sys.platform!='win32':
  raise RuntimeError('TARGET_RUNTIME_PENDING_WINDOWS_ONLY')
 if sys.version_info.major!=3:
  raise RuntimeError('PYTHON_VERSION_INVALID')


def ps_major(temp_dir):
 ps_script=temp_dir/'b1_ps_version.ps1'
 ps_script.write_bytes(b'$ErrorActionPreference="Stop"\n[Console]::Out.WriteLine($PSVersionTable.PSVersion.Major)\n')
 p=subprocess.Popen(['powershell.exe','-NoLogo','-NoProfile','-NonInteractive','-File',str(ps_script)],
                    stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 start=time.monotonic()
 try:
  next_heartbeat=start+5
  while p.poll() is None:
   now=time.monotonic()
   if now-start>40:
    raise TimeoutError('POWERSHELL_VERSION_TIMEOUT_PID_'+str(p.pid))
   if now>=next_heartbeat:
    print('B1_NATIVE_HEARTBEAT PHASE=PS51_CHECK PID='+str(p.pid)+
          ' ELAPSED_S='+str(round(now-start,2))+' ETA=UNKNOWN_AS='+
          str(int(time.time())),flush=True)
    next_heartbeat=now+5
   time.sleep(0.25)
  out,err=p.communicate(timeout=5)
  if p.returncode!=0 or out.strip()!=b'5':
   raise RuntimeError('PS51_NOT_VALIDATED:'+repr((p.returncode,out[:100],err[:100])))
  return 5
 except Exception:
  # Do not auto-kill an orphaned child on timeout; preserve for reconciliation.
  raise


def execute(final_file,inputs_dir,policy_dir,output_dir,producer_file,control):
 require_native_windows()
 # Runtime preconditions before evidence effects. Empty destination required.
 final_raw=final_file.read_bytes()
 inputs=read_inputs(inputs_dir)
 master=(policy_dir/'POLITICA_CANONICA_UNIFICADA_OPERACIONAL.md').read_bytes()
 head=(policy_dir/'POLITICA_CANONICA_HEAD.json').read_bytes()
 formal,distributed=attach_imports(control)
 formal.verify_policy(master,head)
 formal.verify_final_package(final_raw,(control/'B1_FORMAL_ADMISSION.py').read_bytes())
 if output_dir.exists():
  raise ValueError('OUTPUT_MUST_NOT_EXIST_NO_OVERWRITE')
 if any(output_dir==v or output_dir in v.parents for v in (final_file,inputs_dir,policy_dir,control)):
  raise ValueError('OUTPUT_OVERLAPS_INPUTS')
 # External Windows source-root resolution MUST prove the exact packaged files.
 if zipfile.ZipFile(io.BytesIO(final_raw)).read(FINAL_PRODUCER_MEMBER)!=producer_file.read_bytes():
  raise ValueError('PRODUCER_SOURCE_MISMATCH')
 output_dir.mkdir(parents=True,exist_ok=False)
 try:
  ps_temp=output_dir/'_ps51_probe'
  ps_temp.mkdir(exist_ok=False)
  major=ps_major(ps_temp)
  hb_stop=threading.Event()
  def heartbeat():
   began=time.monotonic()
   while not hb_stop.wait(5.0):
    print('B1_NATIVE_HEARTBEAT PHASE=B1_10_TEST_SUITE ELAPSED_S='+
       str(round(time.monotonic()-began,2))+' ETA=UNKNOWN_AS='+str(int(time.time())),flush=True)
  worker=threading.Thread(target=heartbeat,daemon=True)
  worker.start()
  try:
   formal,distributed,issuer,tests=native_suite(final_raw,master,head,inputs,producer_file,control)
  finally:
   hb_stop.set()
   worker.join(timeout=1.0)
  native_log='\n'.join([f'{r["id"]}: PASS' for r in tests]+['Ran 10 tests','OK',''])
  runtime_sha=digest(zipfile.ZipFile(io.BytesIO(final_raw)).read('implementation_v001/RUNTIME_CODE_MANIFEST.json'))
  receipt={'schema':formal.SCHEMA, 'status':'PASS_NATIVE_INTEGRATED',
     'platform':sys.platform,'powershell_major':major,
     'os_release':platform.platform(),'python_version':platform.python_version(),
     'python_executable_sha256':digest(Path(sys.executable).read_bytes()),
     'final_zip_sha256':digest(final_raw), 'runtime_manifest_sha256':runtime_sha,
     'b1_formal_source_sha256':digest(issuer),
     'b1_native_producer_source_sha256':digest(producer_file.read_bytes()),
     'policy_master_sha256':formal.EXPECTED_MASTER_SHA,'policy_head_sha256':formal.EXPECTED_HEAD_SHA,
     'policy_revision_id':formal.EXPECTED_REV,'tested_code_equals_packaged_code':'PASS',
     'production_execution':False,'result_return_to':CONTEXT,
     'tests_run':len(tests),'failures':0,'errors':0,'skips':0}
  native_zip=mk_return(formal,receipt,tests,native_log)
  # Formal consumer reads exact native RETURN bytes and all four original input artifacts.
  verified=formal.evaluate(*inputs,final_raw,native_zip,master,head,issuer,distributed.evaluate)
  ensure(verified['status']=='PASS' and verified['gate']=='B1_FORMAL', 'FORMAL_VERDICT_NOT_PASS')
  outputs={'B1_NATIVE_RETURN.zip':native_zip,
           'B1_FORMAL_ADMISSION.json':canonical(verified),
           'B1_NATIVE_QUAL_RECEIPT.json':canonical(receipt)}
  for name,data in outputs.items():
   tmp=output_dir/(name+'.pending')
   with open(tmp,'xb') as f:
    f.write(data);f.flush();os.fsync(f.fileno())
   os.replace(str(tmp),str(output_dir/name))
  for name,raw in outputs.items():
   if digest((output_dir/name).read_bytes())!=digest(raw):
    raise IOError('EVIDENCE_READBACK:'+name)
  return verified
 except BaseException as exc:
  # Leave failed run-owned directory for forensic reconciliation; do not remove.
  reason={'status':'BLOCKED','cause':type(exc).__name__+':'+str(exc),
          'result_return_to':CONTEXT,'full_started':False}
  error_path=output_dir/'B1_BLOCKED.json'
  with open(error_path,'xb') as fh:
   body=canonical(reason);fh.write(body);fh.flush();os.fsync(fh.fileno())
  raise


def main(argv=None):
 ap=argparse.ArgumentParser(description='B1 formal source-only target Windows qualifier; read-only to product')
 ap.add_argument('--final',type=Path,required=True)
 ap.add_argument('--inputs',type=Path,required=True)
 ap.add_argument('--policy',type=Path,required=True)
 ap.add_argument('--output',type=Path,required=True)
 args=ap.parse_args(argv)
 print('RESULT_CONTEXT='+CONTEXT,flush=True)
 try:
  here=Path(__file__).resolve()
  if here.parts[-3:]!=('implementation_v001','qual','B1_NATIVE_FINAL_QUALIFICATION.py'):
   # Python package layout may vary but the source itself MUST be readback-compared.
   pass
  result=execute(args.final.resolve(),args.inputs.resolve(),args.policy.resolve(),
                 args.output.resolve(),here,here.parent.parent/'candidate'/'control')
  print('B1_FORMAL='+result['status']+' FINAL_SHA256='+result['final_zip_sha256'],flush=True)
  code=0
 except KeyboardInterrupt:
  print('B1_FORMAL=SAFE_STOP',flush=True);code=130
 except Exception as ex:
  print('B1_FORMAL=BLOCKED CAUSE='+repr(ex),flush=True);code=2
 print(RETURN_CONTEXT,flush=True)
 print('RESULT_RETURN_TO='+CONTEXT,flush=True)
 return code

if __name__=='__main__':sys.exit(main())
