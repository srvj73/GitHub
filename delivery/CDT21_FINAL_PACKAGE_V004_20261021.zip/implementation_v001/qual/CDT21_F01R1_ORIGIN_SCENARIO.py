"""CDT21 F-01R1 - the origin's B06 reproduction, run against the exact sources of a final package.

Scenario A is the origin reproducer (REPRODUZIR_F01_LEGADO_ATIVO_OFFLINE.py, 03311136...) with its child
code verbatim: a frozen process builds State and appends one line BEFORE the fence, the fence tool of the
package is applied, a new legacy instance is started, then the old process appends again.  Scenario B is
the same with the old process inside a node (frozen execute: STARTED with its run_id), closing it after
the fence with the frozen finish().  Facts are reported, nothing is asserted; the caller judges.
Effects: only a new directory under --work.  POSIX model: when run as root the legacy children start
with SECBIT_NOROOT (uid 0 without CAP_DAC_OVERRIDE), as the frozen code has no privilege to bypass the
cut; Windows runs natively.

Usage: python -I -B CDT21_F01R1_ORIGIN_SCENARIO.py --package <CDT21_FINAL_PACKAGE_V00x.zip> --work <new dir> --out <json>
"""
import argparse
import ctypes
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

SOURCES = {
    'orch': 'implementation_v001/candidate/recovery/modules/orchestrator.py',
    'fence': 'implementation_v001/candidate/control/LEGACY_ENTRY_FENCE.py',
    'adapter': 'implementation_v001/candidate/adapter/runtime_locator_orchestrator_entry.py',
}
# Verbatim child of the origin reproducer (scenario A).
CHILD_A = '''import importlib.util,sys
spec=importlib.util.spec_from_file_location("frozen",sys.argv[1]); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
s=m.State(sys.argv[2])
s.log("A0","LEGACY_PRE_FENCE",origin="frozen_original_state_object")
print("CHILD_LEGACY_INITIALIZED",flush=True)
assert sys.stdin.readline().strip()=="APPEND"
s.log("A0","LEGACY_APPEND_AFTER_FENCE",origin="frozen_original_state_object")
print("CHILD_APPEND_COMPLETE",flush=True)
'''
# Scenario B: the old process is inside a node (frozen execute/finish calls).
CHILD_B = '''import datetime,importlib.util,os,sys
spec=importlib.util.spec_from_file_location("frozen",sys.argv[1]); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
s=m.State(sys.argv[2])
run_id=datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]+f"_{os.getpid()}"
s.log("D4","STARTED",run_id=run_id)
print("CHILD_LEGACY_INITIALIZED",flush=True)
assert sys.stdin.readline().strip()=="APPEND"
s.finish("D4","PASS",{"node":"D4"})
print("CHILD_APPEND_COMPLETE",flush=True)
'''


def sh(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def no_capability():
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(28, 1, 0, 0, 0) != 0:  # PR_SET_SECUREBITS, SECBIT_NOROOT
        raise OSError(ctypes.get_errno(), 'PR_SET_SECUREBITS')


def last_error(stderr):
    lines = [l for l in stderr.strip().splitlines() if l.strip()]
    return lines[-1][:300] if lines else ''


def scenario(name, child_code, code, root, model_extra):
    lab = root / 'owned_lab'
    state = lab / 'state' / 'STATE.json'
    journal = lab / 'state' / 'STATE_JOURNAL.jsonl'
    child_script = root / 'child.py'
    child_script.write_text(child_code, encoding='utf-8')
    out = {'scenario': name}
    proc = subprocess.Popen([sys.executable, '-B', str(child_script), str(code / 'orch.py'), str(lab)], stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1, **model_extra)
    try:
        ready = proc.stdout.readline().strip()
        out['legacy_child_initialized_before_fence'] = ready == 'CHILD_LEGACY_INITIALIZED'
        if ready != 'CHILD_LEGACY_INITIALIZED':
            out['child_init_error'] = last_error(proc.stderr.read())
            return out
        state_before, journal_before = state.read_bytes(), journal.read_bytes()
        tool = [sys.executable, '-B', '-I', str(code / 'fence.py'), '--state', str(state), '--adapter-dir', str(code)]
        install = subprocess.run(tool + ['--apply'], capture_output=True, text=True, timeout=300)
        try:
            rep = json.loads(install.stdout)
        except ValueError:
            rep = {'decision': 'NO_JSON', 'stdout': install.stdout[-500:], 'stderr': install.stderr[-500:]}
        out.update(fence_install_exit=install.returncode, fence_install_decision=rep.get('decision'),
                   fence_install_reasons=rep.get('reasons'), fence_marker_present=(state.with_name('STATE.json.partial')
                                                                                   / 'LEGACY_ENTRY_FENCE.json').exists(),
                   cut_record_present=(state.with_name('STATE.json.partial') / 'LEGACY_JOURNAL_CUT.json').exists())
        deny = subprocess.run([sys.executable, '-B', str(child_script), str(code / 'orch.py'), str(lab)], input='APPEND\n',
                              capture_output=True, text=True, timeout=120, **model_extra)
        out['new_legacy_state_after_fence_blocked'] = deny.returncode != 0 and 'STATE.json.partial' in deny.stderr
        out['new_legacy_error'] = last_error(deny.stderr)
        proc.stdin.write('APPEND\n')
        proc.stdin.flush()
        post = proc.stdout.readline().strip()
        proc.wait(timeout=60)
        err = proc.stderr.read()
        after, state_after = journal.read_bytes(), state.read_bytes()
        # The journal itself is the evidence: frozen finish() appends FINISHED before its STATE write fails.
        out.update(old_legacy_child_append_after_fence=after != journal_before,
                   old_legacy_child_completed=post == 'CHILD_APPEND_COMPLETE',
                   old_legacy_child_exit=proc.returncode, old_legacy_child_error=last_error(err),
                   journal_sha_before=sh(journal_before), journal_sha_after=sh(after),
                   journal_unchanged_after_fence=after == journal_before,
                   state_unchanged_after_fence=state_after == state_before)
        again = subprocess.run(tool, capture_output=True, text=True, timeout=300)
        try:
            out['diagnose_after_old_legacy_exit'] = json.loads(again.stdout).get('decision')
        except ValueError:
            out['diagnose_after_old_legacy_exit'] = 'NO_JSON'
        out['primary_assertion'] = ('F01_LEGACY_ALREADY_INITIALIZED_NOT_STOPPED_BY_FENCE'
                                    if out['old_legacy_child_append_after_fence'] else 'OLD_LEGACY_APPEND_DENIED_AFTER_CUT')
        return out
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.communicate(timeout=30)


def main(argv=None):
    ap = argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument('--package', required=True)
    ap.add_argument('--work', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args(argv)
    raw = Path(a.package).read_bytes()
    with zipfile.ZipFile(io.BytesIO(raw)) as pkg:
        if pkg.testzip() is not None:
            raise SystemExit('PACKAGE_CRC_FAILED')
        blobs = {k: pkg.read(n) for k, n in SOURCES.items()}
    work = Path(a.work)
    work.mkdir(parents=True)  # never reuse
    code = work / 'source'
    code.mkdir()
    for k, b in blobs.items():
        (code / ('runtime_locator_orchestrator_entry.py' if k == 'adapter' else k + '.py')).write_bytes(b)
    model = 'WINDOWS_NATIVE' if os.name == 'nt' else 'POSIX_ROOT_WITHOUT_CAPABILITIES'
    model_extra = {}
    if os.name != 'nt':
        if os.geteuid() != 0:
            model = 'POSIX_SAME_UID_NO_MODEL'
        else:
            model_extra = {'preexec_fn': no_capability}
    result = {'schema': 'CDT21_F01R1_ORIGIN_SCENARIO_V001', 'package_sha256': sh(raw),
              'source_sha256': {k: sh(b) for k, b in blobs.items()}, 'platform': sys.platform, 'model': model,
              'touched_production': False, 'scenarios': {}}
    for name, child in (('A_ORIGIN_REPRODUCER', CHILD_A), ('B_LEGACY_NODE_IN_FLIGHT', CHILD_B)):
        root = work / name
        root.mkdir()
        result['scenarios'][name] = scenario(name, child, code, root, model_extra)
    Path(a.out).write_text(json.dumps(result, indent=1, sort_keys=True) + '\n', encoding='ascii')
    print(json.dumps({k: v.get('primary_assertion') for k, v in result['scenarios'].items()}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
