"""R44 B1: the 126 contract IDs on the CURRENT candidate bytes (Windows native selection).

Inputs are hash-bound: the origin R3 archive (unchanged), the two origin-approved derived
test files (B1A tests_full_lifecycle.py, parent EE30AA93...; B1B tests_delta.py, parent
67B41A04..., approved patch 84E32FA3...), the original 126-ID contract, and the extracted
FINAL candidate with its runtime manifest.  Historical PASS is never inherited: every ID
is executed here on the current bytes.  Requires an elevated process (symlink tests).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
import zipfile
from pathlib import Path


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()


def require(cond, why):
    if not cond:
        raise RuntimeError(why)


def main():
    ap = argparse.ArgumentParser(allow_abbrev=False)
    for k in ('bundle', 'impl', 'work', 'evidence', 'plan'):
        ap.add_argument('--' + k, required=True)
    ap.add_argument('--offline', action='store_true')
    a = ap.parse_args()
    bundle, impl, work, ev = Path(a.bundle), Path(a.impl), Path(a.work), Path(a.evidence)
    spec = json.loads(Path(a.plan).read_bytes())['b1']
    out = {'schema': 'TICKSTORE_CDT15_R44_B1_RESULT_V001', 'mode': 'OFFLINE_HARNESS_CHECK' if a.offline else 'NATIVE_WINDOWS',
           'baseline_results_counted_as_delta': False, 'production_execution': False}
    try:
        # Exact five derived overlays approved for SOURCE_ONLY only.
        # Native B1/gate approval remains absent: fail closed even after R44 rebase.
        require(a.offline, 'C5_SOURCE_ONLY_NATIVE_DISABLED_PENDING_APPROVAL')
        r3zip = bundle / spec['r3_archive']
        require(sha(r3zip) == spec['r3_archive_sha256'], 'R3_ARCHIVE_SHA256')
        contract_path = bundle / spec['contract']
        require(sha(contract_path) == spec['contract_sha256'], 'CONTRACT_SHA256')
        contract = json.loads(contract_path.read_bytes())['required_tests']
        require(len(contract) == 126 and len(set(contract)) == 126, 'CONTRACT_126_UNIQUE')
        cand_contract = impl / 'candidate/control/QUALIFICATION_CONTRACT.json'
        # The historical 126-ID baseline is immutable.  Only the exactly pinned G5
        # process-death replacement contract may follow it as a SOURCE_ONLY migration;
        # unrelated edits, missing tests and altered historic baseline fail closed.
        require(sha(cand_contract) == spec['candidate_contract_sha256'],
                'CANDIDATE_MIGRATION_CONTRACT_SHA256')
        successor = json.loads(cand_contract.read_bytes())
        orig = json.loads(contract_path.read_bytes())
        require(successor.get('schema') == orig.get('schema'), 'MIGRATION_SCHEMA')
        require(successor.get('baseline') == orig.get('baseline'), 'MIGRATION_BASELINE_IMMUTABLE')
        require(successor.get('required_tests') == orig.get('required_tests'), 'MIGRATION_126_IDS_IMMUTABLE')
        expected = dict(orig)
        expected['required_target_proofs'] = [
            'POWERLOSS_EMULATED' if k == 'CHECKPOINT_POWERLOSS_RECOVERY' else k
            for k in orig['required_target_proofs']]
        expected['process_death_only_scope'] = 'EMULATED_PASS_IS_NOT_PHYSICAL_POWERLOSS'
        expected['policy_candidate_id'] = 'CAND-20261015-TICKSTORE_G5_NO_PHYSICAL_CUT-53AEEF5FAA45D7E6'
        expected['policy_candidate_status'] = 'PROMOTED_R44_REVOCATION_ONLY'
        expected['policy_master_sha256'] = 'B215D4DFBC3A0387BA09EE5C3E097ED5D63384675D7E2E70BA2C88E0BF607EE0'
        expected['policy_head_sha256'] = '1F121E61D26EAF346FF9F05AF83DB8EE97ED672E8200369F04462D1A147F4B96'
        expected['policy_revision_id'] = '20261015T134700-0300-B215D4DFBC3A0387'
        require(successor == expected, 'MIGRATION_ALLOWLIST_ONLY')
        require(len(expected['required_target_proofs']) == 6 and
                len(set(expected['required_target_proofs'])) == 6, 'MIGRATION_6_PROOFS')
        out['contract_migration'] = {
            'historical_sha256': spec['contract_sha256'],
            'candidate_sha256': spec['candidate_contract_sha256'],
            'scope': 'SOURCE_ONLY_NOT_G5_OR_POLICY_VERDICT',
            'historical_126_test_ids_preserved': True,
            'policy_promotion': 'R44_REVOKED_POWER_CUT_ONLY_NO_G5_VERDICT'}
        tree = work / 'B1_R3'
        require(not tree.exists(), 'B1_TREE_EXISTS')
        # Preflight all derived bytes + R3 parent SHA before any filesystem extraction.
        # A mismatched overlay must be BLOCKED_NO_EFFECTS, not leave a partial tree.
        with zipfile.ZipFile(r3zip) as z:
            require(z.testzip() is None, 'R3_ARCHIVE_CRC')
            for ov in spec['overlays']:
                derived = bundle / ov['derived']
                require(sha(derived) == ov['derived_sha256'], 'DERIVED_TEST_SHA256:' + ov['target'])
                require(hashlib.sha256(z.read(ov['target'])).hexdigest().upper() == ov['parent_sha256'],
                        'R3_PARENT_TEST_SHA256:' + ov['target'])
            z.extractall(tree)
        out['derived'] = {}
        for ov in spec['overlays']:
            target = tree / ov['target']
            require(sha(target) == ov['parent_sha256'], 'R3_PARENT_TEST_SHA256:' + ov['target'])
            derived = bundle / ov['derived']
            require(sha(derived) == ov['derived_sha256'], 'DERIVED_TEST_SHA256:' + ov['target'])
            # The extracted R3 copy is a disposable working tree; the R3 archive itself is untouched.
            target.write_bytes(derived.read_bytes())
            require(sha(target) == ov['derived_sha256'], 'DERIVED_OVERLAY_READBACK:' + ov['target'])
            out['derived'][ov['target']] = {'parent_sha256': ov['parent_sha256'], 'derived_sha256': ov['derived_sha256']}
        probes = bundle / spec['microprobes']
        require(sha(probes) == spec['microprobes_sha256'], 'MICROPROBES_SHA256')
        (tree / 'engineering/R43_B1A_MICROPROBES.py').write_bytes(probes.read_bytes())
        out.update(r3_archive_sha256=spec['r3_archive_sha256'], contract_sha256=spec['contract_sha256'])

        cand = impl / 'candidate'
        env = dict(os.environ, TICKSTORE_TEST_CANDIDATE=str(cand),
                   TICKSTORE_TEST_MANIFEST=str(impl / 'RUNTIME_CODE_MANIFEST.json'), PYTHONDONTWRITEBYTECODE='1')
        harness = tree / 'engineering/run_current_delta.py'
        sel = ['--native'] if not a.offline else []
        lst = work / 'B1_IDS.json'
        r = subprocess.run([sys.executable, '-B', str(harness), '--list', '--output', str(lst)] + ['--native'],
                           env=env, capture_output=True, text=True, timeout=300)
        require(r.returncode == 0, 'HARNESS_LIST:' + r.stderr[-2000:])
        ids = json.loads(lst.read_bytes())
        require(len(ids) == 126 and set(ids) == set(contract), 'HARNESS_SELECTION_NOT_CONTRACT')
        out['selection'] = {'ids': 126, 'equals_contract': True, 'portable': spec['portable'], 'native_only': spec['native_only']}

        t0 = time.monotonic()
        res_dir = ev / 'B1_HARNESS'
        r = subprocess.run([sys.executable, '-B', str(harness), '--output', str(res_dir)] + sel,
                           env=env, capture_output=True, text=True, timeout=7200)
        (ev / 'B1_HARNESS_STDIO.txt').write_text(r.stdout[-400000:] + '\n---STDERR---\n' + r.stderr[-100000:],
                                                 encoding='utf-8')
        report = json.loads((res_dir / 'RESULT.json').read_bytes())
        statuses = {t['id']: t['status'] for t in report['tests']}
        out['harness'] = {k: report.get(k) for k in ('native_windows', 'selection', 'code_manifest_sha256',
                          'tested_code_unchanged', 'totals', 'tests_expected', 'tests_not_run', 'tests_interrupted',
                          'interruption', 'byte_revalidation_error', 'success')}
        out['harness']['seconds'] = round(time.monotonic() - t0, 3)
        out['tests'] = [{'id': i, 'status': statuses.get(i, 'NOT_SELECTED_OFFLINE' if a.offline else 'NOT_RUN')}
                        for i in contract]
        out['non_pass'] = [t for t in out['tests'] if t['status'] != 'PASS']

        pr = subprocess.run([sys.executable, '-B', '-c',
                             'import sys,unittest;sys.path[:0]=[sys.argv[1],sys.argv[2]];'
                             'import R43_B1A_MICROPROBES as m;r=unittest.TextTestRunner(verbosity=2).run(m.suite());'
                             'sys.exit(0 if r.wasSuccessful() and r.testsRun==5 and not r.skipped else 2)',
                             str(tree / 'engineering'), str(tree / 'cdt15')],
                            env=env, capture_output=True, text=True, timeout=600)
        (ev / 'B1A_MICROPROBES.txt').write_text(pr.stdout + '\n---STDERR---\n' + pr.stderr, encoding='utf-8')
        out['microprobes'] = 'PASS_5_OF_5' if pr.returncode == 0 else 'FAIL'
        expected_total = 126 if not a.offline else spec['portable']
        ran_pass = sum(1 for t in out['tests'] if t['status'] == 'PASS')
        out['counts'] = {'pass': ran_pass, 'expected_executed': expected_total,
                         'non_pass': len([t for t in out['non_pass'] if t['status'] != 'NOT_SELECTED_OFFLINE'])}
        ok = (ran_pass == expected_total and out['counts']['non_pass'] == 0 and report.get('tested_code_unchanged') is True
              and out['microprobes'] == 'PASS_5_OF_5')
        out['status'] = ('PASS' if ok else 'FAIL') if not a.offline else ('OFFLINE_HARNESS_PASS' if ok else 'FAIL')
    except BaseException as exc:
        import traceback
        out['status'] = 'ERROR'
        out['error'] = type(exc).__name__ + ':' + str(exc)
        out['traceback'] = traceback.format_exc()[-6000:]
    (ev / 'B1_RESULT.json').write_text(json.dumps(out, indent=1, sort_keys=True), encoding='utf-8')
    np = ' '.join(t['id'].split('.')[-1] + '=' + t['status'] for t in out.get('non_pass', [])
                  if t['status'] != 'NOT_SELECTED_OFFLINE')
    print('R44_B1 status=%s pass=%s/%s microprobes=%s %s' % (out['status'], out.get('counts', {}).get('pass'),
          out.get('counts', {}).get('expected_executed'), out.get('microprobes'), ('NON_PASS: ' + np) if np else ''),
          flush=True)
    return 0 if out['status'] in ('PASS', 'OFFLINE_HARNESS_PASS') else 2


if __name__ == '__main__':
    raise SystemExit(main())
