# Compressão de Ticks 17 — B1 formal, implantação de código sem liberar produção

Missão bloqueada: FULL Opus R47/C6 é o motor e deve permanecer idêntico.

Este pacote é `SOURCE_ONLY` e incorpora **um** produtor B1 formal nativo ao
mesmo candidato C6, sem modificar o motor original. Não é FULL READY. B1 formal
só existe depois de execução real do produtor no Windows PowerShell 5.1 e do
readback físico do retorno exato; a revisão independente B06 é posterior e
não pode ser simulada.

O código está em `implementation_v001/qual/B1_NATIVE_FINAL_QUALIFICATION.py`;
controlador em `implementation_v001/candidate/control/B1_FORMAL_ADMISSION.py`.

As quatro fontes B1 aprovadas estão embutidas em
`implementation_v001/B1_APPROVED_INPUTS/`, com hashes individuais fechados.
Uma CAPTURA NÃO AUTORITATIVA R45 do par físico está em
`implementation_v001/POLICY_CAPTURE_NONAUTHORITATIVE/`.
No Windows, `--policy` deve apontar para essa captura ou para outra captura
legitimamente certificada na origem. A captura não é MASTER vivo. A origem deve fazer nova reconciliação no
recebimento dos artefatos; nunca tratar a captura Windows como MASTER vivo.

O qualificador nativo só pode escrever em diretório NOVO, exclusivo da execução.
Ele não altera Tickstore, STATE, menu, D4, D5, G5, FULL, locks ou originais.
Antes de executar no PC alvo é necessário qualificar o bootstrap/extrator e
as dependências no próprio Windows (G0 alvo); enquanto isso a classificação é
`EXECUTABLE_DELIVERY_READY=BLOCKED / TARGET_RUNTIME_PENDING`.

O runner não produz B1 PASS quando falta Windows, runtime PS 5.1, fonte, hash,
política, proof negativo ou identidade de pacote. Seu zip de evidência inclui
os resultados individuais dos 10 testes efetivamente executados no Windows.
Os 126 testes antigos permanecem históricos, não são repetidos; o conjunto
G4/G5 continua não admitido. O pacote não autoriza B06 nem produção.

Devolva este resultado ao ChatGPT, no projeto 'Base de Dados CSV / Tickstore', conversa 'Compressão de Ticks 17'. Anexe as evidências existentes e cole esta resposta.
RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão de Ticks 17
