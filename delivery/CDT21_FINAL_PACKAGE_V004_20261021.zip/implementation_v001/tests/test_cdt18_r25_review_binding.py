"""R25 exact review binding: true B07 evidence, no effect on invalid review."""
from __future__ import annotations
import contextlib, io, tempfile, unittest, hashlib, json, sys
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'candidate/control'))
import RC1R1_SUCCESSOR_MIGRATION as M

class ReviewBinding(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.rr=Path(self.temp.name)
        self.review=self.rr/'review.zip'
        self.review.write_bytes(b'known review fixture with no authority')
        self.raw=self.review.read_bytes()
        self.expected=hashlib.sha256(self.raw).hexdigest().upper()
        self.report={'status':'READY','blockers':[], 'resume_root':str(self.rr),'installed_state':'V002R22'}
        self.rr_before=set(self.rr.iterdir())
    def no_effect(self):
        self.assertEqual(set(self.rr.iterdir()),self.rr_before)
        self.assertFalse((self.rr/'SUCCESSOR_PACKAGE').exists())
        self.assertFalse(any(self.rr.glob('SUCCESSOR_PACKAGE.V002R22_BACKUP.*')))
    def test_no_trusted_review_digest_must_block_before_rename(self):
        with self.assertRaisesRegex(M.Blocked,'REVIEW_PACK_TRUSTED_SHA_REQUIRED'):
            M.apply(self.report,{},b'',review_raw=self.raw)
        self.no_effect()
    def test_all_zero_hash_must_block_before_rename(self):
        with self.assertRaisesRegex(M.Blocked,'REVIEW_PACK_TRUSTED_SHA_REQUIRED'):
            M.apply(self.report,{},b'',review_raw=self.raw,review_expected_sha256='0'*64)
        self.no_effect()
    def test_wrong_sha_must_block_before_rename(self):
        with self.assertRaisesRegex(M.Blocked,'REVIEW_PACK_SHA256_PRE_EFFECT'):
            M.apply(self.report,{},b'',review_raw=self.raw,review_expected_sha256='A'*64)
        self.no_effect()
    def test_unbacked_hash_cannot_become_authority(self):
        class Chain:
            receipt_sha='C'*64
            receipts={'B07':{'evidence':[]}}
            def __init__(self,*a,**k):pass
            def __enter__(self):return self
            def __exit__(self,*a):return False
        import FULL_RELEASE_CHAIN
        with mock.patch.object(M,'inspect',return_value=(self.report,{},b'')), \
             mock.patch.object(M,'native_windows',return_value=True), \
             mock.patch.object(FULL_RELEASE_CHAIN,'ReleaseChain',Chain), \
             contextlib.redirect_stdout(io.StringIO()) as output:
            code=M.main(['--resume-root',str(self.rr),'--successor-zip',str(self.rr/'p.zip'),
                         '--review-pack',str(self.review),'--apply','--chain-file','x',
                         '--chain-sha256','A'*64,'--b06-sha256','B'*64])
        self.assertEqual(code,2)
        self.assertIn('REVIEW_PACK_NOT_IN_PINNED_B07_EVIDENCE',output.getvalue())
        self.no_effect()
    def test_effectful_exception_after_rename_propagates_exit_3(self):
        fake_package=self.rr/'SUCCESSOR_PACKAGE';fake_package.mkdir()
        # The classify/inspect mock returns a plan and does not mutate its own input.
        report=dict(self.report)
        original_rename=M.os.rename
        def fail_after_rename(src,dst):
            original_rename(src,dst)
            raise M.Blocked('INJECTED_FAULT_AFTER_COMMITTED_RENAME')
        out=io.StringIO()
        with mock.patch.object(M,'inspect',return_value=(report,{},b'')), \
             mock.patch.object(M,'native_windows',return_value=True), \
             mock.patch.object(M.os,'rename',fail_after_rename), \
             mock.patch.object(__import__('FULL_RELEASE_CHAIN'),'ReleaseChain') as Chain, \
             contextlib.redirect_stdout(out):
            cm=Chain.return_value.__enter__.return_value
            cm.receipt_sha='C'*64
            rc=M.main(['--resume-root',str(self.rr),'--successor-zip',str(self.rr/'p.zip'),
                       '--apply','--chain-file','x','--chain-sha256','A'*64,'--b06-sha256','B'*64])
        self.assertEqual(rc,3)
        self.assertIn('PARTIAL_EFFECT=POSSIBLE',out.getvalue())
        self.assertIn('INJECTED_FAULT_AFTER_COMMITTED_RENAME',out.getvalue())
        self.assertFalse(fake_package.exists())
        self.assertEqual(len(list(self.rr.glob(M.BACKUP_PREFIX+'*'))),1)
    def test_oserror_after_effect_frontier_is_exit_3(self):
        fake_package=self.rr/'SUCCESSOR_PACKAGE';fake_package.mkdir()
        report=dict(self.report)
        out=io.StringIO()
        with mock.patch.object(M,'inspect',return_value=(report,{},b'')), \
             mock.patch.object(M,'native_windows',return_value=True), \
             mock.patch.object(M.os,'rename',side_effect=OSError('INJECTED_NTFS_DENIAL')), \
             mock.patch.object(__import__('FULL_RELEASE_CHAIN'),'ReleaseChain') as Chain, \
             contextlib.redirect_stdout(out):
            Chain.return_value.__enter__.return_value.receipt_sha='C'*64
            rc=M.main(['--resume-root',str(self.rr),'--successor-zip',str(self.rr/'p.zip'),
                '--apply','--chain-file','x','--chain-sha256','A'*64,'--b06-sha256','B'*64])
        self.assertEqual(rc,3)
        self.assertIn('REASON=INJECTED_NTFS_DENIAL',out.getvalue())
        self.assertTrue(fake_package.exists())  # frontiers are conservative
    def test_preflight_oserror_is_blocked_no_effects(self):
        with mock.patch.object(M,'inspect',side_effect=OSError('UNAVAILABLE_BEFORE_MUTATION')), \
             contextlib.redirect_stdout(io.StringIO()) as output:
            rc=M.main(['--resume-root',str(self.rr),'--successor-zip','x'])
        self.assertEqual(rc,2)
        self.assertIn('PARTIAL_EFFECT=NO',output.getvalue())
    def test_missing_pack_expectation_rejected_before_mutation(self):
        with self.assertRaisesRegex(M.Blocked,'REVIEW_EXPECTATION_WITHOUT_PACK'):
            M.apply(self.report,{},b'',review_expected_sha256=self.expected)
        self.no_effect()

if __name__=='__main__':unittest.main(verbosity=2)
