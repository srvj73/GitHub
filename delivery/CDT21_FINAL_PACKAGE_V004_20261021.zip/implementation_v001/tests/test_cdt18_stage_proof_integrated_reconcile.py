"""CDT18 integration anti-false-pass deltas: physical witnesses and G5 gates.
These tests never issue a production release or a B06 verdict.
"""
import hashlib,json,pathlib,sys,tempfile,unittest
R=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'candidate/control'))
from D4_FIRST_ADMISSION_PREP import canonical,sha,Blocked
from FULL_STAGE_EVIDENCE import checks_from_closed_results, STAGE_CHECK_WITNESSES
from FULL_RELEASE_CHAIN import REQUIRED_CHECKS,validate_chain
from G5_FINAL_COMPLETENESS_PRODUCER import verified_native

class Witness(unittest.TestCase):
    def test_01_all_stage_check_contracts_exhaustive(self):
        for stage in STAGE_CHECK_WITNESSES:
            self.assertEqual(set(STAGE_CHECK_WITNESSES[stage]),set(REQUIRED_CHECKS[stage]))
    def test_02_real_hash_bound_result_referenced_for_every_check(self):
        with tempfile.TemporaryDirectory() as d:
            base=pathlib.Path(d); stage='FULL_PREP';nodes=list(dict.fromkeys(STAGE_CHECK_WITNESSES[stage].values()))
            results={};evidence=[]
            for n in nodes:
                obj={'schema':'TEST_RESULT','node':n,'status':'PASS','observed':True}
                p=base/(n+'.json');p.write_bytes(canonical(obj));results[n]=obj
                evidence.append({'path':str(p),'sha256':sha(p.read_bytes())})
            def pinned(path,expected):
                raw=pathlib.Path(path).read_bytes()
                if sha(raw)!=expected:raise Blocked('MISMATCH')
                return raw
            checks,proofs=checks_from_closed_results(stage,nodes,results,evidence,read=pinned)
            self.assertTrue(all(checks.values()))
            self.assertEqual(len(proofs),len(REQUIRED_CHECKS[stage]))
            self.assertTrue(all(proofs[c]['sha256'] in {e['sha256'] for e in evidence} for c in proofs))
    def test_03_missing_node_evidence_blocks(self):
        with self.assertRaisesRegex(RuntimeError,'STAGE_CHECK_NODE_NOT_CLOSED|STAGE_NODE_EVIDENCE_CARDINALITY'):
            checks_from_closed_results('D5',[],{},[],read=lambda p,h:b'')
    def test_04_corrupted_witness_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'D5.json';p.write_bytes(canonical({'node':'D5'}))
            with self.assertRaisesRegex(RuntimeError,'STAGE_NODE_WITNESS_MISMATCH'):
                checks_from_closed_results('D5',['D5'],{'node':'D5'},
                    [{'path':str(p),'sha256':sha(p.read_bytes())}],read=lambda p,h:pathlib.Path(p).read_bytes())
    def test_05_stage_without_semantic_proofs_cannot_admit(self):
        stages=('G5','B06','B07','D4','D5')
        rows={}; hashes={};prev=None
        for stage in stages:
            ob={'schema':'TICKSTORE_STAGE_RECEIPT_V001','stage':stage,'status':'PASS',
               'environment':'WINDOWS_PRODUCTION','code_manifest_sha256':'A'*64,
               'instance_sha256':'B'*64,'previous_receipt_sha256':prev,'blockers':[],
               'checks':{k:True for k in REQUIRED_CHECKS[stage]},
               'evidence':[{'path':'x','sha256':'E'*64}]}
            if stage=='G5':ob['full_candidate_completeness']='PASS'
            if stage=='B06':ob.update(reviewer='independent',implementation_participant=False)
            rows[stage]=ob;hashes[stage]='C'*64;prev='C'*64
        with self.assertRaisesRegex(RuntimeError,'D5_CHECK_PROOF_SET'):
            validate_chain(rows,hashes,code_sha='A'*64,instance_sha='B'*64,b06_sha='C'*64,until='D5')

if __name__=='__main__':unittest.main(verbosity=2)
