"""CDT21 F-01R1 (V004): frozen legacy processes that built State BEFORE the fence - cut, drain, admission.

Finding of the B06 of V003 (reproduced by the origin on the frozen bytes): LEGACY_ENTRY_FENCE --apply
returned FENCE_PRESENT while a frozen process that had constructed State earlier kept appending
STATE_JOURNAL.jsonl; only new instances were blocked.  Every legacy process here is a real child that
executes the frozen recovery/modules/orchestrator.py (3C16FC13...): State(...), State.log and
State.finish are the frozen functions, called as execute() calls them (STARTED with the frozen run_id).
Owned lab only; no production path is named.

Windows (native G0, elevated): the children run as the same elevated user; the journal is closed by the
DACL DENY ACE and admitted appends use backup semantics.  POSIX test host: the children run as uid 0
with SECBIT_NOROOT (no capability at all, so no CAP_DAC_OVERRIDE) and the ACE is modelled by mode 0444;
the admitted writer keeps CAP_DAC_OVERRIDE.  Without root there is no such model: those tests skip on
POSIX only (a skip on Windows fails the G0 unit).
"""
import ctypes
import datetime
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
import unittest

from test_cdt21_f01_legacy_entry_fence import C, COMMANDS, FENCE_TOOL, FROZEN, Lab, NATIVE, ORCH, sha, snapshot

POSIX_MODEL = not NATIVE and hasattr(os, 'geteuid') and os.geteuid() == 0
MODEL = unittest.skipUnless(NATIVE or POSIX_MODEL, 'POSIX model needs root (native Windows always runs)')
NO_CAPABILITY = '0000000000000000'
STAMP = '2026-10-21T12:00:00.000-03:00'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


E = load('cdt21_f01r1_entry', C / 'adapter/runtime_locator_orchestrator_entry.py')
T = load('cdt21_f01r1_fence_tool', FENCE_TOOL)

CHILD = r'''
import datetime, importlib.util, os, sys
spec = importlib.util.spec_from_file_location("frozen_legacy_orchestrator", sys.argv[1])
m = importlib.util.module_from_spec(spec)
def reply(text):
    sys.stdout.write(text + "\n"); sys.stdout.flush()
caps = "WINDOWS"
if os.name != "nt":
    caps = [l.split()[1] for l in open("/proc/self/status") if l.startswith("CapEff:")][0]
try:
    spec.loader.exec_module(m)
    s = m.State(sys.argv[2])
except BaseException as exc:
    reply("INIT_ERR %s %s" % (type(exc).__name__, exc)); sys.exit(3)
run_id = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3] + "_" + str(os.getpid())  # frozen O.__init__
reply("READY %d %s %s" % (os.getpid(), run_id, caps))
held = None
for line in sys.stdin:
    cmd, _, arg = line.strip().partition(" ")
    try:
        if cmd == "STARTED":
            s.log(arg, "STARTED", run_id=run_id)  # frozen execute(): o.st.log(n, "STARTED", run_id=o.id)
        elif cmd == "LOG":
            s.log("A0", arg, origin="frozen_original_state_object")  # the origin reproducer
        elif cmd == "FINISH":
            s.finish(arg, "PASS", {"node": arg})  # frozen finish(): log FINISHED, then atomj(STATE)
        elif cmd == "HOLD":
            held = open(s.jp, "ab")  # a frozen append in flight: its write handle is open
        elif cmd == "WRITE_HELD":
            ls = s.jp.read_bytes().splitlines()
            prev = m.shab(ls[-1]) if ls else ""
            held.write(m.jb({"ts": m.now(), "node": "D4", "phase": "HELD_APPEND", "prev_line_sha256": prev}).rstrip(b"\n") + b"\n")
            held.flush()
        elif cmd == "CLOSE_HELD":
            held.close(); held = None
        elif cmd == "EXIT":
            reply("OK EXIT"); break
        else:
            raise ValueError(cmd)
        reply("OK " + cmd)
    except BaseException as exc:
        reply("ERR %s %s %s" % (cmd, type(exc).__name__, exc))
'''


def _no_capability():
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(28, 1, 0, 0, 0) != 0:  # PR_SET_SECUREBITS, SECBIT_NOROOT: execve grants uid 0 no capability
        raise OSError(ctypes.get_errno(), 'PR_SET_SECUREBITS')


class Legacy:
    """A frozen legacy process: State built at start, then driven line by line."""

    def __init__(self, test, lab):
        script = lab.root / 'legacy_child.py'
        if not script.exists():
            script.write_text(CHILD, encoding='utf-8')
        extra = {} if NATIVE else {'preexec_fn': _no_capability}
        self.p = subprocess.Popen([sys.executable, '-I', '-B', str(script), str(lab.pkg / 'modules/orchestrator.py'),
                                   str(lab.control)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  stderr=subprocess.DEVNULL, text=True, bufsize=1, cwd=str(lab.root), **extra)
        test.addCleanup(self.close)
        self.first = self._read()
        if self.first.startswith('READY'):
            _, pid, self.run_id, caps = self.first.split()
            test.assertEqual(int(pid), self.p.pid)
            test.assertEqual(caps, 'WINDOWS' if NATIVE else NO_CAPABILITY)

    def _read(self):
        timer = threading.Timer(120, self.p.kill)
        timer.start()
        try:
            line = self.p.stdout.readline()
        finally:
            timer.cancel()
        if not line:
            raise AssertionError('LEGACY_CHILD_NO_REPLY rc=' + str(self.p.poll()))
        return line.strip()

    def cmd(self, text):
        self.p.stdin.write(text + '\n')
        self.p.stdin.flush()
        return self._read()

    def exit(self):
        self.cmd('EXIT')
        self.p.wait(60)
        self.close()

    def close(self):
        if self.p.poll() is None:
            try:
                self.p.stdin.write('EXIT\n')
                self.p.stdin.flush()
                self.p.wait(30)
            except (OSError, subprocess.TimeoutExpired):
                self.p.kill()
                self.p.wait(30)
        for stream in (self.p.stdin, self.p.stdout):
            try:
                stream.close()
            except OSError:
                pass


def frozen_namespace():
    ns = {'__name__': 'cdt21_f01r1_frozen_orchestrator_library', '__file__': str(ORCH)}
    exec(compile(ORCH.read_bytes(), str(ORCH), 'exec'), ns, ns)
    return ns


def chain(raw):
    prev = ''
    for line in raw.splitlines():
        rec = json.loads(line)
        if rec.get('prev_line_sha256') != prev:
            raise AssertionError('JOURNAL_CHAIN_BROKEN at ' + line.decode('ascii', 'replace')[:80])
        prev = sha(line)
    return len(raw.splitlines())


def restore_plain_write(journal):
    if NATIVE:
        icacls = Path(os.environ['SystemRoot']) / 'System32/icacls.exe'
        subprocess.run([str(icacls), str(journal), '/remove:d', '*S-1-1-0'], check=True, capture_output=True, timeout=60)
    else:
        os.chmod(journal, 0o644)
    assert not E.legacy_journal_write_denial(journal)['denied']


class Base(unittest.TestCase):
    def setUp(self):
        for rel, digest in FROZEN.items():
            self.assertEqual(sha((C / rel).read_bytes()), digest, 'frozen successor bytes changed: ' + rel)
        self.lab = self.new_lab()

    def new_lab(self):
        t = tempfile.TemporaryDirectory(prefix='cdt21_f01r1_')
        self.addCleanup(t.cleanup)
        lab = Lab(t.name)
        lab.layout()
        lab.d4_state()
        return lab

    def tool(self, lab=None, *extra):
        lab = lab or self.lab
        p = subprocess.run([sys.executable, '-B', '-I', str(FENCE_TOOL), '--state', str(lab.sp),
                            '--adapter-dir', str(C / 'adapter'), *extra], capture_output=True, text=True, timeout=300,
                           cwd=str(lab.root))
        return p.returncode, json.loads(p.stdout)

    def authority(self, lab=None):
        lab = lab or self.lab
        return {'config_path': str(lab.config_path), 'config_sha256': sha(lab.config_path.read_bytes())}

    def admitted_start(self, lab=None):
        lab = lab or self.lab
        cfg_raw = lab.config_path.read_bytes()
        raw, ident = E.read_pinned_regular(lab.sp, 'TEST_STATE')
        return E.AdmittedStart(lab.sp, lab.control, lab.config_path, cfg_raw, sha(cfg_raw),
                               E._ident(os.lstat(lab.config_path)), raw, ident)

    def valid(self, obj):
        self.assertEqual(obj.get('schema'), 'TICKSTORE_ORCH_STATE_V001')

    def record(self, lab=None):
        lab = lab or self.lab
        return json.loads((lab.fence / E.LEGACY_JOURNAL_CUT_RECORD).read_bytes())

    def assertDenied(self, reply, cmd):
        self.assertTrue(reply.startswith('ERR ' + cmd + ' PermissionError'), reply)


@MODEL
class F01R1LegacyAlreadyActive(Base):
    def test_50_origin_scenario_old_legacy_can_no_longer_append(self):
        # The origin reproducer: State built and one line appended before the fence, append after the fence.
        child = Legacy(self, self.lab)
        self.assertEqual(child.cmd('LOG LEGACY_PRE_FENCE'), 'OK LOG')
        state_before, journal_before = self.lab.sp.read_bytes(), self.lab.jp.read_bytes()
        code, rep = self.tool(None, '--apply')
        self.assertEqual((code, rep['decision'], rep['applied']), (0, 'FENCE_PRESENT', True), rep)
        # Physical evidence first: the process that built State before the fence can no longer append.
        self.assertDenied(child.cmd('LOG LEGACY_APPEND_AFTER_FENCE'), 'LOG')
        self.assertDenied(child.cmd('STARTED D4'), 'STARTED')
        self.assertEqual((self.lab.sp.read_bytes(), self.lab.jp.read_bytes()), (state_before, journal_before))
        self.assertTrue(rep['frozen_write_denied'] and rep['frozen_append_denied'])
        self.assertEqual(rep['drain']['runs'], [])  # no legacy node was in flight at the cut
        self.assertEqual(self.record()['journal_at_cut']['sha256'], sha(journal_before))
        late = Legacy(self, self.lab)  # a new legacy instance cannot even build State
        self.assertTrue(late.first.startswith('INIT_ERR'), late.first)
        self.assertIn('STATE.json.partial', late.first)
        self.assertEqual((self.lab.sp.read_bytes(), self.lab.jp.read_bytes()), (state_before, journal_before))
        child.exit()
        self.assertEqual(self.tool()[1]['decision'], 'FENCE_PRESENT')

    def test_51_legacy_node_in_flight_blocks_admission_until_its_identity_is_gone(self):
        child = Legacy(self, self.lab)
        self.assertEqual(child.cmd('STARTED D4'), 'OK STARTED')
        code, rep = self.tool(None, '--apply')
        self.assertEqual((code, rep['decision'], rep['applied']), (2, 'CUT_PRESENT_LEGACY_RUN_NOT_DRAINED', True), rep)
        self.assertEqual(rep['drain']['not_drained'], [child.run_id + '/' + str(child.p.pid) + '/POSSIBLY_ALIVE'])
        state_cut, journal_cut = self.lab.sp.read_bytes(), self.lab.jp.read_bytes()
        with self.assertRaisesRegex(RuntimeError, 'LEGACY_RUN_POSSIBLY_ACTIVE:' + child.run_id):
            E.validate_d4_start(self.lab.pkg, sys.executable, self.authority())
        ns = frozen_namespace()
        frozen_state = ns['State']
        with self.assertRaisesRegex(RuntimeError, 'LEGACY_RUN_POSSIBLY_ACTIVE'):
            E.guard_frozen_state_reads(ns, self.admitted_start(), state_validator=self.valid)
        self.assertIs(ns['State'], frozen_state)  # refused before any frozen name is replaced
        # The in-flight legacy can neither close its node nor write STATE: frozen finish() logs first.
        self.assertDenied(child.cmd('FINISH D4'), 'FINISH')
        self.assertDenied(child.cmd('STARTED D5'), 'STARTED')
        self.assertEqual((self.lab.sp.read_bytes(), self.lab.jp.read_bytes()), (state_cut, journal_cut))
        self.assertEqual(self.tool()[1]['decision'], 'CUT_PRESENT_LEGACY_RUN_NOT_DRAINED')
        child.exit()
        code, rep = self.tool()
        self.assertEqual((code, rep['decision']), (0, 'FENCE_PRESENT'), rep)
        self.assertTrue(rep['drain']['runs'][0]['verdict'].startswith('GONE_'), rep['drain'])
        self.assertNotIn('applied', rep)
        admitted = E.validate_d4_start(self.lab.pkg, sys.executable, self.authority())
        self.assertEqual(admitted.state_raw, state_cut)

    def test_52_write_handle_open_at_the_cut_is_refused_and_no_record_is_written(self):
        child = Legacy(self, self.lab)
        self.assertEqual(child.cmd('HOLD'), 'OK HOLD')
        started = time.monotonic()
        code, rep = self.tool(None, '--apply')
        self.assertEqual((code, rep['decision']), (2, 'BLOCKED_MANUAL'), rep)
        self.assertIn('LEGACY_JOURNAL_WRITER_OPEN_AT_CUT', rep['reasons'])
        self.assertGreater(time.monotonic() - started, T.PROBE_ATTEMPTS * T.PROBE_INTERVAL_S * 0.8)
        self.assertFalse((self.lab.fence / E.LEGACY_JOURNAL_CUT_RECORD).exists())
        self.assertEqual(self.tool()[1]['decision'], 'FENCE_CUT_INCOMPLETE_INSTALLABLE')
        with self.assertRaisesRegex(RuntimeError, 'LEGACY_JOURNAL_CUT_RECORD_MISSING'):
            E.validate_d4_start(self.lab.pkg, sys.executable, self.authority())
        # Why the probe is required: a handle opened before the DENY keeps its write access.
        before = self.lab.jp.read_bytes()
        self.assertEqual(child.cmd('WRITE_HELD'), 'OK WRITE_HELD')
        self.assertNotEqual(self.lab.jp.read_bytes(), before)
        self.assertEqual(child.cmd('CLOSE_HELD'), 'OK CLOSE_HELD')
        code, rep = self.tool(None, '--apply')
        self.assertEqual((code, rep['decision'], rep['applied']), (0, 'FENCE_PRESENT', True), rep)
        self.assertEqual(self.record()['journal_at_cut']['sha256'], sha(self.lab.jp.read_bytes()))
        frozen = self.lab.jp.read_bytes()
        self.assertDenied(child.cmd('HOLD'), 'HOLD')
        self.assertDenied(child.cmd('LOG AFTER_CUT'), 'LOG')
        self.assertEqual(self.lab.jp.read_bytes(), frozen)
        chain(frozen)

    def test_53_legacy_activity_between_diagnosis_and_cut_is_reported_and_bound(self):
        # TOCTOU window: the legacy appends STARTED after the tool's last diagnosis, just before the DENY.
        child = Legacy(self, self.lab)
        entry = load('cdt21_f01r1_entry_toctou', C / 'adapter/runtime_locator_orchestrator_entry.py')
        real = entry.deny_legacy_journal_writes

        def race_then_deny(journal):
            self.assertEqual(child.cmd('STARTED D4'), 'OK STARTED')
            real(journal)

        entry.deny_legacy_journal_writes = race_then_deny
        rep = T.diagnose(self.lab.sp, entry)
        self.assertEqual(rep['decision'], 'FENCE_ABSENT_INSTALLABLE')
        result = T.apply(self.lab.sp, rep, entry, FENCE_TOOL.read_bytes(),
                         (C / 'adapter/runtime_locator_orchestrator_entry.py').read_bytes())
        self.assertEqual(result['decision'], 'CUT_PRESENT_LEGACY_ACTIVITY_DURING_CUT', result)
        self.assertIn('LEGACY_JOURNAL_ACTIVITY_DURING_CUT', result['reasons'])
        record = self.record()
        self.assertTrue(record['journal_changed_during_cut'])
        self.assertEqual(record['journal_at_cut']['sha256'], sha(self.lab.jp.read_bytes()))  # the STARTED is in the cut
        self.assertEqual(result['drain']['not_drained'], [child.run_id + '/' + str(child.p.pid) + '/POSSIBLY_ALIVE'])
        frozen = self.lab.jp.read_bytes()
        self.assertDenied(child.cmd('FINISH D4'), 'FINISH')
        self.assertEqual(self.lab.jp.read_bytes(), frozen)
        child.exit()
        self.assertEqual(self.tool()[1]['decision'], 'FENCE_PRESENT')

    def test_54_new_legacy_entries_after_the_cut_blocked_before_any_effect(self):
        self.assertEqual(self.tool(None, '--apply')[0], 0)
        before = snapshot(self.lab.control)
        late = Legacy(self, self.lab)
        self.assertTrue(late.first.startswith('INIT_ERR') and 'STATE.json.partial' in late.first, late.first)
        for command in COMMANDS:
            r = self.lab.frozen(command)
            self.assertNotEqual(r.returncode, 0, command)
            self.assertIn('STATE.json.partial', r.stderr, command)
        self.assertEqual(snapshot(self.lab.control), before)
        self.assertEqual(self.tool()[1]['decision'], 'FENCE_PRESENT')


@MODEL
class F01R1ConcurrentAdmission(Base):
    def test_55_two_concurrent_installs_produce_one_cut(self):
        cmd = [sys.executable, '-B', '-I', str(FENCE_TOOL), '--state', str(self.lab.sp), '--adapter-dir', str(C / 'adapter'),
               '--apply']
        procs = [subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, cwd=str(self.lab.root))
                 for _ in range(2)]
        out = []
        for p in procs:
            so, _ = p.communicate(timeout=300)
            out.append((p.returncode, json.loads(so)))
        applied = [rep for code, rep in out if rep.get('applied')]
        self.assertEqual(len(applied), 1, out)
        self.assertEqual(applied[0]['decision'], 'FENCE_PRESENT')
        for code, rep in out:
            if not rep.get('applied'):  # lost the boundary, saw the evidence change, or came after the winner
                self.assertIn(rep['decision'], ('FENCE_PRESENT', 'BLOCKED_MANUAL'), rep)
        self.assertEqual(sorted(os.listdir(self.lab.fence)), sorted([E.LEGACY_ENTRY_FENCE_MARKER, E.LEGACY_JOURNAL_CUT_RECORD]))
        self.assertEqual(self.tool()[1]['decision'], 'FENCE_PRESENT')

    def test_56_install_refused_while_an_admitted_entry_holds_the_state(self):
        release = E.acquire_state_boundary(self.lab.sp)
        try:
            code, rep = self.tool(None, '--apply')
        finally:
            release()
        self.assertEqual((code, rep['decision']), (2, 'BLOCKED_MANUAL'))
        self.assertTrue(any('BOUNDARY_BUSY' in r for r in rep['reasons']), rep)
        self.assertFalse(os.path.lexists(self.lab.fence))
        self.assertTrue(E.legacy_journal_write_denial(self.lab.jp)['denied'] is False)

    def test_57_admission_order_before_cut_incomplete_cut_and_complete_cut(self):
        with self.assertRaisesRegex(RuntimeError, 'LEGACY_ENTRY_FENCE_MISSING'):
            E.validate_d4_start(self.lab.pkg, sys.executable, self.authority())
        # A V003 fence (directory + marker, no journal cut) is not enough any more.
        self.lab.fence.mkdir()
        marker = {'schema': E.LEGACY_ENTRY_FENCE_SCHEMA, 'state_name': 'STATE.json', 'fence_name': 'STATE.json.partial'}
        (self.lab.fence / E.LEGACY_ENTRY_FENCE_MARKER).write_text(json.dumps(marker))
        self.assertEqual(self.tool()[1]['decision'], 'FENCE_CUT_INCOMPLETE_INSTALLABLE')
        with self.assertRaisesRegex(RuntimeError, 'LEGACY_JOURNAL_CUT_RECORD_MISSING'):
            E.validate_d4_start(self.lab.pkg, sys.executable, self.authority())
        code, rep = self.tool(None, '--apply')
        self.assertEqual((code, rep['decision'], rep['applied']), (0, 'FENCE_PRESENT', True), rep)
        E.validate_d4_start(self.lab.pkg, sys.executable, self.authority())


@MODEL
class F01R1AdmittedJournalWriter(Base):
    def cut(self, lab=None):
        code, rep = self.tool(lab, '--apply')
        self.assertEqual((code, rep['decision']), (0, 'FENCE_PRESENT'), rep)

    def test_60_admitted_append_is_the_frozen_line_and_cut_stays_closed(self):
        self.cut()
        reference = self.lab.root / 'reference'
        reference.mkdir()
        ref = reference / 'STATE_JOURNAL.jsonl'
        ref.write_bytes(self.lab.jp.read_bytes())
        frozen = frozen_namespace()
        frozen['now'] = lambda: STAMP
        st = object.__new__(frozen['State'])
        st.jp = ref
        live = '20261021_120000_000_1'  # PID 1 is alive: after the cut it must not influence the drain
        frozen['State'].log(st, 'D4', 'STARTED', run_id=live)
        frozen['State'].log(st, 'D4', 'FINISHED', status='FAIL', result_sha256=None, primary_error='LAB')
        ns = frozen_namespace()
        ns['now'] = lambda: STAMP
        E.guard_frozen_state_reads(ns, self.admitted_start(), state_validator=self.valid)
        try:
            s = ns['State'](self.lab.control)
            s.log('D4', 'STARTED', run_id=live)
            s.log('D4', 'FINISHED', status='FAIL', result_sha256=None, primary_error='LAB')
        finally:
            ns['_TICKSTORE_D4_ENTRY_RELEASE_STATE_BOUNDARY']()
        self.assertEqual(self.lab.jp.read_bytes(), ref.read_bytes())
        chain(self.lab.jp.read_bytes())
        E.require_legacy_journal_cut_enforced(self.lab.jp)
        self.assertEqual(E.require_legacy_entry_fence(self.lab.sp)['status'], 'DRAINED')
        self.assertEqual(self.tool()[1]['decision'], 'FENCE_PRESENT')

    def test_61_admitted_append_and_commit_refused_when_the_cut_is_broken(self):
        def drop_record(lab):
            (lab.fence / E.LEGACY_JOURNAL_CUT_RECORD).unlink()

        def reopen(lab):
            restore_plain_write(lab.jp)

        def rewrite_prefix(lab):
            restore_plain_write(lab.jp)
            raw = bytearray(lab.jp.read_bytes())
            raw[raw.index(b'FAIL')] = ord('f')
            lab.jp.write_bytes(bytes(raw))
            E.deny_legacy_journal_writes(lab.jp)

        def replace_journal(lab):
            twin = lab.jp.with_name('STATE_JOURNAL.jsonl.twin')
            twin.write_bytes(lab.jp.read_bytes())
            os.replace(twin, lab.jp)
            E.deny_legacy_journal_writes(lab.jp)

        def bad_record_binding(lab):
            p = lab.fence / E.LEGACY_JOURNAL_CUT_RECORD
            rec = json.loads(p.read_bytes())
            rec['fence_marker_sha256'] = '0' * 64
            p.write_text(json.dumps(rec))

        def bad_record_json(lab):
            (lab.fence / E.LEGACY_JOURNAL_CUT_RECORD).write_bytes(b'{"half":')

        variants = ((drop_record, 'LEGACY_JOURNAL_CUT_RECORD_MISSING'), (reopen, 'LEGACY_JOURNAL_CUT_NOT_ENFORCED'),
                    (rewrite_prefix, 'LEGACY_JOURNAL_CUT_PREFIX_CHANGED'), (replace_journal, 'LEGACY_JOURNAL_CUT_IDENTITY'),
                    (bad_record_binding, 'LEGACY_JOURNAL_CUT_RECORD_CONTENT'),
                    (bad_record_json, 'LEGACY_JOURNAL_CUT_RECORD_JSON'))
        for breaker, reason in variants:
            with self.subTest(breaker.__name__):
                lab = self.new_lab()
                self.cut(lab)
                ns = frozen_namespace()
                E.guard_frozen_state_reads(ns, self.admitted_start(lab), state_validator=self.valid)
                try:
                    s = ns['State'](lab.control)
                    breaker(lab)
                    state, journal = lab.sp.read_bytes(), lab.jp.read_bytes()
                    with self.assertRaisesRegex(RuntimeError, reason):
                        s.log('D4', 'STARTED', run_id='20261021_120000_000_1')
                    s.d['engineering_checkpoint'] = 1
                    with self.assertRaisesRegex(RuntimeError, reason):
                        ns['atomj'](s.sp, s.d)
                    self.assertEqual((lab.sp.read_bytes(), lab.jp.read_bytes()), (state, journal))
                    self.assertEqual(sorted(n for n in os.listdir(lab.sd) if '.cas-' in n), [])
                finally:
                    ns['_TICKSTORE_D4_ENTRY_RELEASE_STATE_BOUNDARY']()
                with self.assertRaisesRegex(RuntimeError, reason):
                    E.validate_d4_start(lab.pkg, sys.executable, self.authority(lab))
                self.assertNotEqual(self.tool(lab)[1]['decision'], 'FENCE_PRESENT')

    def test_62_legacy_refused_while_admitted_writer_appends_and_commits(self):
        child = Legacy(self, self.lab)
        self.cut()
        ns = frozen_namespace()
        E.guard_frozen_state_reads(ns, self.admitted_start(), state_validator=self.valid)
        try:
            s = ns['State'](self.lab.control)
            at_cut = self.lab.jp.read_bytes()
            s.log('D4', 'STARTED', run_id='20261021_120000_000_' + str(os.getpid()))
            self.assertDenied(child.cmd('LOG CONCURRENT_LEGACY'), 'LOG')
            s.finish('D4', 'FAIL', error='LAB_ADMITTED_ATTEMPT')  # frozen finish: admitted log + CAS commit
            self.assertDenied(child.cmd('FINISH D4'), 'FINISH')
            committed = self.lab.sp.read_bytes()
            self.assertEqual(json.loads(committed)['status'], 'FAIL')
        finally:
            ns['_TICKSTORE_D4_ENTRY_RELEASE_STATE_BOUNDARY']()
        raw = self.lab.jp.read_bytes()
        self.assertTrue(raw.startswith(at_cut))
        added = [json.loads(line) for line in raw[len(at_cut):].splitlines()]
        self.assertEqual([(r['node'], r['phase']) for r in added], [('D4', 'STARTED'), ('D4', 'FINISHED')])
        chain(raw)
        self.assertEqual(self.lab.sp.read_bytes(), committed)
        self.assertEqual(sorted(n for n in os.listdir(self.lab.sd) if '.cas-' in n), [])
        child.exit()


class F01R1DrainRule(unittest.TestCase):
    def line(self, prev, **fields):
        ns = frozen_namespace()
        return ns['jb'](dict(fields, prev_line_sha256=prev)).rstrip(b'\n')

    def journal(self, *records):
        out, prev = [], ''
        for rec in records:
            out.append(self.line(prev, **rec))
            prev = sha(out[-1])
        return b'\n'.join(out) + b'\n'

    def test_70_runs_are_the_started_lines_of_the_frozen_execute(self):
        raw = self.journal({'ts': '2026-10-20T10:00:00.000-03:00', 'node': 'D3', 'phase': 'STARTED', 'run_id': '20261020_095959_001_4242'},
                           {'ts': '2026-10-20T10:01:00.000-03:00', 'node': 'D3', 'phase': 'FINISHED', 'status': 'PASS'},
                           {'ts': '2026-10-20T10:01:01.000-03:00', 'node': 'D4', 'phase': 'STARTED', 'run_id': '20261020_095959_001_4242'},
                           {'ts': 'lab', 'node': 'A0', 'phase': 'LEGACY_PRE_FENCE'},
                           {'ts': '2026-10-21T08:00:00.500+00:00', 'node': 'D4', 'phase': 'STARTED', 'run_id': '20261021_075959_999_77'})
        runs = E.legacy_runs_in_journal(raw)
        self.assertEqual([(r['run_id'], r['pid'], r['started_lines'], r['nodes']) for r in runs],
                         [('20261020_095959_001_4242', 4242, 2, ['D3', 'D4']), ('20261021_075959_999_77', 77, 1, ['D4'])])
        when = datetime.datetime(2026, 10, 20, 13, 0, tzinfo=datetime.timezone.utc)
        self.assertEqual(runs[0]['first_started_ns'], int(when.timestamp()) * 1_000_000_000)
        self.assertEqual(runs[0]['first_started_line'], 1)

    def test_71_unreadable_evidence_never_drains(self):
        cases = ((b'not json\n', 'LEGACY_JOURNAL_LINE_NOT_JSON:1'), (b'[1]\n', 'LEGACY_JOURNAL_LINE_NOT_OBJECT:1'),
                 (self.journal({'ts': '2026-10-20T10:00:00.000-03:00', 'node': 'D4', 'phase': 'STARTED'}), 'LEGACY_RUN_ID_UNREADABLE:1'),
                 (self.journal({'ts': '2026-10-20T10:00:00.000-03:00', 'node': 'D4', 'phase': 'STARTED', 'run_id': 'abc'}),
                  'LEGACY_RUN_ID_UNREADABLE:1'),
                 (self.journal({'ts': '2026-10-20T10:00:00', 'node': 'D4', 'phase': 'STARTED', 'run_id': '20261020_095959_001_1'}),
                  'LEGACY_STARTED_TS_UNREADABLE:1'))
        for raw, reason in cases:
            with self.subTest(reason):
                with self.assertRaisesRegex(RuntimeError, reason):
                    E.legacy_drain(raw, observe=lambda pid: ('ABSENT', None))

    def test_72_identity_classification_and_margin(self):
        run = {'pid': 4242, 'first_started_ns': 1_000 * 1_000_000_000}
        margin = E.LEGACY_DRAIN_CLOCK_MARGIN_NS
        cases = ((('ABSENT', None), 'GONE_NO_PROCESS'), (('EXITED', None), 'GONE_EXITED'),
                 (('LIVE', run['first_started_ns'] - 5_000_000_000), 'POSSIBLY_ALIVE'),
                 (('LIVE', run['first_started_ns'] + margin), 'POSSIBLY_ALIVE'),
                 (('LIVE', run['first_started_ns'] + margin + 1), 'GONE_PID_REUSED_BY_LATER_PROCESS'),
                 (('UNREADABLE:5', None), 'UNREADABLE'))
        for observation, verdict in cases:
            with self.subTest(observation):
                self.assertEqual(E.classify_legacy_run(run, observation, self_pid=1), verdict)
        self.assertEqual(E.classify_legacy_run(dict(run, pid=7), ('LIVE', 0), self_pid=7), 'GONE_PID_IS_THIS_PROCESS')
        raw = self.journal({'ts': '2026-10-20T10:00:00.000-03:00', 'node': 'D4', 'phase': 'STARTED', 'run_id': '20261020_095959_001_4242'})
        self.assertEqual(E.legacy_drain(raw, observe=lambda pid: ('UNREADABLE:5', None))['status'], 'NOT_DRAINED')
        self.assertEqual(E.legacy_drain(raw, observe=lambda pid: ('EXITED', None))['status'], 'DRAINED')
        self.assertEqual(E.legacy_drain(b'', observe=lambda pid: 1 / 0)['status'], 'DRAINED')

    def test_73_real_process_identities(self):
        state, created = E.observe_process(os.getpid())
        self.assertEqual(state, 'LIVE')
        self.assertLessEqual(created, time.time_ns() + 2_000_000_000)
        sleeper = subprocess.Popen([sys.executable, '-I', '-B', '-c', 'import time; time.sleep(60)'])
        try:
            run = {'pid': sleeper.pid, 'first_started_ns': time.time_ns()}
            self.assertEqual(E.classify_legacy_run(run, E.observe_process(sleeper.pid), os.getpid()), 'POSSIBLY_ALIVE')
        finally:
            sleeper.kill()
            sleeper.wait(30)
        self.assertTrue(E.classify_legacy_run(run, E.observe_process(sleeper.pid), os.getpid()).startswith('GONE_'))


@unittest.skipUnless(NATIVE, 'Windows DACL, backup semantics and thread token (G0)')
class F01R1WindowsNative(Base):
    def test_80_native_deny_ace_backup_writer_and_no_lingering_privilege(self):
        code, rep = self.tool(None, '--apply')
        self.assertEqual((code, rep['decision']), (0, 'FENCE_PRESENT'), rep)
        denial = rep['write_denial']
        self.assertTrue(denial['explicit_deny_ace_everyone'], denial)
        self.assertEqual(set(denial['plain_open_for_write'].values()), {'ACCESS_DENIED'})
        self.assertIn('WD)', denial['sddl'])
        for mode in ('ab', 'r+b', 'wb'):
            with self.assertRaises(PermissionError):
                open(self.lab.jp, mode)
        with self.assertRaises(PermissionError):
            os.open(self.lab.jp, os.O_WRONLY)
        self.assertEqual(self.lab.jp.read_bytes(), self.lab.jp.read_bytes())  # reading stays allowed
        line = E.append_admitted_journal_line(self.lab.jp, lambda prev: (json.dumps(
            {'node': 'D4', 'phase': 'LAB', 'prev_line_sha256': prev, 'ts': STAMP}, sort_keys=True,
            separators=(',', ':')) + '\n').encode('ascii'))
        self.assertTrue(self.lab.jp.read_bytes().endswith(line))
        k = ctypes.WinDLL('kernel32', use_last_error=True)
        a = ctypes.WinDLL('advapi32', use_last_error=True)
        k.GetCurrentThread.restype = ctypes.c_void_p
        a.OpenThreadToken.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.POINTER(ctypes.c_void_p)]
        token = ctypes.c_void_p()
        self.assertFalse(a.OpenThreadToken(k.GetCurrentThread(), 0x0008, True, ctypes.byref(token)))
        self.assertEqual(ctypes.get_last_error(), 1008)  # ERROR_NO_TOKEN: the impersonation ended with the open
        with self.assertRaises(PermissionError):
            open(self.lab.jp, 'ab')
        chain(self.lab.jp.read_bytes())


if __name__ == '__main__':
    unittest.main()
