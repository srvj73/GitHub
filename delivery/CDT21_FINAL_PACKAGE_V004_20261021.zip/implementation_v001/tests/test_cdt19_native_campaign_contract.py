"""Harness contracts only; these tests never constitute Windows execution proof."""
import copy
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]/'candidate'
sys.path.insert(0,str(ROOT/'g5proof'))
import PRE_G06_CAMPAIGN as C
import PRE_G06_PROOF_PROJECTION as P
import PRE_G06_CONSUMERS as E
import FULL_CRASH_RECOVERY as R


class Campaign(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)

    def test_committed_same_bytes_reused(self):
        (self.root/'COMMITS').mkdir();p=self.root/'log';p.write_bytes(b'physical log')
        obj=dict(schema='CDT19_NATIVE_UNIT_COMMIT_V001',package_sha256='A'*64,code_sha256='B'*64,
                 result={'status':'PASS','exit_code':0},own_descendants_final=[],artifacts=[C.physical(p,self.root)])
        R.publish(self.root/'COMMITS/UNIT.json',obj)
        self.assertEqual(C.run_unit(dict(root=str(self.root),key='UNIT',package_sha256='A'*64,
            code_sha256='B'*64)),obj['result'])

    def test_chain_run_id_tamper_fails_before_archive_projection(self):
        import FULL_G5_COMPLETE_PROOF_GATE as G
        import hashlib
        name='R08_Q1_20261019165536_ff043e3870e0'
        evidence={'schema':'TICKSTORE_PRE_B06_11_CONSUMER_EVIDENCE_V002',
                  'code_manifest_sha256':'A'*64, 'run_id':'0'*32}
        raw=R.encoded(evidence)
        member='EVIDENCE/PRE_B06/ELEVEN_CONSUMERS.json'
        ref={'member':member,'sha256':R.sha(raw),'bytes':len(raw)}
        with self.assertRaisesRegex(Exception,'PRE_B06_CONSUMER_RUN_BINDING'):
            G.verify_pre_b06_v002({member:raw},
                {'pre_b06_11_receipt':ref,'run_id':name},'A'*64,'B'*64,{}, {})
        self.assertEqual(C.consumer_evidence_run_id(name),
                         hashlib.sha256(name.encode('ascii')).hexdigest()[:32])

    def test_cross_package_commit_cannot_be_rebound(self):
        (self.root/'COMMITS').mkdir()
        p=self.root/'log';p.write_bytes(b'physical PASS log')
        R.publish(self.root/'COMMITS/UNIT.json',dict(
            schema='CDT19_NATIVE_UNIT_COMMIT_V001',package_sha256='A'*64,
            code_sha256='B'*64,result={'status':'PASS','exit_code':0},
            own_descendants_final=[],artifacts=[C.physical(p,self.root)]))
        with self.assertRaisesRegex(Exception,'COMMITTED_INPUT_DRIFT'):
            C.run_unit(dict(root=str(self.root),key='UNIT',package_sha256='C'*64,code_sha256='B'*64))
        self.assertEqual(p.read_bytes(),b'physical PASS log')

    def test_failed_unit_cannot_be_reused(self):
        (self.root/'COMMITS').mkdir();p=self.root/'log';p.write_bytes(b'failure')
        R.publish(self.root/'COMMITS/UNIT.json',dict(schema='CDT19_NATIVE_UNIT_COMMIT_V001',
            package_sha256='A'*64,code_sha256='B'*64,result={'status':'BLOCKED','exit_code':2},
            own_descendants_final=[],artifacts=[C.physical(p,self.root)]))
        with self.assertRaisesRegex(Exception,'COMMITTED_UNIT_NOT_CLOSED'):
            C.run_unit(dict(root=str(self.root),key='UNIT',package_sha256='A'*64,code_sha256='B'*64))

    def test_changed_log_blocks_reuse(self):
        (self.root/'COMMITS').mkdir();p=self.root/'log';p.write_bytes(b'PASS')
        ref=C.physical(p,self.root);p.write_bytes(b'FAIL')
        R.publish(self.root/'COMMITS/UNIT.json',dict(schema='CDT19_NATIVE_UNIT_COMMIT_V001',
            package_sha256='A'*64,code_sha256='B'*64,result={'status':'PASS','exit_code':0},
            own_descendants_final=[],artifacts=[ref]))
        with self.assertRaisesRegex(Exception,'PHYSICAL_REF_DRIFT'):
            C.run_unit(dict(root=str(self.root),key='UNIT',package_sha256='A'*64,code_sha256='B'*64))

    def test_absolute_evidence_escape_blocks(self):
        with self.assertRaises(Exception):C.read_ref({'member':'../outside','sha256':'A'*64,'bytes':1},self.root)

    def test_nested_evidence_projection_rehashes_every_parent(self):
        e=self.root/'EVIDENCE/CONSUMERS';e.mkdir(parents=True)
        leaf=e/'leaf.bin';leaf.write_bytes(b'original physical transition')
        nested=e/'inner.json';nested.write_bytes(R.encoded({'readback':C.physical(leaf,e)}))
        outer=e/'outer.json';outer.write_bytes(R.encoded({'transition':C.physical(nested,e)}))
        src=e/'runner.py';src.write_bytes(b'print("safe")\n')
        row={k:C.physical(outer,e) for k in ('execution_witness','negative_controls','internal_branch_execution','code_path_review')}
        row['runner_source']=C.physical(src,e)
        original=R.encoded({'consumers':[row]});(e/'ELEVEN_CONSUMERS.json').write_bytes(original)
        ref=C.project_consumer_refs(self.root);d=json.loads(C.read_ref(ref,self.root))
        self.assertEqual(ref['member'],'EVIDENCE/PRE_B06/ELEVEN_CONSUMERS.json')
        evidence_root=self.root/'EVIDENCE/PRE_B06'
        first=json.loads(C.read_ref(d['consumers'][0]['execution_witness'],evidence_root))
        second=json.loads(C.read_ref(first['transition'],evidence_root))
        self.assertEqual(C.read_ref(second['readback'],evidence_root),leaf.read_bytes())
        self.assertEqual((e/'ELEVEN_CONSUMERS.json').read_bytes(),original)

    def test_python_guard_negative_does_not_accept_success(self):
        with self.assertRaisesRegex(Exception,'NEGATIVE_WAS_ACCEPTED'):E.denied(lambda:None)

    def test_inline_composes_actual_engine_and_blocks_hash_drift(self):
        out,positive,negative,expected=E.python_operations(ROOT,'adapter/runtime_locator_inline_entry.py',self.root)
        positive();self.assertTrue(out.is_file());before=out.read_bytes()
        self.assertTrue(E.denied(negative,expected)['rejected'])
        self.assertEqual(out.read_bytes(),before)

    def test_caller_guard_rejects_foreign_owner(self):
        R.publish(self.root/'OWNER.json',{'run_id':'owned'})
        with self.assertRaisesRegex(Exception,'FOREIGN_OWNER'):
            E.scoped(self.root,'0'*64,self.root/'effect',lambda:self.fail('effect reached'))

    def test_linux_cannot_issue_native_projection(self):
        if os.name=='nt':
            # Windows still cannot produce without actual source evidence.
            with self.assertRaises(Exception):P.produce(self.root,'A'*64,'B'*64)
        else:
            with self.assertRaisesRegex(Exception,'WINDOWS_REQUIRED'):P.produce(self.root,'A'*64,'B'*64)

    def test_clean_or_empty_summary_cannot_claim_death_resume(self):
        for summary in ({'status':'PASS'},dict(schema='CDT19_G3_G6_NATIVE_SCENARIOS_V001',status='PASS',
                native_windows=True,operational_authority=False,production_modified=False,
                results={'baseline':{'status':'PASS'},'scenarios':[]})):
            with self.subTest(summary=summary),self.assertRaises(Exception):P.validate(summary)

    def test_legacy_engine_cannot_admit_arbitrary_existing_roots(self):
        import G5_MULTIWORK_SCENARIOS as legacy
        # Q1: a negative outside-owned-root must be structurally complete and
        # really outside LOCALAPPDATA/CDT19_R08, not merely outside run/TEMP.
        # Do not widen the accepted exceptions to PATH_CHAIN_MISSING.
        lab_base=Path(os.environ['LOCALAPPDATA']).absolute()/'CDT20_R08' if os.name=='nt' else self.root
        fixture_parent=Path(os.environ['LOCALAPPDATA']).absolute() if os.name=='nt' else self.root
        with tempfile.TemporaryDirectory(prefix='CDT19_Q1_OUTSIDE_R08_',dir=str(fixture_parent)) as q:
            outside=Path(q)
            self.assertFalse(outside.is_relative_to(lab_base)) if os.name=='nt' else None
            fx={'root':outside,**{k:outside/k for k in ('source','dest','scratch')}}
            for key in ('source','dest','scratch'):
                fx[key].mkdir()
            sentinel=outside/'sentinel';sentinel.write_bytes(b'PRESERVE')
            expected=('LEGACY_ENGINE_OUTSIDE_OWNED_R08' if os.name=='nt'
                      else 'NATIVE_G3_G6_WINDOWS_REQUIRED')
            with self.assertRaisesRegex(Exception,'^'+expected+'$'):
                legacy.run_engine(R.core,None,None,fx,'test','1')
            self.assertEqual(sentinel.read_bytes(),b'PRESERVE')
            self.assertEqual({p.name for p in outside.iterdir()},
                             {'source','dest','scratch','sentinel'})

if __name__=='__main__':unittest.main(verbosity=2)
