"""Synthetic contract alignment only: never actual owner G5 issuance / Windows production proof.

The final G5 binding path must consume the same exact physical evidence shape
as FULL_RELEASE_CHAIN. Negative checks must fail closed when that bridge drifts.
"""
import json
import pathlib
import sys
import unittest

R=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'candidate/control'))
from ORIGIN_DECISION_BINDER import _check_native_chain,_check_evidence_semantics,DecisionBlocked
from tests.test_cdt17_final_g5_complete_proof_gate import ClosedFixture

class BinderFinalG5Tests(unittest.TestCase):
    def setUp(self):
        f=ClosedFixture();receipt=f.generate();self.f=f;self.receipt=receipt
        self.code=f.code;self.instance=f.instance
        self.bodies={e['role']:f.objects[e['path']] for e in receipt['evidence'] if e['role']!='ORIGIN_DECISION'}
        self.paths={e['role']:e['path'] for e in receipt['evidence'] if e['role']!='ORIGIN_DECISION'}
        self.decision=f.objects['ORIGIN_DECISION'];self.final=receipt['final_package_sha256']
    def invoke(self):
        return _check_native_chain('G5',self.bodies,code_sha=self.code,final_package_sha=self.final,
                instance_sha=self.instance,evidence_paths=self.paths,read=lambda p:self.f.objects[p],
                decision_raw=self.decision)
    def test_01_exact_final_consumer_contract_shape(self):
        self.assertIsNone(self.invoke())
    def test_02_previous_scoped_inputs_cannot_be_labeled_complete(self):
        self.bodies.pop('FINAL_PACKAGE_ZIP')
        with self.assertRaisesRegex(DecisionBlocked,'DECISION_FINAL_PROOFS_MISSING'):self.invoke()
    def test_03_wrong_final_code_rejected(self):
        self.code='C'*64
        with self.assertRaisesRegex(DecisionBlocked,'FINAL_'):self.invoke()
    def test_04_tampered_complete_proof_rejected(self):
        self.f.objects['PROOF_'+next(iter(json.loads(self.f.objects['ENGINEERING_COMPLETENESS'])['five_part_completeness']))]=b'bad'
        with self.assertRaisesRegex(DecisionBlocked,'DECISION_FINAL_PINNED_SHA'):self.invoke()
    def test_05_no_synthetic_decision_minting(self):
        self.decision=b'{}'
        with self.assertRaisesRegex(DecisionBlocked,'FINAL_'):self.invoke()
    def test_06_final_integration_manifest_binds_actual_modules(self):
        from hashlib import sha256
        items=[]
        for name in ('control/FULL_RELEASE_CHAIN.py','control/FULL_G5_COMPLETE_PROOF_GATE.py',
                     'control/ORIGIN_DECISION_BINDER.py','control/G5_C6_FORMAL_CONTRACT.py',
                     'control/G5_C6_FORMAL_STAGE_BUILDER.py','control/FULL_QUALIFICATION_CONTRACT.py'):
            b=(R/'candidate'/name).read_bytes()
            items.append({'path':name,'bytes':len(b),'sha256':sha256(b).hexdigest().upper()})
        o={'schema':'CDT17_G5_FINAL_INTEGRATED_CODE_MANIFEST_V001','binding_mode':'FINAL_CANDIDATE',
           'code_manifest_sha256':self.code,'final_package_sha256':self.final,'files':items}
        raw=json.dumps(o).encode()
        _check_evidence_semantics('G5','G5_INTEGRATION_MANIFEST',raw,
                code_sha=self.code,final_package_sha=self.final,b06_sha=None)
        o['files'][0]['sha256']='F'*64
        with self.assertRaisesRegex(DecisionBlocked,'DECISION_FINAL_INTEGRATION_MODULE_SHA'):
            _check_evidence_semantics('G5','G5_INTEGRATION_MANIFEST',json.dumps(o).encode(),
                code_sha=self.code,final_package_sha=self.final,b06_sha=None)
    def test_07_final_integration_code_drift_rejected(self):
        o={'schema':'CDT17_G5_FINAL_INTEGRATED_CODE_MANIFEST_V001','binding_mode':'FINAL_CANDIDATE',
           'code_manifest_sha256':'F'*64,'final_package_sha256':self.final,'files':[]}
        with self.assertRaisesRegex(DecisionBlocked,'DECISION_FINAL_INTEGRATION_IDENTITY'):
            _check_evidence_semantics('G5','G5_INTEGRATION_MANIFEST',json.dumps(o).encode(),
                code_sha=self.code,final_package_sha=self.final,b06_sha=None)

if __name__ == '__main__':unittest.main()
