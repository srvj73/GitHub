"""Ordering contracts for the probe; mocked identity is not a native witness."""
from pathlib import Path
import sys
import tempfile
import unittest
import pickle
from unittest import mock
ROOT=Path(__file__).resolve().parents[1]/'candidate'
sys.path.insert(0,str(ROOT/'g5proof'))
import PRE_G06_NATIVE_SCENARIOS as N


class BarrierOrdering(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.marker=self.root/'GAP.json'
        self.probe=N.Barrier(self.root,'contract','20240110','AFTER_GROUP_JOURNAL',self.marker)
        self.probe=self.probe.for_day('20240110',[])

    def test_wrong_gap_has_no_effect(self):
        self.probe.hit('OTHER_POINT')
        self.assertFalse(self.marker.exists())

    def test_no_preexisting_commit_cannot_publish_gap(self):
        self.probe.required_commit=str(self.root/'missing.commit.json')
        with mock.patch.object(N.time,'monotonic',side_effect=[0,121]):
            with self.assertRaisesRegex(Exception,'PREEXISTING_COMMIT_TIMEOUT'):
                self.probe.hit('AFTER_GROUP_JOURNAL')
        self.assertFalse(self.marker.exists())

    def test_preexisting_commit_precedes_durable_marker(self):
        commit=self.root/'day.commit.json';N.R.publish(commit,{'fixture':True})
        before=commit.read_bytes();self.probe.required_commit=str(commit)
        N.R.publish(str(self.marker)+'.release',{'fixture_release':True})
        with mock.patch.object(N.R,'native_process',return_value={'pid':123,'creation_filetime':456,'state':'LIVE'}):
            self.probe.hit('AFTER_GROUP_JOURNAL')
        self.assertTrue(self.marker.is_file());self.assertEqual(commit.read_bytes(),before)
        self.assertEqual(N.R.read(self.marker)[0]['point'],'AFTER_GROUP_JOURNAL')


class BarrierOneShot(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.marker=self.root/'GAP.json'
        self.probe=N.Barrier(self.root,'owned-run','20240110','AFTER_GROUP_JOURNAL',self.marker)
        self.identity={'pid':123,'creation_filetime':456,'state':'LIVE'}
        patch=mock.patch.object(N.R,'native_process',return_value=self.identity)
        patch.start();self.addCleanup(patch.stop)
        N.R.publish(str(self.marker)+'.release',{'fixture_release':True})

    def hit(self, probe=None, paths=()):
        (probe or self.probe).for_day('20240110',paths).hit('AFTER_GROUP_JOURNAL')

    def test_three_flushed_groups_use_one_immutable_marker(self):
        data=self.root/'day.partial';data.write_bytes(b'group one')
        with mock.patch.object(N.R,'publish',wraps=N.R.publish) as publish:
            self.hit(paths=[data]);first=self.marker.read_bytes()
            for group in (b'group two',b'group three'):
                data.write_bytes(data.read_bytes()+group)
                self.hit(paths=[data])
            self.assertEqual(publish.call_count,1)
        self.assertEqual(first,self.marker.read_bytes())
        self.assertEqual(N.R.read(self.marker)[0]['physical_files'][0]['sha256'],N.R.sha(b'group one'))

    def test_fresh_probe_cannot_adopt_existing_marker(self):
        self.hit();before=self.marker.read_bytes()
        with self.assertRaises(Exception):
            self.hit(N.Barrier(self.root,'owned-run','20240110','AFTER_GROUP_JOURNAL',self.marker))
        self.assertEqual(before,self.marker.read_bytes())

    def test_preexisting_foreign_marker_preserved(self):
        N.R.publish(self.marker,{'foreign':True});before=self.marker.read_bytes()
        with self.assertRaises(Exception):self.hit()
        self.assertEqual(before,self.marker.read_bytes())
        self.assertFalse(self.probe._released_gap)

    def test_tampered_marker_rejected(self):
        self.hit();self.marker.write_bytes(b'{"forged":true}\n')
        with self.assertRaisesRegex(Exception,'BARRIER_REPLAY_DRIFT'):self.hit()

    def test_deleted_marker_not_recreated(self):
        self.hit();self.marker.unlink()
        with self.assertRaises(Exception):self.hit()
        self.assertFalse(self.marker.exists())

    def test_changed_run_rejected(self):
        self.hit();self.probe.run_id='different-run'
        with self.assertRaisesRegex(Exception,'BARRIER_REPLAY_IDENTITY'):self.hit()

    def test_changed_artifact_set_rejected(self):
        self.hit()
        with self.assertRaisesRegex(Exception,'BARRIER_REPLAY_IDENTITY'):self.hit(paths=[self.root/'foreign'])

    def test_other_process_cannot_inherit_released_state(self):
        self.hit();spawned=pickle.loads(pickle.dumps(self.probe))
        self.identity['pid']=124
        with self.assertRaisesRegex(Exception,'BARRIER_REPLAY_IDENTITY'):self.hit(spawned)

    def test_pid_reuse_rejected(self):
        self.hit();self.identity['creation_filetime']=457
        with self.assertRaisesRegex(Exception,'BARRIER_REPLAY_IDENTITY'):self.hit()

    def test_unrelated_day_never_consumes_one_shot(self):
        self.probe.for_day('20240212',[]).hit('AFTER_GROUP_JOURNAL')
        self.assertFalse(self.probe._released_gap);self.assertFalse(self.marker.exists())
        self.hit();self.assertTrue(self.marker.exists())

    def test_timeout_not_promoted_to_released(self):
        Path(str(self.marker)+'.release').unlink()
        with mock.patch.object(N.time,'monotonic',side_effect=[0,121]):
            with self.assertRaisesRegex(Exception,'BARRIER_TIMEOUT'):self.hit()
        before=self.marker.read_bytes();self.assertFalse(self.probe._released_gap)
        with self.assertRaises(Exception):self.hit()
        self.assertEqual(before,self.marker.read_bytes())

    def test_mutation_during_pause_rejected(self):
        Path(str(self.marker)+'.release').unlink()
        def release(_):
            self.marker.write_bytes(b'forged')
            N.R.publish(str(self.marker)+'.release',{'fixture_release':True})
        with mock.patch.object(N.time,'sleep',side_effect=release):
            with self.assertRaisesRegex(Exception,'BARRIER_RELEASE_DRIFT'):self.hit()
        self.assertFalse(self.probe._released_gap)

if __name__=='__main__':unittest.main(verbosity=2)
