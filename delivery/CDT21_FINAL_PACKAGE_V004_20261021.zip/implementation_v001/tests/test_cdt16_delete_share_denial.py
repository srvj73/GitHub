"""Targeted mock-only negatives. Native Win32 acceptance remains unqualified."""
import ctypes
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'qual'))
import SANDBOX_ADMISSION as A


class ProbeContract(unittest.TestCase):
    def make(self, result, last_error):
        calls = []

        class Kernel:
            def CreateFileW(self, *args):
                calls.append(('open', args))
                return result
            def CloseHandle(self, h):
                calls.append(('close', h))

        obj = A.HeldDirectory.__new__(A.HeldDirectory)
        obj.path = 'C:\\QUAL\\OWNED'
        obj.native = True
        obj._k = Kernel()
        obj._ctypes = SimpleNamespace(c_void_p=ctypes.c_void_p,
                                      get_last_error=lambda: last_error)
        return obj, calls

    def test_sharing_violation_is_the_only_accepted_denial(self):
        obj, calls = self.make(ctypes.c_void_p(-1).value, 32)
        self.assertEqual(obj.require_delete_open_denial(), 32)
        self.assertEqual(calls[0][1][1], 0x00010000)
        self.assertEqual(calls[0][1][2], 7)
        self.assertFalse(any(c[0] == 'close' for c in calls))

    def test_acl_denial_is_not_confused_with_share_denial(self):
        obj, calls = self.make(ctypes.c_void_p(-1).value, 5)
        with self.assertRaisesRegex(A.AdmissionBlocked, 'NOT_ATTRIBUTABLE_TO_SHARING'):
            obj.require_delete_open_denial()
        self.assertFalse(any(c[0] == 'close' for c in calls))

    def test_successful_delete_open_blocks_and_closes_temporary_handle(self):
        obj, calls = self.make(991, 0)
        with self.assertRaisesRegex(A.AdmissionBlocked, 'UNEXPECTEDLY_ADMITTED'):
            obj.require_delete_open_denial()
        self.assertEqual(calls[-1], ('close', 991))

    def test_zero_error_does_not_mean_denial(self):
        obj, _ = self.make(ctypes.c_void_p(-1).value, 0)
        with self.assertRaisesRegex(A.AdmissionBlocked, 'NOT_ATTRIBUTABLE_TO_SHARING'):
            obj.require_delete_open_denial()

    def test_prewrite_denial_never_calls_mkdir(self):
        chain = SimpleNamespace(record={'path': '/tmp/owned'},
                                verify=Mock(), leaf=SimpleNamespace(
                                    require_delete_open_denial=Mock(side_effect=A.AdmissionBlocked('DENIED'))))
        with patch.object(A.os, 'mkdir') as mkdir:
            with self.assertRaisesRegex(A.AdmissionBlocked, 'DENIED'):
                A.create_run_dir_exclusive(chain, 'RUN_NEW')
            mkdir.assert_not_called()
        self.assertEqual(chain.verify.call_count, 1)

    def test_prewrite_guard_invoked_before_existence_check(self):
        seen = []
        def check():
            seen.append('share_guard')
            raise A.AdmissionBlocked('GUARD')
        chain = SimpleNamespace(record={'path': '/tmp/owned'},
                                verify=lambda: seen.append('verify'), leaf=SimpleNamespace(
                                    require_delete_open_denial=check))
        with patch.object(A.os.path, 'lexists', side_effect=AssertionError('path read before guard')):
            with patch.object(A.os, 'mkdir', side_effect=AssertionError('write before guard')):
                with self.assertRaisesRegex(A.AdmissionBlocked, 'GUARD'):
                    A.create_run_dir_exclusive(chain, 'RUN_NEW')
        self.assertEqual(seen, ['verify', 'share_guard'])

    def test_portable_branch_stays_noop(self):
        obj, calls = self.make(991, 0)
        obj.native = False
        self.assertIsNone(obj.require_delete_open_denial())
        self.assertEqual(calls, [])


if __name__ == '__main__':
    unittest.main()
