"""CDT17 B1 formal adapter: tests run on portable code; NEVER Windows G4/G5 proof."""
import io
import importlib.util
import json
import pathlib
import unittest
import zipfile

CONTROLS=pathlib.Path(__file__).resolve().parents[1]/'candidate'/'control'
spec=importlib.util.spec_from_file_location('b1formal', CONTROLS/'B1_FORMAL_ADMISSION.py')
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class B1FormalFailClosed(unittest.TestCase):
    def test_static_contract_is_frozen_and_explicit(self):
        self.assertEqual(mod.EXPECTED_REV,'20261015T184900-0300-270753E5577C4C80')
        self.assertEqual(len(mod.REQUIRED_NEW_TESTS),10)

    def test_bad_policy_bytes_block(self):
        with self.assertRaisesRegex(mod.Blocked,'POLICY_PHYSICAL_HASH'):
            mod.verify_policy(b'NOT REAL',b'NOT REAL')

    def test_duplicate_policy_key_blocks(self):
        with self.assertRaisesRegex(mod.Blocked,'DUPLICATE_JSON_KEY'):
            mod.js(b'{"state":"FROZEN","state":"PASS"}')

    def test_missing_native_input_blocks_before_formal_receipt(self):
        called=[]
        def verify(*args): called.append('should not run')
        with self.assertRaises(mod.Blocked):
            mod.evaluate(b'm',b'e',b'b',b'p',b'f',b'',b'x',b'y',b'issuer',verify)
        self.assertEqual(called,[])

    def test_rejects_path_escape(self):
        bio=io.BytesIO()
        with zipfile.ZipFile(bio,'w') as z:
            z.writestr('../escape','x')
        with self.assertRaisesRegex(mod.Blocked,'UNSAFE_PATH'):
            mod.safe_zip(bio.getvalue(),'EV')

    def test_rejects_duplicate_zip_entries(self):
        import warnings
        bio=io.BytesIO()
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',UserWarning)
            with zipfile.ZipFile(bio,'w') as z:
                z.writestr('x','a');z.writestr('x','b')
        with self.assertRaisesRegex(mod.Blocked,'MEMBER_SET'):
            mod.safe_zip(bio.getvalue(),'EV')

    def test_rejects_missing_manifest(self):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:z.writestr('QUAL_RECEIPT.json','{}')
        with self.assertRaisesRegex(mod.Blocked,'MISSING_MANIFEST'):
            mod.verify_native_return(b.getvalue(),final_sha='A'*64,
                                     runtime_manifest_sha='B'*64,issuer_sha='C'*64)

    def test_rejects_incomplete_native_return(self):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:
            z.writestr('QUAL_RECEIPT.json','{}')
            z.writestr('RETURN_MANIFEST.json',json.dumps({
                'schema':mod.NATIVE_RETURN_SCHEMA,
                'files':{'QUAL_RECEIPT.json':mod.sha(b'{}')}}))
        with self.assertRaisesRegex(mod.Blocked,'EXACT_SET'):
            mod.verify_native_return(b.getvalue(),final_sha='A'*64,
                                     runtime_manifest_sha='B'*64,issuer_sha='C'*64)

    def test_no_g5_release_from_b1(self):
        src=(CONTROLS/'FULL_QUALIFICATION_CONTRACT.py').read_text()
        self.assertIn('def evaluate_b1_formal_admission(',src)
        self.assertIn('def validate(',src)
        self.assertIn('def physical_findings(',src)
        self.assertIn('def evaluate_b1_distributed_admission(',src)

    def test_native_forged_status_rejected(self):
        q={'schema':mod.SCHEMA, 'status':'PASS_NATIVE_INTEGRATED','platform':'linux',
           'powershell_major':5,'tests_run':10, 'failures':0,'errors':0,'skips':0,
           'final_zip_sha256':'A'*64,'runtime_manifest_sha256':'B'*64,
           'b1_formal_source_sha256':'C'*64,
           'policy_master_sha256':mod.EXPECTED_MASTER_SHA,
           'policy_head_sha256':mod.EXPECTED_HEAD_SHA,
           'policy_revision_id':mod.EXPECTED_REV,
           'tested_code_equals_packaged_code':'PASS','production_execution':False,
           'result_return_to':mod.CONTEXT}
        files={'QUAL_RECEIPT.json':json.dumps(q).encode(),
               'TESTS.json':json.dumps([{'id':t,'status':'PASS'} for t in mod.REQUIRED_NEW_TESTS]).encode(),
               'TESTS.log':b'Ran 10 tests\nOK'}
        files['RETURN_MANIFEST.json']=json.dumps({'schema':mod.NATIVE_RETURN_SCHEMA,
                  'files':{n:mod.sha(v) for n,v in files.items()}}).encode()
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:
            for n,v in files.items():z.writestr(n,v)
        with self.assertRaisesRegex(mod.Blocked,'NATIVE:QUAL_RECEIPT_BINDINGS'):
            mod.verify_native_return(b.getvalue(), final_sha='A'*64,
                                     runtime_manifest_sha='B'*64,issuer_sha='C'*64)

if __name__=='__main__':unittest.main()
