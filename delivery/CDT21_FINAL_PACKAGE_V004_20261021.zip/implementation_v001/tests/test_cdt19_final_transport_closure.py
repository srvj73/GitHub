"""Synthetic adversarial contracts, never Windows execution evidence."""
import copy
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import zipfile

ROOT=Path(__file__).resolve().parents[1]
for name in ('g5proof','control','full'):sys.path.insert(0,str(ROOT/'candidate'/name))
import PRE_G06_CAMPAIGN as C
import PRE_G06_PROOF_PROJECTION as P
import FULL_G5_COMPLETE_PROOF_GATE as G
import FULL_CRASH_RECOVERY as R
import test_cdt19_r04_evidence_contract as fixture


class ElevenArchive(unittest.TestCase):
    put_blob=fixture.EvidenceContract.put_blob
    def put_json(self,obj):
        self.counter+=1;name='json_%04d.json'%self.counter
        (self.ev/name).write_bytes(R.encoded(obj))
        return C.physical(self.ev/name,self.ev)

    def setUp(self):
        fixture.EvidenceContract.setUp(self)
        self.campaign=self.root/'CAMPAIGN';(self.campaign/'EVIDENCE').mkdir(parents=True)
        self.run='R08_Q1_20261019165536_ff043e3870e0'
        runid=C.consumer_evidence_run_id(self.run)
        self.dossier['run_id']=runid
        for row in self.dossier['consumers']:
            for key in ('execution_witness','internal_branch_execution'):
                obj=json.loads((self.ev/row[key]['member']).read_bytes());obj['run_id']=runid
                row[key]=self.put_json(obj)
        (self.ev/'ELEVEN_CONSUMERS.json').write_bytes(R.encoded(self.dossier))
        shutil.move(str(self.ev),str(self.campaign/'EVIDENCE/CONSUMERS'))
        self.ev=self.campaign/'EVIDENCE/CONSUMERS'
        self.members={'implementation_v001/RUNTIME_CODE_MANIFEST.json':self.manifest.read_bytes()}
        self.members.update({'implementation_v001/candidate/'+p.relative_to(self.cand).as_posix():p.read_bytes()
                             for p in self.cand.rglob('*') if p.is_file()})
        self.code=R.sha(self.manifest.read_bytes())

    def verify(self):
        ref=C.project_consumer_refs(self.campaign)
        native={p.relative_to(self.campaign).as_posix():p.read_bytes()
                for p in (self.campaign/'EVIDENCE/PRE_B06').rglob('*') if p.is_file()}
        result=dict(pre_b06_11_receipt=ref,run_id=self.run,
                    pre_b06_11_evidence_class='ENGINEERING_READINESS_NOT_PRODUCTION')
        return G.verify_pre_b06_v002(native,result,self.code,'B'*64,{},self.members)

    def test_all_eleven_projected_through_final_archive_verifier(self):
        self.assertEqual(self.verify()['member'],'EVIDENCE/PRE_B06/ELEVEN_CONSUMERS.json')

    def test_interrupted_projection_is_preserved_and_resumed(self):
        dest=self.campaign/'EVIDENCE/PRE_B06';dest.mkdir();(dest/'incomplete').write_bytes(b'KEEP')
        first=self.verify();second=self.verify()
        self.assertEqual(first,second)
        kept=list((self.campaign/'INTERRUPTED_ATTEMPTS').glob('PROJECTION_*/incomplete'))
        self.assertEqual(len(kept),1);self.assertEqual(kept[0].read_bytes(),b'KEEP')

    def test_json_leaf_remains_byte_identical(self):
        row=self.dossier['consumers'][0]
        obj=json.loads((self.ev/row['internal_branch_execution']['member']).read_bytes())
        raw=b'{ "observed" : 1, "state" : "committed" }\r\n'
        leaf=self.ev/'physical.json';leaf.write_bytes(raw)
        obj['isolated_transitions'][0]['after']=C.physical(leaf,self.ev)
        obj['isolated_transitions'][0]['after_sha256']=R.sha(raw)
        row['internal_branch_execution']=self.put_json(obj)
        (self.ev/'ELEVEN_CONSUMERS.json').write_bytes(R.encoded(self.dossier))
        self.verify()
        self.assertTrue(any(p.read_bytes()==raw for p in (self.campaign/'EVIDENCE/PRE_B06').glob('*physical.json')))

    def test_same_syntax_foreign_run_rejected(self):
        self.run='R08_Q1_20261019165536_aaaaaaaaaaaa'
        with self.assertRaisesRegex(Exception,'CONSUMER_RUN_BINDING'):self.verify()

    def test_rehashed_wrong_source_is_not_evidence(self):
        key='implementation_v001/candidate/'+self.dossier['consumers'][0]['source_path']
        self.members[key]+=b'changed'
        with self.assertRaisesRegex(Exception,'ARCHIVE_CODE_MEMBER'):self.verify()

    def test_changed_nested_physical_bytes_rejected(self):
        row=self.dossier['consumers'][0]
        obj=json.loads((self.ev/row['internal_branch_execution']['member']).read_bytes())
        (self.ev/obj['isolated_transitions'][0]['after']['member']).write_bytes(b'changed')
        with self.assertRaisesRegex(Exception,'PHYSICAL_REF_DRIFT'):self.verify()


def causal_fixture():
    """Explicit synthetic input to validators, not a process observation."""
    rows=[]
    for name,point in [('GROUP_CRASH','AFTER_GROUP_JOURNAL'),('COMMIT_CRASH','AFTER_COMMIT_RENAME_BEFORE_MANIFEST'),
                       ('CANCEL_TREE','AFTER_GROUP_JOURNAL'),('SAFE_STOP','AFTER_GROUP_JOURNAL')]:
        stopped=name=='SAFE_STOP';pid=dict(pid=99,creation_filetime=100)
        event=({'status':'SAFE_STOP'} if stopped else dict(exit_code=0 if name=='CANCEL_TREE' else 1,before_census=[pid],after_census=[],
               observations=[dict(pid,observation='EXITED')],gap=dict(point=point,paused_after_real_flush=True),
               action='CANCEL_OWNED_JOB_TREE' if name=='CANCEL_TREE' else 'TERMINATE_OWNED_COORDINATOR'))
        rows.append(dict(name=name,run_id=name,interruption=event,worker_equivalence=True,
              published_containers={'sample':'test'},durable_sections_preserved=[{'test':True}],
              committed_before={'test':'bytes'},committed_after={'test':'bytes'},
              resumed=dict(status='PASS',run_id=name,source_hashes_unchanged=True,workers_effective=2,
              own_census={'known_recovery_supervisor_or_workers':0},
              g6=dict(g3_ownership_closed=True,g3_dead_predecessors_verified=0 if stopped else 1))))
    return dict(schema='CDT19_G3_G6_NATIVE_SCENARIOS_V001',status='PASS',native_windows=True,
       operational_authority=False,production_modified=False,results=dict(baseline={'status':'PASS'},scenarios=rows,
       native_negatives=[{'name':n} for n in ('live_lease_overlap','false_owner_death','foreign_instance','foreign_lock','outside_run_owned')]))


class CausalClosure(unittest.TestCase):
    def setUp(self):self.summary=causal_fixture()
    def test_contract_only_all_four_scenarios(self):self.assertEqual(len(P.validate(self.summary)['scenarios']),4)
    def test_job_cancellation_zero_exit_with_real_death_is_valid(self):
        cancel=self.summary['results']['scenarios'][2]['interruption']
        self.assertEqual(cancel['exit_code'],0)
        self.assertEqual(cancel['action'],'CANCEL_OWNED_JOB_TREE')
        self.assertEqual(len(P.validate(self.summary)['scenarios']),4)

    def test_zero_exit_crash_still_rejected(self):
        self.summary['results']['scenarios'][0]['interruption']['exit_code']=0
        with self.assertRaisesRegex(Exception,'NATIVE_DELIBERATE_DEATH'):P.validate(self.summary)

    def test_mislabeled_cancel_rejected(self):
        self.summary['results']['scenarios'][2]['interruption']['action']='TERMINATE_OWNED_COORDINATOR'
        with self.assertRaisesRegex(Exception,'NATIVE_DELIBERATE_DEATH'):P.validate(self.summary)

    def test_cancel_dead_process_required_despite_zero_exit(self):
        cancel=self.summary['results']['scenarios'][2]['interruption']
        cancel['observations'][0]['observation']='LIVE'
        with self.assertRaisesRegex(Exception,'NATIVE_DEATH_OBSERVATION'):P.validate(self.summary)

    def test_zero_exit_boolean_rejected(self):
        self.summary['results']['scenarios'][2]['interruption']['exit_code']=False
        with self.assertRaisesRegex(Exception,'NATIVE_DELIBERATE_DEATH'):P.validate(self.summary)

    def test_single_worker_resume_rejected(self):
        self.summary['results']['scenarios'][0]['resumed']['workers_effective']=1
        with self.assertRaisesRegex(Exception,'MULTIWORK_REQUIRED'):P.validate(self.summary)
    def test_live_child_cannot_be_reported_dead(self):
        self.summary['results']['scenarios'][0]['interruption']['observations'][0]['observation']='LIVE'
        with self.assertRaisesRegex(Exception,'DEATH_OBSERVATION'):P.validate(self.summary)
    def test_same_gap_twice_rejected(self):
        self.summary['results']['scenarios'][1]['interruption']['gap']['point']='AFTER_GROUP_JOURNAL'
        with self.assertRaisesRegex(Exception,'DISTINCT_NATIVE_GAPS'):P.validate(self.summary)
    def test_missing_child_death_rejected(self):
        self.summary['results']['scenarios'][0]['interruption']['observations']=[]
        with self.assertRaisesRegex(Exception,'DEATH_PROCESS_SET'):P.validate(self.summary)
    def test_causal_archive_deep_refs_and_tampering(self):
        name='WORK/G3_G6_NATIVE/G3_G6_NATIVE_SCENARIOS.json'
        members={name:R.encoded(self.summary),'WORK/G3_G6_NATIVE/physical.bin':b'bytes'}
        refs=[dict(member=n,sha256=R.sha(raw),bytes=len(raw)) for n,raw in members.items()]
        for role in ('PROCESS_TREE_CRASH_CONTAINMENT','SAFE_STOP_RESUME_ROW_GROUP','POWERLOSS_EMULATED'):
            members['EVIDENCE/PROOFS/'+role+'/NATIVE_CAUSAL_EVIDENCE.json']=R.encoded(dict(
                schema='CDT19_SCOPED_NATIVE_PROOF_PROJECTION_V002',proof=role,summary=self.summary,
                code_manifest_sha256='A'*64,final_zip_sha256='B'*64,operational_authority=False,physical_files=refs))
        self.assertEqual(G.verify_causal_projection(members,'A'*64,'B'*64),self.summary)
        members['WORK/G3_G6_NATIVE/physical.bin']=b'wrong'
        with self.assertRaisesRegex(Exception,'NATIVE_CAUSAL_ARTIFACT'):G.verify_causal_projection(members,'A'*64,'B'*64)


class ReturnClosure(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
        (self.root/'CAMPAIGN.lock').write_bytes(b'X')
        R.publish(self.root/'OWNER.json',{'run_id':self.root.name})
    def test_partial_preserved_and_only_exact_active_lock_excluded(self):
        (self.root/'R08_RETURN.zip.partial').write_bytes(b'old partial')
        (self.root/'nested').mkdir();(self.root/'nested/CAMPAIGN.lock').write_bytes(b'other lock')
        (self.root/'nested/R08_RETURN.zip').write_bytes(b'nested historical return')
        out=C.seal_return(self.root,'R08_RETURN.zip',excluded=('R08_RETURN.zip','R08_RETURN.sha256'))
        with zipfile.ZipFile(out) as z:
            self.assertNotIn('CAMPAIGN.lock',z.namelist())
            self.assertEqual(z.read('nested/CAMPAIGN.lock'),b'other lock')
            self.assertEqual(z.read('nested/R08_RETURN.zip'),b'nested historical return')
            self.assertTrue(any(z.read(n)==b'old partial' for n in z.namelist() if n.endswith('.partial')))
    def test_foreign_partial_owner_rejected_without_deletion(self):
        (self.root/'OWNER.json').write_bytes(R.encoded({'run_id':'foreign'}))
        p=self.root/'R08_RETURN.zip.partial';p.write_bytes(b'preserve')
        with self.assertRaisesRegex(Exception,'FOREIGN_OWNER'):C.seal_return(self.root,'R08_RETURN.zip')
        self.assertEqual(p.read_bytes(),b'preserve')
    def test_count_surfaces_name_projected_and_diagnostic_units(self):
        (self.root/'COMMITS').mkdir();(self.root/'COMMITS/DIAG.json').write_bytes(b'{}')
        C.write_terminal(self.root,dict(status='BLOCKED',tests={'PROJECTED':{}},additional_tests={'DIAG':{}}))
        obj=R.read(self.root/'LIVE_STATUS.json')[0]
        self.assertEqual(obj['roles_without_own_commit'],['PROJECTED'])
        self.assertEqual(obj['commits_outside_contracted_roles'],['DIAG'])


if __name__=='__main__':unittest.main(verbosity=2)
