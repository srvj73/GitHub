"""Portable negative controls for composing the frozen Opus R47/C6 FULL with native G5 delta.
No authority to start FULL or issue B06 is granted by these tests.
"""
import ast
import hashlib
import json
import sys
import unittest
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'candidate'
BASE_MANIFEST=ROOT/'RUNTIME_CODE_MANIFEST.json'
EVIDENCE=ROOT/'FULL_COMPOSITION_EVIDENCE.json'
sha=lambda raw:hashlib.sha256(raw).hexdigest().upper()

class ComposeScope(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runtime=json.loads(BASE_MANIFEST.read_bytes())
        cls.receipt=json.loads(EVIDENCE.read_bytes())
    def test_01_all_runtime_files_exactly_declared(self):
        rows={r['path']:r for r in self.runtime['files']}
        files={p.relative_to(SRC).as_posix():p for p in SRC.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
        self.assertEqual(set(rows),set(files))
        for n,p in files.items():
            v=p.read_bytes();self.assertEqual(rows[n]['sha256'],sha(v));self.assertEqual(rows[n]['bytes'],len(v))
    def test_02_old_composite_not_same_as_parent(self):
        self.assertNotEqual(self.receipt['parent_runtime_code_manifest_sha256'],sha(BASE_MANIFEST.read_bytes()))
    def test_03_modifications_exact_three(self):
        self.assertEqual({r['path'] for r in self.receipt['five_g5_deltas'] if r['type']=='MODIFIED'},
          {'control/FULL_QUALIFICATION_CONTRACT.py','control/G5_EVIDENCE_BUILDER.py','control/ORIGIN_DECISION_BINDER.py'})
    def test_04_new_contracts_exact_two(self):
        self.assertEqual({r['path'] for r in self.receipt['five_g5_deltas'] if r['type']=='ADDED'},
          {'control/G5_C6_FORMAL_CONTRACT.py','control/G5_C6_FORMAL_STAGE_BUILDER.py'})
    def test_05_support_files_exact_two(self):
        self.assertEqual({r['path'] for r in self.receipt['support_dependencies']},
          {'SUPPORT/G5_C6_B1_FORMAL_CONSUMER.py','SUPPORT/FULL_QUALIFICATION_CONTRACT.py'})
    def test_06_support_original_contract_is_old(self):
        support=SRC/'SUPPORT/FULL_QUALIFICATION_CONTRACT.py'
        current=SRC/'control/FULL_QUALIFICATION_CONTRACT.py'
        self.assertNotEqual(sha(support.read_bytes()),sha(current.read_bytes()))
        self.assertIn(b'def evaluate_formal_g5_stage',current.read_bytes())
        self.assertNotIn(b'def evaluate_formal_g5_stage',support.read_bytes())
    def test_07_parent_native_g5_not_new_full_verdict(self):
        with zipfile.ZipFile(ROOT/'G5_APPROVED_INPUTS/G5_OWNER_FORMAL_RETURN_G5_C6_OWNER_CLOSE_20261016_132140_430_17988.zip') as z:
            o=json.loads(z.read('G5_FORMAL_STAGE_RECEIPT.json'))
        self.assertEqual(o['final_package_sha256'],self.receipt['parent_zip_sha256'])
        self.assertNotEqual(o['code_manifest_sha256'],sha(BASE_MANIFEST.read_bytes()))
    def test_08_five_part_not_pass(self):
        self.assertTrue(all(v!='PASS' for v in self.receipt['five_part_completeness'].values()))
        self.assertFalse(self.receipt['full_started'])
    def test_09_no_b06_false_evidence(self):
        self.assertNotIn('PASS',str(self.receipt['known_critical_reconciliation']))
        self.assertTrue(self.receipt['no_b06_no_b07_no_d4_d5_no_canary_no_full'])
    def test_10_reparse_all_new_modules_compilable(self):
        for change in self.receipt['five_g5_deltas']+self.receipt['support_dependencies']:
            p=SRC/change['path'];ast.parse(p.read_bytes().decode('utf8'),filename=str(p))
    def test_11_negative_wrong_member_hash(self):
        rows={r['path']:r for r in self.runtime['files']}
        x=bytearray((SRC/'control/G5_C6_FORMAL_CONTRACT.py').read_bytes());x[-1]^=1
        self.assertNotEqual(sha(bytes(x)),rows['control/G5_C6_FORMAL_CONTRACT.py']['sha256'])
    def test_12_negative_missing_support_detectable(self):
        rows={r['path'] for r in self.runtime['files']};missing=rows-{'SUPPORT/G5_C6_B1_FORMAL_CONSUMER.py'}
        self.assertNotEqual(rows,missing)
    def test_13_negative_duplicate_path_detectable(self):
        names=[r['path'] for r in self.runtime['files']];names.append(names[0]);self.assertNotEqual(len(names),len(set(names)))
    def test_14_negative_false_g5_manifest_binding(self):
        self.assertNotEqual(self.receipt['owner_g5_native_receipt_sha256'],'0'*64)
        self.assertNotEqual(self.receipt['owner_g5_native_return_sha256'],'0'*64)
    def test_15_positive_native_provenance_reverified_portably(self):
        # Preserve original G5 native campaign as a historical, SHA-bound input to this *new* codebase.
        from importlib.util import spec_from_file_location,module_from_spec
        control=SRC/'control';sys.path.insert(0,str(control))
        try:
            import G5_C6_FORMAL_CONTRACT as c
            z=zipfile.ZipFile(ROOT/'G5_APPROVED_INPUTS/G5_OWNER_FORMAL_RETURN_G5_C6_OWNER_CLOSE_20261016_132140_430_17988.zip')
            self.assertEqual(json.loads(z.read('G5_FORMAL_STAGE_RECEIPT.json'))['status'],'PASS')
        finally:
            sys.path.remove(str(control))

if __name__=='__main__':unittest.main()
