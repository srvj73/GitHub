"""Unit-only closed G5 fixture; never production attestation or native qualification.

This fixture exercises the *actual* C4 consumer over synthetic ZIP bytes instead of bypassing
its six-proof/native-provenance validation.  No G5/B06/B07 decision may use it.
"""
import json
import sys
from pathlib import Path

def build_fixture(candidate, out_dir):
    impl = Path(candidate).resolve().parent
    sys.path[:0] = [str(impl / 'tests'), str(impl / 'candidate/control')]
    import g5_native_fixture as F
    import G5_EVIDENCE_BUILDER as G
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    fx = F.NativeFixture(F.load_consumer())
    returned, final, code_sha, _ = fx.make(out_dir, 'UNIT_ONLY')
    completeness = G.build(return_zip=returned, final_zip=final,
        baseline_archive=impl / 'tests/fixtures/V38_NATIVE_QUALIFICATION_RESULT_ORIGINAL_DC73A8C3.zip',
        known_blockers=[], out_dir=out_dir / 'G5_COMPLETENESS')
    if completeness['status'] != 'COMPLETE' or completeness['consumer_self_check'] != 'ACCEPTS':
        raise AssertionError('UNIT_FIXTURE_NOT_CLOSED:'+str(completeness['known_blockers']))
    with __import__('zipfile').ZipFile(final) as z:
        manifest_bytes = z.read('implementation_v001/RUNTIME_CODE_MANIFEST.json')
    contract = json.loads((impl / 'candidate/control/QUALIFICATION_CONTRACT.json').read_bytes())
    assert code_sha == __import__('hashlib').sha256(manifest_bytes).hexdigest().upper()
    assert len(contract['required_tests']) == 126 and len(contract['required_target_proofs']) == 6
    assert completeness['gate_verdict_issued'] is False
    return contract, completeness, code_sha, manifest_bytes
