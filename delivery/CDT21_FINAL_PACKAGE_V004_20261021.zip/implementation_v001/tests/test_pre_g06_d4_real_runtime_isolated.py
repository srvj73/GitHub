"""Original D4/recovery function effects on isolated files; not D4 production.

This explicitly closes the gap left by tests that exercised only CAS/menu helpers.
Cannot grant G5 or B06: real 1,399 S0 source, VSS and operator policy are absent.
"""
from __future__ import annotations
import hashlib,importlib.util,json,pathlib,tempfile,unittest,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
BASE=ROOT/'candidate'

def load(key, path):
    full=BASE/path
    spec=importlib.util.spec_from_file_location(key,full)
    module=importlib.util.module_from_spec(spec);sys.modules[key]=module;spec.loader.exec_module(module)
    return module

def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest().upper()

class D4PhysicalEngineEffects(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.release=load('cdt18_owned_d4_release', 'recovery/engine/tickstore_publisher_recovery_v004_release.py')
        cls.candidate=load('cdt18_owned_d4_candidate', 'recovery/engine/tickstore_publisher_recovery_v004_candidate.py')
        cls.admission=load('cdt18_owned_d4_firstadmission','control/D4_FIRST_ADMISSION_TRANSACTION.py')
        cls.roots=load('cdt18_owned_d4_roots','control/D4_ROOTS_EVIDENCE.py')
    def setUp(self):
        t=tempfile.TemporaryDirectory(prefix='PRE_G06_REAL_D4_RUNTIME_')
        self.addCleanup(t.cleanup)
        self.root=pathlib.Path(t.name)
    def test_real_release_and_candidate_atomic_writer_readback(self):
        p=self.root/'checkpoints'/'CHECKPOINT.json'
        a=b'{"committed":1,"producer":"release"}\n'
        self.release._d4r_atomic(p,a)
        self.assertEqual(p.read_bytes(),a)
        before=digest(p)
        b=b'{"committed":2,"producer":"candidate"}\n'
        self.candidate._d4r_atomic(p,b)
        self.assertEqual(p.read_bytes(),b)
        self.assertNotEqual(digest(p),before)
        self.assertFalse(list(p.parent.glob('*.pending.*')))
    def test_real_recovery_receipt_exclusive_immutable(self):
        p=self.root/'receipts'/'REC.json'; p.parent.mkdir()
        a=b'{"run_id":"A","status":"COMMITTED"}\n'
        self.release._d4r_atomic_receipt(p,a)
        self.assertEqual(p.read_bytes(),a)
        with self.assertRaises(Exception):self.release._d4r_atomic_receipt(p,b'{"status":"FORGED"}')
        self.assertEqual(p.read_bytes(),a)
    def test_real_d4_run_authority_single_publish_and_root_scan(self):
        resume=self.root/'RESUME'; control=self.root/'CONTROL'
        for d in (resume/'admission',resume/'authority',control/'state',control/'runs'):d.mkdir(parents=True)
        support=resume/'admission'; target=resume/'authority'/'RUN_AUTHORITY.json'
        bytes_to_publish=self.admission.canon({'schema':'TICKSTORE_D4_RUN_AUTHORITY_V005','run_id':'A'*32,'mode':'ISOLATED_QUAL_ONLY'})
        staged=support/'RUN_AUTHORITY.staged.json';staged.write_bytes(bytes_to_publish)
        self.admission.publish_authority(staged,target)
        self.assertEqual(target.read_bytes(),bytes_to_publish)
        second=support/'second.staged.json'; second.write_bytes(self.admission.canon({'run_id':'B'*32}))
        with self.assertRaises(Exception):self.admission.publish_authority(second,target)
        self.assertEqual(target.read_bytes(),bytes_to_publish)
        (control/'state'/'STATE.json').write_bytes(self.admission.canon({'status':'FAIL','next_node':'D4','canary':{}}))
        report=self.root/'ROOTS_READBACK.json'
        code=self.roots.main(['--resume-root',str(resume),'--control-root',str(control),'--out',str(report)])
        self.assertEqual(code,0)
        evidence=json.loads(report.read_bytes())
        self.assertEqual(evidence.get('schema'),'TICKSTORE_D4_ROOTS_EVIDENCE_V001')
        self.assertTrue(any(x.get('kind')=='run_authority' and x.get('sha256')==digest(target) for x in evidence['found']))
        self.assertTrue(evidence['scope_fingerprint']['unchanged'])
    def test_d4_engine_gate_remains_closed_without_actual_authority(self):
        # The frozen production release has no grant from the test namespace.
        # Neither a new synthetic Owner Gate nor an audit verdict is produced.
        self.assertFalse((self.root/'STATE.json').exists())
        self.assertFalse((self.root/'B06_PASS.json').exists())
        self.assertFalse((self.root/'SNAPSHOT.json').exists())

if __name__=='__main__':unittest.main(verbosity=2)
