"""Adversarial contracts; native process-death proof is a separate campaign."""
import copy
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]/'candidate'
for name in ('control', 'full', 'adapter'):
    sys.path.insert(0, str(ROOT/name))
import FULL_CRASH_RECOVERY as R
import FULL_G3_INTERRUPTION as G
import FULL_STAGE_CONTINUATION as S
import runtime_locator_orchestrator_entry as entry


class OwnershipTests(unittest.TestCase):
    def test_live_owner_blocks(self):
        with self.assertRaisesRegex(Exception, 'OWNER_OR_CHILD_LIVE'):
            R.dead({'pid': 10, 'creation_filetime': 20}, lambda p: {'pid': p, 'creation_filetime': 20, 'state': 'LIVE'})

    def test_reused_pid_is_never_a_kill_target(self):
        result = R.dead({'pid': 10, 'creation_filetime': 20}, lambda p: {'pid': p, 'creation_filetime': 30, 'state': 'LIVE'})
        self.assertEqual(result['observation'], 'PID_REUSED_OLD_OWNER_DEAD')

    def test_visibility_error_is_not_death(self):
        def denied(pid):
            raise PermissionError('denied')
        with self.assertRaises(PermissionError):
            R.dead({'pid': 10, 'creation_filetime': 20}, denied)

    def test_invalid_observation_is_not_death(self):
        for obj in ({'pid': 11, 'state': 'ABSENT'}, {'pid': 10, 'state': 'UNKNOWN', 'creation_filetime': 20}):
            with self.subTest(obj=obj), self.assertRaises(Exception):
                R.dead({'pid': 10, 'creation_filetime': 20}, lambda p: obj)

    def test_foreign_owner_and_live_child_are_denied(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/('a'*32); path.mkdir()
            owner = {'schema': 'TICKSTORE_MULTIWORK_ATTEMPT_OWNER_V001', 'attempt_id': path.name,
                     'binding': {'run_id': 'OWN'}, 'owner': {'pid': 10, 'creation_filetime': 20}}
            ref = R.publish(path/'OWNER.json', owner)
            R.publish(path/'CHILD_11_21.json', {'schema': 'TICKSTORE_MULTIWORK_CHILD_OWNER_V001',
                      'owner_sha256': ref['sha256'], 'identity': {'pid': 11, 'creation_filetime': 21}})
            with self.assertRaisesRegex(Exception, 'FOREIGN_OWNER'):
                R.inspect_attempt(path, {'run_id': 'FOREIGN'}, probe=lambda p: {'pid': p, 'state': 'ABSENT'})
            def census(pid):
                return {'pid': pid, 'state': 'ABSENT'} if pid == 10 else {'pid': pid, 'state': 'LIVE', 'creation_filetime': 21}
            with self.assertRaisesRegex(Exception, 'OWNER_OR_CHILD_LIVE'):
                R.inspect_attempt(path, {'run_id': 'OWN'}, probe=census)
            _, proof = R.inspect_attempt(path, {'run_id': 'OWN'}, probe=lambda p: {'pid': p, 'state': 'ABSENT'})
            self.assertEqual(proof['own_processes_alive'], 0)
            self.assertEqual(len(proof['children']), 1)


class JournalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.ns = S.load((ROOT/'recovery/modules/orchestrator.py').read_bytes(), ROOT/'recovery/modules/orchestrator.py')
        st = self.ns['State'](self.root)
        st.d = dict(schema='TICKSTORE_ORCH_STATE_V001', next_node='G3', completed=['D4', 'G2'],
                    status='PASS', canary_scratch_cert='FIXTURE', created_at='FIXTURE')
        self.ns['atomj'](st.sp, st.d)
        st.log('G2', 'STARTED', run_id='fixture_predecessor')
        st.log('G2', 'FINISHED', status='PASS')
        self.before = st.sp.read_bytes()
        entry.guard_frozen_state_reads(self.ns, st.sp, state_validator=S.StageBoundary('FULL').validate,
                                      transition_validator=S.StageBoundary('FULL').transition)
        self.addCleanup(self.ns['_TICKSTORE_D4_ENTRY_RELEASE_STATE_BOUNDARY'])
        st = self.ns['State'](self.root)
        rd = st.runs/'interrupted'; rd.mkdir()
        self.o = types.SimpleNamespace(st=st, rd=rd, id='interrupted')
        self.ns['immutable_receipt'] = lambda p, b: p.write_bytes(b)  # fixture-only writer
        self.adm = types.SimpleNamespace(instance={'run_id': 'same_instance',
             'bindings': {'scratch_root': str(self.root/'scratch'), 'dest_root': str(self.root/'dest')}},
             descriptor={'instance_sha256': 'A'*64, 'code_manifest_sha256': 'B'*64}, revalidate=lambda: None)
        (self.root/'scratch').mkdir(); (self.root/'dest').mkdir()
        with mock.patch.object(R, 'native_process', return_value={'pid': 123, 'creation_filetime': 456, 'state': 'LIVE'}):
            self.meta = G.begin(self.o, self.ns, self.adm)
        st.log('G3', 'STARTED', run_id='interrupted', **self.meta)
        self.journal = st.jp.read_bytes()

    def test_dead_attempt_closes_fail_without_advancing_or_recreating_state(self):
        with mock.patch.object(R, 'dead', return_value={'pid': 123, 'creation_filetime': 456, 'observation': 'ABSENT'}):
            ref = G.reconcile(self.o, self.ns, self.adm)
        self.assertTrue(Path(ref['path']).is_file())
        self.assertEqual(self.o.st.d['status'], 'FAIL')
        self.assertEqual(self.o.st.d['next_node'], 'G3')
        self.assertNotIn('G3', self.o.st.d['completed'])
        self.assertTrue(self.o.st.jp.read_bytes().startswith(self.journal))
        S.validate_stage_history(self.o.st.jp.read_bytes(), S.StageBoundary('FULL'), self.o.st.d)
        self.assertFalse(G.needs_reconciliation(self.o.st.jp.read_bytes(), self.o.st.d))

    def test_false_crash_blocks_before_state_and_journal_changes(self):
        with mock.patch.object(R, 'dead', side_effect=RuntimeError('OWNER_OR_CHILD_LIVE')):
            with self.assertRaisesRegex(RuntimeError, 'OWNER_OR_CHILD_LIVE'):
                G.reconcile(self.o, self.ns, self.adm)
        self.assertEqual(self.o.st.sp.read_bytes(), self.before)
        self.assertEqual(self.o.st.jp.read_bytes(), self.journal)

    def test_wrong_instance_and_tampered_attempt_block(self):
        self.adm.descriptor['instance_sha256'] = 'C'*64
        with self.assertRaisesRegex(Exception, 'G3_ATTEMPT_BINDING'):
            G.reconcile(self.o, self.ns, self.adm)
        self.assertEqual(self.o.st.jp.read_bytes(), self.journal)

    def test_state_drift_blocks(self):
        self.o.st.sp.write_bytes(self.before + b' ')
        with self.assertRaisesRegex(Exception, 'G3_INTERRUPTED_STATE_DRIFT'):
            G.reconcile(self.o, self.ns, self.adm)

    def test_tampered_predecessor_blocks(self):
        (self.o.rd/'G3_JOURNAL_BEFORE.jsonl').write_bytes(b'wrong')
        with self.assertRaisesRegex(Exception, 'G3_PREDECESSOR_DRIFT'):
            G.reconcile(self.o, self.ns, self.adm)
        self.assertEqual(self.o.st.jp.read_bytes(), self.journal)

    def test_unrecorded_started_cannot_be_recovered(self):
        (self.o.rd/'G3_ATTEMPT.json').unlink()
        with self.assertRaises(Exception):
            G.reconcile(self.o, self.ns, self.adm)
        self.assertEqual(self.o.st.jp.read_bytes(), self.journal)


if __name__ == '__main__':
    unittest.main(verbosity=2)
