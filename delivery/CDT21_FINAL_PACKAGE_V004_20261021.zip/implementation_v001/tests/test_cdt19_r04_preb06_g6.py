"""R04 contract and G6 boundary tests (offline NOT Windows homologation)."""
import hashlib
import importlib
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest

ROOT=Path(__file__).resolve().parents[1]
CONTROL=ROOT/'candidate/control'
OBS=ROOT/'candidate/g5proof'
sys.path.insert(0,str(CONTROL))
sys.path.insert(0,str(OBS))
gate=importlib.import_module('PRE_B06_ENGINEERING_GATE')
full=importlib.import_module('FULL_G5_COMPLETE_PROOF_GATE')
producer=importlib.import_module('G5_FINAL_COMPLETENESS_PRODUCER')
d4=importlib.import_module('D4_FIRST_ADMISSION_TRANSACTION')
bootstrap=importlib.import_module('D4_FIRST_ADMISSION_BOOTSTRAP')
lifecycle=importlib.import_module('FULL_LIFECYCLE')
observer=importlib.import_module('NATIVE_EXECUTION_OBSERVER')


# R05R1 fixture-only repair. Windows symlinks can require SeCreateSymbolicLinkPrivilege;
# a local NTFS junction is another real directory reparse point (0x400),
# and exercises the identical production guard without changing Windows policy.
def make_owned_reparse_fixture(alias, target):
    import os, subprocess
    try:
        alias.symlink_to(target, target_is_directory=True)
    except OSError as exc:
        if os.name != 'nt' or getattr(exc, 'winerror', None) != 1314:
            raise
        cmd = Path(os.environ['SystemRoot']) / 'System32' / 'cmd.exe'
        if not cmd.is_file():
            raise RuntimeError('NATIVE_REPARSE_FIXTURE_CMD_NOT_FOUND') from exc
        run = subprocess.run([str(cmd), '/d', '/c', 'mklink', '/J', str(alias), str(target)],
                             capture_output=True, timeout=20)
        if run.returncode != 0:
            raise RuntimeError('NATIVE_REPARSE_FIXTURE_JUNCTION_FAILED:' +
                               str(run.returncode)) from exc
    attrs = getattr(alias.lstat(), 'st_file_attributes', 0)
    if os.name == 'nt' and not (attrs & 0x400):
        raise RuntimeError('NATIVE_REPARSE_FIXTURE_NOT_REPARSE')
    if not alias.is_dir():
        raise RuntimeError('NATIVE_REPARSE_FIXTURE_NOT_DIRECTORY')


class G6Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.dest=Path(self.tmp.name)/'DEST';self.dest.mkdir()
        self.o=types.SimpleNamespace(cfg={'production_dest_root':str(self.dest)},
                                     eng=types.SimpleNamespace(recovery_process_census=lambda:
                                         {'known_recovery_supervisor_or_workers':0}))
    def test_pass_only_no_lock_no_process(self):
        result=lifecycle._full_multiwork_g6(self.o)
        self.assertEqual(result['RECONCILE'],'PASS')
        self.assertFalse(result['legacy_recovery_invoked'])
        self.assertEqual(result['action'],'NONE')
    def test_writer_lock_blocks_without_mutating(self):
        path=self.dest/'TICKSTORE_WRITER.lock';path.write_bytes(b'owned-unchanged')
        with self.assertRaisesRegex(RuntimeError,'FULL_WRITER_LOCK_RECONCILIATION_REQUIRED'):
            lifecycle._full_multiwork_g6(self.o)
        self.assertEqual(path.read_bytes(),b'owned-unchanged')
    def test_any_process_census_blocks(self):
        self.o.eng.recovery_process_census=lambda:{'known_recovery_supervisor_or_workers':1}
        with self.assertRaisesRegex(RuntimeError,'FULL_PROCESS_RECONCILIATION_REQUIRED'):
            lifecycle._full_multiwork_g6(self.o)
    def test_incomplete_process_census_blocks(self):
        self.o.eng.recovery_process_census=lambda:{'known_recovery_supervisor_or_workers':None}
        with self.assertRaisesRegex(RuntimeError,'FULL_PROCESS_RECONCILIATION_REQUIRED'):
            lifecycle._full_multiwork_g6(self.o)
    def test_lock_created_during_census_blocks(self):
        lock=self.dest/'TICKSTORE_WRITER.lock'
        def race():
            lock.write_bytes(b'new-owned-lock')
            return {'known_recovery_supervisor_or_workers':0}
        self.o.eng.recovery_process_census=race
        with self.assertRaisesRegex(RuntimeError,'FULL_WRITER_LOCK_RECONCILIATION_REQUIRED'):
            lifecycle._full_multiwork_g6(self.o)
        self.assertEqual(lock.read_bytes(),b'new-owned-lock')
    def test_missing_dest_blocks(self):
        self.dest.rmdir()
        with self.assertRaisesRegex(RuntimeError,'FULL_G6_DEST_ROOT_MISSING'):
            lifecycle._full_multiwork_g6(self.o)
    def test_reparse_root_blocks(self):
        with tempfile.TemporaryDirectory() as target:
            alias=Path(self.tmp.name)/'ALIAS'
            make_owned_reparse_fixture(alias,Path(target))
            self.o.cfg['production_dest_root']=str(alias)
            with self.assertRaisesRegex(RuntimeError,'FULL_G6_ROOT_REPARSE'):
                lifecycle._full_multiwork_g6(self.o)

class ContractTests(unittest.TestCase):
    def test_v002_cannot_become_operational_g5(self):
        bogus={'schema':'TICKSTORE_PRE_B06_11_CONSUMER_EVIDENCE_V002'}
        with self.assertRaisesRegex(Exception,'PRE_B06_PROOF_IS_NOT_D4_AUTHORITY'):
            d4.verify_final_g5_completeness(bogus,{},None,None)
        self.assertEqual(bootstrap.validate_instance_binding.__name__,'validate_instance_binding')
    def test_legacy_g5_checks_not_weakened(self):
        self.assertIn('LEGACY_11_CHAIN',full.validate_g5_complete_proof.__code__.co_consts.__str__())
        self.assertTrue(callable(full.inspect_pre_b06_eleven_consumer_evidence))
        self.assertTrue(callable(producer.inspect_pre_b06_eleven))
    def test_powershell_cannot_masquerade_as_python_function_frames(self):
        with self.assertRaisesRegex(RuntimeError,'POWERSHELL_REQUIRES_NATIVE_PROCESS_OBSERVER'):
            observer.observe_call('.','loader.ps1','main',lambda:0,[],'.','abc')
    def test_pre_b06_excludes_superceded_without_reachability_proof(self):
        self.assertIn(gate.SUPERSEDED, (gate.SAFE,gate.GUARD,gate.SUPERSEDED))
    def test_eleven_count_is_exact(self):
        self.assertEqual(len(gate.EXPECTED),11)
        self.assertEqual(len(set(gate.EXPECTED)),11)
        self.assertEqual(set(gate.EXPECTED),set(full.LEGACY11))
    def test_unsubstantiated_v002_rejected(self):
        with self.assertRaises(gate.NotProven):
            gate.verify_dossier({'schema':gate.SCHEMA},ROOT/'candidate',ROOT,native_required=False)

if __name__=='__main__':unittest.main()
