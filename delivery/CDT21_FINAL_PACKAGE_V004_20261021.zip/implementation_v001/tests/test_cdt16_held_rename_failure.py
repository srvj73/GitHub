"""Directed negative controls for CDT16 fail-closed R44D2 evidence retention."""
from __future__ import annotations
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'qual'))
import R44D2_DROOT_AUDIT as D
import SANDBOX_ADMISSION as A

class FailClosedRename(unittest.TestCase):
    def test_os_denial_allows_caller_to_continue(self):
        called = []
        D.require_held_rename_refused({'result':'OS_REFUSED','reason':'sharing violation'},
            case='C', checkpoint=lambda x: called.append(x))
        self.assertEqual(called, [])

    def test_accepted_rename_checkpoints_and_blocks(self):
        called = []
        with self.assertRaisesRegex(A.AdmissionBlocked, 'HELD_RENAME_NOT_DENIED:C'):
            D.require_held_rename_refused({'result':'ADMITTED'}, case='C',
                checkpoint=lambda x: called.append(x))
        self.assertEqual(len(called), 1)
        self.assertFalse(called[0]['next_write_attempted'])
        self.assertEqual(called[0]['rename_result']['result'], 'ADMITTED')

    def test_without_checkpoint_blocks(self):
        with self.assertRaisesRegex(A.AdmissionBlocked, 'HELD_RENAME_CHECKPOINT_MISSING'):
            D.require_held_rename_refused({'result':'ADMITTED'}, case='C')

    def test_atomic_checkpoint_roundtrip_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as t:
            folder = Path(t)
            rec={'case':'C','next_write_attempted':False,'rename_result':{'result':'ADMITTED'}}
            D.atomic_hold_checkpoint(folder, rec)
            target=folder/'HELD_RENAME_FAILURE.json'
            self.assertEqual(json.loads(target.read_bytes()), rec)
            self.assertFalse(any(p.suffix == '.pending' for p in folder.iterdir()))
            with self.assertRaisesRegex(A.AdmissionBlocked, 'HOLD_FAILURE_RECEIPT_PREEXISTS'):
                D.atomic_hold_checkpoint(folder, rec)
            self.assertEqual(json.loads(target.read_bytes()), rec)

if __name__ == '__main__':
    unittest.main()
