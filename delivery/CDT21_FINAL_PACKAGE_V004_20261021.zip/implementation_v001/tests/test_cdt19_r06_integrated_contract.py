"""CDT19 R06 integrated pre-B06 and post-G3 gate contract tests (sandbox)."""
import importlib, io, json, pathlib, sys, unittest, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'candidate/control'))
import FULL_G5_COMPLETE_PROOF_GATE as G
from test_cdt19_r04_evidence_contract import EvidenceContract

def enc(obj): return (json.dumps(obj,sort_keys=True)+'\n').encode()
def make_zip(items):
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED) as z:
        for n,r in items.items(): z.writestr(n,r)
    return b.getvalue()

class ScopeTests(unittest.TestCase):
    def test_v002_real_isolated_positive_and_negative(self):
        proof={'boundary_scope':'OWNED_ISOLATED_NTFS_PRE_B06',
               'operational_authority':False,'protected_effects':False,
               'real_packaged_code_invoked':True,
               'isolated_physical_readback':True,
               'protected_inventory_unchanged':True}
        self.assertIsNone(G.verify_native_isolated_boundary(proof,'D4_REAL_ISOLATED_PATH_NATIVE',pre_b06=True))
        for k,invalid in [('boundary_scope','NATIVE_FULL_INTEGRATED_REAL_EFFECTS'),
                          ('operational_authority',True),('protected_effects',True),
                          ('real_packaged_code_invoked',False),
                          ('isolated_physical_readback',False),
                          ('protected_inventory_unchanged',False)]:
            changed=dict(proof);changed[k]=invalid
            with self.subTest(k=k), self.assertRaises(G.G5Incomplete):
                G.verify_native_isolated_boundary(changed,'D4_REAL_ISOLATED_PATH_NATIVE',pre_b06=True)
    def test_legacy_scope_unchanged(self):
        self.assertEqual(G.PROOFS.count('D4_REAL_ISOLATED_PATH_NATIVE'),1)
        self.assertTrue(callable(G.verify_legacy11))
    def test_v002_cannot_succeed_by_status_only(self):
        native=make_zip({'ENGINEERING_RESULT.json':enc({'schema':'CDT19_PRE_B06_NATIVE_ENGINEERING_V002',
                 'status':'PASS_NATIVE_INTEGRATED_PRE_B06', 'code_manifest_sha256':'A'*64,
                 'final_zip_sha256':'B'*64,'pre_b06_11_receipt':{'member':'MISSING','sha256':'C'*64}}),
                 'LIVE_STATUS.json':enc({'status':'PASS_NATIVE_INTEGRATED_PRE_B06','committed_units':1})})
        with self.assertRaisesRegex(G.G5Incomplete,'PRE_B06_11_RECEIPT'):
            G.verify_native_campaign(native,'A'*64,'B'*64,{},final_members={})
    def test_g6_requires_actual_g3_journal_read_in_installed_path(self):
        text=(ROOT/'candidate/control/FULL_LIFECYCLE.py').read_text()
        self.assertIn("closed_results(evidence.read(o.st.jp), ('G3',)",text)
        self.assertIn('FULL_G6_G3_SAME_INSTANCE_RECOVERY_NOT_PROVEN',text)
        self.assertIn("result['g3_reconciliation_sha256'] = meta['sha256']",text)
        self.assertNotIn('o.n_g6()',text)

class GuardEvidenceTests(unittest.TestCase):
    # Use R04 setup/helpers without inheriting its nine test methods again.
    setUp = EvidenceContract.setUp
    put_blob = EvidenceContract.put_blob
    put_json = EvidenceContract.put_json
    verify = EvidenceContract.verify
    def test_guarded_positive_requires_internal_branch(self):
        self.dossier['consumers'][0].pop('internal_branch_execution')
        with self.assertRaisesRegex(__import__('PRE_B06_ENGINEERING_GATE').NotProven,'GUARD_INTERNAL_BRANCH'):
            self.verify()
    def test_guarded_transition_must_change_bytes(self):
        row=self.dossier['consumers'][0]
        o=json.loads((self.ev/row['internal_branch_execution']['member']).read_bytes())
        o['isolated_transitions'][0]['before_sha256']=o['isolated_transitions'][0]['after_sha256']
        row['internal_branch_execution']=self.put_json(o)
        with self.assertRaisesRegex(__import__('PRE_B06_ENGINEERING_GATE').NotProven,'GUARD_TRANSITION_NOT_PROVEN'):
            self.verify()
    def test_guarded_native_return_must_be_zero(self):
        row=self.dossier['consumers'][0]
        o=json.loads((self.ev/row['internal_branch_execution']['member']).read_bytes())
        o['exit_code']=2
        row['internal_branch_execution']=self.put_json(o)
        with self.assertRaisesRegex(__import__('PRE_B06_ENGINEERING_GATE').NotProven,'GUARD_INTERNAL_NOT_EXECUTED'):
            self.verify()
