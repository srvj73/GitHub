"""In-memory contract fixtures only: never native observations or approvals."""
import copy
import importlib.util
import io
import json
from pathlib import Path
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PATH = ROOT/'candidate/control/FULL_G5_COMPLETE_PROOF_GATE.py'
spec = importlib.util.spec_from_file_location('g5_contract_under_test', PATH)
G = importlib.util.module_from_spec(spec)
spec.loader.exec_module(G)


def canonical(obj):
    return (json.dumps(obj, sort_keys=True, separators=(',', ':'))+'\n').encode()


class ContractFixture:
    def __init__(self, runtime_index=None, code=None, package=None):
        self.members = {}
        self.code, self.package, self.run = code or 'A'*64, package or 'B'*64, 'C'*32
        self.index = runtime_index or {p: {'sha256': G.digest(p.encode()), 'bytes': len(p)} for p in G.LEGACY11}
        self.chain = dict(schema='TICKSTORE_LEGACY_11_EFFECTFUL_INTEGRATION_V001',
                          status='PASS_EFFECTFUL_INTEGRATED', native_windows=True,
                          scope='OWNED_SCRATCH', synthetic_substitute=False,
                          production_modified=False, code_manifest_sha256=self.code,
                          final_zip_sha256=self.package, run_id=self.run, executions=[], negative_controls={})
        output_hashes, events = [], []
        for n, path in enumerate(G.LEGACY11):
            output = self.put('EVIDENCE/EFFECTS/%02d.bin' % n, b'FIXTURE_ONLY:'+path.encode())
            event = dict(schema='TICKSTORE_NATIVE_CONSUMER_EFFECT_V001',
                         source_path=path, source_sha256=self.index[path]['sha256'],
                         run_id=self.run, native_windows=True, status='COMMITTED',
                         test_only_branch=False, event_id='E%02d'%n,
                         predecessor_event_ids=events[-1:], pid=100+n,
                         process_creation_filetime=1+n, outputs=[output])
            # Construct explicit *synthetic* CALL/RETURN and effect evidence;
            # unlike the old fixture this exercises observation validation.
            sample=(ROOT/'candidate'/path).read_bytes() if runtime_index else path.encode()
            source_ref=self.put('EVIDENCE/SOURCE/%02d.bin'%n, sample)
            ep=G.ENTRYPOINTS[path][0]
            records=[{'sequence':0,'previous_sha256':'','call_id':0,'phase':'CALL',
                      'pid':100+n,'run_id':self.run,'source_path':path,
                      'source_sha256':self.index[path]['sha256'],'function':ep}]
            records.append(dict(records[0],sequence=1,previous_sha256=G.digest(canonical(records[0]).rstrip(b'\n')),
                                phase='RETURN'))
            trace_raw=b''.join(canonical(v) for v in records)
            obs={'schema':'TICKSTORE_EXECUTION_OBSERVATION_V001','run_id':self.run,
                 'pid':100+n,'process_creation_filetime':1+n,'exit_code':0,
                 'native_windows':True,'source':source_ref,
                 'runner':{'path':path,'source':source_ref},
                 'trace':self.put('EVIDENCE/TRACE/%02d.jsonl'%n,trace_raw),
                 'effects':[dict(output,before_sha256='0'*64)]}
            event['entrypoint']=ep
            event['observation']=self.put('EVIDENCE/OBSERVATIONS/%02d.json'%n,canonical(obs))
            ref = self.put('EVIDENCE/EVENTS/%02d.json'%n, canonical(event))
            self.chain['executions'].append(dict(source_path=path, source_sha256=self.index[path]['sha256'], receipt=ref))
            events.append(event['event_id']); output_hashes.append(output['sha256'])
        terminal = dict(schema='TICKSTORE_NATIVE_CHAIN_TERMINAL_V001', run_id=self.run,
                        source_event_ids=sorted(events), effect_artifact_sha256=sorted(output_hashes),
                        tree_members_after_exit=[], state_journal_checkpoint_consistent=True)
        self.chain['terminal_readback'] = self.put('EVIDENCE/TERMINAL.json', canonical(terminal))
        for name in G.NEGATIVE_CONTROLS:
            artifacts = [self.put('EVIDENCE/NEGATIVE/'+name+'/'+s, b'FIXTURE_ONLY:'+s.encode())
                         for s in ('before', 'after')]
            control = dict(schema='TICKSTORE_NATIVE_NEGATIVE_CONTROL_V001', probe=name,
                           native_windows=True, run_id=self.run, status='PASS',
                           reproduction_observed=True, fixed_probe_rejected=True,
                           positive_control_committed=True, artifacts=artifacts)
            self.chain['negative_controls'][name] = self.put('EVIDENCE/NEGATIVE/'+name+'.json', canonical(control))
        self.result = dict(schema='CDT18_ONE_SINGLE_FULL_ENGINEERING_QUAL_V001',
                           status='PASS_NATIVE_INTEGRATED_PRE_G5_DECISION',
                           code_manifest_sha256=self.code, final_zip_sha256=self.package,
                           legacy_11_effectful_windows='PASS_EFFECTFUL_INTEGRATED',
                           legacy_11_effectful_receipt_schema=self.chain['schema'],
                           native_proofs_are_sandbox_experiments=False, synthetic_d4_stage_b_substitute=False,
                           production_modified=False, full_started=False, blockers=[], b06='NOT_STARTED',
                           g5_final='NOT_ISSUED', tests={})
        for name in G.SUITES:
            member = 'LOGS/'+name+'.log'
            ref = self.put(member, b'Ran 2 tests in 0.01s\n\nOK\n')
            self.result['tests']['SUITE_'+name] = dict(status='PASS_NATIVE_SCOPED', exit_code=0,
                                                       skipped=False, test_count=2, log=member, sha256=ref['sha256'])
        for name in G.PROOFS:
            ref = self.put('EVIDENCE/PROOFS/'+name+'/FIXTURE.txt', b'FIXTURE_ONLY')
            proof = dict(schema='TICKSTORE_G5_TARGET_PROOF_RECEIPT_V001', proof=name,
                         kind='CONTRACT_SHAPE_FIXTURE', native_windows=True,
                         code_manifest_sha256=self.code, final_zip_sha256=self.package,
                         status='EMULATED_PASS' if name == 'POWERLOSS_EMULATED' else 'PASS',
                         production_execution=False, gate_verdict_issued=False, error=None,
                         checks={'fixture_shape_only': 'PASS'}, artifacts=[ref])
            if name in ('D4_REAL_ISOLATED_PATH_NATIVE','STAGE_B_REAL_ISOLATED_PATH_NATIVE'):
                # Hypothetical positive dialect ONLY, not a physical native result.
                proof['boundary_scope']='NATIVE_FULL_INTEGRATED_REAL_EFFECTS'
            if name == 'POWERLOSS_EMULATED': proof['counts_as'] = 'NOT_CHECKPOINT_POWERLOSS_RECOVERY'
            self.put('EVIDENCE/PROOFS/'+name+'/PROOF_RECEIPT.json', canonical(proof))
            self.result['tests']['G5_'+name] = dict(status='PASS_NATIVE_SCOPED', exit_code=0)
        self.refresh_chain()
        self.live = dict(status=self.result['status'], committed_units=len(self.result['tests']))

    def put(self, name, raw):
        self.members[name] = raw
        return dict(member=name, sha256=G.digest(raw), bytes=len(raw))

    def refresh_chain(self):
        ref = self.put('EVIDENCE/LEGACY11/CHAIN_RECEIPT.json', canonical(self.chain))
        self.result['legacy_11_effectful_receipt'] = ref
        self.result['tests']['LEGACY_11_CHAIN'] = dict(status='PASS_EFFECTFUL_INTEGRATED', exit_code=0, receipt=ref)

    def mutate_event(self, n, key, value):
        row = self.chain['executions'][n]
        event = json.loads(self.members[row['receipt']['member']])
        event[key] = value
        row['receipt'] = self.put(row['receipt']['member'], canonical(event))
        self.refresh_chain()

    def archive(self):
        self.put('ENGINEERING_RESULT.json', canonical(self.result))
        self.put('LIVE_STATUS.json', canonical(self.live))
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, 'w') as arc:
            for name, raw in self.members.items(): arc.writestr(name, raw)
        return stream.getvalue()

    def check(self):
        return G.verify_native_campaign(self.archive(), self.code, self.package, self.index)


class EvidenceContract(unittest.TestCase):
    def setUp(self):
        self.f = ContractFixture()
        # Synthetic CALL/RETURN records now pass through the real validator.
        # This tests only contract consistency, NEVER native authenticity.
    def blocked(self, reason):
        with self.assertRaisesRegex(G.G5Incomplete, reason): self.f.check()
    def test_complete_contract_shape_only(self):
        self.assertEqual(len(self.f.check()[1]), len(G.SUITES)+len(G.PROOFS)+1)
    def test_chain_not_present(self):
        self.f.result.pop('legacy_11_effectful_receipt'); self.blocked('CHAIN_REQUIRED')
    def test_one_consumer_not_called(self):
        self.f.chain['executions'].pop(); self.f.refresh_chain(); self.blocked('EXECUTIONS_REQUIRED')
    def test_static_source_hash_is_not_execution(self):
        self.f.chain['executions'][0].pop('receipt'); self.f.refresh_chain(); self.blocked('EXECUTION_REF')
    def test_test_only_branch_does_not_count(self):
        self.f.mutate_event(2, 'test_only_branch', True); self.blocked('EFFECT_NOT_PROVEN')
    def test_foreign_source_hash(self):
        self.f.index[G.LEGACY11[3]]['sha256'] = 'D'*64; self.blocked('PACKAGED_SOURCE')
    def test_forked_unlinked_event(self):
        self.f.mutate_event(3, 'predecessor_event_ids', []); self.blocked('CAUSAL_CHAIN')
    def test_forward_reference(self):
        self.f.mutate_event(3, 'predecessor_event_ids', ['E09']); self.blocked('CAUSAL_CHAIN')
    def test_output_changed(self):
        self.f.members['EVIDENCE/EFFECTS/02.bin'] += b'tampered'; self.blocked('ARTIFACT_BYTES')
    def test_missing_effect(self):
        self.f.mutate_event(2, 'outputs', []); self.blocked('EFFECT_ARTIFACTS_REQUIRED')
    def test_foreign_run(self):
        self.f.mutate_event(2, 'run_id', 'D'*32); self.blocked('EFFECT_NOT_PROVEN')
    def test_source_only_pid_absent(self):
        self.f.mutate_event(2, 'pid', None); self.blocked('PROCESS_IDENTITY')
    def test_negative_control_missing(self):
        self.f.chain['negative_controls'].pop(G.NEGATIVE_CONTROLS[0]); self.f.refresh_chain(); self.blocked('NEGATIVE_CONTROLS_REQUIRED')
    def test_false_final_commit_count(self):
        self.f.live['committed_units'] -= 1; self.blocked('TERMINAL_COMMITTED')
    def test_count_does_not_replace_required_unit(self):
        obj = self.f.result['tests'].pop('SUITE_'+G.SUITES[0]); self.f.result['tests']['OTHER'] = obj; self.blocked('UNIT_SET')
    def test_log_test_count_mismatch(self):
        self.f.result['tests']['SUITE_'+G.SUITES[0]]['test_count'] = 999; self.blocked('SUITE_RESULT')
    def test_declared_skip(self):
        self.f.result['tests']['SUITE_'+G.SUITES[0]]['skipped'] = True; self.blocked('SUITE_NOT_PASS')
    def test_missing_flag_is_not_false(self):
        self.f.result.pop('synthetic_d4_stage_b_substitute'); self.blocked('SYNTHETIC_SUBSTITUTION')
    def test_proof_cannot_be_artifact_free(self):
        name = 'EVIDENCE/PROOFS/'+G.PROOFS[0]+'/PROOF_RECEIPT.json'
        obj = json.loads(self.f.members[name]); obj['artifacts'] = []; self.f.put(name, canonical(obj)); self.blocked('ARTIFACTS_REQUIRED')
    def test_bounded_native_proof_cannot_impersonate_final(self):
        name = 'EVIDENCE/PROOFS/D4_REAL_ISOLATED_PATH_NATIVE/PROOF_RECEIPT.json'
        obj = json.loads(self.f.members[name])
        obj['boundary_scope'] = 'PRE_B06_ISOLATED_REAL_CODE'
        self.f.put(name, canonical(obj)); self.blocked('BOUNDED_PROOF_NOT_FINAL_G5')
    def test_synthetic_1399_is_not_real_d4(self):
        name = 'EVIDENCE/PROOFS/D4_REAL_ISOLATED_PATH_NATIVE/PROOF_RECEIPT.json'
        obj = json.loads(self.f.members[name]); obj['kind'] = 'TICKSTORE_G5_PROOF_D4_CLOSURE_SYNTHETIC_1399_V001'
        self.f.put(name, canonical(obj)); self.blocked('PROOF_SYNTHETIC')
    def test_duplicate_json_key(self):
        self.f.members['EVIDENCE/LEGACY11/CHAIN_RECEIPT.json'] = b'{"status":"PASS","status":"FAIL"}'
        raw = self.f.members['EVIDENCE/LEGACY11/CHAIN_RECEIPT.json']
        self.f.result['legacy_11_effectful_receipt'] = self.f.put('EVIDENCE/LEGACY11/CHAIN_RECEIPT.json', raw)
        self.blocked('JSON_DUPLICATE_KEY')


if __name__ == '__main__': unittest.main(verbosity=2)
