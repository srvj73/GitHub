"""Synthetic in-memory contract roundtrip, not a native engineering receipt."""
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'candidate/control'))
sys.path.insert(0,str(ROOT/'tests'))
from test_cdt17_final_g5_complete_proof_gate import ClosedFixture,canon,sha
from G5_FINAL_COMPLETENESS_PRODUCER import produce,Blocked
from FULL_G5_COMPLETE_PROOF_GATE import FIVE,G5Incomplete,validate_g5_complete_proof


class ProducerRoundtrip(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='CDT18_G5_CONTRACT_FIXTURE_')
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.fixture=ClosedFixture()
        self.fixture.generate()
        self.final=self.root/'FIXTURE_FINAL.zip'
        self.native=self.root/'FIXTURE_NATIVE.zip'
        self.instance=self.root/'FIXTURE_INSTANCE.json'
        self.adverse=self.root/'FIXTURE_ADVERSARIAL.json'
        self.out=self.root/'OUTPUT'
        self.final.write_bytes(self.fixture.objects['FINAL_PACKAGE_ZIP'])
        self.native.write_bytes(self.fixture.objects['NATIVE_RETURN_ZIP'])
        self.instance.write_bytes(canon({'schema':'TICKSTORE_FULL_INSTANCE_V001',
                                        'code_manifest_sha256':self.fixture.code}))
        self.adverse.write_bytes(self.fixture.objects['ADVERSARIAL_CLOSURE'])

    def produce(self):
        return produce(self.final,self.native,self.instance,self.adverse,self.out)

    def test_all_five_physical_files_and_no_origin_decision(self):
        result=self.produce()
        self.assertEqual(result['status'],'EVIDENCE_READY_ORIGIN_G5_NOT_ISSUED')
        self.assertEqual(result['g5'],'NOT_ISSUED')
        self.assertEqual(result['b06'],'NOT_STARTED')
        self.assertFalse(result['full_started'])
        self.assertEqual({p.stem for p in (self.out/'FIVE_PART_PROOFS').iterdir()},set(FIVE))
        self.assertFalse(list(self.out.rglob('ORIGIN_DECISION*')))
        for path in (self.out/'FIVE_PART_PROOFS').iterdir():
            proof=json.loads(path.read_bytes())
            self.assertIn('LEGACY_11_CHAIN',{e['role'] for e in proof['evidence']})
            for ref in proof['evidence']:
                self.assertEqual(sha(Path(ref['path']).read_bytes()),ref['sha256'])

    def test_existing_output_is_preserved(self):
        self.out.mkdir();(self.out/'KEEP').write_bytes(b'keep')
        with self.assertRaisesRegex(Blocked,'OUTPUT_ALREADY_EXISTS'):self.produce()
        self.assertEqual((self.out/'KEEP').read_bytes(),b'keep')

    def test_native_zip_substitution_blocks_before_output_creation(self):
        self.native.write_bytes(b'not native evidence')
        with self.assertRaisesRegex(G5Incomplete,'NATIVE_ZIP_INVALID'):self.produce()
        self.assertFalse(self.out.exists())

    def test_foreign_adversarial_native_hash_blocks_before_write(self):
        obj=json.loads(self.adverse.read_bytes());obj['native_g5_return_sha256']='D'*64
        self.adverse.write_bytes(canon(obj))
        with self.assertRaisesRegex(Blocked,'ADVERSARIAL_CLOSURE_NOT_PROVEN'):self.produce()
        self.assertFalse(self.out.exists())


if __name__=='__main__':unittest.main(verbosity=2)
