"""Physical receipt coverage; native liveness is separately exercised on Windows."""
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]/'candidate'
for name in ('full', 'control'):
    sys.path.insert(0, str(ROOT/name))
import FULL_CRASH_RECOVERY as R
import FULL_LIFECYCLE as L


class Closure(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.adm = types.SimpleNamespace(instance={'run_id':'run', 'bindings':{
            'scratch_root':str(self.root/'scratch'), 'dest_root':str(self.root/'dest')}},
            descriptor={'instance_sha256':'A'*64,'code_manifest_sha256':'B'*64})
        scratch=self.root/'scratch/RUN_INSTANCES/run'
        expected=R.binding(self.adm,self.root/'dest',scratch)
        self.a=scratch/'RECOVERY_ATTEMPTS'/('a'*32);self.a.mkdir(parents=True)
        self.b=self.a.with_name('b'*32);self.b.mkdir()
        def owner(path,pid):
            return R.publish(path/'OWNER.json',dict(schema='TICKSTORE_MULTIWORK_ATTEMPT_OWNER_V001',
                attempt_id=path.name,binding=expected,owner={'pid':pid,'creation_filetime':pid*100}))
        ar=owner(self.a,1);br=owner(self.b,2)
        self.child={'pid':3,'creation_filetime':300}
        cr=R.publish(self.a/'CHILD_3_300.json',dict(schema='TICKSTORE_MULTIWORK_CHILD_OWNER_V001',
                  owner_sha256=ar['sha256'],identity=self.child))
        self.retired=dict(schema='TICKSTORE_MULTIWORK_DEAD_ATTEMPT_V001',binding=expected,owner=ar,
            children=[cr],process_observations=[dict(pid=1,creation_filetime=100,observation='ABSENT'),
                dict(self.child,observation='ABSENT')],own_processes_alive=0,lock_disposition='NO_LOCK_BEFORE_ADMISSION')
        pr=R.publish(self.a/'RETIRED.json',self.retired)
        self.closed=dict(schema='TICKSTORE_MULTIWORK_ATTEMPT_CLOSED_V001',owner_sha256=br['sha256'],
            outcome='ENGINE_RECONCILED',writer_lock='ABSENT',own_processes_alive=0,process_observations=[])
        close=R.publish(self.b/'CLOSED.json',self.closed)
        self.rec={'attempt_owner':br,'attempt_closed':close,'predecessor_attempts':[pr]}
        self.mock=mock.patch.object(R,'dead',side_effect=lambda p:dict(p,observation='ABSENT'))
        self.mock.start();self.addCleanup(self.mock.stop)

    def read(self,path,expected=None):
        raw=R.core.secure_read_all(Path(path))
        if expected is not None and R.sha(raw)!=expected:raise ValueError('HASH_MISMATCH')
        return raw

    def rewrite_retired(self):
        p=self.a/'RETIRED.json';p.write_bytes(R.encoded(self.retired))
        self.rec['predecessor_attempts'][0]['sha256']=R.sha(p.read_bytes())

    def verify(self):return L.verify_dead_predecessors(self.rec,self.adm,self.read)

    def test_complete_physical_set(self):
        self.assertEqual(self.verify()['g3_dead_predecessors_verified'],1)

    def test_missing_child_reference_even_with_rehashed_receipt(self):
        self.retired['children']=[];self.rewrite_retired()
        with self.assertRaisesRegex(Exception,'CHILD_SET'):self.verify()

    def test_partial_death_observation(self):
        self.retired['process_observations'].pop();self.rewrite_retired()
        with self.assertRaisesRegex(Exception,'PROCESS_SET'):self.verify()

    def test_false_death_kind(self):
        self.retired['process_observations'][0]['observation']='LIVE';self.rewrite_retired()
        with self.assertRaisesRegex(Exception,'OBSERVATION_KIND'):self.verify()

    def test_duplicate_process_observation(self):
        self.retired['process_observations'].append(dict(self.retired['process_observations'][0]));self.rewrite_retired()
        with self.assertRaisesRegex(Exception,'DUPLICATE_PROCESS'):self.verify()

    def test_current_closed_omits_physical_child(self):
        R.publish(self.b/'CHILD_4_400.json',dict(schema='TICKSTORE_MULTIWORK_CHILD_OWNER_V001',
                  owner_sha256=self.rec['attempt_owner']['sha256'],identity={'pid':4,'creation_filetime':400}))
        with self.assertRaisesRegex(Exception,'CLOSED_CHILD_SET'):self.verify()

    def test_changed_child_bytes(self):
        p=self.a/'CHILD_3_300.json';p.write_bytes(p.read_bytes()+b' ')
        with self.assertRaisesRegex(Exception,'CHILD_SET'):self.verify()

    def test_missing_owner_blocks(self):
        (self.a/'OWNER.json').unlink()
        with self.assertRaises(Exception):self.verify()

if __name__=='__main__':unittest.main(verbosity=2)
