"""G5 producer/consumer after B2-G5-01: physical provenance, negative controls, never a gate PASS.

The positive fixture is synthetic (see g5_native_fixture); it proves only the mechanics.
Every adversarial condition reproduced by the origin must block in BOTH the producer
(G5_EVIDENCE_BUILDER.build) and the consumer (FULL_QUALIFICATION_CONTRACT.validate).
"""
import copy
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

R = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(R / 'candidate/control'))
sys.path.insert(0, str(R / 'tests'))
import G5_EVIDENCE_BUILDER as G  # noqa: E402
import g5_native_fixture as FX  # noqa: E402

BASELINE = R / 'tests/fixtures/V38_NATIVE_QUALIFICATION_RESULT_ORIGINAL_DC73A8C3.zip'
ADVERSARIAL = R / 'tests/fixtures/ORIGIN_B2_reproduce_adversarial_completeness.py'
ADVERSARIAL_SHA = '1AB624048C66F73EA60EEE7624DA442AD82BFE823442AFC3D2C5328C46ADB8F8'
CONTRACT = FX.CONTRACT
POWER = 'POWERLOSS_EMULATED:PROCESS_DEATH_RECOVERY_INVARIANTS'


def h(raw):
    return hashlib.sha256(raw).hexdigest().upper()


class Base(unittest.TestCase):
    hypothetical = False

    def setUp(self):
        t = tempfile.TemporaryDirectory(); self.addCleanup(t.cleanup); self.t = Path(t.name)
        self.ns = FX.with_physical_powerloss_spec() if self.hypothetical else FX.load_consumer()
        self.fx = FX.NativeFixture(self.ns)
        self.n = 0

    def build(self, blockers=(), baseline=BASELINE):
        self.n += 1
        rz, fz, code_sha, final_sha = self.fx.make(self.t, 'F%d' % self.n)
        out = self.t / ('OUT%d' % self.n)
        sha = h((R / 'candidate/control/FULL_QUALIFICATION_CONTRACT.py').read_bytes())
        with mock.patch.object(G, 'load_consumer', return_value=(self.ns, sha)):
            c = G.build(return_zip=rz, final_zip=fz, baseline_archive=baseline, known_blockers=list(blockers),
                        out_dir=out)
        return c, out

    def consume(self, c):
        def require(cond, why):
            if not cond:
                raise G.Blocked(why)
        self.ns['validate'](c, CONTRACT, c['delta_qualification'], c['code_manifest_sha256'], require)

    def assert_blocks(self, needle):
        c, out = self.build()
        self.assertEqual(c['status'], 'INCOMPLETE')
        self.assertTrue(any(needle in b for b in c['known_blockers']), c['known_blockers'])
        self.assertTrue(c['consumer_self_check'].startswith('REJECTS'), c['consumer_self_check'])
        with self.assertRaises(G.Blocked):
            self.consume(c)
        return c, out


class MechanicsAcceptWithHypotheticalPhysicalSpec(Base):
    hypothetical = False

    def test_01_closed_native_return_zip_is_accepted_by_both(self):
        c, out = self.build()
        self.assertEqual(c['known_blockers'], [])
        self.assertEqual(c['status'], 'COMPLETE'); self.assertEqual(c['consumer_self_check'], 'ACCEPTS')
        self.assertEqual(c['windows_qualification'], 'PASS'); self.assertEqual(c['provenance_mode'], 'CLOSED_NATIVE_RETURN_ZIP')
        self.assertEqual(c['delta_test_totals'], {'run': 126, 'failures': 0, 'errors': 0, 'skips': 0})
        self.consume(c)
        delta_raw = (out / 'DELTA_QUALIFICATION.json').read_bytes()
        self.assertEqual(c['delta_qualification_evidence']['sha256'], h(delta_raw))
        prov = c['delta_qualification']['native_provenance']
        self.assertEqual(prov['code_manifest_files'], 2)
        self.assertEqual(h((out / prov['return_zip']['pack_relative']).read_bytes()), prov['return_zip']['sha256'])

    def test_02_pack_is_relocatable_but_bytes_stay_bound(self):
        c, out = self.build()
        moved = self.t / 'MOVED'; shutil.move(str(out), str(moved))
        c2 = json.loads((moved / 'ENGINEERING_COMPLETENESS.json').read_bytes())
        c2['delta_qualification_evidence']['path'] = str(moved / 'DELTA_QUALIFICATION.json')
        for e in c2['delta_qualification']['target_proofs'].values():
            e['evidence'][0]['path'] = str(self.t / 'gone.json')
        for k in ('return_zip', 'final_zip'):
            c2['delta_qualification']['native_provenance'][k]['path'] = str(self.t / 'gone.zip')
        self.consume(c2)
        z = moved / c2['delta_qualification']['native_provenance']['return_zip']['pack_relative']
        z.write_bytes(z.read_bytes() + b'x')
        with self.assertRaisesRegex(G.Blocked, 'PROVENANCE_RETURN_ZIP_SHA256'):
            self.consume(c2)

    def test_03_consumer_rejects_delta_tests_not_from_physical_harness(self):
        c, _ = self.build()
        d = c['delta_qualification']
        d['tests'] = list(reversed(d['tests']))
        with self.assertRaisesRegex(G.Blocked, 'DELTA_TESTS_NOT_PHYSICAL_HARNESS'):
            self.consume(c)

    def test_04_consumer_rejects_hand_written_delta_without_provenance(self):
        c, _ = self.build()
        del c['delta_qualification']['native_provenance']
        with self.assertRaisesRegex(G.Blocked, 'NATIVE_PROVENANCE_MISSING'):
            self.consume(c)


class ProcessOnlyRecoveryContract(Base):
    def test_05_six_distinct_typed_proofs_with_true_emulated_status(self):
        c, _ = self.build()
        self.assertEqual(c['status'], 'COMPLETE')
        self.assertEqual(c['consumer_self_check'], 'ACCEPTS')
        self.assertEqual(c['delta_qualification']['target_proofs']['POWERLOSS_EMULATED']['status'], 'EMULATED_PASS')
        self.assertEqual(c['powerloss_emulated']['counts_as'], 'NOT_CHECKPOINT_POWERLOSS_RECOVERY')
        self.consume(c)

    def test_06_absent_process_recovery_receipt_fails_closed(self):
        del self.fx.proofs['POWERLOSS_EMULATED']
        self.assert_blocks('POWERLOSS_EMULATED:EVIDENCE_NOT_SINGLE_TYPED_RECEIPT')

    def test_07_plain_pass_cannot_impersonate_emulated_pass(self):
        self.fx.proofs['POWERLOSS_EMULATED'] = {'status': 'PASS'}
        self.assert_blocks('POWERLOSS_EMULATED:RECEIPT_STATUS:PASS')

    def test_08_physical_loss_cannot_be_claimed(self):
        self.fx.proofs['POWERLOSS_EMULATED'] = {'counts_as': 'CHECKPOINT_POWERLOSS_RECOVERY'}
        self.assert_blocks('POWERLOSS_EMULATED:PROCESS_ONLY_SCOPE_MISSING')

    def test_09_process_recovery_observation_required(self):
        self.fx.proofs['POWERLOSS_EMULATED'] = {'artifacts': []}
        self.assert_blocks('POWERLOSS_EMULATED:RECEIPT_NO_ARTIFACTS')

    def test_09a_never_issues_a_gate_pass(self):
        c, out = self.build()
        draft = json.loads((out / 'G5_STAGE_RECEIPT_DRAFT.json').read_bytes())
        self.assertEqual(draft['status'], 'PENDING_ORIGIN_DECISION')
        self.assertFalse(draft['gate_verdict_issued']); self.assertFalse(c['gate_verdict_issued'])
        for path in out.rglob('*.json'):
            self.assertNotIn(b'"status":"PASS","stage"', path.read_bytes())
        from FULL_RELEASE_CHAIN import validate_chain
        with self.assertRaises(Exception):
            validate_chain({'G5': draft}, {'G5': 'A' * 64}, code_sha=c['code_manifest_sha256'],
                           instance_sha='B' * 64, b06_sha='C' * 64, until='G5')


class ProcessDeathSemanticNegativeControls(Base):
    def setUp(self):
        super().setUp()
        self.name = 'POWERLOSS_EMULATED'
        self.rec, self.arts = self.fx.receipt(self.name, 'A' * 64, 'B' * 64)

    def findings(self, *, receipt=None, observation=None):
        rec = copy.deepcopy(receipt if receipt is not None else self.rec)
        arts = dict(self.arts)
        if observation is not None:
            member = next(iter(arts))
            art = FX.j(observation)
            arts[member] = art
            rec['artifacts'][0]['sha256'] = h(art)
            rec['artifacts'][0]['bytes'] = len(art)
        return self.ns['proof_receipt_findings'](self.name, rec,
                self.ns['PROOF_PREFIX'] + self.name + '/PROOF_RECEIPT.json', arts,
                {self.ns['PROOF_RUNNER']: rec['runner']['sha256']},
                'A' * 64, 'B' * 64, self.fx.run_id)

    def test_real_process_death_semantics_pass(self):
        self.assertEqual(self.findings(), [])

    def test_fake_physical_claim_rejected(self):
        r = dict(self.rec, counts_as='CHECKPOINT_POWERLOSS_RECOVERY')
        self.assertIn('POWERLOSS_EMULATED:PROCESS_ONLY_SCOPE_MISSING', self.findings(receipt=r))

    def test_forged_emulated_pass_as_plain_pass_rejected(self):
        r = dict(self.rec, status='PASS')
        self.assertIn('POWERLOSS_EMULATED:RECEIPT_STATUS:PASS', self.findings(receipt=r))

    def test_observation_tamper_even_after_rehash_rejected(self):
        member = next(iter(self.arts)); obs = json.loads(self.arts[member]);
        obs['not_physical_power_loss'] = False
        self.assertIn('POWERLOSS_EMULATED:PROCESS_DEATH_RECOVERY_INVARIANTS',
                      self.findings(observation=obs))

    def test_recovery_not_equal_to_control_rejected(self):
        member = next(iter(self.arts)); obs = json.loads(self.arts[member]);
        obs['containers_after_recovery'] = {'day': 'B' * 64}
        self.assertIn('POWERLOSS_EMULATED:PROCESS_DEATH_RECOVERY_INVARIANTS',
                      self.findings(observation=obs))

    def test_only_one_killed_process_not_enough(self):
        member = next(iter(self.arts)); obs = json.loads(self.arts[member]);
        obs['events'] = obs['events'][:1]
        self.assertIn('POWERLOSS_EMULATED:PROCESS_DEATH_RECOVERY_INVARIANTS',
                      self.findings(observation=obs))

    def test_forged_pre_execution_receipt_status_rejected(self):
        r = dict(self.rec, native_windows=False, status='OFFLINE_HARNESS_ONLY')
        f = self.findings(receipt=r)
        self.assertIn('POWERLOSS_EMULATED:RECEIPT_NOT_NATIVE', f)
        self.assertIn('POWERLOSS_EMULATED:RECEIPT_STATUS:OFFLINE_HARNESS_ONLY', f)


class OriginAdversarialControls(Base):
    """B2-G5-01 conditions, one by one, on the closed native interface."""
    hypothetical = False

    def test_10_empty_code_manifest(self):
        self.fx.empty_code_manifest = True
        self.assert_blocks('FINAL_RUNTIME_MANIFEST_EMPTY')

    def test_11_127_records_for_126_ids(self):
        self.fx.harness['tests'].append(dict(self.fx.harness['tests'][0]))
        self.assert_blocks('HARNESS_DUPLICATE_RECORDS:' + CONTRACT['required_tests'][0])

    def test_12_harness_success_false(self):
        self.fx.harness['success'] = False
        self.assert_blocks('HARNESS_SUCCESS_NOT_TRUE')

    def test_13_harness_tests_run_zero(self):
        self.fx.harness['totals'] = {'tests_run': 0, 'failures': 0, 'errors': 0, 'skips': 0}
        self.assert_blocks('HARNESS_TOTALS')

    def test_14_declared_native_without_windows_evidence(self):
        self.fx.harness.update(platform='Linux-6.18-x86_64', python='3.14.0 [GCC 14]')
        self.fx.precheck.update(platform='Linux-6.18-x86_64', powershell='7.5.0')
        c, _ = self.assert_blocks('HARNESS_PLATFORM_NOT_WINDOWS')
        self.assertEqual(c['windows_qualification'], 'NOT_PASS')
        self.assertFalse(c['delta_qualification']['native_windows'])
        self.assertIn('QUAL_PRECHECK_PS51', c['known_blockers'])

    def test_15_same_receipt_for_all_proofs(self):
        rec, _ = self.fx.receipt('PROCESS_TREE_CRASH_CONTAINMENT', 'X', 'Y')
        for name in CONTRACT['required_target_proofs']:
            self.fx.proof_override[name] = rec
        c, _ = self.assert_blocks('EVIDENCE_REUSED_FROM')
        self.assertTrue(any('RECEIPT_PROOF_NAME' in b for b in c['known_blockers']))

    def test_16_generic_receipt_without_named_checks(self):
        self.fx.proofs['SAFE_STOP_RESUME_ROW_GROUP'] = {'checks': {'generic': 'PASS'}}
        self.assert_blocks('SAFE_STOP_RESUME_ROW_GROUP:RECEIPT_CHECKS')

    def test_17_receipt_without_artifacts(self):
        self.fx.proofs['PS51_INSTALL_MENU'] = {'artifacts': []}
        self.assert_blocks('PS51_INSTALL_MENU:RECEIPT_NO_ARTIFACTS')

    def test_18_receipt_artifact_not_in_return_zip(self):
        self.fx.proofs['D4_REAL_ISOLATED_PATH_NATIVE'] = {
            'artifacts': [{'member': 'EVIDENCE/PROOFS/D4_REAL_ISOLATED_PATH_NATIVE/missing.json', 'sha256': 'A' * 64}]}
        self.assert_blocks('D4_REAL_ISOLATED_PATH_NATIVE:RECEIPT_ARTIFACT')

    def test_19_runner_not_the_packaged_runner(self):
        self.fx.proofs['STAGE_B_REAL_ISOLATED_PATH_NATIVE'] = {
            'runner': {'path': 'somewhere/else.py', 'function': 'proof_stage_b_synthetic_chain', 'sha256': 'A' * 64}}
        self.assert_blocks('STAGE_B_REAL_ISOLATED_PATH_NATIVE:RECEIPT_RUNNER_NOT_PACKAGED')

    def test_20_receipt_from_another_run_or_bytes(self):
        self.fx.proofs['PROCESS_TREE_CRASH_CONTAINMENT'] = {'run_id': 'OTHER_RUN'}
        self.assert_blocks('PROCESS_TREE_CRASH_CONTAINMENT:RECEIPT_RUN_BINDING')

    def test_21_receipt_status_not_pass(self):
        self.fx.proofs['PROCESS_TREE_CRASH_CONTAINMENT'] = {'status': 'FAIL'}
        self.assert_blocks('PROCESS_TREE_CRASH_CONTAINMENT:RECEIPT_STATUS:FAIL')

    def test_22_missing_typed_receipt(self):
        del self.fx.proofs['PS51_INSTALL_MENU']
        self.assert_blocks('PS51_INSTALL_MENU:EVIDENCE_NOT_SINGLE_TYPED_RECEIPT')

    def test_23_final_zip_member_tampered(self):
        self.fx.tamper_final_member = True
        self.assert_blocks('FINAL_RUNTIME_MEMBER:control/EXAMPLE.py')

    def test_24_return_member_outside_return_manifest(self):
        self.fx.extra_return['EVIDENCE/INJECTED.txt'] = b'x'
        self.fx.drop_manifest_entry = 'EVIDENCE/INJECTED.txt'
        self.assert_blocks('RETURN_MANIFEST_COVERAGE')

    def test_25_tests_log_missing_one_id(self):
        self.fx.log_ids = self.fx.log_ids[1:]
        self.assert_blocks('TESTS_LOG_RECORDS:1')

    def test_26_tests_log_failed(self):
        self.fx.log_tail = '\nRan 126 tests in 1.0s\n\nFAILED (failures=1)\n'
        self.assert_blocks('TESTS_LOG_NOT_OK')

    def test_27_receipt_bound_to_other_final_zip(self):
        self.fx.receipt_extra = {'SOURCE_SHA256': 'F' * 64}
        self.assert_blocks('QUAL_RECEIPT_FINAL_ZIP_BINDING')

    def test_28_not_elevated(self):
        self.fx.precheck['elevated'] = False
        self.assert_blocks('QUAL_PRECHECK_ELEVATION_SYMLINK')

    def test_29_harness_bound_to_other_code(self):
        self.fx.harness['code_manifest_sha256'] = 'F' * 64
        c, _ = self.assert_blocks('HARNESS_CODE_MANIFEST_MISMATCH')
        self.assertEqual(c['delta_qualification']['tested_code_equals_packaged_code'], 'FAIL')

    def test_30_one_non_pass_id(self):
        self.fx.harness['tests'][7]['status'] = 'FAIL'
        c, _ = self.assert_blocks('NON_PASS_IDS:' + CONTRACT['required_tests'][7])
        self.assertEqual(c['windows_qualification'], 'NOT_PASS')

    def test_31_known_blocker_and_wrong_baseline(self):
        c, _ = self.build(blockers=['R44-B2C'])
        self.assertIn('R44-B2C', c['known_blockers']); self.assertEqual(c['status'], 'INCOMPLETE')
        other = self.t / 'other.zip'; other.write_bytes(b'not the baseline')
        c, _ = self.build(baseline=other)
        self.assertIn('BASELINE_ARCHIVE_SHA256', c['known_blockers'])

    def test_32_no_clobber(self):
        _, out = self.build()
        rz, fz, _, _ = self.fx.make(self.t, 'NC')
        with self.assertRaisesRegex(G.Blocked, 'OUTPUT_EXISTS'):
            G.build(return_zip=rz, final_zip=fz, baseline_archive=BASELINE, known_blockers=[], out_dir=out)


class GenericConsumerHardening(unittest.TestCase):
    def test_40_same_evidence_cannot_prove_two_requirements(self):
        ns = FX.load_consumer()
        contract = dict(CONTRACT)
        names = contract['required_target_proofs']
        ev = {'path': 'same', 'sha256': 'B' * 64}
        proofs = {k: {'status': ('EMULATED_PASS' if k == 'POWERLOSS_EMULATED' else 'PASS'),
                       'evidence': [{'path': str(k), 'sha256': format(i + 1, '064X')}]} for i, k in enumerate(names)}
        proofs[names[1]]['evidence'] = [ev]
        proofs[names[0]]['evidence'] = [ev]
        delta = dict(schema='TICKSTORE_CDT15_DELTA_QUALIFICATION_V001', platform='WINDOWS_NTFS_PS51',
                     native_windows=True, code_manifest_sha256='A' * 64, tested_code_equals_packaged_code='PASS',
                     production_execution=False, success=True,
                     tests=[{'id': i, 'status': 'PASS'} for i in contract['required_tests']],
                     target_proofs=proofs)
        complete = {'baseline': contract['baseline'],
                    'baseline_archive_evidence': {'path': 'x', 'sha256': contract['baseline']['archive_sha256']},
                    'delta_test_totals': {'run': len(contract['required_tests']), 'failures': 0, 'errors': 0, 'skips': 0},
                    'baseline_results_counted_as_delta': False}
        def require(cond, why):
            if not cond:
                raise G.Blocked(why)
        with self.assertRaisesRegex(G.Blocked, 'DELTA_TARGET_EVIDENCE_REUSED'):
            ns['validate'](complete, contract, delta, 'A' * 64, require)
        proofs[names[1]]['evidence'] = [{'path': 'other', 'sha256': 'C' * 64}]
        with self.assertRaisesRegex(G.Blocked, 'NATIVE_PROVENANCE_MISSING'):
            ns['validate'](complete, contract, delta, 'A' * 64, require)
        delta['harness_totals'] = {'tests_run': 0, 'failures': 0, 'errors': 0, 'skips': 0}
        with self.assertRaisesRegex(G.Blocked, 'DELTA_HARNESS_TOTALS'):
            ns['validate'](complete, contract, delta, 'A' * 64, require)

    def test_41_real_contract_requires_typed_provenance(self):
        ns = FX.load_consumer()
        self.assertEqual(set(CONTRACT['required_target_proofs']), set(ns['TYPED_PROOFS']))


class OriginAdversarialScript(unittest.TestCase):
    """The origin's own reproducer, byte-exact, against the current producer and consumer."""

    def test_50_origin_reproducer_now_incomplete_and_rejected(self):
        self.assertEqual(h(ADVERSARIAL.read_bytes()), ADVERSARIAL_SHA)
        with tempfile.TemporaryDirectory() as t:
            t = Path(t)
            shutil.copytree(R / 'candidate/control', t / 'candidate/control',
                            ignore=shutil.ignore_patterns('__pycache__'))
            (t / 'tests/fixtures').mkdir(parents=True)
            shutil.copy2(BASELINE, t / 'tests/fixtures' / BASELINE.name)
            shutil.copy2(ADVERSARIAL, t / 'reproduce.py')
            r = subprocess.run([sys.executable, '-B', str(t / 'reproduce.py')], capture_output=True, text=True,
                               timeout=300, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
        # The reproducer asserts the old false positive; it must now fail that assertion.
        self.assertNotEqual(r.returncode, 0, r.stdout)
        self.assertIn('AssertionError', r.stderr)
        out = json.loads(r.stdout)
        self.assertEqual(out['status'], 'INCOMPLETE')
        self.assertTrue(out['self_check'].startswith('REJECTS'))
        for needle in ('NATIVE_PROVENANCE_UNBOUND', 'CODE_MANIFEST_EMPTY', 'HARNESS_RECORD_COUNT:127!=126',
                       'HARNESS_DUPLICATE_RECORDS', 'HARNESS_SUCCESS_NOT_TRUE', 'HARNESS_TOTALS',
                       'HARNESS_PLATFORM_NOT_WINDOWS', 'TARGET_PROOF_EVIDENCE_REUSED', 'TARGET_PROOF_NOT_TYPED_RECEIPT'):
            self.assertTrue(any(needle in b for b in out['blockers']), (needle, out['blockers']))
        self.assertFalse(out['gate_verdict_issued'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
