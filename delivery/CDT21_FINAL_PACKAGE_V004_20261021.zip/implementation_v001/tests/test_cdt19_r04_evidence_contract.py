"""Adversarial contract fixtures. ALL rows here are synthetic and NOT native proof."""
import hashlib,importlib,json,pathlib,sys,tempfile,unittest,uuid
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'candidate/control'))
G=importlib.import_module('PRE_B06_ENGINEERING_GATE')
def sha(b):return hashlib.sha256(b).hexdigest().upper()
def canonical(o):return (json.dumps(o,sort_keys=True)+'\n').encode('utf8')


# R05R1 fixture-only repair. Windows symlinks can require SeCreateSymbolicLinkPrivilege;
# a local NTFS junction is another real directory reparse point (0x400),
# and exercises the identical production guard without changing Windows policy.
def make_owned_reparse_fixture(alias, target):
    import os, subprocess
    try:
        alias.symlink_to(target, target_is_directory=True)
    except OSError as exc:
        if os.name != 'nt' or getattr(exc, 'winerror', None) != 1314:
            raise
        cmd = pathlib.Path(os.environ['SystemRoot']) / 'System32' / 'cmd.exe'
        if not cmd.is_file():
            raise RuntimeError('NATIVE_REPARSE_FIXTURE_CMD_NOT_FOUND') from exc
        run = subprocess.run([str(cmd), '/d', '/c', 'mklink', '/J', str(alias), str(target)],
                             capture_output=True, timeout=20)
        if run.returncode != 0:
            raise RuntimeError('NATIVE_REPARSE_FIXTURE_JUNCTION_FAILED:' +
                               str(run.returncode)) from exc
    attrs = getattr(alias.lstat(), 'st_file_attributes', 0)
    if os.name == 'nt' and not (attrs & 0x400):
        raise RuntimeError('NATIVE_REPARSE_FIXTURE_NOT_REPARSE')
    if not alias.is_dir():
        raise RuntimeError('NATIVE_REPARSE_FIXTURE_NOT_DIRECTORY')


class EvidenceContract(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=pathlib.Path(self.temp.name);self.cand=self.root/'candidate';self.cand.mkdir()
        self.ev=self.root/'EVIDENCE';self.ev.mkdir();self.counter=0
        self.run_id=uuid.uuid4().hex
        files=[]
        for rel in G.EXPECTED:
            path=self.cand/rel;path.parent.mkdir(parents=True,exist_ok=True)
            b=('CODE:'+rel+'\n').encode();path.write_bytes(b)
            files.append({'path':rel,'sha256':sha(b),'bytes':len(b)})
        manifest={'schema':'TICKSTORE_FINAL_RUNTIME_CODE_MANIFEST_V001','files':files}
        self.manifest=self.root/'RUNTIME_CODE_MANIFEST.json';self.manifest.write_bytes(canonical(manifest))
        self.dossier={'schema':G.SCHEMA,'purpose':'ENGINEERING_PRE_B06_NO_OPERATIONAL_ADMISSION',
                      'code_manifest_sha256':sha(self.manifest.read_bytes()),
                      'production_modified':False,'b06':'NOT_STARTED','b07':'NOT_STARTED',
                      'full_started':False,'run_id':self.run_id,'consumers':[]}
        for rel in G.EXPECTED:
            srch=sha((self.cand/rel).read_bytes());runner=b'example-runner-from-fixture'
            before=b'fixed-protected-inventory';before_ref=self.put_blob(before)
            after_ref=self.put_blob(before)
            controls={'schema':'TICKSTORE_PRE_B06_CONTROLS_V001','source_path':rel,
                      'protected_inventory_before':before_ref,'protected_inventory_after':after_ref,
                      'before_protected_roots_sha256':sha(before),
                      'after_protected_roots_sha256':sha(before),
                      'reparse_rejected':True,'foreign_owner_rejected':True}
            witness={'schema':'TICKSTORE_PRE_B06_NATIVE_EXECUTION_WITNESS_V001',
                     'run_id':self.run_id,'source_path':rel,'source_sha256':srch,
                     'native_windows':True,'scope':'OWNED_ISOLATED_NTFS',
                     'production_modified':False,'pid':99,'creation_filetime':12345,
                     'invoked':True,'entrypoint_observed':True,
                     'language':'POWERSHELL_5_1' if rel.endswith('.ps1') else 'PYTHON',
                     'runner_sha256':sha(runner),
                     'exit_code':2,'protected_effects':False,'isolated_effects':[],
                     'failure_before_protected_effect':True}
            review={'schema':'TICKSTORE_PRE_B06_IMPLEMENTATION_REVIEW_V001',
                    'source_path':rel,'source_sha256':srch,'implementation_reviewed':True,
                    'required_branches_implemented':True,'remaining_implementation_blockers':[]}
            before_bytes=b'BEFORE-'+rel.encode();after_bytes=b'AFTER-'+rel.encode()
            internal={'schema':'TICKSTORE_PRE_B06_INTERNAL_BRANCH_V001',
                      'source_path':rel,'source_sha256':srch,'run_id':self.run_id,
                      'native_windows':True,'scope':'OWNED_ISOLATED_NTFS',
                      'runner_sha256':sha(runner),'source_entrypoint_reached':True,
                      'guarded_transition_exercised':True,'production_modified':False,
                      'protected_effects':False,'pid':99,'creation_filetime':12345,
                      'exit_code':0,'isolated_transitions':[{'before':self.put_blob(before_bytes),
                      'after':self.put_blob(after_bytes),
                      'before_sha256':sha(before_bytes),'after_sha256':sha(after_bytes)}]}
            row={'source_path':rel,'source_sha256':srch,'role':G.GUARD,
                 'execution_witness':self.put_json(witness),
                 'runner_source':self.put_blob(runner),
                 'negative_controls':self.put_json(controls),
                 'code_path_review':self.put_json(review),
                 'internal_branch_execution':self.put_json(internal)}
            self.dossier['consumers'].append(row)
    def put_blob(self,b):
        self.counter+=1;n='blob_%04d.bin'%self.counter
        (self.ev/n).write_bytes(b);return {'member':n,'sha256':sha(b),'bytes':len(b)}
    def put_json(self,o):return self.put_blob(canonical(o))
    def verify(self):return G.verify_dossier(self.dossier,self.cand,self.ev,native_required=False)
    def test_offline_contract_does_not_mint_gate(self):
        r=self.verify();self.assertEqual(r['consumers_verified'],11)
        self.assertEqual(r['status'],'CONTRACT_ONLY_NOT_NATIVE')
        self.assertEqual(r['five_part_completeness'],'NOT_EVALUATED')
    def test_native_required_blocks_offline(self):
        if sys.platform=='win32':self.skipTest('Windows native separately')
        with self.assertRaisesRegex(G.NotProven,'NATIVE_TARGET_NOT_EXECUTED_HERE'):
            G.verify_dossier(self.dossier,self.cand,self.ev,native_required=True)
    def test_reparse_evidence_root_is_denied(self):
        alias=self.root/'EVIDENCE_LINK'
        make_owned_reparse_fixture(alias,self.ev)
        with self.assertRaisesRegex(G.NotProven,'ROOT_REPARSE'):
            G.verify_dossier(self.dossier,self.cand,alias,native_required=False)
    def test_no_overlapping_same_evidence_digest_when_file_tampered(self):
        ref=self.dossier['consumers'][0]['execution_witness']
        (self.ev/ref['member']).write_bytes(b'evil')
        with self.assertRaisesRegex(G.NotProven,'DIGEST'):self.verify()
    def test_source_drift_blocks(self):
        (self.cand/G.EXPECTED[0]).write_bytes(b'wrong')
        with self.assertRaisesRegex(G.NotProven,'SOURCE_DRIFT'):self.verify()
    def test_wrong_runner_bytes_block(self):
        self.dossier['consumers'][1]['runner_source']=self.put_blob(b'wrong-runner')
        with self.assertRaisesRegex(G.NotProven,'RUNNER_BYTES'):self.verify()
    def test_false_safe_positive_blocks(self):
        self.dossier['consumers'][0]['role']=G.SAFE
        with self.assertRaisesRegex(G.NotProven,'ISOLATED_POSITIVE'):self.verify()
    def test_superseded_requires_reachability(self):
        self.dossier['consumers'][0]['role']=G.SUPERSEDED
        with self.assertRaisesRegex(G.NotProven,'SUPERSEDED_NOT_YET_QUALIFIED'):self.verify()
    def test_negative_control_must_hash_physical_inventories(self):
        row=self.dossier['consumers'][0]
        control=json.loads((self.ev/row['negative_controls']['member']).read_bytes())
        control['protected_inventory_after']=self.put_blob(b'changed')
        row['negative_controls']=self.put_json(control)
        with self.assertRaisesRegex(G.NotProven,'NEGATIVE_SCOPE'):self.verify()

if __name__=='__main__':unittest.main()
