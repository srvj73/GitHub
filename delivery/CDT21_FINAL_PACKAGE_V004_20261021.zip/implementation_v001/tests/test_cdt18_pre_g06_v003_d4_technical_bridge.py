"""Pure contract unit tests for the V003->D4 ABI bridge (NOT native G5 verdict)."""
import hashlib,importlib.util,pathlib,sys,unittest,json
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'candidate/control'))
sys.path.insert(0,str(ROOT/'tests'))
import D4_FIRST_ADMISSION_TRANSACTION as D
from test_cdt17_final_g5_complete_proof_gate import ClosedFixture,canon,sha
class Bridge(unittest.TestCase):
 def setUp(self):
  self.f=ClosedFixture();self.g=self.f.generate()
  ref=next(v for v in self.g['evidence'] if v['role']=='ENGINEERING_COMPLETENESS')
  self.comp=json.loads(self.f.objects[ref['path']]);self.opts={'final_code_manifest_sha256':self.f.code,
   'g5_instance_sha256':self.f.instance,'completeness_path':ref['path'],
   'completeness_sha256':ref['sha256'],'g5_final_validator_sha256':sha((ROOT/'candidate/control/FULL_G5_COMPLETE_PROOF_GATE.py').read_bytes())}
 def verify(self):return D.verify_final_g5_completeness(self.comp,self.opts,self.g,self.f.get)
 def test_01_closed_fixture_shape_is_accepted_not_issued(self):self.assertEqual(self.verify()['five_parts_verified'],5)
 def test_02_v002_legacy_bypass_rejected(self):
  self.comp['schema']='TICKSTORE_ENGINEERING_COMPLETENESS_V002'
  with self.assertRaisesRegex(D.Blocked,'FINAL_G5_V003_REQUIRED'):self.verify()
 def test_03_no_pin_reader_rejected(self):
  with self.assertRaisesRegex(D.Blocked,'G5_NATIVE_PINNED_READ_REQUIRED'):
   D.verify_final_g5_completeness(self.comp,self.opts,self.g,None)
 def test_04_wrong_instance_rejected(self):
  self.opts['g5_instance_sha256']='F'*64
  with self.assertRaisesRegex(D.Blocked,'G5_V003_FINAL_CODE_INSTANCE_BINDING'):self.verify()
 def test_05_missing_origin_decision_rejected(self):
  self.g['evidence']=[v for v in self.g['evidence'] if v['role']!='ORIGIN_DECISION']
  with self.assertRaisesRegex(Exception,'G5_FINAL_REQUIRED_EVIDENCE_MISSING'):self.verify()
 def test_06_completeness_wrong_path_rejected(self):
  self.opts['completeness_path']='other'
  with self.assertRaisesRegex(D.Blocked,'G5_COMPLETENESS_SAME_PHYSICAL_BYTES'):self.verify()
 def test_07_false_five_part_approved_rejected(self):
  from FULL_G5_COMPLETE_PROOF_GATE import FIVE
  self.comp['five_part_completeness'].pop(FIVE[2]);body=canon(self.comp)
  self.f.objects['ENGINEERING_COMPLETENESS']=body
  self.opts['completeness_sha256']=sha(body)
  self.g['evidence']=[dict(v,sha256=sha(body)) if v['role']=='ENGINEERING_COMPLETENESS' else v for v in self.g['evidence']]
  with self.assertRaisesRegex(Exception,'G5_FINAL_FIVE_PART_SET'):self.verify()
if __name__=='__main__':unittest.main(verbosity=2)
