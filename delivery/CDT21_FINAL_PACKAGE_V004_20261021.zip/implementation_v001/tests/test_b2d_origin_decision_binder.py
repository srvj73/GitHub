"""Current G5 C6 binder regression; supersedes obsolete R45 COMPLETE fixture.

Original historical R45 suite is retained byte-exact under tests/legacy/ and is NOT a
2026-10-16 execution gate. Replays a physically sealed R2 owner-scoped package as
an *isolated test reference*, without issuing a new owner decision or claiming a
new FULL identity. All mutations below are temporary negative UNIT FIXTURES only.
"""
from __future__ import annotations
import copy
import datetime as dt
import hashlib
import importlib.util
import json
import os
import shutil
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REFERENCE=ROOT/'tests/fixtures/CDT17_G5_OWNER_R2_SCOPED_IMMUTABLE_REFERENCE.zip'
REFERENCE_SHA='3C5A99EF3F3714FDEF4DC1B8FD264736DE3E63122B0016F68827FAC6E8DA6D49'
NOW=dt.datetime(2026,10,16,13,0,tzinfo=dt.timezone(dt.timedelta(hours=-3)))
H=lambda raw:hashlib.sha256(raw).hexdigest().upper()
J=lambda obj:(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode()

class CurrentOwnerScope(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  assert H(REFERENCE.read_bytes())==REFERENCE_SHA, 'FROZEN_G5_REFERENCE_IDENTITY_DRIFT'
  with zipfile.ZipFile(REFERENCE) as z:
   names=z.namelist()
   assert len(names)==len(set(x.casefold() for x in names))
   assert set(names)>={'EVIDENCE/G5_OWNER_STAGE_DECISION.json','CONTROL/ORIGIN_DECISION_BINDER.py',
     'INPUTS/FULL.zip','SOURCE_CODE_MANIFEST.json','EVIDENCE/ORIGIN_POLICY_RECONCILIATION.json'}
   for r in z.infolist():assert z.read(r.filename) is not None
   cls.control_raw=z.read('CONTROL/ORIGIN_DECISION_BINDER.py')
   # Historical scoped replay runs ONLY the archived, hash-bound module bytes.
   # The current FINAL binder has changed legitimately and is independently
   # checked in test_cdt17_final_binder_bridge; old PASS never transfers.
   assert cls.control_raw!=b''
   assert H(cls.control_raw)==H(z.read('CONTROL/ORIGIN_DECISION_BINDER.py'))
 def setUp(self):
  # NTFS native protected reader refuses alias paths (e.g. legacy 8.3 / TMP
  # expansions). The untrusted OS TEMP environment is NOT a path authority.
  # Use a fresh test workspace outside EXTRACTED, owned by this qualification run.
  parent=ROOT.parent.parent
  if os.name == 'nt':
   if ROOT.parent.name != 'EXTRACTED' or not parent.name.startswith('CURRENT_G5_DELTA_'):
    raise RuntimeError('G5_FIXTURE_RUNROOT_CONTRACT_NOT_MET')
   if os.path.normcase(os.path.realpath(str(parent))) != os.path.normcase(str(parent)):
    raise RuntimeError('G5_FIXTURE_RUNROOT_ALIAS_NOT_CANONICAL')
  temp=tempfile.TemporaryDirectory(prefix='cdt17_g5_current_',dir=str(parent));self.addCleanup(temp.cleanup)
  self.home=Path(temp.name)
  if os.name == 'nt' and os.path.normcase(os.path.realpath(str(self.home))) != os.path.normcase(str(self.home)):
   raise RuntimeError('G5_FIXTURE_WORKSPACE_ALIAS_NOT_CANONICAL')
  with zipfile.ZipFile(REFERENCE) as z:z.extractall(self.home)
  # The production stage closes from STAGE_EVIDENCE/INPUTS, not the ZIP transport INPUTS.
  shutil.copytree(self.home/'INPUTS',self.home/'EVIDENCE/INPUTS')
  for module in ('G5_C6_FORMAL_CONTRACT','G5_C6_B1_FORMAL_CONSUMER'):
   sys.modules.pop(module,None)
  sys.path.insert(0,str(self.home/'CONTROL'))
  try:
   spec=importlib.util.spec_from_file_location('cdt17_unit_scoped_binder',self.home/'CONTROL/ORIGIN_DECISION_BINDER.py')
   self.D=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.D)
  finally:pass
  self.addCleanup(lambda:sys.path.remove(str(self.home/'CONTROL')))
  self.original=json.loads((self.home/'EVIDENCE/G5_OWNER_STAGE_DECISION.json').read_bytes())
  self.evid={
   'G5_EVIDENCE_PACK':self.home/'EVIDENCE/G5_EVIDENCE_PACK.json',
   'ENGINEERING_COMPLETENESS':self.home/'EVIDENCE/ENGINEERING_COMPLETENESS.json',
   'G5_STAGE_COMPLETENESS':self.home/'EVIDENCE/G5_STAGE_COMPLETENESS.json',
   'G5_INTEGRATION_SOURCE':self.home/'CONTROL/G5_C6_FORMAL_CONTRACT.py',
   'G5_INTEGRATION_MANIFEST':self.home/'SOURCE_CODE_MANIFEST.json',
   'NATIVE_RETURN_ZIP':self.home/'INPUTS/G4_RETURN.zip'}
  self.out=self.home/'UNIT_SCOPED_RECEIPT.json';self.dec=self.home/'UNIT_SCOPED_DECISION.json'
  self.write_dec(copy.deepcopy(self.original))
 def write_dec(self,obj):self.dec.write_bytes(J(obj));self.decision=obj
 def bind(self,now=NOW,**kw):
  opts=dict(decision_path=self.dec,decision_sha256=H(self.dec.read_bytes()),stage='G5',
   code_sha=self.original['code_manifest_sha256'],final_package_sha=self.original['final_package_sha256'],
   instance_sha=self.original['instance_sha256'],policy_root=self.home/'POLICY_CAPTURE_NONAUTHORITATIVE',
   policy_reconciliation=self.home/'EVIDENCE/ORIGIN_POLICY_RECONCILIATION.json',
   policy_reconciliation_sha256=H((self.home/'EVIDENCE/ORIGIN_POLICY_RECONCILIATION.json').read_bytes()),
   predecessor_hashes={},evidence_paths=self.evid,out_path=self.out,now=now)
  opts.update(kw)
  return self.D.materialize(**opts)
 def blocked(self,code,**kw):
  with self.assertRaisesRegex(self.D.DecisionBlocked,code):self.bind(**kw)
  self.assertFalse(self.out.exists())
 def mutate_dec(self,**edits):
  o=copy.deepcopy(self.decision);o.update(edits);self.write_dec(o)
 def mutate_evidence(self,role,obj):
  p=self.evid[role];p.write_bytes(J(obj));o=copy.deepcopy(self.decision)
  for row in o['evidence']:
   if row['role']==role:row['sha256']=H(p.read_bytes())
  self.write_dec(o)
 def test_01_sealed_reference_and_exact_roles(self):
  self.assertEqual(tuple(self.evid),self.D.REQUIRED_EVIDENCE['G5'])
  self.assertEqual(self.original['code_manifest_sha256'],'0255AF34ACECFF2B4167CF89B9C493C9237E0EE8F2C928DE9CE334E514F252BF')
 def test_02_success_replays_scope_without_new_authority(self):
  r=self.bind();o=json.loads(self.out.read_bytes())
  self.assertEqual(o['status'],'PASS');self.assertEqual(o['final_package_sha256'],self.original['final_package_sha256'])
  self.assertEqual(o['decision_owner'],'OWNER_RELEASE_AUTHORITY')
  self.assertEqual(o['environment'],r['environment'])
  self.assertIn(o['environment'],('FIXTURE_NOT_NATIVE','WINDOWS_PRODUCTION'))
 def test_03_decision_wrong_external_digest(self):self.blocked('DECISION_SHA256_SUPPLIED_SEPARATELY',decision_sha256='0'*64)
 def test_04_reject_decision(self):self.mutate_dec(decision='REJECT');self.blocked('ORIGIN_DECISION_REJECT')
 def test_05_wrong_issuer(self):self.mutate_dec(issuer='ENGINEER');self.blocked('DECISION_SCHEMA_ISSUER')
 def test_06_implementer_not_issuer(self):self.mutate_dec(implementation_participant_is_issuer=True);self.blocked('DECISION_IMPLEMENTER_CANNOT_ISSUE')
 def test_07_owner_basis_required(self):self.mutate_dec(issuer_basis='FICTION');self.blocked('G5_OWNER_SCOPE')
 def test_08_owner_no_fake_independent_auditor(self):self.mutate_dec(owner_is_independent_b06_auditor=True);self.blocked('G5_OWNER_SCOPE')
 def test_09_no_administrative_owner_gate(self):self.mutate_dec(administrative_owner_gate=True);self.blocked('DECISION_NO_ADMINISTRATIVE_OWNER_GATE')
 def test_10_wrong_code_manifest(self):self.mutate_dec(code_manifest_sha256='D'*64);self.blocked('DECISION_BINDING:code_manifest')
 def test_11_wrong_final_zip(self):self.mutate_dec(final_package_sha256='D'*64);self.blocked('DECISION_BINDING:final_package')
 def test_12_wrong_instance(self):self.mutate_dec(instance_sha256='D'*64);self.blocked('DECISION_BINDING:instance')
 def test_13_no_predecessor_override(self):self.blocked('DECISION_PREDECESSOR_SET',predecessor_hashes={'G5':'E'*64})
 def test_14_different_reconciliation_hash(self):
  q=copy.deepcopy(self.decision);q['policy']['reconciliation_sha256']='D'*64;self.write_dec(q)
  self.blocked('DECISION_POLICY_BINDING:reconciliation')
 def test_15_blockers_refuse(self):self.mutate_dec(blockers=['CRITICAL']);self.blocked('DECISION_BLOCKERS')
 def test_16_failed_complete_check_refuses(self):
  q=copy.deepcopy(self.decision);q['checks']['byte_freeze']=False;self.write_dec(q);self.blocked('DECISION_CHECKS')
 def test_17_missing_evidence_role_refuses(self):
  q=copy.deepcopy(self.decision);q['evidence']=[e for e in q['evidence'] if e['role']!='G5_STAGE_COMPLETENESS'];self.write_dec(q)
  self.blocked('DECISION_EVIDENCE_ROLES')
 def test_18_duplicate_evidence_refuses(self):
  q=copy.deepcopy(self.decision);q['evidence'].append(dict(q['evidence'][0]));self.write_dec(q)
  self.blocked('DECISION_EVIDENCE_ROLES')
 def test_19_bad_evidence_bytes_refuses(self):
  self.evid['G5_EVIDENCE_PACK'].write_bytes(b'{}')
  self.blocked('DECISION_EVIDENCE_SHA256:G5_EVIDENCE_PACK')
 def test_20_tamper_semantics_even_with_rebound_hash_refuses(self):
  x=json.loads(self.evid['G5_EVIDENCE_PACK'].read_bytes());x['consumer_self_check']='FALSE_PASS';self.mutate_evidence('G5_EVIDENCE_PACK',x)
  self.blocked('DECISION_EVIDENCE_G5_PACK')
 def test_21_stage_false_full_promotion_refuses(self):
  x=json.loads(self.evid['G5_STAGE_COMPLETENESS'].read_bytes());x['full_candidate_completeness']='PASS';self.mutate_evidence('G5_STAGE_COMPLETENESS',x)
  self.blocked('DECISION_G5_STAGE_SCOPED_INTEGRITY')
 def test_22_integration_module_modified_refuses(self):
  p=self.evid['G5_INTEGRATION_SOURCE'];p.write_bytes(p.read_bytes()+b'\n# changed\n')
  o=copy.deepcopy(self.decision)
  for row in o['evidence']:
   if row['role']=='G5_INTEGRATION_SOURCE':row['sha256']=H(p.read_bytes())
  self.write_dec(o);self.blocked('DECISION_INTEGRATION_MODULE_SHA')
 def test_23_integration_manifest_file_digest_refuses(self):
  x=json.loads(self.evid['G5_INTEGRATION_MANIFEST'].read_bytes());x['files'][0]['sha256']='D'*64
  self.mutate_evidence('G5_INTEGRATION_MANIFEST',x);self.blocked('DECISION_INTEGRATION_MODULE_SHA')
 def test_24_g4_return_modified_refuses(self):
  p=self.evid['NATIVE_RETURN_ZIP'];p.write_bytes(p.read_bytes()+b'bad')
  o=copy.deepcopy(self.decision)
  for row in o['evidence']:
   if row['role']=='NATIVE_RETURN_ZIP':row['sha256']=H(p.read_bytes())
  self.write_dec(o);self.blocked('DECISION_G5_SOURCE_BINDING')
 def test_25_policy_reconciliation_corrupted_refuses(self):
  p=self.home/'EVIDENCE/ORIGIN_POLICY_RECONCILIATION.json';x=json.loads(p.read_bytes());x['policy_master_sha256']='D'*64;p.write_bytes(J(x))
  self.blocked('DECISION_POLICY_NOT_VERIFIED')
 def test_26_expired_policy_reconciliation_refuses(self):
  self.blocked('DECISION_POLICY_NOT_VERIFIED',now=dt.datetime(2026,11,1,tzinfo=dt.timezone.utc))
 def test_27_no_clobber_same_receipt(self):
  self.bind();with_n=self.out.read_bytes()
  with self.assertRaisesRegex(self.D.DecisionBlocked,'STAGE_RECEIPT_EXISTS'):self.bind()
  self.assertEqual(self.out.read_bytes(),with_n)
 def test_28_original_untouched_vs_new_full_digest(self):
  # Historic owner G5 is not a final code-bound G5; changes require a new decision.
  from hashlib import sha256
  composite=H((ROOT/'RUNTIME_CODE_MANIFEST.json').read_bytes())
  self.assertNotEqual(composite,self.original['code_manifest_sha256'])
  self.blocked('DECISION_BINDING:code_manifest',code_sha=composite)
 def test_29_no_full_claim_in_scoped_evidence(self):
  x=json.loads(self.evid['ENGINEERING_COMPLETENESS'].read_bytes())
  self.assertEqual(x['status'],'INCOMPLETE');self.assertFalse(x['full_started'])
  self.assertEqual(x['known_blockers'],['FULL_CANDIDATE_COMPLETENESS_NOT_YET_PROVEN'])

if __name__=='__main__':unittest.main(verbosity=2)
