"""Real V002 native-branch guards, with constructed return fixtures only."""
import importlib,io,json,pathlib,sys,unittest,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'candidate/control'))
G=importlib.import_module('FULL_G5_COMPLETE_PROOF_GATE')

def archive(files):
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED) as z:
        for k,v in files.items():z.writestr(k, v)
    return b.getvalue()

def enc(d):return (json.dumps(d,sort_keys=True)+'\n').encode('utf8')

class NativeBranches(unittest.TestCase):
    def test_v002_not_promoted_by_summary_only(self):
        return_zip=archive({'ENGINEERING_RESULT.json':enc({
            'schema':'CDT19_PRE_B06_NATIVE_ENGINEERING_V002',
            'status':'PASS_NATIVE_INTEGRATED_PRE_B06',
            'code_manifest_sha256':'A'*64,'final_zip_sha256':'B'*64,
            'pre_b06_11_receipt':{'member':'MISSING.json','sha256':'C'*64}}),
            'LIVE_STATUS.json':enc({'status':'PASS_NATIVE_INTEGRATED_PRE_B06','committed_units':1})})
        with self.assertRaisesRegex(G.G5Incomplete,'PRE_B06_11_RECEIPT'):
            G.verify_native_campaign(return_zip,'A'*64,'B'*64,{},final_members={})
    def test_v002_cannot_invent_native_positive_code_sha(self):
        return_zip=archive({'ENGINEERING_RESULT.json':enc({
            'schema':'CDT19_PRE_B06_NATIVE_ENGINEERING_V002',
            'status':'PASS_NATIVE_INTEGRATED_PRE_B06',
            'code_manifest_sha256':'F'*64,'final_zip_sha256':'B'*64}),
            'LIVE_STATUS.json':enc({})})
        with self.assertRaisesRegex(G.G5Incomplete,'NATIVE_G5_SOURCE_BINDING'):
            G.verify_native_campaign(return_zip,'A'*64,'B'*64,{},final_members={})
    def test_v001_legacy_proof_does_not_accept_new_label(self):
        return_zip=archive({'ENGINEERING_RESULT.json':enc({
            'schema':'CDT18_ONE_SINGLE_FULL_ENGINEERING_QUAL_V001',
            'status':'PASS_NATIVE_INTEGRATED_PRE_B06'}),
            'LIVE_STATUS.json':enc({})})
        with self.assertRaisesRegex(G.G5Incomplete,'NATIVE_G5_RUN_NOT_PASS'):
            G.verify_native_campaign(return_zip,'A'*64,'B'*64,{})
    def test_existing_operational_validator_stays_distinct(self):
        self.assertTrue(callable(G.verify_legacy11))
        self.assertTrue(callable(G.verify_pre_b06_v002))
        self.assertEqual(G.LEGACY11.__len__(),11)

if __name__=='__main__':unittest.main()
