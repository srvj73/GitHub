"""Technical instance producer/consumer; no policy files or authority creation."""
import os, pathlib, sys, tempfile, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'candidate/control'))
import FULL_INSTANCE_PREPARE as producer
import D4_FIRST_ADMISSION_BOOTSTRAP as consumer

class Binding(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='CDT19_INSTANCE_');self.addCleanup(self.tmp.cleanup)
        p=pathlib.Path(self.tmp.name)
        self.inputs={'schema':'TICKSTORE_INSTANCE_INPUTS_V001','config_sha256':'C'*64,
                     'resources':{'max_workers':1,'ram_target_percent':50}}
        for k in ('source_root','dest_root','scratch_root','ledger_path','d4_resume_root','policy_root','origin_witness'):
            self.inputs[k]=str(p/k)
        params={k:'A'*64 if k.endswith('Sha') else str(p/k) for k in producer.D4_PARAMETERS}
        params.update(PolicyRoot=self.inputs['policy_root'],OriginCapturePath=self.inputs['origin_witness'])
        self.inputs['d4_parameters']=params
        self.bindings={k+'_root':os.path.normcase(self.inputs[k+'_root']) for k in ('source','dest','scratch')}
        self.config={'control_root':str(p/'control')}
    def compile(self):return producer.compile_instance(self.inputs,self.bindings,self.config,'A'*64,'B'*64,run_id='C'*32)
    def test_roundtrip(self):
        v=self.compile();consumer.validate_instance_binding(v,'A'*64)
        self.assertFalse(v['authority_created']);self.assertFalse(v['production_started'])
    def test_producer_negative(self):
        self.inputs['d4_parameters']['FinalCodeManifestSha']='D'*64
        with self.assertRaisesRegex(RuntimeError,'INSTANCE_MANIFEST_BINDING'):self.compile()
    def test_consumer_negative(self):
        with self.assertRaisesRegex(RuntimeError,'G5_FINAL_INSTANCE_BINDING'):consumer.validate_instance_binding(self.compile(),'F'*64)

if __name__=='__main__':unittest.main(verbosity=2)
