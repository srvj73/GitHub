"""C3: lock the exact Windows directory-handle access mask in the admission boundary.

The native Win32 rename-denial result remains a TARGET_RUNTIME gate, not a mock PASS.
"""
import ctypes
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'qual'))
import SANDBOX_ADMISSION as A

class Kernel:
    def __init__(self):
        self.calls=[]
        self.GetFileInformationByHandleEx=Mock(return_value=1)
    def CreateFileW(self,*args):
        self.calls.append(('open',args))
        return 9876
    def CloseHandle(self,h):
        self.calls.append(('close',h))

class WinDirectoryPinContract(unittest.TestCase):
    def test_new_pin_does_not_reuse_insufficient_mask(self):
        k=Kernel()
        simulated_os=SimpleNamespace(name='nt',path=os.path)
        ident=dict(reparse=False,final_path=os.path.abspath('/sandbox'), filesystem='NTFS',
                   volume_serial='01010101',file_index='ABAB')
        fake_win=(SimpleNamespace(c_void_p=ctypes.c_void_p,c_int=ctypes.c_int,get_last_error=lambda:0),SimpleNamespace(HANDLE=ctypes.c_void_p,DWORD=ctypes.c_uint32,LPVOID=ctypes.c_void_p,BOOL=ctypes.c_int),k,object)
        with patch.object(A,'os',simulated_os),patch.object(A,'_win',return_value=fake_win),patch.object(A.HeldDirectory,'read_identity',return_value=ident):
            p=A.HeldDirectory('/sandbox')
        try:
            self.assertEqual(k.calls[0][0],'open')
            args=k.calls[0][1]
            self.assertEqual(args[1],0x00100081) # FILE_LIST_DIRECTORY | READ_ATTRIBUTES | SYNCHRONIZE
            self.assertEqual(args[2],0x3) # SHARE_READ|SHARE_WRITE, never SHARE_DELETE
            self.assertEqual(args[4],3) # OPEN_EXISTING
            self.assertEqual(args[5],0x02200000) # BACKUP_SEMANTICS|OPEN_REPARSE_POINT
            self.assertEqual(k.calls[-1],('open',args))
        finally:
            p.close()
        self.assertEqual(k.calls[-1],('close',9876))

    def test_runtime_engine_proven_mask_matches_guard(self):
        # Different code units. Assert numerical mask and share parity, not a mock of OS proof.
        runtime=Path(__file__).resolve().parents[1] / 'candidate' / 'full' / 'tickstore_serial_runner.py'
        data=runtime.read_bytes()
        self.assertIn(b'desired=FILE_LIST_DIRECTORY|FILE_READ_ATTRIBUTES|SYNCHRONIZE',data)
        self.assertIn(b'h=CreateFileW(str(path),desired,FILE_SHARE_READ|FILE_SHARE_WRITE',data)
        self.assertNotIn(b'h=CreateFileW(str(path),desired,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE',data)

if __name__=='__main__': unittest.main()
