import hashlib,importlib.util,io,json,sys,unittest,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CONTROL=ROOT/'candidate'/'control'
sys.path.insert(0,str(CONTROL))
import FULL_QUALIFICATION_CONTRACT as original
import B1_DISTRIBUTED_CONTRACT_CONSUMER as consumer
INPUT=Path(__file__).resolve().parents[2]/'B1_APPROVED_INPUTS'
NAMES=['B1_126_PROVENANCE_MAP.json','CDT16_C5R44_B1_126_EVIDENCE_CONSOLIDATED_20261015.zip','TICKSTORE_CDT16_C5R44_B1_DELTA_SOURCE_ONLY.zip','TICKSTORE_CDT16_FULL_C5R44_G5_CONTRACT_REBASED_SOURCE_ONLY_20261015.zip']
class ApprovedAdmission(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.raw=[(INPUT/n).read_bytes() for n in NAMES]
 def test_01_approved_positive(self):
  v=original.evaluate_b1_distributed_admission(*self.raw)
  self.assertEqual(v['verified_test_ids'],126)
  self.assertEqual(v['remediations'],7)
  self.assertEqual(v['b1_formal_gate'],'NOT_ISSUED')
  self.assertEqual(v['g5_formal_gate'],'NOT_ISSUED')
  self.assertFalse(v['new_consumer_native_qualified'])
 def test_02_reject_map_tamper(self):
  r=list(self.raw);r[0]=r[0]+b'0'
  with self.assertRaisesRegex(ValueError,'B1_SOURCE_IDENTITY'):original.evaluate_b1_distributed_admission(*r)
 def test_03_reject_evidence_tamper(self):
  r=list(self.raw);r[1]=r[1]+b'0'
  with self.assertRaisesRegex(ValueError,'B1_SOURCE_IDENTITY'):original.evaluate_b1_distributed_admission(*r)
 def test_04_reject_b1_overlay_tamper(self):
  r=list(self.raw);r[2]=r[2]+b'0'
  with self.assertRaisesRegex(ValueError,'B1_SOURCE_IDENTITY'):original.evaluate_b1_distributed_admission(*r)
 def test_05_reject_old_full_tamper(self):
  r=list(self.raw);r[3]=r[3]+b'0'
  with self.assertRaisesRegex(ValueError,'B1_SOURCE_IDENTITY'):original.evaluate_b1_distributed_admission(*r)
 def test_06_reject_synthetic_pass(self):
  r=list(self.raw);d=json.loads(r[0]);d['b1_formal_gate']='PASS';r[0]=json.dumps(d).encode()
  with self.assertRaises(ValueError):original.evaluate_b1_distributed_admission(*r)
 def test_07_reject_retargeted_id(self):
  r=list(self.raw);d=json.loads(r[0]);d['test_results'][0]['proof_source']='native6';r[0]=json.dumps(d).encode()
  with self.assertRaises(ValueError):original.evaluate_b1_distributed_admission(*r)
 def test_08_reject_empty_evidence(self):
  r=list(self.raw);r[1]=b''
  with self.assertRaises(ValueError):original.evaluate_b1_distributed_admission(*r)
 def test_09_old_validation_contract_unmodified(self):
  self.assertIn('NATIVE_PROVENANCE_MISSING',original.physical_findings({'native_provenance':{'schema':'fake'}},{'required_tests':[], 'required_target_proofs':[]},'A'*64))
 def test_10_six_g5_proofs_remain(self):
  self.assertEqual(len(original.TYPED_PROOFS),6)
  self.assertIn('POWERLOSS_EMULATED',original.TYPED_PROOFS)
 def test_11_distributed_not_g5_native(self):
  self.assertIn('NATIVE_PROVENANCE_MISSING',original.physical_findings({'b1_distributed_provenance':{}},{'required_tests':[], 'required_target_proofs':[]},'A'*64))
 def test_12_no_fake_single_return(self):
  self.assertNotIn('B1_RESULT.json',consumer.evaluate(*self.raw))
 def test_13_wrong_contract_detected(self):
  self.assertEqual(consumer.CONTRACT_SHA256, hashlib.sha256((CONTROL/consumer.CONTRACT_FILENAME).read_bytes()).hexdigest().upper())
 def test_14_source_original_g5_logic_preserved(self):
  import zipfile
  full=zipfile.ZipFile(io.BytesIO(self.raw[3]))
  prev=full.read('implementation_v001/candidate/control/FULL_QUALIFICATION_CONTRACT.py')
  cur=(CONTROL/'FULL_QUALIFICATION_CONTRACT.py').read_bytes()
  self.assertTrue(cur.startswith(prev))
  self.assertEqual(cur[len(prev):].count(b'def evaluate_b1_distributed_admission'),1)
if __name__=='__main__': unittest.main(verbosity=2)
