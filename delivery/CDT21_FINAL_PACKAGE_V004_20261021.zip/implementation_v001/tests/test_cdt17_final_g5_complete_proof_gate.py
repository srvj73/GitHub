"""G5 final proof gate unit qualification: synthetic GOOD is contract-shape only.
Never a claim of native FULL code completion or issuance of an owner stage decision.
"""
import hashlib
import io
import json
import pathlib
import sys
import unittest
from unittest.mock import patch
import zipfile

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'candidate/control'))
from FULL_G5_COMPLETE_PROOF_GATE import validate_g5_complete_proof,G5Incomplete,FIVE,ROLES

def canon(o):return (json.dumps(o,sort_keys=True,separators=(',',':'))+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest().upper()

class ClosedFixture:
    def __init__(self):
        self.objects={};self.code='A'*64;self.instance='B'*64
    def put(self,n,b):
        self.objects[n]=b;return {'role':n,'path':n,'sha256':sha(b)}
    def get(self,p,h):
        assert sha(self.objects[p])==h
        return self.objects[p]
    def generate(self):
        # Rich fixture verifies the full evidence dialect in memory only.
        # No generated object is an actual native result or origin approval.
        members={}
        for p in sorted((ROOT/'candidate').rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:
                members['implementation_v001/candidate/'+p.relative_to(ROOT/'candidate').as_posix()]=p.read_bytes()
        index={n.removeprefix('implementation_v001/candidate/'): {'path':n.removeprefix('implementation_v001/candidate/'),'sha256':sha(raw),'bytes':len(raw)} for n,raw in members.items()}
        manifest_code=canon({'schema':'TICKSTORE_FINAL_RUNTIME_CODE_MANIFEST_V001','files':list(index.values())})
        members['implementation_v001/RUNTIME_CODE_MANIFEST.json']=manifest_code
        self.code=sha(manifest_code)
        manifest={'schema':'TICKSTORE_FINAL_PACKAGE_MANIFEST_V001',
                  'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in members.items()]}
        archive=io.BytesIO()
        with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
            for n,b in members.items():z.writestr(n,b)
            z.writestr('PACKAGE_MANIFEST.json',canon(manifest))
        zbody=archive.getvalue();fin_sha=sha(zbody)
        sys.path.insert(0,str(ROOT/'tests'))
        from test_integrated_evidence_contract import ContractFixture
        native=ContractFixture(index,self.code,fin_sha)
        native_raw=native.archive()
        chain_ref=native.result['legacy_11_effectful_receipt']
        self.put('LEGACY_11_CHAIN',native.members[chain_ref['member']])
        adverse={'schema':'TICKSTORE_FINAL_ADVERSARIAL_ENGINEERING_ATTESTATION_V001','status':'PASS',
                 'known_blockers':[],'candidate_sha256':fin_sha,'code_manifest_sha256':self.code,
                 'native_g5_return_sha256':sha(native_raw),'legacy_technical_consumer_count':11,
                 'false_completeness_search':'PASS','state_toctou_receipt_checkpoint_negative_controls':'PASS',
                 'final_bytes_freeze':'PASS'}
        self.put('ADVERSARIAL_CLOSURE',canon(adverse))
        evidence=[];parts={}
        for part in FIVE:
            blob=self.put('PROOF_BODY_'+part,b'physical readback test data '+part.encode())
            ev={'role':'SOURCE_EVIDENCE','path':blob['path'],'sha256':blob['sha256']}
            proof={'schema':'TICKSTORE_FINAL_COMPLETENESS_PROOF_V001','part':part,'status':'PASS',
                'code_manifest_sha256':self.code,'instance_sha256':self.instance,'evidence':[ev,
                    {'role':'FINAL_PACKAGE_ZIP','path':'FINAL_PACKAGE_ZIP','sha256':fin_sha},
                    {'role':'ADVERSARIAL_CLOSURE','path':'ADVERSARIAL_CLOSURE','sha256':sha(self.objects['ADVERSARIAL_CLOSURE'])},
                    {'role':'LEGACY_11_CHAIN','path':'LEGACY_11_CHAIN','sha256':chain_ref['sha256']}]}
            pref=self.put('PROOF_'+part,canon(proof))
            parts[part]={'status':'PASS','code_manifest_sha256':self.code,'instance_sha256':self.instance,
                         'path':pref['path'],'sha256':pref['sha256']}
        comp={'schema':'TICKSTORE_ENGINEERING_COMPLETENESS_V003','status':'COMPLETE',
              'code_manifest_sha256':self.code,'instance_sha256':self.instance,
              'known_blockers':[],'full_started':False,'formal_audit_started':False,
              'five_part_completeness':parts,'native_g5_return_sha256':sha(native_raw)}
        fields={'ENGINEERING_COMPLETENESS':comp,
             'G5_STAGE_COMPLETENESS':{'full_candidate_completeness':'PASS','original_full_sha256':fin_sha},
             'G5_EVIDENCE_PACK':{'code_manifest_sha256':self.code},
             'ORIGIN_DECISION':{'stage':'G5','decision':'PASS','code_manifest_sha256':self.code,
                                'instance_sha256':self.instance,'final_package_sha256':fin_sha,
                                'evidence':[{'role':'NATIVE_RETURN_ZIP','sha256':sha(native_raw)}]}}
        integration_paths=('control/FULL_RELEASE_CHAIN.py','control/FULL_G5_COMPLETE_PROOF_GATE.py',
          'control/ORIGIN_DECISION_BINDER.py','control/G5_C6_FORMAL_CONTRACT.py',
          'control/G5_C6_FORMAL_STAGE_BUILDER.py','control/FULL_QUALIFICATION_CONTRACT.py',
          'control/G5_FINAL_COMPLETENESS_PRODUCER.py')
        fields['G5_INTEGRATION_MANIFEST']={'schema':'CDT17_G5_FINAL_INTEGRATED_CODE_MANIFEST_V001',
          'binding_mode':'FINAL_CANDIDATE','code_manifest_sha256':self.code,'final_package_sha256':fin_sha,
          'files':[index[n] for n in integration_paths]}
        for n in ROLES:
            b=zbody if n=='FINAL_PACKAGE_ZIP' else native_raw if n=='NATIVE_RETURN_ZIP' else members['implementation_v001/candidate/control/G5_C6_FORMAL_CONTRACT.py'] if n=='G5_INTEGRATION_SOURCE' else canon(fields[n])
            evidence.append(self.put(n,b))
        d={'stage':'G5','status':'PASS','environment':'WINDOWS_PRODUCTION',
           'code_manifest_sha256':self.code,'instance_sha256':self.instance,
           'full_candidate_completeness':'PASS','final_package_sha256':fin_sha,
           'origin_decision_sha256':next(x['sha256'] for x in evidence if x['role']=='ORIGIN_DECISION'),
           'evidence':evidence}
        return d

class CompleteG5GateTests(unittest.TestCase):
    def setUp(self):
        self.f=ClosedFixture();self.r=self.f.generate()
        # No broad mock: synthetic trace now exercises the actual verifier.
        # A synthetic fixture is not evidence that Windows ran the program.
    def verify(self):return validate_g5_complete_proof(self.r,self.f.code,self.f.instance,self.f.get)
    def assert_blocks(self,code):
        with self.assertRaisesRegex(G5Incomplete,code):self.verify()
    def test_01_synthetic_contract_positive_only(self):self.assertEqual(self.verify()['five_parts_verified'],5)
    def test_02_old_scoped_receipt_rejected(self):
        self.r.pop('full_candidate_completeness');self.assert_blocks('SCOPED_RECEIPT_NOT_FULL')
    def test_03_fake_scoped_to_full_flag_rejected(self):
        self.r['evidence']=[x for x in self.r['evidence'] if x['role']!='ENGINEERING_COMPLETENESS']
        self.assert_blocks('REQUIRED_EVIDENCE_MISSING')
    def test_04_origin_decision_different_code_rejected(self):
        obj=json.loads(self.f.objects['ORIGIN_DECISION']);obj['code_manifest_sha256']='C'*64
        ref=self.f.put('ORIGIN_DECISION',canon(obj))
        self.r['evidence']=[ref if v['role']=='ORIGIN_DECISION' else v for v in self.r['evidence']]
        self.r['origin_decision_sha256']=ref['sha256']
        self.assert_blocks('ORIGIN_DECISION_OLD_OR_WRONG_CODE')
    def test_05_one_of_five_proofs_missing_rejected(self):
        obj=json.loads(self.f.objects['ENGINEERING_COMPLETENESS'])
        obj['five_part_completeness'].pop(FIVE[0])
        ref=self.f.put('ENGINEERING_COMPLETENESS',canon(obj))
        self.r['evidence']=[ref if v['role']=='ENGINEERING_COMPLETENESS' else v for v in self.r['evidence']]
        self.assert_blocks('FIVE_PART_SET')
    def test_06_false_pass_bool_rejected(self):
        obj=json.loads(self.f.objects['ENGINEERING_COMPLETENESS'])
        obj['five_part_completeness'][FIVE[2]]={'status':'PASS'}
        ref=self.f.put('ENGINEERING_COMPLETENESS',canon(obj));self.r['evidence']=[ref if v['role']=='ENGINEERING_COMPLETENESS' else v for v in self.r['evidence']]
        self.assert_blocks('FIVE_PART_CODE_DRIFT')
    def test_07_invalid_final_zip_member_rejected(self):
        self.f.objects['FINAL_PACKAGE_ZIP']=b'not a zip'
        self.r['evidence']=[dict(x,sha256=sha(self.f.objects['FINAL_PACKAGE_ZIP'])) if x['role']=='FINAL_PACKAGE_ZIP' else x for x in self.r['evidence']]
        self.r['final_package_sha256']=sha(self.f.objects['FINAL_PACKAGE_ZIP'])
        # Rebind the envelope so this test reaches ZIP parsing rather than the
        # earlier physical-reader hash rejection, which has a separate probe.
        comp=json.loads(self.f.objects['ENGINEERING_COMPLETENESS'])
        for part in FIVE:
            proof=json.loads(self.f.objects['PROOF_'+part])
            for item in proof['evidence']:
                if item['role']=='FINAL_PACKAGE_ZIP':item['sha256']=self.r['final_package_sha256']
            ref=self.f.put('PROOF_'+part,canon(proof))
            comp['five_part_completeness'][part]['sha256']=ref['sha256']
        ref=self.f.put('ENGINEERING_COMPLETENESS',canon(comp))
        self.r['evidence']=[ref if x['role']=='ENGINEERING_COMPLETENESS' else x for x in self.r['evidence']]
        self.assert_blocks('FINAL_PACKAGE_FORMAT')
    def test_08_different_code_manifest_rejected(self):
        self.r['code_manifest_sha256']='C'*64
        self.assert_blocks('RUNTIME_INSTANCE_BINDING')
    def test_09_corrupted_proof_blocked(self):
        self.f.objects['PROOF_'+FIVE[0]]=b'broken'
        # The protected pinned reader rejects bytes not matching claimed sha before status.
        with self.assertRaises(AssertionError):self.verify()
    def test_10_no_evidence_payload_rejected(self):
        obj=json.loads(self.f.objects['PROOF_'+FIVE[0]]);obj['evidence']=[]
        pref=self.f.put('PROOF_'+FIVE[0],canon(obj));comp=json.loads(self.f.objects['ENGINEERING_COMPLETENESS'])
        comp['five_part_completeness'][FIVE[0]]['sha256']=pref['sha256']
        ref=self.f.put('ENGINEERING_COMPLETENESS',canon(comp))
        self.r['evidence']=[ref if v['role']=='ENGINEERING_COMPLETENESS' else v for v in self.r['evidence']]
        self.assert_blocks('FIVE_PART_NO_SUBSTANTIVE_EVIDENCE')
    def test_11_native_return_must_be_a_real_zip(self):
        ref=self.f.put('NATIVE_RETURN_ZIP',b'opaque status PASS is not a zip')
        self.r['evidence']=[ref if x['role']=='NATIVE_RETURN_ZIP' else x for x in self.r['evidence']]
        self.assert_blocks('NATIVE_ZIP_INVALID')
    def test_12_integration_source_must_match_final_code(self):
        ref=self.f.put('G5_INTEGRATION_SOURCE',b'arbitrary hashed text')
        self.r['evidence']=[ref if x['role']=='G5_INTEGRATION_SOURCE' else x for x in self.r['evidence']]
        self.assert_blocks('INTEGRATION_SOURCE_BYTES')
    def test_13_integration_manifest_is_not_an_opaque_attachment(self):
        ref=self.f.put('G5_INTEGRATION_MANIFEST',canon({'status':'PASS'}))
        self.r['evidence']=[ref if x['role']=='G5_INTEGRATION_MANIFEST' else x for x in self.r['evidence']]
        self.assert_blocks('INTEGRATION_MANIFEST_BINDING')

if __name__=='__main__':unittest.main()
