"""Bounded engineering tests. Not proof of Windows process-kill recovery."""
import sys
import pathlib
import unittest
import types
import json
from contextlib import contextmanager
from unittest import mock

IMPL=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(IMPL/'candidate/full'))
sys.path.insert(0,str(IMPL/'candidate/control'))
sys.path.insert(0,str(IMPL/'candidate/g5proof'))
import tickstore_full_multiwork as M
import FULL_LIFECYCLE as L


def trace(keys, statuses):
    return {'schema':'TICKSTORE_G3_PREPARALLEL_RECOVERY_TRACE_V001',
            'status':'PASS_NORMALIZED','observed_transient_dates':keys,
            'normalized':[{'date_key':k,'status':s} for k,s in zip(keys,statuses)],
            'recovered_count':len(statuses),'post_normalization_transient_count':0,
            'crash_origin_attestation':'NOT_PROVEN_BY_NORMALIZATION_ALONE',
            'physical_powerloss':'NOT_TESTED_PHYSICAL_POWERLOSS'}


class NativeCausalityContract(unittest.TestCase):
    def test_empty_start_cannot_be_falsely_claimed_as_recovery(self):
        with mock.patch.object(M,'_canonical_transient_dates',side_effect=[[],[]]):
            t=M._normalize_interrupted_canonical_transactions('s','d',[],{},'L',{},None,capture_evidence=True)
        self.assertEqual(t,trace([],[]))
        result=L.verify_g3_recovery_trace({'pre_multiwork_recovery':t})
        self.assertEqual(result['g3_observed_recovered_days'],0)
        self.assertEqual(result['g3_post_crash_test'],'NOT_PROVEN_BY_G3_RECEIPT')
    def test_two_interrupted_days_physically_normalized(self):
        days=[{'date_key':'20200701','month_id':'2020_07'},{'date_key':'20200702','month_id':'2020_07'}]
        with mock.patch.object(M,'_canonical_transient_dates',side_effect=[['20200701','20200702'],[]]) as classify, \
             mock.patch.object(M,'_recover_full_serial_day',side_effect=['RESUMED','RESUMED_MANIFEST']) as recover:
            t=M._normalize_interrupted_canonical_transactions('s','d',days,{'2020_07':{'source_size':'1'}},'L',{},None,capture_evidence=True)
        self.assertEqual(classify.call_count,2)
        self.assertEqual(recover.call_count,2)
        self.assertEqual(t['observed_transient_dates'],['20200701','20200702'])
        self.assertEqual(t['recovered_count'],2)
        self.assertEqual(L.verify_g3_recovery_trace({'pre_multiwork_recovery':t})['g3_observed_recovered_days'],2)
    def test_residual_canonical_partial_blocks(self):
        d=[{'date_key':'20200701','month_id':'2020_07'}]
        with mock.patch.object(M,'_canonical_transient_dates',side_effect=[['20200701'],['20200701']]), \
             mock.patch.object(M,'_recover_full_serial_day',return_value='RESUMED'):
            with self.assertRaisesRegex(Exception,'PRE_MULTIWORK_RECOVERY_RESIDUAL'):
                M._normalize_interrupted_canonical_transactions('s','d',d,{'2020_07':{}},'L',{},None,capture_evidence=True)
    def test_legacy_integer_call_retained(self):
        d=[{'date_key':'20200701','month_id':'2020_07'}]
        with mock.patch.object(M,'_canonical_transient_dates',return_value=['20200701']) as classify, \
             mock.patch.object(M,'_recover_full_serial_day',return_value='RESUMED'):
            count=M._normalize_interrupted_canonical_transactions('s','d',d,{'2020_07':{}},'L',{},None)
        self.assertEqual(count,1)
        self.assertEqual(classify.call_count,1)
    def test_unrecognized_recovery_status_cannot_count(self):
        d=[{'date_key':'20200701','month_id':'2020_07'}]
        with mock.patch.object(M,'_canonical_transient_dates',return_value=['20200701']), \
             mock.patch.object(M,'_recover_full_serial_day',return_value='FAKE_PASS'):
            with self.assertRaisesRegex(Exception,'PRE_MULTIWORK_RECOVERY_UNEXPECTED_STATUS'):
                M._normalize_interrupted_canonical_transactions('s','d',d,{'2020_07':{}},'L',{},None,capture_evidence=True)
    def test_duplicate_transient_keys_fail(self):
        with mock.patch.object(M,'_canonical_transient_dates',return_value=['20200701','20200701']):
            with self.assertRaisesRegex(Exception,'PRE_MULTIWORK_RECOVERY_DUPLICATE_DATE'):
                M._normalize_interrupted_canonical_transactions('s','d',[],{},'L',{},None,capture_evidence=True)
    def test_g6_rejects_invented_crash_origin_and_mismatched_days(self):
        base=trace(['20200701'],['RESUMED'])
        mutations=[{'crash_origin_attestation':'PHYSICAL_CRASH_PASS'},
                   {'physical_powerloss':'PASS'},
                   {'status':'PASS'},
                   {'post_normalization_transient_count':1},
                   {'recovered_count':2},
                   {'observed_transient_dates':['20200702']},
                   {'normalized':[]},
                   {'normalized':[{'date_key':'20200701','status':'MAGIC'}]},
                   {'observed_transient_dates':['20200701','20200701'],'recovered_count':2,
                    'normalized':[{'date_key':'20200701','status':'RESUMED'}]*2}]
        for mutation in mutations:
            with self.subTest(mutation=mutation),self.assertRaises(Exception):
                L.verify_g3_recovery_trace({'pre_multiwork_recovery':dict(base,**mutation)})
    def test_g6_requires_trace_even_if_reconcile_claims_pass(self):
        with self.assertRaisesRegex(Exception,'G3_NORMALIZATION_WITNESS_MISSING'):
            L.verify_g3_recovery_trace({'status':'PASS'})
    def test_dispatcher_g6_does_not_promote_unproven_crash_to_pass(self):
        proof={
            'schema':'TICKSTORE_MULTIWORK_RECONCILIATION_V001',
            'status':'PASS','run_id':'SAME-INSTANCE',
            'instance_sha256':'A'*64,'code_manifest_sha256':'B'*64,
            'pre_multiwork_recovery':trace([],[]),
        }
        class Reader:
            def __enter__(self): return self
            def __exit__(self,*args): return None
            def read(self,*args): return json.dumps(proof).encode()
            def revalidate(self): return None
        original=lambda node: {'LEGACY_CALLED':node}
        engine=types.SimpleNamespace(runnode=original,
            st=types.SimpleNamespace(jp='JOURNAL',runs='RUNS'),
            cfg={'production_dest_root':'NOT_USED'})
        adm=types.SimpleNamespace(instance={'run_id':'SAME-INSTANCE'},
            descriptor={'instance_sha256':'A'*64,'code_manifest_sha256':'B'*64})
        ns={}
        with mock.patch.object(L,'Reads',Reader), \
             mock.patch.object(L,'closed_results',return_value=({'G3':{
                 'reconciliation':{'path':'PHYSICAL_G3','sha256':'C'*64}}},[])), \
             mock.patch.object(L,'_full_multiwork_g6',return_value={'RECONCILE':'PASS'}) as post:
            L.install(engine,ns,adm,2)
            actual=engine.runnode('G6')
        post.assert_called_once_with(engine)
        self.assertEqual(actual['g3_observed_recovered_days'],0)
        self.assertEqual(actual['g3_post_crash_test'],'NOT_PROVEN_BY_G3_RECEIPT')
        self.assertNotIn('g3_recovery_verified',actual)
        self.assertEqual(actual['g3_reconciliation_sha256'],'C'*64)
    def test_dispatcher_g6_rejects_missing_normalization_proof(self):
        proof={
            'schema':'TICKSTORE_MULTIWORK_RECONCILIATION_V001',
            'status':'PASS','run_id':'SAME-INSTANCE',
            'instance_sha256':'A'*64,'code_manifest_sha256':'B'*64,
        }
        class Reader:
            def __enter__(self): return self
            def __exit__(self,*args): return None
            def read(self,*args): return json.dumps(proof).encode()
            def revalidate(self): return None
        engine=types.SimpleNamespace(runnode=lambda n:None,
            st=types.SimpleNamespace(jp='JOURNAL',runs='RUNS'),
            cfg={'production_dest_root':'NOT_USED'})
        adm=types.SimpleNamespace(instance={'run_id':'SAME-INSTANCE'},
            descriptor={'instance_sha256':'A'*64,'code_manifest_sha256':'B'*64})
        with mock.patch.object(L,'Reads',Reader), \
             mock.patch.object(L,'closed_results',return_value=({'G3':{
                 'reconciliation':{'path':'PHYSICAL_G3','sha256':'C'*64}}},[])), \
             mock.patch.object(L,'_full_multiwork_g6') as post:
            L.install(engine,{},adm,2)
            with self.assertRaisesRegex(Exception,'G3_NORMALIZATION_WITNESS_MISSING'):
                engine.runnode('G6')
            post.assert_not_called()

    def test_job_census_empties_before_handle_signals_bounded_wait(self):
        import PRE_G06_NATIVE_SCENARIOS as N
        from FULL_CRASH_RECOVERY import dead
        identity={'pid':123456,'creation_filetime':42}
        scans=[]
        timeline=iter([0,0.1,0.2,0.3,0.4,0.5])
        states=iter(['LIVE','LIVE','EXITED','EXITED'])
        def probe(pid):
            state=next(states,'EXITED')
            scans.append(state)
            return dict(identity,state=state)
        result=N.bounded_owned_death_consensus([identity],lambda:[],
                    probe=probe,monotonic=lambda:next(timeline,1),snooze=lambda _:None,seconds=2)
        self.assertEqual(scans[:3],['LIVE','LIVE','EXITED'])
        self.assertEqual(result[0]['observation'],'EXITED')

    def test_still_live_owner_never_passes_when_job_census_empty(self):
        import PRE_G06_NATIVE_SCENARIOS as N
        identity={'pid':123456,'creation_filetime':42}
        times=iter([0,0.1,0.3,2])
        with self.assertRaisesRegex(RuntimeError,'OWNED_ORPHANS_AFTER_COORDINATOR_DEATH'):
            N.bounded_owned_death_consensus([identity],lambda:[],
                probe=lambda pid:dict(identity,state='LIVE'),
                monotonic=lambda:next(times,2),snooze=lambda _:None,seconds=1)

    def test_job_member_alive_never_passes_even_if_identity_exited(self):
        import PRE_G06_NATIVE_SCENARIOS as N
        identity={'pid':123456,'creation_filetime':42}
        times=iter([0,0.1,2])
        with self.assertRaisesRegex(RuntimeError,'OWNED_ORPHANS_AFTER_COORDINATOR_DEATH'):
            N.bounded_owned_death_consensus([identity],lambda:[identity],
                probe=lambda pid:dict(identity,state='EXITED'),
                monotonic=lambda:next(times,2),snooze=lambda _:None,seconds=1)

    def test_no_change_frozen_serial_runner_hash(self):
        import hashlib
        src=IMPL/'candidate/full/tickstore_serial_runner.py'
        self.assertEqual(hashlib.sha256(src.read_bytes()).hexdigest().upper(),
                         '749EEC5DF5C4F396D553AD75C1765D5BDA108391F877CC0C9179D82590429E00')

if __name__=='__main__':unittest.main()
