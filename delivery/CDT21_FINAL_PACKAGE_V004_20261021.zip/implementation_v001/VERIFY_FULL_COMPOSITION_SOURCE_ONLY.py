import json,hashlib,sys,pathlib,ast
R=pathlib.Path(__file__).resolve().parent
S=lambda b:hashlib.sha256(b).hexdigest().upper()
def ck(c,msg):
 if not c:raise RuntimeError(msg)
def main():
 m=json.loads((R/'RUNTIME_CODE_MANIFEST.json').read_bytes())
 c=R/'candidate'; actual={p.relative_to(c).as_posix():p for p in c.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
 listed={row['path']:row for row in m['files']}
 ck(set(actual)==set(listed),'RUNTIME_MEMBER_SET')
 for name,path in actual.items():
  raw=path.read_bytes();entry=listed[name]
  ck(len(raw)==entry['bytes'] and S(raw)==entry['sha256'],'CODE_MEMBER:'+name)
  if path.suffix=='.py':ast.parse(raw.decode('utf8'),filename=str(path))
 t=json.loads((R/'SOURCE_MANIFEST.json').read_bytes());expected={r['path']:r for r in t['files']}
 actual={p.relative_to(R).as_posix():p for p in R.rglob('*') if p.is_file() and p.name!='SOURCE_MANIFEST.json' and '__pycache__' not in p.parts}
 ck(set(actual)==set(expected),'SOURCE_EXACT_SET')
 for name,path in actual.items():
  row=expected[name];raw=path.read_bytes()
  ck(len(raw)==row['bytes'] and S(raw)==row['sha256'],'SOURCE_MEMBER:'+name)
 e=json.loads((R/'FULL_COMPOSITION_EVIDENCE.json').read_bytes())
 ck(e['five_part_completeness']['frozen_for_independent_audit']=='NO','FALSE_READY')
 ck(e['full_started'] is False and e['production_modified'] is False,'FALSE_PRODUCTION')
 print('COMPOSITION_SOURCE_INTEGRITY=PASS\nFULL_CANDIDATE_COMPLETENESS=NOT_PROVEN\nB06=NOT_STARTED\nFULL_STARTED=NO')
if __name__=='__main__':
 try:main()
 except Exception as ex:print('COMPOSITION_SOURCE_INTEGRITY=BLOCKED '+str(ex));sys.exit(2)
