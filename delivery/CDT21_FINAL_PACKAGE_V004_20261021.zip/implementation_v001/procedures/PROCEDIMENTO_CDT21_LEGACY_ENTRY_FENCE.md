# Procedimento CDT21 — corte de entrada legada (F-01 / F-01R1, V004)

**Status:** não executado. Requer autorização expressa da origem, porque escreve no `control_root` produtivo:
- um diretório e dois arquivos em `state\STATE.json.partial`;
- uma ACE de negação na DACL de `state\STATE_JOURNAL.jsonl`, ou a criação de um journal vazio, se não houver.

Não altera o conteúdo de STATE nem do journal.

## Por que mudou em relação ao V003

A B06 do V003 mostrou que a cerca V003 (somente o diretório `STATE.json.partial`) barra **novas** instâncias legadas, mas não barra um processo legado que construiu `State` **antes** da cerca. Esse processo continua acrescentando ao journal: `State.log` abre `STATE_JOURNAL.jsonl` em `"ab"` por nome a cada chamada e não segura handle, lock nem mutex entre as escritas.

O V004 fecha o journal pelo nome para todos os processos, do instante do corte em diante:
- **ACE explícita de negação** para Todos (`FILE_WRITE_DATA|FILE_APPEND_DATA`), verificada pelo kernel a cada abertura;
- **prova do instante do corte:** o journal é aberto sem compartilhamento de escrita, o que prova que nenhum handle de escrita aberto antes da ACE sobreviveu;
- **registro** dos bytes do journal nesse instante, em `LEGACY_JOURNAL_CUT.json`.

Escritores admitidos (entrada D4 e continuação FULL, ambos elevados) acrescentam a mesma linha com backup semantics, usando `SeRestorePrivilege` somente no token da thread e somente durante a abertura.

## Quando

Uma única vez, antes da primeira admissão D4 ou de qualquer continuação oficial com o candidato V004. Sem o corte completo e drenado, a cadeia oficial falha fechada. Os motivos possíveis são:
- `LEGACY_ENTRY_FENCE_MISSING`;
- `LEGACY_JOURNAL_CUT_RECORD_MISSING`;
- `LEGACY_JOURNAL_CUT_NOT_ENFORCED`;
- `LEGACY_RUN_POSSIBLY_ACTIVE`.

## Como

Use PowerShell 5.1 **elevado**, a partir de `C:\Users\silvi`, com o Python fixado e o diretório `adapter` instalado do V004:

```
& 'C:\Users\silvi\AppData\Local\Python\pythoncore-3.14-64\python.exe' -I -B <V004>\implementation_v001\candidate\control\LEGACY_ENTRY_FENCE.py --state 'D:\Base CSV\Scripts\TICKSTORE_R9_DEV\WORK_R9_PUBLISHER_RECOVERY_V004R1R1\ORCHESTRATOR_V001R9R1_B6_R8_PROVENANCE_VSS_SCOPE_FIX\state\STATE.json' --adapter-dir <V004>\implementation_v001\candidate\adapter
```

1. **Diagnóstico somente leitura** (sem `--apply`).
   - Esperado: `FENCE_ABSENT_INSTALLABLE` (exit 2).
   - Se a cerca do V003 já tiver sido instalada: `FENCE_CUT_INCOMPLETE_INSTALLABLE`.
2. **Corte** (com `--apply`).
   - Esperado: `FENCE_PRESENT`, com `applied=true`, `frozen_write_denied=true` e `frozen_append_denied=true` (exit 0).
   - `state_version` não muda.
   - `cut.journal_at_cut` registra os bytes do journal no instante do corte.
3. **Recibo.** Guarde a saída JSON e os arquivos `state\STATE.json.partial\LEGACY_ENTRY_FENCE.json` e `LEGACY_JOURNAL_CUT.json`.

## Resultados que não são PASS

| Resultado | Situação | Ação |
|---|---|---|
| `CUT_PRESENT_LEGACY_RUN_NOT_DRAINED` | O corte está feito, mas o journal no corte nomeia uma execução legada (`STARTED` com `run_id=<carimbo>_<pid>`) cujo processo pode estar vivo. Esse processo já não consegue escrever STATE nem o journal. | Aguarde o fim do processo (nunca o encerre sem autorização) e repita o diagnóstico. A decisão passa a `FENCE_PRESENT` quando a identidade dele deixar de existir. |
| `CUT_PRESENT_LEGACY_ACTIVITY_DURING_CUT` (só `--apply`) | O journal mudou entre o diagnóstico e o instante do corte, ou seja, havia um escritor legado vivo. O corte está feito e registrado com essa linha. | Repita o diagnóstico. |
| `BLOCKED_MANUAL` + `LEGACY_JOURNAL_WRITER_OPEN_AT_CUT` | Havia um handle de escrita aberto no journal durante 5 s de sondagem. A ACE foi aplicada, mas o registro do corte **não** foi escrito; a admissão continua recusada. | Repita `--apply` quando o escritor fechar. |
| `BLOCKED_MANUAL` + `LEGACY_PARTIAL_DEBRIS_PRESENT` | Existe um arquivo `STATE.json.partial`: uma escrita congelada interrompida. | Diagnóstico manual. |
| `BLOCKED_MANUAL` + `LINK_OR_REPARSE` | Há link ou reparse na cadeia. | Diagnóstico manual. |
| `BLOCKED_MANUAL` + `ADAPTER_ENTRY_STATE_BOUNDARY_BUSY` | Há uma entrada D4 viva segurando a fronteira de STATE. | Aguarde o fim dela. |
| `BLOCKED_MANUAL` + marcador ou registro inválido | Adulteração ou instalação interrompida. | Diagnóstico manual. |

## Efeito comprovado

Comprovação: `tests/test_cdt21_f01_legacy_entry_fence.py`, `tests/test_cdt21_f01r1_preexisting_legacy_cut.py` e `qual/CDT21_F01R1_MUTATION_CONTROLS.py`.

**Processos legados novos.** Qualquer invocação do orquestrador congelado, pelo PS1 legado, por `python orchestrator.py` ou por qualquer cópia, sai antes de construir `State`, sem alterar nada.

**Processo legado que construiu `State` antes do corte:**
- recebe `PermissionError` na próxima tentativa de acrescentar ao journal;
- não consegue gravar STATE (o `finish()` congelado registra no journal antes de gravar STATE, e esse registro é negado);
- não consegue iniciar um novo nó (`STARTED` é negado).

**Nó legado em andamento no instante do corte.** Fica nomeado no journal do corte e bloqueia a admissão até que a identidade do processo deixe de existir.

**Prova de drenagem.** A prova vem do journal do corte e de identidades de processo específicas, verificadas pelos critérios abaixo; não é um censo de processos. A propriedade é monotônica: depois do corte nenhum legado registra um novo `STARTED`, e uma identidade encerrada não volta. Uma identidade é considerada encerrada quando, para o PID de cada execução registrada no journal do corte:
- não existe processo com esse PID; ou
- o processo saiu; ou
- o PID pertence agora a um processo criado depois do primeiro `STARTED` da execução mais 600 s.

## Limites declarados

- Supõe-se que o relógio do sistema não recue mais de 600 s entre a criação de um processo legado e o seu primeiro `STARTED`.
- Fora do modelo de ameaça: um principal com escrita na DACL que remova a ACE ou renomeie a cerca. A admissão recusa a ACE ausente (`LEGACY_JOURNAL_CUT_NOT_ENFORCED`), a troca do journal (`LEGACY_JOURNAL_CUT_IDENTITY`) e a reescrita do prefixo (`LEGACY_JOURNAL_CUT_PREFIX_CHANGED`).
- Comandos legados sem nó (`stop`, `confirm-stale-lock`, `status`, `plan`, `attach`, `ingest-stage-b`, `reconcile`, `postfull`) não registram `STARTED`. Se já tiverem construído `State` antes do corte, não escrevem STATE nem o journal:
  - `confirm-stale-lock` pode gravar o seu token na `inbox`;
  - `stop` pode sinalizar o evento de parada segura de um motor;
  - `reconcile` grava apenas no próprio `runs\<id>` e falha ao gravar STATE;
  - `postfull` só lê.
- `run`/`resume` antes do primeiro `STARTED` falham no próprio `STARTED` (negado), sem efeito de nó.

O corte nunca é removido pela ferramenta. Removê-lo reabre a rota legada e faz a cadeia oficial falhar fechada.
