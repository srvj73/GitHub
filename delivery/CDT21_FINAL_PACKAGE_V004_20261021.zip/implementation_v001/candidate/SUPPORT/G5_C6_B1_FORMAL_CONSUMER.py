"""CDT17 G5 C6 native RETURN evidence consumer: formal-B1 additive path.

This is a sidecar G5 evidence consumer, NOT a G5 gate issuer. It uses the
unchanged FULL package and the original contract's typed-proof verifier. Never
relabels 126 historical B1 IDs as freshly executed C6 delta tests.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import os
import re
import sys
import time
import zipfile
from pathlib import Path

from FULL_QUALIFICATION_CONTRACT import (
    _zip_members, final_zip_findings, proof_receipt_findings, _sha,
    TYPED_PROOFS, PROOF_PREFIX,
)

FULL_SHA='2A522667D2592E848E055C8374C9453660D774276ED4522DF82B15F30523F660'
G4_SHA='222FDB46FC97D0B1E518B648FC00CCE3A18E2C6B8B42E73D2E32A90B448C19B3'
HISTORY_SHA='2D9DBA00D3282E2899672722DE9E6B856F0BC8E9F29657FFC24F1149FB4E0CAC'
BASE_SHA='DC73A8C3819F1B7E0C4C71665C3379F0186A4518849573738746444B48C379F8'
RUNTIME_SHA='0255AF34ACECFF2B4167CF89B9C493C9237E0EE8F2C928DE9CE334E514F252BF'
P_MASTER='623A8EC6170E97C7C14CAD1B873F3706725BD610438AC65BE58FEEF0435581BC'
P_HEAD='D71C963758E65A1BA9D1621C49D7A23D9FCF9E596CF6780F2379BD59E295688B'
SIX=('D4_REAL_ISOLATED_PATH_NATIVE','STAGE_B_REAL_ISOLATED_PATH_NATIVE','PROCESS_TREE_CRASH_CONTAINMENT','SAFE_STOP_RESUME_ROW_GROUP','PS51_INSTALL_MENU','POWERLOSS_EMULATED')
TEN=('formal.source_126','formal.policy_r45','formal.package_closed_set','formal.native_bound_final_code',
     'negative.missing_source','negative.mismatched_policy','negative.changed_final_package',
     'negative.incomplete_native_return','negative.duplicate_test_id','negative.terminal_status_not_pass')
class Blocked(RuntimeError): pass

def ck(cond,reason):
    if not cond: raise Blocked(reason)

def strict_json(data):
    def pairs(items):
        d={}
        for k,v in items:
            ck(k not in d,'JSON_DUPLICATE_KEY:'+str(k));d[k]=v
        return d
    return json.loads(data.decode('utf-8'),object_pairs_hook=pairs)

def closed(raw, expected_schema, manifest='RETURN_MANIFEST.json'):
    try:
        z,files,errors=_zip_members(raw,'CLOSED')
    except Exception as ex:
        raise Blocked('ZIP_DECOMPRESSION_ERROR:'+type(ex).__name__) from ex
    ck(z is not None and not errors,'ZIP_INVALID:'+str(errors))
    ck(manifest in files,'MANIFEST_MISSING')
    obj=strict_json(files[manifest]);ck(obj.get('schema')==expected_schema,'MANIFEST_SCHEMA')
    rows=obj.get('files')
    if isinstance(rows,dict):
        ck(expected_schema=='TICKSTORE_CDT17_B1_FINAL_NATIVE_RETURN_MANIFEST_V001','UNEXPECTED_MANIFEST_MAP_SCHEMA')
        ck(set(rows)==set(files)-{manifest},'MANIFEST_EXACT_SET')
        for name,expect in rows.items():
            ck(isinstance(expect,str) and _sha(files[name])==expect,'MANIFEST_MEMBER:'+name)
    else:
        ck(isinstance(rows,list),'MANIFEST_RECORDS')
        names=[a.get('path') for a in rows if isinstance(a,dict)]
        ck(len(names)==len(rows) and len(set(names))==len(names),'MANIFEST_DUPLICATES')
        ck(set(names)==set(files)-{manifest},'MANIFEST_EXACT_SET')
        for row in rows:
            body=files[row['path']]
            ck(type(row.get('bytes')) is int and row['bytes']==len(body) and row.get('sha256')==_sha(body), 'MANIFEST_MEMBER:'+row['path'])
    return files

def plain_zip(raw):
    try:
        z,files,errors=_zip_members(raw,'PACK')
    except Exception as ex:
        raise Blocked('PACK_DECOMPRESSION_ERROR:'+type(ex).__name__) from ex
    ck(z is not None and not errors,'PACK_INVALID:'+str(errors))
    return files

def readfile(p,required):
    b=Path(p).read_bytes()
    ck(_sha(b)==required,'INPUT_SHA256:'+str(p))
    return b

def run(*, final_raw, g4_raw, history_raw, baseline_raw, consumer_sha=None):
    ck(_sha(final_raw)==FULL_SHA,'FULL_SHA256_MISMATCH')
    ck(_sha(g4_raw)==G4_SHA,'G4_RETURN_SHA256_MISMATCH')
    ck(_sha(history_raw)==HISTORY_SHA,'HISTORY_SHA256_MISMATCH')
    ck(_sha(baseline_raw)==BASE_SHA,'BASELINE_SHA256_MISMATCH')
    # Exact closed FINAL source and old, unchanged typed-proofs implementation.
    ff,code_index=final_zip_findings(final_raw,RUNTIME_SHA)
    ck(not ff and isinstance(code_index,dict) and len(code_index)>0,'FINAL_PACKAGE:'+str(ff[:5]))
    raw=plain_zip(final_raw)
    old_consumer=raw['implementation_v001/candidate/control/FULL_QUALIFICATION_CONTRACT.py']
    ck(old_consumer==Path(__file__).with_name('FULL_QUALIFICATION_CONTRACT.py').read_bytes(), 'BASE_CONSUMER_NOT_ORIGINAL')
    contract=strict_json(raw['implementation_v001/candidate/control/QUALIFICATION_CONTRACT.json'])
    ck(contract.get('schema')=='TICKSTORE_QUALIFICATION_CONTRACT_V001','CONTRACT_SCHEMA')
    wanted=contract['required_tests']
    ck(len(wanted)==126 and len(set(wanted))==126,'B1_CONTRACT_126')
    ck(tuple(contract['required_target_proofs'])==SIX,'SIX_PROOF_NAMES_OR_ORDER_CHANGED')
    ck(contract['baseline']['archive_sha256']==_sha(baseline_raw),'BASELINE_NOT_CONTRACT')
    # G4 closed return and explicit scoped evidence admission.
    g4=closed(g4_raw,'TICKSTORE_CDT15_RETURN_MANIFEST_V001')
    q=strict_json(g4['QUAL_RECEIPT.json']); ck(isinstance(q,dict),'QUAL_RECEIPT_SCHEMA')
    ck(q.get('schema')=='TICKSTORE_CDT15_WINDOWS_QUALIFICATION_RECEIPT_V003','QUAL_SCHEMA')
    ck(q.get('G4_NATIVE_QUALIFICATION')=='PASS' and q.get('B1_FORMAL_ADMISSION')=='PASS','G4_B1_NOT_PASS')
    ck(q.get('GATE_VERDICT_ISSUED') is False and q.get('EXIT_CODE')==0 and q.get('BLOCKER') is None,'G4_FALSE_GATE_OR_BLOCKER')
    ck(q.get('SOURCE_SHA256')==FULL_SHA and q.get('RUNTIME_CODE_MANIFEST_SHA256')==RUNTIME_SHA,'G4_FINAL_NOT_SAME_BYTES')
    ck(q.get('PRODUCTION_MODIFIED') is False and q.get('FULL_STARTED') is False and q.get('mode')=='NATIVE_WINDOWS','G4_WRONG_SCOPE')
    ck(str(q.get('TESTED_CODE_EQUALS_PACKAGED_CODE','')).startswith('PASS'),'G4_TESTED_PACKAGED')
    pre=q.get('PRECHECK')
    ck(isinstance(pre,dict) and str(pre.get('powershell','')).startswith('5.1.') and
       str(pre.get('platform','')).startswith('Windows') and 'MSC v.' in str(pre.get('python','')) and
       pre.get('elevated') is True and pre.get('symlink_privilege')=='PASS' and
       all(isinstance(x,dict) and x.get('filesystem')=='NTFS' for x in pre.get('volumes',{}).values()) and
       set(pre.get('volumes',{}))=={'C','D'},'G4_NATIVE_PRECHECK')
    suites=q.get('TESTS',[])
    ck(len(suites)==17 and len({s.get('suite') for s in suites})==17,'G4_SUITE_CARDINALITY')
    cnt=0
    for s in suites:
        name=s['suite'];ck(s.get('status')=='PASS','G4_SUITE_NONPASS:'+name)
        if name.startswith('S'):
            member='EVIDENCE/SUITE_'+name+'.json'
            ck(member in g4 and _sha(g4[member])==s.get('result_sha256'),'G4_SUITE_BINDING:'+name)
            d=strict_json(g4[member]);num=s.get('run')
            ck(type(num) is int and num==s.get('expected') and s.get('failures')==0 and s.get('errors')==0 and s.get('skips')==0,'G4_SUITE_COUNTER:'+name)
            ck(d.get('run')==num and d.get('failures')==0 and d.get('errors')==0 and d.get('skips')==0,'G4_SUITE_PAYLOAD:'+name)
            cnt+=num
    ck(cnt==279,'G4_SUITE_TOTAL_279')
    ck({'R45_B2C_NATIVE_PROBE','B1_FORMAL_ADMISSION'}=={s['suite'] for s in suites if not s['suite'].startswith('S')},'G4_NONSUITE_UNEXPECTED')
    b1=strict_json(g4['EVIDENCE/B1_FORMAL_ADMISSION.json'])
    ck(b1.get('schema')=='CDT17_G4_R3_B1_FORMAL_ADMISSION_V001' and b1.get('status')=='PASS' and b1.get('historical_126_unique_pass')==126 and b1.get('native_formal_new_tests')==10,'B1_G4_ADMISSION')
    ck(b1.get('final_candidate_sha256')==FULL_SHA and b1.get('runtime_code_manifest_sha256')==RUNTIME_SHA,'B1_G4_PACKAGE_BINDING')
    ck(b1.get('current_source_R46_master_sha256')==P_MASTER and b1.get('R44_R2_27_NONPASS_RELABELED') is False,'B1_G4_DRIFT_OR_FALSE_PASS')
    ck(b1.get('FULL_STARTED') is False and b1.get('G5_FORMAL')=='NOT_ISSUED','B1_G4_OUT_OF_SCOPE')
    # Actual nested B1 receipt and 10 physical native test records; not an unbound summary.
    b1return=g4.get('EVIDENCE/B1_FORMAL_RETURN.zip')
    ck(b1return is not None and _sha(b1return)==b1.get('source_b1_formal_sha256'),'B1_FORMAL_SOURCE')
    nested=plain_zip(b1return)
    ck(set(nested)=={'B1_FORMAL_ADMISSION.json','B1_NATIVE_QUAL_RECEIPT.json','B1_NATIVE_RETURN.zip','B1_NATIVE_STDERR.log','B1_NATIVE_STDOUT.log','G0_EXIT0_STDERR.log','G0_EXIT0_STDOUT.log','G0_EXIT7_STDERR.log','G0_EXIT7_STDOUT.log','LAUNCHER_WITNESS.json'},'B1_FORMAL_MEMBERS')
    fa=strict_json(nested['B1_FORMAL_ADMISSION.json']);nr=strict_json(nested['B1_NATIVE_QUAL_RECEIPT.json'])
    ck(fa.get('status')=='PASS' and fa.get('gate')=='B1_FORMAL' and fa.get('legacy_b1_126_ids')==126 and fa.get('new_consumer_native_tests')==10,'B1_FORMAL_SUMMARY')
    ck(fa.get('final_zip_sha256')==FULL_SHA and fa.get('runtime_manifest_sha256')==RUNTIME_SHA and fa.get('native_return_sha256')==_sha(nested['B1_NATIVE_RETURN.zip']),'B1_FORMAL_IDENTITY')
    ck(nr.get('status')=='PASS_NATIVE_INTEGRATED' and nr.get('tests_run')==10 and nr.get('errors')==nr.get('failures')==nr.get('skips')==0,'B1_NATIVE10_RESULT')
    ck(nr.get('final_zip_sha256')==FULL_SHA and nr.get('runtime_manifest_sha256')==RUNTIME_SHA and nr.get('platform')=='win32' and nr.get('powershell_major')==5 and nr.get('production_execution') is False,'B1_NATIVE10_BINDING')
    bn=closed(nested['B1_NATIVE_RETURN.zip'],'TICKSTORE_CDT17_B1_FINAL_NATIVE_RETURN_MANIFEST_V001')
    nqual=strict_json(bn['QUAL_RECEIPT.json']);nresults=strict_json(bn['TESTS.json'])
    ck(nqual==nr,'B1_NATIVE_RECEIPT_MISMATCH')
    ck(isinstance(nresults,list) and len(nresults)==10 and len({x.get('id') for x in nresults})==10,'B1_NATIVE10_CARDINALITY')
    ck(set(x['id'] for x in nresults)==set(TEN) and all(x.get('status')=='PASS' for x in nresults),'B1_NATIVE10_NOT_PASS')
    text=bn['TESTS.log'].decode('utf-8')
    ck(re.search(r'Ran 10 tests?(?: in [0-9.]+s)?',text) and text.rstrip().endswith('OK'),'B1_NATIVE10_LOG')
    # Historical source: exact 126 distinct IDs in contract, manifest of four physical returns
    # with a distinct retry of earlier failed native6. Never relabel an old failed native20 PASS.
    historical=plain_zip(history_raw)
    cov=strict_json(historical['CDT16_C5R44_B1_126_COVERAGE_RECONCILIATION_20261015.json'])
    ck(cov.get('schema')=='CDT16_C5R44_B1_DISTRIBUTED_TEST_COVERAGE_RECONCILIATION_V001' and cov.get('all_checks_pass') is True,'B1_HISTORY_RECONCILIATION')
    passes=cov.get('passes');ck(isinstance(passes,list) and len(passes)==126 and len(set(passes))==126 and set(passes)==set(wanted),'B1_HISTORY_ID_SET')
    counts=cov.get('counts',{});ck(counts=={'portable_prior_pass':105,'portable_isolated_pass':1,'native_prior_pass':14,'native_isolated_pass':6,'total_distinct_contract_ids':126},'B1_HISTORY_COUNTS')
    for sr in cov.get('source_files',[]):
        if sr.get('purpose') not in ('portable105','portable1','native14','native6'):continue
        nn='RETURNS/'+sr['file'];ck(nn in historical and len(historical[nn])==sr['bytes'] and _sha(historical[nn])==sr['sha256'],'B1_HISTORY_SOURCE:'+nn)
        rr=closed(historical[nn],strict_json(plain_zip(historical[nn])['RETURN_MANIFEST.json'])['schema'])
    # All six typed proofs run in the Windows qualification, bind to original FINAL and own run.
    proof_data={}; receipts=q.get('PROOFS',[])
    ck(isinstance(receipts,list) and len(receipts)==6 and {x.get('proof') for x in receipts}==set(SIX),'G4_PROOF_LIST')
    for name in SIX:
        member=PROOF_PREFIX+name+'/PROOF_RECEIPT.json'
        ck(member in g4,'PROOF_MISSING:'+name)
        data=strict_json(g4[member]);digest=_sha(g4[member])
        qr=next(x for x in receipts if x['proof']==name)
        ck(qr.get('receipt_sha256')==digest and qr.get('status')==data.get('status') and qr.get('exit')==0,'PROOF_QUAL_BINDING:'+name)
        pf=proof_receipt_findings(name,data,member,g4,code_index,FULL_SHA,RUNTIME_SHA,q.get('RUN_ID'))
        ck(not pf,'PROOF_TYPED:'+name+':'+','.join(pf[:3]))
        proof_data[name]={'sha256':digest,'status':data['status'],'kind':data['kind'],'original_run_id':data['run_id'],
                          'source_member':member,'checks':sorted(data['checks'])}
    ck(proof_data['POWERLOSS_EMULATED']['status']=='EMULATED_PASS','EMULATED_ONLY')
    # Independence/decisions remain separate.  Qualification of evidence alone is not G5.
    return {'schema':'CDT17_G5_C6_FORMAL_B1_EVIDENCE_ADMISSION_V001',
            'status':'PASS_EVIDENCE_CONSUMER_SCOPED','original_full_sha256':FULL_SHA,'g4_return_sha256':G4_SHA,
            'legacy_g5_consumer_sha256':_sha(old_consumer),'runtime_code_manifest_sha256':RUNTIME_SHA,
            'historical_b1':{'status':'PASS_HISTORICAL_BYTES_ONLY','distinct_test_ids':126,'physical_coverage_archive_sha256':HISTORY_SHA,'not_reexecuted_on_c6':True},
            'native_b1':{'status':'PASS','distinct_tests':10,'formal_return_sha256':_sha(b1return),'native_return_sha256':_sha(nested['B1_NATIVE_RETURN.zip'])},
            'g4_native_suites':{'status':'PASS','executed_tests':279,'suites':14,'probe':'R45_B2C_NATIVE_PROBE'},
            'six_typed_proofs':proof_data,
            'real_physical_electrical_power_cut':'NOT_TESTED_PHYSICAL_POWERLOSS',
            'powerloss_emulated_is_electrical_cut':False,
            'gate_verdict_issued':False,'g5_formal':'NOT_ISSUED','b06':'NOT_STARTED','full_started':False,
            'tested_code_equals_packaged_code':'ORIGINAL_FINAL_UNCHANGED',
            'source_scope':'ENGINEERING_READONLY_EVIDENCE_RECONCILIATION','baseline_archive_sha256':_sha(baseline_raw)}

def save_atomic_new(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with open(path,'xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    ck(path.read_bytes()==data,'OUTPUT_READBACK:'+str(path))

def canonical(x):return (json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8')

def main(argv=None):
    ap=argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument('--inputs-dir',required=True);ap.add_argument('--out-dir',required=True)
    args=ap.parse_args(argv)
    inp=Path(args.inputs_dir);out=Path(args.out_dir)
    try:
        ck(not out.exists(),'OUTPUT_EXISTS')
        mapping=[('FULL.zip',FULL_SHA),('G4_RETURN.zip',G4_SHA),('B1_HISTORY.zip',HISTORY_SHA),('BASELINE.zip',BASE_SHA)]
        contents={n:readfile(inp/n,h) for n,h in mapping}
        result=run(final_raw=contents['FULL.zip'],g4_raw=contents['G4_RETURN.zip'],history_raw=contents['B1_HISTORY.zip'],baseline_raw=contents['BASELINE.zip'])
        out.mkdir(parents=True,exist_ok=False)
        save_atomic_new(out/'G5_C6_CONSUMER_ADMISSION.json',canonical(result))
        pack={'schema':'CDT17_G5_C6_EVIDENCE_PACK_V001','inputs':[{'name':n,'sha256':h,'bytes':len(contents[n])} for n,h in mapping],
              'consumer_source_sha256':_sha(Path(__file__).read_bytes()),
              'legacy_original_consumer_sha256':_sha(Path(__file__).with_name('FULL_QUALIFICATION_CONTRACT.py').read_bytes()),
              'admission_sha256':_sha((out/'G5_C6_CONSUMER_ADMISSION.json').read_bytes()),
              'g5_formal':'NOT_ISSUED','g5_evidence':'PASS_SCOPED',
              'reused_proofs':6,'not_reexecuted_historical':126,'native_formal_tests_preserved':10}
        save_atomic_new(out/'G5_C6_EVIDENCE_PACK.json',canonical(pack))
        print('G5_CONSUMER_ADMISSION=PASS_SCOPED G5_FORMAL=NOT_ISSUED B06=NOT_STARTED FULL_STARTED=NO')
        print('RESULT_DIR='+str(out.resolve()))
        return 0
    except (Blocked,OSError,ValueError,KeyError,TypeError) as exc:
        print('G5_CONSUMER_ADMISSION=BLOCKED REASON='+type(exc).__name__+':'+str(exc))
        return 2

if __name__=='__main__':raise SystemExit(main())
