"""Bounded runtime exercises in sibling WORK/EVIDENCE. Never a G5 attestation."""
import argparse, hashlib, json, pathlib, os, stat, unittest

def h(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest().upper()
def require(value):
    if not value: raise RuntimeError('OWNED_PROOF_ROOT')
def no_alias(path):
    path=pathlib.Path(os.path.abspath(path))
    for p in (path,*path.parents):
        s=os.lstat(p)
        require(not stat.S_ISLNK(s.st_mode) and not getattr(s,'st_file_attributes',0)&0x400)
    return path

def main():
    p=argparse.ArgumentParser(allow_abbrev=False)
    for name in ('tests','run-root','run-owned','output','suites'):
        p.add_argument('--'+name,required=True)
    a=p.parse_args()
    root=no_alias(a.run_root); work=no_alias(a.run_owned); tests=no_alias(a.tests)
    output=pathlib.Path(os.path.abspath(a.output)); parent=no_alias(output.parent)
    require(root.is_dir() and work.is_dir() and tests.is_dir())
    require(work.is_relative_to(root/'WORK') and parent.is_relative_to(root/'EVIDENCE'))
    require(not os.path.lexists(output))
    suits=json.loads(a.suites)
    require(isinstance(suits,(list,dict)) and bool(suits))
    require(len(suits)==len(set(suits)))
    prepared=[]
    for name in suits:
        require(isinstance(name,str) and pathlib.Path(name).name==name and name.endswith('.py'))
        q=no_alias(tests/name); require(q.is_file())
        suite=unittest.defaultTestLoader.discover(str(tests),pattern=name,top_level_dir=str(tests))
        require(suite.countTestCases()>0)
        prepared.append((name,q,suite))
    report={}; logs=[]; result=0
    for name,q,suite in prepared:
        before=h(q); log=work/(name+'.tests.log')
        with log.open('x',encoding='utf8') as stream:
            r=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
            stream.flush(); os.fsync(stream.fileno())
        require(before==h(q))
        report[name]={'run':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),
                      'skips':len(r.skipped),'source_sha256':before}
        logs.append({'path':str(log),'sha256':h(log),'bytes':log.stat().st_size})
        if not r.wasSuccessful() or r.skipped or r.testsRun==0: result=1
    no_alias(parent); no_alias(work)
    raw=(json.dumps({'schema':'TICKSTORE_PRE_G06_REAL_CODE_NATIVE_BOUNDED_V001',
        'run_root':str(root),'native_windows':os.name=='nt','suites':report,
        'physical_artifacts':logs,'production_execution':False},sort_keys=True,indent=2)+'\n').encode()
    with output.open('xb') as f: f.write(raw); f.flush(); os.fsync(f.fileno())
    require(output.read_bytes()==raw)
    return result

if __name__=='__main__': raise SystemExit(main())
