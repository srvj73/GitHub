"""Native, source-bound qualification of the eleven pre-B06 consumers.

Protected dispatch is negative only. Positive internal operations use real
packaged writers, journals, CAS and native loader Jobs on owned NTFS. Fixture
locator metadata is explicitly artificial; no VSS/admission proof is issued.
"""
from __future__ import annotations
import base64
import contextlib
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]
for folder in ('control', 'adapter', 'full', 'g5proof'):
    sys.path.insert(0, str(ROOT/folder))
import FULL_CRASH_RECOVERY as R
import PRE_B06_ENGINEERING_GATE as gate
from PRE_G06_NATIVE_SCENARIOS import inside, no_alias, require


def library(path):
    path = Path(path)
    ns = {'__name__': 'pre_g06_library_' + uuid.uuid4().hex, '__file__': str(path)}
    exec(compile(path.read_bytes(), str(path), 'exec'), ns)
    return ns


def inventory(root):
    rows = []
    for p in sorted(Path(root).rglob('*')):
        R.core.assert_no_link_chain(p)
        if p.is_file():
            raw = R.core.secure_read_all(p)
            rows.append({'path': p.relative_to(root).as_posix(), 'bytes': len(raw), 'sha256': R.sha(raw)})
    return R.encoded(rows)


def junction(alias, target):
    cmd = Path(os.environ['SystemRoot'])/'System32/cmd.exe'
    p = subprocess.run([str(cmd), '/d', '/c', 'mklink', '/J', str(alias), str(target)],
                       capture_output=True, timeout=20)
    require(p.returncode == 0 and alias.lstat().st_file_attributes & 0x400, 'JUNCTION_NOT_CREATED')


def denied(call, expected=None):
    try:
        call()
    except BaseException as exc:
        require(not isinstance(exc, KeyboardInterrupt), 'INTERRUPTED_NEGATIVE')
        error = type(exc).__name__ + ':' + str(exc)
        require(expected is None or expected in error, 'WRONG_NEGATIVE:' + error)
        return {'exit_code': int(exc.code) if isinstance(exc, SystemExit) and isinstance(exc.code, int) else 2,
                'error': error, 'rejected': True}
    raise RuntimeError('NEGATIVE_WAS_ACCEPTED')


def trace(source, call):
    events = []; previous = ''
    def profile(frame, phase, arg):
        nonlocal previous
        if phase not in ('call', 'return') or Path(frame.f_code.co_filename).absolute() != source.absolute():
            return
        obj = {'phase': phase, 'function': frame.f_code.co_name, 'line': frame.f_code.co_firstlineno,
               'previous_sha256': previous, 'pid': os.getpid()}
        raw = R.encoded(obj).rstrip(b'\n'); previous = R.sha(raw); events.append(raw)
    require(sys.getprofile() is None, 'PROFILE_ALREADY_ACTIVE')
    sys.setprofile(profile)
    try: result = call()
    finally: sys.setprofile(None)
    require(bool(events), 'SOURCE_ENTRY_NOT_OBSERVED')
    return result, b'\n'.join(events) + b'\n'


def scoped(root, owner_sha, path, operation):
    require(R.sha(R.core.secure_read_all(Path(root)/'OWNER.json')) == owner_sha, 'FOREIGN_OWNER')
    inside(path, root)
    return operation()


def engine_payload(source):
    ns = library(source); raw = source.read_bytes()
    owner = R.encoded({'schema': 'RECOVERY_OWNER_GATE_V004', 'authorized': False})
    members = {'tickstore_publisher_recovery_v004.py': raw, 'OWNER_GATE.json': owner}
    manifest = R.encoded({'schema': 'RELEASE_MANIFEST_V004', 'members': {
        n: {'sha256': R.sha(b), 'bytes': len(b)} for n, b in members.items()}})
    members['RELEASE_MANIFEST.json'] = manifest
    anchor = {'inline_root_loader_revision': 'INLINE_ROOT_LOADER_V004_R1', 'spec_sha256': ns['SPEC_SHA'],
              'python_version': '3.14.7', 'release_manifest_sha256': R.sha(manifest),
              'recovery_source_sha256': R.sha(raw), 'owner_gate_sha256': R.sha(owner)}
    return ns, anchor, members


def inline_payload(candidate):
    import adapter_tests as fixture
    candidate = Path(candidate)
    binding = dict(fixture.BINDING)
    raw = (candidate/'recovery/engine/tickstore_publisher_recovery_v004_candidate.py').read_bytes()
    ar = (candidate/'adapter/runtime_locator_adapter.py').read_bytes()
    owner = R.encoded({'schema': 'RECOVERY_OWNER_GATE_V004', 'authorized': False, 'admission_generation': fixture.HIST})
    binding.update(frozen_release_sha256=R.sha(raw), adapter_sha256=R.sha(ar), owner_gate_sha256=R.sha(owner))
    receipt = fixture.receipt(); receipt['owner_gate_sha256'] = R.sha(owner)
    members = {'tickstore_publisher_recovery_v004.py': raw, 'OWNER_GATE.json': owner,
               'RUNTIME_LOCATOR_ADAPTER.bin': ar, 'RUNTIME_LOCATOR_BINDING.json': R.encoded(binding),
               'RUNTIME_LOCATOR_RECEIPT.json': R.encoded(receipt)}
    manifest = R.encoded({'schema': 'RELEASE_MANIFEST_V004', 'members': {
        n: {'sha256': R.sha(b), 'bytes': len(b)} for n, b in members.items()}})
    members['RELEASE_MANIFEST.json'] = manifest
    return {'anchor': {'release_manifest_sha256': R.sha(manifest), 'owner_gate_sha256': R.sha(owner),
                       'recovery_source_sha256': R.sha(raw)},
            'members': {n: base64.b64encode(b).decode() for n, b in members.items()}}


def python_operations(candidate, rel, root):
    source = candidate/rel; ns = library(source); output = root/'effect.json'
    def fail(why): raise RuntimeError(why)
    if rel == 'adapter/runtime_locator_adapter.py':
        writer = ns['make_no_clobber_receipt_writer'](fail)
        positive = lambda: writer(output, R.encoded({'scope': 'ENGINEERING', 'run_owned': True}))
        negative = lambda: writer(output, b'FORBIDDEN_OVERWRITE')
        expected = 'RECEIPT_ALREADY_EXISTS'
    elif rel == 'adapter/runtime_locator_inline_entry.py':
        payload = inline_payload(candidate)
        def positive():
            composed = ns['prepare_runtime'](payload)
            require(composed['_TICKSTORE_RUNTIME_LOCATOR_ADAPTER_INSTALLED'], 'INLINE_NOT_COMPOSED')
            # This is the actual writer installed into the real engine by the
            # shared preparation path; dispatch remains behind its false fuse.
            composed['_d4r_atomic_receipt'](output, R.encoded({'composed_safe_receipt': True, 'operational_authority': False}))
        bad = dict(payload, anchor=dict(payload['anchor'], release_manifest_sha256='0'*64))
        negative = lambda: ns['execute_payload'](bad); expected = 'ADAPTER_PREVERIFY_MANIFEST_HASH'
    elif rel == 'adapter/runtime_locator_orchestrator_entry.py':
        orch = library(candidate/'recovery/modules/orchestrator.py')
        control = root/'control'; st = orch['State'](control)
        def valid(obj): require(obj.get('schema') == 'TICKSTORE_ORCH_STATE_V001', 'STATE_SCHEMA')
        ns['guard_frozen_state_reads'](orch, st.sp, state_validator=valid)
        def positive():
            try:
                admitted = orch['State'](control)
                admitted.d['engineering_checkpoint'] = 1
                orch['atomj'](admitted.sp, admitted.d)
            finally: orch['_TICKSTORE_D4_ENTRY_RELEASE_STATE_BOUNDARY']()
        output = st.sp
        negative = lambda: ns['parse_d4_arguments'](['run', '--until', 'G3', '--package', str(control), '--python', sys.executable])
        expected = None
    elif rel == 'control/D4_FIRST_ADMISSION_TRANSACTION.py':
        staged = root/'prepared_receipt.json'
        def positive():
            ns['create_file'](staged, R.encoded({'scope': 'PRE_B06_INTERNAL_FILE_TRANSACTION', 'operational_authority': False}))
            ns['publish_authority'](staged, output)
        negative = lambda: ns['validate_gates']({}, {}, {'schema': gate.SCHEMA}, {}, {})
        expected = 'PRE_B06_PROOF_IS_NOT_D4_AUTHORITY'
    elif rel == 'control/D4_ROOTS_EVIDENCE.py':
        resume = root/'resume'; resume.mkdir(exist_ok=True); control = root/'control'; control.mkdir(exist_ok=True)
        orch=library(candidate/'recovery/modules/orchestrator.py');state=orch['State'](control)
        recovery_root=root/'recovery';recovery_root.mkdir(exist_ok=True)
        state.d['canary']={'recovery':str(recovery_root)};orch['atomj'](state.sp,state.d)
        state.log('ENGINEERING','FINISHED',status='OBSERVED_NO_AUTHORITY')
        positive = lambda: ns['main'](['--resume-root', str(resume), '--control-root', str(control), '--out', str(output)])
        negative = lambda: ns['main'](['--resume-root', str(resume), '--control-root', str(control), '--out', str(output), '--unknown-mode'])
        expected = None
    elif rel.startswith('recovery/engine/'):
        ns, anchor, members = engine_payload(source)
        def positive():
            ns['Win32Store']().immutable(root, output.name, R.encoded({'scope': 'PRE_B06_NATIVE_IMMUTABLE', 'operational_authority': False}))
        negative = lambda: ns['admit_bundle'](anchor, members); expected = 'OWNER_GATE_NOT_AUTHORIZED'
    elif rel == 'recovery/modules/orchestrator.py':
        control = root/'control'
        def positive():
            state = ns['State'](control)
            state.log('ENGINEERING', 'STARTED', run_id='owned_fixture')
            state.log('ENGINEERING', 'FINISHED', status='OBSERVED_NO_AUTHORITY')
        output = control/'state/STATE_JOURNAL.jsonl'
        # A file cannot become the orchestration root. Exercise the real State
        # entry and retain the protected sentinel byte-for-byte.
        negative = lambda: ns['State'](root/'PROTECTED/sentinel.bin')
        expected = None
    else:
        raise RuntimeError('UNIMPLEMENTED_CONSUMER:' + rel)
    return output, positive, negative, expected


def run_process(argv, root, label):
    stdout = root/(label+'.stdout'); stderr = root/(label+'.stderr')
    with stdout.open('xb') as so, stderr.open('xb') as se:
        p = subprocess.Popen(list(map(str,argv)), stdin=subprocess.DEVNULL, stdout=so, stderr=se)
        # Popen retains the process handle; creation remains observable even
        # if an immediate guard exits before the next scheduler quantum.
        k = ctypes.WinDLL('kernel32', use_last_error=True)
        k.GetProcessTimes.argtypes = [ctypes.c_void_p] + [ctypes.POINTER(ctypes.c_ulonglong)]*4
        times = [ctypes.c_ulonglong() for _ in range(4)]
        require(k.GetProcessTimes(ctypes.c_void_p(int(p._handle)), *[ctypes.byref(t) for t in times]), 'PS_PROCESS_TIMES')
        deadline = time.monotonic()+180; beat=0
        while p.poll() is None:
            require(time.monotonic()<deadline, 'PS_TIMEOUT')
            if time.monotonic() >= beat:
                print('HEARTBEAT PHASE=CONSUMER_PS51 PID='+str(p.pid)+' ETA=UNKNOWN REASON=NATIVE_BRANCH', flush=True); beat=time.monotonic()+5
            time.sleep(.1)
    return {'pid': p.pid, 'creation_filetime': times[0].value, 'exit_code': p.returncode,
            'stdout': stdout, 'stderr': stderr}


def run_ps(script, args, root, label):
    ps = Path(os.environ['SystemRoot'])/'System32/WindowsPowerShell/v1.0/powershell.exe'
    return run_process([ps,'-NoProfile','-NonInteractive','-ExecutionPolicy','RemoteSigned',
                        '-File',script,*args],root,label)


def python_call(candidate, rel, root, owner_sha, mode):
    """One branch per native process; observed process exit is never fabricated."""
    require(os.name=='nt','WINDOWS_REQUIRED')
    candidate=no_alias(candidate);root=no_alias(root);source=candidate/rel
    require(rel in gate.EXPECTED and rel.endswith('.py'),'CONSUMER_NOT_ALLOWED')
    output,positive,negative,expected=python_operations(candidate,rel,root)
    operation=positive if mode=='POSITIVE' else lambda:denied(negative,expected)
    value,events=trace(source,lambda:scoped(root,owner_sha,output,operation))
    if mode=='POSITIVE':require(type(value) is not int or value==0,'POSITIVE_EXIT_NONZERO')
    R.publish(root/(mode+'_CALL.json'),dict(source_path=rel,source_sha256=R.sha(source.read_bytes()),
        mode=mode,result=value,pid=os.getpid(),creation_filetime=R.native_process(os.getpid())['creation_filetime']))
    with (root/(mode+'_TRACE.jsonl')).open('xb') as stream:
        stream.write(events);stream.flush();os.fsync(stream.fileno())
    return 0 if mode=='POSITIVE' else value['exit_code']


def python_process_operations(candidate,rel,root,owner_sha):
    output=root/'effect.json'
    if rel=='adapter/runtime_locator_orchestrator_entry.py':output=root/'control/state/STATE.json'
    if rel=='recovery/modules/orchestrator.py':output=root/'control/state/STATE_JOURNAL.jsonl'
    before=R.encoded({'exists':False,'path':str(output)})
    command=[sys.executable,'-I','-X','utf8','-B',Path(__file__),
             '--python-call',candidate,rel,root,owner_sha]
    pos=run_process(command+['POSITIVE'],root,'POSITIVE')
    require(pos['exit_code']==0 and output.is_file(),'PYTHON_POSITIVE_PROCESS')
    effect=R.core.secure_read_all(output)
    neg=run_process(command+['NEGATIVE'],root,'NEGATIVE')
    observed=R.read(root/'NEGATIVE_CALL.json')[0]
    require(neg['exit_code']!=0 and observed['result']['rejected'],'PYTHON_NEGATIVE_PROCESS')
    require(neg['exit_code']==observed['result']['exit_code'],'NEGATIVE_EXIT_MISMATCH')
    require(R.core.secure_read_all(output)==effect,'NEGATIVE_CHANGED_POSITIVE_EFFECT')
    return output,before,pos,neg


def powershell_operations(candidate, rel, root, owner_sha):
    source = candidate/rel
    if rel == 'control/60_EFFECTFUL_WRAPPER_RELEASE.ps1':
        temp = Path(os.environ['TEMP'])/('TICKSTORE V002R22 TARGET PROBE '+uuid.uuid4().hex); temp.mkdir()
        output = temp/'child result with spaces.json'
        positive = run_ps(source, ['-RuntimeProbeChild', '-ProbeExitCode', '0', '-ChildResultPath', output], root, 'POSITIVE')
        negative = run_ps(source, ['-ExecuteD4'], root, 'NEGATIVE')
        require(positive['exit_code'] == 0 and negative['exit_code'] != 0 and output.is_file(), 'WRAPPER_BOUNDARY')
        return output, positive, negative, 'RuntimeProbeChild', None
    output = root/'effect.json'; child = root/'child.py'
    engine = candidate/'recovery/engine/tickstore_publisher_recovery_v004_candidate.py'
    code = "import os,json,pathlib,hashlib,ctypes\np=pathlib.Path("+repr(str(engine))+")\nraw=p.read_bytes()\nassert hashlib.sha256(raw).hexdigest().upper()=="+repr(R.sha(engine.read_bytes()))+"\nns={'__name__':'safe_internal_engine','__file__':str(p)}\nexec(compile(raw,str(p),'exec'),ns)\nns['Win32Store']().immutable(pathlib.Path("+repr(str(root))+"),'effect.json',b'{\"scope\":\"PRE_B06_NATIVE_LOADER_JOB\",\"operational_authority\":false}\\n')\n"
    R.publish(root/'CHILD_SOURCE_DESCRIPTION.json', {'scope':'OWNED_ISOLATED_NTFS','engine_sha256':R.sha(engine.read_bytes())})
    with child.open('xb') as f: f.write(code.encode()); f.flush(); os.fsync(f.fileno())
    probe = candidate/'g5proof/PRE_G06_LOADER_PROBE.ps1'
    args = ['-Source',source,'-SourceSha',R.sha(source.read_bytes()),
        '-LabRoot',root,'-OwnerSha',owner_sha,'-Python',sys.executable,'-ChildScript',child,'-ChildSha',R.sha(child.read_bytes())]
    negative = run_ps(probe, args+['-NegativeOnly'], root, 'LOADER_NEGATIVE')
    negative_observed = R.read(root/'LOADER_NEGATIVE_RESULT.json')[0]
    require(negative['exit_code']==2 and not output.exists(), 'LOADER_NEGATIVE_EFFECT_OR_EXIT')
    require(negative_observed['entry_observed'] and negative_observed['internal_exit'] is None
            and 'ANCHOR_HASH_REQUIRED' in negative_observed['negative_error'], 'LOADER_NEGATIVE_NOT_OBSERVED')
    negative['error'] = negative_observed['negative_error']
    result = run_ps(probe, args, root, 'LOADER')
    require(result['exit_code'] == 0 and output.is_file(), 'LOADER_BRANCH_FAILED')
    observed = R.read(root/'LOADER_RESULT.json')[0]
    require(observed['entry_observed'] and observed['internal_exit']==0, 'LOADER_ENTRY_NOT_OBSERVED')
    observed['negative_process'] = {k:v for k,v in negative.items() if k not in ('stdout','stderr')}
    observed['negative_observation'] = negative_observed
    return output, result, negative, observed['entrypoint'], observed


def campaign(candidate, work, evidence, run_id):
    require(os.name == 'nt', 'WINDOWS_REQUIRED')
    candidate = no_alias(candidate); work = no_alias(work); evidence = no_alias(evidence)
    require(R.core.windows_volume_identity(work)['filesystem']=='NTFS', 'NTFS_REQUIRED')
    runner = Path(__file__).read_bytes(); serial=0
    def put(raw, suffix):
        nonlocal serial
        serial+=1; member='%04d_%s'%(serial,suffix); path=evidence/member
        with path.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        require(path.read_bytes()==raw,'EVIDENCE_READBACK')
        return {'member':member,'sha256':R.sha(raw),'bytes':len(raw)}
    dossier={'schema':gate.SCHEMA,'purpose':'ENGINEERING_PRE_B06_NO_OPERATIONAL_ADMISSION',
        'code_manifest_sha256':R.sha((candidate.parent/'RUNTIME_CODE_MANIFEST.json').read_bytes()),
        'production_modified':False,'b06':'NOT_STARTED','b07':'NOT_STARTED','full_started':False,'run_id':run_id,'consumers':[]}
    for number,rel in enumerate(gate.EXPECTED,1):
        print('CONSUMER %d/11 %s'%(number,rel),flush=True)
        root=work/('%02d'%number);root.mkdir();protected=root/'PROTECTED';protected.mkdir()
        (protected/'sentinel.bin').write_bytes(os.urandom(32)); before=inventory(protected)
        owner=R.publish(root/'OWNER.json',{'run_id':run_id,'source_path':rel,'scope':'OWNED_ISOLATED_NTFS'})
        source=candidate/rel; source_sha=R.sha(source.read_bytes());role=gate.GUARD
        if rel.endswith('.py'):
            output,before_effect,positive_meta,negative_meta=python_process_operations(candidate,rel,root,owner['sha256'])
            entrypoint='PYTHON_CALL_TRACE'
            extra={'positive_trace':put((root/'POSITIVE_TRACE.jsonl').read_bytes(),'positive_trace.jsonl'),
                   'negative_trace':put((root/'NEGATIVE_TRACE.jsonl').read_bytes(),'negative_trace.jsonl'),
                   'positive_call':put((root/'POSITIVE_CALL.json').read_bytes(),'positive_call.json'),
                   'negative_call':put((root/'NEGATIVE_CALL.json').read_bytes(),'negative_call.json'),
                   'negative_stderr':put(negative_meta['stderr'].read_bytes(),'negative_stderr.bin')}
        else:
            before_effect=R.encoded({'exists':False})
            output,positive_meta,negative_meta,entrypoint,detail=powershell_operations(candidate,rel,root,owner['sha256'])
            extra={'positive_stdout':put(positive_meta['stdout'].read_bytes(),'stdout.bin'),
                   'positive_stderr':put(positive_meta['stderr'].read_bytes(),'stderr.bin'),
                   'negative_stdout':put(negative_meta['stdout'].read_bytes(),'negative_stdout.bin'),
                   'negative_stderr':put(negative_meta['stderr'].read_bytes(),'negative_stderr.bin'),'native_detail':detail}
        after_effect=R.core.secure_read_all(output)
        require(R.sha(before_effect)!=R.sha(after_effect),'NO_REAL_TRANSITION')
        alias=root/'ALIAS';junction(alias,protected)
        try:
            rp=denied(lambda:scoped(root,owner['sha256'],alias/'forbidden',lambda:(_ for _ in ()).throw(RuntimeError('GUARD_FAILED'))))
            require('GUARD_FAILED' not in rp['error'],'REPARSE_GUARD_BYPASSED')
        finally:os.rmdir(alias)
        fo=denied(lambda:scoped(root,'0'*64,output,lambda:(_ for _ in ()).throw(RuntimeError('GUARD_FAILED'))),'FOREIGN_OWNER')
        after=inventory(protected);require(before==after,'PROTECTED_SENTINEL_CHANGED')
        bref=put(before,'protected_before.json');aref=put(after,'protected_after.json')
        controls={'schema':'TICKSTORE_PRE_B06_CONTROLS_V001','source_path':rel,
            'protected_inventory_before':bref,'protected_inventory_after':aref,
            'before_protected_roots_sha256':R.sha(before),'after_protected_roots_sha256':R.sha(after),
            'reparse_rejected':True,'foreign_owner_rejected':True,
            'guard_layer':'OWNED_ENGINEERING_CALL_BOUNDARY','scope':'PROTECTED_LAB_SENTINELS_NOT_PRODUCTION_INVENTORY',
            'reparse_observation':rp,'foreign_owner_observation':fo}
        witness={'schema':'TICKSTORE_PRE_B06_NATIVE_EXECUTION_WITNESS_V001','run_id':run_id,'source_path':rel,
            'source_sha256':source_sha,'native_windows':True,'scope':'OWNED_ISOLATED_NTFS','production_modified':False,
            'pid':negative_meta['pid'],'creation_filetime':negative_meta['creation_filetime'],'invoked':True,'entrypoint_observed':True,
            'language':'POWERSHELL_5_1' if rel.endswith('.ps1') else 'PYTHON','runner_sha256':R.sha(runner),
            'exit_code':negative_meta['exit_code'],'protected_effects':False,'isolated_effects':[],
            'failure_before_protected_effect':True,'entrypoint':entrypoint,'observation':extra}
        if rel in ('recovery/modules/orchestrator.py', 'control/D4_ROOTS_EVIDENCE.py'):
            # These safe public operations have their own direct positive
            # witness; no protected-path rejection is fabricated for them.
            role=gate.SAFE
            witness.update(pid=positive_meta['pid'],creation_filetime=positive_meta['creation_filetime'],exit_code=0,
                failure_before_protected_effect=False,
                isolated_effects=[{'before_sha256':R.sha(before_effect),'after_sha256':R.sha(after_effect),
                                   'readback':put(after_effect,'safe_effect.bin')}])
        before_ref=put(before_effect,'transition_before.bin');after_ref=put(after_effect,'transition_after.bin')
        internal={'schema':'TICKSTORE_PRE_B06_INTERNAL_BRANCH_V001','source_path':rel,'source_sha256':source_sha,
            'run_id':run_id,'native_windows':True,'scope':'OWNED_ISOLATED_NTFS','runner_sha256':R.sha(runner),
            'source_entrypoint_reached':True,'guarded_transition_exercised':True,'production_modified':False,'protected_effects':False,
            'pid':positive_meta['pid'],'creation_filetime':positive_meta['creation_filetime'],'exit_code':positive_meta['exit_code'],
            'isolated_transitions':[{'before':before_ref,'after':after_ref,'before_sha256':R.sha(before_effect),'after_sha256':R.sha(after_effect)}]}
        catalog=R.read(candidate/'g5proof/PRE_G06_CONSUMER_REVIEW.json')[0]
        reviewed=catalog['consumers'][rel]
        require(reviewed['source_sha256']==source_sha and reviewed['safe_positive'] and reviewed['negative_guard'],
                'SOURCE_REVIEW_NOT_BOUND')
        review={'schema':'TICKSTORE_PRE_B06_IMPLEMENTATION_REVIEW_V001','source_path':rel,'source_sha256':source_sha,
            'implementation_reviewed':True,'required_branches_implemented':True,'remaining_implementation_blockers':[],
            'qualification_scope':'SAFE_INTERNAL_TRANSITION_AND_PROTECTED_REJECTION_NO_OPERATIONAL_APPROVAL',
            'fixture_locator_is_not_vss_attestation':True,'reviewed_branches':reviewed,
            'source_review_sha256':R.sha((candidate/'g5proof/PRE_G06_CONSUMER_REVIEW.json').read_bytes())}
        dossier['consumers'].append({'source_path':rel,'source_sha256':source_sha,'role':role,
            'execution_witness':put(R.encoded(witness),'execution.json'),'runner_source':put(runner,'runner.py'),
            'negative_controls':put(R.encoded(controls),'controls.json'),'internal_branch_execution':put(R.encoded(internal),'internal.json'),
            'code_path_review':put(R.encoded(review),'review.json')})
        require(R.sha(source.read_bytes())==source_sha,'SOURCE_CHANGED')
    checked=gate.verify_dossier(dossier,candidate,evidence,native_required=True)
    R.publish(evidence/'ELEVEN_CONSUMERS.json',dossier);R.publish(evidence/'ELEVEN_CONSUMERS_CHECK.json',checked)
    return dossier,checked


if __name__=='__main__':
    require(len(sys.argv)==7 and sys.argv[1]=='--python-call','INTERNAL_INVOCATION_REQUIRED')
    raise SystemExit(python_call(Path(sys.argv[2]),sys.argv[3],Path(sys.argv[4]),sys.argv[5],sys.argv[6]))
