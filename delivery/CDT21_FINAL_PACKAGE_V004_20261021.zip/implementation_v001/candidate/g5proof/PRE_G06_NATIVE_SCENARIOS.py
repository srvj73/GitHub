"""Real Windows G3/G6 experiments on disposable, owned NTFS fixtures.

No D4/G2 receipt is invented: ENGINEERING_PREDECESSOR is explicitly a lab
declaration. The actual G3 dispatcher, STATE guard, journal writer, MULTIWORK
pipeline and installed G6 are used. Only the deterministic data plan/ledger
provider and the non-operational admission boundary differ from production.
Pause probes stop at real flushed journals; the supervisor kills real owned
processes. No journal, checkpoint, lock or output is edited to obtain recovery.
"""
from __future__ import annotations

import contextlib
import copy
import hashlib
import json
import multiprocessing as mp
import os
import re
from pathlib import Path
import sys
import time
import types
import uuid

ROOT = Path(__file__).resolve().parents[1]
for folder in ('full', 'control', 'adapter', 'g5proof'):
    sys.path.insert(0, str(ROOT/folder))
import FULL_CRASH_RECOVERY as R
import FULL_G3_INTERRUPTION as interruption
import FULL_LIFECYCLE as lifecycle
import FULL_STAGE_CONTINUATION as continuation
from FULL_PROCESS_CONTROL import ProcessJob, StopEvent
import runtime_locator_orchestrator_entry as entry
import runtime_locator_adapter as adapter
import G5_MULTIWORK_SCENARIOS as fixtures


def require(ok, why):
    if not ok:
        raise RuntimeError('PRE_G06_LAB_' + why)


def no_alias(path):
    path = Path(os.path.abspath(path))
    R.core.strict_directory(path)
    return path


def inside(path, root):
    path = Path(os.path.abspath(path)); root = no_alias(root)
    require(path.is_relative_to(root) and path != root, 'OUTSIDE_OWNED_ROOT')
    R.core.assert_no_link_chain(path, allow_missing_tail=True)
    return path


def file_map(root, suffix):
    return {p.relative_to(root).as_posix(): R.sha(R.core.secure_read_all(p))
            for p in sorted(Path(root).rglob('*' + suffix))}


def lab_history(raw, state):
    continuation.validate_journal(raw)
    rows = [json.loads(line) for line in raw.splitlines()]
    require(rows[0].get('node') == 'ENGINEERING_PREDECESSOR'
            and rows[0].get('phase') == 'FINISHED'
            and rows[0].get('scope') == 'OWNED_ISOLATED_NTFS_PRE_B06', 'PREDECESSOR_MISSING')
    require(not set(state.get('completed', [])).intersection({'D4', 'G2'}), 'OPERATIONAL_PREDECESSOR_FORBIDDEN')
    opened = None
    for row in rows[1:]:
        require(row.get('node') == 'G3', 'UNEXPECTED_STAGE')
        if row.get('phase') == 'STARTED':
            require(opened is None, 'UNCLOSED_STARTED'); opened = row
        else:
            require(opened is not None and row.get('phase') == 'FINISHED', 'UNPAIRED_FINISH')
            opened = None
    require(opened is None, 'UNCLOSED_STARTED')


class LabBoundary:
    nodes = ('G3',)

    def validate(self, state):
        require(state.get('schema') == 'TICKSTORE_ORCH_STATE_V001'
                and state.get('status') in ('PASS', 'FAIL', 'SAFE_STOP')
                and state.get('next_node') == 'G3' and state.get('completed') == [], 'STATE_BOUNDARY')

    def transition(self, before, after):
        self.validate(before)
        require(after.get('completed') in ([], ['G3']) and after.get('next_node') ==
                ('G4' if after.get('completed') == ['G3'] else 'G3'), 'STATE_ADVANCE')
        require(after.get('created_at') == before.get('created_at') and after.get('schema') == before.get('schema'), 'STATE_IDENTITY')


class LabAdmission:
    def __init__(self, fx, run_id, code_sha, lab_root):
        self.root = no_alias(lab_root)
        for key in ('source', 'dest', 'scratch'):
            no_alias(inside(fx[key], self.root))
        b = R.core.full_gate_bindings(fx['source'], fx['dest'], fx['scratch'], fx['ids'], fx['contract'])
        self.bindings = b
        self.instance = dict(scope='OWNED_ISOLATED_NTFS_PRE_B06', operational_authority=False,
            run_id=run_id, bindings={k: v for k, v in b.items() if k not in ('schema', 'authorized')},
            resources={'max_workers': 4, 'ram_target_percent': 60}, ledger_path=str(self.root/'FIXTURE_LEDGER_DECLARATION.json'))
        self.descriptor = {'instance_sha256': R.sha(R.encoded(self.instance)), 'code_manifest_sha256': code_sha}
        self.source_hashes = file_map(fx['source'], '.csv')

    def read(self, path, expected=None):
        path = inside(path, self.root)
        raw = R.core.secure_read_all(path)
        require(expected is None or R.sha(raw) == expected, 'EVIDENCE_HASH')
        return raw

    def revalidate(self):
        no_alias(self.root)
        for key in ('source', 'dest', 'scratch'):
            no_alias(inside(self.instance['bindings'][key + '_root'], self.root))

    def validate_full(self, bindings, workers, maximum, ram):
        self.revalidate()
        require(bindings == self.bindings and 1 <= workers <= maximum == 4 and ram == 60, 'ENGINE_BINDING')

    def authorize_engineering_probe(self, probe, source, dest, scratch):
        self.revalidate()
        require(probe.lab_root == str(self.root) and probe.run_id == self.instance['run_id'], 'PROBE_OWNER')
        for p in (source, dest, scratch):
            no_alias(inside(p, self.root))
        inside(probe.output, self.root)


class Barrier:
    def __init__(self, root, run_id, target_day, target_point, output):
        self.lab_root = str(root); self.run_id = run_id
        self.day = target_day; self.point = target_point; self.output = str(output)
        self.current_day = None; self.paths = []
        self.required_commit = None
        # for_day returns a shallow view for each flushed row group. Share the
        # one-shot state between those views, within this worker only. Spawned
        # workers get independent state and cannot adopt another worker's file.
        self._released_gap = {}

    def for_day(self, day, paths):
        bound = copy.copy(self); bound.current_day = day; bound.paths = [str(p) for p in paths]
        return bound

    def hit(self, point):
        if point != self.point or self.current_day != self.day:
            return
        if self.required_commit is not None:
            commit=inside(self.required_commit,self.lab_root)
            deadline=time.monotonic()+120
            # Make the preexisting-COMMITTED assertion deterministic while the
            # publisher can finish the earlier small day independently.
            while not commit.is_file():
                require(time.monotonic()<deadline,'PREEXISTING_COMMIT_TIMEOUT')
                time.sleep(.05)
            R.read(commit)
        identity = R.native_process(os.getpid())
        binding = (self.lab_root, self.run_id, self.day, self.point, self.output,
                   tuple(self.paths), self.required_commit,
                   identity['pid'], identity['creation_filetime'])
        if self._released_gap:
            require(self._released_gap['binding'] == binding, 'BARRIER_REPLAY_IDENTITY')
            raw = R.core.secure_read_all(inside(self.output, self.lab_root))
            require(R.sha(raw) == self._released_gap['sha256'], 'BARRIER_REPLAY_DRIFT')
            # SAFE_STOP is propagated asynchronously by the coordinator. A
            # subsequent durable group must not republish the first gap.
            return
        observations = []
        for item in self.paths:
            path = inside(item, self.lab_root)
            if path.is_file():
                raw = R.core.secure_read_all(path)
                observations.append({'path': str(path), 'bytes': len(raw), 'sha256': R.sha(raw)})
        R.publish(inside(self.output, self.lab_root), dict(schema='TICKSTORE_NATIVE_DURABLE_GAP_V001',
             run_id=self.run_id, point=point, date_key=self.day, process=identity,
             physical_files=observations, paused_after_real_flush=True))
        published = R.core.secure_read_all(inside(self.output, self.lab_root))
        # Supervisor observes this flushed file and kills/stops this owned tree.
        release = Path(self.output + '.release')
        deadline = time.monotonic() + 120
        while not release.exists():
            require(time.monotonic() < deadline, 'BARRIER_TIMEOUT')
            time.sleep(.05)
        require(R.core.secure_read_all(inside(self.output, self.lab_root)) == published,
                'BARRIER_RELEASE_DRIFT')
        self._released_gap.update(binding=binding, sha256=R.sha(published))


def own_census(scratch):
    alive = []
    for path in sorted(Path(scratch).rglob('CHILD_*.json')):
        identity = R.read(path)[0]['identity']; now = R.native_process(identity['pid'])
        if now.get('state') == 'LIVE' and now.get('creation_filetime') == identity['creation_filetime']:
            alive.append(identity)
    return {'known_recovery_supervisor_or_workers': len(alive), 'identities': alive}


def child(candidate, fixture_file, lab_root, run_id, workers, output, log, probe=None):
    """Target admitted into supervisor Job before any fixture or stage effects."""
    with open(log, 'x', encoding='utf8', buffering=1) as stream, contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
        result = {'status': 'BLOCKED', 'native_windows': os.name == 'nt'}
        release = lambda: None
        saved = []
        try:
            require(os.name == 'nt', 'WINDOWS_REQUIRED')
            core, multi, r9 = fixtures.load(candidate)
            fx = json.loads(Path(fixture_file).read_bytes())
            for key in ('root', 'source', 'dest', 'scratch'):
                fx[key] = Path(fx[key])
            manifest = Path(candidate).parent/'RUNTIME_CODE_MANIFEST.json'
            admission = LabAdmission(fx, run_id, R.sha(manifest.read_bytes()), lab_root)
            seams = {'full_release_materials': lambda base: (fx['contract'], fx['cert'], fx['ids']),
                     'load_ledgers': lambda path: (fx['days'], fx['months'], r9.LEDGER_SHA),
                     'validate_full_plan': lambda days, months, ledger, contract: days}
            for name, value in seams.items():
                saved.append((name, getattr(core, name))); setattr(core, name, value)
            ns = continuation.load((Path(candidate)/'recovery/modules/orchestrator.py').read_bytes(),
                                   Path(candidate)/'recovery/modules/orchestrator.py')
            control = inside(Path(fx['root'])/'control', lab_root)
            if not control.exists():
                control.mkdir()
                initial = ns['State'](control)
                initial.d = dict(schema='TICKSTORE_ORCH_STATE_V001', next_node='G3', completed=[], status='PASS',
                                 created_at=ns['now'](), scope='OWNED_ISOLATED_NTFS_PRE_B06')
                ns['atomj'](initial.sp, initial.d)
                initial.log('ENGINEERING_PREDECESSOR', 'FINISHED', scope='OWNED_ISOLATED_NTFS_PRE_B06',
                            operational_authority=False, instance_sha256=admission.descriptor['instance_sha256'])
            boundary = LabBoundary()
            entry.guard_frozen_state_reads(ns, control/'state/STATE.json', state_validator=boundary.validate,
                                          transition_validator=boundary.transition)
            release = ns['_TICKSTORE_D4_ENTRY_RELEASE_STATE_BOUNDARY']
            state = ns['State'](control)
            attempt_id = uuid.uuid4().hex; rd = state.runs/attempt_id; rd.mkdir()
            def fail(why): raise RuntimeError(why)
            ns['immutable_receipt'] = adapter.make_no_clobber_receipt_writer(fail)
            o = types.SimpleNamespace(st=state, id=attempt_id, rd=rd,
                    cfg={'production_dest_root': str(fx['dest'])},
                    eng=types.SimpleNamespace(recovery_process_census=lambda: own_census(fx['scratch'])),
                    runnode=lambda n: fail('UNEXPECTED_OPERATIONAL_NODE:' + n))
            if interruption.needs_reconciliation(state.jp.read_bytes(), state.d):
                result['interruption'] = interruption.reconcile(o, ns, admission, history_validator=lab_history)
            lab_history(state.jp.read_bytes(), state.d)
            lifecycle.install(o, ns, admission, workers, engineering_probe=probe)
            code = continuation.execute_nodes(o, ns, boundary, admission.revalidate)
            result.update(exit_code=code, status='SAFE_STOP' if code == 130 else 'PASS')
            if code == 0:
                result['g6'] = o.runnode('G6')
            result.update(instance_sha256=admission.descriptor['instance_sha256'], code_manifest_sha256=admission.descriptor['code_manifest_sha256'],
                          state_path=str(state.sp), journal_path=str(state.jp), attempt_dir=str(rd), run_id=run_id,
                          source_hashes_unchanged=file_map(fx['source'], '.csv') == admission.source_hashes,
                          own_census=own_census(fx['scratch']))
        except BaseException as exc:
            import traceback
            result.update(error=type(exc).__name__ + ':' + str(exc), traceback=traceback.format_exc())
        finally:
            release()
            for name, value in saved:
                setattr(R.core, name, value)
            R.publish(output, result)


def wait_process(process, job, timeout, phase, *, until=None):
    deadline = time.monotonic() + timeout; heartbeat = 0
    while True:
        if until is not None and Path(until).is_file():
            return
        if not process.is_alive():
            process.join(); require(until is None, 'CHILD_EXIT_BEFORE_GAP:' + str(process.exitcode)); return
        require(time.monotonic() < deadline, 'TIMEOUT:' + phase)
        if time.monotonic() >= heartbeat:
            sample = job.memory_snapshot()
            print('HEARTBEAT PHASE=' + phase + ' OWNED_PIDS=' + str(len(sample['processes']) - 1)
                  + ' ETA=UNKNOWN REASON=DATA_DEPENDENT_NATIVE_QUALIFICATION', flush=True)
            heartbeat = time.monotonic() + 5
        time.sleep(.1)


def prepare(candidate, root, plan):
    _, _, r9 = fixtures.load(candidate)
    fx = fixtures.make_fixture(r9, root, plan)
    # The fixture changes only dataset dimensions/ledger. Core and reference
    # identities are physical source hashes, never fictional release IDs.
    fx['ids'] = {'runner_sha256': R.sha((Path(candidate)/'full/tickstore_serial_runner.py').read_bytes()),
                 'reference_sha256': R.sha((Path(candidate)/'full/pts2g_reference.py').read_bytes()),
                 'spec_sha256': R.sha(R.encoded(fx['contract']))}
    serial = {k: str(v) if isinstance(v, Path) else v for k, v in fx.items()}
    path = root/'FIXTURE.json'; R.publish(path, serial)
    return fx, path


def bounded_owned_death_consensus(observed, job_live, *, probe=R.native_process,
                                 monotonic=time.monotonic, snooze=time.sleep, seconds=30):
    """Independent process-handle death + Job-object quiescence, both required.

    The Job process-ID list can become empty while a terminating process handle
    is not signaled yet. A job census alone is never evidence of death. No PID
    is killed by this check; live same-creation identities remain blockers.
    """
    require(0 < seconds <= 120, 'DEATH_WATCHDOG_BUDGET')
    require(isinstance(observed,list) and len(observed)>0, 'DEATH_OBSERVATIONS_ABSENT')
    keys=[]
    for p in observed:
        require(type(p.get('pid')) is int and p['pid']>0 and
                type(p.get('creation_filetime')) is int and p['creation_filetime']>0,
                'DEATH_IDENTITY_MISSING')
        keys.append((p['pid'],p['creation_filetime']))
    require(len(keys)==len(set(keys)), 'DEATH_IDENTITY_DUPLICATE')
    deadline=monotonic()+seconds
    while True:
        pending=[]
        for p in observed:
            now=probe(p['pid'])
            require(now.get('pid')==p['pid'], 'DEATH_PID_MISMATCH')
            state=now.get('state')
            require(state in ('EXITED','ABSENT','LIVE'), 'DEATH_STATE_INVALID')
            if state=='ABSENT':continue
            require(type(now.get('creation_filetime')) is int and
                    now['creation_filetime']>0, 'DEATH_CREATION_MISSING')
            if (now['creation_filetime']==p['creation_filetime'] and state=='LIVE'):
                pending.append((p['pid'],p['creation_filetime']))
        # Do not trust only one source; identity checks and job census are both
        # needed. Process creation times prevent PID-reuse false positives.
        live=job_live()
        require(isinstance(live,list), 'DEATH_JOB_CENSUS_SHAPE')
        if not pending and not live:
            # End with the actual non-mocked durable recovery predicate. It
            # fails closed if any identity unexpectedly becomes LIVE again.
            return [R.dead(p,probe=probe) for p in observed]
        require(monotonic()<deadline,
                'OWNED_ORPHANS_AFTER_COORDINATOR_DEATH:identity_pids='+
                ','.join(str(p[0]) for p in pending)+':job_live='+
                ','.join(str(p.get('pid','INVALID')) for p in live))
        snooze(.1)


def registered_process_identities(fx_file, run_id):
    """Do not omit descendants that escaped or vanished from a Job census."""
    fx=R.read(fx_file)[0]
    scratch=Path(fx['scratch'])/'RUN_INSTANCES'/run_id/'RECOVERY_ATTEMPTS'
    require(scratch.is_dir(), 'OWNED_ATTEMPT_RECORDS_MISSING')
    attempts=[p for p in scratch.iterdir() if p.is_dir()]
    require(len(attempts)==1, 'OWNED_ATTEMPT_CARDINALITY')
    attempt=attempts[0]
    owner,raw=R.read(attempt/'OWNER.json')
    require(owner.get('attempt_id')==attempt.name and owner.get('schema')==
            'TICKSTORE_MULTIWORK_ATTEMPT_OWNER_V001','OWNED_ATTEMPT_BINDING')
    rows=[owner['owner']]
    for path in sorted(attempt.glob('CHILD_*.json')):
        obj,_=R.read(path)
        require(obj.get('schema')=='TICKSTORE_MULTIWORK_CHILD_OWNER_V001'
                and obj.get('owner_sha256')==R.sha(raw), 'OWNED_CHILD_BINDING')
        p=obj['identity']
        require(path.name==f"CHILD_{p['pid']}_{p['creation_filetime']}.json",
                'OWNED_CHILD_FILENAME')
        rows.append(p)
    require(len(rows)>=2, 'OWNED_ATTEMPT_CHILDREN_MISSING')
    return rows


def supervise(candidate, lab_root, fx_file, run_id, workers, label, probe=None, stop=False, cancel=False):
    ctx = mp.get_context('spawn'); job = ProcessJob()
    output = Path(lab_root)/(label + '.json'); log = Path(lab_root)/(label + '.log')
    proc = None; observed = []
    try:
        proc = job.start(ctx, child, args=(str(candidate), str(fx_file), str(lab_root), run_id,
                           workers, str(output), str(log), probe), name='PRE-G06-' + label)
        if probe is not None:
            wait_process(proc, job, 1800, label, until=probe.output)
            gap = R.read(probe.output)[0]
            observed = [p for p in job.memory_snapshot()['processes'] if p['pid'] != os.getpid()]
            require(any(p['pid'] == gap['process']['pid'] and p['creation_filetime'] == gap['process']['creation_filetime']
                        for p in observed), 'GAP_PROCESS_NOT_OWNED')
            # Ledger is an independent identity source. The job-only census
            # cannot silently omit a registered worker during termination.
            ledger = registered_process_identities(fx_file,run_id)
            mapped={(p['pid'],p['creation_filetime']):p for p in observed}
            for p in ledger:
                key=(p['pid'],p['creation_filetime'])
                mapped.setdefault(key,dict(p))
            observed=list(mapped.values())
            if stop:
                event = StopEvent(run_id, request=True); event.close()
                R.publish(probe.output + '.release', {'action': 'COOPERATIVE_STOP_REQUESTED'})
            else:
                # Kill coordinator alone. Its own KILL_ON_JOB_CLOSE must drain
                # publisher and workers; the outer job remains held for census.
                owner = R.native_process(proc.pid)
                if cancel:
                    job.close()
                else:
                    proc.terminate()
                proc.join(30)
                require(not proc.is_alive(), 'COORDINATOR_DID_NOT_DIE')
                def job_live():
                    return [] if cancel else [p for p in job.memory_snapshot()['processes']
                                              if p['pid']!=os.getpid()]
                # Wait for *both* OS process handles to signal and the owned
                # Job to become empty. A formerly missing job member is not
                # authority to call a recorded child dead.
                deaths = bounded_owned_death_consensus(observed,job_live,seconds=30)
                record = dict(schema='TICKSTORE_NATIVE_PROCESS_DEATH_V001',
                              action='CANCEL_OWNED_JOB_TREE' if cancel else 'TERMINATE_OWNED_COORDINATOR',
                              owner=owner, exit_code=proc.exitcode, gap=gap, before_census=observed,
                              after_census=[], observations=deaths, physical_powerloss='NOT_TESTED_PHYSICAL_POWERLOSS')
                R.publish(Path(lab_root)/(label + '_DEATH.json'), record)
                return record
        wait_process(proc, job, 1800, label)
        require(proc.exitcode == 0 and output.is_file(), 'CHILD_PROCESS_FAILED:' + str(proc.exitcode))
        result = R.read(output)[0]
        require(result['status'] == ('SAFE_STOP' if stop else 'PASS'), 'CHILD_RESULT:' + str(result.get('error')))
        require(result['source_hashes_unchanged'] and result['own_census']['known_recovery_supervisor_or_workers'] == 0,
                'SOURCE_OR_PROCESS_POSTCONDITION')
        lograw=R.core.secure_read_all(log)
        match=re.findall(rb'(?m)^WORKERS_EFFECTIVE=(\d+)\r?$',lograw)
        require(len(match)==1,'WORKER_COUNT_NOT_OBSERVED')
        result['workers_effective']=int(match[0]);result['workers_requested']=workers
        result['native_log_sha256']=R.sha(lograw)
        return result
    finally:
        job.close()
        if proc is not None:
            proc.join(30)
            require(not proc.is_alive(), 'SUPERVISOR_CLEANUP_FAILED')


def negative_controls(candidate, root):
    """Real native owner, live lease and immutable lock negatives; no mocked census."""
    import tickstore_full_multiwork as multi
    rows=[]
    def reject(name, call, expected):
        try: call()
        except Exception as exc:
            require(expected in str(exc), 'WRONG_NEGATIVE:'+name+':'+str(exc))
            rows.append({'name':name,'error':str(exc),'pid':os.getpid(),
                         'creation_filetime':R.native_process(os.getpid())['creation_filetime']})
        else: raise RuntimeError('NEGATIVE_ACCEPTED:'+name)
    fx, _ = prepare(candidate,root/'NEGATIVES',[('20240110',1500)])
    admission=LabAdmission(fx,uuid.uuid4().hex,R.sha((candidate.parent/'RUNTIME_CODE_MANIFEST.json').read_bytes()),root)
    lease=multi.FullProcessLease(fx['dest'])
    try:
        reject('live_lease_overlap',lambda:multi.FullProcessLease(fx['dest']),'LIVE_SUPERVISOR')
        scratch=multi.instance_scratch(fx['scratch'],admission,admission.bindings)
        attempt=R.Attempt(admission,fx['dest'],scratch,lease.identity)
        reject('false_owner_death',lambda:R.inspect_attempt(attempt.path,attempt.expected),'OWNER_OR_CHILD_LIVE')
        foreign=dict(attempt.expected,instance_sha256='F'*64)
        reject('foreign_instance',lambda:R.inspect_attempt(attempt.path,foreign),'FOREIGN_OWNER')
        attempt.close('ENGINEERING_NEGATIVE_DONE')
        lock=fx['dest']/'TICKSTORE_WRITER.lock'
        raw=R.encoded({'pid':os.getpid(),'scope':'FOREIGN_UNBOUND_NEGATIVE_FIXTURE'})
        with lock.open('xb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
        reject('foreign_lock',lambda:R.Attempt(admission,fx['dest'],scratch,lease.identity),'FOREIGN_OR_UNBOUND_LOCK')
        require(R.core.secure_read_all(lock)==raw,'NEGATIVE_LOCK_CHANGED')
        # Preserve the deliberately foreign lock in the evidence. No unlink.
    finally:lease.close()
    reject('outside_run_owned',lambda:inside(root.parent/'outside',root),'OUTSIDE_OWNED_ROOT')
    R.publish(root/'NATIVE_NEGATIVE_CONTROLS.json',{'native_windows':True,'checks':rows,
              'foreign_lock_preserved':True,'production_modified':False})
    return rows


def campaign(candidate, lab_root):
    require(os.name == 'nt', 'WINDOWS_REQUIRED')
    candidate = no_alias(candidate); root = no_alias(lab_root)
    require('D:' != root.drive.upper(), 'PRODUCTION_DRIVE_FORBIDDEN')
    require(root.is_relative_to(Path(os.environ['LOCALAPPDATA']).absolute()), 'LOCAL_OWNED_ROOT_REQUIRED')
    negatives=negative_controls(candidate,root)
    plan = [('20231211', 1500), ('20240110', 530000), ('20240212', 1500)]
    control, cf = prepare(candidate, root/'CONTROL', plan)
    baseline = supervise(candidate, root, cf, uuid.uuid4().hex, '1', 'CONTROL')
    expected = fixtures.containers(control['dest'])
    results = {'baseline': baseline, 'native_negatives':negatives, 'scenarios': []}
    for label, point, stopping, workers, cancel in (
            ('GROUP_CRASH', 'AFTER_GROUP_JOURNAL', False, 'AUTO',False),
            ('COMMIT_CRASH', 'AFTER_COMMIT_RENAME_BEFORE_MANIFEST', False, '2',False),
            ('CANCEL_TREE', 'AFTER_GROUP_JOURNAL', False, '2',True),
            ('SAFE_STOP', 'AFTER_GROUP_JOURNAL', True, '2',False)):
        fx, fp = prepare(candidate, root/label, plan); run = uuid.uuid4().hex
        barrier = Barrier(root, run, '20240110', point, root/(label + '_GAP.json'))
        barrier.required_commit=str(fx['dest']/'WIN@N/2023_12/20231211.commit.json')
        interruption_result = supervise(candidate, root, fp, run, '1', label + '_FIRST', barrier, stopping, cancel)
        committed = file_map(fx['dest'], '.commit.json')
        sections = []
        # Preserve actual durable compressed payloads, not a reconstructed row
        # count. The frozen finalizer changes the index, not these payload bytes.
        journals = list(fx['scratch'].rglob('20240110.journal.json')) + list(fx['dest'].rglob('20240110.journal.json'))
        for journal in journals:
            body = R.read(journal)[0]
            partial = journal.with_name('20240110.pts2g.partial')
            container = journal.with_name('20240110.pts2g')
            data_file = partial if partial.is_file() else container
            with R.core.secure_open_existing(data_file, 'rb') as stream:
                for group in body['completed_groups']:
                    for section in group['sections']:
                        stream.seek(section['payload_offset'])
                        raw = stream.read(section['stored_len'])
                        require(len(raw) == section['stored_len'], 'PARTIAL_SECTION_TRUNCATED')
                        sections.append({'offset': section['payload_offset'], 'bytes': len(raw), 'sha256': R.sha(raw)})
        require(bool(sections), 'NO_DURABLE_PARTIAL_OBSERVED')
        result = supervise(candidate, root, fp, run, workers, label + '_RESUME')
        require(result['workers_effective']>1,'MULTIWORK_NOT_EXERCISED')
        after = file_map(fx['dest'], '.commit.json')
        require(all(after.get(k) == v for k, v in committed.items()), 'COMMITTED_BYTES_CHANGED')
        require(fixtures.containers(fx['dest']) == expected, 'WORKER_EQUIVALENCE')
        require(result['g6']['g3_ownership_closed'] and
                result['g6']['g3_dead_predecessors_verified'] == (0 if stopping else 1), 'G6_CAUSAL_PREDECESSOR')
        require(not (fx['dest']/'TICKSTORE_WRITER.lock').exists(), 'FINAL_LOCK_REMAINS')
        final = fx['dest']/'WIN@N/2024_01/20240110.pts2g'
        with R.core.secure_open_existing(final, 'rb') as stream:
            for section in sections:
                stream.seek(section['offset'])
                require(R.sha(stream.read(section['bytes'])) == section['sha256'], 'DURABLE_PARTIAL_CHANGED')
        results['scenarios'].append({'name': label, 'run_id': run, 'interruption': interruption_result,
             'resumed': result, 'committed_before': committed, 'committed_after': after,
             'published_containers': expected, 'worker_equivalence': True, 'durable_sections_preserved': sections})
    R.publish(root/'G3_G6_NATIVE_SCENARIOS.json', dict(schema='CDT19_G3_G6_NATIVE_SCENARIOS_V001', status='PASS',
        native_windows=True, operational_authority=False, production_modified=False,
        physical_powerloss='NOT_TESTED_PHYSICAL_POWERLOSS', results=results))
    return results
