"""Project one actual G3/G6 run into distinct scoped G5 evidence roles.

No experiment is replayed to populate another label. Every role names the
original run, physical artifacts and its specific assertions. These V002
engineering receipts cannot substitute for physical power-loss evidence or
the older operational qualification receipt contract.
"""
import json
import os
from pathlib import Path
import platform
import shutil
import sys
import uuid

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'full'))
import FULL_CRASH_RECOVERY as R


def validate(summary):
    R.require(summary.get('schema')=='CDT19_G3_G6_NATIVE_SCENARIOS_V001'
              and summary.get('status')=='PASS' and summary.get('native_windows') is True
              and summary.get('operational_authority') is False
              and summary.get('production_modified') is False,'NATIVE_SCENARIO_REQUIRED')
    results=summary['results'];rows=results['scenarios']
    R.require(len(rows)==4 and {r['name'] for r in rows}=={'GROUP_CRASH','COMMIT_CRASH','CANCEL_TREE','SAFE_STOP'},'NATIVE_SCENARIO_SET')
    R.require(results['baseline']['status']=='PASS','UNINTERRUPTED_CONTROL')
    for row in rows:
        resumed=row['resumed'];stopped=row['name']=='SAFE_STOP'
        R.require(resumed['status']=='PASS' and resumed['run_id']==row['run_id']
                  and resumed['source_hashes_unchanged'] and resumed['own_census']['known_recovery_supervisor_or_workers']==0,
                  'NATIVE_RESUME_POSTCONDITION')
        R.require(resumed['g6']['g3_ownership_closed'] is True
                  and resumed['g6']['g3_dead_predecessors_verified']==(0 if stopped else 1), 'NATIVE_G6_PREDECESSORS')
        R.require(type(resumed.get('workers_effective')) is int and resumed['workers_effective']>1,
                  'NATIVE_MULTIWORK_REQUIRED')
        R.require(row['worker_equivalence'] is True and row['published_containers']
                  and row['durable_sections_preserved'] and row['committed_before']
                  and all(row['committed_after'].get(k)==v for k,v in row['committed_before'].items()),'NATIVE_DATA_CONTINUITY')
        event=row['interruption']
        if stopped:R.require(event['status']=='SAFE_STOP','NATIVE_SAFE_STOP')
        else:
            # A forced JobObject close may legitimately yield exit code 0 on
            # Windows.  Abrupt coordinator termination must remain nonzero;
            # both paths still require the exact before/after owned-process
            # census and independently confirmed PID+creation-time deaths.
            action=event.get('action')
            exit_code=event.get('exit_code')
            R.require(type(exit_code) is int and
                      ((row['name']=='CANCEL_TREE' and action=='CANCEL_OWNED_JOB_TREE') or
                       (row['name']!='CANCEL_TREE' and action=='TERMINATE_OWNED_COORDINATOR' and exit_code!=0))
                      and event['before_census'] and event['after_census']==[]
                      and event['gap']['paused_after_real_flush'] is True,'NATIVE_DELIBERATE_DEATH')
            expected={(p['pid'],p['creation_filetime']) for p in event['before_census']}
            actual={(p['pid'],p['creation_filetime']) for p in event['observations']}
            R.require(len(expected)==len(event['before_census']) and expected==actual
                      and len(actual)==len(event['observations']),'NATIVE_DEATH_PROCESS_SET')
            for process in event['observations']:
                R.require(process.get('observation') in ('ABSENT','EXITED','PID_REUSED_OLD_OWNER_DEAD'),'NATIVE_DEATH_OBSERVATION')
    byname={r['name']:r for r in rows}
    R.require(byname['GROUP_CRASH']['interruption']['gap']['point']=='AFTER_GROUP_JOURNAL'
              and byname['COMMIT_CRASH']['interruption']['gap']['point']=='AFTER_COMMIT_RENAME_BEFORE_MANIFEST'
              and byname['CANCEL_TREE']['interruption']['action']=='CANCEL_OWNED_JOB_TREE','DISTINCT_NATIVE_GAPS')
    R.require({r['name'] for r in results['native_negatives']}=={
        'live_lease_overlap','false_owner_death','foreign_instance','foreign_lock','outside_run_owned'},'NATIVE_NEGATIVE_SET')
    return results


def produce(run_root,code_sha,package_sha):
    R.require(os.name=='nt','WINDOWS_REQUIRED')
    root=Path(run_root);work=root/'WORK/G3_G6_NATIVE'
    summary,raw=R.read(work/'G3_G6_NATIVE_SCENARIOS.json');results=validate(summary)
    sources=[]
    for p in sorted(work.rglob('*')):
        if p.is_file():
            b=R.core.secure_read_all(p)
            sources.append({'member':p.relative_to(root).as_posix(),'sha256':R.sha(b),'bytes':len(b)})
    roles={
      'PROCESS_TREE_CRASH_CONTAINMENT':{
        'real_coordinator_and_workers_observed':'PASS','owned_process_death_confirmed':'PASS',
        'same_instance_g3_resume':'PASS','causal_g6_closed':'PASS','zero_owned_descendants':'PASS'},
      'SAFE_STOP_RESUME_ROW_GROUP':{
        'native_named_stop':'PASS','durable_partial_bytes_preserved':'PASS','committed_not_duplicated':'PASS',
        'different_worker_equivalence':'PASS','g3_resume_g6_closed':'PASS'},
      'POWERLOSS_EMULATED':{
        'two_distinct_durable_gaps':'PASS','cancel_job_tree':'PASS','automatic_owned_lock_reconciliation':'PASS',
        'foreign_lock_preserved':'PASS','containers_equal_uninterrupted':'PASS'} }
    for name,checks in roles.items():
        out=root/'EVIDENCE/PROOFS'/name
        if out.exists():
            if (out/'PROOF_RECEIPT.json').exists():
                old=R.read(out/'PROOF_RECEIPT.json')[0]
                R.require(old['code_manifest_sha256']==code_sha and old['final_zip_sha256']==package_sha,'PROJECTION_DRIFT')
                for ref in old['artifacts']:
                    b=R.core.secure_read_all(root/ref['member']);R.require(R.sha(b)==ref['sha256'] and len(b)==ref['bytes'],'PROJECTION_ARTIFACT_DRIFT')
                continue
            preserved=root/'INTERRUPTED_ATTEMPTS'/('CAUSAL_PROJECTION_'+uuid.uuid4().hex)
            preserved.parent.mkdir(parents=True,exist_ok=True)
            shutil.move(str(out),str(preserved))
        out.mkdir(parents=True)
        # Full physical inventory points to the one owned experiment namespace;
        # all bytes are also sealed by the unit COMMIT and returned in the ZIP.
        R.publish(out/'NATIVE_CAUSAL_EVIDENCE.json',dict(schema='CDT19_SCOPED_NATIVE_PROOF_PROJECTION_V002',
            proof=name,summary=summary,physical_files=sources,
            code_manifest_sha256=code_sha,final_zip_sha256=package_sha,
            reused_single_experiment=True,operational_authority=False))
        p=out/'NATIVE_CAUSAL_EVIDENCE.json';b=p.read_bytes()
        receipt=dict(schema='TICKSTORE_G5_TARGET_PROOF_RECEIPT_V001',proof=name,
            kind='CDT19_PRE_B06_G3_G6_'+name+'_V002',status='EMULATED_PASS' if name=='POWERLOSS_EMULATED' else 'PASS',
            native_windows=True,platform=platform.platform(),python=sys.version,
            code_manifest_sha256=code_sha,final_zip_sha256=package_sha,run_id=root.name,
            runner={'path':'g5proof/PRE_G06_PROOF_PROJECTION.py','function':'produce','sha256':R.sha(Path(__file__).read_bytes())},
            scenario='Same-instance native G3/G6 over owned NTFS; durable group and commit gaps, real process death and Job cancellation.',
            checks=checks,production_execution=False,gate_verdict_issued=False,error=None,
            artifacts=[{'member':p.relative_to(root).as_posix(),'sha256':R.sha(b),'bytes':len(b)}])
        if name=='POWERLOSS_EMULATED':receipt.update(counts_as='NOT_CHECKPOINT_POWERLOSS_RECOVERY',limitation='NOT_TESTED_PHYSICAL_POWERLOSS; no physical power cut.')
        R.publish(out/'PROOF_RECEIPT.json',receipt)
