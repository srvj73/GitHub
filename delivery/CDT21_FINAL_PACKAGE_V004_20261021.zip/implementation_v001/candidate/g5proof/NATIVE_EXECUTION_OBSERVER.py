"""Native engineering observation. Does not issue operational authority.

Observe an explicitly supplied call and real artifact transitions. The caller
must choose its authorized scope. A trace proves consistency, not issuer trust.
"""
from pathlib import Path
import ctypes
import hashlib
import json
import os
import sys
import uuid


def digest(raw): return hashlib.sha256(raw).hexdigest().upper()
def canonical(value): return (json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()


def process_identity():
    if os.name != 'nt': raise RuntimeError('OBSERVATION_NATIVE_WINDOWS_REQUIRED')
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.GetCurrentProcess.restype=ctypes.c_void_p
    k.GetProcessTimes.argtypes=[ctypes.c_void_p]+[ctypes.POINTER(ctypes.c_ulonglong)]*4
    values=[ctypes.c_ulonglong() for _ in range(4)]
    if not k.GetProcessTimes(k.GetCurrentProcess(),*[ctypes.byref(v) for v in values]):
        raise ctypes.WinError(ctypes.get_last_error())
    return os.getpid(),values[0].value


def observe_call(candidate,source_path,entrypoint,operation,outputs,evidence,run_id):
    # sys.setprofile only sees Python frames. Never fabricate function frames
    # for a PowerShell process that this Python interpreter cannot observe.
    if str(source_path).lower().endswith('.ps1'):
        raise RuntimeError('POWERSHELL_REQUIRES_NATIVE_PROCESS_OBSERVER')
    candidate=Path(candidate).resolve();evidence=Path(evidence).resolve()
    source=candidate/source_path;source_raw=source.read_bytes();source_sha=digest(source_raw)
    if sys.getprofile() is not None: raise RuntimeError('OBSERVATION_PROFILE_ALREADY_ACTIVE')
    pid,creation=process_identity();records=[];active={};previous='';serial=0
    out_paths=[Path(p).absolute() for p in outputs]
    if not out_paths or len(set(out_paths))!=len(out_paths):raise RuntimeError('OBSERVATION_OUTPUT_SET')
    before={p:digest(p.read_bytes()) if p.exists() else None for p in out_paths}
    def profile(frame,phase,arg):
        nonlocal previous,serial
        if phase not in ('call','return') or Path(frame.f_code.co_filename).absolute()!=source:return
        if phase=='call':
            call_id=serial;serial+=1;active[id(frame)]=call_id
        else:
            call_id=active.pop(id(frame))
        record={'sequence':len(records),'previous_sha256':previous,'pid':pid,'run_id':run_id,
                'phase':phase.upper(),'call_id':call_id,'source_path':source_path,
                'source_sha256':source_sha,'function':frame.f_code.co_name}
        raw=canonical(record).rstrip(b'\n');records.append(raw);previous=digest(raw)
    code=0;error=None
    sys.setprofile(profile)
    try:
        result=operation()
        if type(result) is int:code=result
    except BaseException as exc:
        code=1;error=type(exc).__name__+':'+str(exc)
    finally:sys.setprofile(None)
    if source.read_bytes()!=source_raw:raise RuntimeError('OBSERVATION_SOURCE_CHANGED')
    prefix='OBSERVATIONS/'+uuid.uuid4().hex;members={}
    def put(name,raw):
        member=prefix+'/'+name;target=evidence/member;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        if target.read_bytes()!=raw:raise RuntimeError('OBSERVATION_READBACK')
        members[member]=raw
        return {'member':member,'sha256':digest(raw),'bytes':len(raw)}
    effects=[]
    for n,p in enumerate(out_paths):
        if p.is_file():
            ref=put('effect_%d.bin'%n,p.read_bytes());ref['before_sha256']=before[p];effects.append(ref)
    runner=Path(__file__).resolve();runner_path=runner.relative_to(candidate).as_posix()
    observation={'schema':'TICKSTORE_EXECUTION_OBSERVATION_V001','run_id':run_id,'pid':pid,
                 'process_creation_filetime':creation,'exit_code':code,'native_windows':True,
                 'source':put('source.bin',source_raw),
                 'runner':{'path':runner_path,'source':put('runner.py',runner.read_bytes())},
                 'trace':put('trace.jsonl',b'\n'.join(records)+b'\n'),
                 'effects':effects,'error':error}
    committed=code==0 and bool(effects) and all(e['before_sha256']!=e['sha256'] for e in effects)
    event={'schema':'TICKSTORE_NATIVE_CONSUMER_EFFECT_V001','event_id':uuid.uuid4().hex,
           'source_path':source_path,'source_sha256':source_sha,'entrypoint':entrypoint,
           'run_id':run_id,'pid':pid,'process_creation_filetime':creation,'native_windows':True,
           'status':'COMMITTED' if committed else 'NOT_PROVEN','test_only_branch':False,
           'outputs':[{k:v for k,v in e.items() if k!='before_sha256'} for e in effects],
           'observation':put('observation.json',canonical(observation)),
           'predecessor_event_ids':[]}
    put('event.json',canonical(event))
    return event,members


def observe_powershell_process(candidate, source_path, argv, outputs, evidence, run_id,
                               *, timeout_seconds=180):
    """Observe exact PS5.1 script process and output bytes; not Python frames.

    Use a process-only RemoteSigned execution policy. Does not grant D4
    execution authority. No automatic child kill on timeout (reconcile first).
    Runner writes only run-owned evidence, no protected data mutation itself.
    """
    import subprocess
    if os.name != 'nt':
        raise RuntimeError('OBSERVATION_NATIVE_WINDOWS_REQUIRED')
    base=Path(candidate).resolve(strict=True)
    source=base/source_path
    if source.suffix.lower()!='.ps1' or not source.is_file() or source.is_symlink():
        raise RuntimeError('POWERSHELL_SOURCE_NOT_PINNED')
    before_source=source.read_bytes(); source_sha=digest(before_source)
    out_paths=[Path(p).absolute() for p in outputs]
    if len(set(out_paths))!=len(out_paths):raise RuntimeError('OBSERVATION_OUTPUT_SET')
    before={str(x):digest(x.read_bytes()) if x.exists() else None for x in out_paths}
    evidence=Path(evidence).resolve()
    evidence.mkdir(parents=True,exist_ok=True)
    stamp=uuid.uuid4().hex
    stdout=evidence/('PS51_STDOUT_'+stamp+'.bin')
    stderr=evidence/('PS51_STDERR_'+stamp+'.bin')
    ps=Path(os.environ['SystemRoot'])/'System32/WindowsPowerShell/v1.0/powershell.exe'
    if not ps.is_file():raise RuntimeError('POWERSHELL_51_MISSING')
    args=[str(ps),'-NoProfile','-NonInteractive','-ExecutionPolicy','RemoteSigned',
          '-File',str(source),*[str(a) for a in argv]]
    with stdout.open('xb') as so,stderr.open('xb') as se:
        proc=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=so,stderr=se,
                              creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.GetProcessTimes.argtypes=[ctypes.c_void_p]+[ctypes.POINTER(ctypes.c_ulonglong)]*4
        times=[ctypes.c_ulonglong() for _ in range(4)]
        if not kernel.GetProcessTimes(ctypes.c_void_p(int(proc._handle)),
                                      *[ctypes.byref(t) for t in times]):
            raise ctypes.WinError(ctypes.get_last_error())
        import time
        started=time.monotonic()
        while True:
            elapsed=time.monotonic()-started
            budget=min(5.0,max(0.1,timeout_seconds-elapsed))
            try:
                code=proc.wait(timeout=budget)
                break
            except subprocess.TimeoutExpired as exc:
                if time.monotonic()-started>=timeout_seconds:
                    raise RuntimeError('POWERSHELL_TIMEOUT_PROCESS_RECONCILIATION_REQUIRED') from exc
                print('PS51_ACTIVE_PID=%d ELAPSED_S=%d ETA=UNKNOWN' %
                      (proc.pid,int(time.monotonic()-started)),flush=True)
    if before_source!=source.read_bytes():raise RuntimeError('OBSERVATION_SOURCE_CHANGED')
    after={str(x):digest(x.read_bytes()) if x.is_file() else None for x in out_paths}
    changes=[{'path':p,'before_sha256':before[p],'after_sha256':after[p]}
             for p in before if before[p]!=after[p]]
    result={'schema':'TICKSTORE_PS51_PROCESS_OBSERVATION_V001','language':'POWERSHELL_5_1',
            'run_id':run_id,'source_path':source_path,'source_sha256':source_sha,
            'runner_sha256':digest(Path(__file__).read_bytes()),
            'powershell_exe_sha256':digest(ps.read_bytes()),
            'pid':proc.pid,'creation_filetime':times[0].value,'exit_code':code,
            'stdout_sha256':digest(stdout.read_bytes()),'stderr_sha256':digest(stderr.read_bytes()),
            'stdout_path':str(stdout),'stderr_path':str(stderr),
            'outputs_before_after':changes,'native_windows':True,
            'does_not_prove_ps_function_calls':True,'production_authority_granted':False}
    # exit 0 and changed scratch files are observations, never a D4/G5 PASS.
    return result
