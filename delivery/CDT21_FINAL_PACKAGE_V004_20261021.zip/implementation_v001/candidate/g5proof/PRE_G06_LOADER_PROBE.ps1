param(
    [Parameter(Mandatory=$true)][string]$Source,
    [Parameter(Mandatory=$true)][string]$SourceSha,
    [Parameter(Mandatory=$true)][string]$LabRoot,
    [Parameter(Mandatory=$true)][string]$OwnerSha,
    [Parameter(Mandatory=$true)][string]$Python,
    [Parameter(Mandatory=$true)][string]$ChildScript,
    [Parameter(Mandatory=$true)][string]$ChildSha,
    [switch]$NegativeOnly
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) {throw 'PS51_REQUIRED'}
$root=[IO.Path]::GetFullPath($LabRoot)
$scan=[IO.DirectoryInfo]::new($root)
while ($null -ne $scan) {
    if (-not $scan.Exists -or ($scan.Attributes -band [IO.FileAttributes]::ReparsePoint)) {throw 'LAB_ROOT_REPARSE_OR_MISSING'}
    $scan=$scan.Parent
}
if ((Get-FileHash -LiteralPath (Join-Path $root 'OWNER.json') -Algorithm SHA256).Hash -cne $OwnerSha) {throw 'LAB_FOREIGN_OWNER'}
if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -cne $SourceSha) {throw 'LOADER_SOURCE_DRIFT'}
if ([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($ChildScript)) -cne $root) {throw 'CHILD_OUTSIDE_LAB'}
if ((Get-FileHash -LiteralPath $ChildScript -Algorithm SHA256).Hash -cne $ChildSha) {throw 'CHILD_SOURCE_DRIFT'}
# Defining the exact loader function has no launch effects. The ordinary entry
# is then invoked with an intentionally inadmissible anchor; it must block.
. $Source
$isAdapter=[IO.Path]::GetFileName($Source).Contains('ADAPTER')
$command=if($isAdapter){'Invoke-TickstoreInlineRootV004R1Adapter'}else{'Invoke-TickstoreInlineRootV004R1'}
$script:entryObserved=$false
$breakpoint=Set-PSBreakpoint -Command $command -Action { $script:entryObserved=$true }
$negative=''
try {
    $badAnchor=@{release_bundle_sha256='';release_manifest_sha256='';recovery_source_sha256='';owner_gate_sha256='';python_exe_sha256=''}|ConvertTo-Json -Compress
    $argsInvoke=@{BundlePath=(Join-Path $root 'DOES_NOT_EXIST.zip');PythonPath=$Python;ExternalAnchorJson=$badAnchor}
    if($isAdapter){$argsInvoke.AdapterEntryPath=$ChildScript;$argsInvoke.ExpectedAdapterEntrySha=$ChildSha}
    & $command @argsInvoke | Out-Null
    throw 'INADMISSIBLE_ANCHOR_WAS_ACCEPTED'
} catch {
    $negative=$_.Exception.Message
    if ($negative -notmatch 'ANCHOR_HASH_REQUIRED') {throw}
} finally {Remove-PSBreakpoint -Breakpoint $breakpoint}
if (-not $script:entryObserved) {throw 'LOADER_ENTRY_NOT_OBSERVED'}
# Exercise the original compiled native Launch branch using a safe internal
# receipt operation on owned NTFS. No OWNER_GATE is created or authorized.
$code=$null
if (-not $NegativeOnly) {
    $code=[TickstoreRootV004R1]::Launch($Python,[IO.File]::ReadAllBytes($ChildScript),[byte[]]@())
    if($code -ne 0){throw ('INTERNAL_LAUNCH_EXIT_'+$code)}
}
if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -cne $SourceSha) {throw 'LOADER_SOURCE_CHANGED'}
$out=[ordered]@{schema='CDT19_NATIVE_LOADER_BRANCH_V001';entrypoint=$command;entry_observed=$script:entryObserved;
  pid=$PID;creation_filetime=(Get-Process -Id $PID).StartTime.ToUniversalTime().ToFileTimeUtc();
  negative_error=$negative;internal_exit=$code;compiled_branch='TickstoreRootV004R1.Launch';source_sha256=$SourceSha}
$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($out|ConvertTo-Json -Compress)+"`n")
$resultName=if($NegativeOnly){'LOADER_NEGATIVE_RESULT.json'}else{'LOADER_RESULT.json'}
$f=[IO.FileStream]::new((Join-Path $root $resultName),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()}
if($NegativeOnly){exit 2}
exit 0
