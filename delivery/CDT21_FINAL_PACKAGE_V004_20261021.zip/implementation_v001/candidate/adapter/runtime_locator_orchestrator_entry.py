from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import sys


def sha_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def parse_d4_arguments(argv: list[str]) -> argparse.Namespace:
    """Constrain dispatch before reading paths or executing either namespace.

    Even frozen 'status' and 'plan' construct State and rewrite STATE.json.
    Omitting --until in the frozen runner defaults to E9, not D4.
    """
    class Once(argparse.Action):
        def __call__(self, parser, namespace, value, option_string=None):
            if getattr(namespace, self.dest, None) is not None:
                parser.error("ADAPTER_ENTRY_DUPLICATE_ARGUMENT:" + str(option_string))
            setattr(namespace, self.dest, value)

    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("command", choices=("run", "resume"))
    parser.add_argument("--until", required=True, choices=("D4",), action=Once)
    parser.add_argument("--package", required=True, action=Once)
    parser.add_argument("--python", required=True, action=Once)
    return parser.parse_args(argv)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest().upper()


_FILE_ATTRIBUTE_REPARSE_POINT = 0x400


def _is_link_or_reparse(st: os.stat_result) -> bool:
    import stat as _stat
    return _stat.S_ISLNK(st.st_mode) or bool(getattr(st, "st_file_attributes", 0) & _FILE_ATTRIBUTE_REPARSE_POINT)


def _lexical(path) -> str:
    return os.path.normcase(os.path.abspath(str(path)))


def _ident(st: os.stat_result) -> tuple:
    # Physical identity and version of one directory entry, taken with lstat only.
    return (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns)


def require_no_link_chain(path, label: str) -> None:
    """B06R2: reject a symlink, junction or other reparse point at the path or any ancestor."""
    p = pathlib.Path(_lexical(path))
    for part in (p, *p.parents):
        try:
            st = os.lstat(part)
        except FileNotFoundError:
            raise RuntimeError(label + ("_MISSING" if part == p else "_ANCESTOR_MISSING")) from None
        if _is_link_or_reparse(st):
            raise RuntimeError(label + "_LINK_OR_REPARSE")


def read_pinned_regular(path, label: str) -> tuple:
    """Bind bytes to the opened file, not two observations of a replaceable name.

    Windows denies concurrent write/delete on this handle. fstat binds the actual
    reader to the admitted lstat identity and rejects ABA name substitutions.
    """
    import stat
    require_no_link_chain(path, label)
    before = os.lstat(path)
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError(label + "_NOT_REGULAR")
    fd = None
    try:
        if os.name == 'nt':
            import ctypes
            import ctypes.wintypes as w
            import msvcrt
            k = ctypes.WinDLL('kernel32', use_last_error=True)
            k.CreateFileW.argtypes = [w.LPCWSTR,w.DWORD,w.DWORD,ctypes.c_void_p,w.DWORD,w.DWORD,w.HANDLE]
            k.CreateFileW.restype = w.HANDLE
            k.CloseHandle.argtypes = [w.HANDLE]; k.CloseHandle.restype = w.BOOL
            handle = k.CreateFileW(str(path),0x80000000,1,None,3,0x00200000,None)
            if handle == ctypes.c_void_p(-1).value:
                raise OSError(ctypes.get_last_error(),label + '_OPEN_PINNED')
            try: fd = msvcrt.open_osfhandle(handle,os.O_RDONLY | os.O_BINARY)
            except BaseException:
                k.CloseHandle(handle); raise
        else:
            fd = os.open(path,os.O_RDONLY | getattr(os,'O_NOFOLLOW',0))
        with os.fdopen(fd,'rb') as stream:
            fd = None
            opened = os.fstat(stream.fileno())
            if not stat.S_ISREG(opened.st_mode) or _ident(opened) != _ident(before):
                raise RuntimeError(label + '_CHANGED_DURING_OPEN')
            raw = stream.read()
            after_fd = os.fstat(stream.fileno())
            require_no_link_chain(path,label)
            after = os.lstat(path)
            if (_ident(opened) != _ident(after_fd) or _ident(after_fd) != _ident(after)
                    or len(raw) != after.st_size):
                raise RuntimeError(label + '_CHANGED_DURING_READ')
    except FileNotFoundError:
        raise RuntimeError(label + "_MISSING") from None
    except OSError as exc:
        raise RuntimeError(label + '_PINNED_READ:' + str(exc)) from exc
    finally:
        if fd is not None: os.close(fd)
    return raw, _ident(after)


class AdmittedStart:
    """Objects admitted at the D4 start boundary; later consumers use these, not re-reads."""
    __slots__ = ("state_path", "control_root", "config_path", "config_raw", "config_sha256",
                 "config_ident", "state_raw", "state_ident")

    def __init__(self, state_path, control_root, config_path, config_raw, config_sha256,
                 config_ident=None, state_raw=None, state_ident=None):
        self.state_path = state_path
        self.control_root = control_root
        self.config_path = config_path
        self.config_raw = bytes(config_raw)
        self.config_sha256 = config_sha256
        self.config_ident = config_ident
        self.state_raw = None if state_raw is None else bytes(state_raw)
        self.state_ident = state_ident


class RunIdentity:
    """RUN_AUTHORITY and its checkpoint anchor, each read once (hashed bytes = parsed bytes)."""
    __slots__ = ("ra", "ra_raw", "ra_sha", "anchor_raw", "anchor_sha", "anchor")

    def __init__(self, ra, ra_raw, anchor_raw):
        self.ra = ra
        self.ra_raw = bytes(ra_raw)
        self.ra_sha = _sha(ra_raw)
        self.anchor_raw = bytes(anchor_raw)
        self.anchor_sha = _sha(anchor_raw)
        self.anchor = json.loads(self.anchor_raw.decode("utf-8-sig"))


def load_run_identity(binding: dict) -> RunIdentity:
    """Load the D4 run identity before the frozen O constructor can touch STATE.

    B06R3 / policy rev. 37 §13.2 (decision: option B): OWNER_GATE.json is no
    longer an autonomous production approval. The historical gate is read only
    as the technical identity anchor of the checkpoint (its SHA-256 is part of
    RUN_AUTHORITY and of every signed checkpoint payload). Every property of the
    anchor is judged later by evaluate_resume_identity, as a frozen-engine data
    constraint or as identity continuity, never as an approval.
    """
    if os.environ.get("TICKSTORE_D4_RESUME_ENABLE") != "1":
        raise RuntimeError("ADAPTER_ENTRY_D4_AUTHORITY_REQUIRED")
    authority = pathlib.Path(os.environ["TICKSTORE_D4_RUN_AUTHORITY"])
    authority_raw, _ = read_pinned_regular(authority, "ADAPTER_ENTRY_AUTHORITY")
    if _sha(authority_raw) != os.environ["TICKSTORE_D4_RUN_AUTHORITY_SHA256"].upper():
        raise RuntimeError("ADAPTER_ENTRY_AUTHORITY_SHA")
    ra = json.loads(authority_raw.decode("ascii"))
    if (ra.get("schema") != "TICKSTORE_D4_RUN_AUTHORITY_V005" or ra.get("status") != "ACTIVE"
        or ra.get("effect_scope") != "D4_ONLY" or ra.get("d5_authorized") is not False
        or ra.get("full_authorized") is not False):
        raise RuntimeError("ADAPTER_ENTRY_AUTHORITY_SCOPE")
    anchor_raw, _ = read_pinned_regular(ra["owner_gate_path"], "ADAPTER_ENTRY_ANCHOR")
    if _sha(anchor_raw) != ra.get("owner_gate_sha256"):
        raise RuntimeError("ADAPTER_ENTRY_ANCHOR_SHA")
    return RunIdentity(ra, authority_raw, anchor_raw)


def validate_first_admission_commit(authority: dict, state_raw: bytes, state_path=None) -> None:
    """Authenticate a newly materialized instance before any frozen constructor.

    Historical authorities remain under their existing reconciliation contract.
    A first-admission authority can only refer to a complete, byte-bound support
    directory, and absence of checkpoint requires the original physical STATE.
    """
    manifest_path = authority.get("first_admission_manifest_path")
    if manifest_path is None:
        return
    path = pathlib.Path(manifest_path)
    raw, _ = read_pinned_regular(path, "FIRST_ADMISSION_COMMIT")
    if _sha(raw) != authority.get("first_admission_manifest_sha256"):
        raise RuntimeError("FIRST_ADMISSION_COMMIT_SHA")
    manifest = json.loads(raw.decode("ascii"))
    expected = {"TECHNICAL_EXECUTION_DESCRIPTOR.json", "G_CA_RUNTIME_LOCATOR.json",
                "RUNTIME_LOCATOR_ADAPTER_BINDING.json", "runtime_locator_adapter.py",
                "runtime_locator_orchestrator_entry.py", "runtime_locator_inline_entry.py",
                "INLINE_ROOT_LOADER_V004_R1R1_ADAPTER.ps1", "Launch-TickstoreBundle-Adapter.ps1"}
    if (manifest.get("schema") != "TICKSTORE_FIRST_ADMISSION_COMMIT_V001"
        or manifest.get("run_id") != authority.get("run_id")
        or set(manifest.get("files", {})) != expected
        or manifest.get("initial_state") != authority.get("first_admission_state")):
        raise RuntimeError("FIRST_ADMISSION_COMMIT_CONTRACT")
    for name, digest in manifest["files"].items():
        data, _ = read_pinned_regular(path.parent / name, "FIRST_ADMISSION_SUPPORT")
        if _sha(data) != digest:
            raise RuntimeError("FIRST_ADMISSION_SUPPORT_SHA:" + name)
    for pk, hk, name in (("owner_gate_path", "owner_gate_sha256", "TECHNICAL_EXECUTION_DESCRIPTOR.json"),
                         ("gca_recovery_receipt_path", "gca_recovery_receipt_sha256", "G_CA_RUNTIME_LOCATOR.json"),
                         ("adapter_binding_path", "adapter_binding_sha256", "RUNTIME_LOCATOR_ADAPTER_BINDING.json")):
        if (_lexical(authority.get(pk, "")) != _lexical(path.parent / name)
            or authority.get(hk) != manifest["files"][name]):
            raise RuntimeError("FIRST_ADMISSION_RUNTIME_BINDING:" + pk)
    for pk, hk in (("b07_receipt_path", "b07_receipt_sha256"), ("completeness_path", "completeness_sha256"),
                   ("final_code_manifest_path", "final_code_manifest_sha256"),
                   ("policy_master_path", "policy_master_sha256"), ("policy_head_path", "policy_head_sha256"),
                   ("origin_witness_path", "origin_witness_sha256")):
        data, _ = read_pinned_regular(authority[pk], "FIRST_ADMISSION_GATE_EVIDENCE")
        if _sha(data) != authority.get(hk):
            raise RuntimeError("FIRST_ADMISSION_GATE_EVIDENCE_SHA:" + pk)
    if not os.path.lexists(pathlib.Path(authority["resume_root"]) / "CHECKPOINT.json"):
        pin = authority["first_admission_state"]
        if (state_path is None or _sha(state_raw) != pin.get("sha256")
            or list(_ident(os.lstat(state_path))) != pin.get("identity")):
            raise RuntimeError("FIRST_ADMISSION_INITIAL_STATE_CHANGED")


def validate_run_authority(binding: dict) -> dict:
    """Compatibility wrapper (B06R3): run scope and anchor integrity only."""
    return load_run_identity(binding).ra


_STABLE_GENERATION_FIELDS = ("snapshot_id", "snapshot_set_id", "provider_id", "volume_identity", "purpose")
CHECKPOINT_SCHEMA = "TICKSTORE_D4_SIGNED_CHECKPOINT_V003"
CHECKPOINT_PAYLOAD_SCHEMA = "TICKSTORE_D4_CERTIFY_CHECKPOINT_V003"


def _norm_generation_value(key, value):
    if key in ("snapshot_id", "snapshot_set_id", "provider_id"):
        return str(value or "").strip().strip("{}").lower()
    return value


def _same_generation(a, b) -> bool:
    if not isinstance(a, dict) or not isinstance(b, dict):
        return False
    return all(_norm_generation_value(k, a.get(k)) == _norm_generation_value(k, b.get(k)) and a.get(k) is not None
               for k in _STABLE_GENERATION_FIELDS)


def _frozen_library(release_raw: bytes) -> dict:
    ns = {"__name__": "tickstore_frozen_engine_identity_library", "__file__": "<tickstore_publisher_recovery_v004.py>"}
    exec(compile(release_raw, "<tickstore_publisher_recovery_v004.py>", "exec"), ns, ns)
    return ns


def evaluate_resume_identity(identity: RunIdentity, binding: dict, admitted, locator_receipt: dict,
                             release_raw: bytes, key_hex: str) -> list:
    """B06R3: prove that anchor, RUN_AUTHORITY, run_id, signed checkpoint, STATE and VSS generation
    belong to one execution. Returns [(label, ok, detail)]; nothing is written.

    Frozen-engine constraints are cited by function so that a mismatch is recognised as a technical
    impossibility of the frozen V002R22 release, not as a missing approval:
      dispatch_bootstrap: anchor gate format, recovery_source == running engine, OWNER_GATE member hash;
      _d4r_activate_runtime: RUN_AUTHORITY.owner_gate_sha256 == bundle anchor; successor == engine;
      _d4r_read_checkpoint: checkpoint payload bound to run_id, authority, release, config, anchor, generation.
    """
    import hmac as _hmac
    ra, anchor = identity.ra, identity.anchor
    out = []

    def check(label, ok, detail=""):
        out.append((label, bool(ok), detail))

    release_sha = _sha(release_raw)
    generation = anchor.get("admission_generation") if isinstance(anchor, dict) else None
    check("ANCHOR_IS_BOUND_IDENTITY", identity.anchor_sha == str(ra.get("owner_gate_sha256", "")).upper()
          == str(binding.get("owner_gate_sha256", "")).upper()
          == str(locator_receipt.get("owner_gate_sha256", "")).upper(), identity.anchor_sha)
    check("FROZEN_ENGINE_ANCHOR_FORMAT(dispatch_bootstrap)",
          isinstance(anchor, dict) and anchor.get("schema") == "RECOVERY_OWNER_GATE_V004"
          and anchor.get("authorized") is True and anchor.get("mode") == "CERTIFY_SCRATCH"
          and isinstance(anchor.get("permissions"), dict) and anchor["permissions"].get("CERTIFY_SCRATCH") is True
          and "release_bundle_sha256" not in anchor and "external_anchor_sha256" not in anchor,
          "format constants required by the frozen engine; not an approval")
    check("FROZEN_ENGINE_SOURCE(dispatch_bootstrap/_d4r_activate_runtime)",
          isinstance(anchor, dict) and anchor.get("recovery_source_sha256") == release_sha
          == str(ra.get("successor_release_sha256", "")).upper() == str(binding.get("frozen_release_sha256", "")).upper(),
          "anchor.recovery_source=" + str(anchor.get("recovery_source_sha256") if isinstance(anchor, dict) else None)
          + " running_engine=" + release_sha)
    check("GENERATION_ANCHOR_EQUALS_RUN_AUTHORITY", generation is not None and generation == ra.get("generation"))
    check("GENERATION_LOCATOR_STABLE_IDENTITY", _same_generation(generation, locator_receipt.get("generation")))
    g_ca = None
    if getattr(admitted, "state_raw", None) is not None:
        g_ca = json.loads(admitted.state_raw.decode("utf-8")).get("G_CA")
    check("GENERATION_STATE_G_CA_STABLE_IDENTITY", _same_generation(generation, g_ca))
    check("CONFIG_ADMITTED_EQUALS_RUN_AUTHORITY", str(ra.get("config_sha256", "")).upper() == admitted.config_sha256)
    key = b""
    try:
        key = bytes.fromhex(key_hex or "")
    except ValueError:
        key = b""
    check("RUN_KEY_EQUALS_RUN_AUTHORITY", len(key) == 32 and _sha(key) == str(ra.get("key_sha256", "")).upper())
    resume_root = pathlib.Path(str(ra.get("resume_root", "")))
    cp_path = resume_root / "CHECKPOINT.json"
    lib = _frozen_library(release_raw)
    if os.path.lexists(cp_path):
        try:
            raw, _ = read_pinned_regular(cp_path, "ADAPTER_ENTRY_CHECKPOINT")
            signed = json.loads(raw.decode("ascii"))
            payload = signed.get("payload") if isinstance(signed, dict) else None
            ok_sig = (isinstance(payload, dict) and signed.get("schema") == CHECKPOINT_SCHEMA and len(key) == 32
                      and _hmac.compare_digest(str(signed.get("hmac_sha256", "")).upper(), lib["_d4r_hmac_hex"](key, payload)))
        except (RuntimeError, ValueError, UnicodeDecodeError) as exc:
            payload, ok_sig = None, False
            check("CHECKPOINT_READ", False, str(exc))
        check("CHECKPOINT_SIGNATURE_RUN_KEY", ok_sig)
        p = payload if isinstance(payload, dict) else {}
        check("CHECKPOINT_PAYLOAD_SCHEMA", p.get("schema") == CHECKPOINT_PAYLOAD_SCHEMA)
        check("CHECKPOINT_RUN_ID", p.get("run_id") == ra.get("run_id") and bool(ra.get("run_id")))
        check("CHECKPOINT_RUN_AUTHORITY_SHA", p.get("run_authority_sha256") == identity.ra_sha)
        check("CHECKPOINT_RELEASE", p.get("successor_release_sha256") == release_sha)
        check("CHECKPOINT_CONFIG", p.get("config_sha256") == admitted.config_sha256)
        check("CHECKPOINT_ANCHOR", p.get("owner_gate_sha256") == identity.anchor_sha)
        check("CHECKPOINT_GENERATION", generation is not None and p.get("generation_sha256") == lib["_d4r_sha_obj"](generation))
        check("CHECKPOINT_TOTAL", p.get("total") == lib["S0_COUNT"])
        committed = p.get("committed")
        inventory = anchor.get("s0_inventory") if isinstance(anchor, dict) else None
        check("CHECKPOINT_COMMITTED_WITHIN_ANCHOR_INVENTORY", isinstance(committed, list) and isinstance(inventory, dict)
              and committed == sorted(committed) and set(committed) <= set(inventory)
              and p.get("committed_count") == len(committed))
    else:
        chunks = resume_root / "chunks"
        orphan = chunks.is_dir() and any(chunks.iterdir())
        check("CHECKPOINT_ABSENT_WITHOUT_COMMITTED_CHUNKS", str(ra.get("resume_root", "")) != "" and not orphan,
              "no checkpoint to preserve" if not orphan else "chunks without checkpoint")
    return out


def reconcile_resume_identity(identity: RunIdentity, binding: dict, admitted, locator_receipt: dict,
                              release_raw: bytes, key_hex: str) -> list:
    report = evaluate_resume_identity(identity, binding, admitted, locator_receipt, release_raw, key_hex)
    failed = [label for label, ok, _ in report if not ok]
    if failed:
        raise RuntimeError("ADAPTER_ENTRY_IDENTITY_NOT_RECONCILED:" + ",".join(failed))
    return report


CAS_DEBRIS_MARKERS = (".cas-new.", ".cas-old.", ".cas-intent.")


def require_no_cas_debris(state_path) -> None:
    """B06R3: an interrupted STATE commit is never resumed or repaired implicitly.

    Leftovers of the CAS protocol block admission; only the explicit
    state_cas_recovery tool may resolve them, from its recorded intent.
    """
    state_path = pathlib.Path(state_path)
    try:
        names = os.listdir(state_path.parent)
    except FileNotFoundError:
        return
    if any(n.startswith(state_path.name) and any(m in n for m in CAS_DEBRIS_MARKERS) for n in names):
        raise RuntimeError("ADAPTER_ENTRY_STATE_CAS_RECOVERY_REQUIRED")


# CDT21 F-01: legacy entry fence.  Every frozen orchestrator route (the V004R1 master
# launcher, `python orchestrator.py <command>`, any deployed copy) constructs State(control_root)
# first, and the frozen State.__init__ always publishes STATE through atom(): it opens
# "STATE.json.partial" for writing and then os.replace()s it.  A directory at that exact name
# makes that first write fail before any byte of STATE, journal, inbox or runs changes.  Admitted
# writers never use that name (their STATE commits are the CAS above), so the fence is invisible
# to them and is required before a writer is admitted.  control/LEGACY_ENTRY_FENCE.py installs it.
LEGACY_ENTRY_FENCE_SCHEMA = "TICKSTORE_LEGACY_ENTRY_FENCE_V001"
LEGACY_ENTRY_FENCE_MARKER = "LEGACY_ENTRY_FENCE.json"


def legacy_entry_fence_path(state_path) -> pathlib.Path:
    state_path = pathlib.Path(state_path)
    return state_path.with_name(state_path.name + ".partial")


def require_legacy_entry_fence_marker(state_path) -> bytes:
    """CDT21 F-01: the fence directory and its marker (V003 contract); returns the marker bytes."""
    import stat
    state_path = pathlib.Path(state_path)
    fence = legacy_entry_fence_path(state_path)
    require_no_link_chain(fence, "LEGACY_ENTRY_FENCE")
    if not stat.S_ISDIR(os.lstat(fence).st_mode):
        raise RuntimeError("LEGACY_ENTRY_FENCE_NOT_DIRECTORY")
    raw, _ = read_pinned_regular(fence / LEGACY_ENTRY_FENCE_MARKER, "LEGACY_ENTRY_FENCE_MARKER")
    try:
        marker = json.loads(raw.decode("utf-8"))
    except ValueError:
        raise RuntimeError("LEGACY_ENTRY_FENCE_MARKER_JSON") from None
    if (not isinstance(marker, dict) or marker.get("schema") != LEGACY_ENTRY_FENCE_SCHEMA
            or marker.get("state_name") != state_path.name or marker.get("fence_name") != fence.name):
        raise RuntimeError("LEGACY_ENTRY_FENCE_MARKER_CONTENT")
    return raw


# CDT21 F-01R1 (V004): the cut also binds frozen processes that built State BEFORE the fence.
# B06 of V003: such a process appends STATE_JOURNAL.jsonl by name (State.log: open(..., "ab") on
# every call) and holds no handle, lock or mutex in between, so neither the fence directory (it only
# denies the next State construction) nor acquire_state_boundary could exclude it.  The journal is
# therefore closed by name as well: on Windows an explicit DENY ACE (Everyone: FILE_WRITE_DATA |
# FILE_APPEND_DATA) is checked by the kernel at every open, so the frozen open for appending fails
# for every process, whenever it started; the cut instant is then proven by opening the journal
# without write sharing (no write handle opened before the ACE survives) and recording its bytes.
# Admitted writers (elevated D4 entry / FULL continuation) append the same line through
# append_admitted_journal_line: backup semantics with SeRestorePrivilege enabled on a thread
# impersonation token for that single open.
# Drain: frozen execute() logs STARTED(run_id=<yyyymmdd_HHMMSS_mmm>_<pid>) before any node effect,
# so the journal at the cut names every legacy run that may still be inside a node.  A run is drained
# when its process identity is gone: no process, exited, or the PID now belongs to a process created
# after the run's first STARTED plus LEGACY_DRAIN_CLOCK_MARGIN_NS.  Monotone: after the cut no legacy
# STARTED can be logged and a gone identity never returns.  No process census is taken.
# POSIX test hosts model the ACE with mode 0444 (writers without CAP_DAC_OVERRIDE are refused) and
# the write-sharing probe with a read lease (F_SETLEASE fails while any write descriptor is open).
LEGACY_JOURNAL_NAME = "STATE_JOURNAL.jsonl"
LEGACY_JOURNAL_CUT_SCHEMA = "TICKSTORE_LEGACY_JOURNAL_CUT_V001"
LEGACY_JOURNAL_CUT_RECORD = "LEGACY_JOURNAL_CUT.json"
LEGACY_JOURNAL_DENIED_ACCESS = 0x0002 | 0x0004  # FILE_WRITE_DATA | FILE_APPEND_DATA
LEGACY_DRAIN_CLOCK_MARGIN_NS = 600 * 1_000_000_000
LEGACY_RUN_ID_PATTERN = r"[0-9]{8}_[0-9]{6}_[0-9]{3}_([0-9]{1,10})"
_FILETIME_UNIX_EPOCH = 116444736000000000


def legacy_journal_path(state_path) -> pathlib.Path:
    return pathlib.Path(state_path).with_name(LEGACY_JOURNAL_NAME)


class _Win32:
    """kernel32/advapi32 entry points used by the journal cut (Windows only)."""

    def __init__(self):
        import ctypes
        import ctypes.wintypes as w
        self.ctypes, self.w = ctypes, w
        k = self.k = ctypes.WinDLL("kernel32", use_last_error=True)
        a = self.a = ctypes.WinDLL("advapi32", use_last_error=True)
        vp, dw, bo, h = ctypes.c_void_p, w.DWORD, w.BOOL, w.HANDLE
        for fn, args, res in (
                (k.CreateFileW, [w.LPCWSTR, dw, dw, vp, dw, dw, h], h), (k.CloseHandle, [h], bo),
                (k.LocalFree, [vp], vp), (k.GetCurrentProcess, [], h),
                (k.OpenProcess, [dw, bo, dw], h), (k.WaitForSingleObject, [h, dw], dw),
                (k.GetProcessTimes, [h] + [ctypes.POINTER(ctypes.c_ulonglong)] * 4, bo),
                (a.ConvertStringSidToSidW, [w.LPCWSTR, ctypes.POINTER(vp)], bo), (a.EqualSid, [vp, vp], bo),
                (a.GetNamedSecurityInfoW, [w.LPCWSTR, ctypes.c_int, dw] + [ctypes.POINTER(vp)] * 5, dw),
                (a.SetNamedSecurityInfoW, [w.LPWSTR, ctypes.c_int, dw, vp, vp, vp, vp], dw),
                (a.SetEntriesInAclW, [ctypes.c_ulong, vp, vp, ctypes.POINTER(vp)], dw),
                (a.GetAce, [vp, dw, ctypes.POINTER(vp)], bo),
                (a.ConvertSecurityDescriptorToStringSecurityDescriptorW,
                 [vp, dw, dw, ctypes.POINTER(w.LPWSTR), ctypes.POINTER(ctypes.c_ulong)], bo),
                (a.OpenProcessToken, [h, dw, ctypes.POINTER(h)], bo),
                (a.DuplicateTokenEx, [h, dw, vp, ctypes.c_int, ctypes.c_int, ctypes.POINTER(h)], bo),
                (a.LookupPrivilegeValueW, [w.LPCWSTR, w.LPCWSTR, vp], bo),
                (a.AdjustTokenPrivileges, [h, bo, vp, dw, vp, vp], bo),
                (a.SetThreadToken, [vp, h], bo), (a.RevertToSelf, [], bo)):
            fn.argtypes, fn.restype = args, res
        self.invalid = ctypes.c_void_p(-1).value

    def error(self) -> int:
        return self.ctypes.get_last_error()

    def everyone(self):
        sid = self.ctypes.c_void_p()
        if not self.a.ConvertStringSidToSidW("S-1-1-0", self.ctypes.byref(sid)):
            raise RuntimeError("LEGACY_JOURNAL_CUT_SID:" + str(self.error()))
        return sid

    def dacl(self, path):
        ctypes = self.ctypes
        dacl, sd = ctypes.c_void_p(), ctypes.c_void_p()
        rc = self.a.GetNamedSecurityInfoW(str(path), 1, 4, None, None, ctypes.byref(dacl), None, ctypes.byref(sd))
        if rc != 0:
            raise RuntimeError("LEGACY_JOURNAL_CUT_GET_DACL:" + str(rc))
        return dacl, sd


def _win_deny_journal_writes(journal) -> None:
    W = _Win32()
    ctypes = W.ctypes

    class TRUSTEE(ctypes.Structure):
        _fields_ = [("pMultipleTrustee", ctypes.c_void_p), ("MultipleTrusteeOperation", ctypes.c_int),
                    ("TrusteeForm", ctypes.c_int), ("TrusteeType", ctypes.c_int), ("ptstrName", ctypes.c_void_p)]

    class EXPLICIT_ACCESS(ctypes.Structure):
        _fields_ = [("grfAccessPermissions", W.w.DWORD), ("grfAccessMode", ctypes.c_int),
                    ("grfInheritance", W.w.DWORD), ("Trustee", TRUSTEE)]

    sid = W.everyone()
    try:
        dacl, sd = W.dacl(journal)
        try:
            ea = EXPLICIT_ACCESS()
            ea.grfAccessPermissions = LEGACY_JOURNAL_DENIED_ACCESS
            ea.grfAccessMode = 3  # DENY_ACCESS
            ea.grfInheritance = 0  # NO_INHERITANCE
            ea.Trustee.TrusteeForm = 0  # TRUSTEE_IS_SID
            ea.Trustee.TrusteeType = 5  # TRUSTEE_IS_WELL_KNOWN_GROUP
            ea.Trustee.ptstrName = sid.value
            new = ctypes.c_void_p()
            rc = W.a.SetEntriesInAclW(1, ctypes.byref(ea), dacl, ctypes.byref(new))
            if rc != 0:
                raise RuntimeError("LEGACY_JOURNAL_CUT_BUILD_DACL:" + str(rc))
            try:
                rc = W.a.SetNamedSecurityInfoW(str(journal), 1, 4, None, None, new, None)
                if rc != 0:
                    raise RuntimeError("LEGACY_JOURNAL_CUT_SET_DACL:" + str(rc))
            finally:
                W.k.LocalFree(new)
        finally:
            W.k.LocalFree(sd)
    finally:
        W.k.LocalFree(sid)


def _win_write_denial(journal) -> dict:
    W = _Win32()
    ctypes = W.ctypes
    functional = {}
    for name, access in (("GENERIC_WRITE", 0x40000000), ("FILE_WRITE_DATA", 0x2), ("FILE_APPEND_DATA", 0x4)):
        handle = W.k.CreateFileW(str(journal), access, 7, None, 3, 0x00200000, None)
        error = W.error()
        if handle not in (None, W.invalid):
            W.k.CloseHandle(handle)
            functional[name] = "OPENED"
        else:
            functional[name] = "ACCESS_DENIED" if error == 5 else "ERROR_" + str(error)
    explicit = False
    sddl = None
    sid = W.everyone()
    try:
        dacl, sd = W.dacl(journal)
        try:
            if dacl.value:
                for index in range(ctypes.c_ushort.from_address(dacl.value + 4).value):
                    ace = ctypes.c_void_p()
                    if not W.a.GetAce(dacl, index, ctypes.byref(ace)):
                        raise RuntimeError("LEGACY_JOURNAL_CUT_GET_ACE:" + str(W.error()))
                    kind = ctypes.c_ubyte.from_address(ace.value).value
                    flags = ctypes.c_ubyte.from_address(ace.value + 1).value
                    mask = ctypes.c_uint32.from_address(ace.value + 4).value
                    if (kind == 1 and not flags & 0x18 and mask & LEGACY_JOURNAL_DENIED_ACCESS == LEGACY_JOURNAL_DENIED_ACCESS
                            and W.a.EqualSid(ace.value + 8, sid)):
                        explicit = True
            text = W.w.LPWSTR()
            if W.a.ConvertSecurityDescriptorToStringSecurityDescriptorW(sd, 1, 4, ctypes.byref(text), None):
                sddl = text.value
                W.k.LocalFree(ctypes.cast(text, ctypes.c_void_p))
        finally:
            W.k.LocalFree(sd)
    finally:
        W.k.LocalFree(sid)
    return {"mechanism": "WINDOWS_DACL_EXPLICIT_DENY_EVERYONE_WRITE_DATA_APPEND_DATA",
            "denied": explicit and all(v == "ACCESS_DENIED" for v in functional.values()),
            "explicit_deny_ace_everyone": explicit, "plain_open_for_write": functional, "sddl": sddl}


def deny_legacy_journal_writes(journal) -> None:
    """Close the journal by name to every writer that does not use backup semantics."""
    journal = pathlib.Path(journal)
    require_no_link_chain(journal, "LEGACY_JOURNAL")
    if os.name == "nt":
        _win_deny_journal_writes(journal)
    else:
        os.chmod(journal, 0o444)


def legacy_journal_write_denial(journal) -> dict:
    """Evidence that a plain (frozen) open of the journal for writing is refused."""
    import stat
    journal = pathlib.Path(journal)
    require_no_link_chain(journal, "LEGACY_JOURNAL")
    if os.name == "nt":
        return _win_write_denial(journal)
    mode = stat.S_IMODE(os.lstat(journal).st_mode)
    return {"mechanism": "POSIX_TEST_HOST_MODE_0444_WITHOUT_CAP_DAC_OVERRIDE", "denied": mode & 0o222 == 0,
            "mode": oct(mode)}


def require_legacy_journal_cut_enforced(journal) -> dict:
    evidence = legacy_journal_write_denial(journal)
    if not evidence["denied"]:
        raise RuntimeError("LEGACY_JOURNAL_CUT_NOT_ENFORCED")
    return evidence


def probe_journal_at_cut(journal):
    """(bytes, [dev, ino]) read while no write handle/descriptor can exist, or None if one is open now."""
    journal = pathlib.Path(journal)
    if os.name == "nt":
        try:
            raw, ident = read_pinned_regular(journal, "LEGACY_JOURNAL_CUT_PROBE")  # GENERIC_READ, FILE_SHARE_READ
        except RuntimeError as exc:
            if isinstance(exc.__cause__, OSError) and exc.__cause__.errno == 32:  # ERROR_SHARING_VIOLATION
                return None
            raise
        return raw, [ident[0], ident[1]]
    import errno
    import fcntl
    import signal
    import stat
    import threading
    require_no_link_chain(journal, "LEGACY_JOURNAL_CUT_PROBE")
    fd = os.open(journal, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    restore = None
    try:
        if threading.current_thread() is threading.main_thread():
            restore = signal.signal(signal.SIGIO, signal.SIG_IGN)
        try:
            fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_RDLCK)
        except OSError as exc:
            if exc.errno in (errno.EAGAIN, errno.EBUSY):
                return None
            raise RuntimeError("LEGACY_JOURNAL_CUT_PROBE_LEASE:" + str(exc)) from exc
        try:
            st = os.fstat(fd)
            if not stat.S_ISREG(st.st_mode):
                raise RuntimeError("LEGACY_JOURNAL_CUT_PROBE_NOT_REGULAR")
            chunks = []
            while True:
                chunk = os.read(fd, 1 << 20)
                if not chunk:
                    break
                chunks.append(chunk)
            raw = b"".join(chunks)
            if len(raw) != os.fstat(fd).st_size:
                raise RuntimeError("LEGACY_JOURNAL_CUT_PROBE_CHANGED")
        finally:
            fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
        return raw, [st.st_dev, st.st_ino]
    finally:
        if restore is not None:
            signal.signal(signal.SIGIO, restore)
        os.close(fd)


def require_legacy_journal_cut(state_path, marker_raw: bytes) -> tuple:
    """The cut record of this fence, the journal it names and the journal bytes at the cut."""
    import stat
    state_path = pathlib.Path(state_path)
    fence = legacy_entry_fence_path(state_path)
    raw, _ = read_pinned_regular(fence / LEGACY_JOURNAL_CUT_RECORD, "LEGACY_JOURNAL_CUT_RECORD")
    try:
        record = json.loads(raw.decode("ascii"))
    except ValueError:
        raise RuntimeError("LEGACY_JOURNAL_CUT_RECORD_JSON") from None
    at = record.get("journal_at_cut") if isinstance(record, dict) else None
    if (not isinstance(record, dict) or record.get("schema") != LEGACY_JOURNAL_CUT_SCHEMA
            or record.get("state_name") != state_path.name or record.get("journal_name") != LEGACY_JOURNAL_NAME
            or record.get("fence_marker_sha256") != _sha(marker_raw) or not isinstance(at, dict)
            or not isinstance(at.get("bytes"), int) or at["bytes"] < 0 or not isinstance(at.get("sha256"), str)
            or not isinstance(record.get("journal_identity"), list) or len(record["journal_identity"]) != 2):
        raise RuntimeError("LEGACY_JOURNAL_CUT_RECORD_CONTENT")
    journal = legacy_journal_path(state_path)
    require_no_link_chain(journal, "LEGACY_JOURNAL")
    st = os.lstat(journal)
    if not stat.S_ISREG(st.st_mode):
        raise RuntimeError("LEGACY_JOURNAL_NOT_REGULAR")
    if [st.st_dev, st.st_ino] != record["journal_identity"]:
        raise RuntimeError("LEGACY_JOURNAL_CUT_IDENTITY")
    require_legacy_journal_cut_enforced(journal)
    current, ident = read_pinned_regular(journal, "LEGACY_JOURNAL")
    if [ident[0], ident[1]] != record["journal_identity"]:
        raise RuntimeError("LEGACY_JOURNAL_CUT_IDENTITY")
    prefix = current[:at["bytes"]]
    if len(prefix) != at["bytes"] or _sha(prefix) != at["sha256"]:
        raise RuntimeError("LEGACY_JOURNAL_CUT_PREFIX_CHANGED")
    return record, prefix


def legacy_runs_in_journal(raw: bytes) -> list:
    """Every run that logged STARTED (frozen execute: before any node effect), with its PID and first instant."""
    import datetime
    import re
    runs = {}
    for number, line in enumerate(raw.splitlines(), 1):
        try:
            rec = json.loads(line)
        except ValueError:
            raise RuntimeError("LEGACY_JOURNAL_LINE_NOT_JSON:" + str(number)) from None
        if not isinstance(rec, dict):
            raise RuntimeError("LEGACY_JOURNAL_LINE_NOT_OBJECT:" + str(number))
        if rec.get("phase") != "STARTED":
            continue
        run_id = rec.get("run_id")
        match = re.fullmatch(LEGACY_RUN_ID_PATTERN, run_id) if isinstance(run_id, str) else None
        if match is None:
            raise RuntimeError("LEGACY_RUN_ID_UNREADABLE:" + str(number))
        try:
            when = datetime.datetime.fromisoformat(rec["ts"])
            if when.tzinfo is None:
                raise ValueError("naive")
        except (KeyError, TypeError, ValueError):
            raise RuntimeError("LEGACY_STARTED_TS_UNREADABLE:" + str(number)) from None
        started_ns = (when - datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc)) // datetime.timedelta(microseconds=1) * 1000
        run = runs.setdefault(run_id, {"run_id": run_id, "pid": int(match.group(1)), "first_started_ns": started_ns,
                                       "first_started_line": number, "started_lines": 0, "nodes": []})
        if started_ns < run["first_started_ns"]:
            run["first_started_ns"], run["first_started_line"] = started_ns, number
        run["started_lines"] += 1
        if rec.get("node") not in run["nodes"]:
            run["nodes"].append(rec.get("node"))
    return [runs[k] for k in sorted(runs)]


def observe_process(pid: int) -> tuple:
    """(state, creation_unix_ns) of the process now holding this PID: ABSENT, EXITED, LIVE or UNREADABLE:<why>."""
    if os.name == "nt":
        W = _Win32()
        handle = W.k.OpenProcess(0x1000 | 0x00100000, False, pid)  # QUERY_LIMITED_INFORMATION | SYNCHRONIZE
        if not handle:
            error = W.error()
            return ("ABSENT", None) if error == 87 else ("UNREADABLE:" + str(error), None)
        try:
            if W.k.WaitForSingleObject(handle, 0) == 0:
                return "EXITED", None
            times = [W.ctypes.c_ulonglong() for _ in range(4)]
            if not W.k.GetProcessTimes(handle, *(W.ctypes.byref(t) for t in times)):
                return "UNREADABLE:" + str(W.error()), None
            return "LIVE", (times[0].value - _FILETIME_UNIX_EPOCH) * 100
        finally:
            W.k.CloseHandle(handle)
    try:
        with open("/proc/%d/stat" % pid, "rb") as f:
            text = f.read().decode("ascii", "replace")
        with open("/proc/stat", "rb") as f:
            btime = int(next(l for l in f.read().decode("ascii").splitlines() if l.startswith("btime ")).split()[1])
    except FileNotFoundError:
        return "ABSENT", None
    except (OSError, StopIteration, ValueError) as exc:
        return "UNREADABLE:" + type(exc).__name__, None
    fields = text[text.rindex(")") + 2:].split()
    if fields[0] in ("Z", "X"):
        return "EXITED", None
    return "LIVE", (btime * 1_000_000_000 + int(fields[19]) * 1_000_000_000 // os.sysconf("SC_CLK_TCK"))


def classify_legacy_run(run: dict, observation: tuple, self_pid: int) -> str:
    state, created_ns = observation
    if run["pid"] == self_pid:
        return "GONE_PID_IS_THIS_PROCESS"
    if state == "ABSENT":
        return "GONE_NO_PROCESS"
    if state == "EXITED":
        return "GONE_EXITED"
    if state == "LIVE":
        if created_ns > run["first_started_ns"] + LEGACY_DRAIN_CLOCK_MARGIN_NS:
            return "GONE_PID_REUSED_BY_LATER_PROCESS"
        return "POSSIBLY_ALIVE"
    return "UNREADABLE"


def legacy_drain(raw_at_cut: bytes, observe=observe_process) -> dict:
    runs = legacy_runs_in_journal(raw_at_cut)
    for run in runs:
        observation = observe(run["pid"])
        run["observation"] = list(observation)
        run["verdict"] = classify_legacy_run(run, observation, os.getpid())
    open_runs = [r for r in runs if not r["verdict"].startswith("GONE_")]
    return {"status": "NOT_DRAINED" if open_runs else "DRAINED", "runs": runs,
            "not_drained": [r["run_id"] + "/" + str(r["pid"]) + "/" + r["verdict"] for r in open_runs],
            "clock_margin_seconds": LEGACY_DRAIN_CLOCK_MARGIN_NS // 1_000_000_000,
            "rule": "every run with a STARTED line in the journal at the cut has a gone process identity"}


def require_legacy_entry_fence(state_path) -> dict:
    """CDT21 F-01 / F-01R1: fail closed unless the legacy cut of this STATE is complete and drained.

    Fence directory and marker (no new frozen State, no frozen STATE write), cut record bound to the
    marker, the journal identity and its bytes at the cut, the journal still closed to plain writers
    and still beginning with those bytes, and no legacy run of the journal at the cut still running.
    """
    state_path = pathlib.Path(state_path)
    marker_raw = require_legacy_entry_fence_marker(state_path)
    _, prefix = require_legacy_journal_cut(state_path, marker_raw)
    drain = legacy_drain(prefix)
    if drain["status"] != "DRAINED":
        raise RuntimeError("LEGACY_RUN_POSSIBLY_ACTIVE:" + ",".join(drain["not_drained"]))
    return drain


def append_admitted_journal_line(journal, render) -> bytes:
    """Append render(prev_line_sha256) exactly as frozen State.log would, through the admitted writer.

    Windows: FILE_READ_DATA|FILE_APPEND_DATA with backup semantics, SeRestorePrivilege enabled only on a
    thread impersonation token and only for this open, no write sharing while the line is appended.
    POSIX test hosts: a writer with CAP_DAC_OVERRIDE (the 0444 model).  Returns the appended line.
    """
    journal = pathlib.Path(journal)
    require_no_link_chain(journal, "ADMITTED_JOURNAL")
    if os.name == "nt":
        import msvcrt
        W = _Win32()
        ctypes, w = W.ctypes, W.w

        class LUID_AND_ATTRIBUTES(ctypes.Structure):
            _fields_ = [("LowPart", w.DWORD), ("HighPart", w.LONG), ("Attributes", w.DWORD)]

        class TOKEN_PRIVILEGES(ctypes.Structure):
            _fields_ = [("PrivilegeCount", w.DWORD), ("Privileges", LUID_AND_ATTRIBUTES * 1)]

        token, imp = w.HANDLE(), w.HANDLE()
        if not W.a.OpenProcessToken(W.k.GetCurrentProcess(), 0x0002 | 0x0008, ctypes.byref(token)):
            raise RuntimeError("ADMITTED_JOURNAL_TOKEN:" + str(W.error()))
        try:
            if not W.a.DuplicateTokenEx(token, 0x0020 | 0x0008 | 0x0004, None, 2, 2, ctypes.byref(imp)):
                raise RuntimeError("ADMITTED_JOURNAL_TOKEN_DUPLICATE:" + str(W.error()))
            try:
                tp = TOKEN_PRIVILEGES()
                tp.PrivilegeCount = 1
                tp.Privileges[0].Attributes = 0x2  # SE_PRIVILEGE_ENABLED
                if not W.a.LookupPrivilegeValueW(None, "SeRestorePrivilege", ctypes.byref(tp.Privileges[0])):
                    raise RuntimeError("ADMITTED_JOURNAL_PRIVILEGE_LOOKUP:" + str(W.error()))
                ctypes.set_last_error(0)
                if not W.a.AdjustTokenPrivileges(imp, False, ctypes.byref(tp), 0, None, None) or W.error() == 1300:
                    raise RuntimeError("ADMITTED_JOURNAL_RESTORE_PRIVILEGE_UNAVAILABLE")
                if not W.a.SetThreadToken(None, imp):
                    raise RuntimeError("ADMITTED_JOURNAL_IMPERSONATE:" + str(W.error()))
                try:
                    # FILE_READ_DATA|FILE_APPEND_DATA|FILE_READ_ATTRIBUTES|SYNCHRONIZE, FILE_SHARE_READ, OPEN_EXISTING,
                    # FILE_FLAG_BACKUP_SEMANTICS|FILE_FLAG_OPEN_REPARSE_POINT
                    handle = W.k.CreateFileW(str(journal), 0x1 | 0x4 | 0x80 | 0x00100000, 1, None, 3,
                                             0x02000000 | 0x00200000, None)
                    error = W.error()
                finally:
                    if not W.a.RevertToSelf():
                        raise RuntimeError("ADMITTED_JOURNAL_REVERT:" + str(W.error()))
            finally:
                W.k.CloseHandle(imp)
        finally:
            W.k.CloseHandle(token)
        if handle in (None, W.invalid):
            raise RuntimeError("ADMITTED_JOURNAL_OPEN:" + str(error))
        try:
            fd = msvcrt.open_osfhandle(handle, os.O_RDWR | os.O_APPEND | os.O_BINARY)
        except BaseException:
            W.k.CloseHandle(handle)
            raise
    else:
        try:
            fd = os.open(journal, os.O_RDWR | os.O_APPEND | getattr(os, "O_NOFOLLOW", 0))
        except OSError as exc:
            raise RuntimeError("ADMITTED_JOURNAL_OPEN:" + str(exc)) from exc
    try:
        before = os.fstat(fd)
        chunks = []
        while True:
            chunk = os.read(fd, 1 << 20)
            if not chunk:
                break
            chunks.append(chunk)
        raw = b"".join(chunks)
        if len(raw) != before.st_size:
            raise RuntimeError("ADMITTED_JOURNAL_CHANGED_DURING_READ")
        lines = raw.splitlines()
        line = render(_sha(lines[-1]) if lines else "")
        view = memoryview(line)
        while view:
            view = view[os.write(fd, view):]
        os.fsync(fd)
        after = os.fstat(fd)
        if (after.st_dev, after.st_ino, after.st_size) != (before.st_dev, before.st_ino, len(raw) + len(line)):
            raise RuntimeError("ADMITTED_JOURNAL_APPEND_READBACK")
        return line
    finally:
        os.close(fd)


def validate_d4_start(package: pathlib.Path, python: str, authority: dict) -> AdmittedStart:
    """Read-only start-boundary check; never instantiate frozen State here."""
    config_path = package / "config" / "STAGE_A_SEALED_VALUES_V001.json"
    if config_path.resolve() != pathlib.Path(authority["config_path"]).resolve():
        raise RuntimeError("ADAPTER_ENTRY_CONFIG_PATH")
    raw, config_ident = read_pinned_regular(config_path, "ADAPTER_ENTRY_CONFIG")
    config_sha = _sha(raw)
    if config_sha != authority.get("config_sha256"):
        raise RuntimeError("ADAPTER_ENTRY_CONFIG_SHA")
    config = json.loads(raw)
    if (pathlib.Path(python).resolve() != pathlib.Path(sys.executable).resolve()
        or sha_file(pathlib.Path(python)) != config.get("python_exe_sha256")):
        raise RuntimeError("ADAPTER_ENTRY_PYTHON_IDENTITY")
    control_root = pathlib.Path(config["control_root"])
    state_path = control_root / "state" / "STATE.json"
    require_no_cas_debris(state_path)
    require_legacy_entry_fence(state_path)
    state_raw, state_ident = read_pinned_regular(state_path, "ADAPTER_ENTRY_STATE")
    validate_d4_state(json.loads(state_raw))
    return AdmittedStart(state_path=state_path, control_root=control_root, config_path=config_path,
                         config_raw=raw, config_sha256=config_sha, config_ident=config_ident,
                         state_raw=state_raw, state_ident=state_ident)


def validate_d4_state(state: dict) -> None:
    # --until is only an upper bound in the frozen runner. Earlier next_node
    # values would dispatch earlier nodes; a later value could return false PASS.
    if (state.get("schema") != "TICKSTORE_ORCH_STATE_V001"
        or state.get("next_node") != "D4"
        or state.get("status") not in ("FAIL", "SAFE_STOP")
        or not isinstance(state.get("completed"), list)
        or "D4" in state["completed"]
        or state.get("canary_scratch_cert") is not None):
        raise RuntimeError("ADAPTER_ENTRY_STATE_NOT_D4_ONLY")


def _fsync_directory(directory: pathlib.Path) -> None:
    try:
        fd = os.open(str(directory), os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except (OSError, PermissionError):
        pass


def acquire_state_boundary(state_path: pathlib.Path):
    """B06R2: one D4 entry per STATE for the whole process lifetime.

    Windows: named kernel mutex (same Global\\ pattern as the FULL lease); it
    disappears with the process. Elsewhere (test hosts): flock on a lock file
    in the temporary directory, also released by process exit.
    Returns a callable that releases the boundary (tests only).
    """
    key = _sha(_lexical(state_path.resolve()).encode("utf-8"))
    if os.name == "nt":
        import ctypes
        import ctypes.wintypes as w
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.CreateMutexW.argtypes = [w.HANDLE, w.BOOL, w.LPCWSTR]
        k.CreateMutexW.restype = w.HANDLE
        k.CloseHandle.argtypes = [w.HANDLE]
        k.CloseHandle.restype = w.BOOL
        ctypes.set_last_error(0)
        handle = k.CreateMutexW(None, False, "Global\\TICKSTORE_D4_ENTRY_STATE_" + key)
        if not handle:
            raise RuntimeError("ADAPTER_ENTRY_STATE_BOUNDARY_CREATE:" + str(ctypes.get_last_error()))
        if ctypes.get_last_error() == 183:
            k.CloseHandle(handle)
            raise RuntimeError("ADAPTER_ENTRY_STATE_BOUNDARY_BUSY")
        return lambda: k.CloseHandle(handle)
    import fcntl
    import tempfile
    f = open(os.path.join(tempfile.gettempdir(), "TICKSTORE_D4_ENTRY_STATE_" + key + ".lock"), "a+b")
    try:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        raise RuntimeError("ADAPTER_ENTRY_STATE_BOUNDARY_BUSY") from None
    return f.close


def guard_frozen_state_reads(namespace: dict, admitted, *, state_validator=validate_d4_state,
                             transition_validator=None) -> None:
    """Bind every frozen State/config consumption to the objects admitted for D4_ONLY.

    B06-01 (B06R2): STATE is pinned by identity and version (dev, ino, size,
    mtime_ns, SHA-256) from admission. Constructing State never writes STATE.
    Every journal append and every STATE write first re-verifies the pin; a
    STATE write is a compare-and-swap (rename current -> backup, verify that
    the moved entry is the pinned one, publish with create-if-absent). A
    vanished, replaced or newer STATE is preserved and the entry fails closed.
    One D4 entry per STATE holds a process-lifetime boundary.
    B06-02 (B06R2): the configuration is recognised by its admitted lexical
    path as well as its resolved path, so retargeting the name cannot fall
    back to a free read; links/reparse points anywhere in the chain, or any
    identity/byte drift, block. Consumers receive only the admitted buffer.
    Accepts AdmittedStart, or a STATE path for State-only callers (the pin is
    then taken at the first construction).
    CDT21 F-01/F-01R1: with AdmittedStart the complete, drained legacy cut is
    required at admission, before every STATE commit and before every journal
    append, and the journal is appended through append_admitted_journal_line.
    """
    import uuid
    if isinstance(admitted, AdmittedStart):
        state_path, config = pathlib.Path(admitted.state_path), admitted
        pin = {"sha": None if admitted.state_raw is None else _sha(admitted.state_raw), "ident": admitted.state_ident}
    else:
        state_path, config = pathlib.Path(admitted), None
        pin = {"sha": None, "ident": None}
    expected = state_path.resolve()
    state_lexical = _lexical(state_path)
    admitted_root = state_path.parent.parent.resolve()
    if config is not None and config.control_root.resolve() != admitted_root:
        raise RuntimeError("ADAPTER_ENTRY_ADMITTED_ROOT_MISMATCH")
    if config is not None:
        # CDT21 F-01: an admitted writer (D4 entry, stage continuation) requires the legacy entry fence.
        require_legacy_entry_fence(state_path)
    config_expected = config.config_path.resolve() if config is not None else None
    config_lexical = _lexical(config.config_path) if config is not None else None
    original_atomj = namespace["atomj"]
    original_read = namespace["rj"]
    boundary = {"release": None}

    def is_state(path) -> bool:
        return _lexical(path) == state_lexical or pathlib.Path(path).resolve() == expected

    def is_config(path) -> bool:
        return config is not None and (_lexical(path) == config_lexical or pathlib.Path(path).resolve() == config_expected)

    def verify_pin(stage: str) -> bytes:
        try:
            raw, ident = read_pinned_regular(state_path, "ADAPTER_ENTRY_STATE")
        except RuntimeError as exc:
            raise RuntimeError("ADAPTER_ENTRY_STATE_CONCURRENT_CHANGE:" + stage + ":" + str(exc)) from None
        if _sha(raw) != pin["sha"] or ident != pin["ident"]:
            raise RuntimeError("ADAPTER_ENTRY_STATE_CONCURRENT_CHANGE:" + stage)
        return raw

    def guarded_read(path):
        if is_config(path):
            try:
                raw, ident = read_pinned_regular(path, "ADAPTER_ENTRY_CONFIG")
            except RuntimeError:
                raise RuntimeError("ADAPTER_ENTRY_CONFIG_DRIFT") from None
            if _sha(raw) != config.config_sha256 or (config.config_ident is not None and ident != config.config_ident):
                raise RuntimeError("ADAPTER_ENTRY_CONFIG_DRIFT")
            return json.loads(config.config_raw.decode("utf-8"))
        if is_state(path):
            if pin["sha"] is None:
                raise RuntimeError("ADAPTER_ENTRY_STATE_NOT_PINNED")
            obj = json.loads(verify_pin("READ").decode("utf-8"))
            state_validator(obj)
            return obj
        return original_read(path)

    def rename_with_retry(src: pathlib.Path, dst: pathlib.Path) -> None:
        import time
        for attempt in range(10):
            try:
                os.rename(src, dst)  # Windows: MoveFileExW without REPLACE_EXISTING
                return
            except PermissionError:
                if attempt == 9:
                    raise RuntimeError("ADAPTER_ENTRY_STATE_COMMIT_BUSY") from None
                time.sleep(0.1)

    def commit_state(obj) -> None:
        data = namespace["jb"](obj)
        if config is not None:
            require_legacy_entry_fence(state_path)  # CDT21 F-01: no admitted commit while the legacy route is open
        previous_raw = verify_pin("COMMIT")
        if transition_validator is not None:
            transition_validator(json.loads(previous_raw), obj)
        tag = str(os.getpid()) + "." + uuid.uuid4().hex
        partial = state_path.with_name(state_path.name + ".cas-new." + tag)
        backup = state_path.with_name(state_path.name + ".cas-old." + tag)
        intent = state_path.with_name(state_path.name + ".cas-intent." + tag)
        with open(partial, "xb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        # B06R3: durable record of the confirmed (prev) and target (new) versions,
        # so an interruption can be resolved deterministically by the recovery tool.
        intent_obj = {"schema": "TICKSTORE_D4_STATE_CAS_INTENT_V001", "tag": tag, "state_name": state_path.name,
                      "prev_sha256": pin["sha"], "prev_identity": list(pin["ident"]), "new_sha256": _sha(data)}
        with open(intent, "xb") as f:
            f.write((json.dumps(intent_obj, sort_keys=True, separators=(",", ":")) + "\n").encode("ascii"))
            f.flush()
            os.fsync(f.fileno())
        _fsync_directory(state_path.parent)
        cleanup_intent = True
        try:
            try:
                rename_with_retry(state_path, backup)
            except FileNotFoundError:
                raise RuntimeError("ADAPTER_ENTRY_STATE_CONCURRENT_CHANGE:VANISHED_BEFORE_COMMIT") from None
            try:
                moved_raw, moved_ident = read_pinned_regular(backup, "ADAPTER_ENTRY_STATE_BACKUP")
                # A rename keeps device, file id, size and mtime: anything else is not the pinned STATE.
                swapped = _sha(moved_raw) != pin["sha"] or moved_ident != pin["ident"]
            except RuntimeError:
                swapped = True
            if swapped:
                try:
                    os.link(backup, state_path)  # put the concurrent winner back, never clobbering
                    os.unlink(backup)
                except OSError:
                    cleanup_intent = False  # leave the evidence for the recovery tool
                raise RuntimeError("ADAPTER_ENTRY_STATE_CONCURRENT_CHANGE:REPLACED_BEFORE_COMMIT")
            try:
                os.link(partial, state_path)  # create-if-absent: a STATE created meanwhile is preserved
            except FileExistsError:
                cleanup_intent = False  # confirmed version stays in cas-old; recovery decides
                raise RuntimeError("ADAPTER_ENTRY_STATE_CONCURRENT_CHANGE:RECREATED_DURING_COMMIT") from None
            os.unlink(partial)
            new_raw, new_ident = read_pinned_regular(state_path, "ADAPTER_ENTRY_STATE")
            if new_raw != data:
                raise RuntimeError("ADAPTER_ENTRY_STATE_COMMIT_READBACK")
            with open(state_path, "rb+") as committed:
                os.fsync(committed.fileno())
            _fsync_directory(state_path.parent)
            pin.update(sha=_sha(data), ident=new_ident)
            os.unlink(backup)
        finally:
            try:
                os.unlink(partial)
            except OSError:
                pass
            if cleanup_intent and not os.path.lexists(backup):
                try:
                    os.unlink(intent)
                    _fsync_directory(state_path.parent)
                except OSError:
                    pass

    def guarded_atomj(path, obj):
        if is_state(path):
            if pin["sha"] is None or boundary["release"] is None:
                raise RuntimeError("ADAPTER_ENTRY_STATE_WRITE_OUTSIDE_BOUNDARY")
            return commit_state(obj)
        return original_atomj(path, obj)

    frozen_state = namespace["State"]

    class D4OnlyState(frozen_state):
        def __init__(self, root):
            root = pathlib.Path(root)
            if root.resolve() != admitted_root:
                raise RuntimeError("ADAPTER_ENTRY_STATE_ROOT_NOT_ADMITTED")
            require_no_cas_debris(root / "state" / "STATE.json")
            raw, ident = read_pinned_regular(root / "state" / "STATE.json", "ADAPTER_ENTRY_STATE")
            obj = json.loads(raw.decode("utf-8"))
            state_validator(obj)
            if pin["sha"] is None:
                pin.update(sha=_sha(raw), ident=ident)
            elif _sha(raw) != pin["sha"] or ident != pin["ident"]:
                raise RuntimeError("ADAPTER_ENTRY_STATE_CHANGED_SINCE_ADMISSION")
            if boundary["release"] is None:
                boundary["release"] = acquire_state_boundary(state_path)
                verify_pin("BOUNDARY")
            # Same attribute layout and directories as frozen State.__init__;
            # unlike it, no STATE rewrite here (the admitted bytes stay in place).
            self.root = root; self.sd = root / "state"; self.runs = root / "runs"
            self.inbox = root / "inbox"; self.packs = root / "packs"; self.ev = root / "evidence"
            for p in (self.sd, self.runs, self.inbox, self.packs, self.ev):
                p.mkdir(parents=True, exist_ok=True)
            self.sp = self.sd / "STATE.json"; self.jp = self.sd / "STATE_JOURNAL.jsonl"
            self.d = obj

        def log(self, node, phase, **x):
            verify_pin("JOURNAL")
            if config is None:
                return frozen_state.log(self, node, phase, **x)
            # CDT21 F-01R1: behind the cut the frozen open(journal, "ab") is refused to everyone; an admitted
            # writer appends the same line (frozen jb/now, same prev_line_sha256 chain) through the cut.
            require_legacy_entry_fence(state_path)
            if _lexical(self.jp) != _lexical(legacy_journal_path(state_path)):
                raise RuntimeError("ADAPTER_ENTRY_JOURNAL_NOT_ADMITTED")
            jb, now = namespace["jb"], namespace["now"]
            append_admitted_journal_line(self.jp, lambda prev: jb(
                {"ts": now(), "node": node, "phase": phase, "prev_line_sha256": prev, **x}).rstrip(b"\n") + b"\n")

    def release_boundary():
        if boundary["release"] is not None:
            boundary["release"]()
            boundary["release"] = None

    namespace["rj"] = guarded_read
    namespace["atomj"] = guarded_atomj
    namespace["State"] = D4OnlyState
    namespace["_TICKSTORE_D4_ENTRY_RELEASE_STATE_BOUNDARY"] = release_boundary


def pin_frozen_engine_load(namespace: dict, release_path: pathlib.Path, release_raw: bytes) -> None:
    """B06-02 (same principle for code): O loads the engine from the hashed buffer."""
    expected = release_path.resolve()

    def pinned_load_engine(p):
        if pathlib.Path(p).resolve() != expected:
            raise RuntimeError("ADAPTER_ENTRY_ENGINE_PATH_NOT_ADMITTED")
        ns = {"__name__": "tickstore_engine_library", "__file__": str(p)}
        exec(compile(release_raw, str(p), "exec"), ns, ns)
        return namespace["types"].SimpleNamespace(**ns)

    namespace["load_engine"] = pinned_load_engine


def main() -> int:
    args = parse_d4_arguments(sys.argv[1:])
    package = pathlib.Path(args.package)
    adapter_dir = pathlib.Path(os.environ.get("TICKSTORE_RUNTIME_LOCATOR_ADAPTER_DIR", pathlib.Path(__file__).resolve().parent))
    receipt_path = pathlib.Path(os.environ["TICKSTORE_G_CA_RUNTIME_LOCATOR_RECEIPT"])
    binding_path = adapter_dir / "RUNTIME_LOCATOR_ADAPTER_BINDING.json"
    adapter_path = adapter_dir / "runtime_locator_adapter.py"
    inline_entry = adapter_dir / "runtime_locator_inline_entry.py"
    adapted_loader = adapter_dir / "INLINE_ROOT_LOADER_V004_R1R1_ADAPTER.ps1"
    adapted_launch = adapter_dir / "Launch-TickstoreBundle-Adapter.ps1"
    frozen_orchestrator = package / "modules" / "orchestrator.py"
    frozen_release = package / "engine" / "tickstore_publisher_recovery_v004_release.py"

    binding = json.loads(binding_path.read_text(encoding="utf-8"))
    if binding.get("schema") != "TICKSTORE_G_CA_RUNTIME_LOCATOR_ADAPTER_BINDING_V002":
        raise RuntimeError("ADAPTER_ENTRY_BINDING_SCHEMA")
    checks = (
        (frozen_release, "frozen_release_sha256", "ADAPTER_ENTRY_FROZEN_RELEASE"),
        (frozen_orchestrator, "frozen_orchestrator_sha256", "ADAPTER_ENTRY_FROZEN_ORCHESTRATOR"),
        (adapter_path, "adapter_sha256", "ADAPTER_ENTRY_ADAPTER"),
        (inline_entry, "inline_entry_sha256", "ADAPTER_ENTRY_INLINE"),
        (adapted_loader, "adapted_loader_sha256", "ADAPTER_ENTRY_LOADER"),
        (adapted_launch, "adapted_launch_sha256", "ADAPTER_ENTRY_LAUNCH"),
    )
    admitted_code = {}
    for path, key, label in checks:
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest().upper() != str(binding.get(key, "")).upper():
            raise RuntimeError(label + "_SHA")
        admitted_code[key] = raw
    if not receipt_path.is_file():
        raise RuntimeError("ADAPTER_ENTRY_LOCATOR_RECEIPT_MISSING")
    identity = load_run_identity(binding)
    admitted = validate_d4_start(package, args.python, identity.ra)
    validate_first_admission_commit(identity.ra, admitted.state_raw, admitted.state_path)

    adapter_ns = {"__name__": "tickstore_runtime_locator_adapter_orchestrator", "__file__": str(adapter_path)}
    adapter_raw = admitted_code["adapter_sha256"]
    exec(compile(adapter_raw, str(adapter_path), "exec"), adapter_ns, adapter_ns)
    adapter_ns["validate_binding"](binding)
    receipt = json.loads(receipt_path.read_text(encoding="utf-8-sig"))
    adapter_ns["validate_locator_receipt"](receipt, binding)
    # B06R3 (option B): resume only when anchor, RUN_AUTHORITY, run_id, signed checkpoint,
    # STATE and VSS generation are proven to be one execution.
    reconcile_resume_identity(identity, binding, admitted, receipt, admitted_code["frozen_release_sha256"],
                              os.environ.get("TICKSTORE_D4_RUN_HMAC_KEY_HEX", ""))

    orch_ns = {"__name__": "tickstore_frozen_orchestrator_with_runtime_adapter", "__file__": str(frozen_orchestrator)}
    orch_raw = admitted_code["frozen_orchestrator_sha256"]
    exec(compile(orch_raw, str(frozen_orchestrator), "exec"), orch_ns, orch_ns)
    adapter_ns["install_orchestrator_namespace"](orch_ns, binding, adapter_dir, receipt_path)
    guard_frozen_state_reads(orch_ns, admitted)
    pin_frozen_engine_load(orch_ns, frozen_release, admitted_code["frozen_release_sha256"])
    return int(orch_ns["main"]())


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RuntimeError, OSError, ValueError, KeyError) as exc:
        print("ORCHESTRATOR_ADAPTER_BLOCKED=" + str(exc), flush=True)
        raise SystemExit(2)
