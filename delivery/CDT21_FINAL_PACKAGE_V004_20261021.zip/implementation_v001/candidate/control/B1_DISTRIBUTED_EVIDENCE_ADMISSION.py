#!/usr/bin/env python3
"""Read-only, independently pinned B1 *evidence* checker; NEVER a formal gate issuer.

Requires the four historical native returns, the exact B1 bundle, and the exact
source-only FULL. All evidence must be same frozen C5-R44 bytes.
"""
from __future__ import annotations
import argparse, hashlib, io, json, re, sys, zipfile
from pathlib import Path

EXPECTED = {
    'evidence': '2D9DBA00D3282E2899672722DE9E6B856F0BC8E9F29657FFC24F1149FB4E0CAC',
    'b1_bundle': '0B7FC2ACAA59A4D11C8B43B4EAB8FAEE9FC067C3D7F7591524811D01FF0CCDFA',
    'full': 'C9C4F01F0EF2E2748A4063617E7896DDE767F9C5147644DB1C4D77DC78AC167F',
    'portable105': '98015C0B0B47A0D2421CC442AF21A0982EF13E622538C71A797685FC444543C3',
    'portable1': 'E46C45131398EEA6CFA213D7787F5C0E40BCC9DB47CF9E94EDE232970575D3E8',
    'native14': '3DC92B6D6DB66886335FCBB25222F773CC64731B40DF992DFE88E1272C85E1CD',
    'native6': '4F4CBB5153EB61D7DC55F1E19CB21A51BC021969DBD196199E356E2EFFB07783',
    'policy_master': 'B215D4DFBC3A0387BA09EE5C3E097ED5D63384675D7E2E70BA2C88E0BF607EE0',
    'policy_head': '1F121E61D26EAF346FF9F05AF83DB8EE97ED672E8200369F04462D1A147F4B96',
    'runtime_manifest': 'C8194F27709FA031DC6B142043ED75D3E495F7F6B6DB50EF9B28A703C136AF03',
}
RETURNS = {
    'portable105': 'RETURNS/C5R44_DIAG_RETURN_CDT16_C5R44_DELTA_QUAL_20261015_142214_0b2615d8.zip',
    'portable1': 'RETURNS/C5R44_B1_ONE_TEST_RETURN.zip',
    'native14': 'RETURNS/C5R44_B1_NATIVE20_RETURN.zip',
    'native6': 'RETURNS/C5R44_B1_NATIVE6_RETURN.zip',
}

class Blocked(Exception):
    pass

def demand(test, label):
    if not test: raise Blocked(label)

def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

def strict_json(raw):
    def unique_pairs(pairs):
        d={}
        for k,v in pairs:
            demand(k not in d, 'DUPLICATE_JSON_KEY:'+k)
            d[k]=v
        return d
    return json.loads(raw.decode('utf-8'),object_pairs_hook=unique_pairs)

def opened(raw, label, limit=256):
    demand(len(raw)<10_000_000, 'ZIP_INPUT_OVERSIZE:'+label)
    try: z=zipfile.ZipFile(io.BytesIO(raw))
    except Exception as exc: raise Blocked('ZIP_UNREADABLE:'+label) from exc
    names=z.namelist()
    demand(len(names)<=limit and len(set(names))==len(names),'ZIP_CARDINALITY:'+label)
    demand(all(n and not n.startswith('/') and not n.startswith('../') and not n.startswith('\\') and '\\' not in n and '/..' not in n for n in names),'ZIP_PATH_ESCAPE:'+label)
    demand(sum(x.file_size for x in z.infolist())<20_000_000,'ZIP_UNCOMPRESSED_OVERSIZE:'+label)
    demand(z.testzip() is None,'ZIP_CRC:'+label)
    return z

def manifest(z, filename, label, prefix='', omit=None):
    m=strict_json(z.read(filename));items=m['files']
    demand(isinstance(items,list), 'MANIFEST_NOT_LIST:'+label)
    paths=[x['path'] for x in items]
    demand(len(paths)==len(set(paths)),'MANIFEST_DUP:'+label)
    available=set(z.namelist())-{filename} if omit is None else set(z.namelist())-set(omit)
    demand(set(paths)==available,'MANIFEST_SET:'+label)
    for x in items:
        d=z.read(x['path']);demand(len(d)==x['bytes'] and sha(d)==x['sha256'],'MANIFEST_BYTES:'+label+':'+x['path'])
    return len(items)

def assess(evidence, bundle, full):
    checks=[]
    def check(name, okay):
        demand(bool(okay),name);checks.append(name)
    for k,b in [('evidence',evidence),('b1_bundle',bundle),('full',full)]:
        check('PIN_'+k,sha(b)==EXPECTED[k])
    d=opened(evidence,'DOSSIER',20);bz=opened(bundle,'B1_BUNDLE',40);fz=opened(full,'FULL_PACKAGE',260)
    check('DOSSIER_FILE_SET',set(d.namelist())==set(RETURNS.values())|{
        'CDT16_C5R44_B1_126_COVERAGE_RECONCILIATION_20261015.json',
        'CDT16_C5R44_B1_NATIVE6_AND_COVERAGE_AUDIT_20261015.md',
        'CONTRACT/QUALIFICATION_CONTRACT_ORIGINAL.json',
        'CONTRACT/QUALIFICATION_CONTRACT_G5_R44.json',
        'AUDIT/REPRODUCE_B1_COVERAGE_RECONCILIATION.py'})
    check('FULL_MANIFEST',manifest(fz,'PACKAGE_MANIFEST.json','FULL')==len(fz.namelist())-1)
    runman=strict_json(fz.read('implementation_v001/RUNTIME_CODE_MANIFEST.json'))
    check('RUNTIME_FILE_COUNT',len(runman['files'])==137)
    for item in runman['files']:
        file='implementation_v001/candidate/'+item['path']
        check('RUNTIME_SHA:'+item['path'],file in fz.namelist() and sha(fz.read(file))==item['sha256'] and len(fz.read(file))==item['bytes'])
    check('BUNDLE_FINAL_EMBEDDED',sha(bz.read('FINAL/TICKSTORE_CDT16_FULL_C5R44_G5_CONTRACT_REBASED_SOURCE_ONLY_20261015.zip'))==EXPECTED['full'])
    p=strict_json(bz.read('qual/QUAL_PLAN.json'))['b1']
    check('R3_SHA',sha(bz.read(p['r3_archive']))==p['r3_archive_sha256'])
    r3=opened(bz.read(p['r3_archive']),'R3',500)
    check('HISTORIC_CONTRACT_SHA',sha(bz.read(p['contract']))==p['contract_sha256'])
    hc=strict_json(bz.read(p['contract']))
    check('HISTORIC_DOSSIER_IDENTICAL',d.read('CONTRACT/QUALIFICATION_CONTRACT_ORIGINAL.json')==bz.read(p['contract']))
    cc=fz.read('implementation_v001/candidate/control/QUALIFICATION_CONTRACT.json')
    check('MIGRATED_CONTRACT_SHA',sha(cc)==p['candidate_contract_sha256'])
    check('MIGRATED_DOSSIER_IDENTICAL',d.read('CONTRACT/QUALIFICATION_CONTRACT_G5_R44.json')==cc)
    migrated=strict_json(cc)
    check('MIGRATION_IDS_INTACT',migrated['required_tests']==hc['required_tests'])
    check('MIGRATION_POLICY_ID',migrated['policy_master_sha256']==EXPECTED['policy_master'] and migrated['policy_head_sha256']==EXPECTED['policy_head'] and migrated['policy_candidate_status']=='PROMOTED_R44_REVOCATION_ONLY')
    check('MIGRATION_PROOFS',len(set(migrated['required_target_proofs']))==6 and 'POWERLOSS_EMULATED' in migrated['required_target_proofs'] and 'CHECKPOINT_POWERLOSS_RECOVERY' not in migrated['required_target_proofs'])
    check('SIX_GATES_NOT_ISSUED',strict_json(d.read('CDT16_C5R44_B1_126_COVERAGE_RECONCILIATION_20261015.json'))['B1_FORMAL']=='NOT_ISSUED')
    check('OVERLAY_CARDINALITY',len(p['overlays'])==5)
    for ov in p['overlays']:
        check('OVERLAY_'+ov['target'],sha(r3.read(ov['target']))==ov['parent_sha256'] and sha(bz.read(ov['derived']))==ov['derived_sha256'])
    check('B1_CONTRACT_IDS',len(hc['required_tests'])==len(set(hc['required_tests']))==126)
    ret={}
    for key,rel in RETURNS.items():
        raw=d.read(rel);check('SOURCE_SHA_'+key,sha(raw)==EXPECTED[key]);z=opened(raw,key,24)
        check('RETURN_MANIFEST_'+key,manifest(z,'RETURN_MANIFEST.json',key)==len(z.namelist())-1)
        ret[key]=z
    r105=strict_json(ret['portable105'].read('B1/B1_HARNESS/RESULT.json'))
    r20=strict_json(ret['native14'].read('EVIDENCE/B1_HARNESS/RESULT.json'))
    r6=strict_json(ret['native6'].read('EVIDENCE/B1_HARNESS/RESULT.json'))
    one=strict_json(ret['portable1'].read('RECEIPT.json'))
    r20rc=strict_json(ret['native14'].read('RECEIPT.json'))
    r6rc=strict_json(ret['native6'].read('RECEIPT.json'))
    for name,r in [('portable105',r105),('native14',r20),('native6',r6)]:
        check('REPORT_IDENTITY_'+name,r['tested_code_unchanged'] is True and r['production_execution'] is False and r['code_manifest_sha256']==EXPECTED['runtime_manifest'] and r['platform'].startswith('Windows') and r['qualification_contract_satisfied'] is False)
        check('REPORT_SINGLE_ID_'+name,len({x['id'] for x in r['tests']})==len(r['tests']))
    check('PORTABLE_EXPECTED',r105['selection']=='PORTABLE' and r105['tests_expected']==106 and r105['totals']=={'tests_run':106,'failures':0,'errors':1,'skips':0} and r105['success'] is False)
    id0='test_first_admission_transaction.TransactionTests.test_reparse_resume_root_rejected'
    p105={x['id'] for x in r105['tests'] if x['status']=='PASS'}
    perr={x['id'] for x in r105['tests'] if x['status']!='PASS'}
    check('PORTABLE_105PLUS_ONE',len(p105)==105 and perr=={id0})
    check('ONE_PASS',one['test_id']==id0 and one['exit_code']==0 and one['tested_code_unchanged'] is True and one['status']=='PASS_SCOPED_NATIVE_SINGLE_TEST' and one['is_elevated'] is True and one['gate_verdict_issued'] is False)
    one_log=ret['portable1'].read('NATIVE_ONE_TEST.log').decode('utf8','replace')
    check('ONE_LOG',id0.split('.')[-1] in one_log and 'Ran 1 test' in one_log and '\nOK' in one_log)
    check('NATIVE20_RESULT',r20['selection']=='NATIVE' and r20['tests_expected']==20 and r20['totals']=={'tests_run':20,'failures':3,'errors':3,'skips':0} and r20['success'] is False)
    n14={x['id'] for x in r20['tests'] if x['status']=='PASS'}
    nfail={x['id'] for x in r20['tests'] if x['status']!='PASS'}
    check('NATIVE14PLUS6',len(n14)==14 and len(nfail)==6)
    check('NATIVE6_RESULT',r6['selection']=='NATIVE' and r6['tests_expected']==6 and r6['tests_not_run']==0 and r6['tests_interrupted']==0 and r6['success'] is True and r6['totals']=={'tests_run':6,'failures':0,'errors':0,'skips':0} and len(r6['tests'])==6)
    n6={x['id'] for x in r6['tests'] if x['status']=='PASS'}
    check('SIX_REMEDY_EXACT',nfail==n6)
    check('EXACT_126_UNION',p105|{id0}|n14|n6==set(hc['required_tests']) and len(p105|{id0}|n14|n6)==126)
    check('NO_OVERLAP',not (p105|{id0}) & (n14|n6) and not n14&n6)
    check('BUNDLE_LINKED',all(strict_json(ret[k].read('RECEIPT.json'))['b1_bundle_sha256']==EXPECTED['b1_bundle'] and strict_json(ret[k].read('RECEIPT.json'))['full_sha256']==EXPECTED['full'] for k in ('portable1','native14','native6')))
    check('NATIVE_ELEVATED',all(strict_json(ret[k].read('RECEIPT.json'))['is_elevated'] is True for k in ('portable1','native14','native6')))
    check('RETRY_CHAIN',r6rc['previous_return_sha256']==EXPECTED['portable105'] and r6rc['failed20_return_sha256']==EXPECTED['native14'] and r20rc['previous_return_sha256']==EXPECTED['portable105'] and one['previous_return_sha256']==EXPECTED['portable105'])
    check('NEGATIVE_SCOPE',all(strict_json(ret[k].read('RECEIPT.json'))['gate_verdict_issued'] is False for k in ('portable1','native14','native6')))
    check('EXACT_DIAGNOSTIC_LABELS',
        r20rc['status']=='BLOCKED_OR_FAIL' and r20rc['exit_code']==2
        and r6rc['status']=='PASS_SCOPED_NATIVE6_TESTS_NOT_B1_GATE' and r6rc['exit_code']==0
        and one['status']=='PASS_SCOPED_NATIVE_SINGLE_TEST' and one['exit_code']==0)
    check('INTEGRITY_REPORT_STATUS',r20rc['report_success'] is False and r6rc['report_success'] is True
        and r20rc['tested_code_unchanged'] is True and r6rc['tested_code_unchanged'] is True)

    # For audit admission, a fully closed strict count is enough; native FULL gate is deliberately NOT issued.
    return {'schema':'CDT16_B1_DISTRIBUTED_RECEIPT_ADMISSION_V001',
        'result_context':'ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 16',
        'policy_master_sha256':EXPECTED['policy_master'],'policy_head_sha256':EXPECTED['policy_head'],
        'source_full_sha256':EXPECTED['full'],'source_b1_bundle_sha256':EXPECTED['b1_bundle'],
        'checks_passed':len(checks),'checks':checks,'portable_pass':106,'native_pass':20,'total_ids':126,
        'B1_DISTRIBUTED_EVIDENCE_ADMISSION':'PASS_SOURCE_ONLY',
        'B1_FORMAL_GATE':'NOT_ISSUED_SOURCE_RUNNER_AND_PROVENANCE_CONTRACT_REQUIRE_SINGLE_NATIVE_RETURN',
        'G5_FORMAL_GATE':'NOT_ISSUED','B06':'NOT_STARTED','FULL_STARTED':False,
        'result_return_to':'ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 16'}

def run_from_paths(ev,b1,full):
    try:
        out=assess(Path(ev).read_bytes(),Path(b1).read_bytes(),Path(full).read_bytes())
        exitcode=0
    except Exception as exc:
        out={'schema':'CDT16_B1_DISTRIBUTED_RECEIPT_ADMISSION_V001',
             'B1_DISTRIBUTED_EVIDENCE_ADMISSION':'BLOCKED','B1_FORMAL_GATE':'NOT_ISSUED',
             'blocker':type(exc).__name__+':'+str(exc),'FULL_STARTED':False,
             'result_return_to':'ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 16'}
        exitcode=2
    print(json.dumps(out,indent=2,ensure_ascii=False))
    print("Devolva este resultado ao ChatGPT, no projeto 'Base de Dados CSV / Tickstore', conversa 'Compressão De Ticks 16'. Anexe as evidências existentes e cole esta resposta.")
    print('RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 16')
    return exitcode

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence_zip');parser.add_argument('b1_bundle_zip');parser.add_argument('full_zip')
    args=parser.parse_args()
    sys.exit(run_from_paths(args.evidence_zip,args.b1_bundle_zip,args.full_zip))
