"""TICKSTORE CDT21 F-01 / F-01R1 - legacy cut for the frozen V004R1 orchestrator.

Explicit tool, never invoked by the frozen code.  Default is a read-only DIAGNOSE; --apply installs
the cut under the same process-lifetime boundary that a D4 entry holds (so no live entry can race)
and never removes it.

The frozen orchestrator (recovery/modules/orchestrator.py, any deployed copy, started by
TICKSTORE_V004R1_MASTER_ORCHESTRATOR.ps1 or by `python orchestrator.py <command>`) has exactly two
ways to change the control state, and the cut closes both by name, for every process, whenever it
started:
  1. STATE - State.__init__/finish publish through atom(): open("STATE.json.partial", "wb") and
     os.replace().  A directory at that name (the V003 fence) makes that write fail: no new State is
     built and no frozen STATE write can complete.  Admitted writers use the CAS names instead.
  2. Journal - State.log appends with open("STATE_JOURNAL.jsonl", "ab") on every call and holds no
     handle, lock or mutex in between, so a process that built State BEFORE the fence kept appending
     (finding of the B06 of V003; the fence only denies the next construction).  The cut adds an
     explicit DENY ACE (Everyone: FILE_WRITE_DATA|FILE_APPEND_DATA) to the journal, checked by the
     kernel at every open, then proves the cut instant: the journal is opened without write sharing
     (a write handle opened before the ACE would refuse it) and its bytes at that instant are
     recorded in LEGACY_JOURNAL_CUT.json (create-new, inside the fence).  From that instant no
     frozen process can change STATE or the journal.
Drain: frozen execute() logs STARTED with run_id=<stamp>_<pid> before any node effect, so the
journal at the cut names every legacy run that may still be inside a node.  FENCE_PRESENT requires
each of those process identities to be gone (absent, exited, or the PID now held by a process created
after that run started + 600 s).  No process census is taken; the evidence is monotone.
Admitted writers (elevated D4 entry, FULL continuation) append through backup semantics and require
the complete, drained cut at admission, at every STATE commit and at every journal append
(runtime_locator_orchestrator_entry.require_legacy_entry_fence).

Decision table (exit 0 only for FENCE_PRESENT):
  FENCE_PRESENT                           fence + marker + cut record + journal still closed to plain
                                          writers and still beginning with its bytes at the cut + every
                                          legacy run of the journal at the cut gone (nothing written)
  CUT_PRESENT_LEGACY_RUN_NOT_DRAINED      the same, but a legacy run of the journal at the cut may still
                                          be running; it can no longer write STATE or the journal.
                                          Diagnose again later (nothing written)
  CUT_PRESENT_LEGACY_ACTIVITY_DURING_CUT  --apply only: the journal changed between the diagnosis and the
                                          cut instant, i.e. a legacy writer was live; the cut is in place
                                          and recorded; diagnose again
  FENCE_ABSENT_INSTALLABLE                nothing at the fence name, sound state dir; --apply: fence,
                                          marker, journal cut, record, verify
  FENCE_CUT_INCOMPLETE_INSTALLABLE        V003 fence (directory + valid marker) without the journal cut;
                                          --apply: journal cut, record, verify
  BLOCKED_MANUAL                          anything else: a regular file at the fence name (interrupted
                                          frozen write), links/reparse points, missing state dir, invalid
                                          marker or record, a journal write handle still open at the cut
                                          (the record is then not written), tampered journal
STATE is only read; its version is compared before and after.

Usage: python -B -I LEGACY_ENTRY_FENCE.py --state <...\\state\\STATE.json> [--adapter-dir <adapter dir>] [--apply]
Windows: run elevated (the ACE needs WRITE_DAC; admitted appends need SeRestorePrivilege).
Exit code: 0 when the cut is present and drained, 2 otherwise.
"""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import time

SCHEMA = "TICKSTORE_LEGACY_ENTRY_FENCE_REPORT_V002"
RULE = ("frozen State.__init__/finish -> atom(STATE.json) -> open(STATE.json.partial, 'wb') is denied by this "
        "directory; admitted CAS commits never use this name")
CUT_RULE = ("frozen State.log -> open(STATE_JOURNAL.jsonl, 'ab') is denied to every process by an explicit DENY "
            "ACE (Everyone: FILE_WRITE_DATA|FILE_APPEND_DATA); no write handle was open at the cut instant; admitted "
            "writers append with backup semantics")
INSTALLABLE = ("FENCE_ABSENT_INSTALLABLE", "FENCE_CUT_INCOMPLETE_INSTALLABLE")
PROBE_ATTEMPTS = 50
PROBE_INTERVAL_S = 0.1


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def load_entry(adapter_dir):
    p = Path(adapter_dir) / "runtime_locator_orchestrator_entry.py"
    spec = importlib.util.spec_from_file_location("tickstore_legacy_fence_entry", p)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _version(path):
    """Identity and digest of a regular file, or None when absent; links and reparse points refused."""
    try:
        before = os.lstat(path)
    except FileNotFoundError:
        return None
    if not stat.S_ISREG(before.st_mode) or getattr(before, "st_file_attributes", 0) & 0x400:
        raise RuntimeError("LEGACY_FENCE_NOT_REGULAR:" + Path(path).name)
    with open(path, "rb") as f:
        raw = f.read()
        opened = os.fstat(f.fileno())
    after = os.lstat(path)
    ident = [after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns]
    if [opened.st_dev, opened.st_ino, opened.st_size, opened.st_mtime_ns] != ident or len(raw) != after.st_size:
        raise RuntimeError("LEGACY_FENCE_EVIDENCE_CHANGED")
    return {"identity": ident, "sha256": sha(raw), "bytes": len(raw)}


def diagnose(state_path: Path, entry):
    state_path = Path(state_path)
    fence = entry.legacy_entry_fence_path(state_path)
    journal = entry.legacy_journal_path(state_path)
    rep = {"schema": SCHEMA, "state": str(state_path), "fence": str(fence), "journal": str(journal),
           "decision": "BLOCKED_MANUAL", "reasons": []}
    try:
        entry.require_no_link_chain(state_path.parent, "LEGACY_FENCE_STATE_DIR")
        if not stat.S_ISDIR(os.lstat(state_path.parent).st_mode):
            raise RuntimeError("LEGACY_FENCE_STATE_DIR_NOT_DIRECTORY")
        rep["state_version"] = _version(state_path)
        rep["journal_version"] = _version(journal)
        if not os.path.lexists(fence):
            rep["decision"] = "FENCE_ABSENT_INSTALLABLE"
            return rep
        st = os.lstat(fence)
        if stat.S_ISREG(st.st_mode) and not getattr(st, "st_file_attributes", 0) & 0x400:
            rep["reasons"].append("LEGACY_PARTIAL_DEBRIS_PRESENT")
            rep["partial_debris"] = _version(fence)
            return rep
        marker_raw = entry.require_legacy_entry_fence_marker(state_path)
        if not os.path.lexists(fence / entry.LEGACY_JOURNAL_CUT_RECORD):
            rep["decision"] = "FENCE_CUT_INCOMPLETE_INSTALLABLE"
            return rep
        record, prefix = entry.require_legacy_journal_cut(state_path, marker_raw)
        rep["cut"] = {"record_sha256": sha((fence / entry.LEGACY_JOURNAL_CUT_RECORD).read_bytes()),
                      "cut_utc": record.get("cut_utc"), "journal_at_cut": record["journal_at_cut"],
                      "journal_changed_during_cut": record.get("journal_changed_during_cut")}
        rep["write_denial"] = entry.legacy_journal_write_denial(journal)
        drain = entry.legacy_drain(prefix)
        rep["drain"] = drain
        if drain["status"] == "DRAINED":
            rep["decision"] = "FENCE_PRESENT"
        else:
            rep["decision"] = "CUT_PRESENT_LEGACY_RUN_NOT_DRAINED"
            rep["reasons"].append("LEGACY_RUN_POSSIBLY_ACTIVE:" + ",".join(drain["not_drained"]))
        return rep
    except (OSError, RuntimeError) as exc:
        rep["reasons"].append(str(exc))
        return rep


def _comparable(rep):
    return {k: v for k, v in rep.items() if k != "applied_utc"}


def apply(state_path: Path, rep, entry, tool_raw, entry_raw):
    if rep.get("decision") not in INSTALLABLE:
        return rep
    state_path = Path(state_path)
    fence = entry.legacy_entry_fence_path(state_path)
    journal = entry.legacy_journal_path(state_path)
    release = entry.acquire_state_boundary(state_path)  # no live D4 entry may hold this STATE
    try:
        again = diagnose(state_path, entry)
        if _comparable(again) != _comparable(rep):
            raise RuntimeError("LEGACY_FENCE_EVIDENCE_CHANGED")
        if rep["decision"] == "FENCE_ABSENT_INSTALLABLE":
            os.mkdir(fence)  # never exist_ok: a concurrent creation is not adopted
            marker = {"schema": entry.LEGACY_ENTRY_FENCE_SCHEMA, "state_name": state_path.name, "fence_name": fence.name,
                      "rule": RULE, "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      "tool_sha256": sha(tool_raw), "entry_sha256": sha(entry_raw),
                      "state_version_at_install": rep["state_version"], "journal_version_at_install": rep["journal_version"]}
            with open(fence / entry.LEGACY_ENTRY_FENCE_MARKER, "xb") as f:
                f.write((json.dumps(marker, indent=1, sort_keys=True) + "\n").encode("ascii"))
                f.flush()
                os.fsync(f.fileno())
            entry._fsync_directory(fence)
            entry._fsync_directory(state_path.parent)
        marker_raw = entry.require_legacy_entry_fence_marker(state_path)
        try:
            with open(fence, "wb"):
                pass
            frozen_write_denied = False
        except OSError:
            frozen_write_denied = True
        if not frozen_write_denied:
            raise RuntimeError("LEGACY_FENCE_DOES_NOT_DENY_FROZEN_WRITE")
        # Journal cut: close the name to plain writers, then prove that no earlier write handle survives.
        created = rep["journal_version"] is None
        if created:
            with open(journal, "xb") as f:
                f.flush()
                os.fsync(f.fileno())
            entry._fsync_directory(state_path.parent)
        entry.deny_legacy_journal_writes(journal)
        probe = None
        for _ in range(PROBE_ATTEMPTS):
            probe = entry.probe_journal_at_cut(journal)
            if probe is not None:
                break
            time.sleep(PROBE_INTERVAL_S)
        if probe is None:
            raise RuntimeError("LEGACY_JOURNAL_WRITER_OPEN_AT_CUT")
        cut_raw, cut_identity = probe
        cut_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
        denial = entry.require_legacy_journal_cut_enforced(journal)
        expected = rep["journal_version"]
        if expected is not None and cut_identity != expected["identity"][:2]:
            raise RuntimeError("LEGACY_JOURNAL_REPLACED_DURING_CUT")
        changed = (cut_raw != b"") if expected is None else (sha(cut_raw) != expected["sha256"] or len(cut_raw) != expected["bytes"])
        record = {"schema": entry.LEGACY_JOURNAL_CUT_SCHEMA, "state_name": state_path.name, "fence_name": fence.name,
                  "journal_name": entry.LEGACY_JOURNAL_NAME, "fence_marker_sha256": sha(marker_raw),
                  "journal_identity": cut_identity,
                  "journal_at_cut": {"bytes": len(cut_raw), "sha256": sha(cut_raw), "lines": len(cut_raw.splitlines())},
                  "journal_version_at_diagnosis": expected, "journal_created_by_cut": created,
                  "journal_changed_during_cut": changed, "writer_handles_at_cut": 0, "write_denial": denial,
                  "rule": CUT_RULE, "cut_utc": cut_utc, "platform": sys.platform,
                  "tool_sha256": sha(tool_raw), "entry_sha256": sha(entry_raw)}
        with open(fence / entry.LEGACY_JOURNAL_CUT_RECORD, "xb") as f:
            f.write((json.dumps(record, indent=1, sort_keys=True) + "\n").encode("ascii"))
            f.flush()
            os.fsync(f.fileno())
        entry._fsync_directory(fence)
        entry._fsync_directory(state_path.parent)
        after = diagnose(state_path, entry)
        if after.get("state_version") != rep["state_version"]:
            raise RuntimeError("LEGACY_FENCE_STATE_CHANGED")
        if after.get("decision") not in ("FENCE_PRESENT", "CUT_PRESENT_LEGACY_RUN_NOT_DRAINED"):
            raise RuntimeError("LEGACY_FENCE_CUT_NOT_VERIFIED:" + ";".join(after.get("reasons", [])))
        if (after.get("journal_version") or {}).get("sha256") != sha(cut_raw):
            raise RuntimeError("LEGACY_JOURNAL_CHANGED_AFTER_CUT")
        result = dict(after)
        result.update(applied=True, applied_utc=cut_utc, frozen_write_denied=True, frozen_append_denied=denial["denied"],
                      marker_sha256=sha(marker_raw),
                      cut_record_sha256=sha((fence / entry.LEGACY_JOURNAL_CUT_RECORD).read_bytes()))
        if changed:
            result["decision"] = "CUT_PRESENT_LEGACY_ACTIVITY_DURING_CUT"
            result["reasons"] = list(result.get("reasons", [])) + ["LEGACY_JOURNAL_ACTIVITY_DURING_CUT"]
        return result
    finally:
        release()


def main(argv=None):
    ap = argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument("--state", required=True)
    ap.add_argument("--adapter-dir", default=str(Path(__file__).resolve().parent.parent / "adapter"))
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args(argv)
    entry_path = Path(a.adapter_dir) / "runtime_locator_orchestrator_entry.py"
    entry = load_entry(a.adapter_dir)
    state_path = Path(a.state)
    rep = diagnose(state_path, entry)
    if a.apply:
        try:
            rep = apply(state_path, rep, entry, Path(__file__).read_bytes(), entry_path.read_bytes())
        except (OSError, RuntimeError) as exc:
            rep = {"schema": SCHEMA, "state": str(state_path), "decision": "BLOCKED_MANUAL", "reasons": [str(exc)]}
    print(json.dumps(rep, indent=2, sort_keys=True, default=str))
    return 0 if rep.get("decision") == "FENCE_PRESENT" else 2


if __name__ == "__main__":
    raise SystemExit(main())
