"""Strict G5 stage-only formal B1 provenance admission. No FULL candidate release.
The unchanged C6 engine and its native 6 proofs are verified using exact original consumer.
"""
from __future__ import annotations
import hashlib, zipfile, io, json, re, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'SUPPORT'))
import G5_C6_B1_FORMAL_CONSUMER as source

G5_NATIVE_SHA='92395C38428CDA48DB3FF6ED94EADA0A28896BA1994F975079DDD4ACBE49FFC9'
SCHEMA='TICKSTORE_CDT17_G5_STAGE_COMPLETENESS_V001'
PROV_SCHEMA='TICKSTORE_CDT17_G5_B1_FORMAL_PROVENANCE_V001'
class Blocked(ValueError): pass
def ck(v,s):
 if not v: raise Blocked(s)
def sha(b):return hashlib.sha256(b).hexdigest().upper()
def strict(b):
 def pairs(xs):
  d={}
  for k,v in xs:
   ck(k not in d,'DUPLICATE_JSON_KEY:'+k);d[k]=v
  return d
 return json.loads(b.decode('utf-8'),object_pairs_hook=pairs)
def enclosed(raw,manifest_name='RETURN_MANIFEST.json'):
 try:
  z, data, e=source._zip_members(raw,'G5_NATIVE')
 except (Exception,) as err: raise Blocked('ZIP_BAD:'+type(err).__name__) from err
 ck(z is not None and not e,'ZIP_INVALID:'+str(e))
 ck(manifest_name in data,'MISSING_MANIFEST')
 o=strict(data[manifest_name]);rows=o.get('files')
 ck(o.get('schema')=='CDT17_G5_C6_ADMISSION_RETURN_MANIFEST_V001','G5_RETURN_SCHEMA')
 ck(isinstance(rows,list),'G5_RETURN_LIST')
 names=[r.get('path') for r in rows]
 ck(len(names)==len(set(names))==len(rows),'G5_RETURN_DUPLICATE')
 ck(set(names)==set(data)-{manifest_name},'G5_RETURN_EXACT_SET')
 for r in rows:
  n=r['path'];ck(len(data[n])==r.get('bytes') and sha(data[n])==r.get('sha256'),'G5_RETURN_MEMBER:'+n)
 return data

def verify(final,g4,hist,baseline,g5,*,allow_different_g5_sha=False):
 ck(sha(g5)==G5_NATIVE_SHA or allow_different_g5_sha,'G5_NATIVE_RETURN_SHA')
 # The source verifier re-reads full runtime manifest, nested native formal B1 10 tests,
 # 126 historical IDs as HISTORICAL ONLY, G4 Windows suites 279 and all 6 typed proofs.
 b=source.run(final_raw=final,g4_raw=g4,history_raw=hist,baseline_raw=baseline)
 ck(b['status']=='PASS_EVIDENCE_CONSUMER_SCOPED','B1_NATIVE_INTAKE')
 g=enclosed(g5)
 a=strict(g['G5_C6_CONSUMER_ADMISSION.json'])
 ck(a==b,'G5_WINDOWS_ADMISSION_CONTENT_NOT_RECOMPUTED')
 p=strict(g['G5_C6_EVIDENCE_PACK.json'])
 ck(p.get('admission_sha256')==sha(g['G5_C6_CONSUMER_ADMISSION.json']) and
    p.get('consumer_source_sha256')==sha(Path(source.__file__).read_bytes()) and
    p.get('legacy_original_consumer_sha256')==sha(Path(source.__file__).with_name('FULL_QUALIFICATION_CONTRACT.py').read_bytes()),'G5_NATIVE_CONSUMER_IDENTITY')
 expect={'FULL.zip':final,'G4_RETURN.zip':g4,'B1_HISTORY.zip':hist,'BASELINE.zip':baseline}
 ck({x['name']:(x['sha256'],x['bytes']) for x in p['inputs']}==
    {n:(sha(v),len(v)) for n,v in expect.items()},'G5_NATIVE_INPUTS')
 ck(p.get('g5_evidence')=='PASS_SCOPED' and p.get('g5_formal')=='NOT_ISSUED', 'G5_FALSE_GATE_VERDICT')
 err=g['NEGATIVE_STDERR.txt'].decode('utf-8')
 ck(re.search(r'Ran 17 tests in [\d.]+s',err) is not None and err.rstrip().endswith('OK'),'G5_NATIVE_NEGATIVE_17')
 log=g['RUN_LOG.txt'].decode('utf-8')
 ck('G5_CHILD=NEGATIVE_CONTROLS_17 EXIT=0' in log and
    'G5_CHILD=G5_B1_FORMAL_AND_PROOFS EXIT=0' in log and
    'G5_PROGRESS [##########################----] 90.00%' in log,'G5_NATIVE_EXECUTION_LOG')
 ck(b['g5_formal']=='NOT_ISSUED' and b['historical_b1']['not_reexecuted_on_c6'] is True,'G5_SCOPE')
 ck(len(b['six_typed_proofs'])==6 and b['six_typed_proofs']['POWERLOSS_EMULATED']['status']=='EMULATED_PASS','TYPED_SIX_SCOPE')
 return b

def verify_provenance(prov,stage,base):
 ck(prov.get('schema')==PROV_SCHEMA,'PROVENANCE_SCHEMA')
 raw={}
 for n in ('FULL.zip','G4_RETURN.zip','B1_HISTORY.zip','BASELINE.zip','G5_NATIVE_RETURN.zip'):
  entry=(prov.get('inputs') or {}).get(n)
  ck(isinstance(entry,dict),'PROVENANCE_MISSING:'+n)
  p=Path(base)/'INPUTS'/n
  v=p.read_bytes();ck(sha(v)==entry.get('sha256') and len(v)==entry.get('bytes'),'PROVENANCE_MEMBER:'+n)
  raw[n]=v
 b=verify(raw['FULL.zip'],raw['G4_RETURN.zip'],raw['B1_HISTORY.zip'],raw['BASELINE.zip'],raw['G5_NATIVE_RETURN.zip'])
 ck(stage.get('schema')==SCHEMA and stage.get('status')=='COMPLETE_SCOPED' and
    stage.get('full_candidate_completeness')=='NOT_PROVEN' and
    stage.get('formal_gate_verdict_issued') is False and
    stage.get('physical_power_cut')=='NOT_TESTED_PHYSICAL_POWERLOSS' and
    stage.get('b1_historical_executed_again') is False,'STAGE_FALSE_COMPLETENESS')
 ck(stage.get('original_full_sha256')==sha(raw['FULL.zip']) and
    stage.get('g4_return_sha256')==sha(raw['G4_RETURN.zip']) and
    stage.get('g5_native_return_sha256')==sha(raw['G5_NATIVE_RETURN.zip']), 'STAGE_BINDING')
 ck(stage.get('six_typed_receipt_sha256')=={n:v['sha256'] for n,v in b['six_typed_proofs'].items()},'STAGE_TYPED_RECEIPTS')
 return b
