#!/usr/bin/env python3
"""C5-R44 distributed B1 evidence -> exact typed per-ID provenance candidate.

NOT a B1 formal PASS, NOT a G5 proof, NOT a RELEASE. All inputs are immutable
physical ZIP bytes.  The prior verifier's complete checks are mandatory.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import io
import json
import sys
import zipfile
from pathlib import Path

SCHEMA = 'CDT16_B1_DISTRIBUTED_PROVENANCE_CANDIDATE_V002'
CONTEXT='ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 16'

def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

def j(raw):
    def unique(items):
        v={}
        for k,w in items:
            if k in v: raise ValueError('DUPLICATE_JSON_KEY:'+str(k))
            v[k]=w
        return v
    return json.loads(raw.decode('utf-8'), object_pairs_hook=unique)

def verifier():
    spec=importlib.util.spec_from_file_location('immutable_b1_evidence_verifier',Path(__file__).with_name('B1_DISTRIBUTED_EVIDENCE_ADMISSION.py'))
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod

def create(evidence: bytes, b1: bytes, full: bytes) -> dict:
    v=verifier()
    # Every manifest, overlay, physical return, causal link, runtime byte and policy
    # pin is checked by the existing independent read-only verifier.
    receipt=v.assess(evidence,b1,full)
    if (receipt.get('checks_passed')!=190 or receipt.get('total_ids')!=126
        or receipt.get('B1_DISTRIBUTED_EVIDENCE_ADMISSION')!='PASS_SOURCE_ONLY'
        or receipt.get('B1_FORMAL_GATE','').startswith('PASS')):
        raise ValueError('EXISTING_VERIFIER_NOT_PASS_SCOPED')
    z=zipfile.ZipFile(io.BytesIO(evidence))
    returns={key: z.read(path) for key,path in v.RETURNS.items()}
    r105=j(zipfile.ZipFile(io.BytesIO(returns['portable105'])).read('B1/B1_HARNESS/RESULT.json'))
    r20=j(zipfile.ZipFile(io.BytesIO(returns['native14'])).read('EVIDENCE/B1_HARNESS/RESULT.json'))
    r6=j(zipfile.ZipFile(io.BytesIO(returns['native6'])).read('EVIDENCE/B1_HARNESS/RESULT.json'))
    o=j(zipfile.ZipFile(io.BytesIO(returns['portable1'])).read('RECEIPT.json'))
    contract=j(z.read('CONTRACT/QUALIFICATION_CONTRACT_ORIGINAL.json'))['required_tests']
    # Read every source outcome. Explicitly preserve predecessor non-PASS: no rewriting history.
    by_src={k: {x['id']: x['status'] for x in r['tests']} for k,r in [('portable105',r105),('native14',r20),('native6',r6)]}
    if len(set(contract))!=126 or len(contract)!=126: raise ValueError('CONTRACT_CARDINALITY')
    evidence_map=[]
    for test_id in contract:
        observed=[(k,m[test_id]) for k,m in by_src.items() if test_id in m]
        if test_id==o['test_id']:
            if observed!=[('portable105','ERROR')]: raise ValueError('PORTABLE_REMEDIATION_ORIGIN')
            evidence_map.append(dict(id=test_id,final_status='PASS',proof_source='portable1',origin_source='portable105',origin_status='ERROR'))
        elif test_id in by_src['native6']:
            if observed!=[('native14',by_src['native14'][test_id]),('native6','PASS')] or by_src['native14'][test_id]=='PASS':
                raise ValueError('NATIVE_REMEDIATION_ORIGIN')
            evidence_map.append(dict(id=test_id,final_status='PASS',proof_source='native6',origin_source='native14',origin_status=by_src['native14'][test_id]))
        else:
            if len(observed)!=1 or observed[0][1]!='PASS': raise ValueError('AMBIGUOUS_OR_MISSING_TEST:'+test_id)
            evidence_map.append(dict(id=test_id,final_status='PASS',proof_source=observed[0][0],origin_source=None,origin_status=None))
    if len({x['id'] for x in evidence_map})!=126: raise ValueError('MAP_DUPLICATE')
    distribution={k:sum(x['proof_source']==k for x in evidence_map) for k in v.RETURNS}
    if distribution!={'portable105':105,'portable1':1,'native14':14,'native6':6}:
        raise ValueError('MAP_CARDINALITY')
    return dict(schema=SCHEMA, result_context=CONTEXT,
        source_evidence_zip_sha256=sha(evidence), source_full_zip_sha256=sha(full), source_b1_bundle_sha256=sha(b1),
        policy_master_sha256=receipt['policy_master_sha256'], policy_head_sha256=receipt['policy_head_sha256'],
        returns_sha256={k:sha(raw) for k,raw in returns.items()},
        physical_verifier_checks=receipt['checks_passed'],
        test_results=evidence_map, distribution=distribution,
        b1_evidence='COMPLETE_126_DISTINCT_PASS_ON_FROZEN_PARENT_BYTES',
        b1_formal_gate='NOT_ISSUED', g5_formal_gate='NOT_ISSUED', full_started=False,
        limitation='SPLIT_NATIVE_EVIDENCE_ONLY; requires explicit consumer contract and runtime qualification',
        result_return_to=CONTEXT)

def verify(candidate:dict, evidence:bytes, b1:bytes, full:bytes):
    if not isinstance(candidate,dict) or set(candidate)!=set(create(evidence,b1,full)):
        raise ValueError('PROVENANCE_SCHEMA_FIELDS')
    expected=create(evidence,b1,full)
    if candidate!=expected:
        raise ValueError('PROVENANCE_NOT_PHYSICAL_SOURCE_DERIVED')
    if candidate.get('b1_formal_gate')!='NOT_ISSUED' or candidate.get('g5_formal_gate')!='NOT_ISSUED':
        raise ValueError('GATE_FORGERY')
    return True

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--evidence',required=True);parser.add_argument('--b1',required=True);parser.add_argument('--full',required=True)
    parser.add_argument('--output',required=True)
    a=parser.parse_args()
    try:
        data=create(Path(a.evidence).read_bytes(),Path(a.b1).read_bytes(),Path(a.full).read_bytes())
        raw=(json.dumps(data,sort_keys=True,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
        out=Path(a.output)
        if out.exists(): raise ValueError('OUTPUT_ALREADY_EXISTS')
        out.write_bytes(raw)
        print('B1_DISTRIBUTED_PHYSICAL_EVIDENCE=PASS 126/126; B1_FORMAL_GATE=NOT_ISSUED')
        print('EVIDENCE_MAP='+str(out)+' SHA256='+sha(raw))
        code=0
    except Exception as exc:
        print('B1_DISTRIBUTED_PHYSICAL_EVIDENCE=BLOCKED '+type(exc).__name__+':'+str(exc))
        code=2
    print("Devolva este resultado ao ChatGPT, no projeto 'Base de Dados CSV / Tickstore', conversa 'Compressão De Ticks 16'. Anexe as evidências existentes e cole esta resposta.")
    print('RESULT_RETURN_TO='+CONTEXT)
    return code

if __name__=='__main__': sys.exit(main())
