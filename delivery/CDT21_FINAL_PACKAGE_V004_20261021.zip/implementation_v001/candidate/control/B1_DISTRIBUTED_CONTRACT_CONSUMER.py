"""Contractual B1 distributed evidence intake, no automatic B1/G5 gate release.

User-approved integration; source-only until NEW bytes are target-runtime qualified.
Preserves exact old G5 native_provenance and FULL_QUALIFICATION_CONTRACT.validate.
"""
import hashlib
import importlib.util
import json
from pathlib import Path

SCHEMA='CDT16_B1_DISTRIBUTED_ADMISSION_CONTRACT_V003'
CONTRACT_SHA256='88BA16500D3913EAD3EDF11FF6CF80AD9DFD3B6962B2CCE3407D471979BE4FEE'
CONTRACT_FILENAME='B1_DISTRIBUTED_ADMISSION_CONTRACT_V003.json'

def _sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

def _strict_json(raw):
    def pairs(items):
        out={}
        for key,value in items:
            if key in out:
                raise ValueError('DUPLICATE_CONTRACT_KEY:'+str(key))
            out[key]=value
        return out
    return json.loads(raw.decode('utf-8'),object_pairs_hook=pairs)

def evaluate(provenance_map_bytes, evidence_zip_bytes, b1_zip_bytes, parent_full_zip_bytes):
    here=Path(__file__).resolve().parent
    cbytes=(here/CONTRACT_FILENAME).read_bytes()
    if _sha(cbytes)!=CONTRACT_SHA256:
        raise ValueError('B1_CONTRACT_BYTES_CHANGED')
    contract=_strict_json(cbytes)
    if contract.get('schema')!=SCHEMA or contract.get('production')!='FORBIDDEN' or        contract.get('b1_formal_gate')!='NOT_ISSUED' or contract.get('g5_formal_gate')!='NOT_ISSUED' or        contract.get('qualify_new_consumer_natively')!='REQUIRED_BEFORE_B1_FORMAL':
        raise ValueError('B1_CONTRACT_GATE_LIMITS')
    for key,raw in [('map_sha256',provenance_map_bytes),('evidence_zip_sha256',evidence_zip_bytes),
                    ('b1_zip_sha256',b1_zip_bytes),('parent_full_sha256',parent_full_zip_bytes)]:
        if not isinstance(raw,bytes) or contract.get(key)!=_sha(raw):
            raise ValueError('B1_SOURCE_IDENTITY:'+key)
    for filename,key in [('B1_DISTRIBUTED_PROVENANCE_BRIDGE.py','bridge_source_sha256'),
                         ('B1_DISTRIBUTED_EVIDENCE_ADMISSION.py','verifier_source_sha256')]:
        if _sha((here/filename).read_bytes())!=contract[key]:
            raise ValueError('B1_CHECKER_BYTES_CHANGED:'+filename)
    spec=importlib.util.spec_from_file_location('cdt16_b1_bridge_strict',here/'B1_DISTRIBUTED_PROVENANCE_BRIDGE.py')
    bridge=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bridge)
    candidate=_strict_json(provenance_map_bytes)
    bridge.verify(candidate,evidence_zip_bytes,b1_zip_bytes,parent_full_zip_bytes)
    if (candidate.get('schema')!=bridge.SCHEMA or candidate.get('b1_formal_gate')!='NOT_ISSUED'
        or candidate.get('g5_formal_gate')!='NOT_ISSUED' or candidate.get('full_started') is not False
        or candidate.get('policy_master_sha256')!=contract['policy_master_sha256']
        or candidate.get('policy_head_sha256')!=contract['policy_head_sha256']):
        raise ValueError('B1_MAP_AUTHORITY_OR_POLICY')
    tests=candidate.get('test_results')
    if (not isinstance(tests,list) or len(tests)!=contract['required_ids']
        or len({r['id'] for r in tests})!=contract['required_ids']
        or sum(r['origin_status'] is not None for r in tests)!=contract['expected_remediations']
        or candidate.get('distribution')!=contract['expected_distribution']
        or any(r['final_status']!='PASS' for r in tests)):
        raise ValueError('B1_SCOPE_OR_REMEDIATION')
    return {'schema':'CDT16_B1_DISTRIBUTED_CONSUMER_RESULT_V003',
            'status':contract['output_status'],'verified_test_ids':len(tests),
            'distribution':candidate['distribution'],'remediations':contract['expected_remediations'],
            'b1_formal_gate':'NOT_ISSUED','g5_formal_gate':'NOT_ISSUED',
            'new_consumer_native_qualified':False,'full_started':False,
            'parent_full_sha256':contract['parent_full_sha256'],
            'evidence_zip_sha256':contract['evidence_zip_sha256'],
            'contract_sha256':CONTRACT_SHA256,
            'result_return_to':contract['result_return_to']}
