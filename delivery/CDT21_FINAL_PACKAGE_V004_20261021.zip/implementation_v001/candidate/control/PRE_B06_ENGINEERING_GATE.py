"""CDT19 PRE-B06 eleven-consumer *engineering* evidence verification.

No D4, B07, B06, production, or FULL authority is issued by this file.
The V002 record is deliberately distinct from the legacy V001 effectful chain.
All protected actions remain behind the independent post-audit gate.
"""
from __future__ import annotations
import hashlib
import json
import os
import re
from pathlib import Path

SCHEMA = 'TICKSTORE_PRE_B06_11_CONSUMER_EVIDENCE_V002'
EXPECTED = (
 'adapter/INLINE_ROOT_LOADER_V004_R1R1_ADAPTER.ps1',
 'adapter/runtime_locator_adapter.py',
 'adapter/runtime_locator_inline_entry.py',
 'adapter/runtime_locator_orchestrator_entry.py',
 'control/60_EFFECTFUL_WRAPPER_RELEASE.ps1',
 'control/D4_FIRST_ADMISSION_TRANSACTION.py',
 'control/D4_ROOTS_EVIDENCE.py',
 'recovery/engine/tickstore_publisher_recovery_v004_candidate.py',
 'recovery/engine/tickstore_publisher_recovery_v004_release.py',
 'recovery/loader/INLINE_ROOT_LOADER_V004_R1R1.ps1',
 'recovery/modules/orchestrator.py',
)
HEX = re.compile(r'[A-F0-9]{64}\Z')
SAFE = 'SAFE_ISOLATED_POSITIVE'
GUARD = 'GUARD_NEGATIVE_AND_CODE_REVIEW'
SUPERSEDED = 'SUPERSEDED_UNREACHABLE_PROVEN'

class NotProven(RuntimeError):
    pass

def demand(condition, reason):
    if not condition:
        raise NotProven('PRE_B06_' + reason)

def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

def strict(raw):
    def pairs(items):
        result = {}
        for k,v in items:
            demand(k not in result, 'DUPLICATE_JSON_FIELD')
            result[k] = v
        return result
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs)

def physical_blob(record, evidence_root, reason):
    """Read only evidence children; never follow user-provided absolute paths."""
    demand(isinstance(record,dict), reason+'_MISSING')
    rel, h = record.get('member'),record.get('sha256')
    demand(isinstance(rel,str) and rel and not rel.startswith('/') and '\\' not in rel
           and ':' not in rel and '..' not in rel.split('/')
           and all(x not in ('.','') for x in rel.split('/')), reason+'_PATH')
    demand(isinstance(h,str) and HEX.fullmatch(h), reason+'_SHA_FORMAT')
    requested=Path(os.path.abspath(evidence_root))
    for ancestor in (*reversed(requested.parents),requested):
        stat_info=ancestor.lstat()
        demand(not ancestor.is_symlink() and not (getattr(stat_info,'st_file_attributes',0)&0x400),
               reason+'_ROOT_REPARSE')
    root=requested.resolve(strict=True)
    file=root.joinpath(*rel.split('/'))
    # Reject symlinks/reparse for every component including root.
    cur = root
    demand(not cur.is_symlink() and not (getattr(cur.stat(),'st_file_attributes',0)&0x400),reason+'_ROOT_REPARSE')
    for name in rel.split('/'):
        cur=cur/name
        demand(not cur.is_symlink() and not (getattr(cur.lstat(),'st_file_attributes',0)&0x400),reason+'_REPARSE')
    demand(cur.is_file(),reason+'_NOT_FILE')
    raw=cur.read_bytes()
    demand(sha(raw)==h,reason+'_DIGEST')
    if 'bytes' in record:demand(type(record['bytes']) is int and len(raw)==record['bytes'],reason+'_SIZE')
    return raw

def physical_ref(record, evidence_root, reason):
    return strict(physical_blob(record,evidence_root,reason))

def verify_dossier(dossier, candidate_root, evidence_root, *, native_required=True):
    """Verify bounded evidence, not *certify* issuer authenticity or five-part completeness.

    sandbox tests may set native_required=False; result is CONTRACT_ONLY, never PASS.
    All assertions below run even in that mode.
    """
    root=Path(candidate_root).resolve(strict=True)
    demand(root.is_dir(),'SOURCE_ROOT')
    manifest=root.parent/'RUNTIME_CODE_MANIFEST.json'
    manifest_raw=manifest.read_bytes()
    runtime=strict(manifest_raw)
    demand(runtime.get('schema')=='TICKSTORE_FINAL_RUNTIME_CODE_MANIFEST_V001','MANIFEST_SCHEMA')
    files=runtime.get('files')
    demand(isinstance(files,list) and len(files)==len({r.get('path') for r in files if isinstance(r,dict)}),
           'MANIFEST_FILES')
    index={r['path']:r for r in files}
    demand(set(EXPECTED)<=set(index),'MANIFEST_CONSUMERS')
    # Pin physical candidate sources, not merely narrative SHA or cached list.
    for rel in EXPECTED:
        path=root.joinpath(*rel.split('/'))
        demand(path.is_file() and not path.is_symlink(),'MISSING_SOURCE:'+rel)
        raw=path.read_bytes()
        demand(len(raw)==index[rel]['bytes'] and sha(raw)==index[rel]['sha256'], 'SOURCE_DRIFT:'+rel)
    demand(isinstance(dossier,dict) and dossier.get('schema')==SCHEMA,'SCHEMA')
    demand(dossier.get('purpose')=='ENGINEERING_PRE_B06_NO_OPERATIONAL_ADMISSION','PURPOSE')
    demand(dossier.get('code_manifest_sha256')==sha(manifest_raw),'CODE_MANIFEST_BINDING')
    demand(dossier.get('production_modified') is False and
           dossier.get('b06')=='NOT_STARTED' and dossier.get('b07')=='NOT_STARTED' and
           dossier.get('full_started') is False,'NO_PREMATURE_OPERATION')
    run_id=dossier.get('run_id')
    demand(isinstance(run_id,str) and re.fullmatch('[0-9a-f]{32}',run_id),'RUN_ID')
    rows=dossier.get('consumers')
    demand(isinstance(rows,list) and len(rows)==11 and
           {r.get('source_path') for r in rows if isinstance(r,dict)}==set(EXPECTED),
           'EXACT_ELEVEN')
    seen=set();roles=[]
    for row in rows:
        rel=row['source_path']
        demand(rel not in seen,'DUPLICATE_CONSUMER');seen.add(rel)
        demand(row.get('source_sha256')==index[rel]['sha256'],'CONSUMER_SOURCE:'+rel)
        role=row.get('role')
        demand(role in (SAFE,GUARD,SUPERSEDED),'UNRECOGNIZED_ROLE:'+rel)
        # Disallow an unsupported inaccessibility exception until *real release*
        # graph and all registries have a reviewed proof. Do not grant N/A by name.
        demand(role!=SUPERSEDED,'SUPERSEDED_NOT_YET_QUALIFIED:'+rel)
        witness=physical_ref(row.get('execution_witness'),evidence_root,'EXECUTION:'+rel)
        demand(witness.get('schema')=='TICKSTORE_PRE_B06_NATIVE_EXECUTION_WITNESS_V001'
               and witness.get('run_id')==run_id
               and witness.get('source_path')==rel
               and witness.get('source_sha256')==index[rel]['sha256']
               and witness.get('native_windows') is True
               and witness.get('scope')=='OWNED_ISOLATED_NTFS'
               and witness.get('production_modified') is False
               and type(witness.get('pid')) is int and witness['pid']>0
               and type(witness.get('creation_filetime')) is int and witness['creation_filetime']>0,
               'WITNESS_SEMANTICS:'+rel)
        demand(witness.get('invoked') is True and witness.get('entrypoint_observed') is True,
               'UNOBSERVED_ENTRY:'+rel)
        demand(witness.get('language')==('POWERSHELL_5_1' if rel.endswith('.ps1') else 'PYTHON'),
               'LANGUAGE_OBSERVER:'+rel)
        demand(witness.get('runner_sha256') and HEX.fullmatch(witness['runner_sha256']),
               'RUNNER_IDENTITY:'+rel)
        runner_raw = physical_blob(row.get('runner_source'),evidence_root,'RUNNER_SOURCE:'+rel)
        demand(sha(runner_raw)==witness['runner_sha256'],'RUNNER_BYTES:'+rel)
        controls = physical_ref(row.get('negative_controls'),evidence_root,'NEGATIVE:'+rel)
        before = physical_blob(controls.get('protected_inventory_before'),evidence_root,'INVENTORY_BEFORE:'+rel)
        after = physical_blob(controls.get('protected_inventory_after'),evidence_root,'INVENTORY_AFTER:'+rel)
        demand(controls.get('schema')=='TICKSTORE_PRE_B06_CONTROLS_V001'
               and controls.get('source_path')==rel
               and before==after
               and controls.get('before_protected_roots_sha256')==sha(before)
               and controls.get('after_protected_roots_sha256')==sha(after)
               and controls.get('reparse_rejected') is True
               and controls.get('foreign_owner_rejected') is True,
               'NEGATIVE_SCOPE:'+rel)
        if role==SAFE:
            effects=witness.get('isolated_effects')
            demand(witness.get('exit_code')==0 and witness.get('protected_effects') is False
                   and isinstance(effects,list) and bool(effects), 'ISOLATED_POSITIVE:'+rel)
            for effect in effects:
                demand(effect.get('before_sha256') != effect.get('after_sha256')
                       and isinstance(effect.get('after_sha256'),str)
                       and HEX.fullmatch(effect['after_sha256']), 'EFFECT_TRANSITION:'+rel)
                actual=physical_blob(effect.get('readback'),evidence_root,'EFFECT_READBACK:'+rel)
                demand(sha(actual)==effect['after_sha256'], 'EFFECT_MISMATCH:'+rel)
        else:
            demand(type(witness.get('exit_code')) is int and witness['exit_code']!=0
                   and witness.get('protected_effects') is False
                   and witness.get('isolated_effects')==[]
                   and witness.get('failure_before_protected_effect') is True,
                   'GUARD_NEGATIVE:'+rel)
            review=physical_ref(row.get('code_path_review'),evidence_root,'CODE_REVIEW:'+rel)
            demand(review.get('schema')=='TICKSTORE_PRE_B06_IMPLEMENTATION_REVIEW_V001'
                   and review.get('source_path')==rel
                   and review.get('source_sha256')==index[rel]['sha256']
                   and review.get('implementation_reviewed') is True
                   and review.get('required_branches_implemented') is True
                   and review.get('remaining_implementation_blockers')==[],
                   'CODE_IMPLEMENTATION_NOT_PROVEN:'+rel)
            # A declaration that guarded functionality 'was reviewed' is not
            # a positive integration test. Require a second native witness of
            # the same source's internal *safe* transition, physically bound
            # to the source, runner, process and scratch before/after bytes.
            branch=physical_ref(row.get('internal_branch_execution'),evidence_root,
                                'GUARD_INTERNAL_BRANCH:'+rel)
            demand(branch.get('schema')=='TICKSTORE_PRE_B06_INTERNAL_BRANCH_V001'
                   and branch.get('source_path')==rel
                   and branch.get('source_sha256')==index[rel]['sha256']
                   and branch.get('run_id')==run_id
                   and branch.get('native_windows') is True
                   and branch.get('scope')=='OWNED_ISOLATED_NTFS'
                   and branch.get('runner_sha256')==witness['runner_sha256']
                   and branch.get('source_entrypoint_reached') is True
                   and branch.get('guarded_transition_exercised') is True
                   and branch.get('production_modified') is False
                   and branch.get('protected_effects') is False
                   and type(branch.get('pid')) is int and branch['pid']>0
                   and type(branch.get('creation_filetime')) is int
                   and branch['creation_filetime']>0
                   and branch.get('exit_code')==0,
                   'GUARD_INTERNAL_NOT_EXECUTED:'+rel)
            changes=branch.get('isolated_transitions')
            demand(isinstance(changes,list) and bool(changes), 'GUARD_NO_TRANSITIONS:'+rel)
            for transition in changes:
                before=physical_blob(transition.get('before'),evidence_root,'GUARD_BEFORE:'+rel)
                after=physical_blob(transition.get('after'),evidence_root,'GUARD_AFTER:'+rel)
                demand(sha(before)!=sha(after) and
                       transition.get('before_sha256')==sha(before) and
                       transition.get('after_sha256')==sha(after),
                       'GUARD_TRANSITION_NOT_PROVEN:'+rel)
        roles.append(role)
    if native_required:
        demand(os.name=='nt','NATIVE_TARGET_NOT_EXECUTED_HERE')
    return {'schema':'TICKSTORE_PRE_B06_CONTRACT_REVIEW_V001',
            'status':'EVIDENCE_CONSISTENCY_PASS_NOT_AUDIT' if native_required else 'CONTRACT_ONLY_NOT_NATIVE',
            'consumers_verified':11,'positive_count':roles.count(SAFE),
            'guard_count':roles.count(GUARD), 'g5_final':'NOT_ISSUED',
            'b06':'NOT_STARTED','full_started':False,
            'five_part_completeness':'NOT_EVALUATED','operational_effect_authority':False}


def verify_archive_dossier(dossier, final_members, native_members, code_sha):
    """Read V002 Windows technical records from a sealed return ZIP.

    This is a receipt *consistency* check, not independent attestation.
    Temporary staging contains only verified candidate/evidence bytes; no
    operational target or protected path is opened, changed, or installed.
    """
    import tempfile
    import zipfile
    import os
    demand(isinstance(final_members,dict) and isinstance(native_members,dict),'ARCHIVE_MEMBERS')
    manifest_raw=final_members.get('implementation_v001/RUNTIME_CODE_MANIFEST.json')
    demand(isinstance(manifest_raw,bytes) and sha(manifest_raw)==code_sha,'ARCHIVE_CODE_MANIFEST')
    manifest=strict(manifest_raw)
    demand(manifest.get('schema')=='TICKSTORE_FINAL_RUNTIME_CODE_MANIFEST_V001','ARCHIVE_CODE_SCHEMA')
    entries=manifest.get('files')
    demand(isinstance(entries,list),'ARCHIVE_CODE_FILES')
    expected_names={'implementation_v001/candidate/'+e['path'] for e in entries}
    demand(expected_names<=set(final_members),'ARCHIVE_CODE_SET')
    evidence_set={k:v for k,v in native_members.items() if k.startswith('EVIDENCE/PRE_B06/')}
    demand(bool(evidence_set),'ARCHIVE_EVIDENCE_EMPTY')
    demand(sum(map(len,evidence_set.values())) < 64*1024**2,'ARCHIVE_EVIDENCE_TOO_LARGE')
    with tempfile.TemporaryDirectory(prefix='cdt19_pre_b06_consistency_') as scratch:
        root=Path(scratch)
        src=root/'candidate';src.mkdir()
        (root/'RUNTIME_CODE_MANIFEST.json').write_bytes(manifest_raw)
        for entry in entries:
            rel=entry['path'];raw=final_members['implementation_v001/candidate/'+rel]
            demand(len(raw)==entry['bytes'] and sha(raw)==entry['sha256'],'ARCHIVE_CODE_MEMBER:'+rel)
            dest=src.joinpath(*rel.split('/'));dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(raw)
        evidence=root/'EVIDENCE';evidence.mkdir()
        for name,raw in evidence_set.items():
            rel=name[len('EVIDENCE/PRE_B06/'):]
            demand(bool(rel) and not rel.startswith('/') and '\\' not in rel and ':' not in rel
                   and all(x not in ('','.','..') for x in rel.split('/')),'ARCHIVE_EVIDENCE_PATH')
            dest=evidence.joinpath(*rel.split('/'));dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(raw)
        result=verify_dossier(dossier,src,evidence,native_required=False)
        demand(result.get('consumers_verified')==11,'ARCHIVE_ELEVEN_NOT_COMPLETE')
        return result
