"""CDT17 B1 formal proof consumer -- pure read-only, fail closed.

A scoped C5/R44 result is not a formal gate. No formal B1 receipt is emitted
without a NEW Windows qualification bound to the exact final candidate,
active FROZEN policy and the complete physical 126-ID source record.
This consumer never approves G5, B06 or production and never mutates source.
"""
from __future__ import annotations
import hashlib
import io
import json
import re
import zipfile
from pathlib import PurePosixPath

EXPECTED_MASTER_SHA = '270753E5577C4C80E4438DB1DC1390ECD2E78BF9C8D0E041C76573E86F7289A4'
EXPECTED_HEAD_SHA = '5090D7775B7D26ED51D07822162FDDFB36D0A7E9B0D7EBF184F526F91B037DE1'
EXPECTED_REV = '20261015T184900-0300-270753E5577C4C80'
SCHEMA = 'TICKSTORE_CDT17_B1_FORMAL_NATIVE_RECEIPT_V001'
NATIVE_RETURN_SCHEMA = 'TICKSTORE_CDT17_B1_FINAL_NATIVE_RETURN_MANIFEST_V001'
REQUIRED_NEW_TESTS = (
    'formal.source_126',
    'formal.policy_r45',
    'formal.package_closed_set',
    'formal.native_bound_final_code',
    'negative.missing_source',
    'negative.mismatched_policy',
    'negative.changed_final_package',
    'negative.incomplete_native_return',
    'negative.duplicate_test_id',
    'negative.terminal_status_not_pass',
)
CONTEXT = 'ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão de Ticks 17'
MAX_ZIP_MEMBERS = 400
MAX_ZIP_UNCOMPRESSED = 32_000_000

class Blocked(ValueError):
    pass

def require(p, label):
    if not p:
        raise Blocked(label)

def sha(b):
    require(type(b) is bytes, 'INPUT_NOT_BYTES')
    return hashlib.sha256(b).hexdigest().upper()

def js(raw):
    def pairs(seq):
        out={}
        for k,v in seq:
            require(k not in out, 'DUPLICATE_JSON_KEY:'+str(k))
            out[k]=v
        return out
    return json.loads(raw.decode('utf-8'),object_pairs_hook=pairs)

def safe_zip(raw, label):
    require(type(raw) is bytes and len(raw) <= 25_000_000, label+':SIZE')
    try:
        z=zipfile.ZipFile(io.BytesIO(raw))
        names=z.namelist()
    except (zipfile.BadZipFile, OSError) as ex:
        raise Blocked(label+':BAD_ZIP') from ex
    require(len(names) and len(names)<=MAX_ZIP_MEMBERS and len(names)==len(set(names)), label+':MEMBER_SET')
    require(sum(i.file_size for i in z.infolist())<=MAX_ZIP_UNCOMPRESSED, label+':EXPANDED_SIZE')
    for i in z.infolist():
        n=i.filename
        p=PurePosixPath(n)
        require(n and not n.endswith('/') and not n.startswith('/') and '\\' not in n and ':' not in n
                and not n.startswith('//') and all(s not in ('','..','.') for s in n.split('/')),
                label+':UNSAFE_PATH')
        require((i.external_attr >> 16) & 0o170000 != 0o120000, label+':SYMLINK')
    require(z.testzip() is None, label+':CRC')
    return z

def manifest_members(z, manifest_name, schema, label):
    require(manifest_name in z.namelist(), label+':MISSING_MANIFEST')
    m=js(z.read(manifest_name))
    require(m.get('schema')==schema, label+':MANIFEST_SCHEMA')
    records=m.get('files')
    if isinstance(records,list):
        require(all(isinstance(i,dict) and set(i)>= {'path','sha256','bytes'} for i in records),label+':RECORD')
        records={i['path']:i for i in records}
        require(len(records)==len(m['files']),label+':DUPLICATE_RECORD')
        expected={k:(v['sha256'],v['bytes']) for k,v in records.items()}
    else:
        require(isinstance(records,dict),label+':RECORDS')
        expected={k:(v,None) for k,v in records.items()}
    require(set(expected)==set(z.namelist())-{manifest_name},label+':CLOSED_SET')
    for name,(h,n) in expected.items():
        raw=z.read(name)
        require(isinstance(h,str) and re.fullmatch('[0-9A-F]{64}',h) and sha(raw)==h
                and (n is None or n==len(raw)), label+':BYTES:'+name)
    return m

def verify_policy(master,head):
    require(sha(master)==EXPECTED_MASTER_SHA and sha(head)==EXPECTED_HEAD_SHA, 'POLICY_PHYSICAL_HASH')
    h=js(head)
    require(h.get('state')=='FROZEN' and h.get('revision_id')==EXPECTED_REV
            and h.get('master_sha256')==sha(master) and h.get('master_path')=='/POLITICA_CANONICA_ATIVA/POLITICA_CANONICA_UNIFICADA_OPERACIONAL.md',
            'POLICY_ACTIVE_LINK')
    return h

def verify_native_return(raw, *, final_sha, runtime_manifest_sha, issuer_sha):
    z=safe_zip(raw,'NATIVE')
    manifest_members(z,'RETURN_MANIFEST.json',NATIVE_RETURN_SCHEMA,'NATIVE')
    require(set(z.namelist())=={'RETURN_MANIFEST.json','QUAL_RECEIPT.json','TESTS.json','TESTS.log'},'NATIVE:EXACT_SET')
    q=js(z.read('QUAL_RECEIPT.json'))
    require(q.get('schema')==SCHEMA and q.get('status')=='PASS_NATIVE_INTEGRATED'
            and q.get('platform')=='win32' and q.get('powershell_major')==5
            and q.get('final_zip_sha256')==final_sha
            and q.get('runtime_manifest_sha256')==runtime_manifest_sha
            and q.get('b1_formal_source_sha256')==issuer_sha
            and q.get('policy_master_sha256')==EXPECTED_MASTER_SHA
            and q.get('policy_head_sha256')==EXPECTED_HEAD_SHA
            and q.get('policy_revision_id')==EXPECTED_REV
            and q.get('tested_code_equals_packaged_code')=='PASS'
            and q.get('production_execution') is False
            and q.get('result_return_to')==CONTEXT,
            'NATIVE:QUAL_RECEIPT_BINDINGS')
    tests=js(z.read('TESTS.json'))
    require(isinstance(tests,list) and len(tests)==len(REQUIRED_NEW_TESTS)
            and all(isinstance(t,dict) and set(t)=={'id','status'} for t in tests)
            and len({t['id'] for t in tests})==len(tests)
            and set(t['id'] for t in tests)==set(REQUIRED_NEW_TESTS)
            and all(t['status']=='PASS' for t in tests), 'NATIVE:TEST_SET')
    log=z.read('TESTS.log').decode('utf-8')
    require('Ran 10 tests' in log and 'OK' in log and 'FAILED' not in log,'NATIVE:LOG')
    require(q.get('tests_run')==len(REQUIRED_NEW_TESTS) and q.get('failures')==q.get('errors')==q.get('skips')==0,
            'NATIVE:TEST_TOTALS')
    return q

def verify_final_package(raw, issuer_source):
    z=safe_zip(raw,'FINAL')
    manifest_members(z,'PACKAGE_MANIFEST.json','TICKSTORE_FINAL_PACKAGE_MANIFEST_V001','FINAL')
    prefix='implementation_v001/'
    runtime_file=prefix+'RUNTIME_CODE_MANIFEST.json'
    require(runtime_file in z.namelist(),'FINAL:RUNTIME_MANIFEST_MISSING')
    runtime_raw=z.read(runtime_file)
    runtime=js(runtime_raw)
    require(runtime.get('schema')=='TICKSTORE_FINAL_RUNTIME_CODE_MANIFEST_V001','FINAL:RUNTIME_SCHEMA')
    files=runtime.get('files',[])
    require(len(files)>=141 and len({i['path'] for i in files})==len(files), 'FINAL:RUNTIME_CARDINALITY')
    for item in files:
        rel=item['path']
        name=prefix+'candidate/'+rel
        require(name in z.namelist() and len(z.read(name))==item['bytes'] and sha(z.read(name))==item['sha256'],
                'FINAL:RUNTIME_BYTES:'+rel)
    issuer_name=prefix+'candidate/control/B1_FORMAL_ADMISSION.py'
    require(issuer_name in z.namelist() and z.read(issuer_name)==issuer_source,'FINAL:ISSUER_NOT_PACKAGED')
    require('control/B1_FORMAL_ADMISSION.py' in {i['path'] for i in files},'FINAL:ISSUER_NOT_RUNTIME')
    return sha(runtime_raw)

def evaluate(provenance_map, evidence_zip, b1_delta_zip, c5_parent_zip, final_zip,
             native_final_return, policy_master, policy_head, issuer_source,
             distributed_consumer):
    """Emit a FORMAL B1 scoped receipt only after every real input verifies.

    The native return must come from the final Windows runtime. Any missing
    input raises Blocked: no receipt, no fallback to historical returns.
    """
    verify_policy(policy_master,policy_head)
    dist=distributed_consumer(provenance_map,evidence_zip,b1_delta_zip,c5_parent_zip)
    require(dist.get('status')=='PASS_DISTRIBUTED_EVIDENCE_ONLY'
            and dist.get('verified_test_ids')==126 and dist.get('remediations')==7
            and dist.get('b1_formal_gate')=='NOT_ISSUED' and dist.get('g5_formal_gate')=='NOT_ISSUED',
            'B1:SCOPED_EVIDENCE_CONSUMER')
    runtime_sha=verify_final_package(final_zip,issuer_source)
    final_sha=sha(final_zip)
    verify_native_return(native_final_return,final_sha=final_sha,
                         runtime_manifest_sha=runtime_sha,issuer_sha=sha(issuer_source))
    return {
        'schema':'TICKSTORE_CDT17_B1_FORMAL_ADMISSION_V001',
        'status':'PASS', 'gate':'B1_FORMAL',
        'scope':'B1_ONLY_NO_G5_B06_RELEASE',
        'policy_master_sha256':sha(policy_master),'policy_head_sha256':sha(policy_head),
        'policy_revision_id':EXPECTED_REV,
        'final_zip_sha256':final_sha, 'runtime_manifest_sha256':runtime_sha,
        'issuer_sha256':sha(issuer_source),'native_return_sha256':sha(native_final_return),
        'sources':{
           'b1_provenance_sha256':sha(provenance_map),'evidence_zip_sha256':sha(evidence_zip),
           'b1_delta_sha256':sha(b1_delta_zip),'c5_parent_sha256':sha(c5_parent_zip),
        },
        'legacy_b1_126_ids':126,'new_consumer_native_tests':len(REQUIRED_NEW_TESTS),
        'g5_formal_gate':'NOT_ISSUED','b06':'NOT_STARTED','full_started':False,
        'result_return_to':CONTEXT,
    }
