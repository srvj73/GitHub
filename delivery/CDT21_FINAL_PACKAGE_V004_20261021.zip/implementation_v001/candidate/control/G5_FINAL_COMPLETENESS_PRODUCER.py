"""Post-native G5 evidence producer for the exact frozen FULL engineering candidate.

This is an INTERNAL provenance verifier and copy-only preparer. It cannot issue
OWNER_RELEASE_AUTHORITY decisions, B06 verdicts or protected production effects.
It returns nonzero if any prerequisite is missing, unproved or contradictory.
Five-part files are substantive only when independently supplied closed native
logs and a separate adversarial source/ABI review match the final package.
"""
from __future__ import annotations
import argparse,hashlib,json,os,re,shutil,sys,zipfile
from pathlib import Path
# -I excludes the script directory: bind the sibling proof gate from this sealed code root.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from FULL_G5_COMPLETE_PROOF_GATE import FIVE,ROLES,strict,digest,PROOFS,SUITES,G5Incomplete

class Blocked(RuntimeError):pass
HEX=re.compile(r'[0-9A-F]{64}\Z')

def req(ok,why):
    if not ok:raise Blocked(why)
def hash_path(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest().upper()
def canonical(obj):
    return (json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode('utf8')
def copy_new(source,dest):
    source,dest=Path(source),Path(dest);dest.parent.mkdir(parents=True,exist_ok=True)
    raw=source.read_bytes()
    with dest.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    req(dest.read_bytes()==raw,'COPY_READBACK:'+str(dest));return dest

def closed_zip(path,required=None):
    with zipfile.ZipFile(path) as z:
        infos=z.infolist();names=[i.filename for i in infos];req(len(names)==len({n.casefold() for n in names}),'DUPLICATE_ZIP_PATH')
        req(z.testzip() is None,'ZIP_CRC')
        req(all(not i.is_dir() and i.filename and not i.filename.startswith('/') and '\\' not in i.filename and ':' not in i.filename
                and all(x not in ('','.','..') for x in i.filename.split('/')) and ((i.external_attr>>16)&0xF000)!=0xA000
                for i in infos),'UNSAFE_ZIP_MEMBER')
        if required:req(set(required)<=set(names),'ZIP_REQUIRED_MEMBER_MISSING')
        return {n:z.read(n) for n in names}

def verified_native(native_zip,code_sha,package_sha,runtime_index=None,*,final_zip=None):
    from FULL_G5_COMPLETE_PROOF_GATE import verify_native_campaign
    return verify_native_campaign(Path(native_zip).read_bytes(),code_sha,package_sha,runtime_index,final_members=verify_final_zip(final_zip)[1] if final_zip is not None else None)


def verify_final_zip(path):
    members=closed_zip(path,{'PACKAGE_MANIFEST.json','implementation_v001/RUNTIME_CODE_MANIFEST.json'})
    m=strict(members['PACKAGE_MANIFEST.json'])
    req(m.get('schema')=='TICKSTORE_FINAL_PACKAGE_MANIFEST_V001','FINAL_PACKAGE_SCHEMA')
    rows=m['files'];req(len(rows)==len(members)-1 and {r['path'] for r in rows}==set(members)-{'PACKAGE_MANIFEST.json'},'FINAL_MEMBER_SET')
    req(all(len(members[r['path']])==r['bytes'] and digest(members[r['path']])==r['sha256'] for r in rows),'FINAL_MEMBER_HASH')
    code=members['implementation_v001/RUNTIME_CODE_MANIFEST.json'];cm=strict(code)
    req(cm.get('schema')=='TICKSTORE_FINAL_RUNTIME_CODE_MANIFEST_V001','RUNTIME_MANIFEST_SCHEMA')
    req({x['path'] for x in cm['files']}=={n.removeprefix('implementation_v001/candidate/') for n in members
        if n.startswith('implementation_v001/candidate/')},'FINAL_RUNTIME_MEMBER_SET')
    req(all(digest(members['implementation_v001/candidate/'+r['path']])==r['sha256'] and
        len(members['implementation_v001/candidate/'+r['path']])==r['bytes'] for r in cm['files']), 'FINAL_RUNTIME_MEMBER_HASH')
    return digest(code),members

def inspect_pre_b06_eleven(dossier_path, candidate_root, evidence_root, *, native_required=True):
    """Diagnostic input only. Does not manufacture the five-part PASS receipt.

    Intended to be called before the existing V003 final producer, with actual
    native Windows witnesses. This separate contract is not D4 admission.
    """
    from FULL_G5_COMPLETE_PROOF_GATE import inspect_pre_b06_eleven_consumer_evidence
    return inspect_pre_b06_eleven_consumer_evidence(strict(Path(dossier_path).read_bytes()),
        candidate_root,evidence_root,native_required=native_required)


def produce(final_zip,native_zip,instance,adversarial,out_dir):
    out=Path(out_dir);req(not out.exists(),'OUTPUT_ALREADY_EXISTS')
    code_sha,members=verify_final_zip(final_zip);pack_sha=hash_path(final_zip)
    runtime_index={r['path']:r for r in strict(members['implementation_v001/RUNTIME_CODE_MANIFEST.json'])['files']}
    native,units,proofbytes=verified_native(native_zip,code_sha,pack_sha,runtime_index,final_zip=final_zip)
    inst_raw=Path(instance).read_bytes();inst=strict(inst_raw);inst_sha=digest(inst_raw)
    req(inst.get('schema')=='TICKSTORE_FULL_INSTANCE_V001' and
        inst.get('code_manifest_sha256')==code_sha,'INSTANCE_FINAL_CODE_BINDING')
    adv_raw=Path(adversarial).read_bytes();adv=strict(adv_raw)
    req(adv.get('schema')=='TICKSTORE_FINAL_ADVERSARIAL_ENGINEERING_ATTESTATION_V001' and
        adv.get('status')=='PASS' and adv.get('known_blockers')==[] and
        adv.get('candidate_sha256')==pack_sha and adv.get('code_manifest_sha256')==code_sha and
        adv.get('legacy_technical_consumer_count')==11 and
        adv.get('false_completeness_search')=='PASS' and
        adv.get('state_toctou_receipt_checkpoint_negative_controls')=='PASS' and
        adv.get('final_bytes_freeze')=='PASS' and
        adv.get('native_g5_return_sha256')==hash_path(native_zip), 'ADVERSARIAL_CLOSURE_NOT_PROVEN')
    # Final non-origin evidence only; do not mint a decision or pre-audit verdict.
    out.mkdir(parents=True)
    finals={'FINAL_PACKAGE_ZIP':copy_new(final_zip,out/'INPUTS/FINAL_PACKAGE.zip'),
            'NATIVE_RETURN_ZIP':copy_new(native_zip,out/'INPUTS/NATIVE_RETURN.zip'),
            'INSTANCE':copy_new(instance,out/'INPUTS/INSTANCE.json'),
            'ADVERSARIAL':copy_new(adversarial,out/'INPUTS/ADVERSARIAL.json')}
    logs={}
    for key,(member,_) in units.items():
        name='PROOF_NATIVE/'+member
        dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
        b=proofbytes[member]
        with dest.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
        req(dest.read_bytes()==b,'NATIVE_PROOF_READBACK:'+member)
        logs[key]=dest
    integration_files=('control/FULL_RELEASE_CHAIN.py','control/FULL_G5_COMPLETE_PROOF_GATE.py',
                       'control/ORIGIN_DECISION_BINDER.py','control/G5_C6_FORMAL_CONTRACT.py',
                       'control/G5_C6_FORMAL_STAGE_BUILDER.py','control/FULL_QUALIFICATION_CONTRACT.py',
                       'control/G5_FINAL_COMPLETENESS_PRODUCER.py')
    if native.get('schema')=='CDT19_PRE_B06_NATIVE_ENGINEERING_V002':
        integration_files += ('control/PRE_B06_ENGINEERING_GATE.py',
                              'g5proof/NATIVE_EXECUTION_OBSERVER.py')
    integration={'schema':'CDT17_G5_FINAL_INTEGRATED_CODE_MANIFEST_V001','binding_mode':'FINAL_CANDIDATE',
                 'code_manifest_sha256':code_sha,'final_package_sha256':pack_sha,
                 'files':[{'path':f,'sha256':digest(members['implementation_v001/candidate/'+f]),
                           'bytes':len(members['implementation_v001/candidate/'+f])} for f in integration_files]}
    integration_raw=canonical(integration);integration_path=out/'G5_INTEGRATION_MANIFEST.json'
    with integration_path.open('xb') as f:f.write(integration_raw);f.flush();os.fsync(f.fileno())
    integration_code=out/'G5_INTEGRATION_SOURCE.py'
    integration_code.write_bytes(members['implementation_v001/candidate/control/G5_C6_FORMAL_CONTRACT.py'])
    req(hash_path(integration_code)==digest(members['implementation_v001/candidate/control/G5_C6_FORMAL_CONTRACT.py']),
        'INTEGRATION_CODE_READBACK')
    evidence_sets={
      FIVE[0]: ['G5_PROCESS_TREE_CRASH_CONTAINMENT','G5_SAFE_STOP_RESUME_ROW_GROUP','SUITE_adapter_tests.py','SUITE_test_full_multiwork.py'],
      FIVE[1]: ['SUITE_test_state_cas_recovery.py','SUITE_test_official_writer_effectful.py','SUITE_test_scratch_powerloss_debris.py'],
      FIVE[2]: ['SUITE_test_cdt17_final_g5_complete_proof_gate.py','SUITE_test_g5_proof_runner_contract.py','G5_PS51_INSTALL_MENU'],
      FIVE[3]: ['SUITE_test_b2d_origin_decision_binder.py','SUITE_test_operator_entry_points.py','G5_D4_REAL_ISOLATED_PATH_NATIVE'],
      FIVE[4]: ['SUITE_test_cdt16_held_rename_failure.py','SUITE_test_cdt16_native_pin_contract.py','G5_POWERLOSS_EMULATED']}
    chain_role='PRE_B06_11_CHAIN' if 'PRE_B06_11_CHAIN' in units else 'LEGACY_11_CHAIN'
    parts={}
    for part,names in evidence_sets.items():
        names = [*names, chain_role]
        refs=[{'role':n,'path':str(logs[n].absolute()),'sha256':hash_path(logs[n])} for n in names]
        refs+=[{'role':'FINAL_PACKAGE_ZIP','path':str(finals['FINAL_PACKAGE_ZIP'].absolute()),
                'sha256':pack_sha},{'role':'ADVERSARIAL_CLOSURE','path':str(finals['ADVERSARIAL'].absolute()),
                'sha256':hash_path(finals['ADVERSARIAL'])}]
        obj={'schema':'TICKSTORE_FINAL_COMPLETENESS_PROOF_V001','part':part,
             'status':'PASS','code_manifest_sha256':code_sha,'instance_sha256':inst_sha,'evidence':refs}
        p=out/'FIVE_PART_PROOFS'/(part+'.json');p.parent.mkdir(parents=True,exist_ok=True)
        with p.open('xb') as f:b=canonical(obj);f.write(b);f.flush();os.fsync(f.fileno())
        parts[part]={'status':'PASS','code_manifest_sha256':code_sha,'instance_sha256':inst_sha,
                     'path':str(p.absolute()),'sha256':hash_path(p)}
    comp={'schema':'TICKSTORE_ENGINEERING_COMPLETENESS_V003','status':'COMPLETE',
          'code_manifest_sha256':code_sha,'instance_sha256':inst_sha,
          'known_blockers':[],'full_started':False,'formal_audit_started':False,
          'five_part_completeness':parts,'native_g5_return_sha256':hash_path(native_zip),
          'final_package_sha256':pack_sha,'origin_decision_issued':False,
          'physical_powerloss':'NOT_TESTED_PHYSICAL_POWERLOSS'}
    pack={'schema':'TICKSTORE_G5_EVIDENCE_PACK_V001','completeness_status':'COMPLETE_FINAL',
          'known_blockers':[],'consumer_self_check':'ACCEPTS_FINAL_CANDIDATE',
          'code_manifest_sha256':code_sha,'gate_verdict_issued':False,
          'native_return_sha256':hash_path(native_zip),'final_package_sha256':pack_sha}
    stage={'schema':'TICKSTORE_CDT17_G5_STAGE_COMPLETENESS_V001','status':'COMPLETE_FINAL',
           'original_full_sha256':pack_sha,'full_candidate_completeness':'PASS',
           'formal_gate_verdict_issued':False,'native_g5_return_sha256':hash_path(native_zip),
           'physical_powerloss':'NOT_TESTED_PHYSICAL_POWERLOSS'}
    from FULL_G5_COMPLETE_PROOF_GATE import validate_g5_complete_proof
    for name,obj in [('ENGINEERING_COMPLETENESS',comp),('G5_EVIDENCE_PACK',pack),('G5_STAGE_COMPLETENESS',stage)]:
        p=out/(name+'.json')
        with p.open('xb') as f:b=canonical(obj);f.write(b);f.flush();os.fsync(f.fileno())
        req(p.read_bytes()==canonical(obj),'FINAL_G5_COPY_READBACK:'+name)
    # G5 issuer/owner decision must be physically supplied later.  The in-memory
    # exercise is a non-authoritative *contract check* using placeholder decision
    # semantics only; no such object is written or called an authorization.
    roles={'ENGINEERING_COMPLETENESS':out/'ENGINEERING_COMPLETENESS.json',
           'G5_EVIDENCE_PACK':out/'G5_EVIDENCE_PACK.json',
           'G5_STAGE_COMPLETENESS':out/'G5_STAGE_COMPLETENESS.json',
           'G5_INTEGRATION_MANIFEST':integration_path,
           'G5_INTEGRATION_SOURCE':integration_code,
           'NATIVE_RETURN_ZIP':finals['NATIVE_RETURN_ZIP'],
           'FINAL_PACKAGE_ZIP':finals['FINAL_PACKAGE_ZIP']}
    read=lambda p,h:Path(p).read_bytes()
    receipt={'stage':'G5','status':'PASS','environment':'WINDOWS_PRODUCTION',
             'code_manifest_sha256':code_sha,'instance_sha256':inst_sha,
             'full_candidate_completeness':'PASS','final_package_sha256':pack_sha,
             'origin_decision_sha256':digest(b'{}\n'),
             'evidence':[{'role':n,'path':str(p.absolute()),'sha256':hash_path(p)} for n,p in roles.items()]
             +[{'role':'ORIGIN_DECISION','path':'<NOT_ISSUED>','sha256':digest(b'{}\n')}]}
    # Guard test is intentionally expected to reject the nonexistent authority:
    # verifying this prohibition is not issuing a decision.
    try:
        validate_g5_complete_proof(receipt,code_sha,inst_sha,lambda p,h: b'{}\n' if p=='<NOT_ISSUED>' else read(p,h))
    except Exception as error:
        req('ORIGIN_DECISION_' in str(error),'FULL_CONSUMER_REJECTED_BEFORE_EXPECTED_ORIGIN_DECISION:'+str(error))
    else:raise Blocked('FULL_CONSUMER_ACCEPTED_NONEXISTENT_ORIGIN_DECISION')
    return {'status':'EVIDENCE_READY_ORIGIN_G5_NOT_ISSUED','code_manifest_sha256':code_sha,
            'final_package_sha256':pack_sha,'evidence_paths':{n:str(p) for n,p in roles.items()},
            'g5':'NOT_ISSUED','b06':'NOT_STARTED','full_started':False}

def main():
    p=argparse.ArgumentParser(allow_abbrev=False)
    for name in ('final-zip','native-return','instance','adversarial','out-dir'):p.add_argument('--'+name,required=True)
    a=p.parse_args()
    try:
        result=produce(a.final_zip,a.native_return,a.instance,a.adversarial,a.out_dir)
        print(json.dumps(result,sort_keys=True,indent=2));return 0
    except (Blocked,G5Incomplete,OSError,ValueError,KeyError,zipfile.BadZipFile) as error:
        print('G5_FINAL_PRODUCER=BLOCKED REASON='+str(error),file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
