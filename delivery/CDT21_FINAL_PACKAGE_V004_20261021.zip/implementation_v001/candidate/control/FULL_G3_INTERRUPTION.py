"""Close a provably dead G3 attempt as FAIL, retaining the same instance.

This is technical reconciliation, never a PASS or admission. The caller already
holds the guarded STATE boundary and release chain. A subsequent G3 runs the
real MULTIWORK recovery; G6 consumes its actual journal-bound result.
"""
from pathlib import Path
import os
import sys

from D4_FIRST_ADMISSION_PREP import canonical, require, sha, strict_json, validate_journal

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'full'))
import FULL_CRASH_RECOVERY as recovery


def identity(admission):
    return {k: admission.descriptor[k] for k in ('instance_sha256', 'code_manifest_sha256')} | {
        'run_id': admission.instance['run_id']}


def begin(o, ns, admission):
    admission.revalidate()
    state = recovery.core.secure_read_all(o.st.sp)
    journal = recovery.core.secure_read_all(o.st.jp)
    validate_journal(journal)
    require(strict_json(state) == o.st.d and o.st.d.get('next_node') == 'G3'
            and 'G3' not in o.st.d['completed'], 'G3_ATTEMPT_STATE')
    process = recovery.native_process(os.getpid())
    require(process.pop('state') == 'LIVE', 'G3_ATTEMPT_OWNER')
    body = dict(schema='TICKSTORE_G3_ATTEMPT_V001', binding=identity(admission),
                attempt_id=o.id, owner=process, state_before_sha256=sha(state),
                journal_before_sha256=sha(journal), journal_before_bytes=len(journal))
    for name, raw in [('G3_STATE_BEFORE.json', state), ('G3_JOURNAL_BEFORE.jsonl', journal),
                      ('G3_ATTEMPT.json', canonical(body))]:
        ns['immutable_receipt'](o.rd/name, raw)
    return {'g3_attempt_sha256': sha(canonical(body))}


def needs_reconciliation(journal_raw, state):
    validate_journal(journal_raw)
    if state.get('next_node') != 'G3' or 'G3' in state.get('completed', []):
        return False
    latest = [strict_json(line) for line in journal_raw.splitlines() if strict_json(line).get('node') == 'G3']
    if not latest:
        return False
    last = latest[-1]
    return last.get('phase') == 'STARTED' or (last.get('phase') == 'FINISHED'
            and last.get('status') == 'FAIL' and state.get('status') != 'FAIL'
            and str(last.get('primary_error', '')).startswith('PROCESS_DEATH_RECONCILED:'))


def reconcile(o, ns, admission, *, history_validator=None):
    """No lock deletion here. Only the next admitted G3 can retire its own lock."""
    journal = recovery.core.secure_read_all(o.st.jp)
    require(needs_reconciliation(journal, o.st.d), 'G3_NO_INTERRUPTED_ATTEMPT')
    lines = journal.splitlines(keepends=True)
    records = [strict_json(line) for line in lines]
    starts = [i for i, r in enumerate(records) if r.get('node') == 'G3' and r.get('phase') == 'STARTED']
    require(bool(starts), 'G3_NO_START')
    idx = starts[-1]; start = records[idx]; run = start.get('run_id')
    import re
    require(isinstance(run, str) and re.fullmatch('[A-Za-z0-9_-]+', run), 'G3_INTERRUPTED_RUN')
    rd = o.st.runs/run
    attempt, raw = recovery.read(rd/'G3_ATTEMPT.json')
    require(attempt.get('schema') == 'TICKSTORE_G3_ATTEMPT_V001'
            and attempt.get('binding') == identity(admission) and attempt.get('attempt_id') == run
            and start.get('g3_attempt_sha256') == sha(raw), 'G3_ATTEMPT_BINDING')
    prefix = b''.join(lines[:idx])
    require(len(prefix) == attempt['journal_before_bytes'] and sha(prefix) == attempt['journal_before_sha256']
            and recovery.core.secure_read_all(rd/'G3_JOURNAL_BEFORE.jsonl') == prefix, 'G3_PREDECESSOR_DRIFT')
    before = recovery.core.secure_read_all(rd/'G3_STATE_BEFORE.json')
    current = recovery.core.secure_read_all(o.st.sp)
    require(sha(before) == attempt['state_before_sha256'] and current == before
            and strict_json(current) == o.st.d, 'G3_INTERRUPTED_STATE_DRIFT')
    if history_validator is None:
        from FULL_STAGE_CONTINUATION import StageBoundary, validate_stage_history, last_closed_node
        last_closed_node(prefix, 'G2')
        validate_stage_history(prefix, StageBoundary('FULL'), o.st.d)
    else:
        # The pre-B06 lab has an explicitly non-operational predecessor. It
        # exercises this same recovery algorithm without manufacturing D4/G2.
        require(admission.instance.get('scope') == 'OWNED_ISOLATED_NTFS_PRE_B06'
                and admission.instance.get('operational_authority') is False,
                'G3_ENGINEERING_HISTORY_SCOPE')
        history_validator(prefix, o.st.d)
    observation = recovery.dead(attempt['owner'])
    bindings = admission.instance['bindings']
    scratch = Path(bindings['scratch_root'])/'RUN_INSTANCES'/admission.instance['run_id']
    expected = recovery.binding(admission, bindings['dest_root'], scratch)
    engine = []
    if recovery.core.strict_lstat(scratch/'RECOVERY_ATTEMPTS', allow_missing=True) is not None:
        for path in sorted((scratch/'RECOVERY_ATTEMPTS').iterdir()):
            owner, _ = recovery.read(path/'OWNER.json')
            if owner.get('owner') == attempt['owner']:
                _, proof = recovery.inspect_attempt(path, expected)
                engine.append(proof)
    # No runtime owner means G3 never reached child admission. A foreign lock
    # still blocks later in the runtime; it is not removed by journal repair.
    require(len(engine) <= 1, 'G3_MULTIPLE_ENGINE_ATTEMPTS')
    proof = dict(schema='TICKSTORE_G3_INTERRUPTION_RECONCILIATION_V001', binding=identity(admission),
                 attempt={'path': str(rd/'G3_ATTEMPT.json'), 'sha256': sha(raw)},
                 owner_observation=observation, engine_attempts=engine,
                 outcome='FAIL_RECONCILED_REENTER_G3', completed_inferred=False,
                 own_processes_alive=0, physical_powerloss='NOT_TESTED_PHYSICAL_POWERLOSS')
    path = rd/'G3_INTERRUPTION_RECONCILIATION.json'
    if recovery.core.strict_lstat(path, allow_missing=True) is None:
        recovery.publish(path, proof)
    else:
        existing, _ = recovery.read(path)
        # PID reuse/absence may change on a later reconciliation retry; immutable
        # original observations remain, while death is independently checked now.
        require(existing.get('attempt') == proof['attempt'] and existing.get('binding') == proof['binding']
                and existing.get('outcome') == proof['outcome'] and existing.get('own_processes_alive') == 0,
                'G3_RECONCILIATION_DRIFT')
    ref = {'path': str(path), 'sha256': sha(recovery.core.secure_read_all(path))}
    admission.revalidate()
    reason = 'PROCESS_DEATH_RECONCILED:' + ref['sha256']
    if idx == len(lines) - 1:
        o.st.finish('G3', 'FAIL', error=reason)
    else:
        require(idx == len(lines) - 2 and records[-1].get('phase') == 'FINISHED'
                and records[-1].get('node') == 'G3' and records[-1].get('status') == 'FAIL'
                and records[-1].get('primary_error') == reason, 'G3_JOURNAL_TAIL')
        o.st.d['status'] = 'FAIL'
        ns['atomj'](o.st.sp, o.st.d)
    require(strict_json(recovery.core.secure_read_all(o.st.sp)) == o.st.d, 'G3_RECOVERY_STATE_READBACK')
    return ref
