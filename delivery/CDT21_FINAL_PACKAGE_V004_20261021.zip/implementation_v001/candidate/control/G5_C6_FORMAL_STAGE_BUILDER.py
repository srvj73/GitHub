"""G5 new-format formal-stage integration. Source code is external overlay to immutable FINAL.
Creates no origin decision; FULL completeness deliberately remains NOT_PROVEN.
"""
from __future__ import annotations
import json,hashlib,os,sys, argparse
from pathlib import Path
from G5_C6_FORMAL_CONTRACT import sha,strict,verify,verify_provenance,PROV_SCHEMA,SCHEMA,ck

def canonical(obj):return (json.dumps(obj,sort_keys=True,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8')
def write_new(p,body):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(body);f.flush();os.fsync(f.fileno())
 ck(p.read_bytes()==body,'READBACK:'+p.name)
def build_formal(*,out_dir,inputs_dir,known_blockers=()):
 out=Path(out_dir);ck(not out.exists(),'OUTPUT_EXISTS')
 inp=Path(inputs_dir)
 names=('FULL.zip','G4_RETURN.zip','B1_HISTORY.zip','BASELINE.zip','G5_NATIVE_RETURN.zip')
 raw={n:(inp/n).read_bytes() for n in names}
 admission=verify(raw['FULL.zip'],raw['G4_RETURN.zip'],raw['B1_HISTORY.zip'],raw['BASELINE.zip'],raw['G5_NATIVE_RETURN.zip'])
 ck(not known_blockers,'KNOWN_G5_BLOCKERS')
 out.mkdir(parents=True)
 entries={}
 for n,v in raw.items():
  write_new(out/'INPUTS'/n,v)
  entries[n]={'path':'INPUTS/'+n,'sha256':sha(v),'bytes':len(v)}
 prov={'schema':PROV_SCHEMA,'inputs':entries,'reused_G4_proof_count':6,'historical_B1_not_rerun':126,'B1_formal_native_10':10}
 stage={'schema':SCHEMA,'status':'COMPLETE_SCOPED','full_candidate_completeness':'NOT_PROVEN',
       'formal_gate_verdict_issued':False,'b1_historical_executed_again':False,
       'original_full_sha256':sha(raw['FULL.zip']),'g4_return_sha256':sha(raw['G4_RETURN.zip']),
       'g5_native_return_sha256':sha(raw['G5_NATIVE_RETURN.zip']),
       'six_typed_receipt_sha256':{n:v['sha256'] for n,v in admission['six_typed_proofs'].items()},
       'native_windows_evidence_origin':'PRIOR_NATIVE_RETURNS_NOT_REEXECUTED',
       'physical_power_cut':'NOT_TESTED_PHYSICAL_POWERLOSS','blockers_scoped':[],
       'original_engine_bytes_unchanged':True,'gate_issue_requires_origin_policy_capture_and_decision':True}
 verify_provenance(prov,stage,out)
 write_new(out/'G5_STAGE_COMPLETENESS.json',canonical(stage))
 write_new(out/'DELTA_QUALIFICATION.json',canonical({
    'schema':'TICKSTORE_CDT15_DELTA_QUALIFICATION_V001','native_windows':False,
    'platform':'NOT_CURRENT_FULL_CANDIDATE_QUALIFIED','success':False,'production_execution':False,
    'code_manifest_sha256':admission['runtime_code_manifest_sha256'],
    'tested_code_equals_packaged_code':'OLD_FULL_ONLY','tests':[],
    'target_proofs':{},'historical_tests_not_reclassified_as_new':126,'native_provenance':prov}))
 write_new(out/'ENGINEERING_COMPLETENESS.json',canonical({
   'schema':'TICKSTORE_ENGINEERING_COMPLETENESS_V002','status':'INCOMPLETE','known_blockers':['FULL_CANDIDATE_COMPLETENESS_NOT_YET_PROVEN'],
   'integration_implemented':False,'windows_qualification':'NOT_PASS_FOR_NEW_FULL_CANDIDATE',
   'code_manifest_sha256':admission['runtime_code_manifest_sha256'],
   'g5_stage_scope_status':'COMPLETE_SCOPED', 'full_started':False,
   'baseline_results_counted_as_delta':False,'gate_verdict_issued':False}))
 pack={'schema':'TICKSTORE_G5_EVIDENCE_PACK_V001','completeness_status':'COMPLETE_SCOPED',
       'known_blockers':[],'consumer_self_check':'ACCEPTS_FORMAL_B1_SCOPED','gate_verdict_issued':False,
       'code_manifest_sha256':admission['runtime_code_manifest_sha256'],
       'g5_stage_completeness_sha256':sha((out/'G5_STAGE_COMPLETENESS.json').read_bytes()),
       'full_engineering_completeness_status':'INCOMPLETE','inputs':entries,
       'formal_provenance_sha256':sha(canonical(prov)),'six_proofs':6,
       'physical_power_cut':'NOT_TESTED_PHYSICAL_POWERLOSS'}
 write_new(out/'G5_EVIDENCE_PACK.json',canonical(pack))
 # Re-read the exact candidate production validator source, not a duplicate shortcut.
 import importlib.util
 spec=importlib.util.spec_from_file_location('cdt17_patched_qualifier',Path(__file__).with_name('FULL_QUALIFICATION_CONTRACT.py'))
 mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 try:
  mod.evaluate_formal_g5_stage(strict((out/'ENGINEERING_COMPLETENESS.json').read_bytes()),pack,stage,out,
                          strict((out/'DELTA_QUALIFICATION.json').read_bytes()))
 except Exception as error:
  raise ValueError('G5_INTEGRATED_CONSUMER_NOT_ACCEPTING:'+str(error)) from error
 write_new(out/'G5_STAGE_RECEIPT_DRAFT.json',canonical({
  'schema':'TICKSTORE_STAGE_RECEIPT_V001','stage':'G5','status':'PENDING_ORIGIN_DECISION',
  'environment':'NATIVE_WINDOWS_EVIDENCE_REUSED_NO_NEW_STAGE_ISSUANCE','blockers':[],
  'checks':{'features_implemented':None,'blockers_closed':True,
            'tested_equals_packaged':None,'adversarial_completeness':None,'byte_freeze':None},
  'formal_stage_verdict_issued':False,'full_started':False}))
 return stage

def main(argv=None):
 p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('--inputs-dir',required=True);p.add_argument('--out-dir',required=True);a=p.parse_args(argv)
 try:
  s=build_formal(inputs_dir=a.inputs_dir,out_dir=a.out_dir)
  print('G5_STAGE_EVIDENCE='+s['status']+' G5_FORMAL=NOT_ISSUED FULL_CANDIDATE_COMPLETENESS=NOT_PROVEN FULL_STARTED=NO')
  print('G5_OUTPUT_DIR='+str(Path(a.out_dir).absolute()))
  return 0
 except Exception as e:
  print('G5_STAGE_EVIDENCE=BLOCKED REASON='+type(e).__name__+':'+str(e),file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
