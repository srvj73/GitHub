"""Overlay for MULTIWORK completion and technical readmission of the same instance.

The frozen orchestrator is never edited. G3 produces physical reconciliation
evidence; H1/H2/H4/H5/H6 retain their original implementations. H3 consumes the
exact G3 result named by the journal, never the newest file from another run.
"""
from pathlib import Path
import time
import os
import stat

from D4_FIRST_ADMISSION_PREP import Reads, canonical, require, sha, strict_json
from FULL_RELEASE_CHAIN import REQUIRED_CHECKS
from FULL_STAGE_EVIDENCE import closed_results, publish, checks_from_closed_results


def verify_postfull(reconciliation, h2):
    require(reconciliation.get('schema') == 'TICKSTORE_MULTIWORK_RECONCILIATION_V001'
            and reconciliation.get('status') == 'PASS', 'FULL_RECONCILIATION_NOT_PASS')
    deep = h2.get('deep', {}); independent = h2.get('independent', {})
    require(isinstance(deep, dict) and isinstance(independent, dict)
            and deep.get('POST_FULL_AUDIT') == 'PASS'
            and independent.get('schema') == 'POSTFULL_INDEPENDENT_VERIFIER_V001'
            and independent.get('status') == 'PASS', 'FULL_POSTVERIFY_NOT_PASS')
    # The native frozen postverify() and independent verifier must agree on the
    # same published bytes and on the exact certified dataset, not only on rows.
    expected_counts = {'days': 1550, 'rows': 7049522162, 'namespace': 3101}
    for key, expected in expected_counts.items():
        require(type(deep.get(key)) is int and deep[key] == expected,
                'FULL_POSTVERIFY_EXPECTED:' + key)
    for key in ('days', 'rows', 'manifest_sha256'):
        require(deep.get(key) is not None and deep[key] == reconciliation.get(key),
                'FULL_POSTVERIFY_MISMATCH:' + key)
    require(isinstance(deep.get('manifest_sha256'), str)
            and len(deep['manifest_sha256']) == 64
            and all(c in '0123456789ABCDEF' for c in deep['manifest_sha256']),
            'FULL_POSTVERIFY_MANIFEST_SHA256')
    require(type(independent.get('days')) is int and independent['days'] == deep['days']
            and type(independent.get('rows')) is int and independent['rows'] == deep['rows']
            and type(independent.get('namespace_files')) is int
            and independent['namespace_files'] == deep['namespace']
            and independent.get('manifest_sha256') == deep['manifest_sha256'],
            'FULL_INDEPENDENT_READBACK_MISMATCH')
    return {'FINAL_VS_POSTFULL': 'PASS', 'manifest_sha256': deep['manifest_sha256']}


def verify_g3_recovery_trace(reconciliation):
    """Validate causal G3 normalization; cannot invent a crash-resume PASS.

    A clean startup legitimately has zero pre-parallel recoveries. Post-crash
    evidence additionally needs a native terminated-tree witness: this function
    does not manufacture one from a G3 PASS receipt.
    """
    trace = reconciliation.get('pre_multiwork_recovery')
    require(isinstance(trace,dict) and
            trace.get('schema')=='TICKSTORE_G3_PREPARALLEL_RECOVERY_TRACE_V001' and
            trace.get('status')=='PASS_NORMALIZED' and
            trace.get('post_normalization_transient_count')==0 and
            trace.get('crash_origin_attestation')=='NOT_PROVEN_BY_NORMALIZATION_ALONE' and
            trace.get('physical_powerloss')=='NOT_TESTED_PHYSICAL_POWERLOSS',
            'G3_NORMALIZATION_WITNESS_MISSING')
    days=trace.get('observed_transient_dates'); rows=trace.get('normalized')
    require(isinstance(days,list) and isinstance(rows,list) and
            type(trace.get('recovered_count')) is int and
            len(rows)==len(days)==trace['recovered_count'] and
            len(set(days))==len(days) and
            all(isinstance(d,str) and len(d)==8 and d.isdigit() for d in days) and
            all(isinstance(r,dict) and r.get('date_key')==k and
                r.get('status') in ('REUSED','RESUMED','RESUMED_PUBLICATION','RESUMED_MANIFEST','BUILT')
                for k,r in zip(days,rows)),
            'G3_NORMALIZATION_CAUSAL_MISMATCH')
    return {'g3_normalization':'PASS',
            'g3_observed_recovered_days':len(days),
            'g3_post_crash_test':'NOT_PROVEN_BY_G3_RECEIPT',
            'physical_powerloss':'NOT_TESTED_PHYSICAL_POWERLOSS'}


def _full_multiwork_g6(o):
    """Qualify installed G6 only. Never invoke legacy n_g6/n_g3/stale.

    Any lock or recovery process remains a blocked reconciliation case. A
    separate post-B07, run-bound protocol must authorize actual stale recovery.
    """
    dest=Path(o.cfg['production_dest_root'])
    try:
        # A missing root is not an absent writer-lock proof. Detect reparse
        # traversal and refuse partial visibility rather than treating it as 0.
        for ancestor in (*reversed(dest.parents),dest):
            if not ancestor.exists() or not ancestor.is_dir():
                raise RuntimeError('FULL_G6_DEST_ROOT_MISSING')
            attrs=os.lstat(ancestor)
            if stat.S_ISLNK(attrs.st_mode) or (getattr(attrs,'st_file_attributes',0)&0x400):
                raise RuntimeError('FULL_G6_ROOT_REPARSE')
        lock=dest/'TICKSTORE_WRITER.lock'
        try:
            os.lstat(lock)
        except FileNotFoundError:
            pass
        else:
            raise RuntimeError('FULL_WRITER_LOCK_RECONCILIATION_REQUIRED')
        census=o.eng.recovery_process_census()
        count=census['known_recovery_supervisor_or_workers']
        if type(count) is not int or count!=0:
            raise RuntimeError('FULL_PROCESS_RECONCILIATION_REQUIRED')
        # Revalidate absence after the potentially blocking process census.
        # This is NOT an exclusive lock; admission must still own its lease.
        try:
            os.lstat(lock)
        except FileNotFoundError:
            pass
        else:
            raise RuntimeError('FULL_WRITER_LOCK_RECONCILIATION_REQUIRED')
        return {'RECONCILE':'PASS','writer_lock':'ABSENT','action':'NONE',
                'engine':'MULTIWORK','legacy_recovery_invoked':False,
                'scope':'SAME_INSTANCE_INSTALLED_G6_NO_RECOVERY_EFFECT'}
    except OSError as exc:
        raise RuntimeError('FULL_G6_IO_VISIBILITY_BLOCKED') from exc


def verify_dead_predecessors(reconciliation, admission, read):
    """Consume immutable ownership receipts; keep deliberate-kill attestation separate."""
    from FULL_CRASH_RECOVERY import binding, dead, core
    bindings = admission.instance['bindings']
    scratch = Path(bindings['scratch_root'])/'RUN_INSTANCES'/admission.instance['run_id']
    expected = binding(admission, bindings['dest_root'], scratch)
    root = scratch/'RECOVERY_ATTEMPTS'

    def consume(meta, name):
        require(isinstance(meta, dict) and set(meta) == {'path', 'sha256'}, 'FULL_G6_OWNERSHIP_REF')
        path = Path(meta['path'])
        require(path.name == name and path.parent.parent == root
                and len(path.parent.name) == 32
                and all(c in '0123456789abcdef' for c in path.parent.name), 'FULL_G6_OWNERSHIP_SCOPE')
        return strict_json(read(path, meta['sha256']))

    def identities(observations):
        require(isinstance(observations, list), 'FULL_G6_DEATH_OBSERVATIONS')
        keys = []
        for process in observations:
            require(isinstance(process, dict) and process.get('observation') in
                    ('ABSENT', 'EXITED', 'PID_REUSED_OLD_OWNER_DEAD'), 'FULL_G6_DEATH_OBSERVATION_KIND')
            dead(process)
            keys.append((process['pid'], process['creation_filetime']))
        require(len(keys) == len(set(keys)), 'FULL_G6_DUPLICATE_PROCESS')
        return set(keys)

    def children(owner_ref, declared=None):
        directory = Path(owner_ref['path']).parent
        core.strict_directory(directory)
        actual = []
        keys = set()
        for path in sorted(directory.glob('CHILD_*.json')):
            raw = read(path)
            child = strict_json(raw)
            ident = child.get('identity', {})
            require(child.get('schema') == 'TICKSTORE_MULTIWORK_CHILD_OWNER_V001'
                    and child.get('owner_sha256') == owner_ref['sha256']
                    and path.name == 'CHILD_%s_%s.json' % (ident.get('pid'), ident.get('creation_filetime')),
                    'FULL_G6_CHILD_BINDING')
            dead(ident)
            key = (ident['pid'], ident['creation_filetime'])
            require(key not in keys, 'FULL_G6_DUPLICATE_CHILD')
            keys.add(key)
            actual.append({'path': str(path), 'sha256': sha(raw)})
        if declared is not None:
            require(declared == actual, 'FULL_G6_CHILD_SET')
        return keys

    owner = consume(reconciliation['attempt_owner'], 'OWNER.json')
    require(owner.get('binding') == expected
            and owner.get('schema') == 'TICKSTORE_MULTIWORK_ATTEMPT_OWNER_V001'
            and owner.get('attempt_id') == Path(reconciliation['attempt_owner']['path']).parent.name,
            'FULL_G6_CURRENT_OWNER_BINDING')
    closed = consume(reconciliation['attempt_closed'], 'CLOSED.json')
    require(Path(reconciliation['attempt_owner']['path']).parent == Path(reconciliation['attempt_closed']['path']).parent
            and closed.get('owner_sha256') == reconciliation['attempt_owner']['sha256']
            and closed.get('outcome') == 'ENGINE_RECONCILED' and closed.get('writer_lock') == 'ABSENT'
            and closed.get('own_processes_alive') == 0
            and closed.get('schema') == 'TICKSTORE_MULTIWORK_ATTEMPT_CLOSED_V001', 'FULL_G6_CURRENT_ATTEMPT_NOT_CLOSED')
    require(identities(closed.get('process_observations')) == children(reconciliation['attempt_owner']),
            'FULL_G6_CLOSED_CHILD_SET')
    refs = reconciliation.get('predecessor_attempts')
    require(isinstance(refs, list) and len(refs) == len({r.get('path') for r in refs}), 'FULL_G6_PREDECESSOR_SET')
    for meta in refs:
        receipt = consume(meta, 'RETIRED.json')
        previous = consume(receipt.get('owner'), 'OWNER.json')
        require(receipt.get('schema') == 'TICKSTORE_MULTIWORK_DEAD_ATTEMPT_V001'
                and receipt.get('binding') == previous.get('binding') == expected
                and receipt.get('own_processes_alive') == 0
                and receipt.get('lock_disposition') in ('NO_LOCK_BEFORE_ADMISSION',
                    'RETIRED_EXACT_DEAD_OWNER_HANDLE', 'ALREADY_ABSENT_DEAD_OWNER'), 'FULL_G6_DEAD_PREDECESSOR')
        dead(previous['owner'])
        require(Path(meta['path']).parent == Path(receipt['owner']['path']).parent
                and Path(meta['path']).parent != Path(reconciliation['attempt_owner']['path']).parent
                and previous.get('schema') == 'TICKSTORE_MULTIWORK_ATTEMPT_OWNER_V001'
                and previous.get('attempt_id') == Path(meta['path']).parent.name,
                'FULL_G6_PREDECESSOR_DIRECTORY')
        observations = receipt.get('process_observations')
        require(isinstance(receipt.get('children'), list), 'FULL_G6_CHILD_REFS_REQUIRED')
        expected_identities = children(receipt['owner'], receipt['children'])
        expected_identities.add((previous['owner']['pid'], previous['owner']['creation_filetime']))
        require(identities(observations) == expected_identities, 'FULL_G6_PREDECESSOR_PROCESS_SET')
    return {'g3_dead_predecessors_verified': len(refs), 'g3_ownership_closed': True}


def install(o, ns, admission, workers, *, engineering_probe=None):
    """Install only after chain, config, STATE and native boundary are held."""
    import tickstore_full_multiwork as multi
    original = o.runnode
    from FULL_G3_INTERRUPTION import begin
    ns['begin_g3_attempt'] = lambda: begin(o, ns, admission)

    def dispatch(node):
        if node == 'G3':
            instance = admission.instance; bindings = instance['bindings']; limits = instance['resources']
            received = []

            def complete(result):
                require(not received, 'FULL_DUPLICATE_RECONCILIATION')
                raw = canonical(result); path = o.rd/'MULTIWORK_RECONCILIATION.json'
                ns['immutable_receipt'](path, raw)
                admission.read(path, sha(raw)); admission.revalidate()
                received.append({'path': str(path), 'sha256': sha(raw)})

            try:
                code = multi._execute_admitted_multiwork(
                    *(Path(bindings[k + '_root']) for k in ('source', 'dest', 'scratch')),
                    Path(instance['ledger_path']), workers, limits['max_workers'],
                    limits['ram_target_percent'], admission, completion=complete,
                    engineering_probe=engineering_probe)
            except multi.CooperativeSafeStop:
                # MULTIWORK raises this only after its cooperative cleanup succeeds;
                # forced termination or cleanup failure is a non-resumable error.
                o.st.d['full_safe_stop'] = True
                raise ns['SafeStopFlow']('MULTIWORK_COOPERATIVE_STOP')
            require(code == 0 and len(received) == 1, 'FULL_RECONCILIATION_RECEIPT_MISSING')
            o.st.d['full_safe_stop'] = False
            return {'FULL': 'PASS', 'reconciliation': received[0], 'run_id': instance['run_id']}
        if node == 'G5':
            require(o.st.d.get('full_safe_stop') is False, 'FULL_RESUME_MUST_REENTER_G3')
            return {'RESUME': 'NOT_REQUIRED', 'resume_node': 'G3', 'engine': 'MULTIWORK'}
        if node == 'G6':
            # G3 owns crash/recovery normalization. This is a *read-only*
            # same-instance postcondition; never run the obsolete legacy G6.
            with Reads() as evidence:
                results, _ = closed_results(evidence.read(o.st.jp), ('G3',), o.st.runs, evidence.read)
                meta = results['G3']['reconciliation']
                g3 = strict_json(evidence.read(meta['path'], meta['sha256']))
                require(g3.get('schema') == 'TICKSTORE_MULTIWORK_RECONCILIATION_V001'
                        and g3.get('status') == 'PASS'
                        and g3.get('run_id') == admission.instance['run_id']
                        and g3.get('instance_sha256') == admission.descriptor['instance_sha256']
                        and g3.get('code_manifest_sha256') == admission.descriptor['code_manifest_sha256'],
                        'FULL_G6_G3_SAME_INSTANCE_RECOVERY_NOT_PROVEN')
                recovery_verified = verify_g3_recovery_trace(g3)
                # Old R07 contract fixtures do not assert ownership recovery.
                # Any runtime ownership claim must include the complete new chain.
                if any(k in g3 for k in ('attempt_owner', 'attempt_closed', 'predecessor_attempts')):
                    recovery_verified.update(verify_dead_predecessors(g3, admission, evidence.read))
                evidence.revalidate()
            result = _full_multiwork_g6(o)
            # Tie only the physically supported G3 facts to the sealed receipt.
            # Never issue a generic g3_recovery_verified=True on a clean start.
            result['g3_reconciliation_sha256'] = meta['sha256']
            result['g3_recovery_phase'] = 'G3_NORMALIZATION_BEFORE_PARALLEL'
            result.update(recovery_verified)
            return result
        if node == 'G7':
            # The frozen node publishes FULL_COMPLETE before H*. Preserve its
            # position in STATE, but reserve the completion claim for H6 closure.
            return {'schema': 'TICKSTORE_FULL_ENGINE_COMPLETE_V001',
                    'status': 'ENGINE_RECONCILED_POSTFULL_PENDING',
                    'run_id': admission.instance['run_id'], 'full_complete': False}
        if node == 'H3':
            with Reads() as proof:
                results, _ = closed_results(proof.read(o.st.jp), ('G3',), o.st.runs, proof.read)
                meta = results['G3']['reconciliation']
                result = strict_json(proof.read(meta['path'], meta['sha256']))
                require(result.get('run_id') == admission.instance['run_id']
                        and result.get('instance_sha256') == admission.descriptor['instance_sha256']
                        and result.get('code_manifest_sha256') == admission.descriptor['code_manifest_sha256'],
                        'FULL_RECONCILIATION_INSTANCE')
                checked = verify_postfull(result, o.st.d.get('postfull_h2', {}))
                proof.revalidate()
                return dict(checked, reconciliation=meta)
        return original(node)

    o.runnode = dispatch


def publish_completion(o, ns, admission, nodes):
    with Reads() as proof:
        state_raw = proof.read(o.st.sp); state = strict_json(state_raw)
        require(state == o.st.d and state.get('status') == 'PASS' and state.get('next_node') == 'I1'
                and all(n in state.get('completed', []) for n in nodes), 'FULL_FINAL_STATE')
        journal = proof.read(o.st.jp)
        results, evidence = closed_results(journal, nodes, o.st.runs, proof.read)
        meta = results['G3']['reconciliation']; evidence.append(meta)
        reconciliation = strict_json(proof.read(meta['path'], meta['sha256']))
        verify_postfull(reconciliation, results['H2'])
        require(results['H3'].get('FINAL_VS_POSTFULL') == 'PASS'
                and results['H3'].get('reconciliation') == meta, 'FULL_H3_NOT_BOUND')
        pack = results['H6']; proof.read(pack['path'], pack['sha256']); evidence.append(pack)
        for name, raw in [('FULL_STATE_AFTER.json', state_raw), ('FULL_JOURNAL_AFTER.jsonl', journal)]:
            path = o.rd/name; ns['immutable_receipt'](path, raw)
            evidence.append({'path': str(path), 'sha256': sha(raw)})
        for item in evidence: admission.read(item['path'], item['sha256'])
        proof.revalidate(); admission.revalidate()
        receipt = dict(schema='TICKSTORE_FULL_COMPLETION_V001', status='PASS',
                       environment='WINDOWS_PRODUCTION', run_id=admission.instance['run_id'],
                       instance_sha256=admission.descriptor['instance_sha256'],
                       code_manifest_sha256=admission.descriptor['code_manifest_sha256'],
                       full_admission_sha256=admission.receipt_hashes['FULL_ADMISSION'],
                       state_after_sha256=sha(state_raw), evidence=evidence,
                       created_unix_ns=time.time_ns(), next_node='I1',
                       csv_deletion_authorized=False, format_promotion_authorized=False)
        path = o.rd/'FULL_COMPLETION.json'; raw = canonical(receipt)
        ns['immutable_receipt'](path, raw); admission.read(path, sha(raw)); admission.revalidate()
        print('FULL_COMPLETION_FILE=' + str(path) + '\nFULL_COMPLETION_SHA256=' + sha(raw), flush=True)
        return path, sha(raw)


def refresh_admission(o, ns, admission, facts, nodes):
    """New immutable descriptor, same instance; no rewind or scratch replacement."""
    with Reads() as proof:
        state_raw = proof.read(o.st.sp); state = strict_json(state_raw)
        require(state == o.st.d, 'READMISSION_STATE_DRIFT')
        journal = proof.read(o.st.jp)
        # All completed FULL nodes must have current, hash-bound results. The
        # pending node must have no STARTED without FINISHED (checked by caller).
        completed = tuple(n for n in nodes if n in state['completed'])
        _, evidence = closed_results(journal, completed, o.st.runs, proof.read)
        old = admission.descriptor['receipts']['FULL_ADMISSION']
        evidence.append(old)
        evidence += admission.receipts['FULL_ADMISSION']['evidence']
        # publish() keeps its no-replacement invariant. A view exposes the exact
        # immutable prefix, while the original receipt remains explicit evidence.
        class Prefix:
            descriptor = dict(admission.descriptor, receipts={k: v for k, v in admission.descriptor['receipts'].items()
                                                             if k != 'FULL_ADMISSION'})
            receipt_sha = admission.receipt_hashes['FULL_PREP']
            read = admission.read
            revalidate = admission.revalidate
        proof.revalidate()
        # Readmission keeps the original FULL_ADMISSION proof witnesses: the current
        # journal contains G3..H6, not the earlier F1..G2 admission nodes.
        old_receipt = admission.receipts['FULL_ADMISSION']
        from FULL_STAGE_EVIDENCE import STAGE_CHECK_WITNESSES
        checks = old_receipt.get('checks')
        check_proofs = old_receipt.get('check_proofs')
        require(isinstance(checks, dict) and set(checks) == set(REQUIRED_CHECKS['FULL_ADMISSION'])
                and all(v is True for v in checks.values()), 'READMISSION_ORIGINAL_CHECKS')
        require(isinstance(check_proofs, dict) and set(check_proofs) == set(checks),
                'READMISSION_ORIGINAL_PROOFS')
        old_set = {(i['path'], i['sha256']) for i in old_receipt['evidence']}
        for check, item in check_proofs.items():
            require(isinstance(item, dict) and item.get('node') == STAGE_CHECK_WITNESSES['FULL_ADMISSION'][check]
                    and (item.get('path'), item.get('sha256')) in old_set,
                    'READMISSION_CHECK_WITNESS:' + check)
            admission.read(item['path'], item['sha256'])
        return publish('FULL_ADMISSION', Prefix(), o.rd, ns['immutable_receipt'],
                       {'STATE_AFTER.json': state_raw, 'JOURNAL_AFTER.jsonl': journal}, evidence,
                       checks=checks, check_proofs=check_proofs,
                       extra=dict(facts, state_after_sha256=sha(state_raw),
                                  readmission_of_sha256=old['sha256'],
                                  resumed_node=state['next_node'], run_id=admission.instance['run_id']))
