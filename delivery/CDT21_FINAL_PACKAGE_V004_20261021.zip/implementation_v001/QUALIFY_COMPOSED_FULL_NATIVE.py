"""Scoped native READONLY preflight of the fused candidate; cannot approve B06 or start FULL."""
from __future__ import annotations
import argparse,hashlib,io,json,os,pathlib,subprocess,sys,datetime,time,zipfile,signal
R=pathlib.Path(__file__).resolve().parent
S=lambda b:hashlib.sha256(b).hexdigest().upper()
CANON=lambda o:(json.dumps(o,sort_keys=True,separators=(',',':'))+'\n').encode('utf-8')
PROJECT='Base de Dados CSV / Tickstore';THREAD='Compressão de Ticks 17'
SCHEMA='CDT17_COMPOSED_FULL_NATIVE_RETURN_V001'

def write_new(p,b):
    p=pathlib.Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as out:out.write(b);out.flush();os.fsync(out.fileno())
    if p.read_bytes()!=b:raise RuntimeError('RETURN_READBACK_MISMATCH')

def runner(a):
    assert os.name=='nt','TARGET_WINDOWS_REQUIRED'
    root=pathlib.Path(a.runroot).resolve(strict=True)
    assert root!=R and (R.parent==root or root in R.parents),'RUNROOT_BOUNDARY'
    assert (root/'EXTRACTED').resolve(strict=True)==R.parent,'EXTRACTED_ROOT'
    assert (R/'VERIFY_FULL_COMPOSITION_SOURCE_ONLY.py').is_file(),'CHECKER_MISSING'
    expected=a.package_sha.upper()
    assert len(expected)==64 and all(x in '0123456789ABCDEF' for x in expected),'PACKAGE_HASH_GRAMMAR'
    assert a.source_zip.exists() and S(a.source_zip.read_bytes())==expected,'ORIGINAL_SOURCE_ZIP_SHA'
    logs=[]
    def log(s):
        logs.append(s); print(s,flush=True)
    log('RESULT_CONTEXT=ChatGPT | PROJECT='+PROJECT+' | THREAD='+THREAD)
    log('MISSION=CDT17_OPUS_R47_C6_FULL_FUSION_NATIVE_QUAL_READONLY')
    log('SOURCE_ZIP_SHA='+expected+' FULL_STARTED=NO B06=NOT_STARTED')
    commands=[['-I','-X','utf8','-B',str(R/'VERIFY_FULL_COMPOSITION_SOURCE_ONLY.py')],
              ['-I','-X','utf8','-B','-m','unittest','discover','-s',str(R/'tests'),'-p','test_cdt17_full_composition_scope.py']]
    results=[]
    for idx,args in enumerate(commands,1):
        label='SEALED_MEMBERS' if idx==1 else 'NEW_DELTA_NEGATIVE_TESTS_15'
        log('FULL_FUSION_STEP='+str(idx)+'/2 NAME='+label+' ETA=UNKNOWN_SHORT_UNIT')
        process=subprocess.Popen([sys.executable]+args,cwd=str(R),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        started=time.monotonic()
        while process.poll() is None:
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                elapsed=time.monotonic()-started
                log('FULL_FUSION_CHILD_RUNNING NAME='+label+' PID='+str(process.pid)+' ELAPSED_S='+str(int(elapsed))+' ETA=UNKNOWN')
                if elapsed>180:
                    raise RuntimeError('CHILD_WATCHDOG_TIMEOUT_OWNED_PID_'+str(process.pid)+'_NO_AUTO_KILL')
        stdout,stderr=process.communicate(timeout=10)
        results.append({'name':label,'exit':process.returncode,'stdout_sha256':S(stdout),'stderr_sha256':S(stderr),'elapsed_seconds':round(time.monotonic()-started,3)})
        log('FULL_FUSION_CHILD='+label+' EXIT='+str(process.returncode))
        if process.returncode!=0:raise RuntimeError('NATIVE_CHILD_FAILED_'+label+'_EXIT_'+str(process.returncode))
    # No native stages beyond source composition. This receipt does NOT claim final completeness.
    receipt={'schema':SCHEMA,'result':'PASS_SCOPED_READONLY','platform':sys.platform,'python':sys.version,'python_exe_sha256':S(pathlib.Path(sys.executable).read_bytes()),
             'source_zip_sha256':expected,'code_manifest_sha256':S((R/'RUNTIME_CODE_MANIFEST.json').read_bytes()),
             'g5_scope_only':'PREVIOUS_PARENT_G5_OWNER_NATIVE_PASS_NOT_REISSUED_FOR_NEW_PACKAGE',
             'children':results,'production_modified':False,'full_started':False,'b06':'NOT_STARTED','candidate_completeness':'NOT_PROVEN',
             'physical_powerloss':'NOT_TESTED_PHYSICAL_POWERLOSS','tested_code_equals_packaged_code':'PASS_SOURCE_COMPOSITION_SCOPED_ONLY'}
    data={'NATIVE_COMPOSITION_RECEIPT.json':CANON(receipt),'RUN_LOG.txt':('\n'.join(logs)+'\n').encode('utf8')}
    manifest={'schema':'CDT17_COMPOSED_FULL_NATIVE_RETURN_MANIFEST_V001','files':[{'path':name,'bytes':len(raw),'sha256':S(raw)} for name,raw in sorted(data.items())]}
    data['RETURN_MANIFEST.json']=CANON(manifest)
    out=root/('FULL_COMPOSITION_NATIVE_RETURN_'+root.name+'.zip')
    with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,b in sorted(data.items()):z.writestr(n,b)
    with zipfile.ZipFile(out) as z:
        if z.testzip() is not None:raise RuntimeError('RETURN_CRC_FAIL')
        for n,b in data.items():
            if z.read(n)!=b:raise RuntimeError('RETURN_SEAL_READBACK_FAIL')
    log('FULL_FUSION_NATIVE=PASS_SCOPED_READONLY FULL_CANDIDATE_COMPLETENESS=NOT_PROVEN B06=NOT_STARTED FULL_STARTED=NO')
    log('RETURN_ZIP='+str(out))
    log('RETURN_SHA256='+S(out.read_bytes()))
    log('Devolva este resultado ao ChatGPT, no projeto "'+PROJECT+'", conversa "'+THREAD+'". Anexe as evidencias existentes e cole esta resposta.')
    log('RESULT_RETURN_TO=ChatGPT | PROJECT='+PROJECT+' | THREAD='+THREAD)
    return 0

if __name__=='__main__':
    ap=argparse.ArgumentParser(allow_abbrev=False);ap.add_argument('--runroot',required=True);ap.add_argument('--package-sha',required=True);ap.add_argument('--source-zip',type=pathlib.Path,required=True);args=ap.parse_args()
    try:
        result=runner(args)
    except Exception as e:
        print('FULL_FUSION_NATIVE=BLOCKED_CAUSE='+type(e).__name__+':'+str(e),flush=True)
        print('RESULT_RETURN_TO=ChatGPT | PROJECT='+PROJECT+' | THREAD='+THREAD,flush=True)
        sys.exit(2)
    else:
        sys.exit(result)
