# CDT17 B1 formal integration — SOURCE_ONLY / NÃO HOMOLOGADO

Missão imutável: homologar e colocar em produção o motor FULL Opus R47/C6 preservando seu motor.

Este delta é aditivo no plano de controle. Adiciona `control/B1_FORMAL_ADMISSION.py` e uma função roteadora em `control/FULL_QUALIFICATION_CONTRACT.py` sem modificar a lógica preexistente de `validate`, as seis provas G5, o FULL, recovery, adapter, g5proof ou menu.

B1 formal só pode emitir recibo com evidência completa 126 IDs do parent C5-R44, política R45 física MASTER/HEAD FROZEN, ZIP FINAL fechado com manifestos e nova prova *nativa Windows* da identidade exata dos bytes FINAIS desta integração. Nunca transforma o retorno C6 histórico 14/14 em qualificação dos novos bytes.

Os resultados históricos não são recontados como testes do candidato novo. O novo controle não substitui G4/G5/B06/B07. Requer decisão futura de requalificação somente do delta material, em campanha única de Windows, agrupada com demais pendências do candidato FULL. Não usar este ZIP como executável produtivo.

RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão de Ticks 17
