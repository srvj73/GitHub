"""CDT21 F-01R1 - rebuild the V004 final package from the frozen V003 parent and the delta files.

Usage: python -I -B RECONSTRUIR_V004_A_PARTIR_DO_V003.py <CDT21_FINAL_PACKAGE_V003_20261020.zip> <delta dir 01_DELTA> <new output zip>
Checks: V003 SHA; every V004 member (V003 members minus the 3 regenerated manifests, plus the delta files) equals
its row of the V004 PACKAGE_MANIFEST (bytes and SHA-256); member set equals the manifest exactly; RUNTIME and SOURCE
manifests and PACKAGE_MANIFEST equal the expected digests.  Then writes the ZIP with the build parameters
(fixed stamp, DEFLATE level 9, sorted names) and reports whether its SHA-256 equals the delivered V004 ZIP; a
different zlib build may compress differently, in which case member-level identity above is the proof.
"""
import hashlib
import io
import json
import sys
import zipfile
from pathlib import Path

V003_SHA = '69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50'
V004_SHA = 'AD33486954F1248AF28A78677377E83AB979AB86EDD5F71F5B7D108CBA8F99DD'
V004_PACKAGE_MANIFEST = 'F6225EA6720FCA558F8BBAD70B3ED46687103374873439E0FADDB4FEA9D3A813'
V004_CODE_MANIFEST = 'D2C626FD2819B86D472433CB2B26C6688B1688E5E5474402162B67C5048666FF'
REGENERATED = ('PACKAGE_MANIFEST.json', 'implementation_v001/SOURCE_MANIFEST.json', 'implementation_v001/RUNTIME_CODE_MANIFEST.json')
STAMP = (2026, 10, 21, 18, 0, 0)


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def main(parent_zip, delta_dir, out):
    parent_raw = Path(parent_zip).read_bytes()
    assert sha(parent_raw) == V003_SHA, 'V003_SHA_MISMATCH'
    with zipfile.ZipFile(io.BytesIO(parent_raw)) as z:
        assert z.testzip() is None, 'V003_CRC'
        members = {n: z.read(n) for n in z.namelist() if not n.endswith('/') and n not in REGENERATED}
    delta = Path(delta_dir)
    for p in sorted(delta.rglob('*')):
        if p.is_file():
            members[p.relative_to(delta).as_posix()] = p.read_bytes()
    manifest_raw = members['PACKAGE_MANIFEST.json']
    assert sha(manifest_raw) == V004_PACKAGE_MANIFEST, 'PACKAGE_MANIFEST_SHA'
    assert sha(members['implementation_v001/RUNTIME_CODE_MANIFEST.json']) == V004_CODE_MANIFEST, 'CODE_MANIFEST_SHA'
    rows = {r['path']: r for r in json.loads(manifest_raw)['files']}
    assert set(rows) == set(members) - {'PACKAGE_MANIFEST.json'}, 'MEMBER_SET'
    for n, r in rows.items():
        assert len(members[n]) == r['bytes'] and sha(members[n]) == r['sha256'], 'MEMBER:' + n
    out = Path(out)
    assert not out.exists(), 'OUTPUT_EXISTS'
    with zipfile.ZipFile(out, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name in ['PACKAGE_MANIFEST.json'] + sorted(n for n in members if n != 'PACKAGE_MANIFEST.json'):
            info = zipfile.ZipInfo(name, STAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o644 << 16
            z.writestr(info, members[name])
    got = sha(out.read_bytes())
    report = {'members_verified': len(rows) + 1, 'package_manifest_sha256': V004_PACKAGE_MANIFEST,
              'runtime_code_manifest_sha256': V004_CODE_MANIFEST, 'rebuilt_zip_sha256': got,
              'rebuilt_zip_equals_delivered_v004': got == V004_SHA,
              'verdict': 'PASS_MEMBER_IDENTITY' + ('_AND_ZIP_IDENTITY' if got == V004_SHA else '_ZIP_COMPRESSION_DIFFERS')}
    print(json.dumps(report, indent=1, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main(*sys.argv[1:4]))
