# CDT21 — correção F-01R1 (achado material da B06 do V003): pacote delta para nova admissão

**Papel:** implementador. Este pacote **não** é parecer B06, **não** admite o candidato e **não** substitui a custódia da origem.

## Identidades

| Item | Identidade |
|---|---|
| Parent congelado | V003 `69DA2D5964BABA95D8B90D5BC17E12683B5F5E91D1C7D7ABD01938A7AE014A50`, código `D59BC4EE…3953`. Preservado. |
| Sucessor | V004 `CDT21_FINAL_PACKAGE_V004_20261021.zip`, `AD33486954F1248AF28A78677377E83AB979AB86EDD5F71F5B7D108CBA8F99DD`, 17.369.789 bytes, 320 membros |
| Manifestos do V004 | código `D2C626FD2819B86D472433CB2B26C6688B1688E5E5474402162B67C5048666FF`; pacote `F6225EA6…A813`; fonte `459535EA…76DD` |
| Achado recebido | ZIP `676FA20F…4628`, verificado; reproducer `03311136…4922` |

## 1. Causa (confirmada)

O `State.log` congelado abre `STATE_JOURNAL.jsonl` em `"ab"` pelo nome a cada chamada. Entre as chamadas, não mantém handle, lock nem mutex.

A cerca do V003 é um diretório em `STATE.json.partial`. Ela nega apenas a próxima construção de `State`. O mutex do instalador só é tomado pelos consumidores admitidos.

Logo, um processo legado que construiu `State` antes da cerca:
- continua acrescentando ao journal;
- no `finish()`, grava `FINISHED` **antes** de falhar no STATE.

**Reprodução aqui:**
- o reproducer original da origem, sobre o despacho V003, dá `F01_LEGACY_ALREADY_INITIALIZED_NOT_STOPPED_BY_FENCE`;
- `ORIGIN_SCENARIO` sobre o V003 dá o mesmo resultado nos cenários A (reproducer verbatim) e B (nó em andamento).

## 2. Por que a detecção não basta (impedimento técnico declarado)

Com os bytes legados congelados, um processo legado ocioso entre duas escritas não detém nenhum objeto observável ligado ao `control_root`. Nenhum mecanismo de sistema de arquivos o detecta, e uma amostragem de PIDs não fecha a janela.

Por isso a correção não depende de detectá-lo. Ela **o corta fisicamente** e prova a drenagem pelos próprios registros do journal.

## 3. Correção no V004 (o código congelado não foi tocado)

1. **Corte do journal pelo nome.** ACE explícita de negação para Todos (`FILE_WRITE_DATA|FILE_APPEND_DATA`), verificada pelo kernel a cada abertura. O `open("ab")` congelado falha para todo processo, iniciado antes ou depois.
2. **Prova do instante do corte, sem TOCTOU.** Depois da ACE, o journal é aberto sem compartilhamento de escrita, o que prova que não sobrevive nenhum handle de escrita anterior. Os bytes desse instante ficam registrados em `LEGACY_JOURNAL_CUT.json`. Se houver handle aberto, não há registro e a admissão é recusada. A prova vem **depois** do fechamento; não existe janela entre verificação e instalação.
3. **Drenagem sem censo.** O `execute()` congelado registra `STARTED(run_id=<carimbo>_<pid>)` antes de qualquer efeito de nó. Assim, o journal do corte nomeia exatamente as execuções legadas que podem estar dentro de um nó.
   - `FENCE_PRESENT` exige que cada uma dessas identidades tenha deixado de existir: PID ausente, processo encerrado, ou PID reutilizado por processo criado depois do `STARTED` + 600 s.
   - Senão, o resultado é `CUT_PRESENT_LEGACY_RUN_NOT_DRAINED` e a admissão é recusada.
   - A propriedade é monotônica.
4. **Escritor admitido.** D4 e FULL, ambos elevados, acrescentam a mesma linha congelada com backup semantics. `SeRestorePrivilege` fica habilitado só no token da thread e só durante a abertura.
5. **Exigência contínua.** A admissão, cada commit de STATE e cada append admitido exigem o corte completo e drenado. A ausência ou adulteração da ACE, do registro, da identidade ou do prefixo do journal é recusada.

## 4. Controles (Linux, sobre o ZIP final extraído; testado = empacotado)

**Suíte nova** `test_cdt21_f01r1_preexisting_legacy_cut.py`: 16 testes; 1 pulado, que é Windows-only. Cobertura:
- processo legado já ativo, com e sem nó em andamento;
- handle de escrita aberto no corte;
- atividade entre diagnóstico e corte (TOCTOU injetado);
- novas entradas bloqueadas;
- duas instalações concorrentes;
- instalação contra entrada admitida viva;
- ordem de admissão;
- escritor admitido byte a byte igual ao `State.log` congelado;
- seis adulterações do corte;
- integridade da cadeia do journal e do STATE;
- regra de drenagem.

**Suíte F-01 do V003, atualizada:** 30 testes, 3 pulados (Windows-only).

**Mutações:** `CDT21_F01R1_MUTATION_CONTROLS`, baseline PASS e 8/8 mortas. A M2 recria o comportamento do V003 e é detectada.

**Cenário da origem sobre o V004:**

| Cenário | Decisão | Append do legado antigo | Journal e STATE | Nova instância |
|---|---|---|---|---|
| A | `FENCE_PRESENT` | `PermissionError` | inalterados | bloqueada |
| B | `CUT_PRESENT_LEGACY_RUN_NOT_DRAINED` (exit 2); `FENCE_PRESENT` após o fim do processo | `PermissionError` | inalterados | bloqueada |

**Varredura completa:** idêntica à do V003, linha a linha; a única linha nova é a suíte F-01R1.

**Reconstrução:** V003 + `01_DELTA` reproduz o V004 membro a membro e no SHA do ZIP. Os dois negativos (arquivo adulterado e arquivo faltando) são recusados.

**Modelo POSIX:** os filhos legados rodam como uid 0 sem capacidades (`SECBIT_NOROOT`). A ACE é modelada por modo 0444 e a sondagem, por lease de leitura. A prova autoritativa é a nativa Windows (seção 5).

## 5. Qualificação Windows dos componentes afetados (a executar)

Runner: `03_QUALIFICACAO_WINDOWS/RUN_CDT21_F01R1_G0_V004_20261021.ps1`. PS 5.1, autoeleva, executado a partir de `C:\Users\silvi`.

**Executa:**
- as 11 unidades do G0 do V003 mais a suíte nova, com Job por unidade;
- as 8 mutações, nativamente;
- o cenário da origem sobre o V004 (e sobre o V003 como contraste, se presente em Downloads).

**Log:** `C:\Users\silvi\Downloads\CDT21_F01R1_RUNS\G0_<carimbo>\`.

**Não executa:** G5 de 38 unidades, B06, B07, D4/D5, canário, FULL ou produção.

## 6. Não alegado

- PASS nativo Windows do V004 antes do retorno do runner.
- G5 do V004. A evidência G5 (38/38, cinco partes) prova somente os bytes do V003. O contrato G5 congelado vincula o manifesto de código inteiro, então um recibo de cinco partes do V004 exige nova campanha nativa. Essa decisão é da origem.
- Corte instalado em produção (requer autorização; ver `procedures/PROCEDIMENTO_CDT21_LEGACY_ENTRY_FENCE.md`).
- Proteção contra quem remove a ACE ou renomeia a cerca. Isso é detectado na admissão.
- Queda física de energia.

RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 21
