"""Linux qualification of the G5 V004 supervisor (Windows-only parts are qualified natively by phase Q).

Usage: v004_validate.py <SUP_V004.py> <R2.py> <REVIEW_V004.json> <REVIEW_V003.json> <V004_ZIP> <V003_ROOT_FILES> <WORK> <OUT_JSON>
V003_ROOT_FILES: the real collected V003 run root (its COMMITs are bound to the V003 package and code).
"""
import ast, importlib.util, io, json, os, shutil, subprocess, sys, time
from contextlib import redirect_stdout
from pathlib import Path

sup, r2, review, review3, v4zip, v3root, work, out = map(Path, sys.argv[1:9])
checks = {}


def rec(name, ok, detail=''):
    checks[name] = {'status': 'PASS' if ok else 'FAIL', 'detail': str(detail)[:400]}
    print(('PASS ' if ok else 'FAIL ') + name + ' ' + str(detail)[:160], flush=True)


def raises(fn, needle):
    try:
        fn()
    except BaseException as exc:
        m = type(exc).__name__ + ':' + str(exc)
        return needle in m, m
    return False, 'NO_EXCEPTION'


shutil.rmtree(work, ignore_errors=True); work.mkdir(parents=True)
spec = importlib.util.spec_from_file_location('sup_v004', sup)
S = importlib.util.module_from_spec(spec); spec.loader.exec_module(S)
S.__file__ = str(sup)

# 1. Composition: proven R2 functions byte-identical; resume mode absent.
def funcs(p):
    src = Path(p).read_text(encoding='utf-8'); t = ast.parse(src)
    return {n.name: ast.get_source_segment(src, n) for n in t.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
a, b = funcs(sup), funcs(r2)
identical = sorted(k for k in a if k in b and a[k] == b[k])
must_keep = ['SupervisorJob', 'check_fixture_contract', 'extract_package', 'fixture_extract_dir', 'native_b2d', 'path_isolation',
             'plan_keys', 'production_fingerprint', 'reparse_free', 'tree_digest', 'validate_review', 'verify_extract', 'volume_filesystem']
removed = sorted(set(b) - set(a))
rec('r2_functions_byte_identical', all(k in identical for k in must_keep) and len(identical) == 23, identical)
rec('resume_mode_removed', removed == ['checkpoint_consistency', 'lock_probe', 'preserve_prior_terminal', 'prior_processes_dead',
                                       'resume_precheck'] and 'resume_precheck' not in Path(sup).read_text(encoding='utf-8'), removed)
rec('main_has_no_resume_argument', "'--resume-root'" not in a['main'] and "add_argument('--resume" not in a['main']
    and 'require(not reused' in a['main'] and "root.mkdir()" in a['main'], 'argparse/guards')

# 2. Constants bound to V004; V003 identity only as refusal.
rec('constants_bound_to_v004', S.PACKAGE_SHA == 'AD33486954F1248AF28A78677377E83AB979AB86EDD5F71F5B7D108CBA8F99DD'
    and S.CODE_SHA == 'D2C626FD2819B86D472433CB2B26C6688B1688E5E5474402162B67C5048666FF'
    and S.MANIFEST_SHA == 'F6225EA6720FCA558F8BBAD70B3ED46687103374873439E0FADDB4FEA9D3A813'
    and S.PACKAGE_SHA != S.V003_PACKAGE_SHA and S.sha_file(v4zip) == S.PACKAGE_SHA, S.PACKAGE_SHA[:16])

# 3. Fixed layout: extraction byte-exact, b2d contract satisfied; R1 layout refused.
local = work / 'Local'
ext = S.fixture_extract_dir(local, '20261021190000_abcdef'); ext.parent.parent.mkdir(parents=True); ext.parent.mkdir()
n = S.extract_package(v4zip, ext); S.verify_extract(v4zip, ext); S.check_fixture_contract(ext)
rec('fixed_layout_contract_and_byte_exact', n == 320 and ext.parent.name.startswith('CURRENT_G5_DELTA_')
    and ext.parent.parent.name == 'CDT21_G5_V004', str(ext))
old = work / 'R1' / 'R08_Q1_00000000000000_000000000000' / 'PACKAGED'; old.parent.mkdir(parents=True); S.extract_package(v4zip, old)
rec('r1_layout_refused_by_contract_check', *raises(lambda: S.check_fixture_contract(old), 'FIXTURE_LAYOUT'))
rec('frozen_sources_pinned', S.sha_file(ext / 'PACKAGE_MANIFEST.json') == S.MANIFEST_SHA and S.sha_file(ext / S.CAMPAIGN_REL) == S.CAMPAIGN_SHA
    and S.sha_file(ext / S.COMPLETENESS_REL) == S.COMPLETENESS_SHA)

# 4. Plan and frozen verify_package from the fixed extraction.
plan = S.plan_keys(ext)
import PRE_G06_CAMPAIGN as C  # noqa: E402
import FULL_CRASH_RECOVERY as R  # noqa: E402
code, members = C.verify_package(v4zip)
rec('plan_38_from_frozen_constants', len(plan) == 38 and plan[0] == 'G5_PS51_INSTALL_MENU' and plan[-1] == 'G3_G6_NATIVE', len(plan))
rec('frozen_verify_package_v004', code == S.CODE_SHA and Path(C.__file__).resolve() == (ext / S.CAMPAIGN_REL).resolve(), code)

# 5. Source review: V004 accepted, V003 refused (the frozen close() requires the same binding).
S.validate_review(review.read_bytes())
rec('review_v004_accepted', True, S.sha_bytes(review.read_bytes()))
rec('review_v003_refused', *raises(lambda: S.validate_review(review3.read_bytes()), 'SOURCE_REVIEW_BINDING'))
w = S.make_witness('R08_Q1_20261021190000_0123456789ab', S.MANIFEST_SHA); o = S.make_owner('R08_Q1_20261021190000_0123456789ab')
rec('witness_owner_bound_to_v004', w['package_sha256'] == S.PACKAGE_SHA and w['code_manifest_sha256'] == S.CODE_SHA
    and w['issued_by'] == 'CDT21_G5_V004_SUPERVISOR' and o['package_sha256'] == S.PACKAGE_SHA and o['production_authorized'] is False)

# 6. Pre-existing roots (the real V003 root among them) are read only and must not change.
dl = work / 'D' / S.D_LABS_NAME
S.D_LABS = str(dl)
v3run = 'R08_Q1_20261020210605_856fea523791'
shutil.copytree(v3root, local / 'CDT20_R08' / v3run)
(dl / v3run / 'WRITER_EFFECTFUL').mkdir(parents=True); shutil.copyfile(v3root / 'OWNER.json', dl / v3run / 'OWNER.json')
f0 = S.foreign_roots(local); f1 = S.foreign_roots(local)
rec('foreign_roots_recorded_with_owner', f0 == f1 and f0['run/' + v3run]['owner'] == 'V003' and f0['d_lab/' + v3run]['owner'] == 'V003'
    and len(f0) == 2, {k: v.get('owner') for k, v in f0.items()})
new = 'R08_Q1_20261021190000_0123456789ab'
(local / 'CDT20_R08' / new).mkdir(); (dl / new).mkdir()
rec('foreign_unchanged_allows_only_own_new_run', S.foreign_unchanged(f0, S.foreign_roots(local), new)['added'] == ['d_lab/' + new, 'run/' + new])
probe = local / 'CDT20_R08' / v3run / 'COMMITS' / 'G5_PS51_INSTALL_MENU.json'; st = probe.stat()
os.utime(probe, ns=(st.st_atime_ns, st.st_mtime_ns + 1000))
rec('neg_v003_root_touched_is_refused', *raises(lambda: S.foreign_unchanged(f0, S.foreign_roots(local), new), 'FOREIGN_ROOT_CHANGED:run/' + v3run))
os.utime(probe, ns=(st.st_atime_ns, st.st_mtime_ns))
(local / 'CDT20_R08' / 'R08_Q1_20261021190001_ffffffffffff').mkdir()
rec('neg_unexpected_sibling_is_refused', *raises(lambda: S.foreign_unchanged(f0, S.foreign_roots(local), new), 'FOREIGN_ROOT_ADDED'))
(local / 'CDT20_R08' / 'R08_Q1_20261021190001_ffffffffffff').rmdir()
shutil.rmtree(local / 'CDT20_R08' / new); shutil.rmtree(dl / new)
rec('foreign_roots_restored', S.foreign_roots(local) == f0)
# A link left inside a foreign root (loop to its parent, or to an outside tree) is recorded, never followed.
v3 = local / 'CDT20_R08' / v3run
outside = work / 'OUTSIDE'; outside.mkdir(); (outside / 'a.txt').write_text('1')
os.symlink(v3, v3 / 'TEMP_LOOP', target_is_directory=True); os.symlink(outside, v3 / 'TEMP_OUT', target_is_directory=True)
g0 = S.foreign_roots(local); (outside / 'b.txt').write_text('2'); g1 = S.foreign_roots(local)
rec('foreign_digest_terminates_on_link_loop_and_never_follows', g0 == g1 and g0['run/' + v3run]['links_not_followed'] == 2, g0['run/' + v3run])
(v3 / 'TEMP_LOOP').unlink(); (v3 / 'TEMP_OUT').unlink()
rec('foreign_roots_restored_after_links', S.foreign_roots(local) == f0)

# 7. Frozen run_unit refuses a V003-bound COMMIT under the V004 identity before executing anything.
mis = local / 'MISUSE' / 'R08_Q1_20261021190002_aaaaaaaaaaaa'; (mis / 'COMMITS').mkdir(parents=True)
shutil.copyfile(v3root / 'COMMITS' / 'G5_PS51_INSTALL_MENU.json', mis / 'COMMITS' / 'G5_PS51_INSTALL_MENU.json')
for sub in ('UNITS', 'LOGS', 'EVIDENCE'):
    if (v3root / sub).exists():
        shutil.copytree(v3root / sub, mis / sub)
buf = io.StringIO()
with redirect_stdout(buf):
    ok, msg = raises(lambda: C.run_unit({'root': str(mis), 'key': 'G5_PS51_INSTALL_MENU', 'kind': 'proof', 'name': 'PS51_INSTALL_MENU',
                                         'package_sha256': S.PACKAGE_SHA, 'code_sha256': S.CODE_SHA}), 'COMMITTED_INPUT_DRIFT')
rec('frozen_run_unit_refuses_v003_commit_under_v004', ok and 'REUSE_COMMITTED' not in buf.getvalue(), msg)

# 8. The 38 COMMITs of a new run must be exactly the plan and bound to V004.
nr = work / 'NEWRUN' / new; (nr / 'COMMITS').mkdir(parents=True); (nr / 'LOGS').mkdir()
def commit(key, pkg=S.PACKAGE_SHA, code=S.CODE_SHA, desc=()):
    log = nr / 'LOGS' / (key + '.log'); log.write_text('ok ' + key)
    obj = {'schema': 'CDT19_NATIVE_UNIT_COMMIT_V001', 'package_sha256': pkg, 'code_sha256': code,
           'result': {'status': 'PASS', 'exit_code': 0}, 'own_descendants_final': list(desc),
           'artifacts': [{'member': 'LOGS/' + key + '.log', 'sha256': S.sha_file(log), 'bytes': log.stat().st_size}]}
    (nr / 'COMMITS' / (key + '.json')).write_bytes(S.encoded(obj))
for k in plan:
    commit(k)
rec('commits_bound_38_v004', len(S.commits_bound(nr, plan)) == 38)
commit(plan[5], pkg=S.V003_PACKAGE_SHA, code=S.V003_CODE_SHA)
rec('neg_commit_bound_to_v003', *raises(lambda: S.commits_bound(nr, plan), 'COMMIT_BOUND_TO_V003:' + plan[5]))
commit(plan[5])
(nr / 'COMMITS' / (plan[7] + '.json')).unlink()
rec('neg_commit_missing', *raises(lambda: S.commits_bound(nr, plan), 'COMMIT_SET_NE_PLAN:37'))
commit(plan[7]); (nr / 'LOGS' / (plan[9] + '.log')).write_text('tampered')
rec('neg_commit_artifact_drift', *raises(lambda: S.commits_bound(nr, plan), 'COMMIT_ARTIFACT_DRIFT:' + plan[9]))
commit(plan[9]); commit(plan[11], desc=[{'pid': 1}])
rec('neg_commit_with_orphans', *raises(lambda: S.commits_bound(nr, plan), 'COMMIT_NOT_BOUND_TO_V004:' + plan[11]))
commit(plan[11])

# 9. Terminal checkpoints of the new run.
(nr / 'LIVE_STATUS.json').write_bytes(S.encoded({'commit_receipt_keys': sorted(plan), 'status': 'PASS_NATIVE_INTEGRATED_PRE_B06'}))
(nr / 'R08_RETURN.zip').write_bytes(b'PK-test'); (nr / 'R08_RETURN.sha256').write_text(S.sha_file(nr / 'R08_RETURN.zip') + '  R08_RETURN.zip\n')
(nr / 'RETURN_LOCK_SCOPE.json').write_bytes(S.encoded({'run_id': new}))
rec('final_checkpoints_consistent', S.final_checkpoints(nr, plan)['live_status_keys_equal_plan'] is True)
(nr / 'LIVE_STATUS.json').write_bytes(S.encoded({'commit_receipt_keys': sorted(plan)[:-1], 'status': 'PASS_NATIVE_INTEGRATED_PRE_B06'}))
rec('neg_live_status_keys', *raises(lambda: S.final_checkpoints(nr, plan), 'LIVE_STATUS_COMMIT_KEYS'))
(nr / 'LIVE_STATUS.json').write_bytes(S.encoded({'commit_receipt_keys': sorted(plan), 'status': 'PASS_NATIVE_INTEGRATED_PRE_B06'}))
(nr / 'R08_RETURN.sha256').write_text('0' * 64 + '  R08_RETURN.zip\n')
rec('neg_r08_sha_file', *raises(lambda: S.final_checkpoints(nr, plan), 'R08_RETURN_SHA_FILE'))

# 10. Effectful phase admitted only after a fresh PASS qualification of the same supervisor and log dir.
logd = work / 'LOG'; logd.mkdir()
def qual(**kw):
    q = {'schema': S.QUAL_SCHEMA, 'status': 'PASS_WINDOWS_QUALIFICATION', 'supervisor_sha256': S.sha_file(sup), 'mode': 'NEW_RUN_V004',
         'log_dir': str(logd), 'finished_epoch': time.time(), 'checks': {'a': {}}, 'production_fingerprint': {'x': 1}, 'foreign_roots': f0}
    q.update(kw); p = work / ('Q_%d.json' % len(list(work.glob('Q_*.json')))); p.write_text(json.dumps(q)); return p
rec('qualification_admits_new_run', S.require_qualification(qual(), logd)['foreign_roots'] == f0)
for tag, kw, needle in (('blocked', {'status': 'BLOCKED'}, 'QUALIFICATION_NOT_PASS'),
                        ('other_supervisor', {'supervisor_sha256': 'F' * 64}, 'QUALIFICATION_OTHER_SUPERVISOR'),
                        ('r2_qualification', {'schema': 'CDT21_G5_V003_WINDOWS_QUALIFICATION_V001'}, 'QUALIFICATION_NOT_PASS'),
                        ('other_log_dir', {'log_dir': str(logd) + 'X'}, 'QUALIFICATION_OTHER_RUN'),
                        ('other_mode', {'mode': 'RESUME'}, 'QUALIFICATION_OTHER_RUN'),
                        ('stale', {'finished_epoch': time.time() - 3 * 3600}, 'QUALIFICATION_STALE')):
    rec('neg_qualification_' + tag, *raises(lambda: S.require_qualification(qual(**kw), logd), needle))

# 11. Native b2d runner mechanics on the fixed V004 layout.
qt = work / 'QT'; qt.mkdir()
bb = S.native_b2d(ext, qt, work / 'b2d.log')
rec('native_b2d_runner_mechanics', bb['exit'] == 0 and bb['ran'] == 29 and bb['ok'] and bb['contract_not_met'] == 0, bb)

# 12. Return packaging: V004 names, duplicates of the package and native return indexed by hash.
rr = work / 'RET_ROOT'; (rr / 'FINAL_G5' / 'INPUTS').mkdir(parents=True); (rr / 'SOURCE_REVIEW').mkdir()
shutil.copyfile(v4zip, rr / 'FINAL_G5' / 'INPUTS' / 'FINAL_PACKAGE.zip')
(rr / 'R08_RETURN.zip').write_bytes(b'PK-native'); shutil.copyfile(rr / 'R08_RETURN.zip', rr / 'FINAL_G5' / 'INPUTS' / 'NATIVE_RETURN.zip')
(rr / 'FINAL_G5' / 'ENGINEERING_COMPLETENESS.json').write_text('{}'); (rr / 'SOURCE_REVIEW' / S.REVIEW_NAME).write_bytes(review.read_bytes())
stg = work / 'STAGE'; stg.mkdir(); shutil.copyfile(sup, stg / S.SUPERVISOR_NAME); (stg / 'SUPERVISOR_CONSOLE.log').write_text('c')
rz = work / 'RET.zip'
ex = S.build_return(rr, stg, rz, S.PACKAGE_SHA, S.sha_file(rr / 'R08_RETURN.zip'))
import zipfile
with zipfile.ZipFile(rz) as z:
    idx = json.loads(z.read('RETURN_INDEX.json')); names = z.namelist()
rec('return_v004_names_and_duplicate_index', idx['schema'] == 'CDT21_G5_V004_RETURN_INDEX_V001' and 'SUPERVISOR/CDT21_G5_V004_SUPERVISOR.py' in names
    and len(ex) == 2 and all(e['equal'] for e in ex) and 'FINAL_G5/INPUTS/FINAL_PACKAGE.zip' not in names, ex)

# 13. Fail-closed entry points off Windows, without effects on the pre-existing roots.
env = dict(os.environ, LOCALAPPDATA=str(local))
for tag, extra, needle, result_name, rc in (
        ('qualify_only', ['--qualify-only'], 'QUAL_windows_python_admin', 'QUALIFICATION_RESULT.json', 2),
        ('effect_without_qualification', [], 'NEW_RUN_REQUIRES_WINDOWS_QUALIFICATION', 'SUPERVISOR_RESULT.json', 2),
        ('effect_with_qualification_off_windows', ['--require-qualification', str(qual())], 'WINDOWS_REQUIRED', 'SUPERVISOR_RESULT.json', 2)):
    st = work / ('ST_' + tag); st.mkdir(); shutil.copyfile(sup, st / S.SUPERVISOR_NAME)
    rv = st / S.REVIEW_NAME; rv.write_bytes(review.read_bytes()); lg = work / ('LG_' + tag); lg.mkdir()
    before = S.foreign_roots(local); home_before = S.tree_digest(local / 'CDT21_G5_V004')
    r = subprocess.run([sys.executable, '-I', '-B', str(st / S.SUPERVISOR_NAME), '--package', str(v4zip), '--review', str(rv),
                        '--log-dir', str(lg), '--stage', str(st)] + extra, capture_output=True, text=True, timeout=180, env=env)
    res = json.loads((lg / result_name).read_bytes())
    rec('fail_closed_' + tag, r.returncode == rc and any(needle in x for x in res['blockers']) and S.foreign_roots(local) == before
        and S.tree_digest(local / 'CDT21_G5_V004') == home_before, res['blockers'])
st = work / 'ST_resume'; st.mkdir(); shutil.copyfile(sup, st / S.SUPERVISOR_NAME); lg = work / 'LG_resume'; lg.mkdir()
r = subprocess.run([sys.executable, '-I', '-B', str(st / S.SUPERVISOR_NAME), '--package', str(v4zip), '--review', str(review),
                    '--log-dir', str(lg), '--stage', str(st), '--resume-root', str(local / 'CDT20_R08' / v3run), '--d-lab', str(dl / v3run)],
                   capture_output=True, text=True, timeout=60, env=env)
rec('resume_arguments_rejected_before_any_effect', r.returncode == 2 and 'unrecognized arguments: --resume-root' in r.stderr
    and not any(lg.iterdir()) and S.foreign_roots(local) == f0, r.stderr.strip().splitlines()[-1] if r.stderr else '')

summary = {'schema': 'CDT21_G5_V004_SUPERVISOR_LINUX_VALIDATION_V001', 'supervisor_sha256': S.sha_file(sup), 'r2_sha256': S.sha_file(r2),
           'review_sha256': S.sha_file(review), 'candidate_sha256': S.sha_file(v4zip), 'checks': checks,
           'passed': sum(v['status'] == 'PASS' for v in checks.values()), 'total': len(checks),
           'windows_runtime_only': ['IsUserAnAdmin', 'GetVolumeInformationW', 'kill-on-close Job nesting', 'msvcrt CAMPAIGN.lock',
                                    'native b2d negative on the R1 layout (contract branch only on os.name==nt)', 'frozen 38-unit campaign',
                                    'PRE_G06_COMPLETENESS.close on the native return'],
           'decision': 'Linux tests alone do not make the supervisor ready; the launcher runs the native qualification (Q) and the '
                       'effectful phase requires its PASS'}
out.write_text(json.dumps(summary, indent=1, sort_keys=True) + '\n')
print('PASSED', summary['passed'], '/', summary['total'])
sys.exit(0 if summary['passed'] == summary['total'] else 1)
