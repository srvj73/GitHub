"""Qualification of the G5 V004 supervisor R2 digest fix (Linux; the NTFS index lag is modelled exactly as DIAGQ observed).

Usage: python -I test_r2_digest.py <old 273E6207.py> <new R2.py> <v003_root_src> <work> <out.json> [--mutant NAME]
Model (DIAGQ 4FEBE2F7, control tree CDT21_G5_V003: 86 directories): the size/mtime that a directory listing reports for
an entry X (FindFirstFile duplicated information = DirEntry.stat) can lag behind X itself (os.lstat = handle view)
until X is enumerated; enumerating X refreshes it.  os.scandir is wrapped to reproduce that; os.lstat is the truth.
"""
import ast
import importlib.util
import json
import os
import re
import shutil
import sys
import types
from pathlib import Path

old_p, new_p, v003, work, out = map(Path, sys.argv[1:6])
MUTANT = sys.argv[7] if len(sys.argv) > 7 and sys.argv[6] == '--mutant' else None
work = work.resolve()
results = []


def check(name, ok, detail=''):
    results.append({'case': name, 'pass': bool(ok), 'detail': detail})


def load(path, tag):
    src = Path(path).read_text(encoding='utf-8')
    if MUTANT and tag == 'new':
        src = mutate(src)
    mod = types.ModuleType('sup_' + tag); mod.__file__ = str(path)
    exec(compile(src, str(path), 'exec'), mod.__dict__)
    return mod


def mutate(src):
    m = {
        'M1_FOREIGN_INDEX_VIEW': ("                st = os.lstat(e.path)  # the entry itself, not the NTFS directory index (R2)\n            except OSError:",
                                  "                st = e.stat(follow_symlinks=False)\n            except OSError:"),
        'M2_PRODUCTION_INDEX_VIEW': ("            for e in it:\n                st = os.lstat(e.path)  # the entry itself, not the NTFS directory index (R2)\n",
                                     "            for e in it:\n                st = e.stat(follow_symlinks=False)\n"),
        'M3_NO_EVIDENCE': ("        result[key + '_difference'] = foreign_detail(local, before, after, rows_before, dict(_ROWS))\n",
                           "        pass\n"),
        'M4_EMPTY_ENTRY_EVIDENCE': ("                           'entries_changed': [[r1[x], r2[x]] for x in sorted(r1) if x in r2 and r1[x] != r2[x]][:200],",
                                    "                           'entries_changed': [],"),
        'M5_CHECK_SWALLOWED': ("    return foreign_unchanged(before, after, run_id)\n\n",
                               "    return {'pre_existing': len(before)}\n\n"),
    }[MUTANT]
    assert src.count(m[0]) == 1, MUTANT
    return src.replace(m[0], m[1])


OLD, NEW = load(old_p, 'old'), load(new_p, 'new')

# ------------------------------------------------------------------ NTFS directory-index lag model
REAL_SCANDIR = os.scandir
MODEL = {'stale': {}, 'stat_calls': 0}


class Entry:
    def __init__(self, e):
        self._e = e; self.name = e.name; self.path = e.path

    def stat(self, follow_symlinks=True):
        MODEL['stat_calls'] += 1
        st = self._e.stat(follow_symlinks=follow_symlinks)
        lag = MODEL['stale'].get(os.path.abspath(self.path))
        if lag is None:
            return st
        return types.SimpleNamespace(st_size=lag.get('size', st.st_size), st_mtime_ns=lag.get('mtime_ns', st.st_mtime_ns),
                                     st_mode=st.st_mode, st_file_attributes=getattr(st, 'st_file_attributes', 0))

    def is_dir(self, follow_symlinks=True): return self._e.is_dir(follow_symlinks=follow_symlinks)
    def is_file(self, follow_symlinks=True): return self._e.is_file(follow_symlinks=follow_symlinks)
    def is_symlink(self): return self._e.is_symlink()
    def is_junction(self): return self._e.is_junction()
    def inode(self): return self._e.inode()


class Scan:
    def __init__(self, path):
        self.path = os.path.abspath(path); self.it = REAL_SCANDIR(path)
        if MODEL.get('refresh_on_enumerate', True):
            MODEL['stale'].pop(self.path, None)          # enumerating X refreshes X's entry in its parent's index
    def __enter__(self): return self
    def __exit__(self, *a): self.it.close()
    def __iter__(self): return (Entry(e) for e in self.it)


def model_on(stale, refresh=True):
    MODEL.update(stale=dict(stale), stat_calls=0, refresh_on_enumerate=refresh); os.scandir = Scan


def model_off():
    os.scandir = REAL_SCANDIR


def env(tag):
    w = work / tag
    if w.exists():
        shutil.rmtree(w)
    local = w / 'LOCAL'; (local / 'CDT20_R08').mkdir(parents=True)
    root = local / 'CDT20_R08' / 'R08_Q1_20261020210605_856fea523791'
    shutil.copytree(v003, root, symlinks=True)
    (local / 'CDT20_R08' / 'CURRENT_09AA56B867476005.json').write_text('x' * 179)
    dl = w / 'D:\\TICKSTORE_CDT19_PRE_G06_LABS' / 'R08_Q1_20261020210605_856fea523791'
    shutil.copytree(v003 / 'COMMITS', dl / 'WRITER_EFFECTFUL')
    prod = w / 'D:\\Base CSV'; (prod / 'Scripts').mkdir(parents=True); (prod / 'a.csv').write_text('1')
    (prod / 'Scripts' / 'MENU.py').write_text('m')
    os.chdir(w)
    return w, local, root, dl, prod


def dirs_below(base):
    return [os.path.abspath(os.path.join(dp, d)) for dp, dns, _ in os.walk(base) for d in dns]


# 1. Composition: only the intended functions change; no check is added or removed.
def funcs(p):
    src = Path(p).read_text(encoding='utf-8'); t = ast.parse(src)
    return {n.name: ast.get_source_segment(src, n) for n in t.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
fo, fn = funcs(old_p), funcs(new_p)
changed = sorted(k for k in fo if k in fn and fo[k] != fn[k]); added = sorted(k for k in fn if k not in fo)
check('C1_only_intended_functions_change', changed == ['foreign_roots', 'link_safe_digest', 'main', 'qualify_main', 'tree_digest']
      and added == ['foreign_checked', 'foreign_detail', 'foreign_path'] and not [k for k in fo if k not in fn], {'changed': changed, 'added': added})
codes = lambda p: sorted(set(re.findall(r"'([A-Z][A-Z0-9_]{5,})(?::|')", Path(p).read_text(encoding='utf-8'))))
check('C2_same_blocker_codes', codes(old_p) == codes(new_p), sorted(set(codes(old_p)) ^ set(codes(new_p))))
check('C3_no_index_view_metadata_left', 'e.stat(follow_symlinks=False)' not in Path(new_p).read_text(encoding='utf-8')
      and Path(old_p).read_text(encoding='utf-8').count('e.stat(follow_symlinks=False)') == 3)

# 2. Without any lag the new digest equals the old one byte for byte (format and values unchanged).
w, local, root, dl, prod = env('E2_NO_LAG')
check('E2_same_digest_without_lag', OLD.foreign_roots(str(local)) == {k: v for k, v in NEW.foreign_roots(str(local)).items()}
      and OLD.production_fingerprint() == NEW.production_fingerprint())

# 3. The DIAGQ mechanism: stale directory entries refreshed by the first walk.
w, local, root, dl, prod = env('E3_LAG')
lagged = {d: {'mtime_ns': os.lstat(d).st_mtime_ns - 2_000_000} for d in dirs_below(root)[:86] + dirs_below(dl)[:20]}
model_on(lagged); a = OLD.foreign_roots(str(local)); b = OLD.foreign_roots(str(local)); calls_old = MODEL['stat_calls']; model_off()
check('E3a_old_reproduces_q_failure', a != b and all(a[k]['entries'] == b[k]['entries'] for k in a if 'entries' in a[k])
      and sorted(k for k in a if a[k] != b[k]) == ['d_lab/R08_Q1_20261020210605_856fea523791', 'run/R08_Q1_20261020210605_856fea523791'],
      sorted(k for k in a if a[k] != b[k]))
model_on(lagged); c = NEW.foreign_roots(str(local)); d = NEW.foreign_roots(str(local)); calls_new = MODEL['stat_calls']; model_off()
truth = NEW.foreign_roots(str(local))
check('E3b_new_stable_and_true_under_lag', c == d == truth and calls_new == 0 and calls_old > 0, {'index_stat_calls_new': calls_new, 'old': calls_old})
plag = {os.path.abspath(prod / 'Scripts'): {'mtime_ns': os.lstat(prod / 'Scripts').st_mtime_ns - 5_000_000}}
model_on(plag); p1 = OLD.production_fingerprint(); p2 = OLD.production_fingerprint(); model_off()
model_on(plag); p3 = NEW.production_fingerprint(); p4 = NEW.production_fingerprint(); model_off()
check('E3c_production_fingerprint_same_mechanism', p1 != p2 and p3 == p4 == NEW.production_fingerprint())

# 4. Real changes are still detected (protection preserved), each on a fresh tree, with per-entry evidence.
def real_change(tag, mutate_fn, expect_key, expect_code='FOREIGN_ROOT_CHANGED'):
    w, local, root, dl, prod = env('E4_' + tag)
    before = NEW.foreign_roots(str(local)); rows = dict(NEW._ROWS)
    mutate_fn(local, root, dl)
    after = NEW.foreign_roots(str(local))
    det = NEW.foreign_detail(str(local), before, after, rows, dict(NEW._ROWS))
    try:
        NEW.foreign_unchanged(before, after, 'R08_Q1_29990101000000_000000000000'); code = 'NO_BLOCK'
    except Exception as exc:
        code = str(exc)
    try:
        keyed = bool(expect_key(det))
    except Exception as exc:
        keyed = False; code += ' | EVIDENCE_ERROR ' + type(exc).__name__
    ok = after != before and code.startswith(expect_code) and keyed
    check('E4_' + tag, ok, {'code': code[:120], 'detail': json.dumps(det)[:400]})
first_file = lambda root: sorted(p for p in root.rglob('*') if p.is_file() and not p.is_symlink())[0]
real_change('size_change', lambda l, r, d: first_file(r).open('ab').write(b'X'),
            lambda det: det['changed']['run/R08_Q1_20261020210605_856fea523791']['entries_changed'])
real_change('mtime_only', lambda l, r, d: os.utime(first_file(r), ns=(1, 1)),
            lambda det: det['changed']['run/R08_Q1_20261020210605_856fea523791']['entries_changed'][0][1][2] == 1)
real_change('file_created', lambda l, r, d: (r / 'UNITS' / 'NEW.tmp').write_text('n'),
            lambda det: [e[0] for e in det['changed']['run/R08_Q1_20261020210605_856fea523791']['entries_added']] == ['UNITS/NEW.tmp'])
real_change('file_deleted', lambda l, r, d: first_file(r).unlink(),
            lambda det: det['changed']['run/R08_Q1_20261020210605_856fea523791']['entries_removed'])
real_change('file_renamed', lambda l, r, d: first_file(r).rename(first_file(r).with_name('RENAMED.bin')),
            lambda det: det['changed']['run/R08_Q1_20261020210605_856fea523791']['entries_added'])
real_change('dir_created_in_d_lab', lambda l, r, d: (d / 'WRITER_EFFECTFUL' / 'NEWDIR').mkdir(),
            lambda det: det['changed']['d_lab/R08_Q1_20261020210605_856fea523791']['entries_added'])
real_change('link_added', lambda l, r, d: os.symlink('/tmp', r / 'LINK'),
            lambda det: det['changed']['run/R08_Q1_20261020210605_856fea523791']['after']['links_not_followed'] == 1)
real_change('current_json_size', lambda l, r, d: (l / 'CDT20_R08' / 'CURRENT_09AA56B867476005.json').write_text('y' * 180),
            lambda det: 'run/CURRENT_09AA56B867476005.json' in det['changed'])
real_change('sibling_root_added', lambda l, r, d: (l / 'CDT20_R08' / 'R08_Q1_20991231000000_aaaaaaaaaaaa').mkdir(),
            lambda det: det['added'] == ['run/R08_Q1_20991231000000_aaaaaaaaaaaa'], 'FOREIGN_ROOT_ADDED')
w, local, root, dl, prod = env('E4_production')
pb = NEW.production_fingerprint(); (prod / 'a.csv').write_text('22'); pa = NEW.production_fingerprint()
check('E4_production_change_detected', pa != pb)

# 5. A real change hidden by a stale index: the old digest misses it, the new one does not.
w, local, root, dl, prod = env('E5_HIDDEN')
f = first_file(root); st0 = os.lstat(f)
before_old = OLD.foreign_roots(str(local)); before_new = NEW.foreign_roots(str(local))
f.open('ab').write(b'REAL CHANGE')
hide = {os.path.abspath(f): {'size': st0.st_size, 'mtime_ns': st0.st_mtime_ns}}
model_on(hide, refresh=False); after_old = OLD.foreign_roots(str(local)); after_new = NEW.foreign_roots(str(local)); model_off()
check('E5_old_misses_real_change_new_detects', after_old == before_old and after_new != before_new,
      {'old_detects': after_old != before_old, 'new_detects': after_new != before_new})

# 6. E-phase wrapper: own new run admitted; any foreign change refused with per-entry evidence; decisions unchanged.
w, local, root, dl, prod = env('E6_E_PHASE')
run_id = 'R08_Q1_29990101000000_0123456789ab'
before = NEW.foreign_roots(str(local)); rows = dict(NEW._ROWS)
(local / 'CDT20_R08' / run_id).mkdir(); (w / 'D:\\TICKSTORE_CDT19_PRE_G06_LABS' / run_id).mkdir()
res = {}
ok_sum = NEW.foreign_checked(str(local), before, rows, run_id, res, 'foreign_roots')
check('E6a_own_new_run_admitted_without_evidence_noise', ok_sum.get('added') == ['d_lab/' + run_id, 'run/' + run_id] and 'foreign_roots_difference' not in res, ok_sum)
first_file(root).open('ab').write(b'Z'); res = {}
try:
    NEW.foreign_checked(str(local), before, rows, run_id, res, 'foreign_roots_after_close'); code = 'NO_BLOCK'
except Exception as exc:
    code = str(exc)
ev = res.get('foreign_roots_after_close_difference', {})
check('E6b_foreign_change_refused_with_entry_evidence', code.startswith('FOREIGN_ROOT_CHANGED:run/R08_Q1_20261020210605_856fea523791')
      and bool(ev.get('changed', {}).get('run/R08_Q1_20261020210605_856fea523791', {}).get('entries_changed')), code[:100])
w, local, root, dl, prod = env('E6c_MISSING_OWN')
before = NEW.foreign_roots(str(local)); rows = dict(NEW._ROWS)
(w / 'D:\TICKSTORE_CDT19_PRE_G06_LABS' / run_id).mkdir(); res = {}
try:
    NEW.foreign_checked(str(local), before, rows, run_id, res, 'foreign_roots'); code = 'NO_BLOCK'
except Exception as exc:
    code = str(exc)
check('E6c_missing_own_root_refused_with_evidence', code == 'FOREIGN_ROOT_ADDED:d_lab/' + run_id
      and res.get('foreign_roots_difference', {}).get('added') == ['d_lab/' + run_id], code[:100])

# 7. Q evidence path: the statements added to qualify_main produce the per-entry difference the origin found missing.
w, local, root, dl, prod = env('E7_Q_EVIDENCE')
foreign = NEW.foreign_roots(str(local)); rows_q = dict(NEW._ROWS)
(root / 'LIVE_STATUS.json').open('ab').write(b' ')
after = NEW.foreign_roots(str(local)); q = {}
if after != foreign:
    q['foreign_roots_after'] = after
    q['foreign_roots_difference'] = NEW.foreign_detail(str(local), foreign, after, rows_q, dict(NEW._ROWS))
detail = {k: sorted(v) for k, v in q['foreign_roots_difference'].items()}
src_q = funcs(new_p)['qualify_main']
ec = q['foreign_roots_difference'].get('changed', {}).get('run/R08_Q1_20261020210605_856fea523791', {}).get('entries_changed') or [[['']]]
check('E7_q_records_root_and_entry_difference', detail == {'added': [], 'changed': ['run/R08_Q1_20261020210605_856fea523791'], 'removed': []}
      and ec[0][0][0] == 'LIVE_STATUS.json'
      and "q['foreign_roots_difference'] = foreign_detail(local, foreign, after, rows_q, dict(_ROWS))" in src_q
      and "ok('q_no_effect_on_foreign_roots', after == foreign," in src_q, detail)

doc = {'schema': 'CDT21_G5_V004_SUPERVISOR_R2_DIGEST_QUALIFICATION_V001', 'mutant': MUTANT,
       'old_sha256': __import__('hashlib').sha256(old_p.read_bytes()).hexdigest().upper(),
       'new_sha256': __import__('hashlib').sha256(new_p.read_bytes()).hexdigest().upper(),
       'passed': sum(c['pass'] for c in results), 'total': len(results), 'cases': results}
Path(out).write_text(json.dumps(doc, indent=1, default=str), encoding='utf-8')
print('R2_DIGEST', MUTANT or 'ORIGINAL', doc['passed'], '/', doc['total'], [c['case'] for c in results if not c['pass']])
