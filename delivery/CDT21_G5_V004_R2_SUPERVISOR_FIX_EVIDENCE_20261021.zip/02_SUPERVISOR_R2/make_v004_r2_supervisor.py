"""Derive the G5 V004 supervisor R2 from the V004 supervisor (273E6207...) by exact, counted replacements.

Usage: python -I make_v004_r2_supervisor.py <CDT21_G5_V004_SUPERVISOR.py (273E6207...)> <out.py>
Cause closed by the native DIAGQ (return 4FEBE2F7...): the digests took size/mtime from the NTFS directory index
(os.scandir DirEntry.stat -> FindFirstFile duplicated information), which lagged for hours behind the entries
written by the V003 R2 resumption and was refreshed by the first enumeration of Q; the USN journals of C: and D:
cover the Q window and hold no record in any protected root.  Fix: take size/mtime from the entry itself
(os.lstat -> GetFileInformationByHandle); record per-root and per-entry evidence when a foreign check refuses.
Names, types, compared fields, thresholds and every require() are unchanged.
"""
import hashlib
import sys
from pathlib import Path

PARENT_SHA = '273E620746FD5293D87858847CEBE035328B2A354F4371BBB18D82195A410126'
src, out = Path(sys.argv[1]), Path(sys.argv[2])
raw = src.read_bytes()
assert hashlib.sha256(raw).hexdigest().upper() == PARENT_SHA, 'PARENT_SHA'
text = raw.decode('utf-8')

EDITS = [
    # D1 docstring: state the R2 change truthfully.
    ("    38-unit plan read from frozen constants, the kill-on-close Job, the read-only tree digest and\n",
     "    38-unit plan read from frozen constants, the kill-on-close Job, the read-only tree digest (R2: per-entry\n"
     "    metadata from the entry itself, below) and\n"),
    ("    LIVE_STATUS and R08_RETURN checkpoints consistent with them.\n",
     "    LIVE_STATUS and R08_RETURN checkpoints consistent with them.\n"
     "  * R2 (2026-10-21, native DIAGQ 4FEBE2F7...): every digest takes size/mtime of an entry from the entry itself\n"
     "    (os.lstat -> GetFileInformationByHandle), never from the NTFS directory index (FindFirstFile /\n"
     "    DirEntry.stat), which can lag for hours and is refreshed by the first enumeration; a refused foreign-root\n"
     "    check records the difference per root and per entry.  Names, types, fields and checks are unchanged.\n"),
    # D2 evidence store (rows of the last link_safe_digest per base).
    ("_out_lock = threading.Lock()\n_console = None\n",
     "_out_lock = threading.Lock()\n_console = None\n_ROWS = {}  # rows of the last link_safe_digest per base path (evidence only)\n"),
    # D3 tree_digest (production fingerprint): metadata from the entry, not from the directory index.
    ("            for e in it:\n                st = e.stat(follow_symlinks=False)\n                rel = Path(e.path).relative_to(base).as_posix()\n",
     "            for e in it:\n                st = os.lstat(e.path)  # the entry itself, not the NTFS directory index (R2)\n"
     "                rel = Path(e.path).relative_to(base).as_posix()\n"),
    # D4 link_safe_digest (foreign roots): same.
    ("            try:\n                st = e.stat(follow_symlinks=False)\n            except OSError:\n",
     "            try:\n                st = os.lstat(e.path)  # the entry itself, not the NTFS directory index (R2)\n            except OSError:\n"),
    ("    rows.sort()\n    return {'exists': True, 'entries': len(rows), 'links_not_followed': links,",
     "    rows.sort()\n    _ROWS[str(base)] = rows\n    return {'exists': True, 'entries': len(rows), 'links_not_followed': links,"),
    # D5 top-level non-directories of the foreign parents: same.
    ("{'not_a_directory': True, 'size': e.stat(follow_symlinks=False).st_size}",
     "{'not_a_directory': True, 'size': os.lstat(e.path).st_size}"),
    # D6 evidence helpers (decisions stay in foreign_unchanged / the callers' require()).
    ("    require(added == ['d_lab/' + run_id, 'run/' + run_id], 'FOREIGN_ROOT_ADDED:' + ','.join(added))\n"
     "    return {'pre_existing': len(before), 'unchanged': len(before), 'added': added}\n",
     "    require(added == ['d_lab/' + run_id, 'run/' + run_id], 'FOREIGN_ROOT_ADDED:' + ','.join(added))\n"
     "    return {'pre_existing': len(before), 'unchanged': len(before), 'added': added}\n"
     "\n\n"
     "def foreign_path(local, key):\n"
     "    label, name = key.split('/', 1)\n"
     "    return str(Path(local) / RUN_PARENT / name) if label == 'run' else str(Path(D_LABS) / name)\n"
     "\n\n"
     "def foreign_detail(local, before, after, rows_before, rows_after):\n"
     "    \"\"\"Evidence of a foreign-root difference, per root and per entry (never relaxes a check).\"\"\"\n"
     "    d = {'added': sorted(k for k in after if k not in before), 'removed': sorted(k for k in before if k not in after),\n"
     "         'changed': {}}\n"
     "    for k in sorted(k for k in before if k in after and before[k] != after[k]):\n"
     "        r1 = {r[0]: r for r in rows_before.get(foreign_path(local, k), [])}\n"
     "        r2 = {r[0]: r for r in rows_after.get(foreign_path(local, k), [])}\n"
     "        d['changed'][k] = {'before': before[k], 'after': after[k],\n"
     "                           'entries_changed': [[r1[x], r2[x]] for x in sorted(r1) if x in r2 and r1[x] != r2[x]][:200],\n"
     "                           'entries_added': [r2[x] for x in sorted(r2) if x not in r1][:200],\n"
     "                           'entries_removed': [r1[x] for x in sorted(r1) if x not in r2][:200]}\n"
     "    return d\n"
     "\n\n"
     "def foreign_checked(local, before, rows_before, run_id, result, key):\n"
     "    \"\"\"foreign_unchanged, recording result[key + '_difference'] (per entry) whenever it is going to refuse.\"\"\"\n"
     "    after = foreign_roots(local)\n"
     "    own = ('d_lab/' + run_id, 'run/' + run_id)\n"
     "    if {k: v for k, v in after.items() if k not in own} != before or not all(k in after for k in own):\n"
     "        result[key + '_difference'] = foreign_detail(local, before, after, rows_before, dict(_ROWS))\n"
     "    return foreign_unchanged(before, after, run_id)\n"),
    # D7 qualify_main: same predicate, plus the evidence the origin found missing.
    ("        foreign = foreign_roots(local); q['foreign_roots'] = foreign\n",
     "        foreign = foreign_roots(local); q['foreign_roots'] = foreign; rows_q = dict(_ROWS)\n"),
    ("        ok('q_no_effect_on_foreign_roots', foreign_roots(local) == foreign)\n",
     "        after = foreign_roots(local)\n"
     "        if after != foreign:\n"
     "            q['foreign_roots_after'] = after\n"
     "            q['foreign_roots_difference'] = foreign_detail(local, foreign, after, rows_q, dict(_ROWS))\n"
     "        ok('q_no_effect_on_foreign_roots', after == foreign,\n"
     "           '' if after == foreign else {k: sorted(v) for k, v in q['foreign_roots_difference'].items()})\n"),
    # D8 main (E): same predicates, plus evidence.
    ("        foreign_before = foreign_roots(local)\n"
     "        require(foreign_before == result['qualification']['foreign_roots'], 'FOREIGN_ROOTS_CHANGED_SINCE_QUALIFICATION')\n",
     "        foreign_before = foreign_roots(local); rows_e = dict(_ROWS)\n"
     "        if foreign_before != result['qualification']['foreign_roots']:\n"
     "            result['foreign_roots_difference'] = foreign_detail(local, result['qualification']['foreign_roots'],\n"
     "                                                                foreign_before, {}, rows_e)\n"
     "        require(foreign_before == result['qualification']['foreign_roots'], 'FOREIGN_ROOTS_CHANGED_SINCE_QUALIFICATION')\n"),
    ("        result['foreign_roots'] = foreign_unchanged(foreign_before, foreign_roots(local), run_id)\n",
     "        result['foreign_roots'] = foreign_checked(local, foreign_before, rows_e, run_id, result, 'foreign_roots')\n"),
    ("        result['foreign_roots_after_close'] = foreign_unchanged(foreign_before, foreign_roots(local), run_id)\n",
     "        result['foreign_roots_after_close'] = foreign_checked(local, foreign_before, rows_e, run_id, result,\n"
     "                                                              'foreign_roots_after_close')\n"),
]
for old, new in EDITS:
    assert text.count(old) == 1, ('ANCHOR', old[:90])
    text = text.replace(old, new)
assert 'e.stat(follow_symlinks=False)' not in text, 'INDEX_VIEW_METADATA_LEFT'
data = text.encode('utf-8')
out.write_bytes(data)
print(out.name, hashlib.sha256(data).hexdigest().upper(), len(data), len(text.split('\n')))
