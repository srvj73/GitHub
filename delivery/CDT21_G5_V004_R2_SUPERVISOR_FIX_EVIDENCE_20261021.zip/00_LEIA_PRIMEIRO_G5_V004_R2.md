# CDT21 — G5 V004 R2: causa fechada e correção mínima do supervisor

**Papel:** implementador. Este documento não é parecer B06.

## Causa física (fechada pela DIAGQ nativa `4FEBE2F7…`)

1. A retomada do G5 V003 (R2, fase E, 21/10 às 07:28–07:40, horário local) gravou na raiz e no laboratório `R08_Q1_20261020210605_856fea523791`.
2. Para alguns diretórios dessas árvores, o tamanho e o mtime que o **índice do diretório-pai** guarda (FindFirstFile, lido pelo `DirEntry.stat` do Python) ficaram defasados em relação à própria entrada. É o comportamento documentado do NTFS para a informação duplicada no índice.
3. A Q de 15:40 fez seu primeiro digest pelo índice. Essa leitura atualizou o índice (com `DisableLastAccess = 0`, a enumeração reescreve a entrada no índice com os valores atuais). O segundo digest, 15 s depois, leu valores diferentes.
4. **Não houve modificação de nada:**
   - o diário USN de C: e de D: cobre a janela;
   - há 2.236 registros das gravações da própria Q nessa janela, o que comprova a cobertura;
   - não há **nenhum** registro nas raízes protegidas, durante ou depois da Q;
   - as duas raízes mantêm o mesmo número de entradas (3.116 e 339);
   - as outras 24 entradas estão iguais;
   - `D:\Base CSV` está igual;
   - a observação de 2 min ficou estável.
5. **Reprodução independente:** na árvore de controle `CDT21_G5_V003`, gravada pela mesma retomada R2 e nunca percorrida pela Q, a coleta encontrou o fenômeno. Em 86 diretórios, o índice estava atrasado de 1 a 150 ms em relação à entrada havia 10,4 h. Após a leitura, o índice passou a coincidir com a entrada. As árvores de controle G0 não tinham atraso e não se moveram.

**Correção de leitura da coleta:** as “11 divergências índice x handle” nas raízes protegidas são as junctions `Base CSV/Scripts` dos laboratórios. Nelas o mtime é idêntico nas duas vistas; a diferença era apenas o código de tamanho que a minha coleta atribuiu (-2 no índice, -1 no handle). **A divergência real é 0.**

## Correção mínima — `CDT21_G5_V004_SUPERVISOR.py` R2 (`2A5F4B7138C950D320F7787540F98FF912D1AFB6C86C59E0F562887DB671029F`)

A derivação é feita por counted replacements sobre `273E6207…`. O diff tem 9 linhas removidas e 47 acrescentadas.

- **Fonte dos metadados:** os digests passam a ler tamanho e mtime **da própria entrada** (`os.lstat`, vista do handle), nunca do índice. Isso vale em quatro pontos:
  - `link_safe_digest`, usado nas raízes e laboratórios preexistentes;
  - os arquivos de topo de `foreign_roots`;
  - `tree_digest`, que gera a impressão digital de `D:\Base CSV`;
  - a vista do índice deixa de ser lida para metadados: 0 chamadas no modelo.
- **Inalterado:** nomes, tipos, campos comparados, todas as exigências (`require`) e os mesmos códigos de bloqueio. Sem atraso no índice, o digest novo é **idêntico** ao antigo.
- **Evidência:** quando uma checagem de raízes recusa, Q e E registram a diferença por raiz e por entrada (`foreign_roots_difference`) — a lacuna que a origem apontou.

## Qualificação (Linux; os metadados do Windows já foram provados nativamente pela DIAGQ)

**Digest R2: 22/22.**

| Caso | Resultado |
|---|---|
| Composição | mudam só `tree_digest`, `link_safe_digest`, `foreign_roots`, `qualify_main` e `main`; novos só `foreign_path`, `foreign_detail` e `foreign_checked`; códigos de bloqueio idênticos |
| Sem atraso | mesmo digest do antigo |
| Mecanismo da DIAGQ (índice atrasado e atualizado pela leitura) | o antigo reproduz a falha da Q, nas mesmas duas raízes e com as mesmas contagens; o R2 fica estável e verdadeiro |
| Impressão digital de produção | idem |
| Alterações reais detectadas, com evidência por entrada | tamanho, só mtime, criação, exclusão, renomeação, diretório no laboratório, link, `CURRENT_*.json`, raiz irmã nova e produção |
| Alteração real mascarada por índice atrasado | o antigo **não detecta**; o R2 detecta |
| Fase E | a própria raiz nova é admitida; a alteração estrangeira é recusada com evidência; a falta da própria raiz é recusada |
| Fase Q | registra a diferença por entrada |

**Mutantes: 5/5 mortos.**

| Mutante | Enfraquecimento |
|---|---|
| M1 | índice nas raízes |
| M2 | índice em produção |
| M3 | sem evidência |
| M4 | evidência vazia |
| M5 | checagem engolida |

**Validação V004 anterior reexecutada:** 40/41. A única diferença é `r2_functions_byte_identical`, por construção: `tree_digest` deixou de ser idêntico ao R2 do V003. As outras 22 funções continuam idênticas, e todas as checagens de raízes, COMMITs, qualificação e falha fechada passam.

**Prova nativa já existente:**
- A DIAGQ usou `os.lstat` (Python 3.14.7) em todas as entradas das 22 raízes, com 0 erros e 0 divergências reais, e em 1.761 entradas da árvore de controle.
- O valor de `os.lstat` foi o atualizado mesmo quando o índice estava atrasado.
- Nas junctions, `os.lstat` não seguiu o link: o mtime é o da própria junction.

## Launcher único afetado — `RUN_CDT21_G5_V004_R2_20261021.ps1` (`8CC1ACB6B093020D4CFC94B3EB618A624243A3F8B3E9E1E991EA7B9E9C1B8DA2`)

O launcher é derivado do R1 (`E3F83D0A…`). Fora do payload, mudam apenas o cabeçalho (3 linhas) e o SHA fixado do supervisor. A classificação R1, a revisão `E84E5C39…`, os caminhos, o log, as fases e o retorno são byte a byte iguais. Parser com 0 erros, ASCII e CRLF.

RESULT_RETURN_TO=ChatGPT | PROJECT=Base de Dados CSV / Tickstore | THREAD=Compressão De Ticks 21
