"""Derive RUN_CDT21_G5_V004_R2_20261021.ps1 from the R1 launcher (E3F83D0A...): only the embedded supervisor changes.

Usage: python -I build_v004_r2_launcher.py <RUN_CDT21_G5_V004_R1_20261021.ps1> <supervisor R2.py> <out.ps1>
Header: identifies R2 and its cause; documented command names this file.  $SupervisorSha and the $SupervisorB64
here-string carry the R2 supervisor.  The R1 classification, review payload, paths, log rule, phases and return
packaging stay byte-identical.
"""
import base64
import hashlib
import sys
from pathlib import Path

R1_SHA = 'E3F83D0A76E4B372C02C4F7AFD28243CE7DB568A8B242810AECEE86396CED2C8'
OLD_SUP = '273E620746FD5293D87858847CEBE035328B2A354F4371BBB18D82195A410126'
r1, sup, out = map(Path, sys.argv[1:4])
raw = r1.read_bytes()
assert hashlib.sha256(raw).hexdigest().upper() == R1_SHA, 'R1_SHA'
text = raw.decode('ascii').replace('\r\n', '\n')
sup_raw = sup.read_bytes(); new_sup = hashlib.sha256(sup_raw).hexdigest().upper()
b64 = base64.b64encode(sup_raw).decode()
block = '\n'.join(b64[i:i + 100] for i in range(0, len(b64), 100))

start = text.index("$SupervisorB64 = @'\n") + len("$SupervisorB64 = @'\n")
end = text.index("\n'@", start)
old_block = text[start:end]
assert hashlib.sha256(base64.b64decode(old_block.replace('\n', ''))).hexdigest().upper() == OLD_SUP
text = text[:start] + block + text[end:]

EDITS = [
    ("# TICKSTORE CDT21 - LAUNCHER G5 V004 R1: campanha G5 nativa NOVA vinculada ao manifesto completo do V004 (decisao da origem 21/10).\n",
     "# TICKSTORE CDT21 - LAUNCHER G5 V004 R2: campanha G5 nativa NOVA vinculada ao manifesto completo do V004 (decisao da origem 21/10).\n"
     "# R2 (causa fechada pela DIAGQ nativa 4FEBE2F7): so o supervisor embutido muda. Os digests das raizes preexistentes e de\n"
     "# D:\\Base CSV passam a ler tamanho e mtime da propria entrada (os.lstat), nao do indice de diretorio NTFS, que ficava\n"
     "# defasado e era atualizado pela primeira leitura; uma recusa registra a diferenca por raiz e por entrada. Mesmas checagens.\n"),
    ("# byte a byte, mesmo Job kill-on-close, mesma impressao digital de D:\\Base CSV; sem modo de retomada.\n",
     "# byte a byte, mesmo Job kill-on-close, impressao digital de D:\\Base CSV pela vista da entrada (R2); sem modo de retomada.\n"),
    ('#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\\Users\\silvi\\Downloads\\RUN_CDT21_G5_V004_R1_20261021.ps1" -AutorizoLabD\n',
     '#   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\\Users\\silvi\\Downloads\\RUN_CDT21_G5_V004_R2_20261021.ps1" -AutorizoLabD\n'),
    ("$SupervisorSha = '" + OLD_SUP + "'\n", "$SupervisorSha = '" + new_sup + "'\n"),
]
for old, new in EDITS:
    assert text.count(old) == 1, ('ANCHOR', old[:80])
    text = text.replace(old, new)
data = text.replace('\n', '\r\n').encode('ascii')
out.write_bytes(data)
print(out.name, hashlib.sha256(data).hexdigest().upper(), len(data), 'SUPERVISOR', new_sup)
