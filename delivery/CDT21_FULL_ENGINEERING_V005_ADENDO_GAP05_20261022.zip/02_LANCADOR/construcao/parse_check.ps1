param([string]$Path)
$e=$null;$t=$null;[void][System.Management.Automation.Language.Parser]::ParseFile($Path,[ref]$t,[ref]$e)
Write-Output ("PARSE_ERRORS=" + $e.Count)
foreach ($x in $e) { Write-Output ($x.Extent.StartLineNumber.ToString() + ": " + $x.Message) }
