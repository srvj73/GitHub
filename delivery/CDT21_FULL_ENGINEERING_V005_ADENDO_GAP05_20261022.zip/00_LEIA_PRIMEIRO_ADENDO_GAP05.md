# CDT21 — Adendo GAP-05 ao FULL de engenharia V005 (2026-10-22)

**Papel:** implementador, não B06.
**Origem:** decisão da origem de 22/10. Ela determinou fechar a dependência de implementação do produtor das observações nativas do predecessor D4 e reconciliar o P4 com a autoextração segura.

## Vínculos (nada reconstruído)

| Item | SHA-256 |
|---|---|
| Candidato V005 congelado (não alterado) | `E3F1F4790D6AE6E5639F137FAEE3E91B2B8E6FFB51A95F18078DF734553CB145` |
| Pacote FULL de engenharia V005 (preservado) | `99C77F4603E3547E34D4513782B5590E10E5B33159F08CB0A1E08E46B6B77662` |
| Despacho B06 V005 (preservado) | `C43805B8D6187449458897C9B01EC34806407850BBECFF3A7CA8913734C09ED0` |
| G5 nativo V005: 38/38 COMMITs, verificação 32/32, cinco provas | preservados |

## O que este adendo fecha

**1. GAP-05: produtor das observações nativas do predecessor D4.**
- O produtor `01_PRODUTOR/CDT21_D4_PREDECESSOR_OBSERVER.py` fica **fora** do V005 congelado. Isso é tecnicamente possível porque o consumidor congelado só lê arquivos de `PredecessorEvidenceDir`.
- O produtor compõe apenas código congelado do V005:
  - `D4_ROOTS_EVIDENCE` (relatório de raízes e fatos do journal);
  - o `Win32Store` do motor (mesma chamada que gravou as identidades das raízes no gate do predecessor);
  - `PROCESS_CENSUS_MUTEX`;
  - `strict_json` e `validate_journal` do preparo.
- Depois de gravar, ele executa os próprios consumidores congelados sobre o que publicou: `D4_PREDECESSOR_RECONCILIATION.reconcile` e `D4_FIRST_ADMISSION_BOOTSTRAP.fresh_predecessor`.
- Os vínculos estão em `03_VINCULOS_AOS_CONSUMIDORES`: 21 exigências, cada uma com a linha do consumidor, o campo produzido, a fonte e os controles.

**2. P4 com extração manual.** O P4R1 (`06_PROCEDIMENTOS`) substitui a extração manual do instalador pela etapa `Instalar` do lançador autoextraível. O instalador congelado não foi reconstruído.

## Executor único

`02_LANCADOR/RUN_CDT21_V005_PREPARO_D4_20261022.ps1` (`40D8961B75B5385E42F9312A008D2B46E297ED8F00E7E59DADB55BDA3EA6488F`): PowerShell 5.1, autoextraível, executado a partir de `PS C:\Users\silvi>`.
- O produtor vem embutido, com SHA fixado.
- Do ZIP do V005, extrai os 9 membros congelados de que precisa. Cada um é conferido contra o `RUNTIME_CODE_MANIFEST` e contra o pin, com criação exclusiva em pasta própria.
- Etapas: `Qualificar` (laboratório), `Observar` (produção, somente leitura, no momento do D4) e `Instalar`.
- Logs em `C:\Users\silvi\Downloads\CDT21_PREPARO_D4_V005_RUNS\<ETAPA>_<stamp>\RUN_LOG.txt`.

## Qualificação do delta

| Evidência | Resultado |
|---|---|
| Linux, contra os consumidores congelados | 23/23: positivo, somente leitura, arquivamento e 19 recusas, cada uma com o motivo do consumidor |
| Mutantes do produtor | 15/15 mortos |
| Lançador (pwsh no Linux, substituições declaradas) | 8/8; parser sem erros |
| **Laboratório nativo no Windows do titular** (`05_EVIDENCIA_NATIVA`) | `PASS_NATIVE_LAB_QUALIFICATION`, verificação independente 16/16 (detalhes abaixo) |

**Laboratório nativo:**
- **Q1:** evidência admitida pelo `fresh_predecessor` congelado, com leitura Win32 e checagem real do mutex de censo.
- **Q2 a Q5:** lock presente, outro Python, marcador e raiz recriada recusados, cada um com exatamente o motivo previsto.
- **Censo nativo:** 301 processos legíveis. Ficaram fora 7 processos protegidos do kernel e nenhum interpretador.
- **Autoextração do instalador:** PASS.

Nenhuma suíte aprovada foi repetida. G5 e G0 não foram reexecutados.

## Achado informativo (GAP-18, sem alteração do V005)

Com a cadeia do `STATE_JOURNAL` quebrada, o `reconcile` congelado lança `AttributeError` em vez de devolver `BLOCKED`. O bootstrap termina com código diferente de zero, e o wrapper selado exige código 0 antes de qualquer efeito. A falha é fechada e sem efeito.

## Não executado e não declarado

- **Coleta efetiva das observações:** ocorre no momento operacional do D4 (P4R1), depois da B07 e a no máximo 300 s da admissão.
- **Não executados:** B06 pelo implementador, B07, D4/D5, canário e FULL.
- **Não consultados:** MASTER/HEAD.

## Para a B06

Este adendo é um suplemento do despacho `C43805B8…`. O produtor e o lançador são código executável novo da preparação do D4 e devem ser auditados junto com o candidato.
