"""Assemble CDT21_FULL_ENGINEERING_V005_ADENDO_GAP05_20261022.zip (no approved component rebuilt).

Usage: python -I build_adendo_gap05.py
"""
import hashlib, json, shutil, zipfile
from pathlib import Path

S = Path('/tmp/claude-0/-home-user-GitHub/ece1d4c3-5fd3-5d37-a54a-2c0b4e5a2396/scratchpad'); G = S / 'gap05'; A = G / 'adendo'
D = Path('/home/user/GitHub/delivery'); U = Path('/root/.claude/uploads/ece1d4c3-5fd3-5d37-a54a-2c0b4e5a2396/905c9fcc-ENVIAR_AO_OPUS_CDT21_PREPARO_D4_V005_20261022_074912_679_30032.zip')
NAME = 'CDT21_FULL_ENGINEERING_V005_ADENDO_GAP05_20261022'
H = lambda b: hashlib.sha256(b).hexdigest().upper(); Hf = lambda p: H(Path(p).read_bytes())
OUT = G / 'adendo_stage'
if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir()
def cp(src, rel):
    d = OUT / rel; d.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(src, d)
def wj(rel, obj):
    d = OUT / rel; d.parent.mkdir(parents=True, exist_ok=True); d.write_text(json.dumps(obj, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')

BOUND = {'candidate_v005_sha256': 'E3F1F4790D6AE6E5639F137FAEE3E91B2B8E6FFB51A95F18078DF734553CB145',
         'runtime_code_manifest_sha256': '63CBA7065A719CBCF58F1EB1F088D090B87AE7ABBAF37BE03856619CE1D0D74E',
         'full_engineering_v005_sha256': Hf(D / 'CDT21_FULL_ENGINEERING_V005_20261022.zip'),
         'b06_dispatch_v005_sha256': 'C43805B8D6187449458897C9B01EC34806407850BBECFF3A7CA8913734C09ED0',
         'g5_v005_engineering_receipt_sha256': Hf(D / 'CDT21_G5_V005_FINAL_ENGINEERING_RECEIPT.json')}
assert BOUND['full_engineering_v005_sha256'] == '99C77F4603E3547E34D4513782B5590E10E5B33159F08CB0A1E08E46B6B77662'
LAU = G / 'build/RUN_CDT21_V005_PREPARO_D4_20261022.ps1'; OBS = G / 'src/CDT21_D4_PREDECESSOR_OBSERVER.py'
assert Hf(LAU) == '40D8961B75B5385E42F9312A008D2B46E297ED8F00E7E59DADB55BDA3EA6488F' and Hf(OBS) == 'D724908C82573A6618DD365CFFECF8CCC4502FAEFEE00EB8D446422F4DC8EF1F'
q = json.loads((G / 'qual/OBSERVER_LINUX_QUALIFICATION.json').read_bytes()); m = json.loads((G / 'qual/OBSERVER_MUTANTS.json').read_bytes())
l = json.loads((G / 'qual/LAUNCHER_LINUX_FUNCTIONAL.json').read_bytes()); v = json.loads((A / 'VERIFICACAO_NATIVA_GAP05.json').read_bytes())
assert q['observer_sha256'] == Hf(OBS) and q['passed'] == q['total'] == 23 and m['killed'] == m['total'] == 15 and l['passed'] == l['total'] == 8 and v['pass']
assert l['launcher_sha256'] == Hf(LAU) and v['return_zip']['sha256'] == Hf(U)

cp(A / 'LEIA_PRIMEIRO_ADENDO_GAP05.md', '00_LEIA_PRIMEIRO_ADENDO_GAP05.md')
cp(OBS, '01_PRODUTOR/CDT21_D4_PREDECESSOR_OBSERVER.py')
cp(LAU, '02_LANCADOR/RUN_CDT21_V005_PREPARO_D4_20261022.ps1')
for f in ('src/launcher_template.ps1', 'src/build_preparo_launcher.py', 'build/parse_check.ps1'):
    cp(G / f, '02_LANCADOR/construcao/' + Path(f).name)
cp(G / 'qual/GAP05_PRODUCER_CONSUMER_BINDING_MAP.json', '03_VINCULOS_AOS_CONSUMIDORES/GAP05_PRODUCER_CONSUMER_BINDING_MAP.json')
for f in ('qual/OBSERVER_LINUX_QUALIFICATION.json', 'qual/OBSERVER_MUTANTS.json', 'qual/LAUNCHER_LINUX_FUNCTIONAL.json'):
    cp(G / f, '04_EVIDENCIAS_LINUX/resultados/' + Path(f).name)
for f in ('src/test_d4_predecessor_observer.py', 'src/run_observer_mutants.py', 'src/test_preparo_launcher_linux.py', 'src/build_adendo_gap05.py'):
    cp(G / f, '04_EVIDENCIAS_LINUX/ferramentas/' + Path(f).name)
cp(U, '05_EVIDENCIA_NATIVA/ENVIAR_AO_OPUS_CDT21_PREPARO_D4_V005_20261022_074912_679_30032.zip')
cp(A / 'VERIFICACAO_NATIVA_GAP05.json', '05_EVIDENCIA_NATIVA/VERIFICACAO_NATIVA_GAP05.json')
cp(D / 'PROCEDIMENTO_QUALIFICACAO_NATIVA_PREPARO_D4_V005.md', '05_EVIDENCIA_NATIVA/PROCEDIMENTO_QUALIFICACAO_NATIVA_PREPARO_D4_V005.md')
cp(A / 'P4R1_GATES_SEGUINTES_ATE_O_FULL.md', '06_PROCEDIMENTOS/P4R1_GATES_SEGUINTES_ATE_O_FULL.md')

decisions = {'schema': 'CDT21_FULL_INTEGRATION_REVIEW_DECISIONS_ADENDO_V001', 'binds': BOUND, 'supersedes_in_full_package': {
    '04_MAPA_COMPONENTES_E_CONSUMIDORES/INTEGRATION_REVIEW_DECISIONS.json#GAP-05': 'GAP-05 abaixo',
    '10_PROCEDIMENTOS/P4_GATES_SEGUINTES_ATE_O_FULL.md': '06_PROCEDIMENTOS/P4R1_GATES_SEGUINTES_ATE_O_FULL.md'},
 'gaps': [
  {'id': 'GAP-05', 'decision': 'CLOSED_IN_ENGINEERING__EXTERNAL_PRODUCER__LINUX_AND_NATIVE_LAB_QUALIFIED',
   'basis': 'Produtor externo ao V005 congelado (CDT21_D4_PREDECESSOR_OBSERVER.py D724908C...), composto so de codigo congelado do V005 (D4_ROOTS_EVIDENCE.main/journal_facts, motor Win32Store e PROCESS_CENSUS_MUTEX, preparo strict_json/validate_journal) e autoverificado pelos consumidores congelados (reconcile e fresh_predecessor do bootstrap). Distribuido embutido no lancador autoextraivel RUN_CDT21_V005_PREPARO_D4_20261022.ps1 (40D8961B...).',
   'evidence': ['03_VINCULOS_AOS_CONSUMIDORES (21 exigencias)', '04_EVIDENCIAS_LINUX: 23/23, mutantes 15/15, lancador 8/8',
                '05_EVIDENCIA_NATIVA: Q1 positivo admitido pelo bootstrap congelado com leitura Win32 e mutex real; Q2-Q5 recusados com o motivo exato; verificacao 16/16'],
   'residual': 'Coleta efetiva no momento operacional do D4 (apos B07, <= 300 s antes da admissao), pelo titular, etapa Observar. Nao executada.'},
  {'id': 'P4_EXTRACAO_MANUAL', 'decision': 'RECONCILED_P4R1__SAFE_SELF_EXTRACTION',
   'basis': 'A secao de instalacao do P4 usava extracao manual do instalador. O P4R1 a substitui pela etapa Instalar do lancador: SHA do pacote e da testemunha, membro conferido contra o RUNTIME_CODE_MANIFEST e contra o pin BB245FCF, criacao exclusiva em pasta propria, instalador congelado executado com -WitnessPath. O instalador congelado nao foi reconstruido.',
   'evidence': ['04_EVIDENCIAS_LINUX/resultados/LAUNCHER_LINUX_FUNCTIONAL.json (T4a/T4b)', '05_EVIDENCIA_NATIVA (AUTOEXTRACAO_INSTALADOR=PASS no Windows)'],
   'residual': 'Instalacao real quando o titular decidir (nao e admissao).'},
  {'id': 'GAP-18', 'severity': 'INFO', 'decision': 'NOT_CHANGED__FROZEN_FAIL_CLOSED_BY_EXCEPTION',
   'basis': 'Achado desta qualificacao: com a cadeia do STATE_JOURNAL quebrada, D4_ROOTS_EVIDENCE.journal_facts grava journal.last = None e D4_PREDECESSOR_RECONCILIATION.reconcile lanca AttributeError em vez de devolver BLOCKED. No bootstrap a excecao nao e capturada; o processo termina com codigo diferente de zero e o wrapper selado exige codigo 0 antes de qualquer efeito. Falha fechada, sem efeito; o V005 congelado nao foi alterado. O produtor registra FROZEN_RECONCILE_EXCEPTION.',
   'evidence': ['04_EVIDENCIAS_LINUX/resultados/OBSERVER_LINUX_QUALIFICATION.json (N11)'], 'residual': 'Registrado para o auditor B06.'}]}
wj('07_DECISOES_E_ESTADO/INTEGRATION_REVIEW_DECISIONS_ADENDO_GAP05.json', decisions)
gates = {'schema': 'CDT21_FULL_GATE_STATE_V003', 'as_of': '2026-10-22', 'binds': BOUND, 'gates': [
  {'gate': 'G5 tecnico nativo do V005', 'state': 'PASS_NATIVE_V005_G5_TECHNICAL_FIVE_PART (recibo do implementador, verificado 32/32)'},
  {'gate': 'Decisao G5 e recibo de estagio G5', 'state': 'NOT_ISSUED (origem)'},
  {'gate': 'B06', 'state': 'NOT_STARTED (Work independente; despacho C43805B8 pronto; este adendo e suplemento a auditar)'},
  {'gate': 'Instalacao do V005', 'state': 'NOT_STARTED; procedimento: lancador -Etapa Instalar (P4R1)'},
  {'gate': 'B07', 'state': 'NOT_STARTED (2 overlays da origem, GAP-10)'},
  {'gate': 'Entradas da origem para o D4 (recibo de admissao de politica, pacote de revisao D4, reconciliacao corrente)', 'state': 'NOT_ISSUED (origem)'},
  {'gate': 'Observacao nativa do predecessor D4', 'state': 'PRODUCER_READY_QUALIFIED; COLLECTION_NOT_STARTED (no momento operacional do D4, -Etapa Observar)'},
  {'gate': 'D4, D5, CANARY, FULL_PREP, FULL_ADMISSION, FULL', 'state': 'NOT_STARTED'},
  {'gate': 'Queda fisica de energia', 'state': 'NOT_TESTED_PHYSICAL_POWERLOSS'}]}
wj('07_DECISOES_E_ESTADO/ESTADO_DOS_GATES_ADENDO_GAP05.json', gates)
members = sorted(p for p in OUT.rglob('*') if p.is_file())
man = {'schema': 'CDT21_FULL_ENGINEERING_ADENDO_MANIFEST_V001', 'package': NAME, 'binds': BOUND, 'v005_modified': False,
       'approved_components_rebuilt': False,
       'executor_sha256': {'RUN_CDT21_V005_PREPARO_D4_20261022.ps1': Hf(LAU), 'CDT21_D4_PREDECESSOR_OBSERVER.py': Hf(OBS)},
       'members': {str(p.relative_to(OUT)): {'sha256': Hf(p), 'bytes': p.stat().st_size} for p in members}}
(OUT / 'MANIFESTO.json').write_text(json.dumps(man, indent=1, sort_keys=True, ensure_ascii=False), encoding='utf-8')
zp = D / (NAME + '.zip')
with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(p for p in OUT.rglob('*') if p.is_file()):
        zi = zipfile.ZipInfo(str(p.relative_to(OUT)), (2026, 10, 22, 12, 0, 0)); zi.external_attr = 0o644 << 16
        zi.compress_type = zipfile.ZIP_STORED if p.suffix == '.zip' else zipfile.ZIP_DEFLATED
        z.writestr(zi, p.read_bytes())
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None
    mm = json.loads(z.read('MANIFESTO.json'))
    assert all(H(z.read(k)) == e['sha256'] for k, e in mm['members'].items()) and len(z.namelist()) == len(mm['members']) + 1
print(zp.name, Hf(zp), zp.stat().st_size, len(mm['members']) + 1, 'MANIFESTO', Hf(OUT / 'MANIFESTO.json'))
for rel in ('07_DECISOES_E_ESTADO/INTEGRATION_REVIEW_DECISIONS_ADENDO_GAP05.json', '07_DECISOES_E_ESTADO/ESTADO_DOS_GATES_ADENDO_GAP05.json',
            '06_PROCEDIMENTOS/P4R1_GATES_SEGUINTES_ATE_O_FULL.md', '05_EVIDENCIA_NATIVA/VERIFICACAO_NATIVA_GAP05.json',
            '03_VINCULOS_AOS_CONSUMIDORES/GAP05_PRODUCER_CONSUMER_BINDING_MAP.json', '00_LEIA_PRIMEIRO_ADENDO_GAP05.md'):
    print(Hf(OUT / rel), rel)
